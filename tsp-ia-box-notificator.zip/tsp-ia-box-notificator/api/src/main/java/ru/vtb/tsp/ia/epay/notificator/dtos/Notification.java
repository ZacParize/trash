package ru.vtb.tsp.ia.epay.notificator.dtos;

import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeader;
import ru.vtb.tsp.ia.epay.notificator.dtos.payloads.NotificationPayload;

public interface Notification extends NotificationHeader, NotificationPayload {

}