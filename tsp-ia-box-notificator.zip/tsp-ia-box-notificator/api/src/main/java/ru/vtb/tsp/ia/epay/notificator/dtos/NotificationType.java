package ru.vtb.tsp.ia.epay.notificator.dtos;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

public enum NotificationType {

  /*
   * Notification of timeout between 3DS request and acs response.
   * Default value is 10 seconds.
   */
  THREEDS_METHOD_TIMEOUT,

  /*
   * Notification about timeout between 3DS request and acs response.
   * Default value is 15 minutes.
   */
  OTP_PAGE_TIMEOUT,

  /*
   * Multicard request retry notification.
   */
  MULTICARD_REQUEST_RETRY,

  /*
   * CFT create docs request retry notification.
   */
  CFT_CREATE_DOCS_REQUEST_RETRY,


  CFT_CREATE_DOCS_STEP_TWO_REQUEST_RETRY,

  /*
   * CFT execute docs request retry notification.
   */
  CFT_EXECUTE_DOCS_REQUEST_RETRY,

  /*
   * CFT revert docs request retry notification.
   */
  CFT_REVERT_DOCS_REQUEST_RETRY,

  /*
   * Timeout between the creation of a transaction for payment via Mir Pay
   * and its supposed completion, to check the success of the payment.
   */
  MIR_PAY_DECLINE_CHECK_TIMEOUT,

  /*
   * Timeout between the creation of a transaction for payment via Mir Pay
   * and its supposed expiration time of the order
   */
  MIR_PAY_EXPIRATION_ORDER_TIMEOUT,

  /*
   * Запрос на добавление документа в очередь печати.
   *
   */
  FISCAL_QUEUE_REQUEST_RETRY,

  /*
   * Запрос текущего статуса обработки документа.
   *
   */
  FISCAL_STATUS_REQUEST_RETRY,

  /*
   * Refresh sbp payment or refund status retry
   *
   */
  SBP_REFRESH_STATUS_REQUEST_RETRY;

  @NoArgsConstructor(access = AccessLevel.PRIVATE)
  public static class Constants {

    public static final String THREEDS_METHOD_TIMEOUT_NAME = "THREEDS_METHOD_TIMEOUT";
    public static final String OTP_PAGE_TIMEOUT_NAME = "OTP_PAGE_TIMEOUT";
    public static final String MULTICARD_REQUEST_RETRY_NAME = "MULTICARD_REQUEST_RETRY";
    public static final String CFT_CREATE_DOCS_STEP_TWO_REQUEST_RETRY_NAME = "CFT_CREATE_DOCS_STEP_TWO_REQUEST_RETRY";
    public static final String CFT_CREATE_DOCS_REQUEST_RETRY_NAME = "CFT_CREATE_DOCS_REQUEST_RETRY";
    public static final String CFT_EXECUTE_DOCS_REQUEST_RETRY_NAME = "CFT_EXECUTE_DOCS_REQUEST_RETRY";
    public static final String CFT_REVERT_DOCS_REQUEST_RETRY_NAME = "CFT_REVERT_DOCS_REQUEST_RETRY";
    public static final String MIR_PAY_DECLINE_CHECK_TIMEOUT_NAME = "MIR_PAY_DECLINE_CHECK_TIMEOUT";
    public static final String MIR_PAY_EXPIRATION_ORDER_TIMEOUT_NAME = "MIR_PAY_EXPIRATION_ORDER_TIMEOUT";
    public static final String SBP_REFRESH_STATUS_REQUEST_RETRY_NAME = "SBP_REFRESH_STATUS_REQUEST_RETRY";

  }
}