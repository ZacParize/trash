package ru.vtb.tsp.ia.epay.notificator.dtos.headers;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

public interface NotificationHeader extends Serializable {

  @NotEmpty String getCode();

  void setCode(@NotBlank String code);

  @NotNull
  NotificationType getType();

  void setType(@NotNull NotificationType type);

  @NotEmpty List<NotificationAddress> getDestination();

  void setDestination(@NotEmpty List<NotificationAddress> destination);

  @NotNull LocalDateTime getSentAt();

  void setSentAt(@NotNull LocalDateTime sentAt);

}