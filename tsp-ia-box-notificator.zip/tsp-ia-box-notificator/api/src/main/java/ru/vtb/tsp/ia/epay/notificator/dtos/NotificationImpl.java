package ru.vtb.tsp.ia.epay.notificator.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeaderImpl;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationImpl implements Notification {

  @Builder.Default
  @NotNull
  @JsonProperty("header")
  private NotificationHeaderImpl header = new NotificationHeaderImpl();

  @NotNull
  @JsonProperty("payload")
  private Object payload;

  @NotBlank
  @Override
  public String getCode() {
    return Objects.requireNonNull(header, "Notification header is not initialized").getCode();
  }

  @Override
  public void setCode(@NotBlank String code) {
    Objects.requireNonNull(header, "Notification header is not initialized").setCode(code);
  }

  @NotNull
  @Override
  public NotificationType getType() {
    return Objects.requireNonNull(header, "Notification header is not initialized").getType();
  }

  @Override
  public void setType(@NotNull NotificationType type) {
    Objects.requireNonNull(header, "Notification header is not initialized").setType(type);
  }

  @NotEmpty
  @Override
  public List<NotificationAddress> getDestination() {
    return Objects.requireNonNull(header, "Notification header is not initialized").getDestination();
  }

  @Override
  public void setDestination(@NotEmpty List<NotificationAddress> destination) {
    Objects.requireNonNull(header, "Notification header is not initialized").setDestination(destination);
  }

  @NotNull
  @Override
  public LocalDateTime getSentAt() {
    return Objects.requireNonNull(header, "Notification header is not initialized").getSentAt();
  }

  @Override
  public void setSentAt(@NotNull LocalDateTime sentAt) {
    Objects.requireNonNull(header, "Notification header is not initialized").setSentAt(sentAt);
  }

}