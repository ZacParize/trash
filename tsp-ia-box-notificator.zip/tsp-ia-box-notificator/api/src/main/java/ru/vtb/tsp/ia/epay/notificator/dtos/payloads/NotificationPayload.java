package ru.vtb.tsp.ia.epay.notificator.dtos.payloads;

import java.io.Serializable;
import javax.validation.constraints.NotNull;

public interface NotificationPayload extends Serializable {

  @NotNull Object getPayload();

  void setPayload(@NotNull Object payload);

}