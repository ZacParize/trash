package ru.vtb.tsp.ia.epay.notificator.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum NotificationAddress {

  APILISTENER(Constants.APILISTENER_ADDRESS),
  NOTIFICATOR(Constants.NOTIFICATOR_ADDRESS),
  GATEWAY_RETRY(Constants.GATEWAY_RETRY_ADDRESS),
  ABSADAPTER_RETRY(Constants.ABSADAPTER_RETRY_ADDRESS),
  FISCALIZATION_RETRY(Constants.FISCALIZATION_RETRY_ADDRESS),
  SBPADAPTER_NOTIFICATION(Constants.SBPADAPTER_NOTIFICATION_ADDRESS);

  private final String address;

  public static @Nullable NotificationAddress findByAddress(@Nullable String address) {
    if (ObjectUtils.isEmpty(address)) {
      return null;
    }
    for (var val : NotificationAddress.values()) {
      if (val.getAddress().equals(address)) {
        return val;
      }
    }
    return null;
  }

  public static @NotEmpty List<String> getAllAddresses() {
    return Stream.of(NotificationAddress.values())
                 .map(NotificationAddress::getAddress)
                 .collect(Collectors.toList());
  }

  @NoArgsConstructor(access = AccessLevel.PRIVATE)
  public static class Constants {

    public static final String APILISTENER_ADDRESS = "epay.apilistener-topic";
    public static final String NOTIFICATOR_ADDRESS = "epay.notificator-topic";
    public static final String GATEWAY_RETRY_ADDRESS = "epay.gatewayadapter-retry-topic";
    public static final String ABSADAPTER_RETRY_ADDRESS = "epay.absadapter-retry-topic";
    public static final String FISCALIZATION_RETRY_ADDRESS = "epay.fiscalization-retry-topic";
    public static final String SBPADAPTER_NOTIFICATION_ADDRESS = "epay.sbpadapter-notification-topic";

  }
}