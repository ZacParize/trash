package ru.vtb.tsp.ia.epay.notificator.services;

import static ru.vtb.tsp.ia.epay.notificator.services.NotificationService.DISPERSION_TIME_SECONDS;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.util.SerializationUtils;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;
import ru.vtb.tsp.ia.epay.notificator.configs.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.entities.Notification;
import ru.vtb.tsp.ia.epay.notificator.entities.NotificationState;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProcessorService {

  private final Validator validator;
  private final NotificationService notificationService;

  @KafkaListener(topics = "${app.kafka.consumer.topics}",
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  public void process(@NotNull ConsumerRecord<String, ?> record,
                      @NotNull Acknowledgment acknowledgment) {
    try {
      notificationService.transform(record.value())
          .filter(np -> {
            final var errors = new MapBindingResult(new HashMap<String, String>(),
                Objects.requireNonNull(np.getCode(), "Notification code can't be null"));
            validator.validate(np, errors);
            final var errorCount = errors.getTargetMap().values().size();
            log.info("Notification with code {} has {} errors", np.getCode(),
                errorCount == 0 ? "no" : String.valueOf(errorCount));
            return !errors.hasErrors();
          })
          .ifPresent(np -> {
            final var createDate = LocalDateTime.now(ZoneOffset.UTC);
            notificationService.create(Notification.builder()
                  .code(np.getCode())
                  .type(np.getType())
                  .state(createDate.minusSeconds(DISPERSION_TIME_SECONDS).isBefore(np.getSentAt())
                      ? NotificationState.CREATED : NotificationState.REJECTED)
                  .sentAt(np.getSentAt())
                  .destination(np.getDestination().stream()
                      .map(NotificationAddress::getAddress)
                      .toList()
                      .toArray(new String[]{}))
                  .payload(SerializationUtils.serialize(np.getPayload()))
                  .createdAt(createDate)
                  .modifiedAt(createDate)
                  .build())
                .ifPresent(nt -> log.info("Notification with code {} was persisted {}",
                    nt.getCode(), nt));
          });
    } catch (Exception ex) {
      log.error("Notification key {} can't be processed", record.key(), ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}