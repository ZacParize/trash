package ru.vtb.tsp.ia.epay.notificator.entities;

import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum NotificationState {

  CREATED("CREATED"),
  PROCESSED("PROCESSED"),
  REJECTED("REJECTED");

  public static final List<NotificationState> FINAL_STATES = List.of(PROCESSED, REJECTED);
  private final String value;

}