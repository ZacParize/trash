package ru.vtb.tsp.ia.epay.notificator.services;

import java.util.Arrays;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.SerializationUtils;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;
import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeaderImpl;

@Slf4j
@RequiredArgsConstructor
@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_PROTOTYPE)
public class NotificationTask implements Runnable {

  private final Long id;
  private final NotificationService notificationService;
  private final KafkaService kafkaService;

  @Override
  @Transactional
  public void run() {
    notificationService.lockById(id)
        .ifPresent(nt -> {
          try {
            if (nt.isCompleted()) {
              notificationService.removeScheduled(nt.getId());
              return;
            }
            final var destination = Arrays.asList(
                Objects.requireNonNullElse(nt.getDestination(), new String[]{}));
            kafkaService.send(new GenericMessage<>(NotificationImpl.builder()
                .header(NotificationHeaderImpl.builder()
                    .sentAt(nt.getSentAt())
                    .code(nt.getCode())
                    .destination(destination.stream()
                        .map(NotificationAddress::findByAddress)
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList()))
                    .type(nt.getType())
                    .build())
                .payload(SerializationUtils.deserialize(nt.getPayload()))
                .build()), destination);
            notificationService.complete(nt.getId());
            log.info("Notification id {} has been processed", nt.getId());
          } catch (Exception ex) {
            notificationService.schedule(nt.getId());
            log.error(
                "Error occurred during notification id {} processing, "
                    + "notification was scheduled again",
                nt.getId(), ex);
          }
        });
  }
}