package ru.vtb.tsp.ia.epay.notificator.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Lookup;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ThreadPoolTaskScheduler;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.entities.NotificationState;
import ru.vtb.tsp.ia.epay.notificator.repos.NotificationRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public abstract class NotificationService implements
    GenericTransformer<Object, Optional<Notification>> {

  public static final long DISPERSION_TIME_SECONDS = 600L;
  private static final int LIMIT = 200;
  private static final ZoneOffset ZERO_OFFSET = ZoneOffset.ofTotalSeconds(0);
  private static final Set<Long> SCHEDULED_NOTIFICATIONS = ConcurrentHashMap.newKeySet();
  private final ThreadPoolTaskScheduler threadPoolTaskScheduler;
  private final MessageAdapter messageAdapter;
  private final KafkaService kafkaService;
  private final NotificationRepository notificationRepository;


  @Transactional
  public @NotNull Optional<ru.vtb.tsp.ia.epay.notificator.entities.Notification> create(
      @Nullable ru.vtb.tsp.ia.epay.notificator.entities.Notification notification) {
    return Optional.ofNullable(notification).map(notificationRepository::saveOrUpdate);
  }

  @Transactional
  public @NotNull Optional<ru.vtb.tsp.ia.epay.notificator.entities.Notification> lockById(
      @Nullable Long id) {
    return Optional.ofNullable(id).flatMap(notificationRepository::findAndLockById);
  }

  public void removeScheduled(@Nullable Long id) {
    SCHEDULED_NOTIFICATIONS.remove(id);
  }

  @Transactional
  public @NotNull Optional<ru.vtb.tsp.ia.epay.notificator.entities.Notification> complete(
      @Nullable Long id) {
    return lockById(id)
        .map(nt -> {
          if (nt.isCompleted()) {
            removeScheduled(nt.getId());
            return Optional.of(nt);
          }
          nt = notificationRepository.saveOrUpdate(nt.withState(NotificationState.PROCESSED)
              .withModifiedAt(LocalDateTime.now(ZoneOffset.UTC)));
          removeScheduled(nt.getId());
          return Optional.of(nt);
        })
        .orElse(Optional.empty());
  }

  @Transactional
  public @NotNull Optional<ru.vtb.tsp.ia.epay.notificator.entities.Notification> schedule(
      @Nullable Long id) {
    return lockById(id)
        .map(notification -> {
          if (notification.isCompleted()) {
            removeScheduled(notification.getId());
            return Optional.of(notification);
          }
          threadPoolTaskScheduler.schedule(createTask(notification.getId(),
                  this, kafkaService),
              notification.getSentAt().toInstant(ZERO_OFFSET));
          SCHEDULED_NOTIFICATIONS.add(notification.getId());
          return Optional.of(notification);
        })
        .orElse(Optional.empty());
  }

  @Transactional
  @Scheduled(fixedDelay = 500)
  public void handle() {
    final var timeMark = LocalDateTime.now(ZoneOffset.UTC);
    notificationRepository.findAndLockByStateAndSentByWithLimit(NotificationState.CREATED,
            timeMark.minusSeconds(DISPERSION_TIME_SECONDS),
            timeMark.plusSeconds(DISPERSION_TIME_SECONDS), LIMIT)
        .stream()
        .map(ru.vtb.tsp.ia.epay.notificator.entities.Notification::getId)
        .filter(id -> !SCHEDULED_NOTIFICATIONS.contains(id))
        .forEach(this::schedule);
  }

  @Override
  public @NotNull Optional<Notification> transform(@Nullable Object message) {
    return Optional.ofNullable(message)
        .map(messageAdapter::deserializeNotification)
        .or(() -> {
          kafkaService.sendToDlq(message);
          return Optional.empty();
        });
  }

  @Lookup
  public abstract NotificationTask createTask(@NotNull Long notificationId,
      @NotNull NotificationService notificationService,
      @NotNull KafkaService kafkaService);

}