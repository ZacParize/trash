package ru.vtb.tsp.ia.epay.notificator.configs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.NotEmpty;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import ru.vtb.tsp.ia.epay.core.configurations.KafkaConfiguration;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;

@Configuration
@Slf4j
public class KafkaProducerConfig {

  private static final String ACKS = "all";
  private static final int BATCH_SIZE = 16384;
  private static final int BUFFER_MEMORY = 33554432;
  private static final String COMPRESSION_TYPE = "gzip";
  private static final int RETRIES = 1;
  //public static final String TRANSACTIONAL_ID = "epay-notificator-tx-";

  @Value("${spring.kafka.bootstrap-servers}")
  @NotEmpty
  private List<String> bootstrapServers;

  private final List<String> producerTopics = NotificationAddress.getAllAddresses();

  @Value("${app.kafka.partitions-count}")
  private int partitionsCount;

  @Value("${app.kafka.replicas-count}")
  private int replicasCount;

  @Value("${spring.kafka.producer.ssl.protocol:#{null}}")
  private String sslProtocol;

  @Value("${spring.kafka.producer.ssl.trust-store-type:#{null}}")
  private String sslTrustStoreType;

  @Value("${spring.kafka.producer.ssl.trust-store-location:#{null}}")
  private String sslTrustStoreLocation;

  @Value("${spring.kafka.producer.ssl.trust-store-password:#{null}}")
  private String sslTrustStorePassword;

  @Value("${spring.kafka.producer.ssl.key-store-type:#{null}}")
  private String sslKeyStoreType;

  @Value("${spring.kafka.producer.ssl.key-store-location:#{null}}")
  private String sslKeyStoreLocation;

  @Value("${spring.kafka.producer.ssl.key-store-password:#{null}}")
  private String sslKeyStorePassword;

  @Value("${spring.kafka.producer.ssl.key-password:#{null}}")
  private String sslKeyPassword;

  @SneakyThrows
  public Map<String, Object> producerConfigs() {
    final var configuration = new HashMap<String, Object>();
    configuration.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    configuration.put(ProducerConfig.ACKS_CONFIG, ACKS);
    configuration.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, true);
    configuration.put(ProducerConfig.BATCH_SIZE_CONFIG, BATCH_SIZE);
    configuration.put(ProducerConfig.BUFFER_MEMORY_CONFIG, BUFFER_MEMORY);
    configuration.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configuration.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    configuration.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, COMPRESSION_TYPE);
    configuration.put(ProducerConfig.RETRIES_CONFIG, RETRIES);
    //configuration.put(ProducerConfig.TRANSACTIONAL_ID_CONFIG, TRANSACTIONAL_ID);
    //configuration.put(ProducerConfig.ENABLE_IDEMPOTENCE_CONFIG, true);
    KafkaConfiguration.setSslProperties(configuration,
                               sslProtocol,
                               sslTrustStoreType,
                               sslTrustStoreLocation,
                               sslTrustStorePassword,
                               sslKeyStoreType,
                               sslKeyStoreLocation,
                               sslKeyStorePassword,
                               sslKeyPassword);
    KafkaConfiguration.createTopics(configuration, producerTopics, partitionsCount, replicasCount);
    return configuration;
  }

  @Bean
  public ProducerFactory<String, ?> producerFactory() {
    return new DefaultKafkaProducerFactory<>(producerConfigs());
  }

  @Bean
  public KafkaTemplate<String, ?> kafkaTemplate(ProducerFactory<String, ?> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

}