package ru.vtb.tsp.ia.epay.notificator.repos;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.util.Assert;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.notificator.entities.Notification;
import ru.vtb.tsp.ia.epay.notificator.entities.NotificationState;

public interface NotificationRepository extends CrudRepository<Notification, String> {

  String COMMON_SELECT =
      "select n.id, "
          + "n.code,"
          + "n.type, "
          + "n.state, "
          + "n.sent_at, "
          + "n.payload, "
          + "n.destination, "
          + "n.created_at, "
          + "n.modified_at, "
          + "n.version "
          + "from notifications n";

  @NotNull
  @Query(COMMON_SELECT + " where n.id = :id")
  Optional<Notification> findById(@Nullable @Param("id") Long id);

  @NotNull
  @Query(COMMON_SELECT + " where n.id = :id for update of n")
  Optional<Notification> findAndLockById(@Nullable @Param("id") Long id);

  @NotNull
  @Query(COMMON_SELECT + " where n.code = :code order by n.id")
  List<Notification> findByCode(@Nullable @Param("code") String code);

  @NotNull
  @Query(COMMON_SELECT + " where n.state = :state "
      + "and (to_timestamp((:after)::text, 'YYYY-MM-DD HH24:MI:SS') is null "
      + "or n.sent_at >= to_timestamp((:after)::text, 'YYYY-MM-DD HH24:MI:SS')) "
      + "and (to_timestamp((:before)::text, 'YYYY-MM-DD HH24:MI:SS') is null "
      + "or n.sent_at <= to_timestamp((:before)::text, 'YYYY-MM-DD HH24:MI:SS')) "
      + "order by n.id "
      + "limit :limit "
      + "for update of n skip locked")
  List<Notification> findAndLockByStateAndSentByWithLimit(
      @Nullable @Param("state") NotificationState state,
      @Nullable @Param("after") LocalDateTime after,
      @Nullable @Param("before") LocalDateTime before,
      @Param("limit") int limit);

  @NotNull
  @Query(
      "insert into notifications ( id, code, type, state, sent_at, payload, destination, "
          + "created_at, modified_at, version )"
          + "values ( coalesce(:id, nextval('notifications_id_sequence')), :code, :type, :state, "
          + ":sentAt, :payload, :destination, :createdAt, :modifiedAt, :version) "
          + "on conflict (id) do update set "
          + "id = :id, code = :code, type = :type, state = :state, "
          + "sent_at = :sentAt, payload = :payload, destination = :destination, "
          + "created_at = :createdAt, modified_at = :modifiedAt, version = :version + 1 "
          + "RETURNING *")
  Notification saveOrUpdate(@NotNull @Param("id") Long id,
      @NotBlank @Param("code") String code,
      @NotEmpty @Param("type") NotificationType type,
      @NotNull @Param("state") NotificationState state,
      @NotNull @Param("sentAt") LocalDateTime sentAt,
      @NotNull @Param("payload") Serializable payload,
      @NotNull @Param("destination") String[] destination,
      @NotNull @Param("createdAt") LocalDateTime createdAt,
      @NotNull @Param("modifiedAt") LocalDateTime modifiedAt,
      @NotNull @Param("version") int version);

  default @NotNull Notification saveOrUpdate(@Nullable Notification notification) {
    Objects.requireNonNull(notification, "Notification can't be null");
    Objects.requireNonNull(notification.getCode(), "Notification's code can't be null");
    Objects.requireNonNull(notification.getState(), "Notification's state can't be null");
    Objects.requireNonNull(notification.getSentAt(), "Notification's sending date can't be null");
    Objects.requireNonNull(notification.getPayload(), "Notification's payload can't be null");
    Objects.requireNonNull(notification.getDestination(),
        "Notification's destination can't be null");
    Objects.requireNonNull(notification.getCreatedAt(),
        "Notification's creation date can't be null");
    Objects.requireNonNull(notification.getModifiedAt(),
        "Notification's modification date can't be null");
    Assert.isTrue(notification.getCreatedAt().isBefore(notification.getModifiedAt())
            || notification.getCreatedAt().isEqual(notification.getModifiedAt()),
        "Notification's create date should be before modification date");
    MDC.put(MDCKeySupplier.UNIQUE_KEY, UUID.randomUUID().toString());
    return findById(saveOrUpdate(notification.getId(),
        notification.getCode(),
        notification.getType(),
        notification.getState(),
        notification.getSentAt(),
        notification.getPayload(),
        notification.getDestination(),
        notification.getCreatedAt(),
        notification.getModifiedAt(),
        notification.getVersion()).getId()).orElse(null);
  }

  @Query("select n.code from notifications n where n.code in (:uuids) for update of n")
  Optional<List<String>> findAllExpiredNotificationsByIdForUpdate(
      @NotNull @Param("uuids") List<String> uuids);

  @Query("select n.code from notifications n where n.state in (:states) and n.created_at < "
      + " :createdAt limit :limit")
  List<String> findAllNotificationsByStateAndCreatedDateWithLimit(
      @NotNull @Param("states") List<String> states,
      @NotNull @Param("createdAt") LocalDateTime createdAt,
      @Param("limit") int limit);

  default Optional<List<String>> findAllExpiredNotificationsForUpdate(
      @NotNull List<String> uuids) {
    return findAllExpiredNotificationsByIdForUpdate(uuids);
  }

  default List<String> findAllNotificationsByStateAndCreatedDate(
      @NotNull List<NotificationState> states,
      @NotNull LocalDateTime createdAt,
      int limit) {
    final var statesForDelete = states.stream().map(NotificationState::getValue)
        .collect(Collectors.toList());
    return findAllNotificationsByStateAndCreatedDateWithLimit(statesForDelete, createdAt, limit);
  }

  @Modifying
  @Query("delete from notifications where code in (:uuids)")
  void deleteNotificationsById(@NotNull @Param("uuids") List<String> uuids);
}