package ru.vtb.tsp.ia.epay.notificator.configs;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;


@Slf4j
@Configuration
@RequiredArgsConstructor
@EnableScheduling
@ComponentScan(value = {"ru.vtb.tsp.ia.epay.notificator", "ru.vtb.tsp.ia.epay.core.configurations",
    "ru.vtb.tsp.ia.epay.core.utils", "ru.vtb.tsp.ia.epay.core.services"})
public class AppConfig {

}