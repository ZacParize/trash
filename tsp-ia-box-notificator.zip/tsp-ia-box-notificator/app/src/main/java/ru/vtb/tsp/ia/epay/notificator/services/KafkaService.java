package ru.vtb.tsp.ia.epay.notificator.services;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;

@Slf4j
@Service
public class KafkaService {

  private final KafkaTemplate<String, Notification> kafkaTemplate;
  private final String dlqTopic;

  public KafkaService(KafkaTemplate<String, Notification> kafkaTemplate,
      @Value("${app.kafka.dlq-topic}") @NotBlank String dlqTopic) {
    this.kafkaTemplate = kafkaTemplate;
    this.dlqTopic = dlqTopic;
  }

  public void sendToDlq(@Nullable Object message) {
    if (Objects.isNull(message)) {
      return;
    }
    final var headers = new HashMap<String, Object>();
    headers.put(KafkaHeaders.TOPIC, dlqTopic);
    kafkaTemplate.send(new GenericMessage<>(message, headers));
    log.info("Notification message was poisoned and send to dlq {}", message);
  }

  public void send(@Nullable Message<Notification> message, @Nullable List<String> topics) {
    if (ObjectUtils.isEmpty(message) || ObjectUtils.isEmpty(topics)) {
      return;
    }
    final var headers = new HashMap<>(message.getHeaders());
    headers.put(KafkaHeaders.MESSAGE_KEY, message.getPayload().getCode());
    topics.forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(message.getPayload(), headers))
          .addCallback(new ListenableFutureCallback<>() {

            @Override
            public void onSuccess(@NotNull SendResult<String, Notification> result) {
              log.info("Notification with code {} was sent", message.getPayload().getCode());
            }

            @Override
            public void onFailure(@NotNull Throwable ex) {
              log.error("Error during sending notification with code {}",
                  message.getPayload().getCode(), ex);
            }
          });
    });
  }

}
