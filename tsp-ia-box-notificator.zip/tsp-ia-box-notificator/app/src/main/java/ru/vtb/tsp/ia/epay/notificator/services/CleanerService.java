package ru.vtb.tsp.ia.epay.notificator.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.CollectionUtils;
import ru.vtb.smartreplication.core.provider.ChangeProvider;
import ru.vtb.smartreplication.model.ChangeItem;
import ru.vtb.smartreplication.model.ProviderType;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.notificator.entities.NotificationState;
import ru.vtb.tsp.ia.epay.notificator.repos.NotificationRepository;

@Slf4j
@Service
public class CleanerService {

  public static int EXPIRE_DAYS_PERIOD = 60;
  public static int LIMIT_EXPIRED_NOTIFICATIONS = 300;

  private final NotificationRepository notificationRepository;
  private final PlatformTransactionManager platformTransactionManager;
  private final ChangeProvider changeProvider;

  public CleanerService(
      NotificationRepository notificationRepository,
      PlatformTransactionManager platformTransactionManager,
      @Nullable ChangeProvider changeProvider) {
    this.notificationRepository = notificationRepository;
    this.platformTransactionManager = platformTransactionManager;
    this.changeProvider = changeProvider;
  }

  //каждый месяц в первый день месяца 24:00:00
  @Scheduled(cron = "0 0 0 1 * ?")
  @PostConstruct
  public void clean() {
    log.info("start cleaning expired notifications {}", LocalDateTime.now(ZoneOffset.UTC));
    boolean flag = true;
    while (flag) {
      final var ids = notificationRepository.findAllNotificationsByStateAndCreatedDate(
          NotificationState.FINAL_STATES,
          LocalDateTime.now(ZoneOffset.UTC).minusDays(EXPIRE_DAYS_PERIOD),
          LIMIT_EXPIRED_NOTIFICATIONS);
      if (CollectionUtils.isEmpty(ids)) {
        log.info("no expired notifications");
        flag = false;
      } else {
        log.info("found {} expired notifications", ids.size());
        selectAndDeleteExpiredNotifications(ids);
      }
    }
    log.info("finish cleaning expired notifications {}", LocalDateTime.now(ZoneOffset.UTC));
  }

  public void selectAndDeleteExpiredNotifications(List<String> ids) {
    final var txTemplate = new TransactionTemplate(platformTransactionManager);
    txTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRED);
    txTemplate.executeWithoutResult(transactionStatus -> {
      try {
        notificationRepository.findAllExpiredNotificationsForUpdate(ids)
            .ifPresent(values -> {
              MDC.put(MDCKeySupplier.UNIQUE_KEY, UUID.randomUUID().toString());
              notificationRepository.deleteNotificationsById(values);
              if (Objects.nonNull(changeProvider)) {
                //формирование корректного ВИ, где в качестве ключа передается code, вместо id
                List<ChangeItem> changeItemList = changeProvider.getCurrentBuilder(
                        ProviderType.SMART_REPLICATION)
                    .getSnapshot().getPayload();
                for (int i = 0; i < changeItemList.size(); i++) {
                  changeItemList.get(i).getObjectId().clear();
                  changeItemList.get(i).getObjectId().put("code", values.get(i));
                }
              }
              log.info("deleted {} expired notifications", values.size());
            });
      } catch (Exception e) {
        log.error("error occurred while deleting notifications", e);
        transactionStatus.setRollbackOnly();
        throw e;
      }
    });
  }
}
