package ru.vtb.tsp.ia.epay.notificator.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Table("notifications")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Notification {

  @Id
  @Column("id")
  @JsonProperty("id")
  private Long id;

  @NotBlank
  @Column("code")
  @JsonProperty("code")
  private String code;

  @NotNull
  @Column("state")
  @JsonProperty("state")
  private NotificationState state;

  @NotNull
  @Column("type")
  @JsonProperty("type")
  private NotificationType type;

  @NotNull
  @Column("sent_at")
  @JsonProperty("sentAt")
  private LocalDateTime sentAt;

  @NotNull
  @Column("payload")
  @JsonProperty("payload")
  private byte[] payload;

  @NotBlank
  @Column("destination")
  @JsonProperty("destination")
  private String[] destination;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @NotNull
  @Column("modified_at")
  @JsonProperty("modifiedAt")
  private LocalDateTime modifiedAt;

  @Version
  @Column("version")
  @JsonProperty("version")
  private int version;

  public boolean isProcessed() {
    return NotificationState.PROCESSED.equals(state);
  }

  public boolean isRejected() {
    return NotificationState.REJECTED.equals(state);
  }

  public boolean isCompleted() {
    return isProcessed() || isRejected();
  }

}