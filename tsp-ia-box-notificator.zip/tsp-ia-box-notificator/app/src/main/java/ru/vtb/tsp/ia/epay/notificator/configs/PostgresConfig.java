package ru.vtb.tsp.ia.epay.notificator.configs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.util.PGobject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.jdbc.core.convert.JdbcCustomConversions;
import org.springframework.data.jdbc.repository.config.AbstractJdbcConfiguration;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParamValue;

@Slf4j
@Configuration
@RequiredArgsConstructor
@EnableJdbcRepositories(basePackages = {"ru.vtb.tsp.ia.epay.notificator.repos"},
    basePackageClasses = {ru.vtb.tsp.ia.epay.core.repositories.StandInParamsRepository.class})
public class PostgresConfig extends AbstractJdbcConfiguration {

  private final ObjectMapper objectMapper;

  @Bean
  @Override
  public JdbcCustomConversions jdbcCustomConversions() {
    return new JdbcCustomConversions(List.of(
        new PGobjectToStringConverter(),
        new JsonObjectToStringConverter(objectMapper),
        new PGobjectToStandInParamValueConverter(objectMapper)
    ));
  }

  @ReadingConverter
  static class PGobjectToStringConverter implements Converter<PGobject, String> {

    @Override
    public String convert(PGobject source) {
      return source.getValue();
    }
  }

  @ReadingConverter
  @RequiredArgsConstructor
  static class PGobjectToStandInParamValueConverter
      implements Converter<PGobject, StandInParamValue> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public StandInParamValue convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), StandInParamValue.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize stand in param value", e);
        return null;
      }
    }
  }

  @WritingConverter
  @RequiredArgsConstructor
  static class JsonObjectToStringConverter implements Converter<JsonObject, String> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public String convert(@NotNull JsonObject source) {
      try {
        return objectMapper.writeValueAsString(source);
      } catch (JsonProcessingException e) {
        log.error("Can not serialize instance of class {}", source.getClass().getSimpleName(), e);
        return null;
      }
    }
  }

}
