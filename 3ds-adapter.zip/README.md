Internet acquiring, box, 3DS adapter service

Installation instructions:

1) Clone environment project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-environment.git

2) Clone the project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-3ds-adapter.git

3) Launch environment:

   cd tsp-ia-box-environment/docker

   docker-compose stop && docker-compose up -d

4) Launch 3DS adapter service