plugins {
    idea
    base
    java
    application
    `maven-publish`
    checkstyle
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")

val toolDir = "${project.buildDir}/tools"
val toolDependency by configurations.compileOnly
toolDependency.isCanBeResolved = true

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
        exclude("io.springfox", "springfox-bean-validators")
        exclude("io.springfox", "springfox-boot-starter")
        exclude("io.springfox", "springfox-core")
        exclude("io.springfox", "springfox-data-rest")
        exclude("ru.vtb.smartreplication", "smart-replication-proxy-core")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-domain")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")
    implementation("ru.vtb.dev.corp.ia.epay:epay-tokenization-api")
    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")

    // Spring components
    implementation("org.springframework.kafka:spring-kafka")
    implementation("org.springframework.boot:spring-boot-starter-integration")
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
    implementation("org.apache.commons:commons-lang3")
    implementation("org.springframework.boot:spring-boot-starter-web")
    runtimeOnly("org.springframework.boot:spring-boot-starter-undertow")

    // Redis
    implementation("org.springframework.boot:spring-boot-starter-data-redis")

    //Apache components
    implementation("org.apache.commons:commons-pool2")

    // RestTemplate
    implementation("org.apache.httpcomponents:httpclient")
    implementation("com.fasterxml.jackson.dataformat:jackson-dataformat-xml")

    implementation("com.fasterxml.jackson.module:jackson-module-jaxb-annotations")

    // Validation
    implementation("javax.validation:validation-api")
    toolDependency("ru.vtb.dev.corp.ia.epay:epay-build-tools")

    // Tracing
    implementation("ru.vtb.dev.corp.ia.epay:epay-tracing-starter")

    //Monitoring
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("io.micrometer:micrometer-registry-prometheus")

    // Logging
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("com.vlkan.log4j2:log4j2-logstash-layout")
    implementation("ru.vtb.infra.logging:log4j2-integration")

    // Audit
    implementation("ru.vtb.omni:audit-lib-servlet-context")
    implementation("ru.vtb.omni:audit-lib-in-memory-storage")
    implementation("ru.vtb.omni:audit-lib-kafka-sender")
    implementation("ru.vtb.omni:audit-lib-freemarker-template-resolver")

    // Kafka streams
    implementation("org.apache.kafka:kafka-streams")

    // Reactive streams
    implementation("io.projectreactor:reactor-core")
    implementation("io.projectreactor.kafka:reactor-kafka")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    implementation("org.freemarker:freemarker")
    implementation("org.apache.commons:commons-text")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:kafka")
    testImplementation("org.testcontainers:junit-jupiter")
    testImplementation("io.projectreactor:reactor-test")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")

    implementation("javax.xml.bind:jaxb-api")
    implementation("javax.activation:activation")
    implementation("org.glassfish.jaxb:jaxb-runtime")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set("ru.vtb.tsp.ia.epay.multicard.App")
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
}

val extractToolsDependency by tasks.register<Copy>("extractToolsDependency") {
    dependsOn(toolDependency)
    from(toolDependency.map {
        zipTree(it)
    })
    include("config/**")
    into(toolDir)
    includeEmptyDirs = false
}


tasks.withType<Checkstyle>().configureEach {
    dependsOn(extractToolsDependency)
    reports {
        xml.required.set(false)
        html.required.set(true)
    }
}

checkstyle {
    maxWarnings = 0
    isShowViolations = true
    isIgnoreFailures = false
    toolVersion = "9.3"
    configFile = file("${toolDir}/config/checkstyle/checkstyle.xml")
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}
