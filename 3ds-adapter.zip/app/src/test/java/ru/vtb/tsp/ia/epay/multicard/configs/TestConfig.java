package ru.vtb.tsp.ia.epay.multicard.configs;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.web.WebAppConfiguration;

@Configuration
@Import({AppConfig.class, AppConfig.class, KafkaProducerConfig.class})
@ImportAutoConfiguration(classes = ValidationAutoConfiguration.class)
@WebAppConfiguration
public class TestConfig {
}