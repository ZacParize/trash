package ru.vtb.tsp.ia.epay.multicard.containers;

import lombok.extern.slf4j.Slf4j;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.utility.DockerImageName;

@Slf4j
public class ConfluentKafkaContainer extends KafkaContainer {

  private static final String IMAGE_VERSION = "confluentinc/cp-kafka";
  private static final String IMAGE_TYPE = "kafka";
  private static KafkaContainer container;

  private ConfluentKafkaContainer() {
    super(DockerImageName.parse(IMAGE_VERSION).asCompatibleSubstituteFor(IMAGE_TYPE));
    super.withExposedPorts(KAFKA_PORT).withEmbeddedZookeeper();
  }

  public static KafkaContainer getInstance() {
    if (container == null) {
      container = new ConfluentKafkaContainer();
    }
    return container;
  }

  @Override
  public void start() {
    super.start();
    System.setProperty("spring.kafka.bootstrap-servers", container.getBootstrapServers());
    log.info("Kafka in docker started: url = {}", container.getBootstrapServers());
  }

  @Override
  public void stop() {
    //do nothing, JVM handles shut down
  }
}