package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Optional;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.multicard.components.converters.MulticardProcess3DSAuthResponseToAuditResponseDataConverter;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardEndpoints;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.MulticardProcess3DSAuthRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.services.impl.AuditService;

class MulticardProcess3DSAuthFirstHandlerTest {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;
  private final MulticardProcess3DSAuthResponseToAuditResponseDataConverter converter;
  private final MulticardProcess3DSAuthFirstHandler handler;

  public MulticardProcess3DSAuthFirstHandlerTest() {
    this.properties = Mockito.mock(MulticardProperties.class);
    this.restTemplate = Mockito.mock(RestTemplate.class);
    this.converter = new MulticardProcess3DSAuthResponseToAuditResponseDataConverter();
    this.handler = new MulticardProcess3DSAuthFirstHandler(properties, restTemplate,
        Mockito.mock(DataFiller.class), Mockito.mock(AuditService.class));
  }

  @Test
  public void test_handleResponse_Success() {

    String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        + "<TKKPG>\n"
        + "  <Response>\n"
        + "    <Operation>Process3DSAuth</Operation>\n"
        + "    <NextStep>AREQ</NextStep>\n"
        + "    <Status>00</Status>\n"
        + "    <Refinement>\n"
        + "      <RefinementType></RefinementType>\n"
        + "      <AcsURL></AcsURL>\n"
        + "      <PAReq></PAReq>\n"
        + "      <MethodUrl>http://methodUrl</MethodUrl>\n"
        + "      <ThreeDSMethodNotificationURL></ThreeDSMethodNotificationURL>\n"
        + "      <ThreeDSServerTransId>trxId-1234567890</ThreeDSServerTransId>\n"
        + "      <ThreeDSMethodData></ThreeDSMethodData>\n"
        + "    </Refinement>\n"
        + "  </Response>\n"
        + "</TKKPG>";

    MulticardEndpoints multicardEndpoints = new MulticardEndpoints();
    multicardEndpoints.setProcess3DSAuthFirst("first");
    ResponseEntity<String> res = new ResponseEntity<>(xml, HttpStatus.OK);
    when(properties.getBaseUrl()).thenReturn("url/");
    when(properties.getEndpoints()).thenReturn(multicardEndpoints);
    when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class),
        eq(String.class))).thenReturn(res);
    Optional<MulticardProcess3DSAuthResponse> resp = handler.handle(
        new MulticardProcess3DSAuthRequest());

    assertTrue(resp.isPresent());
    MulticardProcess3DSAuthResponse actualMcResp = resp.get();
    assertEquals(MulticardProcess3DSAuthStep.AREQ, actualMcResp.getResponse().getNextStep());
    assertEquals(MulticardOperation.PROCESS_3DS_AUTH, actualMcResp.getResponse().getOperation());
    assertEquals(MulticardStatus.SUCCESS, actualMcResp.getResponse().getStatus());
    assertEquals("http://methodUrl", actualMcResp.getResponse().getRefinement().getMethodUrl());
    assertEquals("trxId-1234567890",
        actualMcResp.getResponse().getRefinement().getThreeDSServerTransId());
  }

  @Test
  public void test_handleResponse_Failure() {

    String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        + "<TKKPG>\n"
        + "<Response>\n"
        + "<Operation></Operation>\n"
        + "<Status>10</Status>\n"
        + "</Response>\n"
        + "</TKKPG>";

    MulticardEndpoints multicardEndpoints = new MulticardEndpoints();
    multicardEndpoints.setProcess3DSAuthFirst("first");
    ResponseEntity<String> res = new ResponseEntity<>(xml, HttpStatus.OK);
    when(properties.getBaseUrl()).thenReturn("url/");
    when(properties.getEndpoints()).thenReturn(multicardEndpoints);
    when(restTemplate.exchange(any(String.class), eq(HttpMethod.POST), any(HttpEntity.class),
        eq(String.class))).thenReturn(res);
    Optional<MulticardProcess3DSAuthResponse> resp = handler.handle(
        new MulticardProcess3DSAuthRequest());

    assertTrue(resp.isPresent());
    MulticardProcess3DSAuthResponse actualMcResp = resp.get();
    assertEquals(null, actualMcResp.getResponse().getOperation());
    assertEquals(MulticardStatus.FORBIDDEN_OPERATION, actualMcResp.getResponse().getStatus());
  }
}