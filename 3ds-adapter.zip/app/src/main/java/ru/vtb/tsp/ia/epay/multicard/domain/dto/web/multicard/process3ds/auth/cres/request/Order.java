package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Order.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Order {

  @XmlElement(name = "OrderID")
  private String orderId;
  @XmlElement(name = "Merchant")
  private String merchant;
}
