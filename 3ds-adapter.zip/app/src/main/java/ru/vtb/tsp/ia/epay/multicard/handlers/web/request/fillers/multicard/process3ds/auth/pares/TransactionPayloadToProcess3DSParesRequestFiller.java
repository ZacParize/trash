package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.pares;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.request.Order;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.request.Request;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;
import ru.vtb.tsp.ia.epay.multicard.services.CryptoService;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSParesRequestFiller implements
    Filler<TransactionPayload, Request> {

  private static final String THREEDS_TDS_PARES_KEY = "TDS_PARES";
  private final CryptoService cryptoService;
  @Lazy
  private final DataFiller filler;

  @Override
  public Optional<Request> fill(TransactionPayload src, Request dest) {
    final var threeds = (Threeds) ((Card) src.getPaymentData()).getAdditionalData();
    if (Objects.isNull(dest.getOrder())) {
      dest.setOrder(new Order());
    }
    dest.setOperation(MulticardOperation.PROCESS_3DS_AUTH);
    dest.setStep(MulticardProcess3DSAuthStep.PARES);
    dest.setCardUid(threeds.getThreeDSData().getCardUid());
    dest.setSessionId((String) src.getContext().get(ThreeDSContextVariables.MK_SESS_ID.cname()));
    LocalDateTime expiryDate = ((Card) src.getPaymentData()).getExpiryDate();
    cryptoService.getCardData(src)
        .ifPresent(pandto -> {
          dest.setPan(pandto.getPan());
          dest.setDate(Date.valueOf(expiryDate.toLocalDate()));
        });
    dest.setPares((String) src.getContext().get(THREEDS_TDS_PARES_KEY));
    dest.setParesExists(StringUtils.isNotEmpty(dest.getPares()));
    filler.fill(src, dest.getOrder());
    return Optional.of(dest);
  }
}
