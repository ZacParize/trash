package ru.vtb.tsp.ia.epay.multicard.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Objects;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@Slf4j
public class FileUtils {

  private FileUtils() {
    throw new IllegalStateException("Utility class!");
  }

  @SneakyThrows
  public static Optional<ByteArrayInputStream> getFileFromApp(String resourcePath) {
    if (StringUtils.isEmpty(resourcePath)) {
      log.error("Не указан путь к ресурсу");
      return Optional.empty();
    }
    final var inputStream = FileUtils.class.getResourceAsStream(resourcePath);
    if (Objects.isNull(inputStream)) {
      log.error("Не удалось получить ресурс {}", resourcePath);
      return Optional.empty();
    }
    try {
      return Optional.of(new ByteArrayInputStream(inputStream.readAllBytes()));
    } catch (IOException e) {
      log.error("Ошибка чтения ресурса {}", resourcePath, e);
    }
    return Optional.empty();
  }
}
