package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * AReqDetails block.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class AReqDetails {

  @XmlElement(name = "browserAcceptHeader")
  private String browserAcceptHeader;

  @XmlElement(name = "browserColorDepth")
  private String browserColorDepth;

  @XmlElement(name = "browserIP")
  private String browserIP;

  @XmlElement(name = "browserLanguage")
  private String browserLanguage;

  @XmlElement(name = "browserScreenHeight")
  private String browserScreenHeight;

  @XmlElement(name = "browserScreenWidth")
  private String browserScreenWidth;

  @XmlElement(name = "browserTZ")
  private String browserTZ;

  @XmlElement(name = "browserUserAgent")
  private String browserUserAgent;

  @XmlElement(name = "deviceChannel")
  private String deviceChannel;

  @XmlElement(name = "browserJavaEnabled")
  private String browserJavaEnabled;

  @XmlElement(name = "notificationURL")
  private String notificationURL;

}
