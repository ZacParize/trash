package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.AReqDetails;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSAReqAReqDetailsFiller implements
    Filler<TransactionPayload, AReqDetails> {

  private final DataFiller filler;

  @Override
  public Optional<AReqDetails> fill(TransactionPayload src, AReqDetails dest) {
    final var threeds = (Threeds) ((Card) src.getPaymentData()).getAdditionalData();
    final var browser = ((Threeds) ((Card) src.getPaymentData()).getAdditionalData())
        .getThreeDSData().getBrowserInfo();
    dest.setBrowserIP(browser.getIp());
    dest.setBrowserAcceptHeader(browser.getAcceptHeader());
    dest.setBrowserColorDepth(browser.getColorDepth());
    dest.setBrowserLanguage(browser.getLanguage());
    dest.setBrowserScreenHeight(browser.getScreenHeight());
    dest.setBrowserScreenWidth(browser.getScreenWidth());
    dest.setBrowserTZ(browser.getTz());
    dest.setBrowserUserAgent(browser.getUserAgent());
    dest.setDeviceChannel(threeds.getThreeDSData().getDeviceChannel());
    dest.setBrowserJavaEnabled(browser.getJavaEnabled());
    dest.setNotificationURL(threeds.getThreeDSData().getNotificationUrlCres());
    return Optional.of(dest);
  }
}
