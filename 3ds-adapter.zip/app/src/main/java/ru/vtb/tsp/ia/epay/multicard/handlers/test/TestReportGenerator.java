package ru.vtb.tsp.ia.epay.multicard.handlers.test;

import java.util.List;
import ru.vtb.tsp.ia.epay.multicard.domain.TestReportItem;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;

/**
 * Интерфейс генератора отчета по тестированию интеграции.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
public interface TestReportGenerator<T> {

  T generate(List<TestReportItem> report);

  TestReportType reportType();
}
