package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.first;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.Order;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.Request;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;
import ru.vtb.tsp.ia.epay.multicard.services.CryptoService;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSRequestFiller implements
    Filler<TransactionPayload, Request> {

  @Lazy
  private final DataFiller filler;
  private final CryptoService cryptoService;

  @Override
  public Optional<Request> fill(TransactionPayload src, Request dest) {
    if (Objects.isNull(dest.getOrder())) {
      dest.setOrder(new Order());
    }
    final var threeds = getThreeds(src);
    dest.setOperation(MulticardOperation.PROCESS_3DS_AUTH);
    dest.setStep(MulticardProcess3DSAuthStep.FIRST);
    dest.setSessionId(threeds.getThreeDSData().getSessionId());
    LocalDateTime expiryDate = ((Card) src.getPaymentData()).getExpiryDate();
    cryptoService.getCardData(src)
        .ifPresent(cardCacheDto -> {
          dest.setPan(cardCacheDto.getPan());
          dest.setDate(Date.valueOf(expiryDate.toLocalDate()));
        });
    filler.fill(src, dest.getOrder());
    return Optional.of(dest);
  }
}
