package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.AREQ;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FINISHED;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FIRST;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.PARES;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.findByStep;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.REF_TYPE;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_ACS;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_BRAND;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_METHOD;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_METHOD_NOTIF;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_PAREQ;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_SERVER_TID;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_THREEDS_VERSION;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSMessageCategory;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSReqAuthInd;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.multicard.domain.consts.TDSConsts;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.AnswerVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;
import ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil;

@Component
@RequiredArgsConstructor
public class MulticardProcess3DSAuthResponseToTransactionPayloadFiller extends
    ATransactionPayloadFiller<MulticardProcess3DSAuthResponse> {

  private static final String NOT_INVOLVED = "N";
  private static final String TDS_ORIGINAL_PAREQ = "TDS_ORIGINAL_PAREQ";
  private static final String PAREQ_XID_XPATH = "/ThreeDSecure/Message/PAReq/Purchase/xid";

  private static final Base64.Decoder DECODER = Base64.getDecoder();
  private static final Base64.Encoder ENCODER = Base64.getEncoder();


  @Override
  public Optional<TransactionPayload> fill(MulticardProcess3DSAuthResponse src,
      TransactionPayload dest) {
    if (Objects.isNull(src) || Objects.isNull(dest) || Objects.isNull(dest.getPaymentData())
        || Objects.isNull(((Card) dest.getPaymentData()).getAdditionalData())) {
      return Optional.empty();
    }
    final var threeds = ((Threeds) ((Card) dest.getPaymentData()).getAdditionalData());
    final var tData = threeds.getThreeDSData();
    if (tData != null) {
      tData.getOperation();
    }
    if (Objects.isNull(tData)) {
      return Optional.empty();
    }
    src.setOrderId(tData.getOrderId());
    src.setTransactionId(dest.getTransactionId());
    return Optional.of(src).map(MulticardProcess3DSAuthResponse::getResponse)
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  tData.setOperation(FINISHED);
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400004")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .message("FIRST_RESPONSE_ERROR")
                      .description("3DS technical error")
                      .build());
                }
              });
          return response;
        })
        .map(response1 -> {
          final var enrolled = Optional.of(response1)
              .map(Response::getResult)
              .map(Result::getXmlOut)
              .map(XmlOut::getMessage)
              .map(Message::getThreeDSVars)
              .map(ThreeDSVars::getAnswerVars)
              .map(AnswerVars::getEnrolled).orElse(null);
          if ((StringUtils.equalsIgnoreCase(enrolled, NOT_INVOLVED))) {
            dest.setStatus(TransactionState.DECLINED);
            dest.setError(TransactionError.builder()
                .id("10400001")
                .httpCode(432)
                .traceId(dest.getTransactionCode())
                .message("FIRST_NOT_INVOLVED_ERROR")
                .description("Платеж отклонен. Проверьте реквизиты платежа")
                .build());
            return null;
          }
          return response1;
        })
        .map(response1 -> {
          Optional.of(response1)
              .map(Response::getNextStep)
              .flatMap(next -> findByStep(next.getStep()))
              .ifPresent(step -> {
                tData.setOperation(FIRST);
                dest.getContext().put(TDSConsts.NEXT, step.name());
              });
          return response1;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  tData.setOperation(FINISHED);
                }
              });
          return response;
        })
        .map(response1 -> {
          final var msg = Optional.of(response1)
              .map(Response::getResult)
              .map(Result::getXmlOut)
              .map(XmlOut::getMessage);
          msg.map(Message::getBrand)
              .ifPresent(brand -> dest.getContext().put(TDS_BRAND.cname(), brand.name()));
          return response1;
        })
        .map(response1 -> {
          Optional.of(response1)
              .map(Response::getRefinement)
              .ifPresent(refinement -> {
                if (dest.getContext().containsKey(TDSConsts.NEXT)) {
                  //flow 3DS 1.0
                  if (dest.getContext().get(TDSConsts.NEXT).equals(PARES.name())) {
                    putInContext(dest, TDS_ORIGINAL_PAREQ, refinement.getPaReq());
                    putInContext(dest, TDS_ACS.cname(), refinement.getAcsURL());
                    final var xmlPareq = StringUtils.toEncodedString(
                        XmlConverterUtil.decompress(DECODER.decode(refinement.getPaReq())),
                        StandardCharsets.UTF_8
                    );
                    threeds.setXid(getXid(xmlPareq));
                    putInContext(dest, TDS_PAREQ.cname(), ENCODER.encodeToString(
                        XmlConverterUtil.processPareq(xmlPareq)));
                    dest.getContext().put(TDS_THREEDS_VERSION.cname(), ThreeDSVersion.V1_0);
                    tData.setThreeDsVersion(ThreeDSVersion.V1_0);
                  }

                  //flow 3DS 2.0
                  if (dest.getContext().get(TDSConsts.NEXT).equals(AREQ.name())) {
                    putInContext(dest, TDS_METHOD.cname(), refinement.getThreeDSMethodData());
                    putInContext(dest, TDS_ACS.cname(), refinement.getMethodUrl());
                    dest.getContext().put(TDS_THREEDS_VERSION.cname(), ThreeDSVersion.V2_0);
                    tData.setThreeDsVersion(ThreeDSVersion.V2_0);
                  }
                }

                //common params
                if (StringUtils.isNotEmpty(refinement.getMethodUrl())) {
                  putInContext(dest, TDS_METHOD.cname(), refinement.getMethodUrl());
                  tData.setNotificationUrl(refinement.getMethodUrl());
                  tData.setMessageCategory(ThreeDSMessageCategory.PAYMENT);
                  tData.setThreeDSRequestorAuthentificatorInd(ThreeDSReqAuthInd.PAYMENT);
                } else {
                  tData.setThreeDSCompInd("U");
                  dest.getContext().put("3DS_COMP_IND", "U");
                }
                putInContext(dest, TDS_METHOD_NOTIF.cname(),
                    refinement.getThreeDSMethodNotificationURL());
                putInContext(dest, TDS_SERVER_TID.cname(), refinement.getThreeDSServerTransId());
                if (Objects.nonNull(refinement.getRefinementType())) {
                  putInContext(dest, REF_TYPE.cname(), refinement.getRefinementType().name());
                }
              });
          return dest;
        });
  }

  private String getXid(String xmlPareq) {
    return StringUtils.isNotBlank(xmlPareq)
        ? XmlConverterUtil.getNodeValue(xmlPareq, PAREQ_XID_XPATH).orElse(null)
        : null;
  }


}
