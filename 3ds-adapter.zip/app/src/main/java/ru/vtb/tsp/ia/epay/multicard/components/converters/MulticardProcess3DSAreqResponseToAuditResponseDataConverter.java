package ru.vtb.tsp.ia.epay.multicard.components.converters;

import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.04.2022
 */
@Component
public class MulticardProcess3DSAreqResponseToAuditResponseDataConverter
    implements Converter<MulticardProcess3DSAreqResponse, AuditResponseData> {

  @Override
  public AuditResponseData convert(MulticardProcess3DSAreqResponse source) {
    final var data = new AuditResponseData();
    if (Objects.isNull(source) || Objects.isNull(source.getResponse())) {
      return null;
    }
    Optional.ofNullable(source)
        .map(MulticardProcess3DSAreqResponse::getResponse)
        .map(response -> {
          data.setNextStep(
              Optional.ofNullable(response.getNextStep())
                  .map(MulticardProcess3DSAuthStep::getStep)
                  .orElse("")
          );
          data.setStatus(
              Optional.ofNullable(response.getStatus())
                  .map(MulticardStatus::name)
                  .orElse("")
          );
          data.setAcsUrl(
              Optional.ofNullable(response.getRefinement())
                  .map(refinement -> StringUtils.isNotEmpty(refinement.getAcsURL()))
                  .orElse(Boolean.FALSE)
          );
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          data.setOrderStatus(
              Optional.ofNullable(message.getOrderStatus())
                  .map(Enum::name)
                  .orElse("")
          );
          data.setOrderId(
              Optional.ofNullable(message.getOrderID())
                  .orElse("")
          );
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .ifPresent(answerVars -> {
          data.setThreeDSVerification(
              Optional.ofNullable(answerVars.getThreeDSVerification())
                  .orElse("")
          );
          data.setThreeDSVersion(
              Optional.ofNullable(answerVars.getThreeDSVersion())
                  .orElse("")
          );
        });
    return data;
  }
}
