package ru.vtb.tsp.ia.epay.multicard.configs.properties.redis;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.12.2021
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "spring.redis")
public class RedisProperties {

  private Integer database;
  private String host;
  private Integer port;
  private Boolean ssl;
  private String password;
  private Long connectTimeout;
  private Integer maxActive;
  private Integer maxIdle;
  private Integer minIdle;
  private Integer maxWait;
}
