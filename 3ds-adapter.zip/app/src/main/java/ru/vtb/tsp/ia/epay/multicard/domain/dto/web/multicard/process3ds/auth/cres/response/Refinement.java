package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Refinement.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
public class Refinement {

  @XmlElement(name = "RefinementType")
  private String refinementType;
  @XmlElement(name = "AcsURL")
  private String acsURL;
  @XmlElement(name = "PAReq")
  private String paReq;
  @XmlElement(name = "MethodUrl")
  private String methodUrl;
  @XmlElement(name = "ThreeDSMethodNotificationURL")
  private String threeDSMethodNotificationURL;
  @XmlElement(name = "ThreeDSServerTransId")
  private String threeDSServerTransId;
  @XmlElement(name = "ThreeDSMethodData")
  private String threeDSMethodData;
}
