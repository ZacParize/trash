package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.services.MulticardService;
import ru.vtb.tsp.ia.epay.multicard.services.TDSService;

@Service
@RequiredArgsConstructor
public class MulticardTDSServiceImpl implements TDSService {

  private final MulticardService multicardService;

  @Override
  public Optional<TransactionPayload> createOrder(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(transactionPayload -> {
          if (multicardService.registerOrder(transactionPayload).isEmpty()) {
            return null;
          }
          return transactionPayload;
        });
  }

  @Override
  public Optional<TransactionPayload> first(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(transactionPayload -> {
          if (multicardService.threeDsProcessAuthFirst(transactionPayload).isEmpty()) {
            return null;
          }
          return transactionPayload;
        });
  }

  @Override
  public Optional<TransactionPayload> areq(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(transactionPayload -> {
          if (multicardService.threeDsProcessAuthAreq(transactionPayload).isEmpty()) {
            return null;
          }
          return transactionPayload;
        });
  }

  @Override
  public Optional<TransactionPayload> cres(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(transactionPayload -> {
          if (multicardService.threeDsProcessAuthCres(transactionPayload).isEmpty()) {
            return null;
          }
          return transactionPayload;
        });
  }

  @Override
  public Optional<TransactionPayload> pares(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(transactionPayload -> {
          if (multicardService.threeDsProcessAuthPares(transactionPayload).isEmpty()) {
            return null;
          }
          return transactionPayload;
        });
  }
}
