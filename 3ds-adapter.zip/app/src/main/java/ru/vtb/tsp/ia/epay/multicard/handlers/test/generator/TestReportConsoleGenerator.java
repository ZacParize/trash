package ru.vtb.tsp.ia.epay.multicard.handlers.test.generator;

import freemarker.cache.ByteArrayTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import lombok.SneakyThrows;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.TestReportItem;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;
import ru.vtb.tsp.ia.epay.multicard.handlers.test.TestReportGenerator;
import ru.vtb.tsp.ia.epay.multicard.utils.FileUtils;

/**
 * генератор отчета для вывода в консоль.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Component
public class TestReportConsoleGenerator implements TestReportGenerator<String> {

  @SneakyThrows
  @Override
  public String generate(List<TestReportItem> report) {
    Configuration cfg = new Configuration();
    final var file = FileUtils.getFileFromApp(
        "/integrations/tests/templates/consoletestreport.ftl");
    final var loader = new ByteArrayTemplateLoader();

    cfg.setTemplateLoader(loader);
    Map<String, Object> root = new HashMap<>();
    root.put("reportItems", report);
    Template temp = new Template("console", new StringReader(new String(file.get().readAllBytes())),
        cfg);
    Writer out = new StringWriter();
    temp.process(root, out);
    return out.toString();
  }

  @Override
  public TestReportType reportType() {
    return TestReportType.CONSOLE;
  }
}
