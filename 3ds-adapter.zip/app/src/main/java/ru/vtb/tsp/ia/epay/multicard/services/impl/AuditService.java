package ru.vtb.tsp.ia.epay.multicard.services.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 04.05.2022
 */
@Slf4j
@Service
public class AuditService {

  @AuditProcess("TSPACQ_BOX_MK_AUTH_PARES_RESPONSE")
  public void authParesResponse(AuditResponseData data) {
    log.debug("Auth pares response: {}", data);
  }

  @AuditProcess("TSPACQ_BOX_MK_AUTH_CREATE_ORDER_RESPONSE")
  public void authCreateOrderResponse(AuditResponseData data) {
    log.debug("Auth create order response: {}", data);
  }

  @AuditProcess("TSPACQ_BOX_MK_AUTH_FIRST_RESPONSE")
  public void authFirstResponse(AuditResponseData data) {
    log.debug("Auth first response: {}", data);
  }

  @AuditProcess("TSPACQ_BOX_MK_AUTH_AREQ_RESPONSE")
  public void authAreqResponse(AuditResponseData data) {
    log.debug("Auth areq response: {}", data);
  }
}
