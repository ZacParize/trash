package ru.vtb.tsp.ia.epay.multicard.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;

public interface CryptoService {

  Optional<CardCacheDto> getCardData(TransactionPayload payload);

}
