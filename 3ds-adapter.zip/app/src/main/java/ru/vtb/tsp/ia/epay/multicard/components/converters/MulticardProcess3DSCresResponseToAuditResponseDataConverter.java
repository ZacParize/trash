package ru.vtb.tsp.ia.epay.multicard.components.converters;

import java.util.Objects;
import java.util.Optional;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.MulticardProcess3DSCresResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.04.2022
 */
@Component
public class MulticardProcess3DSCresResponseToAuditResponseDataConverter
    implements Converter<MulticardProcess3DSCresResponse, AuditResponseData> {

  @Override
  public AuditResponseData convert(MulticardProcess3DSCresResponse source) {
    if (Objects.isNull(source) || Objects.isNull(source.getResponse())) {
      return null;
    }
    final var data = new AuditResponseData();
    Optional.ofNullable(source)
        .map(MulticardProcess3DSCresResponse::getResponse)
        .map(response -> {
          data.setStatus(
              Optional.ofNullable(response.getStatus())
                  .map(MulticardStatus::name)
                  .orElse("")
          );
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          data.setOrderStatus(
              Optional.ofNullable(message.getOrderStatus())
                  .map(Enum::name)
                  .orElse("")
          );
          data.setOrderId(
              Optional.ofNullable(message.getOrderID())
                  .orElse("")
          );
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .ifPresent(answerVars -> {
          data.setThreeDSVerification(
              Optional.ofNullable(answerVars.getThreeDSVerification())
                  .orElse("")
          );
          data.setThreeDSVersion(
              Optional.ofNullable(answerVars.getThreeDSVersion())
                  .orElse("")
          );
        });
    return data;
  }
}
