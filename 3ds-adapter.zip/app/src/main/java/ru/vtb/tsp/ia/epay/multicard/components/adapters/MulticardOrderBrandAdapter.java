package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOrderBrand;

/**
 * Adapter for fill step field in Multicard XML.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardOrderBrandAdapter extends XmlAdapter<String, MulticardOrderBrand> {

  @Override
  public MulticardOrderBrand unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardOrderBrand.findByValue(v).orElse(null);
  }

  @Override
  public String marshal(MulticardOrderBrand v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getValue();
  }
}
