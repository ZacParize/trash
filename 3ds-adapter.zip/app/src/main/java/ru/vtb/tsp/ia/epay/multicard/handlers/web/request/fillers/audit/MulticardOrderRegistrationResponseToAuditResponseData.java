package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.audit;

import java.util.Optional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.MulticardOrderRegistrationResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.Response;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;


@Component
public class MulticardOrderRegistrationResponseToAuditResponseData extends
    AFiller<MulticardOrderRegistrationResponse, AuditResponseData> {

  @Override
  public Optional<AuditResponseData> fill(MulticardOrderRegistrationResponse src,
      AuditResponseData dest) {

    Optional.ofNullable(src)
        .map(root -> {
          dest.setTransactionId(root.getTransactionId());
          return root;
        })
        .map(MulticardOrderRegistrationResponse::getResponse)
        .map(Response::getOrder)
        .ifPresent(order -> {
          dest.setOrderId(order.getOrderID());
          dest.setSessionId(order.getSessionID());
        });
    return Optional.of(dest);
  }
}
