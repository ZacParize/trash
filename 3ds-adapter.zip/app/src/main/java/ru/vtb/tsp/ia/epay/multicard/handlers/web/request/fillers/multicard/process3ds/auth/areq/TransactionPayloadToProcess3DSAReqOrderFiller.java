package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.AddParams;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.Order;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSAReqOrderFiller implements
    Filler<TransactionPayload, Order> {

  private final DataFiller filler;
  private final MulticardProperties properties;

  @Override
  public Optional<Order> fill(TransactionPayload src, Order dest) {
    if (Objects.isNull(dest.getAddParams())) {
      dest.setAddParams(new AddParams());
    }
    final var threeds = (Threeds) ((Card) src.getPaymentData()).getAdditionalData();
    dest.setMerchant(properties.getIpspId());
    dest.setOrderId(threeds.getThreeDSData().getOrderId());
    filler.fill(src, dest.getAddParams());
    return Optional.of(dest);
  }
}