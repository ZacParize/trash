package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MessageDateAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardOrderBrandAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.VerificationOrderStatusesAdapter;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOrderBrand;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOrderStatus;

/**
 * Message.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
public class Message {

  @XmlElement(name = "OrderID")
  private String orderID;
  @XmlElement(name = "Brand")
  @XmlJavaTypeAdapter(MulticardOrderBrandAdapter.class)
  private MulticardOrderBrand brand;
  @XmlElement(name = "OrderStatus")
  @XmlJavaTypeAdapter(VerificationOrderStatusesAdapter.class)
  private MulticardOrderStatus orderStatus;
  @XmlElement(name = "ThreeDSVars")
  private ThreeDSVars threeDSVars;
  @XmlElement(name = "RezultOperation")
  private String rezultOperation;
  @XmlElement(name = "MerchantTranID")
  private String merchantTranID;
  @XmlElement(name = "ShopName")
  private String shopName;
  @XmlElement(name = "Version")
  private String version;
  @XmlAttribute(name = "date")
  @XmlJavaTypeAdapter(MessageDateAdapter.class)
  private Date date;
  @XmlElement(name = "text")
  private String text;
}
