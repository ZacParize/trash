package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.AddParams;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
public class TransactionPayloadToProcess3DSAReqAddParamsFiller
        implements Filler<TransactionPayload, AddParams> {

  @Override
  public Optional<AddParams> fill(TransactionPayload src, AddParams dest) {
    final var threeds = (Threeds) ((Card) src.getPaymentData()).getAdditionalData();
    dest.setMerchantName(src.getMerchant().getMerchantSiteParams()
        .getCardParams().getMerchantName());
    dest.setAcquirerMerchantID(src.getMerchant().getMerchantSiteParams()
        .getCardParams().getMerchantId());
    dest.setMessageCategory(threeds.getThreeDSData().getMessageCategory().getCode());
    dest.setMcc(src.getMerchant().getMerchantSiteParams().getMcc());
    dest.setThreeDSCompInd(threeds.getThreeDSData().getThreeDSCompInd());
    dest.setThreeDSRequestorURL(threeds.getThreeDSData().getThreeDSRequestorUrl());
    dest.setThreeDSRequestorAuthenticationInd(
        threeds.getThreeDSData().getThreeDSRequestorAuthentificatorInd().getCode());
    return Optional.of(dest);
  }

}