package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardLanguage;

/**
 * Адаптер для маршализации/демаршализации языка.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardLanguageAdapter extends XmlAdapter<String, MulticardLanguage> {

  @Override
  public MulticardLanguage unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardLanguage.findByLang(v).orElse(null);
  }

  @Override
  public String marshal(MulticardLanguage v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getLang();
  }
}
