package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.04.2022
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuditResponseData {

  private String nextStep;
  private String status;
  private String threeDSServerTransId;
  private String orderId;
  private String orderStatus;
  private String version;
  private String threeDSVersion;
  private String threeDSVerification;
  private Boolean methodUrl;
  private Boolean acsUrl;
  private String transactionId;
  private String sessionId;

}
