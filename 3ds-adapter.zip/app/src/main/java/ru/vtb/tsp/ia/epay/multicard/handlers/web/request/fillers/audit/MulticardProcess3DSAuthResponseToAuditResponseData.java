package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.audit;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 04.05.2022
 */
@Component
public class MulticardProcess3DSAuthResponseToAuditResponseData extends
    AFiller<MulticardProcess3DSAuthResponse, AuditResponseData> {

  private static final String PARES = "PARES";
  private static final String AREQ = "AREQ";

  @Override
  public Optional<AuditResponseData> fill(MulticardProcess3DSAuthResponse src,
      AuditResponseData dest) {
    dest.setMethodUrl(false);
    Optional.ofNullable(src)
        .map(root -> {
          dest.setOrderId(root.getOrderId());
          dest.setTransactionId(root.getTransactionId());
          return root;
        })
        .map(MulticardProcess3DSAuthResponse::getResponse)
        .map(response -> {
          Optional.ofNullable(response.getStatus())
              .map(MulticardStatus::getStatusCode)
              .ifPresent(dest::setStatus);
          Optional.ofNullable(response.getNextStep())
              .map(MulticardProcess3DSAuthStep::getStep)
              .ifPresent(dest::setNextStep);
          return response;
        })
        .map(Response::getRefinement)
        .ifPresent(refinement -> {
          dest.setMethodUrl(StringUtils.isNotEmpty(refinement.getMethodUrl()));
          dest.setVersion(dest.getMethodUrl() ? AREQ : PARES);
          dest.setThreeDSServerTransId(refinement.getThreeDSServerTransId());
        });
    return Optional.of(dest);
  }
}
