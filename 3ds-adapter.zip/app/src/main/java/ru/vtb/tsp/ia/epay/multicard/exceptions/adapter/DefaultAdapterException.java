package ru.vtb.tsp.ia.epay.multicard.exceptions.adapter;

import ru.vtb.tsp.ia.epay.multicard.domain.enums.ErrorSystem;
import ru.vtb.tsp.ia.epay.multicard.exceptions.AdapterException;

/**
 * Default gateway exception.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 25.01.2022
 */
public class DefaultAdapterException extends AdapterException {

  public DefaultAdapterException() {
    super();
    this.errorSource = ErrorSystem.THREEDS_ADAPTER;
  }

  public DefaultAdapterException(String message) {
    super(message);
    this.errorSource = ErrorSystem.THREEDS_ADAPTER;
  }

  public DefaultAdapterException(String message, Throwable cause) {
    super(message, cause);
    this.errorSource = ErrorSystem.THREEDS_ADAPTER;
  }

  public DefaultAdapterException(Throwable cause) {
    super(cause);
    this.errorSource = ErrorSystem.THREEDS_ADAPTER;
  }
}
