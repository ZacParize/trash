package ru.vtb.tsp.ia.epay.multicard.domain.consts;

/**
 * Multicard constants.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 06.09.2021
 */
public class TDSConsts {

  public static final String ORDER_ID = "TDS_ORDER_ID";
  public static final String SESS_ID = "TDS_SESSION_ID";
  public static final String URL = "TDS_URL";
  public static final String TDS_VERSION = "TDS_3DS_VERSION";
  public static final String VERSION = "TDS_VERSION";
  public static final String NEXT = "TDS_NEXT_STEP";
  public static final String BRAND = "TDS_CARD_BRAND";
  public static final String ACS = "TDS_ACS_URL";
  public static final String METHOD = "TDS_METHOD_URL";
  public static final String ARES = "TDS_ARES";
  public static final String CRES = "CRES";
  public static final String AREQ = "AREQ";
  public static final String PAREQ = "TDS_PAREQ";
  public static final String PARES = "PARES";
  public static final String CREQ = "TDS_CREQ";
  public static final String FRICTIONLESS = "FRICTIONLESS";
  public static final String TDS_METHOD = "TDS_3DS_METHOD";
  public static final String MERCHANT_TID = "TDS_MERCHANT_TRANS_ID";
  public static final String TDS_METHOD_NOTIF = "TDS_3DS_METHOD_NOTIFICATION";
  public static final String TDS_SERVER_TID = "TDS_3DS_SERVER_TRANS_ID";
  public static final String REF_TYPE = "TDS_REFINEMENT_TYPE";
  public static final String CAVV = "TDS_RESP_CAVV";
  public static final String ECI = "TDS_RESP_ECI";
  public static final String XID = "TDS_RESP_XID";
  public static final String TDS_3DS_VERSION = "TDS_RESP_VERSION";
  public static final String TDS_VERIF = "TDS_RESP_VERIF";
}
