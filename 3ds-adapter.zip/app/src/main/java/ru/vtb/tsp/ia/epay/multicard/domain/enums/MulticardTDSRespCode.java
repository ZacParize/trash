package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 3DS Response codes.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 13.09.2021
 */
@RequiredArgsConstructor
@Getter
public enum MulticardTDSRespCode {

  SUCCESS("000", "Обработка завершена успешно"),
  UNSUPPORTED_VERSION("001", "Неподдерживаемая версия"),
  UNSUPPORTED_LANGUAGE("002", "Неподдерживаемый язык"),
  UNSUPPORTED_COMMAND("003", "Неподдерживаемая команда"),
  AUTHENTIFICATION_ERROR("004", "Ошибка аутентификации (неверный сертификат)"),
  PARSING_ERROR("005", "Ошибка разбора сообщения"),
  SYSTEM_ERROR("006", "Системная ошибка"),
  CRYPTO_ERROR("007", "Ошибка криптографии"),
  TIMEOUT("008", "Таймаут"),
  INCORRECT_PARAMETERS_COUNT("009", "Неверное число параметров"),
  OPERATION_SUMM_IS_ZERO("010", "Нулевая сумма операции"),
  TRANSACTION_NOT_FOUND("011", "Оригинальная транзакция не найдена"),
  DUPLICATED_OPERATION_NUMBER("012", "Дубликат уникального номера операции (INVOICE)"),
  WAIT("013", "Исходный запрос обрабатывается, повторите попытку позже"),
  ACC_NOT_FOUND("201", "Счет не найден"),
  INCORRECT_SUM("203", "Неверная сумма"),
  OPERATION_UNBELIEVABLE("204", "Невозможно провести операцию"),
  NOT_HAVE_MONEY("205", "Нет средств на счете"),
  INCORRECT_PAYMENT_INFO("206", "Неверная информация о платеже"),
  INCORRECT_TERMINAL_IDENTIFIER("207", "Неверный идентификатор терминала"),
  CARD_EXPIRED("301", "Карта просрочена"),
  BREAKTHROWN("302", "Отказ без объяснения причин от эмитента"),
  UNSUPPORTED_TRANSACTION("303", "Неподдерживаемая транзакция"),
  TRANSACTION_FORBIDDEN("304", "Транзакция запрещена на уровне финансового института"),
  LOST_OR_STOLEN_CARD("305", "Потерянная или украденная карта"),
  INCORRECT_STATUS_CARD("306", "Неверный статус карты"),
  LIMITED_CARD("307", "Ограниченная карта"),
  UNABLE_AUTHORIZATION("308", "Невозможно авторизовать"),
  CARD_ACTIVITY_LIMIT_EXC("309", "Превышен лимит активности использования карты"),
  CARD_OP_SUM_LIMIT_EXC("310", "Превышен лимит суммы операций по карте"),
  ENTER_PIN_LIMIT_EXC("311", "Превышено число попыток ввода PIN"),
  UNSUPPORTED_CARD("320", "Карта не поддерживается"),
  FORMAT_ERROR("333", "Ошибка формата"),
  TRANSACTION_TIMEOUT("334", "Таймаут при совершении транзакции"),
  SYSTEM_ERROR_A("396", "Системная ошибка"),
  CALL_ISSUER("401", "Необходима связь с эмитентом (call issuer)"),
  INCORRECT_CAVV("410", "Неверное значение данных 3D-Secure (CAVV)"),
  INCORRECT_CVV("411", "Неверное значение CVV2/CVC2"),
  CARD_EXPIRED_REQ_CAPTURE("501", "Карта просрочена – необходим захват карты"),
  REFUSAL_BY_ISSUER_REQ_CAPTURE("502", "Отказ от эмитента – необходим захват карты"),
  SYSTEM_ERROR_B("809", "Системная ошибка");

  private final String code;
  private final String description;

  public static Optional<MulticardTDSRespCode> findByCode(String code) {
    for (var val : MulticardTDSRespCode.values()) {
      if (val.getCode().equals(code)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
