package ru.vtb.tsp.ia.epay.multicard.exceptions.adapter;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.01.2022
 */
public class AdapterCardDataNotFoundException extends DefaultAdapterException {

  public AdapterCardDataNotFoundException() {
    super();
  }

  public AdapterCardDataNotFoundException(String message) {
    super(message);
  }

  public AdapterCardDataNotFoundException(String message, Throwable cause) {
    super(message, cause);
  }

  public AdapterCardDataNotFoundException(Throwable cause) {
    super(cause);
  }
}
