package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Params {

  @XmlElement(name = "TDSVendorMerID")
  private String tdsVendorMerID;
  @XmlElement(name = "TDSVendorMerURL")
  private String tdsVendorMerURL;
  @XmlElement(name = "TDSVendorName")
  private String tdsVendorName;
  @XmlElement(name = "TDSVendorNameAbbr")
  private String tdsVendorNameAbbr;
  @XmlElement(name = "TDSVendorMCC")
  private String tdsVendorMCC;
}
