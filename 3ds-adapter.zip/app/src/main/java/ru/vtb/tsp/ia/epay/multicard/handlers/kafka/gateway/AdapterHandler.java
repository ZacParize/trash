package ru.vtb.tsp.ia.epay.multicard.handlers.kafka.gateway;

import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.Adapter;
import ru.vtb.tsp.ia.epay.multicard.handlers.Handler;

/**
 * Gateway handler.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.09.2021
 */
public interface AdapterHandler extends Handler<TransactionPayload, TransactionPayload> {

  Adapter supportedGateway();

}
