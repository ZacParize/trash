package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.order.registration;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.Params;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToParamsFiller implements Filler<TransactionPayload, Params> {

  @Override
  public Optional<Params> fill(TransactionPayload src, Params dest) {
    dest.setTdsVendorMerID(src.getMerchant().getMerchantSiteParams()
        .getCardParams().getMerchantId());
    dest.setTdsVendorMerURL(src.getMerchant().getUrl());
    dest.setTdsVendorName(src.getMerchant().getMerchantSiteParams()
        .getCardParams().getMerchantName());
    dest.setTdsVendorMCC(src.getMerchant().getMerchantSiteParams().getMcc());
    return Optional.of(dest);
  }
}