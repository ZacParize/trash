package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.first;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.Order;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSOrderFiller implements
    Filler<TransactionPayload, Order> {

  private final MulticardProperties properties;

  @Override
  public Optional<Order> fill(TransactionPayload src, Order dest) {
    final var threeds = getThreeds(src);
    dest.setMerchant(properties.getIpspId());
    dest.setOrderId(threeds.getThreeDSData().getOrderId());
    return Optional.of(dest);
  }
}
