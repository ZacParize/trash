package ru.vtb.tsp.ia.epay.multicard.configs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.annotation.EnableKafka;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;

@Slf4j
@Configuration
@EnableKafka
@Import(MessageAdapter.class)
@ComponentScan({"ru.vtb.tsp.ia.epay.multicard", "ru.vtb.tsp.ia.epay.core.utils",
    "ru.vtb.tsp.ia.epay.core.configurations"})
public class AppConfig {
}