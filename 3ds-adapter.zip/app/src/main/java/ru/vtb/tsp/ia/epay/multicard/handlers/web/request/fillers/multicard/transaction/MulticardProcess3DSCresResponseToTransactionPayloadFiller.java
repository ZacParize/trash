package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FINISHED;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables.TDS_BRAND;

import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.multicard.domain.consts.TDSConsts;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.MulticardProcess3DSCresResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

/**
 * Filler with data from {@link MulticardProcess3DSCresResponse} to {@link TransactionPayload}.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 07.09.2021
 */
@Component
public class MulticardProcess3DSCresResponseToTransactionPayloadFiller extends
    ATransactionPayloadFiller<MulticardProcess3DSCresResponse> {

  @Override
  public Optional<TransactionPayload> fill(MulticardProcess3DSCresResponse src,
      TransactionPayload dest) {
    final var paymentData = (Threeds) ((Card) dest.getPaymentData()).getAdditionalData();

    if (paymentData.getThreeDSData() != null
        && paymentData.getThreeDSData().getOperation() != ThreeDSAdapterOperation.CRES) {
      return Optional.of(dest);
    }

    return Optional.ofNullable(src)
        .map(MulticardProcess3DSCresResponse::getResponse)
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  paymentData.getThreeDSData().setOperation(FINISHED);
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400006")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .message("CRES_RESPONSE_ERROR")
                      .description("3DS technical error")
                      .build());
                }
              });
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          Optional.of(message)
              .map(Message::getBrand)
              .ifPresent(brand -> dest.getContext().put(TDS_BRAND.cname(), brand.name()));
          putInContext(dest, ThreeDSContextVariables.MK_ORDER_ID.cname(), message.getOrderID());
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .map(answerVars -> {
          paymentData.setXid(answerVars.getXid());
          paymentData.setCavv(answerVars.getCavv());
          paymentData.setEci(answerVars.getEci());
          paymentData.getThreeDSData().setOperation(ThreeDSAdapterOperation.FINISHED);
          putInContext(dest, TDSConsts.NEXT, ThreeDSAdapterOperation.FINISHED);
          putInContext(dest, ThreeDSContextVariables.XID.cname(), answerVars.getXid());
          putInContext(dest, ThreeDSContextVariables.CAVV.cname(), answerVars.getCavv());
          putInContext(dest, ThreeDSContextVariables.ECI.cname(), answerVars.getEci());
          putInContext(dest, ThreeDSContextVariables.TDS_CRES_VERIF.cname(),
              answerVars.getThreeDSVerification());
          putInContext(dest, ThreeDSContextVariables.TDS_CRES_3DS_VERSION.cname(),
              answerVars.getThreeDSVersion());
          return dest;
        });
  }
}
