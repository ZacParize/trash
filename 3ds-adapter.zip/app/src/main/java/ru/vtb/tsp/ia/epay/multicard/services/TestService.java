package ru.vtb.tsp.ia.epay.multicard.services;


import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;

public interface TestService {

  /**
   * Тестирование интеграции.
   */
  String allIntegrationsTest(TestReportType reportType);

}
