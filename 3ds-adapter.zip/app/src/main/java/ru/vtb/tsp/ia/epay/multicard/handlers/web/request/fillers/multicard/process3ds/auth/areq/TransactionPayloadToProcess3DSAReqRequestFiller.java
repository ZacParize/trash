package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.sql.Date;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.AReqDetails;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.CReqDetails;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.Order;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.Request;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;
import ru.vtb.tsp.ia.epay.multicard.services.CryptoService;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSAReqRequestFiller implements
    Filler<TransactionPayload, Request> {

  @Lazy
  private final DataFiller filler;
  private final CryptoService cryptoService;

  @Override
  public Optional<Request> fill(TransactionPayload src, Request dest) {
    if (Objects.isNull(dest.getOrder())) {
      dest.setOrder(new Order());
    }
    if (Objects.isNull(dest.getAreqDetails())) {
      dest.setAreqDetails(new AReqDetails());
    }
    if (Objects.isNull(dest.getCreqDetails())) {
      dest.setCreqDetails(new CReqDetails());
    }
    final var threeds = (Threeds) ((Card) src.getPaymentData()).getAdditionalData();
    dest.setOperation(MulticardOperation.PROCESS_3DS_AUTH);
    dest.setStep(MulticardProcess3DSAuthStep.AREQ);
    dest.setSessionId(threeds.getThreeDSData().getSessionId());
    LocalDateTime expiryDate = ((Card) src.getPaymentData()).getExpiryDate();
    cryptoService.getCardData(src)
        .ifPresent(cardCacheDto -> {
          dest.setPan(cardCacheDto.getPan());
          dest.setDate(Date.valueOf(expiryDate.toLocalDate()));
        });
    filler.fill(src, dest.getOrder());
    filler.fill(src, dest.getAreqDetails());
    filler.fill(src, dest.getCreqDetails());
    return Optional.of(dest);
  }
}
