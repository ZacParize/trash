package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.CReqDetails;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

/**
 * Filler with data from {@link TransactionPayload} to {@link CReqDetails}.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 25.08.2021
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToProcess3DSAReqCReqDetailsFiller implements
    Filler<TransactionPayload, CReqDetails> {

  private final DataFiller filler;

  @Override
  public Optional<CReqDetails> fill(TransactionPayload src, CReqDetails dest) {
    final var browser = ((Threeds) ((Card) src.getPaymentData()).getAdditionalData())
        .getThreeDSData().getBrowserInfo();

    dest.setWindowHeight(browser.getWindowHeight());
    dest.setWindowWidth(browser.getWindowsWidth());
    return Optional.of(dest);
  }
}
