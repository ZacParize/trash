package ru.vtb.tsp.ia.epay.multicard.services.impl;

import javax.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;
import ru.vtb.tsp.ia.epay.multicard.domain.CardRequestDto;

@Slf4j
@Component
@RequiredArgsConstructor
public class CardInfoClient {

  private static final String CARD_DECRYPT_PATH = "/card/decrypt";

  @Value("${rests.cardinfo.url}")
  @NotEmpty
  private String baseUrl;

  private final RestTemplate restTemplate;

  public CardCacheDto getCardData(TransactionPayload txData) {
    try {
      CardRequestDto body = CardRequestDto.builder()
          .transactionId(txData.getTransactionId())
          .encryptedPan(((Card) txData.getPaymentData()).getEncryptedPan())
          .encryptedCvv(((Card) txData.getPaymentData()).getEncryptedCvv())
          .build();
      final var entity = new HttpEntity<>(body, new HttpHeaders());
      final var result = restTemplate.exchange(
          baseUrl + CARD_DECRYPT_PATH,
          HttpMethod.POST,
          entity,
          CardCacheDto.class
      );
      return result.getBody();
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }
}
