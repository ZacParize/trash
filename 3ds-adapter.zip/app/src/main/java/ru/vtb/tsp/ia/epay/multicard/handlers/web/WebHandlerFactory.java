package ru.vtb.tsp.ia.epay.multicard.handlers.web;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardRequest;
import ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web.WHFEmptyHandlerException;

/**
 * Фабрика обработчиков REST запросов к мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
@Slf4j
@Component
public class WebHandlerFactory implements ApplicationContextAware {

  @Setter
  private ApplicationContext applicationContext;

  private final Map<MulticardRequest, WebHandler> handlers = new EnumMap<>(MulticardRequest.class);


  public Optional<WebHandler> getHandler(MulticardRequest requests)
      throws WHFEmptyHandlerException {
    if (Objects.isNull(requests)) {
      throw new WHFEmptyHandlerException();
    }
    fillHandlerMap();
    return Optional.ofNullable(handlers.getOrDefault(requests, null));
  }

  private void fillHandlerMap() {
    final var webHandlers = applicationContext.getBeansOfType(WebHandler.class);
    if (webHandlers.size() > handlers.size()) {
      handlers.clear();
      webHandlers
          .values()
          .forEach(webHandler -> MulticardRequest
              .findByHandlerClass(webHandler.getClass())
              .ifPresent(requests -> handlers.put(requests, webHandler)));
    }
  }
}