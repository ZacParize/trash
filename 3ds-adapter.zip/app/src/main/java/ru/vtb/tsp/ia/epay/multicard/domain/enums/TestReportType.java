package ru.vtb.tsp.ia.epay.multicard.domain.enums;

/**
 * Тип отчета о тесте.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
public enum TestReportType {

  HTML,
  CONSOLE

}
