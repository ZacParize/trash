package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;

/**
 * Multicard Process3DSAuth steps.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@Getter
public enum MulticardProcess3DSAuthStep {

  FIRST("FIRST"),
  PARES("PARES"),
  AREQ("AREQ"),
  CRES("CRES"),
  SECUREPLUS_SMS_SENDING("SECUREPLUS_SMS_SENDING");

  private final String step;

  MulticardProcess3DSAuthStep(String step) {
    this.step = step;
  }

  public static Optional<MulticardProcess3DSAuthStep> findByStep(String step) {
    for (var val : MulticardProcess3DSAuthStep.values()) {
      if (val.getStep().equals(step)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
