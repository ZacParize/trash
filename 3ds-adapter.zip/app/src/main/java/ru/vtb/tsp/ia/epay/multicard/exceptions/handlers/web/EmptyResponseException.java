package ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web;

import ru.vtb.tsp.ia.epay.multicard.exceptions.AdapterException;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.04.2022
 */
public class EmptyResponseException extends AdapterException {

}
