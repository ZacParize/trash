package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardTDSRespCode;

/**
 * Adapter for fill respcode.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 13.09.2021
 */
public class MulticardTDSRespCodeAdapter extends XmlAdapter<String, MulticardTDSRespCode> {

  @Override
  public MulticardTDSRespCode unmarshal(String v) throws Exception {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardTDSRespCode.findByCode(v).orElse(null);
  }

  @Override
  public String marshal(MulticardTDSRespCode v) throws Exception {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getCode();
  }
}
