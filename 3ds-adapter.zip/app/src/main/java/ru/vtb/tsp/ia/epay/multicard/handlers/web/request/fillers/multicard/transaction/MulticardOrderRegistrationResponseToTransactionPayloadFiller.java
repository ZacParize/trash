package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FINISHED;

import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.MulticardOrderRegistrationResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

@Component
public class MulticardOrderRegistrationResponseToTransactionPayloadFiller extends
    ATransactionPayloadFiller<MulticardOrderRegistrationResponse> {

  @Override
  public Optional<TransactionPayload> fill(MulticardOrderRegistrationResponse src,
      TransactionPayload dest) {

    src.setTransactionId(dest.getTransactionId());
    final var threeds = (Threeds) ((Card) dest.getPaymentData()).getAdditionalData();

    return Optional.ofNullable(src).map(MulticardOrderRegistrationResponse::getResponse)
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  threeds.getThreeDSData().setOperation(FINISHED);
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400003")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .description("3DS technical error")
                      .message("CREATE_ORDER_RESPONSE_ERROR")
                      .build());
                }
              });
          return response;
        })
        .map(Response::getOrder)
        .map(order -> {
          threeds.getThreeDSData().setSessionId(order.getSessionID());
          threeds.getThreeDSData().setOrderId(order.getOrderID());
          threeds.getThreeDSData().setOperation(ThreeDSAdapterOperation.FIRST);
          putInContext(dest, ThreeDSContextVariables.MK_ORDER_ID.cname(), order.getOrderID());
          putInContext(dest, ThreeDSContextVariables.MK_SESS_ID.cname(), order.getSessionID());
          return dest;
        });
  }
}
