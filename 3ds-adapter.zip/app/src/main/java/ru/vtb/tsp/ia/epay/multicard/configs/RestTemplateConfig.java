package ru.vtb.tsp.ia.epay.multicard.configs;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Enumeration;
import java.util.stream.Collectors;
import javax.net.ssl.SSLContext;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.core.utils.MaskUtils;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.exceptions.config.RestTemplateConfigurationException;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class RestTemplateConfig {

  private final MulticardProperties properties;

  private String getKeyAlias(KeyStore keyStore) {
    try {
      Enumeration<String> aliases = keyStore.aliases();
      for (String alias : Collections.list(aliases)) {
        log.info("RestTemplateConfig keystore aliases {}", alias);
        if (keyStore.isKeyEntry(alias)) {
          log.info("RestTemplateConfig key {}", alias);
          return alias;
        }
      }
    } catch (KeyStoreException e) {
      log.info("RestTemplateConfig keystore error load alias", e);
    }
    return null;
  }

  private KeyStore getKeystore() {
    try (var keyStoreInputStream = new FileInputStream(
        ResourceUtils.getFile(properties.getSsl().getKeystorePath()))) {
      KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(keyStoreInputStream, properties.getSsl().getKeystorePass().toCharArray());
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException e) {
      log.error("Возникла ошибка при создании SSL контекста: ", e);
      throw new RestTemplateConfigurationException(e);
    }
  }

  private SSLContext getSSLContext(Boolean clientAuth, Boolean certValidation) {
    final var builder = new SSLContextBuilder();
    try {
      if (clientAuth) {
        KeyStore keyStore = getKeystore();
        String keyAlias = getKeyAlias(keyStore);
        builder.loadKeyMaterial(keyStore, properties.getSsl().getKeyPass().toCharArray(),
            ((aliases, socket) -> keyAlias));
      }

      if (certValidation) {
        builder.loadTrustMaterial(ResourceUtils.getFile(properties.getSsl().getTruststorePath()),
            properties.getSsl().getTruststorePass().toCharArray());
      } else {
        TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;
        builder.loadTrustMaterial(null, acceptingTrustStrategy);
      }

      return builder.build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException
        | KeyManagementException | UnrecoverableKeyException e) {
      log.error("Возникла ошибка при создании SSL контекста: ", e);
      throw new RestTemplateConfigurationException(e);
    }
  }


  @Bean
  public RestTemplate getRestTemplate(RestTemplateBuilder builder) {
    if (properties.getSslEnabled()) {
      try {
        var socketFactory = new SSLConnectionSocketFactory(
            getSSLContext(properties.getSsl().getClientAuth(),
                properties.getSsl().getCertValidation()),
            NoopHostnameVerifier.INSTANCE);

        CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory)
            .build();

        final var requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        requestFactory.setReadTimeout(properties.getTimeout());
        requestFactory.setConnectTimeout(properties.getTimeout());
        return builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
            .additionalInterceptors(new RestClientInterceptor())
            .build();
      } catch (Exception exception) {
        log.error("Exception Occured while creating restTemplate " + exception);
        exception.printStackTrace();
      }
    }
    final var requestFactory = new HttpComponentsClientHttpRequestFactory();
    requestFactory.setReadTimeout(properties.getTimeout());
    requestFactory.setConnectTimeout(properties.getTimeout());
    return builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
        .additionalInterceptors(new RestClientInterceptor())
        .build();
  }

  private class RestClientInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body,
        ClientHttpRequestExecution execution) throws IOException {
      if (properties.getShowRequest()) {
        log.info("Request url: {}", MaskUtils.maskUri(request.getURI()));
        log.info("Request method: {}", request.getMethodValue());
        log.info("Request headers: {}", request.getHeaders()
            .entrySet()
            .stream()
            .map(stringListEntry -> stringListEntry.getKey()
                + ": "
                + StringUtils.arrayToDelimitedString(
                    stringListEntry.getValue().toArray(new String[0]), ", "))
            .collect(Collectors.joining("\r\n")));
        log.info("Request body: {}", body.length > 0
            ? MaskUtils.maskData(new String(body)) : "empty");
      }
      final var response = execution.execute(request, body);
      if (properties.getShowResponse()) {
        log.info("Response status: {}", response.getRawStatusCode());
        log.info("Response headers: {}", response.getHeaders().entrySet()
            .stream()
            .map(stringListEntry -> stringListEntry.getKey() 
                + ": " 
                + StringUtils.arrayToDelimitedString(
                    stringListEntry.getValue().toArray(new String[0]), ", "))
            .collect(Collectors.joining("\r\n")));
        final var respBody = response.getBody().readAllBytes();
        log.info("Response body: {}", respBody.length > 0
            ? MaskUtils.maskData(new String(respBody)) : "empty");
      }
      return response;
    }
  }
}