package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Refinement types.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 31.08.2021
 */
@Getter
@RequiredArgsConstructor
public enum MulticardRefinementType {

  PAREQ("PAREQ"),
  CREQ("CREQ"),
  SECUREPLUS_CODE_REQUIRED("SECUREPLUS_CODE_REQUIRED");

  private final String type;

  public static Optional<MulticardRefinementType> findByType(String type) {
    for (var val : MulticardRefinementType.values()) {
      if (val.getType().equals(type)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
