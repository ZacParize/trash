package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.test;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.test.request.MulticardTestRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.test.request.Request;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;

@Component
@Slf4j
public class TestRequestFiller extends AFiller<TransactionPayload, MulticardTestRequest> {

  @Override
  public Optional<MulticardTestRequest> fill(TransactionPayload src, MulticardTestRequest dest) {
    if (Objects.isNull(dest)) {
      return Optional.empty();
    }
    if (Objects.isNull(dest.getRequest())) {
      dest.setRequest(new Request());
    }
    final var req = dest.getRequest();
    req.setOperation(MulticardOperation.PROCESS_3DS_AUTH);
    req.setStep(MulticardProcess3DSAuthStep.FIRST);
    req.setDate(new Date());
    return Optional.of(dest);
  }
}
