package ru.vtb.tsp.ia.epay.multicard.domain.consts;

/**
 * Gateway constants.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.09.2021
 */
public class AdapterConsts {

  public static final String ADAPTER = "TDS_SOURCE";

}
