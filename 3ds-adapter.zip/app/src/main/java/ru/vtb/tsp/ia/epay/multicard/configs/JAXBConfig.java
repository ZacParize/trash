package ru.vtb.tsp.ia.epay.multicard.configs;

import com.fasterxml.jackson.module.jaxb.JaxbAnnotationModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.xml.MappingJackson2XmlHttpMessageConverter;

@Configuration
public class JAXBConfig {

  @Bean
  MappingJackson2XmlHttpMessageConverter getMappingJackson2XmlHttpMessageConverter() {
    var mappingJackson2XmlHttpMessageConverter = new MappingJackson2XmlHttpMessageConverter();
    mappingJackson2XmlHttpMessageConverter.getObjectMapper()
        .registerModule(new JaxbAnnotationModule());
    return mappingJackson2XmlHttpMessageConverter;
  }

}
