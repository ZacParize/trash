package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.configs.annotations.IntegrationTestableMethod;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.MulticardOrderRegistrationRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.MulticardOrderRegistrationResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.MulticardProcess3DSAreqRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request.MulticardProcess3DSCresRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.MulticardProcess3DSCresResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.MulticardProcess3DSAuthRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.request.MulticardProcess3DSParesRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.MulticardProcess3DSParesResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.test.request.MulticardTestRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardRequest;
import ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web.WHFEmptyHandlerException;
import ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web.WHFIncorrectInstanceException;
import ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web.WHFWebHandlerInstanceNotCreatedException;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.WebHandlerFactory;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.services.MulticardService;

@RequiredArgsConstructor
@Slf4j
@Service
public class MulticardServiceImpl implements MulticardService {

  private final WebHandlerFactory webHandlerFactory;
  private final DataFiller filler;

  @Override
  public Optional<MulticardOrderRegistrationResponse> registerOrder(
      TransactionPayload transaction) {
    final var request = new MulticardOrderRegistrationRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.ORDER_REGISTRATION, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Order registration failed!", e);
    }
    return Optional.empty();
  }

  @Override
  public Optional<MulticardProcess3DSAuthResponse> threeDsProcessAuthFirst(
      TransactionPayload transaction) {
    final var request = new MulticardProcess3DSAuthRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.AUTH_FIRST, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Order auth first failed!", e);
    }
    return Optional.empty();
  }

  @Override
  public Optional<MulticardProcess3DSAreqResponse> threeDsProcessAuthAreq(
      TransactionPayload transaction) {
    final var request = new MulticardProcess3DSAreqRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.AUTH_AREQ, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Order auth areq failed!", e);
    }
    return Optional.empty();
  }

  @Override
  public Optional<MulticardProcess3DSCresResponse> threeDsProcessAuthCres(
      TransactionPayload transaction) {
    final var request = new MulticardProcess3DSCresRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.AUTH_CRES, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Order auth cres failed!", e);
    }
    return Optional.empty();
  }

  @Override
  public Optional<MulticardProcess3DSParesResponse> threeDsProcessAuthPares(
      TransactionPayload transaction) {
    final var request = new MulticardProcess3DSParesRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.AUTH_PARES, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Order auth pares failed!", e);
    }
    return Optional.empty();
  }

  @IntegrationTestableMethod(
      integrationName = "Интеграция с мультикартой (3DS)",
      correctAnswerReqexp = ".*(\\\"status\\\"\\s{0,}:\\s{0,}\\\"INCORRECT_FORMAT\\\").*",
      methodVariablesTestData = "/integrations/tests/data/multicard.json")
  @Override
  public Optional<MulticardProcess3DSAuthResponse> test(TransactionPayload transaction) {
    final var request = new MulticardTestRequest();
    try {
      if (filler.fill(transaction, request).isPresent()) {
        return handle(MulticardRequest.TEST, transaction, request);
      }
    } catch (WHFIncorrectInstanceException | WHFEmptyHandlerException
        | WHFWebHandlerInstanceNotCreatedException e) {
      log.error("Test failed!", e);
    }
    return Optional.empty();
  }

  private <T> Optional handle(MulticardRequest mcReq, TransactionPayload payload, T request)
      throws WHFIncorrectInstanceException,
      WHFEmptyHandlerException,
      WHFWebHandlerInstanceNotCreatedException {
    return webHandlerFactory.getHandler(mcReq)
        .map(webHandler -> {
          final var response = webHandler.handle(request);
          if (response.isPresent()) {
            filler.fill(response.get(), payload);
            webHandler.confirm(response.get());
            return response.get();
          } else {
            webHandler.confirm(null);
          }
          return null;
        });
  }

}
