package ru.vtb.tsp.ia.epay.multicard.components.converters;

import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Refinement;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.04.2022
 */
@Component
public class MulticardProcess3DSAuthResponseToAuditResponseDataConverter
    implements Converter<MulticardProcess3DSAuthResponse, AuditResponseData> {

  @Override
  public AuditResponseData convert(MulticardProcess3DSAuthResponse source) {
    final var data = new AuditResponseData();
    if (Objects.isNull(source) || Objects.isNull(source.getResponse())) {
      return null;
    }
    Optional.ofNullable(source)
        .map(MulticardProcess3DSAuthResponse::getResponse)
        .map(response -> {
          data.setNextStep(
              Optional.ofNullable(response.getNextStep())
                  .map(MulticardProcess3DSAuthStep::getStep)
                  .orElse("")
          );
          data.setStatus(
              Optional.ofNullable(response.getStatus())
                  .map(MulticardStatus::name)
                  .orElse("")
          );
          data.setMethodUrl(
              Optional.ofNullable(response.getRefinement())
                  .map(refinement -> StringUtils.isNotEmpty(refinement.getMethodUrl()))
                  .orElse(Boolean.FALSE)
          );
          data.setThreeDSServerTransId(
              Optional.ofNullable(response.getRefinement())
                  .map(Refinement::getThreeDSServerTransId)
                  .orElse("")
          );
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .ifPresent(message -> {
          data.setOrderStatus(
              Optional.ofNullable(message.getOrderStatus())
                  .map(Enum::name)
                  .orElse("")
          );
          data.setOrderId(
              Optional.ofNullable(message.getOrderID())
                  .orElse("")
          );
          data.setVersion(
              Optional.ofNullable(message.getVersion())
                  .orElse("")
          );
        });
    return data;
  }
}
