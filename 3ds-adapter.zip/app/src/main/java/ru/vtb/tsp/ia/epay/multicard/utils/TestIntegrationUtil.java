package ru.vtb.tsp.ia.epay.multicard.utils;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.multicard.configs.annotations.IntegrationTestableMethod;
import ru.vtb.tsp.ia.epay.multicard.domain.TestReportItem;

/**
 * Утилита тестирования интеграции.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Component
@Slf4j
@RequiredArgsConstructor
public class TestIntegrationUtil {


  public List<TestReportItem> testIntegration(Object... clients) {
    if (clients == null || clients.length == 0) {
      return Collections.emptyList();
    }
    final var resultList = new ArrayList<TestReportItem>();
    Arrays.stream(clients)
        .forEach(o -> findRequiredMethods(o).forEach(method -> {
          final var annotation = method.getAnnotation(IntegrationTestableMethod.class);
          final var params = method.getParameters();
          final var valueMap = !StringUtils.isEmpty(annotation.methodVariablesTestData())
              ? ObjectLoader.load(annotation.methodVariablesTestData())
              : !StringUtils.isEmpty(annotation.methodVariablesTestJsonData())
                  ? ObjectLoader.loadFromJson(annotation.methodVariablesTestJsonData())
                  : Collections.emptyMap();
          final var methodInboundValues = new ArrayList<Object>();
          if (ArrayUtils.isNotEmpty(params)) {
            Arrays.stream(params).forEach(parameter -> {
              if (valueMap.containsKey(parameter.getName())) {
                final var valueB64Data = new String(
                    Base64.getDecoder().decode((String) valueMap.get(parameter.getName())));

                final var value =
                    valueB64Data.trim().startsWith("{") || valueB64Data.trim().startsWith("\"")
                        ? ObjectLoader.loadFromJson(valueB64Data, parameter.getType())
                        : Optional.of(valueB64Data);
                final var key = parameter.getName();
                if (value.isPresent()) {
                  methodInboundValues.add(value.get());
                } else {
                  throw new NullPointerException(String.format("%s is null", key));
                }
              }
            });
          }
          log.info("Тестовый запрос по интеграции: {}", annotation.integrationName());
          final var startTime = System.currentTimeMillis();
          try {
            final var requestResult = method.invoke(o, CollectionUtils.isEmpty(methodInboundValues)
                ? null
                : methodInboundValues.toArray());
            final var endTime = System.currentTimeMillis();
            final var result = requestResult instanceof Optional
                ? ((Optional<?>) requestResult).isPresent() ? ((Optional<?>) requestResult).get()
                : "empty"
                : requestResult;
            resultList.add(validateResult(annotation, result, endTime - startTime));
          } catch (Exception e) {
            final var endTime = System.currentTimeMillis();

            resultList.add(validateResult(annotation,
                getCause(e), endTime - startTime));
          }
        }));
    return resultList;
  }

  private Throwable getCause(Exception e) {
    var cause = e.getCause();
    if (Objects.isNull(cause)) {
      cause = e;
    }
    return cause;
  }

  private TestReportItem validateResult(IntegrationTestableMethod annotation, Object result,
      Long time) {
    final var reportItem = new TestReportItem();
    reportItem.setIntegration(annotation.integrationName());
    reportItem.setCorrectAnswerRegexp(annotation.correctAnswerReqexp());
    reportItem.setTime(time);
    final var testString = result instanceof Exception
        ? exceptionToString((Exception) result)
        : ObjectLoader.toJson(result);
    reportItem.setAnswer(StringUtils.isEmpty(testString) ? "" : testString);
    reportItem.setResult(
        Pattern.matches(annotation.correctAnswerReqexp(), StringUtils.isEmpty(testString)
            ? ""
            : testString.replaceAll("\r\n|\r|\n", "")
        )
    );
    return reportItem;
  }

  private String exceptionToString(Throwable e) {
    final var strWriter = new StringWriter();
    final var printWriter = new PrintWriter(strWriter);
    e.printStackTrace(printWriter);
    return strWriter.toString();
  }

  private List<Method> findRequiredMethods(Object client) {
    return Arrays.stream(client.getClass().getMethods())
        .filter(method -> method.isAnnotationPresent(IntegrationTestableMethod.class))
        .collect(Collectors.toList());
  }

}
