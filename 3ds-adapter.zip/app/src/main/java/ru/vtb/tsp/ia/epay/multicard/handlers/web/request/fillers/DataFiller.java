package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * DataFiller.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class DataFiller implements ApplicationContextAware {

  private ApplicationContext applicationContext;

  private Map<String, Filler> fillers = new HashMap<>();

  public <S, D> Optional<D> fill(S src, D dest) {
    if (Objects.isNull(dest)) {
      log.warn("Destination unknown!");
      return Optional.empty();
    }
    if (Objects.isNull(src)) {
      log.warn("Source object is null!");
      return Optional.of(dest);
    }
    fillFillerMap();
    final var fillerKey = src.getClass().getCanonicalName()
        .concat(dest.getClass().getCanonicalName());
    return fillers.get(fillerKey).fill(src, dest);
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.applicationContext = applicationContext;
  }

  private void fillFillerMap() {
    final var fillers = applicationContext.getBeansOfType(Filler.class);
    if (fillers.size() > this.fillers.size()) {
      this.fillers.clear();
      fillers
          .values()
          .forEach(filler -> Arrays.stream(filler.getClass().getDeclaredMethods())
              .filter(method -> "fill".equals(method.getName()) && method.getParameterCount() == 2)
              .filter(method ->
                  !method.getParameters()[0].getParameterizedType().getTypeName().endsWith("Object")
                      && !method.getParameters()[1].getParameterizedType().getTypeName()
                      .endsWith("Object"))
              .findFirst().ifPresent(method -> {
                final var params = method.getParameters();
                if (params.length == 2) {
                  final var srcType = params[0].getParameterizedType().getTypeName();
                  final var destType = params[1].getParameterizedType().getTypeName();
                  this.fillers.put(srcType.concat(destType), filler);
                }
              }));
    }
  }
}
