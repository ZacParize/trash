package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers;

import java.util.Collection;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

public abstract class AFiller<S, D> implements Filler<S, D> {

  @Override
  public Optional<D> fill(S src, D dest) {
    return Optional.empty();
  }

  protected Boolean isEmpty(Object o) {
    if (o instanceof String) {
      return StringUtils.isEmpty((String) o);
    }
    if (o instanceof Collection) {
      return CollectionUtils.isEmpty((Collection) o);
    }
    if (o instanceof Map) {
      return CollectionUtils.isEmpty((Map) o);
    }
    return Objects.isNull(o);
  }
}
