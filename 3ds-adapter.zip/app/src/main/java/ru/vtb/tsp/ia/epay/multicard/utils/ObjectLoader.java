package ru.vtb.tsp.ia.epay.multicard.utils;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.ParameterizedType;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

/**
 * Загрузчик объектов из JSON.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Slf4j
public class ObjectLoader {

  public static <T> T load(Class<T> loadClass) {
    return load(loadClass, null);
  }

  @SneakyThrows
  public static <T> T load(Class<T> loadClass, String name) {
    final var mapper = new ObjectMapper()
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, true)
        .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
        .registerModule(new JavaTimeModule());
    final var filename = StringUtils.isEmpty(name)
        ? "/objects/" + loadClass.getSimpleName() + ".json"
        : "/objects/" + loadClass.getSimpleName() + "/" + name + ".json";

    final var fileInfo = loadFromApp(filename);
    return mapper.readValue(fileInfo, loadClass);
  }

  @SneakyThrows
  public static Map<String, String> load(String path) {
    if (StringUtils.isEmpty(path)) {
      return Collections.emptyMap();
    }
    final var mapper = new ObjectMapper()
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, true)
        .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
        .registerModule(new JavaTimeModule());

    final var fileInfo = loadFromApp(path);
    TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() {
    };
    return mapper.readValue(fileInfo, typeRef);
  }

  @SneakyThrows
  public static Map<String, String> loadFromJson(String json) {
    if (StringUtils.isEmpty(json)) {
      return Collections.emptyMap();
    }
    final var mapper = mapper();
    TypeReference<HashMap<String, String>> typeRef = new TypeReference<HashMap<String, String>>() {
    };
    return mapper.readValue(json, typeRef);
  }

  @SneakyThrows
  public static <T> Optional<T> loadFromJson(String json, Class<T> requiredClass) {
    if (StringUtils.isEmpty(json)) {
      return Optional.empty();
    }
    final var mapper = mapper();

    return Optional.of(mapper.readValue(json, requiredClass));
  }

  @SneakyThrows
  public static String toJson(Object o) {
    final var mapper = mapper();
    return mapper.writeValueAsString(o);
  }

  public static <T> Class<T> getGenericTypeClass(T requiredClass) {
    try {
      String className = ((ParameterizedType) requiredClass.getClass()
          .getGenericSuperclass()).getActualTypeArguments()[0].getTypeName();
      Class<?> clazz = Class.forName(className);
      return (Class<T>) clazz;
    } catch (Exception e) {
      throw new IllegalStateException(
          "Class is not parametrized with generic type!!! Please use extends <> ");
    }
  }

  private static InputStream loadFromApp(String fileName) {
    final var inputStream = ObjectLoader.class.getResourceAsStream(fileName);
    if (Objects.isNull(inputStream)) {
      log.error("Не удалось получить ресурс {}", fileName);
    }
    try {
      final var bytes = inputStream.readAllBytes();
      return new ByteArrayInputStream(bytes);
    } catch (IOException e) {
      log.error("Ошибка чтения ресурса {}", fileName, e);
    }
    return null;
  }

  private static ObjectMapper mapper() {
    final var mapper = new ObjectMapper()
        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
        .configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, true)
        .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
        .configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, true);
    mapper.registerModule(new JavaTimeModule());
    return mapper;
  }

}
