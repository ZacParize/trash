package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardOperationAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardStatusAdapter;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

/**
 * Response.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
public class Response {

  @XmlElement(name = "Operation")
  @XmlJavaTypeAdapter(MulticardOperationAdapter.class)
  private MulticardOperation operation;
  @XmlJavaTypeAdapter(MulticardStatusAdapter.class)
  @XmlElement(name = "Status")
  private MulticardStatus status;
  @XmlElement(name = "Result")
  private Result result;

}
