package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardRefinementType;

/**
 * Adapter for fill refinement type field in Multicard XML.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardRefinementTypeAdapter extends XmlAdapter<String, MulticardRefinementType> {

  @Override
  public MulticardRefinementType unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardRefinementType.findByType(v).orElse(null);
  }

  @Override
  public String marshal(MulticardRefinementType v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getType();
  }
}
