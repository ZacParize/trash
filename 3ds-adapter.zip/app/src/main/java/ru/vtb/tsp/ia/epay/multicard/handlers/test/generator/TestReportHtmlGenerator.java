package ru.vtb.tsp.ia.epay.multicard.handlers.test.generator;

import freemarker.cache.ByteArrayTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.SneakyThrows;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.TestReportItem;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;
import ru.vtb.tsp.ia.epay.multicard.handlers.test.TestReportGenerator;
import ru.vtb.tsp.ia.epay.multicard.utils.FileUtils;

/**
 * генератор HTML отчета.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Component
public class TestReportHtmlGenerator implements TestReportGenerator<String> {

  @SneakyThrows
  @Override
  public String generate(List<TestReportItem> report) {
    Configuration cfg = new Configuration(Configuration.VERSION_2_3_30);
    final var file = FileUtils.getFileFromApp("/integrations/tests/templates/htmltestreport.ftl");
    final var loader = new ByteArrayTemplateLoader();
    final var reports = formatHtml(report);
    cfg.setTemplateLoader(loader);
    Map<String, Object> root = new HashMap<>();
    root.put("reportItems", reports);
    Template temp = new Template("html", new StringReader(new String(file.get().readAllBytes())),
        cfg);
    Writer out = new StringWriter();
    temp.process(root, out);
    return out.toString();
  }

  @Override
  public TestReportType reportType() {
    return TestReportType.HTML;
  }

  private List<TestReportItem> formatHtml(List<TestReportItem> testReportItems) {
    return testReportItems
        .stream()
        .map(testReportItem -> TestReportItem
            .builder()
            .answer(StringEscapeUtils.escapeHtml4(testReportItem.getAnswer()))
            .correctAnswerRegexp(testReportItem.getCorrectAnswerRegexp())
            .integration(testReportItem.getIntegration())
            .result(testReportItem.getResult())
            .time(testReportItem.getTime())
            .build())
        .collect(Collectors.toList());
  }
}
