package ru.vtb.tsp.ia.epay.multicard.domain;

import java.io.ByteArrayInputStream;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.01.2022
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class FileInfo {

  private String filename;
  private ByteArrayInputStream data;
}
