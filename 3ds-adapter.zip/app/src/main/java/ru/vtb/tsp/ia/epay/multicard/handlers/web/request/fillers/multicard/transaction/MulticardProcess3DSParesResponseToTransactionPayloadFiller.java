package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FINISHED;

import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.multicard.domain.consts.TDSConsts;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.MulticardProcess3DSParesResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

@Component
public class MulticardProcess3DSParesResponseToTransactionPayloadFiller<S> extends
    ATransactionPayloadFiller<MulticardProcess3DSParesResponse> {

  @Override
  public Optional<TransactionPayload> fill(MulticardProcess3DSParesResponse src,
      TransactionPayload dest) {
    final var paymentData = (Threeds) ((Card) dest.getPaymentData()).getAdditionalData();
    src.setTransactionId(dest.getTransactionId());
    putInContext(dest, TDSConsts.NEXT, ThreeDSAdapterOperation.FINISHED);
    return Optional.ofNullable(src)
        .map(MulticardProcess3DSParesResponse::getResponse)
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  paymentData.getThreeDSData().setOperation(FINISHED);
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400007")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .message("PARES_RESPONSE_ERROR")
                      .description("3DS technical error")
                      .build());
                }
              });
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          Optional.of(message).map(message1 -> {
            putInContext(dest, ThreeDSContextVariables.TDS_BRAND.cname(), message1.getBrand());
            putInContext(dest, ThreeDSContextVariables.TDS_MERCHANT_TID.cname(),
                message1.getMerchantTranID());
            putInContext(dest, ThreeDSContextVariables.MK_ORDER_ID.cname(), message1.getOrderID());
            putInContext(dest, ThreeDSContextVariables.TDS_VERSION.cname(), message1.getVersion());
            return message1;
          });
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .map(answerVars -> {
          Optional.of(answerVars)
              .map(answerVars1 -> {
                paymentData.setXid(answerVars1.getXid());
                paymentData.setCavv(answerVars1.getCavv());
                paymentData.setEci(answerVars1.getEci());
                putInContext(dest, ThreeDSContextVariables.XID.cname(), answerVars1.getXid());
                putInContext(dest, ThreeDSContextVariables.ECI.cname(), answerVars1.getEci());
                putInContext(dest, ThreeDSContextVariables.CAVV.cname(), answerVars1.getCavv());
                putInContext(dest, TDSConsts.TDS_VERIF, answerVars1.getThreeDSVerification());
                putInContext(dest, TDSConsts.TDS_3DS_VERSION, answerVars1.getThreeDSVersion());
                return answerVars1;
              });
          return dest;
        });
  }
}
