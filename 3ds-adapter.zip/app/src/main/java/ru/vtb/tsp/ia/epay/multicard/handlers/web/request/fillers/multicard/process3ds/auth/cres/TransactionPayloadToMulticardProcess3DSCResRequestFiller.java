package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.cres;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request.MulticardProcess3DSCresRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request.Request;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToMulticardProcess3DSCResRequestFiller implements
    Filler<TransactionPayload, MulticardProcess3DSCresRequest> {

  @Lazy
  private final DataFiller filler;

  @Override
  public Optional<MulticardProcess3DSCresRequest> fill(TransactionPayload src,
      MulticardProcess3DSCresRequest dest) {
    if (Objects.isNull(dest.getRequest())) {
      dest.setRequest(new Request());
    }
    dest.setTransactionId(src.getTransactionId());
    filler.fill(src, dest.getRequest());
    return Optional.of(dest);
  }
}
