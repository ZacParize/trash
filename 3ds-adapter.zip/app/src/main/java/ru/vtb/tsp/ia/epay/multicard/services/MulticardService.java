package ru.vtb.tsp.ia.epay.multicard.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.MulticardOrderRegistrationResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.MulticardProcess3DSCresResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.MulticardProcess3DSParesResponse;

public interface MulticardService {

  /**
   * Order registration.
   */
  Optional<MulticardOrderRegistrationResponse> registerOrder(TransactionPayload transaction);

  /**
   * 3DSAuthFirst.
   */
  Optional<MulticardProcess3DSAuthResponse> threeDsProcessAuthFirst(TransactionPayload transaction);

  /**
   * 3DSAuthAreq.
   */
  Optional<MulticardProcess3DSAreqResponse> threeDsProcessAuthAreq(TransactionPayload transaction);

  /**
   * 3DSAuthCres.
   */
  Optional<MulticardProcess3DSCresResponse> threeDsProcessAuthCres(TransactionPayload transaction);

  /**
   * 3DSAuthPAres.
   */
  Optional<MulticardProcess3DSParesResponse> threeDsProcessAuthPares(
      TransactionPayload transaction);

  /**
   * Тестовый запрос к мультикарте.
   */
  Optional<MulticardProcess3DSAuthResponse> test(TransactionPayload transaction);
}