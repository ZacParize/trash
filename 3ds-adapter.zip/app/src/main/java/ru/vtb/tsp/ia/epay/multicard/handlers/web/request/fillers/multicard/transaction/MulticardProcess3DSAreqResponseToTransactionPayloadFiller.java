package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.FINISHED;
import static ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation.findByStep;

import java.util.Objects;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.multicard.domain.consts.TDSConsts;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOrderStatus;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;

@Component
public class MulticardProcess3DSAreqResponseToTransactionPayloadFiller extends
    ATransactionPayloadFiller<MulticardProcess3DSAreqResponse> {

  @Override
  public Optional<TransactionPayload> fill(MulticardProcess3DSAreqResponse src,
      TransactionPayload dest) {
    final var paymentData = (Threeds) ((Card) dest.getPaymentData()).getAdditionalData();
    if (paymentData.getThreeDSData() != null
        && paymentData.getThreeDSData().getOperation() != ThreeDSAdapterOperation.AREQ) {
      return Optional.of(dest);
    }
    src.setTransactionId(dest.getTransactionId());
    src.setAcsUrl(Objects.nonNull(paymentData.getThreeDSData())
        && Objects.nonNull(paymentData.getThreeDSData().getNotificationUrl()));

    final var tData = paymentData.getThreeDSData();

    return Optional.ofNullable(src)
        .map(MulticardProcess3DSAreqResponse::getResponse)
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  tData.setOperation(FINISHED);
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400005")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .message("AREQ_RESPONSE_ERROR")
                      .description("3DS technical error")
                      .build());
                }
              });
          return response;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getResult)
              .map(Result::getXmlOut)
              .map(XmlOut::getMessage)
              .map(Message::getOrderStatus)
              .ifPresent(orderStatus -> {
                if (orderStatus == MulticardOrderStatus.DECLINED) {
                  dest.setStatus(TransactionState.DECLINED);
                  dest.setError(TransactionError.builder()
                      .id("10400002")
                      .httpCode(HttpStatus.INTERNAL_SERVER_ERROR.value())
                      .traceId(dest.getTransactionCode())
                      .message("AREQ_ORDER_DECLINED_ERROR")
                      .description("3DS technical error")
                      .build());
                }
                paymentData.getThreeDSData().setOperation(FINISHED);
                putInContext(dest, TDSConsts.NEXT, FINISHED);
              });
          return response;
        })
        .map(response -> {
          putInContext(dest, ThreeDSContextVariables.TDS_ARES.cname(), response.getAres());
          putInContext(dest, ThreeDSContextVariables.TDS_NEXT.cname(), response.getNextStep());
          return response;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getRefinement)
              .ifPresent(refinement -> {
                putInContext(dest, ThreeDSContextVariables.REF_TYPE.cname(),
                    refinement.getRefinementType());
                putInContext(dest, ThreeDSContextVariables.TDS_ACS.cname(), refinement.getAcsURL());
                putInContext(dest, ThreeDSContextVariables.TDS_CREQ.cname(), refinement.getCreq());
                tData.setNotificationUrl(refinement.getAcsURL());
              });
          return response;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getNextStep)
              .flatMap(next -> findByStep(next.getStep()))
              .ifPresent(step -> paymentData.getThreeDSData().setOperation(step));
          return response;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getStatus)
              .ifPresent(status -> {
                if (!MulticardStatus.SUCCESS.getStatusCode().equals(status.getStatusCode())) {
                  paymentData.getThreeDSData().setOperation(FINISHED);
                }
              });
          return response;
        })
        .map(response -> {
          Optional.of(response)
              .map(Response::getResult)
              .map(Result::getXmlOut)
              .map(XmlOut::getMessage)
              .map(message -> {
                putInContext(dest, ThreeDSContextVariables.TDS_BRAND.cname(), message.getBrand());
                putInContext(dest, ThreeDSContextVariables.MK_ORDER_ID.cname(),
                    message.getOrderID());
                putInContext(dest, ThreeDSContextVariables.TDS_VERSION.cname(),
                    message.getVersion());
                putInContext(dest, ThreeDSContextVariables.TDS_MERCHANT_TID.cname(),
                    message.getMerchantTranID());
                return message;
              })
              .map(Message::getThreeDSVars)
              .map(ThreeDSVars::getAnswerVars)
              .ifPresentOrElse(answerVars -> {
                if (Objects.nonNull(answerVars.getXid())
                    && Objects.nonNull(answerVars.getCavv())
                    && Objects.nonNull(answerVars.getEci())) {
                  paymentData.setXid(answerVars.getXid());
                  paymentData.setCavv(answerVars.getCavv());
                  paymentData.setEci(answerVars.getEci());
                  paymentData.getThreeDSData().setThreeDsVersion(ThreeDSVersion.V2_0_FRICTIONLESS);
                  paymentData.getThreeDSData().setOperation(ThreeDSAdapterOperation.FINISHED);
                  putInContext(dest, ThreeDSContextVariables.XID.cname(), answerVars.getXid());
                  putInContext(dest, ThreeDSContextVariables.CAVV.cname(), answerVars.getCavv());
                  putInContext(dest, ThreeDSContextVariables.ECI.cname(), answerVars.getEci());
                  putInContext(dest, TDSConsts.NEXT, ThreeDSAdapterOperation.FINISHED);
                }
                putInContext(dest, ThreeDSContextVariables.TDS_AREQ_VERIF.cname(),
                    answerVars.getThreeDSVerification());
                putInContext(dest, ThreeDSContextVariables.TDS_AREQ_3DS_VERSION.cname(),
                    answerVars.getThreeDSVersion());
              }, () -> {
                if (Objects.isNull(dest.getError())) {
                  paymentData.getThreeDSData().setThreeDsVersion(ThreeDSVersion.V2_0_CHALLENGE);
                  putInContext(dest, TDSConsts.NEXT, "WAITING");
                }
              });
          return dest;
        });
  }
}
