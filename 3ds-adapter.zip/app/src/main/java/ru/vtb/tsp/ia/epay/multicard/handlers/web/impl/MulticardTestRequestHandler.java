package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.fromStringToXml;
import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.toXmlString;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.test.request.MulticardTestRequest;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.AbstractWebHandler;

/**
 * Обработчик запросов регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MulticardTestRequestHandler extends
    AbstractWebHandler<MulticardTestRequest, MulticardProcess3DSAuthResponse> {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;


  @Override
  public Optional<MulticardProcess3DSAuthResponse> handle(MulticardTestRequest data) {
    try {
      Optional<String> optData = toXmlString(data, MulticardTestRequest.class);
      if (optData.isEmpty()) {
        return Optional.empty();
      }
      final var entity = new HttpEntity<>(optData.get(), basicMulticardHeader());
      final var result = restTemplate.exchange(
          properties.getBaseUrl() + properties.getEndpoints().getTest(),
          HttpMethod.POST,
          entity,
          String.class
      );
      MulticardProcess3DSAuthResponse body;
      if (Objects.isNull(result.getBody())) {
        body = new MulticardProcess3DSAuthResponse();
      } else {
        Optional<MulticardProcess3DSAuthResponse> response = fromStringToXml(
            result.getBody(), MulticardProcess3DSAuthResponse.class);
        body = response.isEmpty() ? new MulticardProcess3DSAuthResponse() : response.get();
      }
      return Optional.of(body);
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }

}
