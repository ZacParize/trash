package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Order.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
public class Order {

  @XmlElement(name = "OrderID")
  private String orderID;
  @XmlElement(name = "SessionID")
  private String sessionID;
  @XmlElement(name = "URL")
  private String url;

}
