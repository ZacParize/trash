package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;
import ru.vtb.tsp.ia.epay.multicard.exceptions.adapter.AdapterCardDataNotFoundException;
import ru.vtb.tsp.ia.epay.multicard.services.CryptoService;
import ru.vtb.tsp.ia.epay.multicard.services.RedisCache;

@Service
@RequiredArgsConstructor
@Slf4j
public class CryptoServiceImpl implements CryptoService {

  private final RedisCache redisCache;
  private final CardInfoClient cardInfoClient;

  @Override
  public Optional<CardCacheDto> getCardData(TransactionPayload payload) {
    log.info("Get cached PAN from redis key={}", payload.getTransactionId());
    final var result = redisCache.getCardData(payload.getTransactionId())
        .orElse(cardInfoClient.getCardData(payload));
    if (Objects.isNull(result)) {
      throw new AdapterCardDataNotFoundException();
    }
    result.setPan(result.getPan().replaceAll("\\D", ""));
    return Optional.of(result);
  }
}
