package ru.vtb.tsp.ia.epay.multicard.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.12.2021
 */
public interface RedisCache {

  Optional<CardCacheDto> getCardData(final String key);
}
