package ru.vtb.tsp.ia.epay.multicard.services;

import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.certificate.CertificateInfo;
import ru.vtb.tsp.ia.epay.core.utils.CertificateUtils;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;

@RequiredArgsConstructor
@Slf4j
@Service
public class CertificateMonitoringService {

  public static final String METRIC_ID = "certificates_ttl_seconds";

  private final MeterRegistry meterRegistry;
  private final MulticardProperties multicardProperties;
  private final List<CertificateInfo> certificates = new ArrayList<>();
  private final List<MulticardProperties> propertiesList = new ArrayList<>();

  /**
   * Обновить метрики для сертификатов.
   */
  @Scheduled(cron = "0 8 * * * *")
  public void updateMetrics() {
    log.info("Certificate metrics update started");
    certificates.forEach(this::updateCertificateMetric);
    log.info("Certificate metrics update finished");
  }

  @PostConstruct
  public void loadCertificateListAndUpdateMetrics() {
    log.info("Load keystore data for certificate metrics started");
    //Из каждого хранилища получаем список x509 сертификатов и кладем в общий список
    propertiesList.add(multicardProperties);
    propertiesList.forEach(props -> {
      final var keystorePath = props.getSsl().getKeystorePath();
      try (var fileInputStream = new FileInputStream(keystorePath)) {
        log.info("Get certificate data from keystore {} with type {}",
            keystorePath, props.getSsl().getKeystoreType());
        final var keyStore = loadKeyStore(props.getSsl().getKeystoreType(),
            props.getSsl().getKeyPass(), fileInputStream);
        //Данные хранилища успешно загружены
        if (Objects.nonNull(keyStore)) {
          certificates.addAll(getCertificatesList(keyStore, keystorePath));
        }
      } catch (IOException ex) {
        log.error("Can't load keystore file", ex);
      }
    });
    log.info("{} certificates loaded for metrics", certificates.size());
    //Обновляем метрики при старте приложения
    updateMetrics();
  }

  private void updateCertificateMetric(CertificateInfo certificateDto) {
    Gauge.builder(METRIC_ID, certificateDto.getNotAfterDate(),
            this::secondsFromDateToNow)
        .strongReference(true)
        .tags(getTags(certificateDto))
        .description("Time left before certificate expiration")
        .register(meterRegistry);
  }

  private List<CertificateInfo> getCertificatesList(KeyStore keyStore, String keyStoreLocation) {
    //Берем все объекты из хранилища и преобразуем каждый в CertificateDto
    var certificateList = new ArrayList<CertificateInfo>();
    CertificateInfo certificateInfo;
    for (var alias : getAliases(keyStore)) {
      try {
        certificateInfo = CertificateUtils.getCertificateInfo(keyStore, keyStoreLocation, alias);
        if (Objects.nonNull(certificateInfo)) {
          certificateList.add(certificateInfo);
        }
      } catch (GeneralSecurityException e) {
        //Если возникли ошибки при чтении, выводи м в логи, а сертификат не добавляем в метрики
        log.error("Error occurred while reading certificate data: alias {}, "
            + "keyStoreLocation {}", alias, keyStoreLocation, e);
      }
    }
    return certificateList;
  }

  private List<String> getAliases(KeyStore keyStore) {
    try {
      //В хранилище каждый объект имеет свой уникальный псевдоним (alias)
      return Collections.list(keyStore.aliases());
    } catch (KeyStoreException e) {
      log.error("Ошибка при получении списка сертификатов в хранилище", e);
      return Collections.emptyList();
    }
  }

  private double secondsFromDateToNow(LocalDateTime notAfter) {
    return Long.valueOf(notAfter.toInstant(ZoneOffset.UTC).getEpochSecond()
            - LocalDateTime.now(ZoneOffset.UTC).toInstant(ZoneOffset.UTC).getEpochSecond())
        .doubleValue();
  }

  private List<Tag> getTags(CertificateInfo certificateDto) {
    return List.of(
        Tag.of("cn", Optional.of(certificateDto.getCommonName()).orElse("")),
        Tag.of("resource", certificateDto.getResource()),
        Tag.of("san", certificateDto.getAllowedHosts()),
        Tag.of("serial", "0x" + certificateDto.getSerialNumber().toString(16))
    );
  }

  private KeyStore loadKeyStore(String keyStoreType, String keyStorePass,
      FileInputStream fileInputStream) {
    try {
      //Загружаем хранилище ключей/сертификатов
      final var keyStore = KeyStore.getInstance(keyStoreType);
      keyStore.load(fileInputStream, keyStorePass.toCharArray());
      return keyStore;
    } catch (IOException e) {
      log.error("Can't load keystore", e);
      return null;
    } catch (GeneralSecurityException e) {
      log.error("Can't read certificates data", e);
      return null;
    }
  }
}