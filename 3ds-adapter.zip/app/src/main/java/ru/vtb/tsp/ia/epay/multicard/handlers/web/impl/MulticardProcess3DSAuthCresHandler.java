package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.fromStringToXml;
import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.toXmlString;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request.MulticardProcess3DSCresRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.response.MulticardProcess3DSCresResponse;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.AbstractWebHandler;

/**
 * Обработчик запросов регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MulticardProcess3DSAuthCresHandler extends
    AbstractWebHandler<MulticardProcess3DSCresRequest, MulticardProcess3DSCresResponse> {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;


  @Override
  @AuditProcess("TSPACQ_BOX_MK_AUTH_CRES_REQUEST")
  public Optional<MulticardProcess3DSCresResponse> handle(MulticardProcess3DSCresRequest data) {
    try {
      Optional<String> optData = toXmlString(data, MulticardProcess3DSCresRequest.class);
      if (optData.isEmpty()) {
        return Optional.empty();
      }
      final var entity = new HttpEntity<>(optData.get(), basicMulticardHeader());
      final var result = restTemplate.exchange(
          properties.getBaseUrl() + properties.getEndpoints().getProcess3DSAuthCres(),
          HttpMethod.POST,
          entity,
          String.class
      );
      MulticardProcess3DSCresResponse body;
      if (Objects.isNull(result.getBody())) {
        body = new MulticardProcess3DSCresResponse();
      } else {
        Optional<MulticardProcess3DSCresResponse> response = fromStringToXml(
            result.getBody(), MulticardProcess3DSCresResponse.class);
        body = response.isEmpty() ? new MulticardProcess3DSCresResponse() : response.get();
      }
      return Optional.of(body);
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }

  @Override
  @AuditProcess("TSPACQ_BOX_MK_AUTH_CRES_RESPONSE")
  public void confirm(MulticardProcess3DSCresResponse response) {
    super.confirm(response);
  }
}
