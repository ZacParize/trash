package ru.vtb.tsp.ia.epay.multicard.controllers;

import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;
import ru.vtb.tsp.ia.epay.multicard.services.TestService;

/**
 * Контроллер для получения json с API онбординга интернет эквайринга.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 21.09.2020
 */
@RestController
@RequestMapping("/api/v1/test")
@RequiredArgsConstructor
public class TestController {

  private final TestService testService;

  @SneakyThrows
  @GetMapping(value = "/integrations", produces = MediaType.TEXT_HTML_VALUE + ";charset=UTF-8")
  @ResponseBody
  public ResponseEntity<String> test() {
    return ResponseEntity.ok(testService.allIntegrationsTest(TestReportType.HTML));
  }
}
