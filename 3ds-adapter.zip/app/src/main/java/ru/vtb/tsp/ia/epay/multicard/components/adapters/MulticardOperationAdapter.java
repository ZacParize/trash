package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;

/**
 * Адаптер для маршализации/демаршализации операции.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardOperationAdapter extends XmlAdapter<String, MulticardOperation> {

  @Override
  public MulticardOperation unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardOperation.findByOperation(v).orElse(null);
  }

  @Override
  public String marshal(MulticardOperation v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getOperation();
  }
}
