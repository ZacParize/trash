package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 3DS Commands.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 13.09.2021
 */
@RequiredArgsConstructor
@Getter
public enum MulticardTDSCommand {

  TEST("TEST", "Проверка связи и корректности настройки системы"),
  PAYMENT("PAYMENT", "Проведение платежной операции по карте клиента"),
  PAYMENTREVERSAL("PAYMENTREVERSAL", "Проведение отмены предварительно "
      + "авторизованной операции"),
  REFUND("REFUND",
      "Проведение возврата товара по предварительно авторизованной операции "
          + "(возврат денег на карту, по которой была авторизация)"),
  PREAUTH("PREAUTH", "Проведение предавторизации по карте клиента"),
  COMPLETE("COMPLETE", "Завершение платежа (по предварительной авторизации)"),
  CARDVERIFICATION("CARDVERIFICATION", "Проверка статуса карты"),
  PAYMENTVENDOR("PAYMENTVENDOR", "Платёж в пользу поставщика услуг"),
  PAYMENTVENDORREVERSAL("PAYMENTVENDORREVERSAL", "Отмена платежа в пользу "
      + "поставщика услуг"),
  P2PCALCFEE("P2PCALCFEE", "Расчёт комиссии за перевод"),
  P2PTRANSFER("P2PTRANSFER", "Перевод с карты на карту"),
  P2PDEBIT("P2PDEBIT", "Перевод средств с карты на карту/счёт (списание с карты)"),
  P2PDEBITREVERSAL("P2PDEBITREVERSAL", "Отмена списания средств с карт дебетовой "
      + "части перевода"),
  P2PCREDIT("P2PCREDIT", "Перевод средств со счета на карту (пополнение карты)"),
  CLOSEDAY("CLOSEDAY", "Закрытие периода (дня) терминала (с одновременной "
      + "сверкой итогов)"),
  STATUS("STATUS", "Запрос статуса операции");


  private final String code;
  private final String description;

  public static Optional<MulticardTDSCommand> findByCode(String code) {
    for (var val : MulticardTDSCommand.values()) {
      if (val.getCode().equals(code)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
