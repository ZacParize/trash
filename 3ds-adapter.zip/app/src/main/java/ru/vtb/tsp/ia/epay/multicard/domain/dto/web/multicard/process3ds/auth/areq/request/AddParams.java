package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Add params block.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class AddParams {

  @XmlElement(name = "acquirerMerchantID")
  private String acquirerMerchantID;

  @XmlElement(name = "merchantName")
  private String merchantName;

  @XmlElement(name = "mcc")
  private String mcc;

  @XmlElement(name = "threeDSRequestorURL")
  private String threeDSRequestorURL;

  @XmlElement(name = "threeDSCompInd")
  private String threeDSCompInd;

  @XmlElement(name = "messageCategory")
  private String messageCategory;

  @XmlElement(name = "threeDSRequestorAuthenticationInd")
  private String threeDSRequestorAuthenticationInd;


}
