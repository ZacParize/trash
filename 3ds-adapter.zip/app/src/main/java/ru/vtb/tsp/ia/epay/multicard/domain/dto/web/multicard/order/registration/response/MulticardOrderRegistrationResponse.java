package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Ответ на запрос регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Data
@XmlRootElement(name = "TKKPG")
@XmlAccessorType(XmlAccessType.FIELD)
public class MulticardOrderRegistrationResponse {

  @XmlElement(name = "Response")
  private Response response;

  @XmlTransient
  private String transactionId;

}
