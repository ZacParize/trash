package ru.vtb.tsp.ia.epay.multicard.handlers.web;

import java.util.Objects;
import java.util.Optional;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web.EmptyResponseException;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 12.04.2022
 */
public abstract class AbstractWebHandler<S, R> implements WebHandler<S, R> {

  @Override
  public Optional<R> handle(S src) {
    return Optional.empty();
  }

  @Override
  public void confirm(R response) {
    if (Objects.isNull(response)) {
      throw new EmptyResponseException();
    }
  }

  protected HttpHeaders basicMulticardHeader() {
    final var header = new HttpHeaders();
    header.add(HttpHeaders.ACCEPT, MediaType.TEXT_XML_VALUE);
    header.add(HttpHeaders.CONTENT_TYPE, MediaType.TEXT_XML_VALUE);
    return header;
  }
}
