package ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web;

/**
 * Выбрасывается, если созданный обработчик не является экземпляром WebHandler.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
public class WHFIncorrectInstanceException extends Exception {

}
