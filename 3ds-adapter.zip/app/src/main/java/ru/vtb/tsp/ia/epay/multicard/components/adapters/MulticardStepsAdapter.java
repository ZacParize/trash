package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;

/**
 * Adapter for fill step field in Multicard XML.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardStepsAdapter extends XmlAdapter<String, MulticardProcess3DSAuthStep> {

  @Override
  public MulticardProcess3DSAuthStep unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardProcess3DSAuthStep.findByStep(v).orElse(null);
  }

  @Override
  public String marshal(MulticardProcess3DSAuthStep v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getStep();
  }
}
