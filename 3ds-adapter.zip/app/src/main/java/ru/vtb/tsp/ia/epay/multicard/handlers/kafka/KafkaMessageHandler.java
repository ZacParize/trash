package ru.vtb.tsp.ia.epay.multicard.handlers.kafka;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.consts.AdapterConsts;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.Adapter;
import ru.vtb.tsp.ia.epay.multicard.handlers.Handler;
import ru.vtb.tsp.ia.epay.multicard.handlers.kafka.gateway.AdapterHandler;

/**
 * Kafka all message handler.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.09.2021
 */
@Component
@RequiredArgsConstructor
public class KafkaMessageHandler implements Handler<TransactionPayload, TransactionPayload>,
    ApplicationContextAware {

  private ApplicationContext context;
  private final Map<Adapter, AdapterHandler> handlers = new EnumMap<>(Adapter.class);

  @Override
  public Optional<TransactionPayload> handle(TransactionPayload src) {
    collectGatewayHandlers();
    final var result = Optional.ofNullable(src)
        .map(TransactionPayload::getContext)
        .map(stringSerializableMap -> {
          if (stringSerializableMap.containsKey(AdapterConsts.ADAPTER)) {
            final var adapter = Adapter.valueOf(
                (String) stringSerializableMap.get(AdapterConsts.ADAPTER));
            if (this.handlers.containsKey(adapter)) {
              return this.handlers.get(adapter).handle(src).orElse(null);
            }
          } else {
            if (this.handlers.containsKey(Adapter.MULTICARD)) {
              return this.handlers.get(Adapter.MULTICARD).handle(src).orElse(null);
            }
          }
          return null;
        });
    if (result.isEmpty()) {
      return Optional.empty();
    }
    return result;
  }

  @PostConstruct
  private void collectGatewayHandlers() {
    final var handlers = context.getBeansOfType(AdapterHandler.class);
    if (handlers.size() <= this.handlers.size()) {
      return;
    }
    handlers.values().forEach(adapterHandler -> {
      final var adapter = adapterHandler.supportedGateway();
      if (Objects.nonNull(adapter)) {
        this.handlers.put(adapter, adapterHandler);
      }
    });
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
    this.context = applicationContext;
  }
}
