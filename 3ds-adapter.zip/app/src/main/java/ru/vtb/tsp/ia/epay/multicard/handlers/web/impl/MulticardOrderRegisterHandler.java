package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.fromStringToXml;
import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.toXmlString;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.MulticardOrderRegistrationRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.response.MulticardOrderRegistrationResponse;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.AbstractWebHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.services.impl.AuditService;

/**
 * Обработчик запросов регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MulticardOrderRegisterHandler extends
    AbstractWebHandler<MulticardOrderRegistrationRequest, MulticardOrderRegistrationResponse> {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;
  private final DataFiller filler;
  private final AuditService auditService;

  @Override
  @AuditProcess("TSPACQ_BOX_MK_AUTH_CREATE_ORDER_REQUEST")
  public Optional<MulticardOrderRegistrationResponse> handle(
      MulticardOrderRegistrationRequest data) {
    try {
      Optional<String> optData = toXmlString(data, MulticardOrderRegistrationRequest.class);
      if (optData.isEmpty()) {
        return Optional.empty();
      }
      final var entity = new HttpEntity<>(optData.get(), basicMulticardHeader());
      final var result = restTemplate.exchange(
          properties.getBaseUrl() + properties.getEndpoints().getOrderRegistration(),
          HttpMethod.POST,
          entity,
          String.class
      );
      MulticardOrderRegistrationResponse body;
      if (Objects.isNull(result.getBody())) {
        body = new MulticardOrderRegistrationResponse();
      } else {
        Optional<MulticardOrderRegistrationResponse> response = fromStringToXml(
            result.getBody(), MulticardOrderRegistrationResponse.class);
        body = response.isEmpty() ? new MulticardOrderRegistrationResponse() : response.get();
      }
      return Optional.of(body);
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }

  @Override
  public void confirm(MulticardOrderRegistrationResponse response) {
    super.confirm(response);
    filler.fill(response, AuditResponseData.builder().build())
        .ifPresent(auditService::authCreateOrderResponse);
  }
}
