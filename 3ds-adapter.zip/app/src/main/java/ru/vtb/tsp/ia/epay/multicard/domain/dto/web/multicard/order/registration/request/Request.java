package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardLanguageAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardOperationAdapter;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardLanguage;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;

/**
 * Блок Request.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Request {

  @XmlElement(name = "Operation")
  @XmlJavaTypeAdapter(MulticardOperationAdapter.class)
  private MulticardOperation operation;
  @XmlElement(name = "Language")
  @XmlJavaTypeAdapter(MulticardLanguageAdapter.class)
  private MulticardLanguage language;
  @XmlElement(name = "Order")
  private Order order;
  @XmlElement(name = "EncryptedPayload")
  private Object encryptedPayload;
}
