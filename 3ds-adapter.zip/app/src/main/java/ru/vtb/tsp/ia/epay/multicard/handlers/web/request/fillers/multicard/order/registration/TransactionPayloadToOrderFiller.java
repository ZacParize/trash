package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.order.registration;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.components.converters.amount.AmountConverter;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.Order;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.Params;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardCurrency;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToOrderFiller implements Filler<TransactionPayload, Order> {

  @Lazy
  private final DataFiller filler;
  private final AmountConverter amountConverter;
  private final MulticardProperties properties;

  @Override
  public Optional<Order> fill(TransactionPayload src, Order dest) {
    if (Objects.isNull(dest.getParams())) {
      dest.setParams(new Params());
    }
    dest.setAmount(amountConverter.convert(src.getAmount()));
    dest.setDescription(src.getDescription());
    dest.setCurrency(
        MulticardCurrency.findByLetterCode(src.getAmount().getCurrency()).orElse(null));
    dest.setMerchant(properties.getIpspId());
    dest.setOrderType("3DSOnly");
    filler.fill(src, dest.getParams());
    return Optional.of(dest);
  }
}
