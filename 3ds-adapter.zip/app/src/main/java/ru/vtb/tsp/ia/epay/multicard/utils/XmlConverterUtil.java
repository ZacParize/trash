package ru.vtb.tsp.ia.epay.multicard.utils;

import java.io.StringReader;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

@Slf4j
@UtilityClass
public final class XmlConverterUtil {

  private static final String XML_HEADER = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
  private static final String EMPTY_STRING = "";

  public static <T> Optional<String> toXmlString(T data, Class<T> jaxbClass) {
    try {
      final var requestContext = JAXBContext.newInstance(jaxbClass);
      final var marshaller = requestContext.createMarshaller();
      marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
      marshaller.setProperty(Marshaller.JAXB_FRAGMENT, true);
      StringWriter writer = new StringWriter();
      writer.append(XML_HEADER);
      marshaller.marshal(data, writer);
      return Optional.of(writer.toString());
    } catch (JAXBException e) {
      log.error("JAXB xml marshall exception", e);
      return Optional.empty();
    }
  }

  public static <T> Optional<T> fromStringToXml(String data, Class<T> jaxbClass) {
    try {
      final var context = JAXBContext.newInstance(jaxbClass);
      final var unmarshaller = context.createUnmarshaller();
      final var reader = new StringReader(data);
      return Optional.of((T) unmarshaller.unmarshal(reader));
    } catch (JAXBException e) {
      log.error("JAXB xml unmarshall exception", e);
    }
    return Optional.empty();
  }

  /**
   * PARES в запросе закодирован в BASE64 и сжат zlib.
   *
   * @param bytesToDecompress -массив байт раскодированного PARES из Base64.
   * @return - массив распакованного  ZLIBом  пареса, фактически готовый читаемый xml
   */
  public static byte[] decompress(byte[] bytesToDecompress) {
    byte[] returnValues = null;
    Inflater inflater = new Inflater();
    int numberOfBytesToDecompress = bytesToDecompress.length;
    inflater.setInput(bytesToDecompress, 0, numberOfBytesToDecompress);
    int bufferSizeInBytes = numberOfBytesToDecompress;
    List<Byte> bytesDecompressedSoFar = new ArrayList<Byte>();
    try {
      while (!inflater.needsInput()) {
        byte[] bytesDecompressedBuffer = new byte[bufferSizeInBytes];
        int numberOfBytesDecompressedThisTime = inflater.inflate(bytesDecompressedBuffer);
        for (int b = 0; b < numberOfBytesDecompressedThisTime; b++) {
          bytesDecompressedSoFar.add(bytesDecompressedBuffer[b]);
        }
      }
      returnValues = new byte[bytesDecompressedSoFar.size()];
      for (int b = 0; b < returnValues.length; b++) {
        returnValues[b] = bytesDecompressedSoFar.get(b);
      }
    } catch (DataFormatException e) {
      log.error("Pares unzip error {}", e.getMessage());
    } finally {
      inflater.end();
    }
    return returnValues;
  }

  public static byte[] compress(byte[] bytesToCompress) {
    Deflater deflater = new Deflater();
    deflater.setInput(bytesToCompress);
    deflater.finish();
    byte[] bytesCompressed = new byte[Short.MAX_VALUE];
    int numberOfBytesAfterCompression = deflater.deflate(bytesCompressed);
    byte[] returnValues = new byte[numberOfBytesAfterCompression];
    System.arraycopy(bytesCompressed, 0, returnValues, 0, numberOfBytesAfterCompression);
    return returnValues;
  }

  public static Optional<String> getNodeValue(String value, String path) {
    return Optional.ofNullable(value).map(v -> {
      String result = null;
      try {
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = builderFactory.newDocumentBuilder();
        Document xmlDocument = builder.parse(new InputSource(new StringReader(v)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        result = ((Node) xpath.compile(path)
            .evaluate(xmlDocument, XPathConstants.NODE)).getFirstChild().getNodeValue();
      } catch (Exception e) {
        log.error("Error parsing pares/pareq {}", e.getMessage());
      }
      return result;
    });
  }

  public byte[] processPareq(String pareq) {
    return compress(Optional.ofNullable(pareq)
        .map(xml ->
            !xml.startsWith("<?xml")
                ? (XML_HEADER + xml).getBytes(StandardCharsets.UTF_8)
                : xml.getBytes(StandardCharsets.UTF_8))
        .orElse(EMPTY_STRING.getBytes(StandardCharsets.UTF_8)));
  }
}
