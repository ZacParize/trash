package ru.vtb.tsp.ia.epay.multicard.configs.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Аннотация навешиваемая на метод доступный для тестирования.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface IntegrationTestableMethod {

  /**
   * Наименование интеграции.
   */
  String integrationName() default "UnnamedIntegration";

  /**
   * Регулярное выражение соответствующее корректному ответу.
   */
  String correctAnswerReqexp() default "(.*?)";

  /**
   * Путь к файлу с входными данными для метода.
   */
  String methodVariablesTestData() default "";

  /**
   * Тестовые входные данные в виде json.
   */
  String methodVariablesTestJsonData() default "";

}
