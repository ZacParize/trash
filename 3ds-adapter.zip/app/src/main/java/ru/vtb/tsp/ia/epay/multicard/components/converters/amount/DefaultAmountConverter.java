package ru.vtb.tsp.ia.epay.multicard.components.converters.amount;

import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;

@Component
public class DefaultAmountConverter implements AmountConverter {

  @Override
  public String convert(Amount source) {
    return String.valueOf(Math.round(source.getValue() * 100));
  }

}
