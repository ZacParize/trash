package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Операции мультикарты.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@RequiredArgsConstructor
@Getter
public enum MulticardStatus {

  SUCCESS("00", "Успех"),
  FORBIDDEN_OPERATION("10",
      "Провайдер/магазин не имеет доступа к операции создания заказа "
          + "(или такой Провайдер/магазин не зарегистрирован)"),
  INCORRECT_FORMAT("30", "неверный формат сообщения "
      + "(нет обязательных полей и т.д.)"),
  INVALID_OPERATION("54", "Недопустимая операция"),
  MESSAGE_PARSE_ERROR("60", "Ошибка разбора сообщения"),
  EMPTY_POS_RESPONSE("72", "Пустой ответ POS-драйвера"),
  SYSTEM_ERROR("96", "Системная ошибка"),
  CONNECTION_WITH_POS_ERROR("97", "Ошибка связи POS-драйвером");

  private final String statusCode;
  private final String description;

  public static Optional<MulticardStatus> findByStatusCode(String statusCode) {
    for (var val : MulticardStatus.values()) {
      if (val.getStatusCode().equals(statusCode)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
