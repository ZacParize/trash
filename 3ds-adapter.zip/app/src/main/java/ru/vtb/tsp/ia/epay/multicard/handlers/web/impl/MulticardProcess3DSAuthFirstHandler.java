package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.fromStringToXml;
import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.toXmlString;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.request.MulticardProcess3DSAuthRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.first.response.MulticardProcess3DSAuthResponse;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.AbstractWebHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.services.impl.AuditService;

/**
 * Обработчик запросов регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MulticardProcess3DSAuthFirstHandler extends
    AbstractWebHandler<MulticardProcess3DSAuthRequest, MulticardProcess3DSAuthResponse> {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;
  private final DataFiller filler;
  private final AuditService auditService;


  @Override
  @AuditProcess("TSPACQ_BOX_MK_AUTH_FIRST_REQUEST")
  public Optional<MulticardProcess3DSAuthResponse> handle(MulticardProcess3DSAuthRequest data) {
    try {
      Optional<String> optData = toXmlString(data, MulticardProcess3DSAuthRequest.class);
      if (optData.isEmpty()) {
        return Optional.empty();
      }
      final var entity = new HttpEntity<>(optData.get(), basicMulticardHeader());
      final var result = restTemplate.exchange(
          properties.getBaseUrl() + properties.getEndpoints().getProcess3DSAuthFirst(),
          HttpMethod.POST,
          entity,
          String.class
      );
      MulticardProcess3DSAuthResponse body;
      if (Objects.isNull(result.getBody())) {
        body = new MulticardProcess3DSAuthResponse();
      } else {
        Optional<MulticardProcess3DSAuthResponse> response = fromStringToXml(
            result.getBody(), MulticardProcess3DSAuthResponse.class);
        body = response.isEmpty() ? new MulticardProcess3DSAuthResponse() : response.get();
      }
      return Optional.of(body);
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }

  @Override
  public void confirm(MulticardProcess3DSAuthResponse response) {
    super.confirm(response);
    filler.fill(response, AuditResponseData.builder().build())
        .ifPresent(auditService::authFirstResponse);
  }
}
