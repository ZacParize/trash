package ru.vtb.tsp.ia.epay.multicard.services.impl;

import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;
import ru.vtb.tsp.ia.epay.multicard.handlers.test.TestReportGeneratorManager;
import ru.vtb.tsp.ia.epay.multicard.services.MulticardService;
import ru.vtb.tsp.ia.epay.multicard.services.TestService;
import ru.vtb.tsp.ia.epay.multicard.utils.TestIntegrationUtil;

/**
 * Сервис самотестирования.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 17.12.2020
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class TestServiceImpl implements TestService {

  private final TestIntegrationUtil testIntegrationUtil;
  private final TestReportGeneratorManager testReportGeneratorManager;
  private final MulticardService multicardService;

  @Override
  public String allIntegrationsTest(TestReportType reportType) {
    final var reports = testIntegrationUtil.testIntegration(multicardService);
    final var generator = testReportGeneratorManager.get(reportType);
    return generator.map(testReportGenerator -> testReportGenerator.generate(reports))
        .map(o -> (String) o)
        .orElse("");
  }

  @PostConstruct
  private void test() {
    log.info(allIntegrationsTest(TestReportType.CONSOLE));
  }
}
