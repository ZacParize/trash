package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.order.registration;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.Order;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.order.registration.request.Request;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardLanguage;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToRequestFiller implements Filler<TransactionPayload, Request> {

  @Lazy
  private final DataFiller filler;

  @Override
  public Optional<Request> fill(TransactionPayload src, Request dest) {
    if (Objects.isNull(dest.getOrder())) {
      dest.setOrder(new Order());
    }
    dest.setLanguage(MulticardLanguage.RU);
    dest.setOperation(MulticardOperation.CREATE_ORDER);
    filler.fill(src, dest.getOrder());
    return Optional.of(dest);
  }
}
