package ru.vtb.tsp.ia.epay.multicard.handlers;

import java.util.Optional;

/**
 * Handler interface.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 25.08.2021
 */
public interface Handler<S, R> {

  Optional<R> handle(S src);

}
