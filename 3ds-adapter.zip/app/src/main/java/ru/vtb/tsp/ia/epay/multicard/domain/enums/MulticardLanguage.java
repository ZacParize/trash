package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Languages.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
@Getter
@RequiredArgsConstructor
public enum MulticardLanguage {

  RU("RU"),
  EN("EN");

  private final String lang;

  public static Optional<MulticardLanguage> findByLang(String lang) {
    for (var val : MulticardLanguage.values()) {
      if (val.getLang().equals(lang)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
