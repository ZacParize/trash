package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardOrderRegisterHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardProcess3DSAuthAreqHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardProcess3DSAuthCresHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardProcess3DSAuthFirstHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardProcess3DSAuthPAResHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.impl.MulticardTestRequestHandler;

/**
 * Запросы к мультикарте и классы обработчиков.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
@Getter
@RequiredArgsConstructor
public enum MulticardRequest {

  ORDER_REGISTRATION(MulticardOrderRegisterHandler.class),
  AUTH_FIRST(MulticardProcess3DSAuthFirstHandler.class),
  AUTH_AREQ(MulticardProcess3DSAuthAreqHandler.class),
  AUTH_CRES(MulticardProcess3DSAuthCresHandler.class),
  AUTH_PARES(MulticardProcess3DSAuthPAResHandler.class),
  TEST(MulticardTestRequestHandler.class);

  private final Class<?> handlerClass;

  public static Optional<MulticardRequest> findByHandlerClass(Class<?> handlerClass) {
    for (var val : MulticardRequest.values()) {
      if (handlerClass.getName().contains("$")) {
        final var className = handlerClass.getName().split("\\$")[0];
        if (val.getHandlerClass().getName().equals(className)) {
          return Optional.of(val);
        }
      } else {
        if (val.getHandlerClass().equals(handlerClass)) {
          return Optional.of(val);
        }
      }
    }
    return Optional.empty();
  }
}
