package ru.vtb.tsp.ia.epay.multicard.configs.properties;

import lombok.Data;

/**
 * Ендпоинты мультикарты.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 16.08.2021
 */
@Data
public class MulticardEndpoints {

  private String orderRegistration;
  private String process3DSAuthFirst;
  private String process3DSAuthAreq;
  private String process3DSAuthCres;
  private String process3DSAuthPares;
  private String test;

}
