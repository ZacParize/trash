package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardTDSCommand;

/**
 * Adapter for fill 3DS commands.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 13.09.2021
 */
public class MulticardTDSCommandsAdapter extends XmlAdapter<String, MulticardTDSCommand> {

  @Override
  public MulticardTDSCommand unmarshal(String v) throws Exception {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardTDSCommand.findByCode(v).orElse(null);
  }

  @Override
  public String marshal(MulticardTDSCommand v) throws Exception {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getCode();
  }
}
