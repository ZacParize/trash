package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * 3DS verification process status.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@RequiredArgsConstructor
@Getter
public enum MulticardOrderStatus {

  APPROVED,
  DECLINED
}
