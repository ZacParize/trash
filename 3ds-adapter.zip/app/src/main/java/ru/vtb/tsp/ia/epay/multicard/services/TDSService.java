package ru.vtb.tsp.ia.epay.multicard.services;


import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

public interface TDSService {

  Optional<TransactionPayload> createOrder(TransactionPayload payload);

  Optional<TransactionPayload> first(TransactionPayload payload);

  Optional<TransactionPayload> areq(TransactionPayload payload);

  Optional<TransactionPayload> cres(TransactionPayload payload);

  Optional<TransactionPayload> pares(TransactionPayload payload);


}
