package ru.vtb.tsp.ia.epay.multicard.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

/**
 * Service for internel transaction routing.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.10.2021
 */
public interface RouterService {

  Optional<TransactionPayload> route(TransactionPayload src, TDSService destService);

}
