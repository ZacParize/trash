package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardCurrency;

/**
 * Адаптер для маршализации/демаршализации статуса.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MulticardCurrencyAdapter extends XmlAdapter<String, MulticardCurrency> {

  @Override
  public MulticardCurrency unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardCurrency.findByNumericCode(v).orElse(null);
  }

  @Override
  public String marshal(MulticardCurrency v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.getNumericCode();
  }
}
