package ru.vtb.tsp.ia.epay.multicard.exceptions.config;

public class RestTemplateConfigurationException extends RuntimeException {

  public RestTemplateConfigurationException(Throwable cause) {
    super(cause);
  }
}
