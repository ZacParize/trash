package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Коды валют мультикарты.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
@Getter
@RequiredArgsConstructor
public enum MulticardCurrency {

  RUB("RUB", "643"),
  RUR("RUR", "810"),
  EUR("EUR", "978"),
  USD("USD", "840");

  private final String letterCode;
  private final String numericCode;

  public static Optional<MulticardCurrency> findByLetterCode(String letterCode) {
    for (var val : MulticardCurrency.values()) {
      if (val.getLetterCode().equals(letterCode)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }

  public static Optional<MulticardCurrency> findByNumericCode(String numericCode) {
    for (var val : MulticardCurrency.values()) {
      if (val.getNumericCode().equals(numericCode)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
