package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.transaction;

import java.util.HashMap;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;

public abstract class ATransactionPayloadFiller<S> extends AFiller<S, TransactionPayload> {

  protected void putInContext(TransactionPayload payload, String key, Object value) {
    if (!isEmpty(payload) && !isEmpty(key) && !isEmpty(value)) {
      if (CollectionUtils.isEmpty(payload.getContext())) {
        payload.setContext(new HashMap<>());
      }
      if (value instanceof Enum<?>) {
        payload.getContext().put(key, ((Enum<?>) value).name());
      }
      if (value instanceof String) {
        payload.getContext().put(key, (String) value);
      }
      payload.getContext().put(key, value.toString());
    }
  }

}
