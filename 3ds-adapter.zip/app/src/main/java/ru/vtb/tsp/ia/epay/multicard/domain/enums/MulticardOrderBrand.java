package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Multicard result brand.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
@RequiredArgsConstructor
@Getter
public enum MulticardOrderBrand {

  MC("MC", "MasterCard"),
  VISA("VISA", "VISA"),
  MIR("MIR", "МИР"),
  AM_EX("AmEx", "American Express");

  private final String value;
  private final String description;

  public static Optional<MulticardOrderBrand> findByValue(String value) {
    for (var val : MulticardOrderBrand.values()) {
      if (val.getValue().equals(value)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
