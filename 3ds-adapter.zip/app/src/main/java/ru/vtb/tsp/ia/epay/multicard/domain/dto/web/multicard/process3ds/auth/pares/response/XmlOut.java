package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * XmlOut.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@XmlAccessorType(XmlAccessType.FIELD)
public class XmlOut {

  @XmlElement(name = "Message")
  private Message message;
}
