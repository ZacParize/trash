package ru.vtb.tsp.ia.epay.multicard.domain;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CardRequestDto {

  @NotNull
  private String transactionId;
  @NotNull
  private String encryptedPan;
  @NotNull
  private String encryptedCvv;
}
