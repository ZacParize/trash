package ru.vtb.tsp.ia.epay.multicard.handlers.test;

import java.util.Optional;
import lombok.Setter;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.TestReportType;

/**
 * Менеджер генераторов тестовых отчетов.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Component
public class TestReportGeneratorManager implements ApplicationContextAware {

  @Setter
  private ApplicationContext applicationContext;

  public Optional<TestReportGenerator> get(TestReportType name) {
    return findObject(name);
  }

  private Optional<TestReportGenerator> findObject(TestReportType key) {
    final var objects = applicationContext.getBeansOfType(TestReportGenerator.class);
    if (CollectionUtils.isEmpty(objects)) {
      return Optional.empty();
    }
    return objects.values()
        .stream()
        .filter(testReportGenerator -> testReportGenerator
            .reportType()
            .equals(key))
        .findFirst();
  }
}
