package ru.vtb.tsp.ia.epay.multicard.exceptions;

import java.time.LocalDateTime;
import lombok.Getter;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.ErrorSystem;

public class AdapterException extends RuntimeException {

  @Getter
  private final LocalDateTime timestamp = LocalDateTime.now();
  @Getter
  protected ErrorSystem errorSource;

  public AdapterException() {
    super();
  }

  public AdapterException(String message) {
    super(message);
  }

  public AdapterException(String message, Throwable cause) {
    super(message, cause);
  }

  public AdapterException(Throwable cause) {
    super(cause);
  }
}
