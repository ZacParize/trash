package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOrderStatus;

/**
 * Adapter for OrderStatus field on result 3ds auth.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.08.2021
 */
public class VerificationOrderStatusesAdapter extends XmlAdapter<String, MulticardOrderStatus> {

  @Override
  public MulticardOrderStatus unmarshal(String v) {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return MulticardOrderStatus.valueOf(v);
  }

  @Override
  public String marshal(MulticardOrderStatus v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return v.name();
  }
}
