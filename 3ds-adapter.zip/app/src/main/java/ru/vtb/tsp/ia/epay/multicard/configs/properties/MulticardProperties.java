package ru.vtb.tsp.ia.epay.multicard.configs.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties("rests.multicard")
public class MulticardProperties {

  private String ipspId;
  private String baseUrl;
  private Integer timeout;
  private Boolean sslEnabled;
  private Boolean showRequest;
  private Boolean showResponse;
  private Ssl ssl;
  private MulticardEndpoints endpoints;

}