package ru.vtb.tsp.ia.epay.multicard.services.transactions;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

@Slf4j
@Service
public class TransactionProducer {

  private final KafkaTemplate<String, Object> kafkaTemplate;
  private final List<String> producerTopics;

  public TransactionProducer(KafkaTemplate<String, Object> kafkaTemplate,
      @Value("${kafka.producer.topics}") @NotEmpty List<String> producerTopics) {
    this.kafkaTemplate = kafkaTemplate;
    this.producerTopics = producerTopics;
  }

  @Transactional
  public void handleMessage(@Nullable Message<TransactionPayload> message) {
    Optional.ofNullable(message)
        .ifPresent(msg -> {
          final var headers = new HashMap<>(msg.getHeaders());
          headers.put(KafkaHeaders.MESSAGE_KEY, msg.getPayload().getTransactionId());

          producerTopics.forEach(topic -> {
            headers.remove(KafkaHeaders.TOPIC);
            headers.put(KafkaHeaders.TOPIC, topic);
            kafkaTemplate.send(new GenericMessage<>(msg.getPayload(), headers))
                .addCallback(new ListenableFutureCallback<>() {
                  @Override
                  public void onSuccess(@NotNull SendResult<String, Object> result) {
                    log.info("Next route point of transaction {} is {}",
                        msg.getPayload().getTransactionId(),
                        msg.getPayload().getRoute());
                  }

                  @Override
                  public void onFailure(Throwable ex) {
                    log.error("Error during sending transaction {} to the next route point {}",
                        msg.getPayload().getTransactionId(),
                        msg.getPayload().getRoute(), ex);
                  }
                });
          });
        });
  }
}