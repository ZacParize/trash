package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;

/**
 * Gateways.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.09.2021
 */
public enum Adapter {

  TEST,
  MULTICARD;

  public static Optional<Adapter> findByName(String name) {
    for (var val : Adapter.values()) {
      if (val.name().equalsIgnoreCase(name)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
