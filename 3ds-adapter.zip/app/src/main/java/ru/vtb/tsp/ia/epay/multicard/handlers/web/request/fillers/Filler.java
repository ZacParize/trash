package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData;
import ru.vtb.tsp.ia.epay.core.utils.CardAdditionalUtils;
import ru.vtb.tsp.ia.epay.core.utils.PayloadUtils;

@FunctionalInterface
public interface Filler<S, D> {

  Optional<D> fill(S src, D dest);

  default Threeds getThreeds(TransactionPayload payload) {
    Optional<Threeds> threeds = CardAdditionalUtils.getThreeds(payload);
    return threeds.orElseGet(() -> createNewThreeds(payload));
  }

  private Threeds createNewThreeds(TransactionPayload payload) {
    final var newThreeds = new Threeds();
    newThreeds.setThreeDSData(new ThreeDSData());
    final var data = newThreeds.getThreeDSData();
    data.setMerchantId(payload.getMerchant().getMstId());
    PayloadUtils.getCard(payload).ifPresent(card -> card.setAdditionalData(newThreeds));
    return newThreeds;
  }
}
