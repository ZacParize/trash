package ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.cres.request;

import java.util.Date;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardOperationAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.MulticardStepsAdapter;
import ru.vtb.tsp.ia.epay.multicard.components.adapters.YearsAndMonthsAdapter;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardOperation;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;

/**
 * Request.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@XmlAccessorType(XmlAccessType.FIELD)
public class Request {

  @XmlElement(name = "Operation")
  @XmlJavaTypeAdapter(MulticardOperationAdapter.class)
  private MulticardOperation operation;
  @XmlElement(name = "Step")
  @XmlJavaTypeAdapter(MulticardStepsAdapter.class)
  private MulticardProcess3DSAuthStep step;
  @XmlElement(name = "Order")
  private Order order;
  @XmlElement(name = "SessionID")
  private String sessionId;
  @XmlElement(name = "PAN")
  private String pan;
  @XmlElement(name = "ExpDate")
  @XmlJavaTypeAdapter(YearsAndMonthsAdapter.class)
  private Date date;
  @XmlElement(name = "CardUID")
  private String cardUid;
  @XmlElement(name = "EncryptedPayload")
  private Object encryptedPayload;
  @XmlElement(name = "CRes")
  private String cres;
}
