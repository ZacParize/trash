package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Optional;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;
import ru.vtb.tsp.ia.epay.multicard.services.RedisCache;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.04.2022
 */
@Service
@Profile("redisMock")
public class RedisCacheMock implements RedisCache {

  @Override
  public Optional<CardCacheDto> getCardData(String key) {
    return Optional.of(
        CardCacheDto.builder().pan("1234567890123456").cvv("222").dpan("1234XXXXXXXXX3456")
            .build());
  }
}
