package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.multicard.process3ds.auth.areq;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.MulticardProcess3DSAreqRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.Request;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.Filler;

@Slf4j
@Component
@RequiredArgsConstructor
public class TransactionPayloadToMulticardProcess3DSAreqRequestFiller implements
    Filler<TransactionPayload, MulticardProcess3DSAreqRequest> {

  @Lazy
  private final DataFiller filler;

  @Override
  public Optional<MulticardProcess3DSAreqRequest> fill(TransactionPayload src,
      MulticardProcess3DSAreqRequest dest) {
    if (Objects.isNull(dest.getRequest())) {
      dest.setRequest(new Request());
    }
    dest.setTransactionId(src.getTransactionId());
    filler.fill(src, dest.getRequest());
    return Optional.of(dest);
  }
}
