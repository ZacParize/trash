package ru.vtb.tsp.ia.epay.multicard.handlers.kafka.gateway;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.Adapter;
import ru.vtb.tsp.ia.epay.multicard.services.RouterService;
import ru.vtb.tsp.ia.epay.multicard.services.TDSService;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 08.09.2021
 */
@Component
@RequiredArgsConstructor
public class KafkaMulticardAdapterMessageHandler implements AdapterHandler {

  private final TDSService multicardTDSService;
  private final RouterService service;

  @Override
  public Optional<TransactionPayload> handle(TransactionPayload src) {
    return service.route(src, multicardTDSService);
  }

  @Override
  public Adapter supportedGateway() {
    return Adapter.MULTICARD;
  }
}
