package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.audit;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardProcess3DSAuthStep;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 04.05.2022
 */
@Component
public class MulticardProcess3DSAreqResponseToAuditResponseData extends
    AFiller<MulticardProcess3DSAreqResponse, AuditResponseData> {

  @Override
  public Optional<AuditResponseData> fill(MulticardProcess3DSAreqResponse src,
      AuditResponseData dest) {
    dest.setAcsUrl(false);
    Optional.ofNullable(src)
        .map(root -> {
          dest.setTransactionId(root.getTransactionId());
          return root;
        })
        .map(MulticardProcess3DSAreqResponse::getResponse)
        .map(response -> {
          Optional.ofNullable(response.getStatus())
              .map(MulticardStatus::getStatusCode)
              .ifPresent(dest::setStatus);
          Optional.ofNullable(response.getNextStep())
              .map(MulticardProcess3DSAuthStep::getStep)
              .ifPresent(dest::setNextStep);
          return response;
        })
        .map(response -> {
          Optional.ofNullable(response.getRefinement())
              .ifPresent(refinement -> dest.setAcsUrl(
                  StringUtils.isNotEmpty(refinement.getAcsURL()))
              );
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          dest.setOrderId(message.getOrderID());
          dest.setOrderStatus(
              Optional.ofNullable(message.getOrderStatus()).map(Enum::name).orElse(null));
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .ifPresent(answerVars -> {
          dest.setThreeDSVersion(answerVars.getThreeDSVersion());
          dest.setThreeDSVerification(answerVars.getThreeDSVerification());
        });
    return Optional.of(dest);
  }
}
