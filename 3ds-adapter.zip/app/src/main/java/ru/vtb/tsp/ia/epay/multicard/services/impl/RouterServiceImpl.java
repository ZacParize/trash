package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Optional;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData;
import ru.vtb.tsp.ia.epay.core.utils.CardAdditionalUtils;
import ru.vtb.tsp.ia.epay.multicard.services.RouterService;
import ru.vtb.tsp.ia.epay.multicard.services.TDSService;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.10.2021
 */
@Service
public class RouterServiceImpl implements RouterService {

  @Override
  public Optional<TransactionPayload> route(TransactionPayload src, TDSService destService) {
    if (CardAdditionalUtils.getThreeds(src).isEmpty()) {
      final var threeds = new Threeds();
      threeds.setThreeDSData(new ThreeDSData());
      ((Card) src.getPaymentData()).setAdditionalData(threeds);
    }
    var operation = CardAdditionalUtils.getThreeds(src)
        .map(Threeds::getThreeDSData)
        .map(ThreeDSData::getOperation);

    if (operation.isEmpty()) {
      return destService.createOrder(src)
          .map(destService::first)
          .isPresent() ? Optional.of(src) : Optional.empty();
    }
    switch (operation.get()) {
      case PARES: {
        return destService.pares(src)
            .isPresent() ? Optional.of(src) : Optional.empty();
      }
      case AREQ: {
        return destService.areq(src)
            .isPresent() ? Optional.of(src) : Optional.empty();
      }
      case CRES: {
        return destService.cres(src)
            .isPresent() ? Optional.of(src) : Optional.empty();
      }
      default:
        return Optional.empty();
    }
  }
}
