package ru.vtb.tsp.ia.epay.multicard.components.converters.amount;

import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;

public interface AmountConverter {

  String convert(Amount source);

}
