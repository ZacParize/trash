package ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web;

/**
 * Выбрасывается, не удалось создать экземпляр обработчика.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
public class WHFWebHandlerInstanceNotCreatedException extends Exception {

}
