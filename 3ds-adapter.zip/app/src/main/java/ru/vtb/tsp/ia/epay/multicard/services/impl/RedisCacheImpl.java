package ru.vtb.tsp.ia.epay.multicard.services.impl;

import java.util.Objects;
import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;
import ru.vtb.tsp.ia.epay.multicard.services.RedisCache;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.12.2021
 */
@Service
@Slf4j
@Profile("!redisMock")
public class RedisCacheImpl implements RedisCache {

  private final ValueOperations<String, Object> valOps;

  public RedisCacheImpl(RedisTemplate<String, Object> redisTemplate) {
    this.valOps = redisTemplate.opsForValue();
  }

  @Override
  public Optional<CardCacheDto> getCardData(String key) {
    final var cache = valOps.get(key);
    log.info("Redis cache for key {} [isNonNull: {}]", key, Objects.nonNull(cache));
    if (Objects.nonNull(cache)) {
      return Optional.of((CardCacheDto) cache);
    }
    return Optional.empty();
  }
}
