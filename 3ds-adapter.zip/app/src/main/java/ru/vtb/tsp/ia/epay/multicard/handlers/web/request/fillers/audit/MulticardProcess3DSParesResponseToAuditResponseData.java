package ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.audit;

import java.util.Optional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Message;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.MulticardProcess3DSParesResponse;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Response;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.Result;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.ThreeDSVars;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.pares.response.XmlOut;
import ru.vtb.tsp.ia.epay.multicard.domain.enums.MulticardStatus;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.AFiller;


@Component
public class MulticardProcess3DSParesResponseToAuditResponseData extends
    AFiller<MulticardProcess3DSParesResponse, AuditResponseData> {

  @Override
  public Optional<AuditResponseData> fill(MulticardProcess3DSParesResponse src,
      AuditResponseData dest) {
    dest.setAcsUrl(false);
    Optional.ofNullable(src)
        .map(root -> {
          dest.setTransactionId(root.getTransactionId());
          return root;
        })
        .map(MulticardProcess3DSParesResponse::getResponse)
        .map(response -> {
          Optional.ofNullable(response.getStatus())
              .map(MulticardStatus::getStatusCode)
              .ifPresent(dest::setStatus);
          return response;
        })
        .map(Response::getResult)
        .map(Result::getXmlOut)
        .map(XmlOut::getMessage)
        .map(message -> {
          dest.setOrderId(message.getOrderID());
          dest.setOrderStatus(
              Optional.ofNullable(message.getOrderStatus()).map(Enum::name).orElse(null));
          return message;
        })
        .map(Message::getThreeDSVars)
        .map(ThreeDSVars::getAnswerVars)
        .ifPresent(answerVars -> {
          dest.setThreeDSVersion(answerVars.getThreeDSVersion());
          dest.setThreeDSVerification(answerVars.getThreeDSVerification());
        });
    return Optional.of(dest);
  }
}
