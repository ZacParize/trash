package ru.vtb.tsp.ia.epay.multicard.handlers.web.impl;

import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.fromStringToXml;
import static ru.vtb.tsp.ia.epay.multicard.utils.XmlConverterUtil.toXmlString;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.multicard.configs.properties.MulticardProperties;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.audit.AuditResponseData;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.request.MulticardProcess3DSAreqRequest;
import ru.vtb.tsp.ia.epay.multicard.domain.dto.web.multicard.process3ds.auth.areq.response.MulticardProcess3DSAreqResponse;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.AbstractWebHandler;
import ru.vtb.tsp.ia.epay.multicard.handlers.web.request.fillers.DataFiller;
import ru.vtb.tsp.ia.epay.multicard.services.impl.AuditService;

/**
 * Обработчик запросов регистрации заказа в мультикарте.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
@Slf4j
@RequiredArgsConstructor
@Component
public class MulticardProcess3DSAuthAreqHandler extends
    AbstractWebHandler<MulticardProcess3DSAreqRequest, MulticardProcess3DSAreqResponse> {

  private final MulticardProperties properties;
  private final RestTemplate restTemplate;
  private final DataFiller filler;
  private final AuditService auditService;

  @Override
  @AuditProcess("TSPACQ_BOX_MK_AUTH_AREQ_REQUEST")
  public Optional<MulticardProcess3DSAreqResponse> handle(MulticardProcess3DSAreqRequest data) {
    try {
      Optional<String> optData = toXmlString(data, MulticardProcess3DSAreqRequest.class);
      if (optData.isEmpty()) {
        return Optional.empty();
      }
      final var entity = new HttpEntity<>(optData.get(), basicMulticardHeader());
      final var result = restTemplate.exchange(
          properties.getBaseUrl() + properties.getEndpoints().getProcess3DSAuthAreq(),
          HttpMethod.POST,
          entity,
          String.class
      );
      MulticardProcess3DSAreqResponse body;
      if (Objects.isNull(result.getBody())) {
        body = new MulticardProcess3DSAreqResponse();
      } else {
        Optional<MulticardProcess3DSAreqResponse> response = fromStringToXml(
            result.getBody(), MulticardProcess3DSAreqResponse.class);
        body = response.isEmpty() ? new MulticardProcess3DSAreqResponse() : response.get();
      }
      return Optional.of(body);
    } catch (HttpClientErrorException e) {
      log.error("Connection error", e);
      throw e;
    }
  }

  @Override
  public void confirm(MulticardProcess3DSAreqResponse response) {
    super.confirm(response);
    filler.fill(response, AuditResponseData.builder().build())
        .ifPresent(auditService::authAreqResponse);
  }
}
