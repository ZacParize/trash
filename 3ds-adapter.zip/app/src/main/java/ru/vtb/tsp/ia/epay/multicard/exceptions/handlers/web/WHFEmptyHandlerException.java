package ru.vtb.tsp.ia.epay.multicard.exceptions.handlers.web;

/**
 * Исключение выбрасываемое в случае если не указан тип запроса в запросе обработчика.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.08.2021
 */
public class WHFEmptyHandlerException extends Exception {

}
