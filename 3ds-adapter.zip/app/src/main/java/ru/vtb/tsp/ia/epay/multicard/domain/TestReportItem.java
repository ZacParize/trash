package ru.vtb.tsp.ia.epay.multicard.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Результат теста интеграции.
 *
 * @author Rustam Valiev RValiev@innotechnum.com
 * @since 22.03.2021
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TestReportItem {

  private String integration;
  private String correctAnswerRegexp;
  private String answer;
  private Boolean result;
  private Long time;

}
