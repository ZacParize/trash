package ru.vtb.tsp.ia.epay.multicard.services;

import java.util.Map;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.multicard.handlers.kafka.KafkaMessageHandler;
import ru.vtb.tsp.ia.epay.multicard.services.transactions.TransactionProducer;

@Slf4j
@Service
public class ProcessorService implements GenericTransformer<Object, TransactionPayload> {

  private final TransactionProducer transactionProducer;
  private final MessageAdapter messageAdapter;
  private final KafkaMessageHandler messageHandler;
  private final String applicationName;

  public ProcessorService(
      TransactionProducer transactionProducer,
      MessageAdapter messageAdapter,
      KafkaMessageHandler messageHandler,
      @Value("${spring.application.name}") String applicationName) {
    this.transactionProducer = transactionProducer;
    this.messageAdapter = messageAdapter;
    this.messageHandler = messageHandler;
    this.applicationName = applicationName;
  }

  @Override
  public @Nullable
  TransactionPayload transform(@Nullable Object source) {
    return messageAdapter.deserialize(source);
  }

  //    @DependsOn("initializerService")
  //    @Transactional(transactionManager = "kafkaTransactionManager")
  @KafkaListener(topics = "${kafka.consumer.topics}",
      containerFactory = "kafkaListenerContainerFactory")
  public void process(@NotNull ConsumerRecord<String, ?> record,
      @Headers Map<String, Object> headers,
      @NotNull Acknowledgment acknowledgment) {
    final var transaction = transform(record.value());
    try {
      Optional.ofNullable(transaction)
          .map(tx -> {
            tx.getRoute().addVisitedService(applicationName);
            return tx;
          })
          .flatMap(tx -> {
            if (!tx.isCompleted()) {
              return messageHandler.handle(tx);
            } else {
              return Optional.of(tx);
            }
          })
          .ifPresent(tp -> transactionProducer.handleMessage(new GenericMessage<>(tp, headers)));
    } catch (Exception ex) {
      log.error("Transaction can't be processed", ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}