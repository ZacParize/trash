package ru.vtb.tsp.ia.epay.multicard.configs.properties;

import lombok.Data;

/**
 * Конфиг SSL.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 16.08.2021
 */
@Data
public class Ssl {

  private String protocol;
  private String truststorePath;
  private String truststorePass;
  private String truststoreType;
  private String keystorePath;
  private String keystorePass;
  private String keystoreType;
  private String keyPass;
  private Boolean clientAuth;
  private Boolean certValidation;

}
