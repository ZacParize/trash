package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ErrorSystem {

  THREEDS_ADAPTER("ru.vtb.tsp.ia.epay.multicard.exceptions.adapter."),
  MULTICARD("ru.vtb.tsp.ia.epay.multicard.exceptions.multicard.");

  private final String pkg;

}
