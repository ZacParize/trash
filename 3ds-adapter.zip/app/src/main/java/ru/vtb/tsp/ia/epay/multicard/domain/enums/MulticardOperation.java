package ru.vtb.tsp.ia.epay.multicard.domain.enums;

import java.util.Optional;
import lombok.Getter;

/**
 * Операции мультикарты.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 17.08.2021
 */
@Getter
public enum MulticardOperation {

  CREATE_ORDER("CreateOrder"),
  PROCESS_3DS_AUTH("Process3DSAuth");

  private final String operation;

  MulticardOperation(String operation) {
    this.operation = operation;
  }

  public static Optional<MulticardOperation> findByOperation(String operation) {
    for (var val : MulticardOperation.values()) {
      if (val.getOperation().equals(operation)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
