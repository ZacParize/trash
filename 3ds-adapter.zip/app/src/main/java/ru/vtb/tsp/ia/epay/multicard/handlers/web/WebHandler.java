package ru.vtb.tsp.ia.epay.multicard.handlers.web;

import ru.vtb.tsp.ia.epay.multicard.handlers.Handler;

/**
 * Обработчик REST запросов веб-клиента.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 10.08.2021
 */
public interface WebHandler<S, R> extends Handler<S, R> {

  void confirm(R response);
}
