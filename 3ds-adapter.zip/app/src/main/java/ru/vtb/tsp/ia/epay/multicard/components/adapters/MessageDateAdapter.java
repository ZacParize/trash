package ru.vtb.tsp.ia.epay.multicard.components.adapters;

import java.text.ParseException;
import java.util.Date;
import java.util.Objects;
import javax.xml.bind.annotation.adapters.XmlAdapter;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

/**
 * Adapter for fill date (YYMM) in Multicard XML.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 18.08.2021
 */
public class MessageDateAdapter extends XmlAdapter<String, Date> {

  @Override
  public Date unmarshal(String v) throws ParseException {
    if (StringUtils.isEmpty(v)) {
      return null;
    }
    return DateUtils.parseDate(v, "dd/MM/yyyy HH:mm:ss");
  }

  @Override
  public String marshal(Date v) {
    if (Objects.isNull(v)) {
      return null;
    }
    return DateFormatUtils.format(v, "dd/MM/yyyy HH:mm:ss");
  }
}
