package ru.vtb.tsp.ia.epay.sbpadapter.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import lombok.SneakyThrows;
import org.jetbrains.annotations.NotNull;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.postgresql.PGNotification;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import ru.vtb.tsp.ia.epay.core.configurations.ObjectMapperConfiguration;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionInfoRepository;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionRepository;
import ru.vtb.tsp.ia.epay.core.services.PgNotificationService;
import ru.vtb.tsp.ia.epay.core.services.TransactionInfoService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpQrNotificationDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpPaymentStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmCode;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRegisterRefundRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.banks.SbpBanksListResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentDetailsResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.client.MockEpaAuthApiClient;
import ru.vtb.tsp.ia.epay.sbpadapter.services.client.MockSbpTykApiClient;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.EpaAuthApi;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories.QrInvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories.RefundInvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrActivationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrDeactivationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.ImageQrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.PaymentStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.QrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundConfirmationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundRegistrationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.SbpInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.SbpTykInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.AbstractResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.ConfirmRefundResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.PaymentStatusResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.QrResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.RefundStatusResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.RegisterRefundResponseParser;

@ExtendWith(MockitoExtension.class)
class InvocationFactoryTest {

  static final String AGENT_ID = "agent_id";

  static final String MEMBER_ID = "member_id";

  static final ObjectMapper OBJECT_MAPPER = new ObjectMapperConfiguration().objectMapper();

  static final SbpQrCodeResponseDto SBP_QR_CODE_RESPONSE_DTO;

  static final SbpRegisterRefundResponseDto SBP_REGISTER_REFUND_RESPONSE_DTO;

  static final SbpConfirmRefundResponseDto SBP_CONFIRM_REFUND_RESPONSE_DTO;

  static final SbpRefundStatusResponseDto SBP_REFUND_STATUS_RESPONSE_DTO;

  static final SbpPaymentStatusResponseDto SBP_PAYMENT_STATUS_RESPONSE_DTO;

  static final SbpApi SBP_API = new SbpApi() {

    @Override
    public ResponseEntity<List<SbpBanksListResponseDto>> getBanks(
        HttpHeaders httpHeaders) {
      return null;
    }

    @Override
    @SneakyThrows
    public ResponseEntity<SbpQrCodeResponseDto> createQr(HttpHeaders httpHeaders,
        SbpQrCodeCreationRequestDto body) {
      return ResponseEntity.ok(SBP_QR_CODE_RESPONSE_DTO);
    }

    @Override
    public ResponseEntity<SbpPaymentStatusResponseDto> getPaymentStatus(
        HttpHeaders httpHeaders, SbpPaymentStatusRequestDto body) {
      return ResponseEntity.ok(SBP_PAYMENT_STATUS_RESPONSE_DTO);
    }

    @Override
    public ResponseEntity<SbpRegisterRefundResponseDto> registerRefund(
        HttpHeaders httpHeaders, SbpRegisterRefundRequestDto body) {
      return ResponseEntity.ok(SBP_REGISTER_REFUND_RESPONSE_DTO);
    }

    @Override
    public ResponseEntity<SbpConfirmRefundResponseDto> confirmRefund(
        HttpHeaders httpHeaders, SbpRefundConfirmRequestDto body) {
      return ResponseEntity.ok(SBP_CONFIRM_REFUND_RESPONSE_DTO);
    }

    @Override
    public ResponseEntity<SbpRefundStatusResponseDto> getRefundStatus(
        HttpHeaders httpHeaders, SbpRefundStatusRequestDto body) {
      return ResponseEntity.ok(SBP_REFUND_STATUS_RESPONSE_DTO);
    }

    @Override
    public ResponseEntity<SbpPaymentDetailsResponseDto> getPaymentDetails(HttpHeaders httpHeaders,
        String qrcId) {
      return null;
    }


  };
  static final SbpTykApi SBP_TYK_API = new MockSbpTykApiClient();
  static final EpaAuthApi EPA_AUTH_API = new MockEpaAuthApiClient();
  static final EpaAuthService EPA_AUTH_SERVICE = new EpaAuthService(EPA_AUTH_API,
      UUID.randomUUID().toString(),
      UUID.randomUUID().toString(),
      UUID.randomUUID().toString());
  static final TransactionRepository TRANSACTION_REPOSITORY =
      Mockito.mock(TransactionRepository.class);
  static final TransactionInfoRepository TRANSACTION_INFO_REPOSITORY =
      Mockito.mock(TransactionInfoRepository.class);
  static final TransactionInfoService TRANSACTION_INFO_SERVICE =
      new TransactionInfoService(TRANSACTION_INFO_REPOSITORY);
  static final TransactionService TRANSACTION_SERVICE =
      new TransactionService(TRANSACTION_INFO_SERVICE, TRANSACTION_REPOSITORY);
  static final OrderServiceFacade ORDER_SERVICE = Mockito.mock(OrderServiceFacade.class);
  static InvocationFactory INVOCATION_FACTORY;

  static {
    try {
      SBP_QR_CODE_RESPONSE_DTO = OBJECT_MAPPER.readValue(
          InvocationFactoryTest.class.getClassLoader()
              .getResourceAsStream("files/responses/sbp-qr-code-response-1.json"),
          SbpQrCodeResponseDto.class);
      SBP_REGISTER_REFUND_RESPONSE_DTO = OBJECT_MAPPER.readValue(
          InvocationFactoryTest.class.getClassLoader()
              .getResourceAsStream("files/responses/sbp-create-refund-response-1.json"),
          SbpRegisterRefundResponseDto.class);
      SBP_CONFIRM_REFUND_RESPONSE_DTO = OBJECT_MAPPER.readValue(
          InvocationFactoryTest.class.getClassLoader()
              .getResourceAsStream("files/responses/sbp-confirm-refund-response-1.json"),
          SbpConfirmRefundResponseDto.class);
      SBP_REFUND_STATUS_RESPONSE_DTO = OBJECT_MAPPER.readValue(
          InvocationFactoryTest.class.getClassLoader()
              .getResourceAsStream("files/responses/sbp-refund-status-response-1.json"),
          SbpRefundStatusResponseDto.class);
      SBP_PAYMENT_STATUS_RESPONSE_DTO = OBJECT_MAPPER.readValue(
          InvocationFactoryTest.class.getClassLoader()
              .getResourceAsStream("files/responses/sbp-payment-status-response-1.json"),
          SbpPaymentStatusResponseDto.class);
    } catch (IOException e) {
      throw new IllegalArgumentException(e);
    }
  }

  static Stream<Arguments> provideEmpty() {
    return Stream.of(Arguments.of((Object) null), Arguments.of(new TransactionPayload()));
  }

  @SneakyThrows
  static Stream<Arguments> providePayments() {
    return Stream.of(Arguments.of(OBJECT_MAPPER.readValue(
        InvocationFactoryTest.class.getClassLoader()
            .getResourceAsStream("files/sbp-payment-1.json"),
        TransactionPayload.class)));
  }

  @SneakyThrows
  static Stream<Arguments> provideConfirmRefunds() {
    return Stream.of(Arguments.of(OBJECT_MAPPER.readValue(
        InvocationFactoryTest.class.getClassLoader().getResourceAsStream(
            "files/sbp-refund-1.json"),
        TransactionPayload.class)));
  }

  @SneakyThrows
  static Stream<Arguments> provideRegisterRefunds() {
    return Stream.of(Arguments.of(OBJECT_MAPPER.readValue(
        InvocationFactoryTest.class.getClassLoader().getResourceAsStream(
            "files/sbp-refund-2.json"),
        TransactionPayload.class)));
  }

  @SneakyThrows
  static Stream<Arguments> provideRefundStatus() {
    return Stream.of(Arguments.of(OBJECT_MAPPER.readValue(
        InvocationFactoryTest.class.getClassLoader().getResourceAsStream(
            "files/sbp-refund-status-1.json"),
        TransactionPayload.class)));
  }

  @SneakyThrows
  static Stream<Arguments> providePaymentStatus() {
    return Stream.of(Arguments.of(OBJECT_MAPPER.readValue(
        InvocationFactoryTest.class.getClassLoader().getResourceAsStream(
            "files/sbp-payment-status-1.json"),
        TransactionPayload.class)));
  }

  @BeforeEach
  void init() {
    final Map<String, SbpInvocation<?>> sbpInvocations = Map.of(QrCreationInvocation.BEAN_NAME,
        new QrCreationInvocation(SBP_API),
        RefundRegistrationInvocation.BEAN_NAME, new RefundRegistrationInvocation(SBP_API),
        RefundConfirmationInvocation.BEAN_NAME, new RefundConfirmationInvocation(SBP_API),
        RefundStatusInvocation.BEAN_NAME, new RefundStatusInvocation(SBP_API),
        PaymentStatusInvocation.BEAN_NAME, new PaymentStatusInvocation(SBP_API));
    final Map<String, SbpTykInvocation<?>> sbpTykInvocations = Map.of(
        CashQrCreationInvocation.BEAN_NAME, new CashQrCreationInvocation(SBP_TYK_API, EPA_AUTH_SERVICE),
        CashQrActivationInvocation.BEAN_NAME, new CashQrActivationInvocation(SBP_TYK_API, EPA_AUTH_SERVICE),
        CashQrDeactivationInvocation.BEAN_NAME, new CashQrDeactivationInvocation(SBP_TYK_API, EPA_AUTH_SERVICE),
        ImageQrCreationInvocation.BEAN_NAME, new ImageQrCreationInvocation(SBP_TYK_API, EPA_AUTH_SERVICE));
    final Map<String, AbstractResponseParser<?>> parsers = Map.of(QrResponseParser.BEAN_NAME,
        new QrResponseParser(TRANSACTION_SERVICE,
            new PgNotificationService<>(new JdbcTemplate() {
              public void execute(@NotNull String sql) throws DataAccessException {
              }
            }) {
              @Override
              public PGNotification receive(@Nullable String channel,
                  @Nullable Function<SbpQrNotificationDto, PGNotification> function) {
                return null;
              }
            }),
        ConfirmRefundResponseParser.BEAN_NAME,
        new ConfirmRefundResponseParser(TRANSACTION_SERVICE),
        PaymentStatusResponseParser.BEAN_NAME,
        new PaymentStatusResponseParser(TRANSACTION_SERVICE,
            ORDER_SERVICE),
        RefundStatusResponseParser.BEAN_NAME,
        new RefundStatusResponseParser(TRANSACTION_SERVICE,
            ORDER_SERVICE),
        RegisterRefundResponseParser.BEAN_NAME,
        new RegisterRefundResponseParser(TRANSACTION_SERVICE));
    INVOCATION_FACTORY = new InvocationFactory(
        new QrInvocationFactory(sbpInvocations, sbpTykInvocations, parsers, AGENT_ID, MEMBER_ID),
        new RefundInvocationFactory(sbpInvocations, parsers));
  }

  @DisplayName("Should pass null value")
  @ParameterizedTest
  @MethodSource("provideEmpty")
  void test_empty(TransactionPayload transactionPayload) {
    Assertions.assertFalse(INVOCATION_FACTORY.create(transactionPayload));
  }

  @DisplayName("Should pass qr creations")
  @ParameterizedTest
  @MethodSource("providePayments")
  @SuppressWarnings("ConstantConditions")
  void test_paymentSuccess(TransactionPayload transactionPayload) {
    assertTrue(INVOCATION_FACTORY.create(transactionPayload));
    assertNull(transactionPayload.getError());
    assertNotNull(transactionPayload.getOrderInfo().getMstOrderId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getQrcId(),
        SBP_QR_CODE_RESPONSE_DTO.getData().getQrcId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getQrLink(),
        SBP_QR_CODE_RESPONSE_DTO.getData().getPayload());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getRequestId(),
        SBP_QR_CODE_RESPONSE_DTO.getRequestId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getStatus(),
        SBP_QR_CODE_RESPONSE_DTO.getData().getStatus());
  }

  @DisplayName("Should pass confirm refunds")
  @ParameterizedTest
  @MethodSource("provideConfirmRefunds")
  void test_confirmRefundSuccess(TransactionPayload transactionPayload) {
    assertTrue(INVOCATION_FACTORY.create(transactionPayload));
    assertNull(transactionPayload.getError());
    assertNotNull(transactionPayload.getOrderInfo().getMstOrderId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getMsgId(),
        SBP_CONFIRM_REFUND_RESPONSE_DTO.getMsgId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getPrtry(),
        SbpRefundConfirmCode.OK.name());
  }

  @DisplayName("Should pass create refunds")
  @ParameterizedTest
  @MethodSource("provideRegisterRefunds")
  void test_createRefundSuccess(TransactionPayload transactionPayload) {
    assertTrue(INVOCATION_FACTORY.create(transactionPayload));
    //assertTrue((Integer) transactionPayload.getContext().get(APPLICATION_NAME) > 0);
    assertNull(transactionPayload.getError());
    assertNotNull(transactionPayload.getOrderInfo().getMstOrderId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getMsgId(),
        SBP_REGISTER_REFUND_RESPONSE_DTO.getMsgId());
  }

  @SneakyThrows
  @DisplayName("Should pass refund statuses")
  @ParameterizedTest
  @MethodSource("provideRefundStatus")
  void test_refundStatusSuccess(TransactionPayload transactionPayload) {
    final var currency = Currency.builder().code(transactionPayload.getAmount().getCurrency())
        .build();
    final var order = Order.builder()
        .state(OrderState.PAID)
        .currency(currency)
        .amount(transactionPayload.getAmount().getValue())
        .build();
    final var transaction = Transaction.builder()
        .transactionId(transactionPayload.getTransactionId())
        .state(transactionPayload.getStatus())
        .currency(currency)
        .amount(transactionPayload.getAmount().getValue())
        .order(order)
        .data(transactionPayload)
        .build();
    final var optTransaction = Optional.of(transaction);
    when(TRANSACTION_REPOSITORY.findById(anyString())).thenReturn(optTransaction);
    assertTrue(INVOCATION_FACTORY.create(transactionPayload));
    assertNull(transactionPayload.getError());
    assertNotNull(transactionPayload.getOrderInfo().getMstOrderId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getMsgId(),
        SBP_REFUND_STATUS_RESPONSE_DTO.getMsgId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getStatus(),
        SBP_REFUND_STATUS_RESPONSE_DTO.getTxSts());
    assertEquals(transactionPayload.getStatus(), TransactionState.RECONCILED);
  }

  @DisplayName("Should pass payment statuses")
  @ParameterizedTest
  @MethodSource("providePaymentStatus")
  void test_paymentStatusSuccess(TransactionPayload transactionPayload) {
    final var currency = Currency.builder().code(transactionPayload.getAmount().getCurrency())
        .build();
    final var order = Order.builder()
        .state(OrderState.PAID)
        .currency(currency)
        .amount(transactionPayload.getAmount().getValue())
        .build();
    final var transaction = Transaction.builder()
        .transactionId(transactionPayload.getTransactionId())
        .state(transactionPayload.getStatus())
        .currency(currency)
        .amount(transactionPayload.getAmount().getValue())
        .order(order)
        .data(transactionPayload)
        .build();
    final var optTransaction = Optional.of(transaction);
    when(TRANSACTION_REPOSITORY.findById(anyString())).thenReturn(optTransaction);
    assertTrue(INVOCATION_FACTORY.create(transactionPayload));
    //assertTrue((Integer) transactionPayload.getContext().get(APPLICATION_NAME) > 0);
    assertNull(transactionPayload.getError());
    assertNotNull(transactionPayload.getOrderInfo().getMstOrderId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getQrcId(),
        SBP_PAYMENT_STATUS_RESPONSE_DTO.getQrcId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getOperationId(),
        SBP_PAYMENT_STATUS_RESPONSE_DTO.getOperationId());
    assertEquals(((Sbp) transactionPayload.getPaymentData()).getStatus(),
        SBP_PAYMENT_STATUS_RESPONSE_DTO.getQState());
    assertEquals(transactionPayload.getStatus(), TransactionState.RECONCILED);
  }
}