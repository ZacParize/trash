package ru.vtb.tsp.ia.epay.sbpadapter.containers;

import lombok.extern.slf4j.Slf4j;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.utility.DockerImageName;

@Slf4j
public class PostgresqlContainer extends PostgreSQLContainer<PostgresqlContainer> {

    private static final String IMAGE_VERSION = "nexus-ci.corp.dev.vtb/efcp-docker-lib/testcontainers/postgres:latest";
    private static final String IMAGE_TYPE = "postgres";
    private static PostgresqlContainer container;

    private PostgresqlContainer() {
        super(DockerImageName.parse(IMAGE_VERSION).asCompatibleSubstituteFor(IMAGE_TYPE));
    }

    public static PostgresqlContainer getInstance() {
        if (container == null) {
            container = new PostgresqlContainer().withInitScript("db/init.sql");
        }
        return container;
    }

    @Override
    public void start() {
        super.start();
        String url = container.getJdbcUrl() + "&stringtype=unspecified";
        System.setProperty("spring.datasource.url", url);
        System.setProperty("spring.datasource.username", container.getUsername());
        System.setProperty("spring.datasource.password", container.getPassword());
        log.info("Postgres in docker started: url = {}", url);
    }

    @Override
    public void stop() {
        //do nothing, JVM handles shut down
    }
}