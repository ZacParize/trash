package ru.vtb.tsp.ia.epay.sbpadapter.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table(QrCodeStatic.TABLE_NAME)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class QrCodeStatic {

  public static final String TABLE_NAME = "qr_code_static";

  @Id
  @Column("id")
  private Long id;

  @NotEmpty
  @Column("qrc_id")
  private String qrcId;

  @NotEmpty
  private String payload;

  @NotEmpty
  @Column("q_state")
  private String qState;

  @NotEmpty
  @Column("q_reason")
  private String qReason;

  @NotEmpty
  @Column("q_code")
  private String qCode;

  @NotEmpty
  @Column("order_id")
  private String orderId;

  @NotEmpty
  @Column("request_id")
  private String requestId;

  @NotEmpty
  @Column("legal_id")
  private String legalId;

  @NotEmpty
  private String account;

  @NotEmpty
  private String currency;

  @NotEmpty
  private String purpose;

  @NotEmpty
  @Column("created_at")
  private LocalDateTime createdAt;

  @NotEmpty
  @Column("merchant_id")
  private String merchantId;

  @NotNull
  private BigDecimal amount;

}