package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@ConditionalOnProperty(name = "app.sbp.native.mock", havingValue = "false")
@FeignClient(name = "sbpApiClient", url = "${app.sbp.native.url}", decode404 = true)
public interface SbpApiClient extends SbpApi {

}