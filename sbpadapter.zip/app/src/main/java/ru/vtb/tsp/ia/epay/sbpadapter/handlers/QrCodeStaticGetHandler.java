package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeGetRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;
import ru.vtb.tsp.ia.epay.sbpadapter.repositories.QrCodeStaticRepository;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Component(QrCodeStaticGetHandler.BEAN_NAME)
public class QrCodeStaticGetHandler extends AbstractEventHandler<SbpQrCodeResponseDto> {

  public static final String BEAN_NAME = Constants.STATIC_QR_GET;
  private final QrCodeStaticRepository qrCodeStaticRepository;

  public QrCodeStaticGetHandler(
      KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper,
      QrCodeStaticRepository qrCodeStaticRepository) {
    super(kafkaService, transactionService, orderService, merchantSiteService, objectMapper);
    this.qrCodeStaticRepository = qrCodeStaticRepository;
  }

  @Override
  @Transactional
  public SbpQrCodeResponseDto apply(Event event) {
    return Optional.ofNullable(event)
        .map(e -> {
          final var request = objectMapper
              .convertValue(e.getPayload(), new TypeReference<SbpQrCodeGetRequestDto>(){});
          e.setPayload(request);
          final var timeMark = LocalDateTime.now(ZoneOffset.UTC);
          final var response = qrCodeStaticRepository.findByQrcId(request.getQrcId())
              .map(qrCodeStatic -> SbpQrCodeResponseDto.builder()
                  .code(qrCodeStatic.getQCode())
                  .requestId(qrCodeStatic.getRequestId())
                  .orderId(qrCodeStatic.getOrderId())
                  .message(qrCodeStatic.getQReason())
                  .data(SbpQrCodeResponseDto.Content.builder()
                      .payload(qrCodeStatic.getPayload())
                      .qrcId(qrCodeStatic.getQrcId())
                      .status(Qstate.valueOf(qrCodeStatic.getQState()))
                      .build())
                  .build())
              .orElse(SbpQrCodeResponseDto.builder().build());
            final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
                    .mstId(e.getMstId())
                    .code(e.getCode())
                    .type(EventType.STATIC_QR_GET)
                    .sentAt(timeMark)
                    .destination(Collections.singletonList(EventAddress.STATIC_QR_GET))
                    .build())
                .payload(response)
                .build();
            kafkaService.sendToGateway(callback);
            return response;
        })
        .orElse(SbpQrCodeResponseDto.builder().build());
  }
}