package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.RegisterRefundResponseParser.BEAN_NAME;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.SuccessCode;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;

@Slf4j
@Component(BEAN_NAME)
public class RegisterRefundResponseParser extends AbstractResponseParser<SbpRegisterRefundResponseDto> {

  public static final String BEAN_NAME = "registerRefundResponseParser";

  public RegisterRefundResponseParser(TransactionService transactionService) {
    super(transactionService);
  }

  @Override
  @AuditProcess("TSPACQ_BOX_SBP_REFUND_RESPONSE")
  public void accept(@Nullable SbpRegisterRefundResponseDto response,
                     @Nullable TransactionPayload transaction) {
    if (Objects.isNull(response) || Objects.isNull(transaction) ||
        transaction.isCompleted()) {
      return;
    }
    final var sbpTransaction = (Sbp) transaction.getPaymentData();
    sbpTransaction.setMsgId(response.getMsgId());
    MDC.put(MDCKeySupplier.UNIQUE_KEY, transaction.getOrderInfo().getOrderId());
    transactionService.upsertInfo(transaction.getTransactionId(),
                                  TransactionInfoKey.SBP_MSG_ID,
                                  response.getMsgId(),
                                  LocalDateTime.now(ZoneOffset.UTC));
    Optional.ofNullable(response.getErrCode())
        .filter(err -> !ObjectUtils.isEmpty(err) && SuccessCode.findByName(err).isEmpty())
        .ifPresentOrElse(
          errCode -> {
            transaction.setError(TransactionError.builder()
                .id(ApplicationException.PAYMENT_DECLINED_ERROR.getId())
                .httpCode(ApplicationException.PAYMENT_DECLINED_ERROR.getHttpCode())
                .message(ApplicationException.PAYMENT_DECLINED_ERROR.getMessage())
                .description(ApplicationException.PAYMENT_DECLINED_ERROR.getDescription())
                .traceId(transaction.getTransactionCode())
                .build());
            transaction.setStatus(TransactionState.DECLINED);
            transactionService.updateDataById(transaction.getTransactionId(), transaction);
            log.info("Refund registration for transaction id {} was declined with code {}",
                transaction.getTransactionId(), errCode);
          },
          () -> {
            transactionService.updateDataById(transaction.getTransactionId(), transaction);
            log.info("Refund registration for transaction id {} was successfully processed",
                transaction.getTransactionId());
          });
  }

}