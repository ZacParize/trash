package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundRegistrationInvocation.BEAN_NAME;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRegisterRefundRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class RefundRegistrationInvocation implements
    SbpInvocation<RefundRegistrationInvocation.Param> {

  public static final String BEAN_NAME = "refundRegistrationInvocationBean";
  private final SbpApi sbpApi;

  @Override
  public ResponseEntity<SbpRegisterRefundResponseDto> invoke(
      @Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          log.info("Refund registration invocation params {}", parametersMap);
          try {
            final var requestEntity = SbpRegisterRefundRequestDto.builder()
                .legalId(Objects.requireNonNull(parametersMap.get(Param.LEGAL_ID)).toString())
                .account(Objects.requireNonNull(parametersMap.get(Param.ACCOUNT)).toString())
                .merchantId(Objects.requireNonNull(parametersMap.get(Param.MERCHANT_ID)).toString())
                .intrBkSttlmAmt(
                    Objects.requireNonNull(parametersMap.get(Param.INTR_BK_STTLM_AMT)).toString())
                .txId(Objects.requireNonNull(parametersMap.get(Param.TX_ID)).toString())
                .cdtrAgt(null)
                .ustrd((String) parametersMap.get(Param.USTRD)).build();
            log.info("Refund registration invocation request {}", requestEntity);
            final var responseEntity =
                sbpApi.registerRefund(getDefaultHeaders(), requestEntity);
            log.info("Received refund registration invocation response {} of transaction id {}",
                responseEntity.getBody(), parametersMap.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during refund registration invocation {}", parametersMap, ex);
            throw new ServiceException(ApplicationException.PAYMENT_CREATION_ERROR);
          }
        }).orElse(null);
  }

  public enum Param {
    TRANSACTION_ID,
    MERCHANT_ID,
    LEGAL_ID,
    ACCOUNT,
    INTR_BK_STTLM_AMT,
    TX_ID,
    USTRD
  }

}