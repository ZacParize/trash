package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundConfirmationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundRegistrationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.SbpInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.AbstractResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.ConfirmRefundResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.RefundStatusResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.RegisterRefundResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.utils.MapperUtils;

@Slf4j
@Service
@RequiredArgsConstructor
public class RefundInvocationFactory {

  private final Map<String, SbpInvocation<?>> invocations;
  private final Map<String, AbstractResponseParser<?>> parsers;

  private @Nullable
  ResponseEntity<SbpRegisterRefundResponseDto> invokeRefundRegistration(
      @NotNull TransactionPayload transaction, @NotNull RefundRegistrationInvocation invocation) {
    try {
      return invocation.invoke(MapperUtils.mapRefundRegistration(transaction));
    } catch (Exception ex) {
      parsers.get(RegisterRefundResponseParser.BEAN_NAME).onError(transaction,
          ex instanceof ServiceException ? (ServiceException) ex
              : new ServiceException(ApplicationException.INTERNAL_ERROR));
      log.error("Refund registration request error, transaction id {} was declined",
          transaction.getTransactionId(), ex);
      return null;
    }
  }

  @Transactional
  public void createRegisterRefund(@NotNull TransactionPayload transaction) {
    log.info("Received refund registration request for transaction with id {}",
        transaction.getTransactionId());
    Optional.ofNullable(
            (RefundRegistrationInvocation) invocations.get(RefundRegistrationInvocation.BEAN_NAME))
        .map(invocation -> invokeRefundRegistration(transaction, invocation))
        .filter(response -> Objects.nonNull(response.getBody()))
        .ifPresent(response -> ((RegisterRefundResponseParser) parsers.get(
            RegisterRefundResponseParser.BEAN_NAME))
            .accept(response.getBody(), transaction));
  }

  private @Nullable ResponseEntity<SbpConfirmRefundResponseDto> invokeConfirmRefund(
      TransactionPayload transaction, RefundConfirmationInvocation invocation) {
    try {
      return invocation.invoke(MapperUtils.mapRefundConfirmation(transaction));
    } catch (Exception ex) {
      parsers.get(ConfirmRefundResponseParser.BEAN_NAME).onError(transaction,
          ex instanceof ServiceException ? (ServiceException) ex
              : new ServiceException(ApplicationException.INTERNAL_ERROR));
      log.error("Refund confirmation error, transaction id {} was declined",
          transaction.getTransactionId(), ex);
      return null;
    }
  }

  @Transactional
  public void createConfirmRefund(@NotNull TransactionPayload transaction) {
    log.info("Received refund confirmation request for transaction with id {}",
        transaction.getTransactionId());
    Optional.ofNullable(
            (RefundConfirmationInvocation) invocations.get(RefundConfirmationInvocation.BEAN_NAME))
        .map(invocation -> invokeConfirmRefund(transaction, invocation))
        .filter(response -> Objects.nonNull(response.getBody()))
        .ifPresent(response -> ((ConfirmRefundResponseParser) parsers.get(
            ConfirmRefundResponseParser.BEAN_NAME))
            .accept(response.getBody(), transaction));
  }

  @Transactional
  public void createRefundStatus(@NotNull TransactionPayload transaction) {
    log.info("Received refund status request for transaction with id {}",
        transaction.getTransactionId());
    Optional.ofNullable((RefundStatusInvocation) invocations.get(RefundStatusInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(MapperUtils.mapRefundStatus(transaction)))
        .filter(response -> Objects.nonNull(response.getBody()) && HttpStatus.OK.equals(
            response.getStatusCode()))
        .ifPresent(response -> ((RefundStatusResponseParser) parsers.get(
            RefundStatusResponseParser.BEAN_NAME))
            .accept(response.getBody(), transaction));
  }
}