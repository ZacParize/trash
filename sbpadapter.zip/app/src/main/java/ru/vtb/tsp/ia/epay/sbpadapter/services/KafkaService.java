package ru.vtb.tsp.ia.epay.sbpadapter.services;

import static ru.vtb.tsp.ia.epay.sbpadapter.configs.KafkaProducerConfig.KAFKA_BOX_TEMPLATE;
import static ru.vtb.tsp.ia.epay.sbpadapter.configs.KafkaProducerConfig.KAFKA_PORTAL_TEMPLATE;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress.Constants;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeaderImpl;
import ru.vtb.tsp.ia.epay.portal.domains.transaction.TransactionCallback;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;

@Slf4j
@Service
public class KafkaService {

  private final KafkaTemplate<String, Object> kafkaBoxTemplate;
  private final KafkaTemplate<String, Object> kafkaPortalTemplate;
  private final List<String> producerTopics;
  private final List<String> transactionTopics;
  private final List<String> dlqTopics;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForBox;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForPortal;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForNotification;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForEvent;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForDlq;

  public KafkaService(@Qualifier(KAFKA_BOX_TEMPLATE) KafkaTemplate<String, Object> kafkaBoxTemplate,
        @Qualifier(KAFKA_PORTAL_TEMPLATE) KafkaTemplate<String, Object> kafkaPortalTemplate,
        @Value("${app.kafka.producer.topics}") @NotEmpty List<String> producerTopics,
        @Value("${app.kafka.callback.transaction-topics}") @NotEmpty List<String> transactionTopics,
        @Value("${app.kafka.dlq-topics}") @NotEmpty List<String> dlqTopics) {
    this.kafkaBoxTemplate = kafkaBoxTemplate;
    this.kafkaPortalTemplate = kafkaPortalTemplate;
    this.producerTopics = Objects.requireNonNullElse(producerTopics, Collections.emptyList());
    this.transactionTopics = Objects.requireNonNullElse(transactionTopics, Collections.emptyList());
    this.dlqTopics = Objects.requireNonNullElse(dlqTopics, Collections.emptyList());
    this.callbackFactoryForBox = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is processed with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to next route point {}", key, topic, ex);
      }
    };
    this.callbackFactoryForPortal = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is sent to portal with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to portal {}", key, topic, ex);
      }
    };
    this.callbackFactoryForNotification = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Notification {} is sent to notificator with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending notification {} to notificator {}", key, topic, ex);
      }
    };
    this.callbackFactoryForEvent = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Event {} is sent with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending event {} to topic {}", key, topic, ex);
      }
    };
    this.callbackFactoryForDlq = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Message {} is sent to dlq with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending message {} to portal {}", key, topic, ex);
      }
    };
  }

  public void sendToBox(@Nullable TransactionPayload payload) {
    Optional.ofNullable(payload)
        .ifPresent(tx -> send(tx, tx.getTransactionId()));
  }

  public void sendToGateway(@Nullable Event event) {
    Optional.ofNullable(event)
        .ifPresent(e -> send(e, e.getMstId()));
  }

  public void sendToPortal(@Nullable TransactionPayload transaction) {
    Optional.ofNullable(transaction)
        .ifPresent(tx -> send(TransactionCallback.map(tx).orElse(null),
            tx.getTransactionId()));
  }

  public void sendToDlq(@Nullable Object message) {
    Optional.ofNullable(message)
        .ifPresent(m -> send(m, m.toString()));
  }

  public void sendToNotificator(@Nullable Serializable payload,
      @Nullable List<NotificationAddress> addresses,
      @Nullable NotificationType type,
      @Nullable LocalDateTime notifyTime) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(addresses)
        || Objects.isNull(type) || Objects.isNull(notifyTime)) {
      return;
    }
    final var notification = NotificationImpl.builder()
        .header(NotificationHeaderImpl.builder()
            .sentAt(notifyTime)
            .code(UUID.randomUUID().toString())
            .destination(addresses)
            .type(type)
            .build())
        .payload(payload)
        .build();
    send(notification, notification.getCode());
  }

  private void send(@Nullable Object payload, String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final KafkaTemplate<String, Object> kafkaTemplate;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    if (payload instanceof TransactionPayload) {
      topics = producerTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForBox;
    } else if (payload instanceof TransactionCallback) {
      topics = transactionTopics;
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForPortal;
    } else if (payload instanceof Event) {
      topics = ((Event)payload).getDestination().stream()
          .map(EventAddress::getResponseAddress)
          .collect(Collectors.toList());
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForEvent;
    } else if (payload instanceof Notification) {
      topics = Collections.singletonList(Constants.NOTIFICATOR_ADDRESS);
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForNotification;
    } else {
      topics = dlqTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForDlq;
    }
    topics.forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
            .addCallback(callback.apply(topic, key));
    });
  }
}