package ru.vtb.tsp.ia.epay.sbpadapter.configs;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Client;
import feign.RequestInterceptor;
import feign.Retryer;
import feign.codec.Decoder;
import feign.micrometer.MeteredClient;
import feign.micrometer.MeteredDecoder;
import io.micrometer.core.instrument.MeterRegistry;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.function.Consumer;
import javax.net.ssl.SSLContext;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.support.HttpMessageConverterCustomizer;
import org.springframework.cloud.openfeign.support.ResponseEntityDecoder;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.ResourceUtils;
import ru.vtb.tsp.ia.epay.sbpadapter.configs.properties.Ssl;

@Configuration
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "app.sbp.native.mock", havingValue = "false")
@EnableFeignClients(basePackages = {"ru.vtb.tsp.ia.epay.sbpadapter.services.client"})
public class FeignConfig {

  private static final long RETRY_PERIOD = 250L;
  private static final long RETRY_MAX_PERIOD = 2000L;
  private static final int RETRY_MAX_ATTEMPTS = 7;
  private final Ssl sslProperties;

  @Bean
  public RequestInterceptor requestInterceptor() {
    return template -> log.info("{} calls method {}: url {}",
        template.feignTarget().name(),
        template.method(),
        template.feignTarget().url().concat(template.url()));
  }

  @Bean
  public Decoder feignDecoder(ObjectMapper objectMapper, MeterRegistry meterRegistry) {
    return new MeteredDecoder(new ResponseEntityDecoder(new SpringDecoder(
        () -> new HttpMessageConverters(new MappingJackson2HttpMessageConverter(objectMapper)),
        new ObjectProvider<>() {

          @Override
          public HttpMessageConverterCustomizer getObject(Object... args) throws BeansException {
            return null;
          }

          @Override
          public HttpMessageConverterCustomizer getIfAvailable() throws BeansException {
            return null;
          }

          @Override
          public HttpMessageConverterCustomizer getIfUnique() throws BeansException {
            return null;
          }

          @Override
          public HttpMessageConverterCustomizer getObject() throws BeansException {
            return null;
          }

          @Override
          public void forEach(Consumer action) {
            // do nothing
          }
        })), meterRegistry);
  }

  @Bean
  public Client client() {
    final var ssl = getSSLContext(sslProperties.isClientAuth(),
        sslProperties.isCertValidation());
    return new MeteredClient.Default(ssl.getSocketFactory(),
        sslProperties.isCertValidation() ? new DefaultHostnameVerifier()
            : new NoopHostnameVerifier());
  }

  @Bean
  public Retryer retryer() {
    return new Retryer.Default(RETRY_PERIOD, RETRY_MAX_PERIOD, RETRY_MAX_ATTEMPTS);
  }

  private KeyStore getKeystore(@NotNull String keystorePath, @NotNull String keystorePass) {
    try(var keyStoreInputStream = new FileInputStream(ResourceUtils.getFile(keystorePath))) {
      final var keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(keyStoreInputStream, keystorePass.toCharArray());
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException ex) {
      log.error("Error occurred during keystore loading", ex);
      throw new ApplicationContextException("Error occurred during keystore loading", ex);
    }
  }

  private String getKeyAlias(@NotNull KeyStore keyStore) {
    try {
      final var aliases = keyStore.aliases();
      for (String alias : Collections.list(aliases)) {
        log.info("FeignClientConfig keystore aliases {}", alias);
        if (keyStore.isKeyEntry(alias)) {
          log.info("FeignClientConfig key {}", alias);
          return alias;
        }
      }
    } catch (KeyStoreException ex) {
      log.error("Error occurred during keystore loading alias", ex);
      throw new ApplicationContextException("Error occurred during keystore loading alias", ex);
    }
    return null;
  }

  private SSLContext getSSLContext(boolean clientAuth, boolean certValidation) {
    final var builder = new SSLContextBuilder();
    try {
      if (clientAuth) {
        final var keyStore = getKeystore(sslProperties.getKeystorePath(),
            sslProperties.getKeystorePass());
        builder.loadKeyMaterial(keyStore, sslProperties.getKeystorePass().toCharArray(),
            ((aliases, socket) -> getKeyAlias(keyStore)));
      }
      if (certValidation) {
        builder.loadTrustMaterial(ResourceUtils.getFile(sslProperties.getTruststorePath()),
            sslProperties.getTruststorePass().toCharArray());
      } else {
        builder.loadTrustMaterial(null,
            (X509Certificate[] chain, String authType) -> true);
      }
      return builder.build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException
        | KeyManagementException | UnrecoverableKeyException ex) {
      log.error("Error occurred during creation ssl context", ex);
      throw new ApplicationContextException("Error occurred during creation ssl context", ex);
    }
  }
}