package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.epa.EpaAuthRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.epa.EpaTokenResponseDto;

public interface EpaAuthApi {

  @PostMapping(path = "/passport/oauth2/token", consumes = "application/x-www-form-urlencoded")
  EpaTokenResponseDto getToken(@RequestBody EpaAuthRequestDto request);

}