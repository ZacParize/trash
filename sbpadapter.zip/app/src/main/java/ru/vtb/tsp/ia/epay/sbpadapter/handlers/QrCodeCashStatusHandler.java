package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.InvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Component(QrCodeCashStatusHandler.BEAN_NAME)
public class QrCodeCashStatusHandler extends AbstractEventHandler<SbpCashQrStatusResponseDto> {

  private static final SbpCashQrStatusResponseDto EMPTY_RESPONSE =
      SbpCashQrStatusResponseDto.builder().build();
  public static final String BEAN_NAME = Constants.CASH_QR_STATUS;
  private final InvocationFactory invocationFactory;

  public QrCodeCashStatusHandler(
      KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper,
      InvocationFactory invocationFactory) {
    super(kafkaService, transactionService, orderService, merchantSiteService, objectMapper);
    this.invocationFactory = invocationFactory;
  }

  @Override
  @Transactional
  public @NotNull SbpCashQrStatusResponseDto apply(@Nullable Event event) {
    return Optional.ofNullable(event)
        .map(e -> {
          final var request = objectMapper
              .convertValue(e.getPayload(), new TypeReference<SbpCashQrStatusRequestDto>() {
              });
          e.setPayload(request);
          final var response = invocationFactory.getStatusCashQr(e);
          final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
                  .mstId(e.getMstId())
                  .code(e.getCode())
                  .type(EventType.CASH_QR_STATUS)
                  .sentAt(LocalDateTime.now(ZoneOffset.UTC))
                  .destination(Collections.singletonList(EventAddress.CASH_QR_STATUS))
                  .build())
              .payload(response)
              .build();
          kafkaService.sendToGateway(callback);
          return response;
        })
        .orElse(EMPTY_RESPONSE);
  }
}