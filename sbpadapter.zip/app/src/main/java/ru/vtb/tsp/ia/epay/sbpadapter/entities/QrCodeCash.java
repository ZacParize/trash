package ru.vtb.tsp.ia.epay.sbpadapter.entities;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import javax.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table(QrCodeCash.TABLE_NAME)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class QrCodeCash {

  public static final String TABLE_NAME = "qr_code_cash";

  @Id
  @Column("id")
  private Long id;

  @NotEmpty
  @Column("qrc_id")
  private String qrcId;

  private String payload;

  @NotEmpty
  private String status;

  @Column("redirect_url")
  private String redirectUrl;

  @NotEmpty
  private String account;

  @NotEmpty
  @Column("created_at")
  private LocalDateTime createdAt;

  @NotEmpty
  @Column("merchant_id")
  private String merchantId;

}