package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.PaymentStatusResponseParser.BEAN_NAME;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Objects;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.OrderServiceFacade;

@Slf4j
@Component(BEAN_NAME)
public class PaymentStatusResponseParser extends
    AbstractResponseParser<SbpPaymentStatusResponseDto> {

  private static final ServiceException PAYMENT_DECLINED_EXCEPTION =
      new ServiceException(ApplicationException.PAYMENT_DECLINED_ERROR);
  public static final String BEAN_NAME = "paymentStatusResponseParser";

  private final OrderServiceFacade orderServiceFacade;

  public PaymentStatusResponseParser(TransactionService transactionService,
      OrderServiceFacade orderServiceFacade) {
    super(transactionService);
    this.orderServiceFacade = orderServiceFacade;
  }

  @Override
  @AuditProcess("TSPACQ_BOX_SBP_PAYMENT_STATUS_RESPONSE")
  public void accept(@Nullable SbpPaymentStatusResponseDto response,
                     @Nullable TransactionPayload transaction) {
    if (Objects.isNull(response) || Objects.isNull(transaction) || transaction.isCompleted()) {
      return;
    }
    final var sbpTransaction = (Sbp) transaction.getPaymentData();
    sbpTransaction.setStatus(response.getQState());
    sbpTransaction.setOperationId(response.getOperationId());
    transactionService.getById(transaction.getTransactionId())
      .filter(foundTx -> !foundTx.isCompleted())
      .ifPresent(foundTx -> {
        if (Qstate.OK.equals(response.getQState())) {
          transactionService.upsertInfo(TransactionInfo.builder()
              .transaction(foundTx)
              .key(TransactionInfoKey.SBP_OPERATION_ID)
              .value(sbpTransaction.getOperationId())
              .createdAt(LocalDateTime.now(ZoneOffset.UTC))
              .build());
          transaction.setStatus(TransactionState.RECONCILED);
          transactionService.updateDataById(transaction.getTransactionId(), transaction);
          log.info("Transaction id {} with type {} was processed by SBP",
              foundTx.getTransactionId(), foundTx.getType());
          final var isFullRefund = Order.calculatePayedAmount(
              transactionService.getByOrderId(foundTx.getOrder().getOrderId()),
              Collections.singletonList(foundTx))
                + foundTx.getAmount() >= foundTx.getOrder().getAmount();
          orderServiceFacade.updateOrderState(foundTx.getOrder()
              .withState(isFullRefund ? OrderState.PAID : OrderState.PARTIALLY_PAID));
          log.info("Order id {} is payed by SBP", foundTx.getOrder().getOrderId());
        } else {
          if (Qstate.Canceled.equals(response.getQState()) || Qstate.Unknown.equals(
              response.getQState())) {
            transactionService.upsertInfo(TransactionInfo.builder()
                .transaction(foundTx)
                .key(TransactionInfoKey.SBP_OPERATION_ID)
                .value(sbpTransaction.getOperationId())
                .createdAt(LocalDateTime.now(ZoneOffset.UTC))
                .build());
            transactionService.updateStateById(transaction.getTransactionId(),
                TransactionState.DECLINED);
            log.info("Transaction id {} is declined by SBP", transaction.getTransactionId());
          } else if (Qstate.CREATED.equals(response.getQState())
              || Qstate.InProgress.equals(response.getQState())) {
            log.info("Transaction id {} is still processing by SBP",
                transaction.getTransactionId());
          } else if (Qstate.NTST.equals(response.getQState())) {
            if (foundTx.getOrder().isExpired()) {
              transactionService.upsertInfo(TransactionInfo.builder()
                  .transaction(foundTx)
                  .key(TransactionInfoKey.SBP_OPERATION_ID)
                  .value(sbpTransaction.getOperationId())
                  .createdAt(LocalDateTime.now(ZoneOffset.UTC))
                  .build());
              transactionService.updateStateById(transaction.getTransactionId(),
                  TransactionState.DECLINED);
            }
            log.info("Transaction id {} still has not payed by SBP", transaction.getTransactionId());
          } else {
            onError(transaction, PAYMENT_DECLINED_EXCEPTION);
            log.error("Transaction id {} has unknown state in SBP",
                transaction.getTransactionId());
          }
        }
      });
  }

}