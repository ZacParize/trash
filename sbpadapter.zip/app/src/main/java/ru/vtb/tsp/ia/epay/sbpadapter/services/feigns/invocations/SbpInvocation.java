package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.EnumMap;
import javax.annotation.Nullable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

public interface SbpInvocation<E extends Enum<E>> {

  default @Nullable ResponseEntity<?> invoke(@Nullable EnumMap<E, Object> params) {
    throw new IllegalArgumentException("Incorrect invocation");
  }

  default HttpHeaders getDefaultHeaders() {
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
    headers.setAcceptCharset(Collections.singletonList(StandardCharsets.UTF_8));
    return headers;
  }
}