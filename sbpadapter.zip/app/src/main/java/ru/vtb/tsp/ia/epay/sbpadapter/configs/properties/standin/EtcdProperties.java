package ru.vtb.tsp.ia.epay.sbpadapter.configs.properties.standin;

import java.util.List;
import lombok.Data;
import org.springframework.util.ObjectUtils;
import ru.vtb.smartreplication.configuration.etcd.IEtcdConfiguration;
import ru.vtb.smartreplication.core.ssl.IPemSslConfiguration;

@Data
public class EtcdProperties implements IEtcdConfiguration {

  private List<String> endpoints;
  private String password;
  private String user;
  private String loadBalancerPolicy;
  private String authority;
  private Integer maxInboundMessageSize;
  private String namespace;
  private Long retryDelayMs = 500L;
  private Long retryMaxDelayMs = 2500L;
  private Long keepaliveTimeMs = 30000L;
  private Long keepaliveTimeoutMs = 10000L;
  private Long retryMaxDurationMs;
  private Long connectTimeoutMs;
  private Boolean discovery;
  private EtcdSslProperties keyStore;
  private boolean enabled;


  @Override
  public List<String> getEndpoints() {
    return endpoints;
  }

  @Override
  public char[] getPassword() {
    return ObjectUtils.isEmpty(password) ? new char[0] : password.toCharArray();
  }

  @Override
  public String getUser() {
    return user;
  }

  @Override
  public String getLoadBalancerPolicy() {
    return loadBalancerPolicy;
  }

  @Override
  public String getAuthority() {
    return authority;
  }

  @Override
  public Integer getMaxInboundMessageSize() {
    return maxInboundMessageSize;
  }

  @Override
  public String getNamespace() {
    return namespace;
  }

  @Override
  public Long getRetryDelayMs() {
    return retryDelayMs;
  }

  @Override
  public Long getRetryMaxDelayMs() {
    return retryMaxDelayMs;
  }

  @Override
  public Long getKeepaliveTimeMs() {
    return keepaliveTimeMs;
  }

  @Override
  public Long getKeepaliveTimeoutMs() {
    return keepaliveTimeoutMs;
  }

  @Override
  public Long getRetryMaxDurationMs() {
    return retryMaxDurationMs;
  }

  @Override
  public Long getConnectTimeoutMs() {
    return connectTimeoutMs;
  }

  @Override
  public Boolean getDiscovery() {
    return discovery;
  }

  @Override
  public IPemSslConfiguration getPem() {
    return null;
  }

  @Override
  public EtcdSslProperties getKeyStore() {
    return keyStore;
  }

  @Override
  public boolean isEnabled() {
    return enabled;
  }
}
