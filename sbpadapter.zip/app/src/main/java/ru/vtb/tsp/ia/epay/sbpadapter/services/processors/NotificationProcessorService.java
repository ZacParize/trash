package ru.vtb.tsp.ia.epay.sbpadapter.services.processors;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.sbpadapter.configs.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpRefreshStatusDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.listeners.RefreshStatusNotificationListener;

@Slf4j
@Service
@AllArgsConstructor
public class NotificationProcessorService {

  private final MessageAdapter messageAdapter;
  private final ObjectMapper objectMapper;
  private final Map<String, Consumer<?>> listeners;

  @KafkaListener(topics = NotificationAddress.Constants.SBPADAPTER_NOTIFICATION_ADDRESS,
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  public void processNotification(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      final var notification = messageAdapter.deserializeNotification(record.value());
      if (Objects.isNull(notification)) {
        return;
      }
      if (NotificationType.SBP_REFRESH_STATUS_REQUEST_RETRY.equals(notification.getType())) {
        final var notificationPayload = objectMapper
            .convertValue(notification.getPayload(), SbpRefreshStatusDto.class);
        ((RefreshStatusNotificationListener) listeners
            .get(RefreshStatusNotificationListener.BEAN_NAME)).accept(notificationPayload);
        log.info("Sbp refresh notification {} is processed", notificationPayload);
      }
    } catch (Exception ex) {
      log.error("Notification can't be processed", ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}