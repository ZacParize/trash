package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundConfirmationInvocation.BEAN_NAME;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmCode;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class RefundConfirmationInvocation implements
    SbpInvocation<RefundConfirmationInvocation.Param> {

  public static final String BEAN_NAME = "refundConfirmationInvocationBean";
  private final SbpApi sbpApi;

  public enum Param {
    TRANSACTION_ID,
    MSG_ID,
    PRTRY
  }

  @AuditProcess("TSPACQ_BOX_SBP_REFUND_ACCEPT_RESULT")
  @Override
  public ResponseEntity<SbpConfirmRefundResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          log.info("Refund confirmation invocation params {}", parametersMap);
          try {
            final var requestEntity = SbpRefundConfirmRequestDto.builder()
                    .msgId(Objects.requireNonNull(parametersMap.get(Param.MSG_ID)).toString())
                    .prtry((SbpRefundConfirmCode) Objects.requireNonNull(parametersMap.get(Param.PRTRY)))
                    .build();
            log.info("Refund confirmation invocation request {}", requestEntity);
            final var responseEntity =
                sbpApi.confirmRefund(getDefaultHeaders(), requestEntity);
            log.info("Received refund confirmation invocation response {} of transaction id {}",
                    responseEntity.getBody(), parametersMap.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
             log.error("Error occurred during refund confirmation invocation {}", parametersMap, ex);
             throw new ServiceException(ApplicationException.PAYMENT_EXECUTION_ERROR);
          }
        }).orElse(null);
  }
}