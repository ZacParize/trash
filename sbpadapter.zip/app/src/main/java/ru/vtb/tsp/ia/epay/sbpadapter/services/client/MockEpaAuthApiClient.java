package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.epa.EpaAuthRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.epa.EpaTokenResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.EpaAuthApi;

@Component
@ConditionalOnProperty(name = "epa.ig.mock", havingValue = "true")
public class MockEpaAuthApiClient implements EpaAuthApi {

  private final static String AUTH_TOKEN = "eyJ0eXAiOiJKV1QiLCJraWQiOiJodHRwczovL3Bhc3Nwb3J0LmFwa"
      + "S52dGIucnUvcGFzc3BvcnQiLCJhbGciOiJFUzI1NiJ9.eyJzdWIiOiJzbWJxX2VwYUB0ZXN0LnZ0Yi5ydSIsIm1l"
      + "dGhvZCI6ImxvZ2luIiwiaXAiOiIxMC4yMjIuMjQ2LjE4OSIsImlzcyI6Imh0dHBzOi8vcGFzc3BvcnQuYXBpLnZ0"
      + "Yi5ydS9wYXNzcG9ydCIsImNoYW5uZWwiOiJzZXJ2aWNlIiwibm9uY2UiOiJlMjEyYzU4Ny1kYWRjLTQxZmEtYTEw"
      + "OS1hZDMxNGQwMDgxMzUiLCJhdWQiOiJodHRwczovL3Bhc3Nwb3J0LmFwaS52dGIucnUvcGFzc3BvcnQiLCJhdXRo"
      + "OnNlcnZpY2UiOiJkZWZhdWx0IiwiYXV0aDptb2R1bGUiOiJwYXNzd29yZCIsInJlYWxtIjoiL2IyYy90ZWNoIiwi"
      + "ZXhwIjoxNjc2NTM5NDk0LCJpYXQiOjE2NzY1Mzg1OTQsImp0aSI6IjU0YmEwZmMyLTZiOWUtNDNmOC04MDZiLWI0"
      + "ZjBmNzQxYjIwMSJ9.6JcXqzabqzdkXCW-DxlH9aIoAbRNrEx_-4qkl1VMUpyGjMj6KRdg4c2C733iffxX2DfvJ4V"
      + "qYG_BNGl_R0j2gA";

  private final static String TOKEN_TYPE = "client_credentials";

  @Override
  public EpaTokenResponseDto getToken(EpaAuthRequestDto request) {
    return EpaTokenResponseDto.builder()
        .accessToken(AUTH_TOKEN)
        .tokenType(TOKEN_TYPE)
        .expiresIn(Long.MAX_VALUE)
        .build();
  }

}