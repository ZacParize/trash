package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundStatusInvocation.BEAN_NAME;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;


@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class RefundStatusInvocation implements SbpInvocation<RefundStatusInvocation.Param> {

  public static final String BEAN_NAME = "refundStatusInvocationBean";
  private final SbpApi sbpApi;

  public enum Param {
    TRANSACTION_ID,
    MSG_ID
  }

  @Override
  public @Nullable ResponseEntity<SbpRefundStatusResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          try {
            final var requestEntity = SbpRefundStatusRequestDto.builder()
                .msgId(Objects.requireNonNull(parametersMap.get(Param.MSG_ID)).toString())
                .build();
            log.info("Refund status invocation params {}", parametersMap);
            final var responseEntity = sbpApi.getRefundStatus(getDefaultHeaders(), requestEntity);
            log.info("Received refund status invocation response {} of transaction id {}",
                responseEntity.getBody(), parametersMap.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during refund status invocation {}", parametersMap, ex);
            return null;
          }
        }).orElse(null);
  }
}