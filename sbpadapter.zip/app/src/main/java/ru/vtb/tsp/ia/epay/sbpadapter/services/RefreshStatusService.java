package ru.vtb.tsp.ia.epay.sbpadapter.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpRefreshStatusDto;

@Slf4j
@Service
@AllArgsConstructor
public class RefreshStatusService {

  private static final int RETRY_COUNT_FOR_EXPIRED_ORDER = 5;
  private static final long REFRESH_STATUS_DELAY_SECONDS = 5L;
  private static final long REFRESH_DAYS_AFTER_EXPIRATION = 4L;

  private final TransactionService transactionService;
  private final OrderServiceFacade orderService;
  private final InvocationFactory invocationFactory;
  private final KafkaService kafkaService;

  @Transactional
  public boolean refreshState(@Nullable String transactionId) {
    return Optional.ofNullable(transactionId)
        .filter(txId -> !ObjectUtils.isEmpty(txId))
        .flatMap(transactionService::lockById)
        .filter(tx -> SchedulerService.STATES_FOR_REFRESH.contains(tx.getState()))
        .map(tx -> {
          try {
            // change transaction state
            tx.setState(TransactionState.PROCESSING);
            transactionService.updateStateById(tx.getTransactionId(), tx.getState());
            // start refresh state retries
            kafkaService.sendToNotificator(
                SbpRefreshStatusDto.builder()
                    .retryCount(1)
                    .transactionId(tx.getTransactionId())
                    .build(),
                Collections.singletonList(NotificationAddress.SBPADAPTER_NOTIFICATION),
                NotificationType.SBP_REFRESH_STATUS_REQUEST_RETRY,
                LocalDateTime.now(ZoneOffset.UTC).plusSeconds(REFRESH_STATUS_DELAY_SECONDS));
            // send transaction to portal
            kafkaService.sendToPortal(tx.getData());
            log.info("Transaction id {} is successfully registered for refresh state",
                tx.getTransactionId());
            return true;
          } catch (Exception exception) {
            log.error("Error occurred during transaction id {} refresh state",
                tx.getTransactionId(), exception);
            return false;
          }})
        .orElse(false);
  }

  @Transactional
  public boolean isRefreshed(@Nullable SbpRefreshStatusDto notification) {
    return Optional.ofNullable(notification)
        .map(SbpRefreshStatusDto::getTransactionId)
        .flatMap(transactionService::lockById)
        .filter(transaction -> (transaction.isSbpRefund() || transaction.isSbpPayment())
            && !transaction.isCompleted())
        .map(transaction -> {
          // refresh status in sbp
          if (transaction.isSbpPayment()) {
            log.info("Refresh sbp payment {}", transaction.getData());
            invocationFactory.createPaymentStatus(transaction.getData());
          } else {
            log.info("Refresh sbp refund {}", transaction.getData());
            invocationFactory.createRefundStatus(transaction.getData());
          }
          final var transactions = transactionService.getByOrderId(transaction
              .getOrder().getOrderId());
          log.info("List of order's transactions {}", transactions);
          transaction = transactions.stream()
              .filter(tx -> notification.getTransactionId().equals(tx.getTransactionId()))
              .findFirst()
              .orElseThrow();
          // get order info
          final var order = transaction.getOrder();
          if (transaction.getData().isCompleted()) {
            log.info("Received terminal status from bank sbp adapter {}", transaction);
            // calculate order state
            orderService.calculateOrderState(order, transactions);
            return false;
          } else {
            // order expired
            if (order.getExpiredAt().plusDays(REFRESH_DAYS_AFTER_EXPIRATION)
                .isBefore(LocalDateTime.now(ZoneOffset.UTC))
                && notification.getRetryCount() > RETRY_COUNT_FOR_EXPIRED_ORDER) {
              // decline transaction
              transaction.setState(TransactionState.DECLINED);
              transactionService.updateStateById(transaction.getTransactionId(),
                  transaction.getState());
              // calculate order state
              orderService.calculateOrderState(order, transactions);
              log.info("Order {} expired, transaction was declined {}", order, transaction);
              // send transaction to portal
              kafkaService.sendToPortal(transaction.getData());
              return false;
            } else {
              return true;
            }
          }})
        .orElse(false);
  }

}
