package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import java.util.Random;
import java.util.UUID;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Component
@ConditionalOnProperty(name = "app.sbp.tyk.mock", havingValue = "true")
public class MockSbpTykApiClient implements SbpTykApi {

  private final static String OK_CODE = "RQ00000";
  private final static String MESSAGE = "Запрос обработан успешно";

  @Override
  public ResponseEntity<SbpQrCodeResponseDto> createQr(HttpHeaders httpHeaders,
      SbpQrCodeCreationRequestDto body) {
    final var dto = new SbpQrCodeResponseDto();
    final var content = new SbpQrCodeResponseDto.Content();
    final var rand = new Random();
    final var qrcId = String.valueOf(Math.round(rand.nextDouble() * 100000000));
    content.setQrcId(qrcId);
    content.setPayload("https://qr.nspk.ru/" + qrcId + "?type=01&bank=100000000005");
    content.setStatus(Qstate.CREATED);
    dto.setCode(OK_CODE);
    dto.setMessage(MESSAGE);
    dto.setData(content);
    dto.setOrderId(body.getOrderId());
    dto.setRequestId(body.getRequestId());
    return ResponseEntity.ok(dto);
  }

  @Override
  public ResponseEntity<SbpCashQrCreationResponseDto> createCashQr(HttpHeaders httpHeaders,
      SbpCashQrCreationRequestDto body) {
    final var rand = new Random();
    return ResponseEntity.ok(SbpCashQrCreationResponseDto.builder()
        .code(OK_CODE)
        .message(MESSAGE)
        .data(SbpCashQrCreationResponseDto.SbpCashQrCreationResponseDtoContent.builder()
            .payload(UUID.randomUUID().toString())
            .status(Qstate.CREATED.name())
            .qrcId(String.valueOf(Math.round(rand.nextDouble() * 100000000)))
            .build())
        .build());
  }

  @Override
  public ResponseEntity<SbpCashQrActivationResponseDto> activateCashQr(HttpHeaders httpHeaders,
      SbpCashQrActivationRequestDto body) {
    final var rand = new Random();
    return ResponseEntity.ok(SbpCashQrActivationResponseDto.builder()
        .code(OK_CODE)
        .message(MESSAGE)
        .data(SbpCashQrActivationResponseDto.SbpCashQrActivationResponseDtoContent.builder()
            .amount(body.getAmount())
            .currency(body.getCurrency())
            .paramsId(UUID.randomUUID().toString().substring(0, 30))
            .qrcId(String.valueOf(Math.round(rand.nextDouble() * 100000000)))
            .paymentPurpose(UUID.randomUUID().toString())
            .build())
        .build());
  }

  @Override
  public ResponseEntity<SbpCashQrDeactivationResponseDto> deactivateCashQr(HttpHeaders httpHeaders,
      SbpCashQrDeactivationRequestDto body) {
    final var response = SbpCashQrDeactivationResponseDto.builder()
        .code(OK_CODE)
        .message(MESSAGE)
        .data(SbpCashQrDeactivationResponseDto.SbpCashQrDeactivationResponseDtoContent.builder()
            .qrcId(body.getQrcId())
            .build())
        .build();
    return ResponseEntity.ok(response);
  }

  @Override
  public ResponseEntity<SbpCashQrStatusResponseDto> getStatusCashQr(HttpHeaders httpHeaders,
      SbpCashQrStatusRequestDto body) {
    return ResponseEntity.ok(SbpCashQrStatusResponseDto.builder()
        .qrcId(body.getQrcId())
        .operationId("B226606481601501000015716FF8C1B9")
        .paramsId(body.getParamsId())
        .qState(Qstate.OK)
        .reasonCode("12323123")
        .qReason("Сообщение СБП обработано успешно")
        .senderPhone("7700****967")
        .slipData("Тип операции: SBP Тип транзакции: Оплата "
            + "ID перации: AS1000670LSS7DN18SJQDNP4B05KLJL2 Сумма, руб: 100\n")
        .build());
  }

  @Override
  public ResponseEntity<SbpImageQrCreationResponseDto> createImageQr(HttpHeaders httpHeaders,
      SbpImageQrCreationRequestDto body) {
    final var response = SbpImageQrCreationResponseDto.builder()
        .content("iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAYAAAB5fY51AAAniUlEQVR4Xu3d+bevZ13ecf6E/t"
            + "BKBSlKbSssFgsQEAFlCqiIyDwuKEJLpVAGoYUCYR5DEBmMgKAIMi3CpKnAsgSKQExLmNIUiEhMmIKY"
            + "MCQnJyfDecreh7M5ee2zc50P9/PsfT/J/V7rvdp1rutzf+/vZ3vudXKS2utMg8FgsBKu4y8MBoNBr4w"
            + "HazAYrIbxYA0Gg9UwHqzBYLAaxoM1GAxWw3iwBoPBahgP1mAwWA3jwRoMBqthPFiDwWA1jAdrMBishv"
            + "FgDQaD1TAerMFgsBrGgzUYDFbDeLAGg8FqGA/WYDBYDeP…")
        .build();
    return ResponseEntity.ok(response);
  }

}