package ru.vtb.tsp.ia.epay.sbpadapter.services.listeners;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Objects;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpRefreshStatusDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.RefreshStatusService;

@Slf4j
@RequiredArgsConstructor
@Component(RefreshStatusNotificationListener.BEAN_NAME)
public class RefreshStatusNotificationListener implements Consumer<SbpRefreshStatusDto> {

  public static final String BEAN_NAME = "refreshStatusNotificationListener";

  private final TransactionService transactionService;

  private final RefreshStatusService refreshStatusService;

  private final KafkaService kafkaService;

  @Override
  public void accept(@Nullable SbpRefreshStatusDto notification) {
    if (Objects.isNull(notification) || Objects.isNull(notification.getTransactionId())
        || !refreshStatusService.isRefreshed(notification)) {
      return;
    }
    transactionService.getById(notification.getTransactionId())
        .ifPresent(transaction -> {
          final var now = LocalDateTime.now(ZoneOffset.UTC);
          final var retryCount = notification.getRetryCount() + 1;
          // plan next notification
          final var payload = SbpRefreshStatusDto.builder()
              .transactionId(transaction.getTransactionId())
              .retryCount(retryCount)
              .build();
          var notificationDelayInMinutes = 0L;
          if (transaction.getOrder().isExpired()) {
            notificationDelayInMinutes = 24L * 60L;
          } else if (retryCount < 5) {
            notificationDelayInMinutes = 20L;
          } else if (retryCount < 10) {
            notificationDelayInMinutes = 60L;
          } else if (retryCount < 20) {
            notificationDelayInMinutes = 12L * 60L;
          } else {
            notificationDelayInMinutes = 24L * 60L;
          }
          // send request for new notification
          kafkaService.sendToNotificator(payload,
              Collections.singletonList(NotificationAddress.SBPADAPTER_NOTIFICATION),
              NotificationType.SBP_REFRESH_STATUS_REQUEST_RETRY,
              now.plusMinutes(notificationDelayInMinutes));
        });
  }
}