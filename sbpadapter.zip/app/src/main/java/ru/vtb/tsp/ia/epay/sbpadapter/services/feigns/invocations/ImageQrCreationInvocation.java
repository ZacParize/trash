package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import io.micrometer.core.lang.Nullable;
import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.EpaAuthService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Slf4j
@Component(ImageQrCreationInvocation.BEAN_NAME)
@RequiredArgsConstructor
public class ImageQrCreationInvocation implements SbpTykInvocation<ImageQrCreationInvocation.Param> {

  public static final String BEAN_NAME = "imageQrCreationInvocationBean";
  private final SbpTykApi sbpTykApi;
  private final EpaAuthService epaAuthService;

  public enum Param {
    QRC_ID,
    WIDTH,
    HEIGHT
  }

  @Override
  public ResponseEntity<SbpImageQrCreationResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(this::buildRequest)
        .map(requestEntity -> {
          log.info("Image QR creation invocation request: {}", requestEntity);
          try {
            final var accessToken = epaAuthService.getToken();
            final var responseEntity = sbpTykApi.createImageQr(getDefaultHeaders(accessToken), requestEntity);
            log.info("Received Image QR creation invocation response: {}", responseEntity.getBody());
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during Image QR creation invocation with params: {}", params, ex);
            throw new ServiceException(ApplicationException.QR_IMAGE_CREATION_ERROR);
          }
        })
        .orElse(null);
  }

  private SbpImageQrCreationRequestDto buildRequest(EnumMap<Param, Object> params) {
    final var requestBuilder = SbpImageQrCreationRequestDto
        .builder().qrcId(Objects.requireNonNull(params.get(Param.QRC_ID)).toString());
    Optional.ofNullable((Integer) params.get(Param.WIDTH)).ifPresent(requestBuilder::width);
    Optional.ofNullable((Integer) params.get(Param.HEIGHT)).ifPresent(requestBuilder::height);
    return requestBuilder.build();

  }

}
