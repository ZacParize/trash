package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto.SbpCashQrDeactivationResponseDtoContent;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.EpaAuthService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Slf4j
@Component(CashQrDeactivationInvocation.BEAN_NAME)
@RequiredArgsConstructor
public class CashQrDeactivationInvocation implements
    SbpTykInvocation<CashQrDeactivationInvocation.Param> {

  public static final String BEAN_NAME = "cashQrDeactivationInvocationBean";
  protected final SbpTykApi sbpTykApi;
  private final EpaAuthService epaAuthService;

  public enum Param {
    QRC_ID
  }

  @Override
  public ResponseEntity<SbpCashQrDeactivationResponseDto> invoke(
      @Nullable EnumMap<CashQrDeactivationInvocation.Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          log.info("Cash qr deactivation invocation params {}", parametersMap);
          try {
            final var requestEntity = SbpCashQrDeactivationRequestDto.builder()
                .qrcId(Objects.requireNonNull(parametersMap.get(Param.QRC_ID)).toString())
                .build();
            log.info("Cash qr deactivation invocation request {}", requestEntity);
            final var accessToken = epaAuthService.getToken();
            final var responseEntity = sbpTykApi
                .deactivateCashQr(getDefaultHeaders(accessToken), requestEntity);
            if (responseEntity.hasBody()) {
              if (Objects.isNull(Objects.requireNonNull(responseEntity.getBody()).getData())) {
                responseEntity.getBody().setData(
                    SbpCashQrDeactivationResponseDtoContent.builder()
                        .qrcId(requestEntity.getQrcId())
                        .build());
              } else {
                responseEntity.getBody().getData().setQrcId(requestEntity.getQrcId());
              }
            }
            log.info("Received cash qr deactivation invocation response {}", responseEntity.getBody());
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during cash qr deactivation invocation {}", parametersMap, ex);
            throw new ServiceException(ApplicationException.PAYMENT_CREATION_ERROR);
          }
        }).orElse(null);
  }

}