package ru.vtb.tsp.ia.epay.sbpadapter.configs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Slf4j
@Configuration
@EnableKafka
@EnableScheduling
@ComponentScan({"ru.vtb.tsp.ia.epay.sbpadapter", "ru.vtb.tsp.ia.epay.core"})
@EnableTransactionManagement
@EnableFeignClients(basePackages = {"ru.vtb.tsp.ia.epay.sbpadapter.services.feigns"})
public class AppConfig {
}