package ru.vtb.tsp.ia.epay.sbpadapter.repositories;

import java.time.LocalDateTime;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeCash;

@Repository
public interface QrCodeCashRepository extends CrudRepository<QrCodeCash, Long> {

  @NotNull
  Optional<QrCodeCash> findByQrcId(String qrcId);

  @NotNull
  @Query("insert into " + QrCodeCash.TABLE_NAME + " (qrc_id, payload, status, redirect_url, account, "
      + "created_at, merchant_id) "
      + "values (:qrcId, :payload, :status, :redirectUrl, :account, :createdAt, :merchantId) "
      + "on conflict (qrc_id) do update set payload = :payload, status = :status, "
      + "redirect_url = :redirectUrl, account = :account, created_at = :createdAt, merchant_id = :merchantId "
      + "where " + QrCodeCash.TABLE_NAME + ".qrc_id = :qrcId RETURNING *")
  QrCodeCash saveOrUpdate(String qrcId,
      String payload,
      String status,
      String redirectUrl,
      String account,
      LocalDateTime createdAt,
      String merchantId);

  @NotNull
  default QrCodeCash saveOrUpdate(QrCodeCash entity) {
    return saveOrUpdate(entity.getQrcId(),
        entity.getPayload(),
        entity.getStatus(),
        entity.getRedirectUrl(),
        entity.getAccount(),
        entity.getCreatedAt(),
        entity.getMerchantId());
  }

}