package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns;

import javax.validation.constraints.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;

public interface SbpTykApi {

  /**
   * Запрос на формирование статического/динамического QR-кода
   */
  @AuditProcess("TSPACQ_BOX_SBP_QR")
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/NSPK_CreateAndGetQRcode", produces = "application/json", consumes = "application/json")
  //@PostMapping(path = "/immediate_payment/qr_code", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpQrCodeResponseDto> createQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpQrCodeCreationRequestDto body);

  /**
   * Запрос на создание кассовой ссылки
   */
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/NSPK_CashRegisterQRC", produces = "application/json", consumes = "application/json")
  //@PostMapping(path = "/api/v1/sbp/entity/qr/cash-register", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpCashQrCreationResponseDto> createCashQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpCashQrCreationRequestDto body);

  /**
   * Запрос на активацию кассовой ссылки
   */
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/NSPK_ActivationCashQRC", produces = "application/json", consumes = "application/json")
  //@PostMapping(path = "/api/v1/sbp/entity/qr/cash-register/activate", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpCashQrActivationResponseDto> activateCashQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpCashQrActivationRequestDto body);

  /**
   * Запрос на деактивацию кассовой ссылки
   */
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/NSPK_DeactivationCashQRC", produces = "application/json", consumes = "application/json")
  //@PostMapping(path = "/api/v1/sbp/entity/qr/cash-register/deactivate", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpCashQrDeactivationResponseDto> deactivateCashQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpCashQrDeactivationRequestDto body);

  /**
   * Запрос на получение статуса кассовой ссылки
   */
  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_PAYMENT_STATUS")
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/NSPK_CashQRCStatusV2", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpCashQrStatusResponseDto> getStatusCashQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpCashQrStatusRequestDto body);

  /**
   * Запрос на получение изображения QR-кода в бинарном формате
   */
  @PostMapping(path = "/api/cross/spbc/sbp/partners/v1/QRImage", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpImageQrCreationResponseDto> createImageQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpImageQrCreationRequestDto body);

}
