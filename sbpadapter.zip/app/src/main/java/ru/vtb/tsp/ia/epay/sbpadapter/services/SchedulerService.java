package ru.vtb.tsp.ia.epay.sbpadapter.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class SchedulerService {

  private static final long DECLINE_REFUNDS_DISPERSION_TIME_TO = 20L * 60L;
  private static final long DECLINE_REFUNDS_DISPERSION_TIME_FROM = 2L * 365L * 24L * 60L * 60L;
  private static final long TIMEOUT_BETWEEN_TASKS = 500L;
  private static final long REFRESH_STATES_DISPERSION_TIME = 2L * 365L * 24L * 60L * 60L;
  private static final String DECLINED_MARK = "declined by scheduler";
  private static final int THREADS_COUNT = 2;
  private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(
      THREADS_COUNT);
  public static final List<TransactionState> STATES_FOR_REFRESH = List.of(
      TransactionState.SBP_PAYMENT_CREATED,
      TransactionState.SBP_REFUND_CREATED);

  private final TransactionService transactionService;
  private final RefreshStatusService refreshStatusService;
  private final KafkaService kafkaService;

  @Scheduled(fixedDelay = 15L * 60L * 1000)
  public void refreshStates() {
    final var tasks = new ArrayList<Callable<Boolean>>();
    final var startTime = LocalDateTime.now(ZoneOffset.UTC);
    for (var state : STATES_FOR_REFRESH) {
      tasks.clear();
      tasks.add(() -> {
        var isAnyProcessed = false;
        final var txForProcessing = transactionService.getByState(state,
            startTime.minus(REFRESH_STATES_DISPERSION_TIME, ChronoUnit.SECONDS))
            .stream()
            .map(Transaction::getTransactionId)
            .collect(Collectors.toSet());
        for (var tx : txForProcessing) {
          if (refreshStatusService.refreshState(tx) && !isAnyProcessed) {
            isAnyProcessed = true;
          }
        }
        if (isAnyProcessed) {
          log.info("Status {} were refreshed successfully", state);
        }
        return isAnyProcessed;
      });
      try {
        EXECUTOR_SERVICE.invokeAll(tasks, TIMEOUT_BETWEEN_TASKS, TimeUnit.MILLISECONDS);
      } catch (InterruptedException | RejectedExecutionException ex) {
        log.error("Error occurred during refresh {}", state, ex);
      }
    }
  }

  @Scheduled(fixedDelay = 30L * 60L * 1000)
  public void declineRefunds() {
    final var tasks = new ArrayList<Callable<Boolean>>();
    final var startTime = LocalDateTime.now(ZoneOffset.UTC);
    tasks.add(() -> {
      final var transactionList = transactionService.getByStateAndType(
          TransactionState.NEW,
          TransactionType.PARTIAL_SBP_REFUND,
          startTime.minus(DECLINE_REFUNDS_DISPERSION_TIME_FROM, ChronoUnit.SECONDS));
      transactionList.addAll(transactionService.getByStateAndType(
          TransactionState.NEW,
          TransactionType.SBP_REFUND,
          startTime.minus(DECLINE_REFUNDS_DISPERSION_TIME_FROM, ChronoUnit.SECONDS)));
      final var toDateTime = startTime.minus(DECLINE_REFUNDS_DISPERSION_TIME_TO,
          ChronoUnit.SECONDS);
      var isAnyProcessed = false;
      for (var tx : transactionList) {
        if (Objects.isNull(tx.getData()) || toDateTime.isBefore(tx.getCreatedAt())) {
          continue;
        }
        if (!isAnyProcessed) {
          isAnyProcessed = true;
        }
        tx.getData().setStatus(TransactionState.DECLINED);
        transactionService.upsertInfo(TransactionInfo.builder()
            .transaction(tx)
            .key(TransactionInfoKey.SBP_DETAIL)
            .value(DECLINED_MARK)
            .createdAt(LocalDateTime.now(ZoneOffset.UTC))
            .build());
        transactionService.updateDataById(tx.getTransactionId(), tx.getData());
        kafkaService.sendToPortal(tx.getData());
      }
      if (isAnyProcessed) {
        log.info("Refunds in frozen NEW status were processed successfully");
      }
      return true;
    });
    try {
      EXECUTOR_SERVICE.invokeAll(tasks, TIMEOUT_BETWEEN_TASKS, TimeUnit.MILLISECONDS);
    } catch (InterruptedException | RejectedExecutionException ex) {
      log.error("Error occurred during frozen refunds cancellation", ex);
    }
  }

}
