package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers;

import java.util.function.BiConsumer;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;

@RequiredArgsConstructor
public abstract class AbstractResponseParser<T> implements BiConsumer<T, TransactionPayload> {

  protected final TransactionService transactionService;

  public abstract void accept(T response, TransactionPayload transaction);

  public void onError(@NotNull TransactionPayload transaction, ServiceException ex) {
    transaction.setError(TransactionError.builder()
        .id(ex.getId())
        .httpCode(ex.getHttpCode())
        .description(ex.getDescription())
        .message(ex.getMessage())
        .traceId(transaction.getTransactionCode())
        .build());
    transaction.setStatus(TransactionState.DECLINED);
    transactionService.updateDataById(transaction.getTransactionId(), transaction);
  }

}