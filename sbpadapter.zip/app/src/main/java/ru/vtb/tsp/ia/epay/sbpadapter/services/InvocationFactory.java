package ru.vtb.tsp.ia.epay.sbpadapter.services;

import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams;
import ru.vtb.tsp.ia.epay.core.domains.transaction.MerchantSiteInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.QrCodeType;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories.QrInvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories.RefundInvocationFactory;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;

@Slf4j
@Service
@AllArgsConstructor
public class InvocationFactory {

  private final QrInvocationFactory qrInvocationFactory;
  private final RefundInvocationFactory refundInvocationFactory;

  public @NotNull SbpQrCodeResponseDto createStaticQr(@Nullable Event event) {
    return qrInvocationFactory.createStaticQr(event);
  }

  public @NotNull SbpCashQrCreationResponseDto createCashQr(@Nullable Event event) {
    return qrInvocationFactory.createCashQr(event);
  }

  public @NotNull SbpImageQrCreationResponseDto createImageQr(@Nullable Event event) {
    return qrInvocationFactory.createImageQr(event);
  }

  public @NotNull SbpCashQrStatusResponseDto getStatusCashQr(@Nullable Event event) {
    return qrInvocationFactory.getStatusCashQr(event);
  }

  public void createPaymentStatus(@NotNull TransactionPayload transaction) {
    qrInvocationFactory.createPaymentStatus(transaction);
  }

  public void createRefundStatus(@NotNull TransactionPayload transaction) {
    refundInvocationFactory.createRefundStatus(transaction);
  }

  public @NotNull SbpCashQrActivationResponseDto activateCashQr(@Nullable Event event) {
    return qrInvocationFactory.activateCashQr(event);
  }

  public @NotNull SbpCashQrDeactivationResponseDto deactivateCashQr(@Nullable Event event) {
    return qrInvocationFactory.deactivateCashQr(event);
  }

  public boolean create(@Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction)
        || Objects.isNull(transaction.getPaymentData())
        || !(transaction.getPaymentData() instanceof Sbp)
        || transaction.isCompleted()
        || !Optional.ofNullable(transaction.getMerchant())
        .map(MerchantSiteInfo::getMerchantSiteParams)
        .map(MerchantSiteParams::getSbpParams)
        .map(MerchantSiteSbpParams::isEnableSbpPayment)
        .orElse(false)) {
      return false;
    }
    if (transaction.isSbpPayment()) {
      if (TransactionState.SBP_PAYMENT_CREATED.equals(transaction.getStatus())) {
        qrInvocationFactory.createPaymentStatus(transaction);
      } else {
        qrInvocationFactory.createQr(transaction, QrCodeType.DYNAMIC);
      }
      return true;
    } else if (transaction.isSbpRefund()) {
      if (TransactionState.SBP_REFUND_CREATED.equals(transaction.getStatus())) {
        refundInvocationFactory.createRefundStatus(transaction);
      } else {
        if (Objects.isNull(((Sbp) transaction.getPaymentData()).getMsgId())) {
          refundInvocationFactory.createRegisterRefund(transaction);
        } else {
          refundInvocationFactory.createConfirmRefund(transaction);
        }
      }
      return true;
    } else {
      log.error("Unsupported transaction type {} for transaction id {}", transaction.getType(),
          transaction.getTransactionId());
      return false;
    }
  }
}