package ru.vtb.tsp.ia.epay.sbpadapter.services.processors;

import java.io.Serializable;
import java.util.Map;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.sbpadapter.configs.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.sbpadapter.handlers.AbstractEventHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress.Constants;

@Slf4j
@Service
@AllArgsConstructor
public class QrCodeStaticProcessorService {

  private final Map<String, AbstractEventHandler<? extends Serializable>> handlers;

  @KafkaListener(topics = {
      EventAddress.Constants.ADAPTER_STATIC_QR_CREATE_ADDRESS,
      EventAddress.Constants.ADAPTER_STATIC_QR_GET_ADDRESS },
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  private void processStaticQrEvent(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      Optional.ofNullable(record.value())
          .ifPresent(event -> Optional.ofNullable(handlers.get(event.getType().name()))
              .ifPresent(handler -> handler.apply(event)));
    } catch (Exception ex) {
      log.error("Static qr event can't be processed", ex);
      Optional.ofNullable(record.value())
          .ifPresent(event -> Optional.ofNullable(handlers.get(event.getType().name()))
              .ifPresent(handler -> handler.onError(event, ex)));
    } finally {
      acknowledgment.acknowledge();
    }
  }

  @KafkaListener(topics = EventAddress.Constants.ADAPTER_STATIC_QR_CREATE_ADDRESS,
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  public void processStaticQrCreateEvent(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    processStaticQrEvent(record, acknowledgment);
  }

  @KafkaListener(topics = Constants.ADAPTER_STATIC_QR_GET_ADDRESS,
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  public void processStaticQrGetEvent(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    processStaticQrEvent(record, acknowledgment);
  }
}