package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeCash;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.repositories.QrCodeCashRepository;
import ru.vtb.tsp.ia.epay.sbpadapter.services.InvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Slf4j
@Component(QrCodeCashCreationHandler.BEAN_NAME)
public class QrCodeCashCreationHandler extends AbstractEventHandler<SbpCashQrCreationResponseDto> {

  private static final SbpCashQrCreationResponseDto EMPTY_RESPONSE =
      SbpCashQrCreationResponseDto.builder().build();
  public static final String BEAN_NAME = Constants.CASH_QR_CRETE;
  private final InvocationFactory invocationFactory;
  private final QrCodeCashRepository qrCodeCashRepository;

  public QrCodeCashCreationHandler(KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper,
      InvocationFactory invocationFactory,
      QrCodeCashRepository qrCodeCashRepository) {
    super(kafkaService, transactionService, orderService, merchantSiteService, objectMapper);
    this.invocationFactory = invocationFactory;
    this.qrCodeCashRepository = qrCodeCashRepository;
  }

  @Override
  @Transactional
  public @NotNull SbpCashQrCreationResponseDto apply(@Nullable Event event) {
    return Optional.ofNullable(event)
        .map(e -> {
          try {
            final var request = objectMapper
                .convertValue(e.getPayload(), new TypeReference<SbpCashQrCreationRequestDto>() {
                });
            e.setPayload(request);
            final var response = invocationFactory.createCashQr(e);
            final var timeMark = LocalDateTime.now(ZoneOffset.UTC);
            qrCodeCashRepository.saveOrUpdate(QrCodeCash.builder()
                .qrcId(response.getData().getQrcId())
                .payload(response.getData().getPayload())
                .account(request.getAccount())
                .createdAt(timeMark)
                .merchantId(request.getMerchantId())
                .status(response.getData().getStatus())
                .redirectUrl(request.getRedirectUrl())
                .build());
            final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
                    .mstId(e.getMstId())
                    .code(e.getCode())
                    .type(e.getType())
                    .sentAt(timeMark)
                    .destination(Collections.singletonList(EventAddress.CASH_QR_CREATE))
                    .build())
                .payload(response)
                .build();
            kafkaService.sendToGateway(callback);
            return response;
          } catch (Exception ex) {
            log.error("Error occurred during cash qr creation, request {}", event.getPayload(), ex);
            throw new ServiceException(ApplicationException.CASH_QR_CREATION_ERROR);
          }
        })
        .orElse(EMPTY_RESPONSE);
  }
}