package ru.vtb.tsp.ia.epay.sbpadapter.utils;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmCode;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.QrCodeType;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.QrTemplateVersion;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.PaymentStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.QrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundConfirmationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundRegistrationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.RefundStatusInvocation;

public final class MapperUtils {

  private static final int MONEY_EXCHANGE_RATE = 100;
  private static final long MIN_QR_TTL = 5L;
  private static final long MAX_QR_TTL = 129_600L;
  private static final String PAYMENT_PURPOSE = "Платеж по заказу №";
  private static final String REFUND_PURPOSE = "Возврат по заказу №";
  private MapperUtils() {
  }

  public static boolean isEmptyParams(@NotNull TransactionPayload transaction) {
    return Objects.isNull(transaction)
        || Objects.isNull(transaction.getMerchant())
        || Objects.isNull(transaction.getMerchant().getMerchantSiteParams().getSbpParams());
  }

  public static EnumMap<QrCreationInvocation.Param, Object> mapQrCreation(
      @Nullable TransactionPayload transaction,
      @Nullable String agentId,
      @Nullable String memberId,
      @Nullable QrCodeType qrCodeType) {
    if (Objects.isNull(transaction) || isEmptyParams(transaction) || ObjectUtils.isEmpty(agentId)
        || ObjectUtils.isEmpty(agentId) || Objects.isNull(qrCodeType)) {
      return null;
    }
    final var params = transaction.getMerchant().getMerchantSiteParams().getSbpParams();
    final var result = new EnumMap<>(QrCreationInvocation.Param.class);
    result.put(QrCreationInvocation.Param.AGENT_ID, agentId);
    result.put(QrCreationInvocation.Param.MEMBER_ID, memberId);
    result.put(QrCreationInvocation.Param.LEGAL_ID, params.getLegalId());
    result.put(QrCreationInvocation.Param.ACCOUNT, params.getAccount());
    result.put(QrCreationInvocation.Param.MERCHANT_ID, params.getMerchantId());
    result.put(QrCreationInvocation.Param.TEMPLATE_VERSION,
        QrTemplateVersion.VERSION_01.getValue());
    result.put(QrCreationInvocation.Param.QRC_TYPE, qrCodeType.getValue());
    if (QrCodeType.DYNAMIC.equals(qrCodeType)) {
      result.put(QrCreationInvocation.Param.QRC_TTL,
          Math.max(Math.min(Duration.between(LocalDateTime.now(ZoneOffset.UTC),
              transaction.getOrderInfo().getExpiredAt()).toMinutes(), MAX_QR_TTL), MIN_QR_TTL));
    }
    result.put(QrCreationInvocation.Param.AMOUNT,
        Optional.ofNullable(transaction.getAmount())
            .map(Amount::getValue)
            .map(amount -> (long) (amount * MONEY_EXCHANGE_RATE))
            .map(Object::toString)
            .orElse(null));
    result.put(QrCreationInvocation.Param.CURRENCY,
        Optional.ofNullable(transaction.getAmount())
            .map(Amount::getCurrency)
            .orElse(null));
    result.put(QrCreationInvocation.Param.PAYMENT_PURPOSE,
        Objects.requireNonNullElse(transaction.getOrderInfo().getName(),
            PAYMENT_PURPOSE + transaction.getOrderInfo().getMstOrderId()));
    result.put(QrCreationInvocation.Param.ORDER_ID, transaction.getOrderInfo().getOrderId());
    result.put(QrCreationInvocation.Param.REQUEST_ID, transaction.getPaymentId());
    result.put(QrCreationInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

  public static EnumMap<CashQrCreationInvocation.Param, Object> mapCashQrCreation(
      @Nullable TransactionPayload transaction,
      @Nullable String agentId,
      @Nullable String memberId) {
    if (Objects.isNull(transaction) || isEmptyParams(transaction) || ObjectUtils.isEmpty(agentId)
        || ObjectUtils.isEmpty(agentId)) {
      return null;
    }
    final var params = transaction.getMerchant().getMerchantSiteParams().getSbpParams();
    final var result = new EnumMap<>(CashQrCreationInvocation.Param.class);
    result.put(CashQrCreationInvocation.Param.AGENT_ID, agentId);
    result.put(CashQrCreationInvocation.Param.MEMBER_ID, memberId);
    result.put(CashQrCreationInvocation.Param.MERCHANT_ID, params.getMerchantId());
    result.put(CashQrCreationInvocation.Param.ACCOUNT, params.getAccount());
    result.put(CashQrCreationInvocation.Param.REDIRECT_URL,
        transaction.getOrderInfo().getReturnUrl() /*TODO add redirect url*/);
    result.put(CashQrCreationInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

  public static EnumMap<RefundRegistrationInvocation.Param, Object> mapRefundRegistration(
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction) || Objects.isNull(transaction.getPaymentData())
        || isEmptyParams(transaction)) {
      return null;
    }
    final var params = transaction.getMerchant().getMerchantSiteParams().getSbpParams();
    final var result = new EnumMap<>(RefundRegistrationInvocation.Param.class);
    result.put(RefundRegistrationInvocation.Param.LEGAL_ID, params.getLegalId());
    result.put(RefundRegistrationInvocation.Param.ACCOUNT, params.getAccount());
    result.put(RefundRegistrationInvocation.Param.MERCHANT_ID, params.getMerchantId());
    result.put(RefundRegistrationInvocation.Param.INTR_BK_STTLM_AMT,
        transaction.getAmount().getValue().toString());
    result.put(RefundRegistrationInvocation.Param.TX_ID,
        ((Sbp) transaction.getPaymentData()).getOperationId());
    result.put(RefundRegistrationInvocation.Param.USTRD,
        REFUND_PURPOSE + transaction.getOrderInfo().getMstOrderId());
    result.put(RefundRegistrationInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

  public static EnumMap<RefundConfirmationInvocation.Param, Object> mapRefundConfirmation(
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction) || Objects.isNull(transaction.getPaymentData())) {
      return null;
    }
    final var result = new EnumMap<>(RefundConfirmationInvocation.Param.class);
    result.put(RefundConfirmationInvocation.Param.MSG_ID,
        ((Sbp) transaction.getPaymentData()).getMsgId());
    result.put(RefundConfirmationInvocation.Param.PRTRY, SbpRefundConfirmCode.OK);
    result.put(RefundConfirmationInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

  public static EnumMap<PaymentStatusInvocation.Param, Object> mapPaymentStatus(
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction) || Objects.isNull(transaction.getPaymentData())) {
      return null;
    }
    final var result = new EnumMap<>(PaymentStatusInvocation.Param.class);
    result.put(PaymentStatusInvocation.Param.QID, UUID.randomUUID().toString());
    result.put(PaymentStatusInvocation.Param.QRC_ID,
        ((Sbp) transaction.getPaymentData()).getQrcId());
    result.put(PaymentStatusInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

  public static EnumMap<CashQrStatusInvocation.Param, Object> mapCashQrStatus(
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction) || Objects.isNull(transaction.getPaymentData())
        || Objects.isNull(transaction.getContext())) {
      return null;
    }
    final var result = new EnumMap<>(CashQrStatusInvocation.Param.class);
    result.put(CashQrStatusInvocation.Param.PARAMS_ID, transaction.getContext().get(
        TransactionInfoKey.SBP_PARAMS_ID.getValue()));
    result.put(CashQrStatusInvocation.Param.QRC_ID,
        ((Sbp) transaction.getPaymentData()).getQrcId());
    return result;
  }

  public static EnumMap<RefundStatusInvocation.Param, Object> mapRefundStatus(
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(transaction) || Objects.isNull(transaction.getPaymentData())) {
      return null;
    }
    final var result = new EnumMap<>(RefundStatusInvocation.Param.class);
    result.put(RefundStatusInvocation.Param.MSG_ID,
        ((Sbp) transaction.getPaymentData()).getMsgId());
    result.put(RefundStatusInvocation.Param.TRANSACTION_ID, transaction.getTransactionId());
    return result;
  }

}