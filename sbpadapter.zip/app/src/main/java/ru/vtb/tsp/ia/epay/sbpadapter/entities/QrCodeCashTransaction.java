package ru.vtb.tsp.ia.epay.sbpadapter.entities;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

@Table(QrCodeCashTransaction.TABLE_NAME)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class QrCodeCashTransaction {

  public static final String TABLE_NAME = "qr_code_cash_transactions";

  @Id
  @Column("id")
  private Long id;

  @NotNull
  @MappedCollection(
      idColumn = "id"
  )
  //@Column("qr_cash_ref")
  private QrCodeCash parent;

  @NotEmpty
  @Column("qrc_id")
  private String qrcId;

  @NotNull
  private BigDecimal amount;

  private String currency;

  @Column("payment_purpose")
  private String paymentPurpose;

  private String extra;

  @NotNull
  @Column("created_at")
  private LocalDateTime createdAt;

  @Column("qr_ttl")
  private Integer qrTtl;

  @Column("params_id")
  private String paramsId;

  @NotEmpty
  private String status;

}