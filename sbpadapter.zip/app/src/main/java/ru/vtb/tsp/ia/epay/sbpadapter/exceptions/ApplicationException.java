package ru.vtb.tsp.ia.epay.sbpadapter.exceptions;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ApplicationException {

  PAYMENT_DECLINED_ERROR("10200001", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_NOT_PERMITTED", "Платеж отклонен. Проверьте реквизиты платежа"),
  PAYMENT_EXECUTION_ERROR("10200002", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_BAD_REQUEST", "Ошибка исполнения платежа"),
  PAYMENT_CREATION_ERROR("10200003", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_UNPROCESSABLE_ENTITY", "Ошибка формирования платежа"),
  INTERNAL_ERROR("10200004", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_INTERNAL_SERVER_ERROR", "Внутренняя ошибка сервиса"),
  BAD_GATEWAY_ERROR("10200005", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_BAD_GATEWAY", "Внутренняя ошибка сервиса"),
  QR_IMAGE_CREATION_ERROR("10200006", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_QR_IMAGE_CREATION_ERROR", "Значение qrcId для получения изображения qr кода не найдено"),
  CASH_QR_CREATION_ERROR("10200007", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_CASH_QR_CREATION_ERROR", "Ошибка создания кассовой ссылки"),
  CASH_QR_ACTIVATION_ERROR("10200008", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_CASH_QR_ACTIVATION_ERROR", "Ошибка активации кассовой ссылки"),
  CASH_QR_DEACTIVATION_ERROR("10200009", HttpStatus.PAYMENT_REQUIRED.value(),
      "SBP_CASH_QR_DEACTIVATION_ERROR", "Ошибка деактивации кассовой ссылки");

  private final String id;
  private final Integer httpCode;
  private final String message;
  private final String description;

}