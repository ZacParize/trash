package ru.vtb.tsp.ia.epay.sbpadapter.services;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.epa.EpaAuthRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.EpaAuthApi;

@Slf4j
@Service
public class EpaAuthService {

  private static final String BEARER = "Bearer ";

  private final EpaAuthApi epaAuthApi;
  private final String grantType;
  private final String clientId;
  private final String clientSecret;

  public EpaAuthService(EpaAuthApi epaAuthApi,
      @Value("${epa.ig.grant.type}") String grantType,
      @Value("${epa.ig.client.id}") String clientId,
      @Value("${epa.ig.client.secret}") String clientSecret) {
    Assert.hasText(grantType, "Epa ig grant type can't be null or empty");
    Assert.hasText(grantType, "Epa ig client id can't be null or empty");
    Assert.hasText(grantType, "Epa ig client secret can't be null or empty");
    this.epaAuthApi = epaAuthApi;
    this.grantType = grantType;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  public String getToken() {
    try {
      var tokenResponse = epaAuthApi.getToken(EpaAuthRequestDto.builder()
          .client_secret(clientSecret)
          .client_id(clientId)
          .grant_type(grantType)
          .build());
      if (tokenResponse != null && tokenResponse.getAccessToken() != null) {
        return BEARER + tokenResponse.getAccessToken();
      }
      throw new IllegalArgumentException(
          "Token response is invalid. Not able to receive epa-ig token");
    } catch (Exception e) {
      log.error(e.getMessage());
      throw new IllegalArgumentException(
          "Token response is invalid. Not able to receive epa-ig token");
    }
  }

}
