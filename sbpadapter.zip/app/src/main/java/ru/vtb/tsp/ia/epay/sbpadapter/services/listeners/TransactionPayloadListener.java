package ru.vtb.tsp.ia.epay.sbpadapter.services.listeners;

import java.util.Optional;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.sbpadapter.services.InvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;

@Slf4j
@Component(TransactionPayloadListener.BEAN_NAME)
public class TransactionPayloadListener implements Consumer<TransactionPayload> {

  public static final String BEAN_NAME = "transactionPayloadListener";

  private final InvocationFactory invocationFactory;
  private final KafkaService kafkaService;
  private final String applicationName;

  public TransactionPayloadListener(InvocationFactory invocationFactory,
      KafkaService kafkaService,
      @Value("${spring.application.name}") String applicationName) {
    Assert.hasText(applicationName, "Application name can't be null or empty");
    this.invocationFactory = invocationFactory;
    this.kafkaService = kafkaService;
    this.applicationName = applicationName;
  }

  @Override
  public void accept(@Nullable TransactionPayload transactionPayload) {
    Optional.ofNullable(transactionPayload).ifPresent(transaction -> {
      if (transaction.isCompleted()) {
        // nothing to do with completed transaction
        return;
      }
      // add information about visit
      transaction.getRoute().addVisitedService(applicationName);
      // process transaction
      invocationFactory.create(transaction);
      // send to next route point only executed transactions
      if (transaction.isCompleted()) {
        // send transaction to portal
        kafkaService.sendToPortal(transaction);
        // send transaction to next route point
        kafkaService.sendToBox(transaction);
      }
    });
  }
}