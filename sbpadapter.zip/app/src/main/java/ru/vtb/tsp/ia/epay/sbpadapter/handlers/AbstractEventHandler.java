package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Objects;
import java.util.function.Function;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Slf4j
public abstract class AbstractEventHandler<T extends Serializable> implements Function<Event, T> {

  protected final KafkaService kafkaService;
  protected final TransactionService transactionService;
  protected final OrderService orderService;
  protected final MerchantSiteService merchantSiteService;
  protected final ObjectMapper objectMapper;

  public AbstractEventHandler(
      KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper) {
    this.kafkaService = kafkaService;
    this.transactionService = transactionService;
    this.orderService = orderService;
    this.merchantSiteService = merchantSiteService;
    this.objectMapper = objectMapper;
  }

  public void onError(Event event, Exception ex) {
    if (Objects.isNull(event) || !(ex instanceof final ServiceException serviceException)) {
      return;
    }
    final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
            .mstId(event.getMstId())
            .code(event.getCode())
            .type(event.getType())
            .sentAt(LocalDateTime.now(ZoneOffset.UTC))
            .destination(Collections.singletonList(EventAddress.findByName(event.getType().name())))
            .build())
        .payload(serviceException.toDto())
        .build();
    kafkaService.sendToGateway(callback);
  }

  @Transactional
  public void declineCashOrderAndTransactionByQrcIdAndMst(@Nullable String qrcId,
      @Nullable String mstId) {
    if (ObjectUtils.isEmpty(qrcId) || ObjectUtils.isEmpty(mstId)) {
      return;
    }
    transactionService.getByKeyAndValueAndState(TransactionInfoKey.SBP_QR_ID, qrcId,
            TransactionState.SBP_PAYMENT_CREATED, null)
        .stream()
        .map(Transaction::getOrder)
        .filter(order -> ObjectUtils.nullSafeEquals(mstId, order.getMst().getId()))
        .forEach(order -> {
          final var transactions = transactionService.getByOrderId(order.getOrderId());
          if (Order.calculatePayedAmount(transactions) != 0d) {
            return;
          }
          transactions.parallelStream()
              .filter(transaction -> !TransactionState.isCompleted(transaction.getState()))
              .forEach(transaction -> {
                transaction.setState(TransactionState.DECLINED);
                transaction.getData().getOrderInfo().setOrderState(OrderState.DECLINED);
                transactionService.upsert(transaction);
                kafkaService.sendToPortal(transaction.getData());
              });
          if (!order.isCompleted()) {
            orderService.upsert(order.withState(OrderState.DECLINED));
          }
        });
  }
}