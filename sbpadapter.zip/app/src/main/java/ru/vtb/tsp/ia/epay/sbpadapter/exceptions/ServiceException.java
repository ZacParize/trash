package ru.vtb.tsp.ia.epay.sbpadapter.exceptions;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.errors.ErrorDto;

public class ServiceException extends RuntimeException {

  protected ApplicationException exception;
  private String traceId;

  public ServiceException() {
  }

  public ServiceException(ApplicationException exception) {
    this.exception = exception;
  }

  public ServiceException(ApplicationException exception, String traceId) {
    this.exception = exception;
    this.traceId = traceId;
  }

  public ServiceException(String message) {
    super(message);
  }

  public ServiceException(String traceId, String message, Throwable cause) {
    super(message, cause);
    this.traceId = traceId;
  }

  public ServiceException(String traceId, Throwable cause) {
    super(cause);
    this.traceId = traceId;
  }

  public String getId () {
    return Optional.ofNullable(exception)
        .map(ApplicationException::getId).orElse(null);
  }

  public Integer getHttpCode () {
    return Optional.ofNullable(exception)
        .map(ApplicationException::getHttpCode).orElse(null);
  }

  public String getMessage () {
    return Optional.ofNullable(exception)
        .map(ApplicationException::getMessage).orElse(null);
  }

  public String getDescription () {
    return Optional.ofNullable(exception)
        .map(ApplicationException::getDescription).orElse(null);
  }

  public ErrorDto toDto() {
    return ErrorDto.builder()
        .id(getId())
        .message(getMessage())
        .description(getDescription() + " (" + getId() + ")")
        .traceId(traceId)
        .build();
  }

}