package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.CurrencyService;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.InvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Slf4j
@Component(QrCodeCashActivationHandler.BEAN_NAME)
public class QrCodeCashActivationHandler extends
    AbstractEventHandler<SbpCashQrActivationResponseDto> {

  public static final String BEAN_NAME = Constants.CASH_QR_ACTIVATE;
  private static final SbpCashQrActivationResponseDto EMPTY_RESPONSE =
      SbpCashQrActivationResponseDto.builder().build();
  private static final List<String> CURRENCIES = List.of("RUB", "RUR");
  private static final int QR_TTL_DEFAULT = 5;
  private static final Map<String, Currency> CURRENCY_MAP = new ConcurrentHashMap<>();
  private final InvocationFactory invocationFactory;

  public QrCodeCashActivationHandler(
      KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper,
      InvocationFactory invocationFactory,
      CurrencyService currencyService) {
    super(kafkaService, transactionService, orderService, merchantSiteService, objectMapper);
    this.invocationFactory = invocationFactory;
    CURRENCIES.forEach(currency ->
        CURRENCY_MAP.put(currency, currencyService.getById(currency).orElseThrow()));
  }

  @Override
  @Transactional
  public @NotNull SbpCashQrActivationResponseDto apply(@Nullable Event event) {
    return Optional.ofNullable(event)
        .map(e -> {
          try {
            final var eventPayload = objectMapper
                .convertValue(e.getPayload(), new TypeReference<SbpCashQrActivationRequestDto>() {
                });
            eventPayload.setCurrency(
                Objects.requireNonNullElse(eventPayload.getCurrency(), CURRENCIES.get(0)));
            eventPayload.setQrTtl(
                Objects.requireNonNullElse(eventPayload.getQrTtl(), QR_TTL_DEFAULT));
            e.setPayload(eventPayload);
            final var rubAmountInString = eventPayload.getAmount();
            eventPayload.setAmount(String.valueOf((long)
                (Double.parseDouble(rubAmountInString) * 100)));
            final var response = invocationFactory.activateCashQr(e);
            if (Objects.isNull(response.getData())) {
              return response;
            }
            final var rubAmountInDouble = Double.parseDouble(response.getData().getAmount()) / 100;
            response.getData().setAmount(String.valueOf(rubAmountInDouble));
            eventPayload.setAmount(rubAmountInString);
            final var paramsId = response.getData().getParamsId();
            final var mst = merchantSiteService
                .getById(event.getMstId())
                .orElseThrow();
            declineCashOrderAndTransactionByQrcIdAndMst(eventPayload.getQrcId(), mst.getId());
            orderService.create(
                    Objects.requireNonNull(CURRENCY_MAP.get(eventPayload.getCurrency())),
                    mst,
                    paramsId,
                    rubAmountInDouble,
                    0d,
                    LocalDateTime.now(ZoneOffset.UTC),
                    null,
                    LocalDateTime.now().plus(eventPayload.getQrTtl(), ChronoUnit.MINUTES),
                    OrderType.PAYMENT,
                    paramsId,
                    paramsId,
                    null,
                    null,
                    null,
                    SourceSystem.ECOM,
                    null,
                    null,
                    null,
                    null)
                .flatMap(orderService::upsert)
                .flatMap(transactionService::createSbpPayment)
                .map(tx -> {
                  tx.getData().getContext()
                      .put(TransactionInfoKey.SBP_PARAMS_ID.getValue(), paramsId);
                  ((Sbp) tx.getData().getPaymentData()).setQrcId(eventPayload.getQrcId());
                  return tx.withState(TransactionState.SBP_PAYMENT_CREATED);
                })
                .flatMap(transactionService::upsert)
                .ifPresent(tx -> {
                  final var createdAt = LocalDateTime.now(ZoneOffset.UTC);
                  MDC.put(MDCKeySupplier.UNIQUE_KEY, tx.getOrder().getOrderId());
                  transactionService.upsertInfo(tx.getTransactionId(),
                      TransactionInfoKey.SBP_PARAMS_ID,
                      response.getData().getParamsId(), createdAt);
                  transactionService.upsertInfo(tx.getTransactionId(), TransactionInfoKey.SBP_EXTRA,
                      eventPayload.getExtra(), createdAt);
                  transactionService.upsertInfo(tx.getTransactionId(),
                      TransactionInfoKey.SBP_PAYMENT_PURPOSE,
                      eventPayload.getPaymentPurpose(), createdAt);
                  transactionService.upsertInfo(tx.getTransactionId(),
                      TransactionInfoKey.SBP_QR_TTL,
                      eventPayload.getQrTtl().toString(), createdAt);
                  transactionService.upsertInfo(tx.getTransactionId(), TransactionInfoKey.SBP_QR_ID,
                      eventPayload.getQrcId(), createdAt);
                  kafkaService.sendToPortal(tx.getData());
                  response.getData().setTransactionCode(tx.getCode());
                  response.getData().setOrderCode(tx.getOrder().getCode());
                });
            final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
                    .mstId(e.getMstId())
                    .code(e.getCode())
                    .type(e.getType())
                    .sentAt(LocalDateTime.now(ZoneOffset.UTC))
                    .destination(Collections.singletonList(EventAddress.CASH_QR_ACTIVATE))
                    .build())
                .payload(response)
                .build();
            kafkaService.sendToGateway(callback);
            return response;
          } catch (Exception ex) {
            log.error("Error occurred during cash qr activation, request {}", e.getPayload(), ex);
            throw new ServiceException(ApplicationException.CASH_QR_ACTIVATION_ERROR);
          }
        })
        .orElse(EMPTY_RESPONSE);
  }
}