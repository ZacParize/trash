package ru.vtb.tsp.ia.epay.sbpadapter.configs.properties.standin;

import lombok.Data;
import org.springframework.util.ObjectUtils;
import ru.vtb.smartreplication.core.ssl.IKeyStoreSslConfiguration;

@Data
public class EtcdSslProperties implements IKeyStoreSslConfiguration {

  private static final String DEFAULT_STORE_PROVIDER = "SunJSSE";
  private String keyStorePath;
  private String keyStorePassword;
  private String trustStorePath;
  private String trustStorePassword;
  private String keyAlias;
  private String keyStoreType;
  private String trustStoreType;

  @Override
  public String getKeyStorePath() {
    return keyStorePath;
  }

  @Override
  public char[] getKeyStorePassword() {
    return ObjectUtils.isEmpty(keyStorePassword) ? new char[0] : keyStorePassword.toCharArray();
  }

  @Override
  public String getTrustStorePath() {
    return trustStorePath;
  }

  @Override
  public char[] getTrustStorePassword() {
    return ObjectUtils.isEmpty(trustStorePassword) ? new char[0] : trustStorePassword.toCharArray();
  }

  @Override
  public String getKeyAlias() {
    return keyAlias;
  }

  @Override
  public String getKeyStoreType() {
    return keyStoreType;
  }

  @Override
  public String getKeyStoreProvider() {
    return DEFAULT_STORE_PROVIDER;
  }

  @Override
  public String getTrustStoreType() {
    return trustStoreType;
  }

  @Override
  public String getTrustStoreProvider() {
    return DEFAULT_STORE_PROVIDER;
  }
}
