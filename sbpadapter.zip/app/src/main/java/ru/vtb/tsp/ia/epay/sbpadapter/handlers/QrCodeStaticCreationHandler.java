package ru.vtb.tsp.ia.epay.sbpadapter.handlers;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeStatic;
import ru.vtb.tsp.ia.epay.sbpadapter.repositories.QrCodeStaticRepository;
import ru.vtb.tsp.ia.epay.sbpadapter.services.InvocationFactory;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Component(QrCodeStaticCreationHandler.BEAN_NAME)
public class QrCodeStaticCreationHandler extends AbstractEventHandler<SbpQrCodeResponseDto> {

  public static final String BEAN_NAME = Constants.STATIC_QR_CREATE;
  private final InvocationFactory invocationFactory;
  private final QrCodeStaticRepository qrCodeStaticRepository;

  public QrCodeStaticCreationHandler(
      KafkaService kafkaService,
      TransactionService transactionService,
      OrderService orderService,
      MerchantSiteService merchantSiteService,
      ObjectMapper objectMapper,
      InvocationFactory invocationFactory,
      QrCodeStaticRepository qrCodeStaticRepository) {
    super(kafkaService, transactionService, orderService, merchantSiteService, objectMapper);
    this.invocationFactory = invocationFactory;
    this.qrCodeStaticRepository = qrCodeStaticRepository;
  }

  @Override
  @Transactional
  public SbpQrCodeResponseDto apply(Event event) {
    return Optional.ofNullable(event)
        .map(e -> {
          final var request = objectMapper
              .convertValue(e.getPayload(), new TypeReference<SbpQrCodeCreationRequestDto>(){});
          e.setPayload(request);
          final var response = invocationFactory.createStaticQr(e);
          final var timeMark = LocalDateTime.now(ZoneOffset.UTC);
          final var entity = qrCodeStaticRepository.saveOrUpdate(QrCodeStatic.builder()
              .account(request.getAccount())
              .payload(response.getData().getPayload())
              .amount(new BigDecimal(request.getAmount()))
              .currency(request.getCurrency())
              .legalId(request.getLegalId())
              .createdAt(timeMark)
              .merchantId(request.getMerchantId())
              .qState(response.getData().getStatus().name())
              .qrcId(response.getData().getQrcId())
              .orderId(response.getOrderId())
              .purpose(request.getPaymentPurpose())
              .qCode(response.getCode())
              .qReason(response.getMessage())
              .build());
          final var callback = EventImpl.builder().header(EventHeaderImpl.builder()
                  .mstId(e.getMstId())
                  .code(e.getCode())
                  .type(EventType.STATIC_QR_CREATE)
                  .sentAt(timeMark)
                  .destination(Collections.singletonList(EventAddress.STATIC_QR_CREATE))
                  .build())
              .payload(response)
              .build();
          kafkaService.sendToGateway(callback);
          return response;
        })
        .orElse(SbpQrCodeResponseDto.builder().build());
  }
}
