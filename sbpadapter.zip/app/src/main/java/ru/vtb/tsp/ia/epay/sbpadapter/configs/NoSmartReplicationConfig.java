package ru.vtb.tsp.ia.epay.sbpadapter.configs;

import javax.sql.DataSource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;


@Configuration
@ConditionalOnProperty(prefix = "smart-replication", name = "enable", havingValue = "false")
@Slf4j
@RequiredArgsConstructor
public class NoSmartReplicationConfig {


  @Bean
  @ConfigurationProperties("spring.datasource.main")
  public DataSourceProperties mainDatasourceProperties() {
    return new DataSourceProperties();
  }

  @Bean("datasource")
  @ConfigurationProperties("spring.datasource.main.hikari")
  public DataSource mainDataSource() {
    return mainDatasourceProperties().initializeDataSourceBuilder().build();
  }

}
