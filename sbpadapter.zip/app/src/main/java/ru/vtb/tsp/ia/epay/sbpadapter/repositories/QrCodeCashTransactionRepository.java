package ru.vtb.tsp.ia.epay.sbpadapter.repositories;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeCash;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeCashTransaction;

public interface QrCodeCashTransactionRepository extends CrudRepository<QrCodeCashTransaction, Long> {

  String COMMON_SELECT =
      "select "
          + "qct.id as id, "
          + "qc.id as parent_id, "
          + "qc.payload as parent_payload, "
          + "qc.status as parent_status, "
          + "qc.redirect_url as parent_redirect_url, "
          + "qc.account as parent_account, "
          + "qc.created_at as parent_created_at, "
          + "qc.merchant_id as parent_merchant_id, "
          + "qct.qrc_id, "
          + "qct.amount, "
          + "qct.currency, "
          + "qct.payment_purpose, "
          + "qct.extra, "
          + "qct.created_at, "
          + "qct.qr_ttl, "
          + "qct.params_id, "
          + "qct.status "
          + "from " + QrCodeCashTransaction.TABLE_NAME + " qct "
          + "inner join " + QrCodeCash.TABLE_NAME + " qc on qc.id = qct.qr_cash_ref";

  @NotNull
  @Query(COMMON_SELECT + " where qct.qrc_id = :qrcId")
  Optional<QrCodeCashTransaction> findByQrcId(String qrcId);

  @NotNull
  @Query("insert into " + QrCodeCashTransaction.TABLE_NAME + " (qr_cash_ref, qrc_id, amount, "
      + "currency, payment_purpose, extra, created_at, qr_ttl, params_id, status) "
      + "values (:parent, :qrcId, :amount, :currency, :paymentPurpose, :extra, :createdAt, "
      + ":qrTtl, :paramsId, :status) "
      + "on conflict (qrc_id) do update set qr_cash_ref = :parent, amount = :amount, "
      + "currency = :currency, payment_purpose = :paymentPurpose, extra = :extra, "
      + "created_at = :createdAt, qr_ttl = :qrTtl, params_id = :paramsId, status = :status "
      + "where " + QrCodeCashTransaction.TABLE_NAME + ".qrc_id = :qrcId RETURNING *")
  QrCodeCashTransaction saveOrUpdate(long parent,
      String qrcId,
      BigDecimal amount,
      String currency,
      String paymentPurpose,
      String extra,
      LocalDateTime createdAt,
      Integer qrTtl,
      String paramsId,
      String status);

  @NotNull
  default QrCodeCashTransaction saveOrUpdate(QrCodeCashTransaction entity) {
    return saveOrUpdate(Objects.requireNonNull(entity.getParent()).getId(),
        entity.getQrcId(),
        entity.getAmount(),
        entity.getCurrency(),
        entity.getPaymentPurpose(),
        entity.getExtra(),
        entity.getCreatedAt(),
        entity.getQrTtl(),
        entity.getParamsId(),
        entity.getStatus());
  }

}
