package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.ConfirmRefundResponseParser.BEAN_NAME;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmCode;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;

@Slf4j
@Component(BEAN_NAME)
public class ConfirmRefundResponseParser extends
    AbstractResponseParser<SbpConfirmRefundResponseDto> {

  public static final String BEAN_NAME = "confirmRefundResponseParser";

  public ConfirmRefundResponseParser(TransactionService transactionService) {
    super(transactionService);
  }

  @Override
  public void accept(@Nullable SbpConfirmRefundResponseDto response,
                     @Nullable TransactionPayload transaction) {
    if (Objects.isNull(response) || Objects.isNull(transaction) || transaction.isCompleted()) {
      return;
    }
    Optional.ofNullable(response.getErrCode())
        .filter(ObjectUtils::isEmpty)
        .ifPresentOrElse(
            errCode -> {
              transaction.setError(
                  TransactionError.builder()
                      .id(ApplicationException.PAYMENT_DECLINED_ERROR.getId())
                      .httpCode(ApplicationException.PAYMENT_DECLINED_ERROR.getHttpCode())
                      .message(ApplicationException.PAYMENT_DECLINED_ERROR.getMessage())
                      .description(ApplicationException.PAYMENT_DECLINED_ERROR.getDescription())
                      .traceId(transaction.getTransactionCode())
                      .build());
              transaction.setStatus(TransactionState.DECLINED);
              transactionService.updateDataById(transaction.getTransactionId(), transaction);
              log.info("Refund confirmation for transaction id {} was declined with code {}",
                  transaction.getTransactionId(), errCode);
            },
            () -> {
              final var sbpTransaction = (Sbp) transaction.getPaymentData();
              sbpTransaction.setPrtry(SbpRefundConfirmCode.OK.name());
              MDC.put(MDCKeySupplier.UNIQUE_KEY, transaction.getOrderInfo().getOrderId());
              transactionService.upsertInfo(transaction.getTransactionId(),
                  TransactionInfoKey.SBP_PRTRY,
                  SbpRefundConfirmCode.OK.name(),
                  LocalDateTime.now(ZoneOffset.UTC));
              transaction.setStatus(TransactionState.SBP_REFUND_CREATED);
              transactionService.updateDataById(transaction.getTransactionId(), transaction);
              log.info("Refund confirmation for transaction id {} was successfully processed",
                  transaction.getTransactionId());
            });
  }
}