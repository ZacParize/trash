package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.EpaAuthApi;

@ConditionalOnProperty(name = "epa.ig.mock", havingValue = "false")
@FeignClient(name = "epaAuthApiClient", url = "${epa.ig.url}",
    //configuration = { SslFeignConfiguration.class },
    decode404 = true)
public interface EpaAuthApiClient extends EpaAuthApi {

}