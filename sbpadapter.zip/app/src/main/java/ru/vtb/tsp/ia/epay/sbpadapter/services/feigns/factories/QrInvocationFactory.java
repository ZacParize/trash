package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.factories;

import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.QrCodeType;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrActivationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrDeactivationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.CashQrStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.ImageQrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.PaymentStatusInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.QrCreationInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.SbpInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.SbpTykInvocation;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.AbstractResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.PaymentStatusResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.QrResponseParser;
import ru.vtb.tsp.ia.epay.sbpadapter.utils.MapperUtils;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;

@Slf4j
@Service
public class QrInvocationFactory {

  private final Map<String, SbpInvocation<?>> sbpInvocations;
  private final Map<String, SbpTykInvocation<?>> sbpTykInvocations;
  private final Map<String, AbstractResponseParser<?>> parsers;
  private final String agentId;
  private final String memberId;

  public QrInvocationFactory(Map<String, SbpInvocation<?>> sbpInvocations,
      Map<String, SbpTykInvocation<?>> sbpTykInvocations,
      Map<String, AbstractResponseParser<?>> parsers,
      @Value("${app.sbp.agent-id}") String agentId,
      @Value("${app.sbp.member-id}") String memberId) {
    Assert.hasText(agentId, "Sbp agent-id can't be null or empty");
    Assert.hasText(memberId, "Sbp member-id can't be null or empty");
    this.sbpInvocations = sbpInvocations;
    this.sbpTykInvocations = sbpTykInvocations;
    this.parsers = parsers;
    this.agentId = agentId;
    this.memberId = memberId;
  }

  private @Nullable ResponseEntity<SbpQrCodeResponseDto> invokeCreateQr(
      @NotNull TransactionPayload transaction,
      @NotNull QrCreationInvocation invocation,
      @NotNull QrCodeType qrCodeType) {
    try {
      return invocation.invoke(
          MapperUtils.mapQrCreation(transaction, agentId, memberId, qrCodeType));
    } catch (Exception ex) {
      parsers.get(QrResponseParser.BEAN_NAME).onError(transaction,
          ex instanceof ServiceException ? (ServiceException) ex
              : new ServiceException(ApplicationException.INTERNAL_ERROR));
      log.error("Qr creation request error, transaction id {} was declined",
          transaction.getTransactionId(), ex);
      return null;
    }
  }

  public void createQr(@NotNull TransactionPayload transaction,
      @NotNull QrCodeType qrCodeType) {
    log.info("Received qr creation request for transaction with id {}",
        transaction.getTransactionId());
    Optional.ofNullable((QrCreationInvocation) sbpInvocations.get(QrCreationInvocation.BEAN_NAME))
        .map(invocation -> invokeCreateQr(transaction, invocation, qrCodeType))
        .filter(response -> Objects.nonNull(response.getBody()))
        .ifPresent(response -> ((QrResponseParser) parsers.get(QrResponseParser.BEAN_NAME))
            .accept(response.getBody(), transaction));
  }

  public SbpImageQrCreationResponseDto createImageQr(@NotNull Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpImageQrCreationRequestDto eventPayload)) {
      return SbpImageQrCreationResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(ImageQrCreationInvocation.Param.class);
    enumMap.put(ImageQrCreationInvocation.Param.QRC_ID, eventPayload.getQrcId());
    Optional.ofNullable(eventPayload.getWidth())
        .ifPresent(width -> enumMap.put(ImageQrCreationInvocation.Param.WIDTH, width));
    Optional.ofNullable(eventPayload.getHeight())
        .ifPresent(height -> enumMap.put(ImageQrCreationInvocation.Param.HEIGHT, height));
    log.info("Received Image QR creation request {}", eventPayload);
    return Optional.ofNullable(
            (ImageQrCreationInvocation) sbpTykInvocations.get(ImageQrCreationInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(enumMap))
        .map(HttpEntity::getBody)
        .orElse(SbpImageQrCreationResponseDto.builder().build());
  }

  public @NotNull SbpCashQrCreationResponseDto createCashQr(@Nullable Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpCashQrCreationRequestDto eventPayload)) {
      return SbpCashQrCreationResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(CashQrCreationInvocation.Param.class);
    enumMap.put(CashQrCreationInvocation.Param.MERCHANT_ID, eventPayload.getMerchantId());
    enumMap.put(CashQrCreationInvocation.Param.ACCOUNT, eventPayload.getAccount());
    Optional.ofNullable(eventPayload.getAgentId()).ifPresent(agentId -> enumMap.put(CashQrCreationInvocation.Param.AGENT_ID, agentId));
    Optional.ofNullable(eventPayload.getMemberId()).ifPresent(memberId -> enumMap.put(CashQrCreationInvocation.Param.MEMBER_ID, memberId));
    Optional.ofNullable(eventPayload.getRedirectUrl()).ifPresent(redirectUrl -> enumMap.put(CashQrCreationInvocation.Param.REDIRECT_URL, redirectUrl));
    log.info("Received Cash QR creation request {}", eventPayload);
    return Optional.ofNullable(
            (CashQrCreationInvocation) sbpTykInvocations.get(CashQrCreationInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(enumMap))
        .map(HttpEntity::getBody)
        .orElse(SbpCashQrCreationResponseDto.builder().build());
  }

  public @NotNull SbpCashQrActivationResponseDto activateCashQr(@Nullable Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpCashQrActivationRequestDto eventPayload)) {
      return SbpCashQrActivationResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(CashQrActivationInvocation.Param.class);
    enumMap.put(CashQrActivationInvocation.Param.QRC_ID, eventPayload.getQrcId());
    enumMap.put(CashQrActivationInvocation.Param.AMOUNT, eventPayload.getAmount());
    Optional.ofNullable(eventPayload.getCurrency()).ifPresent(currency -> enumMap.put(CashQrActivationInvocation.Param.CURRENCY, currency));
    Optional.ofNullable(eventPayload.getQrTtl()).ifPresent(qrTtl -> enumMap.put(CashQrActivationInvocation.Param.QR_TTL, qrTtl));
    Optional.ofNullable(eventPayload.getExtra()).ifPresent(extra -> enumMap.put(CashQrActivationInvocation.Param.EXTRA, extra));
    Optional.ofNullable(eventPayload.getPaymentPurpose()).ifPresent(paymentPurpose -> enumMap.put(CashQrActivationInvocation.Param.PAYMENT_PURPOSE, paymentPurpose));
    enumMap.put(CashQrActivationInvocation.Param.QR_TTL, eventPayload.getQrTtl());
    log.info("Received Cash QR activation request {}", eventPayload);
    return Optional.ofNullable(
            (CashQrActivationInvocation) sbpTykInvocations.get(CashQrActivationInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(enumMap))
        .map(HttpEntity::getBody)
        .orElse(SbpCashQrActivationResponseDto.builder().build());
  }

  public @NotNull SbpCashQrDeactivationResponseDto deactivateCashQr(@Nullable Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpCashQrDeactivationRequestDto eventPayload)) {
      return SbpCashQrDeactivationResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(CashQrDeactivationInvocation.Param.class);
    enumMap.put(CashQrDeactivationInvocation.Param.QRC_ID, eventPayload.getQrcId());
    log.info("Received Cash QR deactivation request {}", eventPayload);
    return Optional.ofNullable(
            (CashQrDeactivationInvocation) sbpTykInvocations.get(CashQrDeactivationInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(enumMap))
        .map(HttpEntity::getBody)
        .orElse(SbpCashQrDeactivationResponseDto.builder().build());
  }

  public @NotNull SbpCashQrStatusResponseDto getStatusCashQr(@Nullable Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpCashQrStatusRequestDto eventPayload)) {
      return SbpCashQrStatusResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(CashQrStatusInvocation.Param.class);
    enumMap.put(CashQrStatusInvocation.Param.QRC_ID, eventPayload.getQrcId());
    enumMap.put(CashQrStatusInvocation.Param.PARAMS_ID, eventPayload.getParamsId());
    return getStatusCashQr(enumMap);
  }

  private SbpCashQrStatusResponseDto getStatusCashQr(
      @Nullable EnumMap<CashQrStatusInvocation.Param, Object> params) {
    if (Objects.isNull(params)) {
      return SbpCashQrStatusResponseDto.builder().build();
    }
    log.info("Received Cash QR status request {}", params);
    return Optional.ofNullable(
            (CashQrStatusInvocation) sbpTykInvocations.get(CashQrStatusInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(params))
        .map(HttpEntity::getBody)
        .orElse(SbpCashQrStatusResponseDto.builder().build());
  }

  @Transactional
  public @NotNull SbpQrCodeResponseDto createStaticQr(@Nullable Event event) {
    if (Objects.isNull(event)
        || !(event.getPayload() instanceof final SbpQrCodeCreationRequestDto eventPayload)) {
      return SbpQrCodeResponseDto.builder().build();
    }
    final var enumMap = new EnumMap<>(QrCreationInvocation.Param.class);
    enumMap.put(QrCreationInvocation.Param.AGENT_ID, eventPayload.getAgentId());
    enumMap.put(QrCreationInvocation.Param.MEMBER_ID, eventPayload.getMemberId());
    enumMap.put(QrCreationInvocation.Param.LEGAL_ID, eventPayload.getLegalId());
    enumMap.put(QrCreationInvocation.Param.ACCOUNT, eventPayload.getAccount());
    enumMap.put(QrCreationInvocation.Param.MERCHANT_ID, eventPayload.getMerchantId());
    enumMap.put(QrCreationInvocation.Param.TEMPLATE_VERSION, eventPayload.getTemplateVersion());
    enumMap.put(QrCreationInvocation.Param.QRC_TYPE, eventPayload.getQrcType());
    enumMap.put(QrCreationInvocation.Param.AMOUNT, eventPayload.getAmount());
    enumMap.put(QrCreationInvocation.Param.CURRENCY, eventPayload.getCurrency());
    enumMap.put(QrCreationInvocation.Param.PAYMENT_PURPOSE, eventPayload.getPaymentPurpose());
    enumMap.put(QrCreationInvocation.Param.ORDER_ID, eventPayload.getOrderId());
    enumMap.put(QrCreationInvocation.Param.REQUEST_ID, eventPayload.getRequestId());
    log.info("Received static qr creation request {}", eventPayload.getRequestId());
    return Optional.ofNullable(
            (QrCreationInvocation) sbpInvocations.get(QrCreationInvocation.BEAN_NAME))
        .map(invocation -> invocation.invoke(enumMap))
        .map(HttpEntity::getBody)
        .orElse(SbpQrCodeResponseDto.builder().build());
  }

  @Transactional
  public void createPaymentStatus(@NotNull TransactionPayload transaction) {
    if (transaction.getContext().containsKey(TransactionInfoKey.SBP_PARAMS_ID.getValue())) {
      getStatusCashQr(MapperUtils.mapCashQrStatus(transaction));
    } else {
      log.info("Received payment status request for transaction with id {}",
          transaction.getTransactionId());
      Optional.ofNullable(
              (PaymentStatusInvocation) sbpInvocations.get(PaymentStatusInvocation.BEAN_NAME))
          .map(invocation -> invocation.invoke(MapperUtils.mapPaymentStatus(transaction)))
          .filter(response -> Objects.nonNull(response.getBody()) && HttpStatus.OK.equals(
              response.getStatusCode()))
          .ifPresent(response -> ((PaymentStatusResponseParser) parsers.get(
              PaymentStatusResponseParser.BEAN_NAME))
              .accept(response.getBody(), transaction));
    }
  }

}