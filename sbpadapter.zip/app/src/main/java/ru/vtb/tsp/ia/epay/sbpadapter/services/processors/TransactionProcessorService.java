package ru.vtb.tsp.ia.epay.sbpadapter.services.processors;

import java.util.Map;
import java.util.Objects;
import java.util.function.Consumer;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.sbpadapter.configs.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.sbpadapter.services.KafkaService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.listeners.TransactionPayloadListener;

@Slf4j
@Service
@AllArgsConstructor
public class TransactionProcessorService {

  private final KafkaService kafkaService;
  private final MessageAdapter messageAdapter;
  private final Map<String, Consumer<?>> listeners;

  @KafkaListener(topics = "${app.kafka.consumer.topics}",
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  public void processTransaction(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      final var transaction = messageAdapter
          .deserializeTransactionPayload(record.value());
      if (Objects.isNull(transaction)) {
        // send to dlq
        kafkaService.sendToDlq(record.value());
      } else {
        ((TransactionPayloadListener) listeners
            .get(TransactionPayloadListener.BEAN_NAME)).accept(transaction);
      }
    } catch (Exception ex) {
      log.error("Transaction can't be processed", ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}