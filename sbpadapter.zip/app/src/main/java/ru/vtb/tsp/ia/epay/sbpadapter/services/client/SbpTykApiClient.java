package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@ConditionalOnProperty(name = "app.sbp.tyk.mock", havingValue = "false")
@FeignClient(name = "sbpTykApiClient", url = "${app.sbp.tyk.url}", decode404 = true)
public interface SbpTykApiClient extends SbpTykApi {

}