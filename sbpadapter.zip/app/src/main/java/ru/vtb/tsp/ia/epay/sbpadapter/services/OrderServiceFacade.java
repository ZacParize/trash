package ru.vtb.tsp.ia.epay.sbpadapter.services;

import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.repositories.OrderRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderServiceFacade {

  private static final String ORDER_STATE_NAME_COUNTER = "TSPACQ_ORDER_STATE-%s";

  private final OrderRepository orderRepository;
  private final MonitoringService monitoringService;

  @Transactional
  public void updateOrderState(Order order) {
    orderRepository.saveOrUpdate(order);
    monitoringService.incrementCounter(
        String.format(ORDER_STATE_NAME_COUNTER, order.getState().getValue())
    );
  }

  @Transactional
  public void calculateOrderState(Order order, List<Transaction> transactions) {
    if (Objects.isNull(order) || Objects.isNull(transactions)) {
      return;
    }
    final var oldState = order.getState();
    var newState = oldState;
    final var refundedAmount = Order.calculateRefundedAmount(transactions);
    //REFUND
    if (refundedAmount > 0d) {
      newState = refundedAmount >= order.getAmount() ? OrderState.REFUNDED
          : OrderState.PARTIALLY_REFUNDED;
    } else {
      //PAYMENT
      final var payedAmount = Order.calculatePayedAmount(transactions);
      if (payedAmount > 0d) {
        newState = payedAmount >= order.getAmount() ? OrderState.PAID : OrderState.PARTIALLY_PAID;
      } else if (order.isExpired()) {
        newState = OrderState.EXPIRED;
      }
    }
    if (!newState.equals(oldState)) {
      updateOrderState(order.withState(newState));
      log.info("Change order id {} state from {} to {}", order.getOrderId(), oldState,
          newState);
    }
  }
}