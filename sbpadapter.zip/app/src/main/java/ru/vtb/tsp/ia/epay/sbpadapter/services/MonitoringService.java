package ru.vtb.tsp.ia.epay.sbpadapter.services;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MonitoringService {

  private final MeterRegistry meterRegistry;

  public void incrementCounter(String name) {
    final var counter = Counter.builder(name).register(meterRegistry);
    counter.increment();
  }
}