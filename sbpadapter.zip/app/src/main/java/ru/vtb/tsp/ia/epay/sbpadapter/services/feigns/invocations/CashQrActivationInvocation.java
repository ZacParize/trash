package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.EpaAuthService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Slf4j
@Component(CashQrActivationInvocation.BEAN_NAME)
@RequiredArgsConstructor
public class CashQrActivationInvocation implements
    SbpTykInvocation<CashQrActivationInvocation.Param> {

  public static final String BEAN_NAME = "cashQrActivationInvocationBean";
  protected final SbpTykApi sbpTykApi;
  private final EpaAuthService epaAuthService;

  public enum Param {
    QRC_ID,
    AMOUNT,
    PAYMENT_PURPOSE,
    EXTRA,
    CURRENCY,
    QR_TTL
  }

  @Override
  public ResponseEntity<SbpCashQrActivationResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(this::buildRequest)
        .map(requestEntity -> {
          log.info("Cash QR activation invocation request: {}", requestEntity);
          try {
            final var accessToken = epaAuthService.getToken();
            final var responseEntity = sbpTykApi.activateCashQr(getDefaultHeaders(accessToken), requestEntity);
            log.info("Received Cash QR activation invocation response {}", responseEntity.getBody());
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during Cash Qr activation invocation {}", params, ex);
            throw new ServiceException(ApplicationException.PAYMENT_CREATION_ERROR);
          }
        }).orElse(null);
  }

  private SbpCashQrActivationRequestDto buildRequest(EnumMap<Param, Object> parametersMap) {
    final var requestBuilder =
        SbpCashQrActivationRequestDto.builder()
            .qrcId(Objects.requireNonNull(parametersMap.get(Param.QRC_ID)).toString())
            .amount(Objects.requireNonNull(parametersMap.get(Param.AMOUNT)).toString());
    Optional.ofNullable(parametersMap.get(Param.CURRENCY)).map(Object::toString)
        .ifPresent(requestBuilder::currency);
    Optional.ofNullable(parametersMap.get(Param.EXTRA)).map(Object::toString)
        .ifPresent(requestBuilder::extra);
    Optional.ofNullable(parametersMap.get(Param.PAYMENT_PURPOSE)).map(Object::toString)
        .ifPresent(requestBuilder::paymentPurpose);
    Optional.ofNullable(parametersMap.get(Param.QR_TTL)).map(qrTtl -> (Integer) qrTtl)
        .ifPresent(requestBuilder::qrTtl);
    return requestBuilder.build();
  }
}