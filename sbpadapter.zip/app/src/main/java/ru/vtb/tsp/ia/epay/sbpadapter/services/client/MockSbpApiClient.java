package ru.vtb.tsp.ia.epay.sbpadapter.services.client;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpPaymentStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRegisterRefundRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.banks.SbpBanksListResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentDetailsResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@Component
@ConditionalOnProperty(name = "app.sbp.native.mock", havingValue = "true")
public class MockSbpApiClient implements SbpApi {

  private final static String OK_CODE2 = "I00000";
  private final static String OK_CODE = "RQ00000";
  private final static String MESSAGE = "Запрос обработан успешно";

  @Override
  public ResponseEntity<List<SbpBanksListResponseDto>> getBanks(HttpHeaders httpHeaders) {
    return ResponseEntity.ok(Collections.emptyList());
  }

  @Override
  public ResponseEntity<SbpQrCodeResponseDto> createQr(HttpHeaders httpHeaders,
      SbpQrCodeCreationRequestDto body) {
    final var dto = new SbpQrCodeResponseDto();
    final var content = new SbpQrCodeResponseDto.Content();
    final var rand = new Random();
    final var qrcId = String.valueOf(Math.round(rand.nextDouble() * 100000000));
    content.setQrcId(qrcId);
    content.setPayload("https://qr.nspk.ru/" + qrcId + "?type=01&bank=100000000005");
    content.setStatus(Qstate.CREATED);
    dto.setCode(OK_CODE);
    dto.setMessage(MESSAGE);
    dto.setData(content);
    dto.setOrderId(body.getOrderId());
    dto.setRequestId(body.getRequestId());
    return ResponseEntity.ok(dto);
  }

  @Override
  public ResponseEntity<SbpPaymentStatusResponseDto> getPaymentStatus(HttpHeaders httpHeaders,
      SbpPaymentStatusRequestDto body) {
    final var responseDto = SbpPaymentStatusResponseDto.builder()
        .anId("anId")
        .qId(body.getQId())
        .qrcId(body.getQrcId())
        .operationId("string")
        .qState(Qstate.OK)
        .qReason("string")
        .build();
    return ResponseEntity.ok(responseDto);
  }

  @Override
  public ResponseEntity<SbpRegisterRefundResponseDto> registerRefund(HttpHeaders httpHeaders,
      SbpRegisterRefundRequestDto body) {
    Random rand = new Random();
    final var msgId = String.valueOf(Math.round(rand.nextDouble() * 100000000));
    final var sbpRegisterRefundResponseDto = SbpRegisterRefundResponseDto
        .builder()
        .errCode(OK_CODE2)
        .errMess("")
        .msgId(msgId)
        .build();
    return ResponseEntity.ok(sbpRegisterRefundResponseDto);
  }

  @Override
  public ResponseEntity<SbpConfirmRefundResponseDto> confirmRefund(HttpHeaders httpHeaders,
      SbpRefundConfirmRequestDto body) {
    final var sbpConfirmRefundResponseDto = SbpConfirmRefundResponseDto.builder()
        .msgId(body.getMsgId())
        .errCode(OK_CODE2)
        .errMess("ok")
        .build();
    return ResponseEntity.ok(sbpConfirmRefundResponseDto);
  }

  @Override
  public ResponseEntity<SbpRefundStatusResponseDto> getRefundStatus(HttpHeaders httpHeaders,
      SbpRefundStatusRequestDto body) {
    final var sbpRefundStatusResponseDto = SbpRefundStatusResponseDto.builder()
        .msgId(body.getMsgId())
        .txSts(Qstate.ACWP)
        .prtry(OK_CODE2)
        .addtlInf("")
        .build();
    return ResponseEntity.ok(sbpRefundStatusResponseDto);
  }

  @Override
  public ResponseEntity<SbpPaymentDetailsResponseDto> getPaymentDetails(HttpHeaders httpHeaders,
      String qrcId) {
    final var sbpPaymentDetailsResponseDto = SbpPaymentDetailsResponseDto.builder()
        .clientFio("test")
        .absOperationId(qrcId)
        .build();
    return ResponseEntity.ok(sbpPaymentDetailsResponseDto);
  }

}