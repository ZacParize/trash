package ru.vtb.tsp.ia.epay.sbpadapter.interceptors;

import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class FeignInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate template) {
        log.info("{} calls method {}: url {}",
            template.feignTarget().name(),
            template.method(),
            template.feignTarget().url().concat(template.url()));
    }
}