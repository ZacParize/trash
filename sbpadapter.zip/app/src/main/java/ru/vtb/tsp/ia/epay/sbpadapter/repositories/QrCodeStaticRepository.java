package ru.vtb.tsp.ia.epay.sbpadapter.repositories;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.sbpadapter.entities.QrCodeStatic;

@Repository
public interface QrCodeStaticRepository extends CrudRepository<QrCodeStatic, Long> {

  @NotNull
  Optional<QrCodeStatic> findByQrcId(String qrcId);

  @NotNull
  @Query("insert into " + QrCodeStatic.TABLE_NAME + " (qrc_id, payload, q_state, q_reason, q_code, "
      + "request_id, legal_id, order_id, account, currency, purpose, created_at, merchant_id, amount) "
      + "values (:qrcId, :payload, :qState, :qReason, :qCode, :requestId, :legalId, :orderId, "
      + ":account, :currency, :purpose, :createdAt, :merchantId, :amount) "
      + "on conflict (qrc_id) do update set payload = :payload, q_state = :qState, "
      + "q_reason = :qReason, q_code = :qCode, request_id = :requestId, legal_id = :legalId, "
      + "order_id = :orderId, account = :account, currency = :currency, purpose = :purpose, "
      + "created_at = :createdAt, merchant_id = :merchantId, amount = :amount "
      + "where " + QrCodeStatic.TABLE_NAME + ".qrc_id = :qrcId RETURNING *")
  QrCodeStatic saveOrUpdate(String qrcId,
      String payload,
      String qState,
      String qReason,
      String qCode,
      String orderId,
      String requestId,
      String legalId,
      String account,
      String currency,
      String purpose,
      LocalDateTime createdAt,
      String merchantId,
      BigDecimal amount);

  @NotNull
  default QrCodeStatic saveOrUpdate(QrCodeStatic entity) {
    return saveOrUpdate(entity.getQrcId(),
        entity.getPayload(),
        entity.getQState(),
        entity.getQReason(),
        entity.getQCode(),
        entity.getOrderId(),
        entity.getRequestId(),
        entity.getLegalId(),
        entity.getAccount(),
        entity.getCurrency(),
        entity.getPurpose(),
        entity.getCreatedAt(),
        entity.getMerchantId(),
        entity.getAmount());
  }

}