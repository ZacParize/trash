package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.parsers.QrResponseParser.BEAN_NAME;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.PGNotification;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.PgNotificationService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpChannel;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpQrNotificationDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.SuccessCode;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;

@Slf4j
@Component(BEAN_NAME)
public class QrResponseParser extends AbstractResponseParser<SbpQrCodeResponseDto> {

  public static final String BEAN_NAME = "qrResponseParser";
  private final PgNotificationService<SbpQrNotificationDto, PGNotification> notificationService;

  public QrResponseParser(TransactionService transactionService,
      PgNotificationService<SbpQrNotificationDto, PGNotification> notificationService) {
    super(transactionService);
    this.notificationService = Objects.requireNonNull(notificationService,
        "Pg notification service can't be null");
  }

  @Override
  @AuditProcess("TSPACQ_BOX_SBP_QR_RESPONSE")
  public void accept(@Nullable SbpQrCodeResponseDto response,
      @Nullable TransactionPayload transaction) {
    if (Objects.isNull(response) || Objects.isNull(transaction) || transaction.isCompleted()) {
      return;
    }
    Optional.ofNullable(response.getCode())
        .filter(code -> SuccessCode.findByName(code).isPresent())
        .ifPresentOrElse(
            code -> {
              final var sbpTransaction = (Sbp) transaction.getPaymentData();
              sbpTransaction.setQrcId(Objects.requireNonNull(response.getData()).getQrcId());
              sbpTransaction.setQrLink(response.getData().getPayload());
              sbpTransaction.setRequestId(response.getRequestId());
              sbpTransaction.setStatus(response.getData().getStatus());
              updateTransaction(response, transaction);
              log.info("Qr creation request for transaction id {} was successfully processed",
                  transaction.getTransactionId());
            },
            () -> {
              transaction.setError(TransactionError.builder()
                  .id(ApplicationException.PAYMENT_DECLINED_ERROR.getId())
                  .httpCode(ApplicationException.PAYMENT_DECLINED_ERROR.getHttpCode())
                  .message(ApplicationException.PAYMENT_DECLINED_ERROR.getMessage())
                  .description(ApplicationException.PAYMENT_DECLINED_ERROR.getDescription())
                  .traceId(transaction.getTransactionCode())
                  .build());
              updateTransaction(response, transaction);
              log.info("Qr creation request for transaction id {} was declined",
                  transaction.getTransactionId());
            });
  }

  private void updateTransaction(@NotNull SbpQrCodeResponseDto response,
      @NotNull TransactionPayload transaction) {
    final var creationTime = LocalDateTime.now(ZoneOffset.UTC);
    if (SuccessCode.findByName(response.getCode()).isPresent()) {
      MDC.put(MDCKeySupplier.UNIQUE_KEY, transaction.getOrderInfo().getOrderId());
      transactionService.upsertInfo(transaction.getTransactionId(),
          TransactionInfoKey.SBP_QR_ID,
          Objects.requireNonNull(response.getData()).getQrcId(),
          creationTime);
      transactionService.upsertInfo(transaction.getTransactionId(),
          TransactionInfoKey.SBP_REQUEST_ID,
          response.getRequestId(),
          creationTime);
      transactionService.upsertInfo(transaction.getTransactionId(),
          TransactionInfoKey.SBP_QR_LINK,
          response.getData().getPayload(),
          creationTime);
      transaction.setStatus(TransactionState.SBP_PAYMENT_CREATED);
      transactionService.updateDataById(transaction.getTransactionId(), transaction);
      notificationService.notify(SbpChannel.SBP_QR_CHANNEL.getValue(),
          SbpQrNotificationDto.builder()
              .qrId(response.getData().getQrcId())
              .qrRequestId(response.getRequestId())
              .qrLink(response.getData().getPayload())
              .transactionId(transaction.getTransactionId())
              .build());
    } else {
      transaction.setStatus(TransactionState.DECLINED);
      transactionService.updateDataById(transaction.getTransactionId(), transaction);
    }
  }

}