package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.QrCreationInvocation.BEAN_NAME;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.QrCodeType;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class QrCreationInvocation implements
    SbpInvocation<QrCreationInvocation.Param> {

  public static final String BEAN_NAME = "qrCreationInvocationBean";
  private final SbpApi sbpApi;

  public enum Param {
    TRANSACTION_ID,
    MERCHANT_ID,
    AGENT_ID,
    MEMBER_ID,
    LEGAL_ID,
    ACCOUNT,
    TEMPLATE_VERSION,
    QRC_TYPE,
    QRC_TTL,
    AMOUNT,
    CURRENCY,
    PAYMENT_PURPOSE,
    ORDER_ID,
    REQUEST_ID
  }

  @Override
  public ResponseEntity<SbpQrCodeResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          log.info("Qr creation invocation params {}", parametersMap);
          ResponseEntity<SbpQrCodeResponseDto> responseEntity;
          try {
            final var requestEntity = SbpQrCodeCreationRequestDto.builder()
                .agentId(Objects.requireNonNull(parametersMap.get(Param.AGENT_ID)).toString())
                .memberId(Objects.requireNonNull(parametersMap.get(Param.MEMBER_ID)).toString())
                .legalId(Objects.requireNonNull(parametersMap.get(Param.LEGAL_ID)).toString())
                .account(Objects.requireNonNull(parametersMap.get(Param.ACCOUNT)).toString())
                .merchantId(Objects.requireNonNull(parametersMap.get(Param.MERCHANT_ID)).toString())
                .templateVersion(
                    Objects.requireNonNull(parametersMap.get(Param.TEMPLATE_VERSION)).toString())
                .qrcType(Objects.requireNonNull(parametersMap.get(Param.QRC_TYPE)).toString())
                .amount(Objects.requireNonNull(parametersMap.get(Param.AMOUNT)).toString())
                .currency(Objects.requireNonNull(parametersMap.get(Param.CURRENCY)).toString())
                .paymentPurpose((String) parametersMap.get(Param.PAYMENT_PURPOSE))
                .orderId((String) parametersMap.get(Param.ORDER_ID))
                .requestId((String) parametersMap.get(Param.REQUEST_ID))
                .build();
            if (QrCodeType.DYNAMIC.getValue().equals(requestEntity.getQrcType())) {
              requestEntity.setQrTtl(
                  Objects.requireNonNull(parametersMap.get(Param.QRC_TTL)).toString());
            }
            log.info("Qr creation invocation request {}", requestEntity);
            responseEntity = sbpApi.createQr(getDefaultHeaders(), requestEntity);
            log.info("Received qr creation invocation response {} of transaction id {}",
                responseEntity.getBody(), parametersMap.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during qr creation invocation {}", parametersMap, ex);
            throw new ServiceException(ApplicationException.PAYMENT_CREATION_ERROR);
          }
        }).orElse(null);
  }

}