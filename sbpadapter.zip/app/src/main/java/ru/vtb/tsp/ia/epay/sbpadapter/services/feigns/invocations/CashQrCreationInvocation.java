package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.EpaAuthService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Slf4j
@Component(CashQrCreationInvocation.BEAN_NAME)
@RequiredArgsConstructor
public class CashQrCreationInvocation implements
    SbpTykInvocation<CashQrCreationInvocation.Param> {

  public static final String BEAN_NAME = "cashQrCreationInvocationBean";
  protected final SbpTykApi sbpTykApi;
  private final EpaAuthService epaAuthService;

  public enum Param {
    TRANSACTION_ID,
    MERCHANT_ID,
    AGENT_ID,
    MEMBER_ID,
    ACCOUNT,
    REDIRECT_URL
  }

  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_RESPONSE")
  @Override
  public ResponseEntity<SbpCashQrCreationResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(this::buildRequest)
        .map(requestEntity -> {
          log.info("Cash qr creation invocation request {}", requestEntity);
          try {
            final var accessToken = epaAuthService.getToken();
            final var responseEntity =
                sbpTykApi.createCashQr(getDefaultHeaders(accessToken), requestEntity);
            log.info("Received cash qr creation invocation response {} of transaction id {}",
                responseEntity.getBody(), params.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during cash qr creation invocation {}", params, ex);
            throw new ServiceException(ApplicationException.PAYMENT_CREATION_ERROR);
          }
        }).orElse(null);
  }

  private SbpCashQrCreationRequestDto buildRequest(EnumMap<Param, Object> parametersMap) {
    final var requestBuilder =
        SbpCashQrCreationRequestDto.builder()
            .merchantId(Objects.requireNonNull(parametersMap.get(Param.MERCHANT_ID)).toString())
            .account(Objects.requireNonNull(parametersMap.get(Param.ACCOUNT)).toString());
    Optional.ofNullable(parametersMap.get(Param.AGENT_ID)).map(Object::toString)
        .ifPresent(requestBuilder::agentId);
    Optional.ofNullable(parametersMap.get(Param.MEMBER_ID)).map(Object::toString)
        .ifPresent(requestBuilder::memberId);
    Optional.ofNullable(parametersMap.get(Param.REDIRECT_URL)).map(Object::toString)
        .ifPresent(requestBuilder::redirectUrl);
    return requestBuilder.build();
  }
}