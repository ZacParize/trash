package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.PaymentStatusInvocation.BEAN_NAME;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpPaymentStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;

@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class PaymentStatusInvocation implements SbpInvocation<PaymentStatusInvocation.Param> {

  public static final String BEAN_NAME = "paymentStatusInvocationBean";
  private final SbpApi sbpApi;

  public enum Param {
    TRANSACTION_ID,
    QRC_ID,
    QID
  }

  @Override
  public @Nullable ResponseEntity<SbpPaymentStatusResponseDto> invoke(@Nullable EnumMap<Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          try {
            final var requestEntity = SbpPaymentStatusRequestDto.builder()
                .qId(Objects.requireNonNull(parametersMap.get(Param.QID)).toString())
                .qrcId(Objects.requireNonNull(parametersMap.get(Param.QRC_ID)).toString())
                .build();
            log.info("Payment status invocation request {}", requestEntity);
            final var responseEntity = sbpApi.getPaymentStatus(getDefaultHeaders(), requestEntity);
            log.info("Received payment status invocation response {} of transaction id {}",
                responseEntity.getBody(), parametersMap.get(Param.TRANSACTION_ID));
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during payment status invocation {}", parametersMap, ex);
            return null;
          }
        }).orElse(null);
  }
}