package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import java.util.EnumMap;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.EpaAuthService;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpTykApi;

@Slf4j
@Component(CashQrStatusInvocation.BEAN_NAME)
@Builder
@RequiredArgsConstructor
public class CashQrStatusInvocation implements
    SbpTykInvocation<CashQrStatusInvocation.Param> {

  public static final String BEAN_NAME = "cashQrStatusInvocation";
  private final SbpTykApi sbpTykApi;
  private final EpaAuthService epaAuthService;

  public enum Param {
    QRC_ID,
    PARAMS_ID
  }

  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_PAYMENT_STATUS_RESPONSE")
  @Override
  public ResponseEntity<SbpCashQrStatusResponseDto> invoke(
      @Nullable EnumMap<CashQrStatusInvocation.Param, Object> params) {
    return Optional.ofNullable(params)
        .map(parametersMap -> {
          log.info("Cash qr status invocation params {}", parametersMap);
          try {
            final var requestEntity = SbpCashQrStatusRequestDto.builder()
                .qrcId(Objects.requireNonNull(
                    parametersMap.get(CashQrStatusInvocation.Param.QRC_ID)).toString())
                .paramsId(Objects.requireNonNull(parametersMap.get(Param.PARAMS_ID)).toString())
                .build();
            log.info("Cash qr status invocation request {}", requestEntity);
            final var accessToken = epaAuthService.getToken();
            final var responseEntity = sbpTykApi.getStatusCashQr(getDefaultHeaders(accessToken), requestEntity);
            log.info("Received cash qr status invocation response {}", responseEntity.getBody());
            return responseEntity;
          } catch (Exception ex) {
            log.error("Error occurred during cash qr status invocation {}", parametersMap, ex);
            throw new ServiceException(ApplicationException.INTERNAL_ERROR);
          }
        }).orElse(null);
  }
}
