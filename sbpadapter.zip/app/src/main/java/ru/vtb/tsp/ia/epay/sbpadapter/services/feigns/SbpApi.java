package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns;

import java.util.List;
import javax.validation.constraints.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpPaymentStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundConfirmRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRefundStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds.SbpRegisterRefundRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.banks.SbpBanksListResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentDetailsResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpConfirmRefundResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRegisterRefundResponseDto;

public interface SbpApi {

  /**
   * Запрос на получение списка банков
   */
  @PostMapping(path = "/refund/nspk/banks_dictionary", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<List<SbpBanksListResponseDto>> getBanks(
      @RequestHeader HttpHeaders httpHeaders);

  /**
   * Запрос на формирование статического/динамического QR-кода
   */
  @AuditProcess("TSPACQ_BOX_SBP_QR")
  @PostMapping(path = "/immediate_payment/qr_code", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpQrCodeResponseDto> createQr(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpQrCodeCreationRequestDto body);

  /**
   * Получаем статус оплаты по сгенерированному ранее коду
   */
  @AuditProcess("TSPACQ_BOX_SBP_PAYMENT_STATUS")
  @PostMapping(path = "/immediate_payment/status", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpPaymentStatusResponseDto> getPaymentStatus(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpPaymentStatusRequestDto body);

  /**
   * Отправляем запрос на возврат
   */
  @AuditProcess("TSPACQ_BOX_SBP_REFUND")
  @PostMapping(path = "/tsp/refund/return/request", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpRegisterRefundResponseDto> registerRefund(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpRegisterRefundRequestDto body);

  /**
   * Отправляем подтверждение на ранее направленный запрос на возврат
   */
  @PostMapping(path = "/tsp/refund/return/transfer/request", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpConfirmRefundResponseDto> confirmRefund(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpRefundConfirmRequestDto body);

  /**
   * Запрашиваем статус ранее отправленного запроса на возврат
   */
  @AuditProcess("TSPACQ_BOX_SBP_REFUND_STATUS")
  @PostMapping(path = "/refund/get_status", produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<SbpRefundStatusResponseDto> getRefundStatus(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody SbpRefundStatusRequestDto body);

  /**
   * Получаем дополнительные сведения по платежу
   */
  @GetMapping(path = "/bqr_reg/get_payments/{qrcId}", produces = "application/json")
  ResponseEntity<SbpPaymentDetailsResponseDto> getPaymentDetails(
      @RequestHeader HttpHeaders httpHeaders,
      @PathVariable("qrcId") String qrcId);
}