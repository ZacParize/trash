package ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations;

import static ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.invocations.BanksInvocation.BEAN_NAME;

import java.util.EnumMap;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.sbpadapter.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.sbpadapter.services.feigns.SbpApi;


@Slf4j
@Component(BEAN_NAME)
@RequiredArgsConstructor
public class BanksInvocation implements SbpInvocation<BanksInvocation.Param> {

    public static final String BEAN_NAME = "banksInvocationBean";
    private final SbpApi sbpApi;

    public enum Param {
    }

    @Override
    public @Nullable ResponseEntity<?> invoke(@Nullable EnumMap<Param, Object> params) {
        try {
            log.info("Getting banks invocation params {}", params);
            final var responseEntity = sbpApi.getBanks(getDefaultHeaders());
            log.info("Received banks invocation response {}", responseEntity.getBody());
            return responseEntity;
        } catch (Exception ex) {
            log.error("Error occurred during getting banks invocation {}", params, ex);
            throw new ServiceException(ApplicationException.BAD_GATEWAY_ERROR);
        }
    }
}