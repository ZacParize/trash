buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

apply(plugin = "com.gorylenko.gradle-git-properties")

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
        exclude("io.springfox", "springfox-bean-validators")
        exclude("io.springfox", "springfox-boot-starter")
        exclude("io.springfox", "springfox-core")
        exclude("io.springfox", "springfox-data-rest")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    implementation(project(":api"))

    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-sbpgateway-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-notificator-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-domain")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")

    // Spring components
    implementation("org.springframework.kafka:spring-kafka")
    implementation("org.springframework.boot:spring-boot-starter-integration")
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.cloud:spring-cloud-starter-openfeign")
    runtimeOnly("org.springframework.boot:spring-boot-starter-undertow")

    // Validation
    implementation("javax.validation:validation-api")

    // Tracing
    implementation("ru.vtb.tstr:tstr-starter")

    // Logging
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("com.vlkan.log4j2:log4j2-logstash-layout")
    implementation("ru.vtb.infra.logging:log4j2-integration")

    // audit
    implementation("ru.vtb.omni:audit-lib-servlet-context")
    implementation("ru.vtb.omni:audit-lib-in-memory-storage")
    implementation("ru.vtb.omni:audit-lib-kafka-sender")
    implementation("ru.vtb.omni:audit-lib-freemarker-template-resolver")

    //Monitoring
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("io.micrometer:micrometer-registry-prometheus")
    implementation("io.github.openfeign:feign-micrometer")

    // Kafka streams
    implementation("org.apache.kafka:kafka-streams")

    // Apache
    implementation("org.apache.httpcomponents:httpclient")

    // Database driver
    implementation("org.postgresql:postgresql")

    // Reactive streams
    implementation("io.projectreactor:reactor-core")
    implementation("io.projectreactor.kafka:reactor-kafka")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    //standin
    implementation("ru.vtb.smartreplication:smart-replication-producer-lib")
    implementation("ru.vtb.smartreplication:smart-replication-client-jdbc")
    implementation("ru.vtb.smartreplication:smart-replication-core-etcd-support-starter")
    implementation("io.grpc:grpc-core")
    implementation("io.grpc:grpc-netty")
    implementation("io.grpc:grpc-protobuf")
    implementation("io.grpc:grpc-stub")
    implementation("io.grpc:grpc-grpclb")
    implementation("net.jodah:failsafe")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testImplementation("org.junit.jupiter:junit-jupiter-params")
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:kafka")
    testImplementation("org.testcontainers:postgresql")
    testImplementation("org.testcontainers:junit-jupiter")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set("ru.vtb.tsp.ia.epay.sbpadapter.App")
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
            versionMapping {
                usage("java-api") {
                    fromResolutionOf("runtimeClasspath")
                }
                usage("java-runtime") {
                    fromResolutionResult()
                }
            }
        }
    }
    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
    maxHeapSize = "1G"
}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
        property("sonar.exclusions", "src/main/resources/**/*," +
                "ru/vtb/tsp/ia/epay/sbpadapter/**/*Dto.java," +
                "ru/vtb/tsp/ia/epay/sbpadapter/**/*Api.java," +
                "ru/vtb/tsp/ia/epay/sbpadapter/**/*Abstract*.java," +
                "ru/vtb/tsp/ia/epay/sbpadapter/**/*Exception.java," +
                "ru/vtb/tsp/ia/epay/sbpadapter/configs/**/*.java" +
                "ru/vtb/tsp/ia/epay/sbpadapter/dtos/*.java" +
                "ru/vtb/tsp/ia/epay/sbpadapter/exceptions/*.java" +
                "ru/vtb/tsp/ia/epay/sbpadapter/App.java" +
                "**/*.yaml," +
                "**/*.yml," +
                "**/*.xml")
    }
}