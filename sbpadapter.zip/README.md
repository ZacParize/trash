Internet acquiring, box, sbp service

Installation instructions:

1) Clone environment project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-environment.git

2) Clone the project:

   git clone https://bitbucket.region.vtb.ru/scm/efcp/tsp-ia-box-sbpadapter.git \
or \
git clone ssh://git@bitbucket.region.vtb.ru:7999/efcp/tsp-ia-box-sbpadapter.git

3) Launch environment:

   cd tsp-ia-box-environment/docker

   docker-compose stop && docker-compose up -d

4) Ask team members for the file with environment variables and secrets. Setup import of it in application*.yml files.
   There are 2 equal ways to do so:\
   1st way. Install the plugin "EnvFile" for IDE and add `.env` to the project root.
   (https://github.com/Ashald/EnvFile)
   2nd way. Put such a file in the resources' folder. Then rename it to "env-local.yml".

5) To use Kafka, copy the certificates to the local machine(e.g.`certs` folder at the root of the project) and update 
corresponding kafka variables from file with environment variables and secrets with actual paths.

6) Launch sbpadapter service: add new Spring Boot Configuration in IDEA, choose JDK 17,'app.main' folder, main class, 
profile(e.g. local), shorten command line @argfile.