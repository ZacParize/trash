package ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpRefreshStatusDto implements Serializable {

  @NotBlank
  private String transactionId;

  @PositiveOrZero
  private int retryCount;

}