package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpPaymentStatusResponseDto implements PaymentRequest, Serializable {

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "anId", required = true, example = "QD10005SR3J7ASVM9QKBLLI364R2O4EG")
  private String anId;

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "qId", required = true, example = "8B0B3597AF67351AE053114EC90A4147")
  private String qId;

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "qrcId", required = true, example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
  private String qrcId;

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "operationId", required = true, example = "B226606481601501000015716FF8C1B9")
  private String operationId;

  @NotNull
  @Schema(name = "qState", required = true, example = "InProgress")
  private Qstate qState;

  @NotBlank
  @Size(min = 1, max = 255)
  @Schema(name = "qReason", required = true, example = "Сообщение СБП обработано успешно")
  private String qReason;

  @NotBlank
  @Size(min = 1, max = 255)
  @Schema(name = "orderId", required = true, example = "164013116")
  private String orderId;

  @NotBlank
  @Size(min = 1, max = 244)
  @Schema(name = "requestId", required = true, example = "12323123")
  private String requestId;

}