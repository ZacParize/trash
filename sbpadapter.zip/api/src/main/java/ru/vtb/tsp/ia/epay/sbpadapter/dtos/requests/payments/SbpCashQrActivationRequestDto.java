package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SbpCashQrActivationRequestDto implements Serializable {

  @NotBlank
  @Size(max = 32)
  @Schema(name = "qrcId", required = true, description ="Идентификатор зарегистрированной Кассовой ссылки СБП", example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
  private String qrcId;

  @NotBlank
  @Size(max = 12)
  @Schema(name = "amount", required = true, description ="Сумма операции в рублях", example = "100.35")
  private String amount;

  @Size(max = 140)
  @Schema(name = "paymentPurpose", nullable = true, description ="Назначение платежа", example = "Капучино 300 мл 1 шт., булочка 1 шт.")
  private String paymentPurpose;

  @Size(max = 255)
  @Schema(name = "extra", nullable = true, description = "Дополнительная информация о ТСП", example = "Магазин номер 2")
  private String extra;

  @Size(max = 20)
  @Schema(name = "currency", nullable = true, description = "Валюта операции", example = "RUB")
  private String currency;

  @Min(1L)
  @Max(20L)
  @Schema(name = "qrTtl", defaultValue = "5", nullable = true, description = "Период использования Кассовой ссылки в минутах. Допустимые значение от 1 до 20", example = "7")
  private Integer qrTtl;

}