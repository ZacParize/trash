package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum SbpRefundConfirmCode {

    OK, CNCL;

}