package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpImageQrCreationResponseDto implements Serializable {

  @NotBlank
  @Size(max = 32_768)
  @Schema(name = "content", required = true, description = "base64encoded строка", example = "iVBORw0KGgoAAAANSUhEUgAAASwAAAEsCAYAAAB5fY51AAAniUlEQVR4X"
      + "u3d+bevZ13ecf6E/tBKBSlKbSssFgsQEAFlCqiIyDwuKEJLpVAGoYUCYR5DEBmMgKAIMi3CpKnAsgSKQExLmNIUiEhMmIKYMCQnJyfDecr"
      + "eh7M5ee2zc50P9/PsfT/J/V7rvdp1rutzf+/vZ3vudXKS2utMg8FgsBKu4y8MBoNBr4wHazAYrIbxYA0Gg9UwHqzBYLAaxoM1GAxWw3iwBo"
      + "PBahgP1mAwWA3jwRoMBqthPFiDwWA1jAdrMBishvFgDQaD1TAerMFgsBrGgzUYDFbDeLAGg8FqGA/WYDBYDeP…")
  private String content;

}
