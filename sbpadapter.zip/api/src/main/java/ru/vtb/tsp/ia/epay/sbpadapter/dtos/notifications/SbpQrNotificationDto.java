package ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpQrNotificationDto implements Serializable {

  @NotBlank
  private String transactionId;

  @NotBlank
  private String qrId;

  @NotBlank
  private String qrRequestId;

  @NotBlank
  private String qrLink;

  @Override
  public String toString() {
    return String.format(
        "{\"transactionId\":\"%s\",\"qrId\":\"%s\",\"qrRequestId\":\"%s\",\"qrLink\":\"%s\"}",
        transactionId, qrId, qrRequestId, qrLink);
  }
}