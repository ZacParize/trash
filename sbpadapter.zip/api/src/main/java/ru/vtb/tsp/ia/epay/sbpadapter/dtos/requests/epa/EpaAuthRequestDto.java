package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.epa;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class EpaAuthRequestDto implements Serializable {

  private String grant_type;

  private String client_secret;

  private String client_id;
}