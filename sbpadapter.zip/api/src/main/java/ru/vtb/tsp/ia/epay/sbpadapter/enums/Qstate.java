package ru.vtb.tsp.ia.epay.sbpadapter.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@JsonFormat(shape = JsonFormat.Shape.STRING)
@Getter
@RequiredArgsConstructor
public enum Qstate {

  OK,
  CREATED,
  Canceled,
  InProgress,
  Unknown,
  NTST,
  ACWP,
  RCVD,
  RJCT;

}