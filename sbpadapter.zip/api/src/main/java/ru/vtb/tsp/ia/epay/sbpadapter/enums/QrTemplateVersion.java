package ru.vtb.tsp.ia.epay.sbpadapter.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@JsonFormat(shape = JsonFormat.Shape.STRING)
@Getter
@RequiredArgsConstructor
public enum QrTemplateVersion {

  VERSION_01("01");

  private final String value;

}