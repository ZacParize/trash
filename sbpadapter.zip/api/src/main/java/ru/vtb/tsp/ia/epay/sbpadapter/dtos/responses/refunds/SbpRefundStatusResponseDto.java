package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpRefundStatusResponseDto implements RefundRequest, Serializable {

  @Size(min = 1, max = 32)
  @JsonProperty(value = "MsgId")
  private String msgId;

  @JsonProperty(value = "TxSts")
  private Qstate txSts;

  @Size(min = 1, max = 6)
  @JsonProperty(value = "Prtry")
  private String prtry;

  @Size(min = 1, max = 105)
  @JsonProperty(value = "AddtlInf")
  private String addtlInf;

}