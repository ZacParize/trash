package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.banks;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum SbpBankMemberCode {

    M, S;

}