package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.errors;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.Optional;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorDto implements Serializable {

  @Size(max = 255)
  @Schema(name = "id", required = true, description = "Идентификатор ошибки", example = "10000001")
  private String id;

  @Size(max = 255)
  @Schema(name = "message", required = true, description = "Описание ошибки", example = "INTERNAL_ERROR")
  private String message;

  @Size(max = 255)
  @Schema(name = "description", required = true, description = "Данные с развернутым описанием ошибки", example = "Внутренняя ощибка сервиса")
  private String description;

  @Size(max = 255)
  @Schema(name = "traceId", required = true, description = "Идентификатор трейса", example = "merch-tx-id")
  private String traceId;

  public static ErrorDto of(TransactionError txError) {
    return Optional.ofNullable(txError)
        .map(error -> ErrorDto.builder()
            .id(error.getId())
            .message(error.getMessage())
            .description(error.getDescription())
            .traceId(error.getTraceId())
            .build())
        .orElse(null);
  }

}
