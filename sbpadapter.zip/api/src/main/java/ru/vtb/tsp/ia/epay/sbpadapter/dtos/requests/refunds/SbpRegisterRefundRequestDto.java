package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpRegisterRefundRequestDto implements Serializable {

    private String legalId;

    private String account;

    private String merchantId;

    private String intrBkSttlmAmt;

    private String txId;

    private String cdtrAgt;

    private String ustrd;
}