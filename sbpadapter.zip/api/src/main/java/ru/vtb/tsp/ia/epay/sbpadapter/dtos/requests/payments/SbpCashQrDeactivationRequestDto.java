package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpCashQrDeactivationRequestDto implements Serializable {

  @NotBlank
  @Size(max = 32)
  @Schema(name = "qrcId", required = true, description = "Идентификатор зарегистрированной Кассовой ссылки СБП", example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
  private String qrcId;

}