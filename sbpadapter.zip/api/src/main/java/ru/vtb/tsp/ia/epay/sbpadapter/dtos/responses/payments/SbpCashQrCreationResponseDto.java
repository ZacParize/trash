package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpCashQrCreationResponseDto implements Serializable {

  @NotBlank
  @Size(max = 10)
  @Schema(name = "code", required = true, description = "Код ответа на запрос", example = "RQ00000")
  private String code;

  @NotBlank
  @Size(max = 255)
  @Schema(name = "message", required = true, description = "Описание кода ответа на запрос", example = "Запрос обработан успешно")
  private String message;

  @Schema(name = "data", required = true, nullable = true, description = "Дополнительные данные")
  private SbpCashQrCreationResponseDtoContent data;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  @Builder
  public static class SbpCashQrCreationResponseDtoContent implements Serializable {

    @NotBlank
    @Size(max = 32)
    @Schema(name = "qrcId", required = true, description = "Идентификатор зарегистрированного Кассовой ссылки СБП", example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
    private String qrcId;

    @NotBlank
    @Size(max = 255)
    @Schema(name = "payload", required = true, description ="Payload зарегистрированной Кассовой ссылки СБП", example = "https://qr.nspk.ru/AS1000670LSS7DN18SJQ"
        + "DNP4B05KLJL2?type=01&bank=100000000001&sum=10000&cur=RUB&crc=C08B")
    private String payload;

    @NotBlank
    @Size(max = 255)
    @Schema(name = "status", required = true, description = "Статус регистрации Кассовой ссылки СБП", example = "CREATED")
    private String status;

  }
}