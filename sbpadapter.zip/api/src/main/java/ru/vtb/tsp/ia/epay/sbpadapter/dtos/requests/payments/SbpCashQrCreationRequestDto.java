package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SbpCashQrCreationRequestDto implements Serializable {

  @Size(max = 12)
  @Schema(name = "agentId", nullable = true, description = "Идентификатор агента. Пример: Агент - приложение ВТБ Бизес QR", example = "A00000000010")
  private String agentId;

  @Size(max = 12)
  @Schema(name = "memberId", nullable = true, description = "Идентификатор Банка Получателя", example = "100000000005")
  private String memberId;

  @NotBlank
  @Size(max = 12)
  @Schema(name = "merchantId", required = true, description = "Идентификатор зарегистрированного ТСП в СБП", example = "MF0000000001")
  private String merchantId;

  @NotBlank
  @Size(max = 20)
  @Schema(name = "account", required = true, description = "Банковский счет ЮЛ, ИП или самозанятого", example = "40702810100010000001")
  private String account;

  @Size(max = 1024)
  @Schema(name = "redirectUrl", nullable = true, description = "Содержит ссылку для автоматического возврата Плательщика из приложения Банка в приложение или на сайт ТСП. "
      + "Допускаются только символы в кодировке ASCII. Формат должен соответствовать правилам кодировки URL.", example = "https://exampletsp.io/qwertyui")
  private String redirectUrl;

}