package ru.vtb.tsp.ia.epay.sbpadapter.enums;

import java.util.Optional;

public enum SuccessCode {

  I00000,
  RQ00000;

  public static Optional<SuccessCode> findByName(String name) {
    for (var code : values()) {
      if (code.name().equals(name)) {
        return Optional.of(code);
      }
    }
    return Optional.empty();
  }
}