package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpPaymentStatusRequestDto implements PaymentRequest, Serializable {

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "qId", required = true, example = "8B0B3597AF67351AE053114EC90A4147")
  private String qId;

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "qrcId", required = true, example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
  private String qrcId;

}