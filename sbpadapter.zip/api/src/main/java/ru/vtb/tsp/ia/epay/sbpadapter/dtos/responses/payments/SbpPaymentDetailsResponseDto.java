package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpPaymentDetailsResponseDto implements Serializable {

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "absOperationId", required = true)
  private String absOperationId;

  @NotBlank
  @Size(min = 1, max = 32)
  @Schema(name = "clientFio", required = true, example = "Сухоруков В.Е.")
  private String clientFio;

  @NotBlank
  @Size(min = 12, max = 12)
  @Schema(name = "clientPhone", required = true, example = "+7902666**13")
  private String clientPhone;

}