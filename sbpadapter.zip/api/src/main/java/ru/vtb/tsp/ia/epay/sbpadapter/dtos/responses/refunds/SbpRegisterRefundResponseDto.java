package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpRegisterRefundResponseDto implements Serializable {

    @Size(min = 1, max = 32)
    @JsonProperty(value = "MsgId")
    private String msgId;

    @Size(min = 1, max = 32)
    @JsonProperty(value = "ErrCode")
    private String errCode;

    @Size(min = 1, max = 2048)
    @JsonProperty(value = "ErrMess")
    private String errMess;

}