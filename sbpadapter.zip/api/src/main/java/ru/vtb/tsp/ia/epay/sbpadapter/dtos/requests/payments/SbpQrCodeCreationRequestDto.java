package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpQrCodeCreationRequestDto implements Serializable {

  @Size(max = 64)
  @Schema(name = "orderId", nullable = true, description = "Идентификатор запроса со стороны клиента", example = "3")
  private String orderId;

  @Size(max = 255)
  @Schema(name = "requestId", nullable = true, description = "Идентификатор операции со стороны клиента", example = "1")
  private String requestId;

  @Size(max = 12)
  @Schema(name = "agentId", nullable = true, description = "Идентификатор Агента ТСП", example = "A00000000010")
  private String agentId;

  @Size(max = 12)
  @Schema(name = "memberId", nullable = true, description = "Идентификатор Банка Получателя", example = "100000000005")
  private String memberId;

  @NotBlank
  @Size(max = 12)
  @Schema(name = "legalId", required = true, description = "Идентификатор ЮЛ из СБП", example = "LA0000013623")
  private String legalId;

  @NotBlank
  @Size(max = 20)
  @Schema(name = "account", required = true, description = "Банковский счёт ЮЛ, ИП или самозанятого. Поле обязательно для заполнения, если qrcType = 01 или qrcType = 02 ",
      example = "40702810100010000001")
  private String account;

  @NotBlank
  @Size(max = 12)
  @Schema(name = "merchantId", required = true, description = "Идентификатор ТСП", example = "MF0000000001")
  private String merchantId;

  @NotBlank
  @Size(max = 2)
  @Schema(name = "templateVersion", nullable = true, description = "Версия payload", example = "01")
  private String templateVersion;

  @NotBlank
  @Size(max = 2, message = "qrcType должен содержать не более 2 символов")
  @Pattern(regexp = "^(01|02|03)$", message = "qrcType должен быть одним из значений: 01, 02 или 03")
  @Schema(name = "qrcType", required = true, description = "Тип ссылки СБП:\n"
      + "01 - QR-Static (Многоразовая Платежная ссылка СБП). Может использоваться для выполнения множества Операций СБП C2B\n"
      + "02 - QR-Dynamic (Одноразовая платежная ссылка СБП). Предназначена для выполнения единичной Операции СБП C2B. Используется в Сценариях Оплата спривязкой счёта и Оплата "
      + "по привязанному счёту\n"
      + "03 - QR-Subscription (Информационная ссылка СБП для привязки счета Плательщика\n", example = "01")
  private String qrcType;

  @Size(max = 12)
  @Schema(name = "amount", nullable = true, description = "Сумма опреации СБП C2B в рублях. Положительное число. Обязателен для заполнения, если qrcType = 02. Всегда отсутсвует "
      + "если qrcType = 03. Может отсутсвовать при регистрации qrcType = 01", example = "100.35")
  private String amount;

  @NotBlank
  @Size(max = 3)
  @Schema(name = "currency", nullable = true, description = "Валюта операции", example = "RUB")
  private String currency;

  @Size(max = 12)
  @Schema(name = "qrTtl", defaultValue = "4320", nullable = true, description = "Срок жизни Функциональной ссылки СБП в минутах. Необязательное поле. минимальное допустимое "
      + "значение - 1. Максимальное допустимое значение - 129 600 (90 дней). Внимание! Рекомендации ОПКЦ СБП: установливать срок жизни Функциональной ссылки СБП не менее 5 минут"
      + ". Если поле qrTtl не передано в запросе, будет использоваться значение по умолчанию - 4 320 минут (3 суток). Неприменимо для qrcType = 01", example = "7")
  private String qrTtl;

  @Size(max = 140)
  @Schema(name = "paymentPurpose", nullable = true, description = "Назначение платежа", example = "Капучино 300 мл 1 шт., булочка 1 шт.")
  private String paymentPurpose;

  @Size(max = 140)
  @Schema(name = "subscriptionPurpose", nullable = true,  description = "Назначение привязки счёта. Поле обязательно для qrcType = 03 и для qrcType = 02 в сценарии Оплата с "
      + "привязкой счёта ", example = "Оплата завтраков у Артура")
  private String subscriptionPurpose;

  @Size(max = 16)
  @Schema(name = "fraudScope", nullable = true, description = "Индикатор Подозрительной Операции Агента ТСП", example = "0000000000000000")
  private String fraudScope;

  @Size(max = 1024)
  @Schema(name = "redirectUrl", nullable = true, description = "Содержит ссылку для автоматического возврата Плательщика из приложения Банка в приложение или на сайт ТСП. "
      + "Допускаются только символы в кодировке ASCII. Формат должен соответствовать правилам кодировки URL.", example = "https://exampletsp.io/qwertyui")
  private String redirectUrl;

  @Size(max = 255)
  @Schema(name = "localTime", nullable = true, description = "Время создания Платёжной ссылки от партнёра", example = "13:45.30.123456789")
  private String localTime;

  @Size(max = 255)
  @Schema(name = "terminalId", nullable = true, description = "Идентификатор терминала", example = "1j3545klh753n6832bfsb13")
  private String terminalId;

  @Size(max = 255)
  @Schema(name = "client_name", nullable = true, description = "Наименование клиента от Партнёра", example = "Стравинский К.Н.")
  private String client_name;

  @Size(max = 140)
  @Schema(name = "namePayer", nullable = true, description = "Наименование плательщика ЮЛ/ИП", example = "ООО Конкорд")
  private String namePayer;

  @Size(max = 32)
  @Schema(name = "innReceiver", nullable = true, description = "ИНН Клиента ЮЛ/ИП", example = "1310034935098967864763")
  private String innReceiver;

  @Size(max = 32)
  @Schema(name = "kppReceiver", nullable = true, description = "КПП Клиента ЮЛ/ИП", example = "7777777777777777777777777777")
  private  String kppReceiver;

  @Size(max = 32)
  @Schema(name = "productCode", nullable = true, description = "Код продукта", example = "asdfg6875df-009sdfxzwhj-9as7877")
  private String productCode;

  @Size(max = 32)
  @Schema(name = "externalOperationId", nullable = true, description = "Номер заявки", example = "1000000000000000000000000000001")
  private String externalOperationId;

  @Size(max = 140)
  @Schema(name = "adressPI", nullable = true, description = "Адрес ЮЛ", example = "пл. Киевского Вокзала, 2, Москва, 121059")
  private String adressPI;
}