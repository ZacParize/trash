package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(Include.NON_NULL)
public class SbpImageQrCreationRequestDto implements Serializable {

  @NotBlank
  @Size(max = 32)
  @Schema(name = "qrcId", required = true, description = "Идентификатор Платёжной ссылки СБП",
      example = "AD10005147O5QKP582OAGJVUD40UBFF2")
  private String qrcId;

  @Min(200L)
  @Max(1000L)
  @Schema(name = "width", defaultValue = "300", description = "Ширина избражения", example = "300")
  private Integer width;

  @Min(200L)
  @Max(1000L)
  @Schema(name = "height", defaultValue = "300", description = "Высота избражения", example = "300")
  private Integer height;

}
