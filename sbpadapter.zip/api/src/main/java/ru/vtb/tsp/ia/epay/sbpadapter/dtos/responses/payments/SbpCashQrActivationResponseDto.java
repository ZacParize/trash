package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpCashQrActivationResponseDto implements Serializable {

  @NotBlank
  @Size(max = 10)
  @Schema(name = "code", required = true, description = "Код ответа на запрос", example = "RQ00000")
  private String code;

  @NotBlank
  @Size(max = 255)
  @Schema(name = "message", required = true, description = "Описание кода ответа на запрос", example = "Запрос обработан успешно")
  private String message;

  @Schema(name = "data", required = true, nullable = true, description = "Дополнительные данные")
  private SbpCashQrActivationResponseDtoContent data;

  @Data
  @AllArgsConstructor
  @NoArgsConstructor
  @Builder
  public static class SbpCashQrActivationResponseDtoContent implements Serializable {

    @NotBlank
    @Schema(name = "transactionCode", required = true, description = "Идентификатор транзакции",
        example = "3b8528fc-94c7-4fef-bc06-8d6e8daefd63")
    private String transactionCode;

    @NotBlank
    @Schema(name = "orderCode", required = true, description = "Идентификатор заказа",
        example = "13b6f9af-73e6-4ad2-889f-0333796df0e4")
    private String orderCode;

    @NotBlank
    @Size(max = 32)
    @Schema(name = "paramsId", required = true, description = "Идентификатор параметров активированной Кассовой ссылки СБП", example = "83746290376583029856473829018735")
    private String paramsId;

    @NotBlank
    @Size(max = 32)
    @Schema(name = "qrcId", required = true, description = "Идентификатор зарегистрированного Кассовой ссылки СБП", example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
    private String qrcId;

    @NotBlank
    @Size(max = 12)
    @Schema(name = "amount", required = true, description = "Сумма операции в рублях", example = "100.56")
    private String amount;

    @Size(max = 255)
    @Schema(name = "extra", nullable = true, description = "Дополнительная информация о ТСП", example = "Магазин номер 2")
    private String extra;

    @Size(max = 3)
    @Schema(name = "currency", nullable = true, description = "Валюта оперпации", example = "RUB")
    private String currency;

    @NotBlank
    @Size(max = 140)
    @Schema(name = "paymentPurpose", required = true, description ="Назначение платежа", example = "Капучино 300 мл 1 шт., булочка 1 шт.")
    private String paymentPurpose;

  }
}