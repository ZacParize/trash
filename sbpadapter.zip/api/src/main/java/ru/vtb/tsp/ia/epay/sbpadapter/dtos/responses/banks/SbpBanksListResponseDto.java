package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.banks;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpBanksListResponseDto implements Serializable {

    @Size(min = 1, max = 7)
    @JsonProperty("endpoints")
    private List<String> endpoints;

    @Size(min = 1, max = 12)
    @JsonProperty("memberId")
    private String memberId;

    @JsonProperty("memberType")
    private SbpBankMemberCode memberType;

    @Size(min = 1, max = 20)
    @JsonProperty("profileName")
    private String profileName;

    @Size(min = 1, max = 8)
    @JsonProperty("effectiveDate")
    private String effectiveDate;

    @Size(min = 1, max = 50)
    @JsonProperty("memberNameRus")
    private String memberNameRus;

    @Size(min = 1, max = 1)
    @JsonProperty("informationOnly")
    private SbpYesNoCode informationOnly;

}