package ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpCashQrStatusResponseDto implements Serializable {

  @NotBlank
  @Size(max = 32)
  @Schema(name = "qrcId", required = true, description = "Идентификатор зарегистрированного Кассовой ссылки СБП", example = "AS1000670LSS7DN18SJQDNP4B05KLJL2")
  private String qrcId;


  @Size(max = 32)
  @Schema(name = "operationId", required = true, nullable = true, description = "Идентификатор Операции СБП", example = "B226606481601501000015716FF8C1B9")
  private String operationId;

  @NotBlank
  @Size(max = 32)
  @Schema(name = "paramsId", required = true, nullable = true, description = "Идентификатор парметров активированной Кассовой ссылки СБП", example =
      "83746290376583029856473829018735")
  private String paramsId;

  @NotNull
  @Schema(name = "qState", required = true, description = "Статус операции:\n"
      + "OK – Обработан успешно\n"
      + "Canceled – Отбракован системой\n"
      + "InProgress – В процессе обработки\n"
      + "Unknown – Не найден\n",
      example = "InProgress")
  private Qstate qState;

  @Size(max = 6)
  @Schema(name = "reasonCode", required = true, description = "Код ответа СБП", nullable = true, example = "B00000")
  private String reasonCode;

  @Size(max = 255)
  @Schema(name = "qReason", required = true, nullable = true, description = "Описание ответа СБП", example = "Сообщение СБП обработано успешно")
  private String qReason;

  @Size(max = 15)
  @Schema(name = "senderPhone", required = true, nullable = true, description = "Идентификатор плательщика (номер телефона в маскированном виде)", example = "7700****967")
  private String senderPhone;

  @Size(max = 255)
  @Schema(name = "slipData", nullable = true, description = "Информация об операции для чека", example = "Тип операции: SBP Тип транзакции: Оплата ID перации: "
      + "AS1000670LSS7DN18SJQDNP4B05KLJL2 Сумма, руб: 100\n")
  private String slipData;



}
