package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.refunds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpRefundConfirmRequestDto implements Serializable {

    private String msgId;

    private SbpRefundConfirmCode prtry;
}
