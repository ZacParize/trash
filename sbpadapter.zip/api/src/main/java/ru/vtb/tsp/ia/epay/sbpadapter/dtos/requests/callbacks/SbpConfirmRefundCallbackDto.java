package ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpConfirmRefundCallbackDto implements RefundRequest, Serializable {

    @NotNull
    @Size(max = 32)
    @JsonProperty("MsgId")
    private String msgId;

    @JsonProperty("TxSts")
    private Qstate txSts;

    @NotNull
    @Size(max = 6)
    @JsonProperty("Prtry")
    private String prtry;

    @JsonProperty("FIO")
    private String fio;

    @Size(max = 105)
    @JsonProperty("AddtlInf")
    private String addtlInf;
}