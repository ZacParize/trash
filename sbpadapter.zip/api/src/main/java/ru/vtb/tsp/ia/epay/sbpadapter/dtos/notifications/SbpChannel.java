package ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum SbpChannel {

  SBP_QR_CHANNEL("sbp_qr_channel");

  private final String value;

}
