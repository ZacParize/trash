Internet acquiring, box, core functionality

Installation instructions:

1) Clone environment project:
   
   git clone https://bitbucket.region.vtb.ru/scm/efcp/tsp-ia-box-core.git
   
3) Launch environment:
    
   cd tsp-ia-box-core/docker
   
   docker-compose stop && docker-compose up -d