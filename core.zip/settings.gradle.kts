include("domain","lib")

pluginManagement {
    repositories {
        maven {
            url = uri(extra["nexus.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
        maven {
            url = uri(extra["nexus.omni.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}