package ru.vtb.tsp.ia.epay.core.domains;

public interface StatefulObject<T> {

  T getState();

  void setState(T state);
}
