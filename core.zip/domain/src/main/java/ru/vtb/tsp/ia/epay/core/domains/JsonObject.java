package ru.vtb.tsp.ia.epay.core.domains;

public interface JsonObject {
}
