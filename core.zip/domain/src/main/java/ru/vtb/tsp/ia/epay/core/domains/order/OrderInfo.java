package ru.vtb.tsp.ia.epay.core.domains.order;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderInfo implements Serializable, JsonObject {

  @JsonProperty("name")
  private String name;

  @JsonProperty("description")
  private String description;

  @JsonProperty("mstOrderId")
  private String mstOrderId;

  @JsonProperty("orderCode")
  private String orderCode;

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderState")
  private OrderState orderState;

  @JsonProperty("orderType")
  private OrderType orderType;

  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @JsonProperty("changedAt")
  private LocalDateTime changedAt;

  @JsonProperty("expiredAt")
  private LocalDateTime expiredAt;

  @JsonProperty("returnUrl")
  private String returnUrl;

  @JsonProperty("account")
  private String account;

  @JsonProperty("bic")
  private String bic;

  @JsonProperty("sourceSystem")
  private SourceSystem sourceSystem;

  @JsonProperty("amount")
  private Amount amount;

  @JsonProperty("bindingType")
  private BindingType bindingType;

  @JsonProperty("bindingCategory")
  private BindingCategory bindingCategory;

  @JsonProperty("bindingCode")
  private UUID bindingCode;

  @JsonIgnore
  public boolean isTransfer() {
    return OrderType.isTransfer(orderType);
  }

  @JsonIgnore
  public boolean isPayment() {
    return OrderType.isPayment(orderType);
  }

  @JsonIgnore
  public boolean isTwoStage() {
    return OrderType.isTwoStage(orderType);
  }

  @JsonIgnore
  public boolean isPending() {
    return OrderState.isPending(orderState);
  }

  public static OrderInfo of(Order order) {
    return Optional.ofNullable(order)
        .map(o -> OrderInfo.builder()
            .name(o.getName())
            .description(o.getDescription())
            .mstOrderId(o.getMstOrderId())
            .orderCode(o.getCode())
            .orderId(o.getOrderId())
            .orderState(o.getState())
            .orderType(o.getOrderType())
            .createdAt(o.getCreatedAt())
            .changedAt(o.getChangedAt())
            .expiredAt(o.getExpiredAt())
            .returnUrl(o.getReturnUrl())
            .bic(o.getBic())
            .account(o.getAccount())
            .sourceSystem(o.getSourceSystem())
            .bindingCode(o.getBindingCode())
            .bindingType(o.getBindingType())
            .bindingCategory(o.getBindingCategory())
            .amount(Amount.builder()
                .currency(o.getCurrency().getCode())
                .value(o.getAmount())
                .build())
            .build())
        .orElse(null);
  }
}