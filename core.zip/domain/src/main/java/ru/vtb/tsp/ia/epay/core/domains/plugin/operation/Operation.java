package ru.vtb.tsp.ia.epay.core.domains.plugin.operation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.enums.OperationState;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Operation implements Serializable {

    String id;
    OperationState state;
    TransactionPayload transaction;

}