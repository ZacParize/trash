package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import java.util.Map;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class MerchantSiteTransferParams implements JsonObject, Serializable {

  @NotEmpty
  @Size(max = 255)
  private String mid;

  @NotEmpty
  @Size(max = 16)
  private String terminalId;

  @Valid
  @NotNull
  private TransferAccount account;

  private TransferCommission commission;

  @Deprecated
  @JsonProperty("enableA2cTransfer")
  private boolean enableA2cTransfer;

  @Deprecated
  @JsonProperty("enableC2aTransfer")
  private boolean enableC2aTransfer;

  @Deprecated
  @JsonProperty("a2cTransferParams")
  private Map<String,Serializable> a2cTransferParams;

  @Deprecated
  @JsonProperty("c2aTransferParams")
  private Map<String,Serializable> c2aTransferParams;

}
