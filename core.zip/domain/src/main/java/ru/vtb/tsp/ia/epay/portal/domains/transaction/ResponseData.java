package ru.vtb.tsp.ia.epay.portal.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseData implements Serializable {

  // id статуса
  @JsonProperty("id")
  private String id;

  // сообщение
  @JsonProperty("message")
  private String message;

}
