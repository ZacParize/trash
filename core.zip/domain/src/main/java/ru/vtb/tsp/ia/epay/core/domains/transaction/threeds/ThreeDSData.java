package ru.vtb.tsp.ia.epay.core.domains.transaction.threeds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSMessageCategory;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSReqAuthInd;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;

import java.io.Serializable;
import java.time.OffsetDateTime;

/**
 * Data for 3DS adapter.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@Data
@JsonIgnoreProperties
public class ThreeDSData implements Serializable {

    @JsonProperty("operation")
    private ThreeDSAdapterOperation operation;
    @JsonProperty("threeDsVersion")
    private ThreeDSVersion threeDsVersion;
    @JsonProperty("orderId")
    private String orderId;
    @JsonProperty("merchantId")
    private String merchantId;
    @JsonProperty("threeDSCompInd")
    private String threeDSCompInd;
    @JsonProperty("merchantName")
    private String merchantName;
    @JsonProperty("mcc")
    private String mcc;
    @JsonProperty("threeDSRequestorUrl")
    private String threeDSRequestorUrl;
    @JsonProperty("messageCategory")
    private ThreeDSMessageCategory messageCategory;
    @JsonProperty("threeDSRequestorAuthentificatorInd")
    private ThreeDSReqAuthInd threeDSRequestorAuthentificatorInd;
    @JsonProperty("sessionId")
    private String sessionId;
    @JsonProperty("pan")
    private String pan;
    @JsonProperty("expDate")
    private String expDate;
    @JsonProperty("cardUid")
    private String cardUid;
    @JsonProperty("browserInfo")
    private BrowserInfo browserInfo;
    @JsonProperty("threeDSMethodData")
    private String threeDSMethodData;
    @JsonProperty("notificationUrl")
    private String notificationUrl;
    @JsonProperty("notificationUrlCres")
    private String notificationUrlCres;
    @JsonProperty("deviceChannel")
    private String deviceChannel;
    @JsonProperty("nextExecution")
    private OffsetDateTime nextExecution;
    @JsonProperty("acsNotificationRequestV10")
    private OffsetDateTime acsNotificationRequestV10;
    @JsonProperty("acsNotificationRequestV20Method")
    private OffsetDateTime acsNotificationRequestV20Method;
    @JsonProperty("acsNotificationRequestV20Decision")
    private OffsetDateTime acsNotificationRequestV20Decision;


}
