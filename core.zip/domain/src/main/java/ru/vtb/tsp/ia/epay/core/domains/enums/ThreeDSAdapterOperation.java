package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;

import java.util.Optional;

/**
 * 3DS Adapter operations.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */

@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSAdapterOperation {

  FIRST("FIRST"),
  PARES("PARES"),
  AREQ("AREQ"),
  CRES("CRES"),
  FINISHED("FINISHED");

  private final String step;

  ThreeDSAdapterOperation(String step) {
    this.step = step;
  }

  public static Optional<ThreeDSAdapterOperation> findByStep(String step) {
    for (var val : ThreeDSAdapterOperation.values()) {
      if (val.getStep().equals(step)) {
        return Optional.of(val);
      }
    }
    return Optional.empty();
  }
}
