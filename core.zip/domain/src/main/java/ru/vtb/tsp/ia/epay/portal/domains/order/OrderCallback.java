package ru.vtb.tsp.ia.epay.portal.domains.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.portal.domains.merchant.MerchantSite;

import javax.annotation.Nullable;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderCallback implements Serializable {

  @JsonProperty("order")
  private OrderData order;

  public static Optional<OrderCallback> map(@Nullable Order order) {
    if (Objects.isNull(order)) {
      return Optional.empty();
    }
    final var currentTime = LocalDateTime.now(ZoneOffset.UTC);
    return Optional.ofNullable(OrderCallback.builder()
            .order(OrderData.builder()
                    .code(order.getCode())
                    .name(order.getName())
                    .type(order.getOrderType())
                    .amount(Amount.builder()
                            .currency(order.getCurrency().getCode())
                            .value(order.getAmount())
                            .build())
                    .createdDate(order.getCreatedAt())
                    .expireDate(order.getExpiredAt())
                    .status(OrderStatus.builder()
                            .value(order.getState())
                            .date(currentTime)
                            .build())
                    .merchantOrderId(order.getMstOrderId())
                    .merchantSite(MerchantSite.builder()
                            .merchantId(order.getMst().getMerchant().getId())
                            .mstId(order.getMst().getId())
                            .url(order.getMst().getUrl())
                            .build())
                    .sourceSystem(order.getSourceSystem())
                    .build())
            .build());
  }

}