package ru.vtb.tsp.ia.epay.core.domains.transaction.threeds;

import lombok.Data;

/**
 * Browser information.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@Data
public class BrowserInfo {

    private String acceptHeader;
    private String ip;
    private String userAgent;
    private String colorDepth;
    private String language;
    private String screenHeight;
    private String screenWidth;
    private String tz;
    private String javaEnabled;
    private String windowHeight;
    private String windowsWidth;

}
