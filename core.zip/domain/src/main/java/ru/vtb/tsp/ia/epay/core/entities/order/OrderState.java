package ru.vtb.tsp.ia.epay.core.entities.order;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum OrderState {

    CREATED("CREATED") /*Новый заказ*/,
    CANCELED("CANCELED") /*Заказ отменен мерчантом*/,
    CLOSED("CLOSED") /*Заказ завершен*/,
    PARTIALLY_PAID("PARTIALLY_PAID") /*Частично оплачен*/,
    PAID("PAID") /*Полностью оплачен*/,
    REFUNDED("REFUNDED") /*Вернули назад полную сумму заказа*/,
    PARTIALLY_REFUNDED("PARTIALLY_REFUNDED")	/*Вернули назад часть суммы заказа*/,
    EXPIRED("EXPIRED")	/*Истек срок жизни заказа*/,
    PENDING("PENDING") /*Ожидает оплаты*/,
    VOIDED("VOIDED") /*Заказ аннулирован*/,
    //отдельные статусы для трансфера
    PROCESSING("PROCESSING") /*в процессе обработки*/,
    REJECTED("REJECTED") /*отменен*/,
    DECLINED("DECLINED") /*отклонен так как не моджет быть исполнен*/;

    private final String value;

    protected static final List<OrderState> PROCESSING_STATES = List.of(PROCESSING, PARTIALLY_PAID, PARTIALLY_REFUNDED);

    protected static final List<OrderState> PAYED_STATES = List.of(PAID);

    protected static final List<OrderState> REFUNDED_STATES = List.of(REFUNDED);

    protected static final List<OrderState> DECLINED_STATES = List.of(CANCELED, REJECTED, DECLINED, EXPIRED, CLOSED);

    protected static final List<OrderState> FINAL_STATES = Collections.unmodifiableList(
            Stream.concat(PAYED_STATES.stream(), Stream.concat(REFUNDED_STATES.stream(), DECLINED_STATES.stream()))
                    .collect(Collectors.toList()));

    public static boolean isCreated(@Nullable OrderState state) {
        return Objects.nonNull(state) && CREATED.equals(state);
    }

    public static boolean isPending(@Nullable OrderState state) {
        return Objects.nonNull(state) && PENDING.equals(state);
    }

    public static boolean isRefunded(@Nullable OrderState state) {
        return Objects.nonNull(state) && REFUNDED_STATES.contains(state);
    }

    public static boolean isPartiallyRefunded(@Nullable OrderState state) {
        return Objects.nonNull(state) && PARTIALLY_REFUNDED.equals(state);
    }

    public static boolean isPartiallyPaid(@Nullable OrderState state) {
        return Objects.nonNull(state) && PARTIALLY_PAID.equals(state);
    }

    public static boolean isCompleted(@Nullable OrderState state) {
        return Objects.nonNull(state) && FINAL_STATES.contains(state);
    }

    public static boolean isProcessing(@Nullable OrderState state) {
        return Objects.nonNull(state) && PROCESSING_STATES.contains(state);
    }

    public static boolean isPaid(@Nullable OrderState state) {
        return Objects.nonNull(state) && PAYED_STATES.contains(state);
    }

    public static boolean isDeclined(@Nullable OrderState state) {
        return Objects.nonNull(state) && DECLINED_STATES.contains(state);
    }

    public static boolean isCanceled(@Nullable OrderState state) {
        return Objects.nonNull(state) && CANCELED.equals(state);
    }

    public static boolean isClosed(@Nullable OrderState state) {
        return Objects.nonNull(state) && CLOSED.equals(state);
    }

    public static boolean isVoided(@Nullable OrderState state) {
        return Objects.nonNull(state) && VOIDED.equals(state);
    }

}