package ru.vtb.tsp.ia.epay.core.entities.transaction;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TransactionInfoKey {

    SBP_QR_ID("SBP_QR_ID"),
    SBP_PRTRY("SBP_PRTRY"),
    SBP_MSG_ID("SBP_MSG_ID"),
    SBP_QR_LINK("SBP_QR_LINK"),
    SBP_REQUEST_ID("SBP_REQUEST_ID"),
    SBP_OPERATION_ID("SBP_OPERATION_ID"),
    SBP_DETAIL("SBP_DETAIL"),
    SBP_PAYMENT_PURPOSE("SBP_PAYMENT_PURPOSE"),
    SBP_EXTRA("SBP_EXTRA"),
    SBP_QR_TTL("SBP_QR_TTL"),
    SBP_PARAMS_ID("SBP_PARAMS_ID"),
    CARD_BANK("CARD_BANK"),
    CARD_PAYSYSTEM("CARD_PAYSYSTEM"),
    CARD_RRN("CARD_RRN"),
    CARD_ECI("CARD_ECI"),
    CARD_OPERATION_ID("CARD_OPERATION_ID") /*id мультикарты */;

    private final String value;

}