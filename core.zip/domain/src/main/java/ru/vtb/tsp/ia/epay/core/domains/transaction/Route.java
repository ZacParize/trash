package ru.vtb.tsp.ia.epay.core.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowPoint;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Route implements Serializable {

    private static final int LOOP_THRESHOLD = 20;

    @JsonProperty("currentPoint")
    private int currentPoint;

    @JsonProperty("flowPoints")
    private List<FlowPoint> flowPoints;

    @JsonProperty("visitedServices")
    private Map<String, Integer> visitedServices;

    public void addVisitedService(@Nullable String service) {
        Optional.ofNullable(service)
                .ifPresent(srv -> visitedServices.put(srv, visitedServices.getOrDefault(srv, 0) + 1));
    }

    public int getVisitedService(@Nullable String service) {
        return Optional.ofNullable(service)
                       .map(srv -> visitedServices.get(srv))
                       .orElse(0);
    }

    public @Nullable String getNextPoint() {
        return Optional.ofNullable(flowPoints)
                .map(listOfFp -> listOfFp.get(currentPoint))
                .map(FlowPoint::getPoint)
                .orElse(null);
    }

    @JsonIgnore
    public boolean isVisitedService(@Nullable String service) {
        return getVisitedService(service) > 0;
    }

    @JsonIgnore
    public boolean isCompleted() {
        return Objects.nonNull(getFlowPoints()) && getFlowPoints().size() - 1 <= getCurrentPoint();
    }

    @JsonIgnore
    public boolean isLoopExists() {
        final var visitedServices = getVisitedServices();
        return !ObjectUtils.isEmpty(visitedServices)
                && visitedServices.values()
                .stream()
                .anyMatch(value -> LOOP_THRESHOLD < value);
    }
}