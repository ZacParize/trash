package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Sbp extends Payment {

    public static final String TYPE = "SBP";

    @JsonProperty("phone")
    private String phone;

    @JsonProperty("requestId")
    private String requestId;

    @JsonProperty("operationId")
    private String operationId;

    @JsonProperty("qrcId")
    private String qrcId;

    @JsonProperty("msgId")
    private String msgId;

    @JsonProperty("prtry")
    private String prtry;

    @JsonProperty("qrLink")
    private String qrLink;

    @JsonProperty("status")
    private Qstate status;

    @Override
    public String getInfo() {
        return qrLink;
    }

}