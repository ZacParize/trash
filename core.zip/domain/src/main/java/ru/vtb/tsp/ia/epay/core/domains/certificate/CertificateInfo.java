package ru.vtb.tsp.ia.epay.core.domains.certificate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigInteger;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CertificateInfo {

  @JsonProperty("serialNumber")
  private BigInteger serialNumber;

  @JsonProperty("commonName")
  private String commonName;

  @JsonProperty("allowedHosts")
  private String allowedHosts;

  @JsonProperty("notAfterDate")
  private LocalDateTime notAfterDate;

  @JsonProperty("resource")
  private String resource;

}