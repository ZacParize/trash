package ru.vtb.tsp.ia.epay.core.domains.fiscalization;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReceiptDto {

  @JsonProperty
  UUID id;

  @JsonProperty
  ReceiptOperator operator;

  @JsonProperty
  ReceiptType type;

  @JsonProperty
  ReceiptState state;

  @JsonProperty("externalId")
  UUID externalId;

  @JsonProperty("documentId")
  UUID documentId;

  @JsonProperty("transactionCode")
  UUID transactionCode;

  @JsonProperty("orderCode")
  UUID orderCode;

  @JsonProperty
  ReceiptData data;

  @JsonProperty("createdAt")
  LocalDateTime createdAt;

  @JsonProperty("changedAt")
  LocalDateTime changedAt;
}
