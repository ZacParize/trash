package ru.vtb.tsp.ia.epay.core.entities.route;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Table("flow_points")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class FlowPoint {

    @Id
    @Column("flow_point_id")
    @JsonProperty("id")
    private Long id;

    @NotNull
    @MappedCollection(idColumn = "flow_id")
    @JsonProperty("flow")
    private Flow flow;

    @NotNull
    @MappedCollection(idColumn = "flow_command_id")
    @JsonProperty("flowCommand")
    private FlowCommand flowCommand;

    @NotNull
    @JsonProperty("rank")
    private Long rank;

    @NotEmpty
    @JsonProperty("point")
    private String point;

    @NotEmpty
    @JsonProperty("name")
    private String name;

    @NotEmpty
    @JsonProperty("description")
    private String description;
}