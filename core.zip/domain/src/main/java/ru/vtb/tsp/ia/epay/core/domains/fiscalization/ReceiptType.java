package ru.vtb.tsp.ia.epay.core.domains.fiscalization;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public enum ReceiptType {

  INCOME,
  INCOME_RETURN;

  private static final Map<String, ReceiptType> NAMES = Arrays.stream(ReceiptType.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v)
      ))
      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

  public static ReceiptType fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown ReceiptType name: " + name));
  }

}