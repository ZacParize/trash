package ru.vtb.tsp.ia.epay.portal.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardInfoData implements Serializable {

  // последние 4 цифры карты клиента
  @JsonProperty("number")
  private String number;

  // срок действия карты
  @JsonProperty("expirationDate")
  private LocalDateTime expirationDate;

  // платежная система
  @JsonProperty("paymentSystem")
  private String paymentSystem;

  // наименование банка
  @JsonProperty("bank")
  private String bank;

  // значение электронного коммерческого идентификатора
  @JsonProperty("eci")
  private String eci;

  // ссылочный номер операции
  @JsonProperty("rrn")
  private String rrn;

  // версия 3DS
  @JsonProperty("threeDS")
  private ThreeDSVersion threeDS;

}