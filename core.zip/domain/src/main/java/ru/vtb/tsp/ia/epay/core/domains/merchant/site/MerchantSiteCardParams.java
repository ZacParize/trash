package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class MerchantSiteCardParams implements JsonObject, Serializable {

  @JsonProperty("enableCardPayment")
  private boolean enableCardPayment;

  @JsonProperty("enablePartialRefund")
  private boolean enablePartialRefund;

  @JsonProperty("enableCardFlowThreeDS")
  private boolean enableCardFlowThreeDS;

  @JsonProperty("enableCardFlowThreeDSOnMerchantSide")
  private boolean enableCardFlowThreeDSOnMerchantSide;

  @JsonProperty("enableGooglePayment")
  private boolean enableGooglePayment;

  @JsonProperty("enableApplePayment")
  private boolean enableApplePayment;

  @JsonProperty("enablePaymentCheckboxesVisible")
  private boolean enablePaymentCheckboxesVisible;

  @JsonProperty("enableTwoStage")
  private boolean enableTwoStage;

  @JsonProperty("merchantId")
  private String merchantId;

  @JsonProperty("terminalId")
  private String terminalId;

  @JsonProperty("merchantName")
  private String merchantName;

  @JsonProperty("enableMirPayment")
  private boolean enableMirPayment;

}