package ru.vtb.tsp.ia.epay.core.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.customer.CustomerInfo;
import ru.vtb.tsp.ia.epay.core.domains.enums.GatewayOperation;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.order.OrderInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Payment;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionPayload implements Serializable, JsonObject {

  @JsonProperty("originContext")
  private Map<String, Serializable> originContext;

  @JsonProperty("context")
  private Map<String, Serializable> context;

  @JsonProperty("transactionId")
  private String transactionId;

  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @JsonProperty("type")
  private TransactionType type;

  @JsonProperty("status")
  private TransactionState status;

  @JsonProperty("route")
  private Route route;

  @JsonProperty("paymentId")
  private String paymentId;

  @JsonProperty("amount")
  private Amount amount;

  @JsonProperty("amountHold")
  private Amount amountHold;

  @JsonProperty("paymentData")
  private Payment paymentData;

  @JsonProperty("merchant")
  private MerchantSiteInfo merchant;

  @JsonProperty("subamounts")
  private List<Subamount> subamounts;

  @JsonProperty("description")
  private String description;

  @JsonProperty("gatewayOperation")
  private GatewayOperation gatewayOperation;

  @JsonProperty("orderInfo")
  private OrderInfo orderInfo;

  @JsonProperty("transactionCode")
  private String transactionCode;

  @JsonProperty("error")
  private TransactionError error;

  @JsonProperty("customerInfo")
  private CustomerInfo customerInfo;

  @JsonIgnore
  public boolean isCompleted() {
    return TransactionState.isCompleted(status);
  }

  @JsonIgnore
  public boolean isProcessing() {
    return TransactionState.isProcessing(status);
  }

  @JsonIgnore
  public boolean isDeclined() {
    return TransactionState.isDeclined(status);
  }

  @JsonIgnore
  public boolean isAuthorized() {
    return TransactionState.isAuthorized(status);
  }

  @JsonIgnore
  public boolean isReversed() {
    return TransactionState.isReversed(status);
  }

  @JsonIgnore
  public boolean isConfirmed() {
    return TransactionState.isConfirmed(status);
  }

  @JsonIgnore
  public boolean isPaid() {
    return TransactionState.isPaid(status);
  }

  @JsonIgnore
  public boolean isRefunded() {
    return isRefund() && TransactionState.isPaid(status);
  }

  @JsonIgnore
  public boolean isRefund() {
    return TransactionType.isRefund(type);
  }

  @JsonIgnore
  public boolean isPayment() {
    return TransactionType.isPayment(type);
  }

  @JsonIgnore
  public boolean isTransfer() {
    return TransactionType.isTransfer(type);
  }

  @JsonIgnore
  public boolean isSbpPayment() {
    return TransactionType.isSbpPayment(type);
  }

  @JsonIgnore
  public boolean isSbpRefund() {
    return TransactionType.isSbpRefund(type);
  }

  @JsonIgnore
  public boolean isCardRefund() {
    return TransactionType.isCardRefund(type);
  }

  @JsonIgnore
  public boolean isCardPayment() {
    return TransactionType.isCardPayment(type);
  }

  @JsonIgnore
  public boolean isRouteCompleted() {
    return Objects.nonNull(getRoute()) && getRoute().isCompleted();
  }

  @JsonIgnore
  public boolean isRouteLoopExists() {
    return Objects.nonNull(route) && route.isLoopExists();
  }

  @JsonIgnore
  public void isValidOrThrow(Supplier<? extends RuntimeException> exceptionSupplier) {
    if (Objects.nonNull(error)) {
      error.isValidOrThrow(exceptionSupplier);
    }
  }

  @JsonIgnore
  public boolean isFiscalPayment() {
    return TransactionState.isFiscalState(status)
        && TransactionType.isFiscalPaymentType(type)
        && Objects.nonNull(merchant.getMerchantSiteParams().getFiscalParams())
        && merchant.getMerchantSiteParams().getFiscalParams().isActive();
  }

  @JsonIgnore
  public boolean isFiscalRefund() {
    return TransactionState.isFiscalState(status)
        && TransactionType.isFiscalRefundType(type)
        && Objects.nonNull(merchant.getMerchantSiteParams().getFiscalParams())
        && merchant.getMerchantSiteParams().getFiscalParams().isActive();
  }

  @JsonIgnore
  public Transaction getConnectedTransaction() {
    return Objects.nonNull(originContext) ?
        Transaction.builder()
            .transactionId((String) originContext.get("transactionId"))
            .code((String) originContext.get("code"))
            .mstTransactionId((String) originContext.get("mstTransactionId"))
            .type(Optional.ofNullable((String) originContext.get("transactionType"))
                .map(TransactionType::valueOf).orElse(null))
            .state(Optional.ofNullable((String) originContext.get("transactionState"))
                .map(TransactionState::valueOf).orElse(null))
            .build() : null;
  }

  @JsonIgnore
  public boolean isAcceptableForStreaming() {
    return isCompleted() || (getOrderInfo().isTwoStage() && getOrderInfo().isPending());
  }

}