package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Invoice extends Payment {

    public static final String TYPE = "INVOICE";

    @JsonProperty("phone")
    private String phone;

    @Override
    public String getInfo() {
        //TODO: change code when reveal implementation of Tokenization service
        return phone;
    }

}
