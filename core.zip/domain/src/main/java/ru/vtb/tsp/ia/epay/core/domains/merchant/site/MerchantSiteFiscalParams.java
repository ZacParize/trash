package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;
import ru.vtb.tsp.ia.epay.core.domains.enums.StorageVersion;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxClient;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class MerchantSiteFiscalParams implements Serializable {

  @JsonProperty("isActive")
  private boolean active;

  private TaxClient taxClient;

  @Size(max = 255)
  private String kktId;

  @Size(max = 255)
  private String email;

  @Size(max = 255)
  private String login;

  private String password;

  private Integer publicKeyVersion;

  @Pattern(regexp = "^\\d{12}$|^\\d{10}$", message = "Incorrect merchant site inn")
  private String inn;

  @Size(max = 255)
  private String url;

  private StorageVersion storageVersion;

  @Valid
  private DefaultSettings defaultSettings;

}