package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class Branch {

  @NotEmpty
  @Size(max = 255)
  private String departmentName;

  @NotEmpty
  @Size(max = 255)
  private String departmentBIC;

  @NotEmpty
  @Size(max = 20)
  private String correspondentNumber;
}
