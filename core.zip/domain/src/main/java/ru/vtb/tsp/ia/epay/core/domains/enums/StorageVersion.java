package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;

@AllArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum StorageVersion {

  V_1_2("1.2");

  private final String name;

  @JsonValue
  public String getName() {
    return name;
  }

}
