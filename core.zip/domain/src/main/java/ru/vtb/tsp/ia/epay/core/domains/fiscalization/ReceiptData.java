package ru.vtb.tsp.ia.epay.core.domains.fiscalization;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReceiptData implements Serializable, JsonObject {

  Long receiptInShiftNumber;
  Long shiftNumber;
  LocalDateTime receiptDatetime;
  String fnNumber;
  String kktRegId;
  Long fiscalDocumentNumber;
  String fiscalSign;
  String fnsUrl;
  String receiptUrl;
  String ofdInn;
  BigDecimal totalSum;

}
