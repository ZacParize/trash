package ru.vtb.tsp.ia.epay.core.domains.exceptions;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.Objects;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionError implements JsonObject, Serializable {

  private static final String OK_ID = "00000000";
  private static final String OK_MESSAGE = "SUCCESSFULLY_COMPLETED";
  private static final String OK_DESCRIPTION = "Операция успешно завершена";
  private static final int MICROSERVICE_ID_LENGTH = 3;

  /**
   * Уникальный id ошибки в рамках всех микросервисов
   */
  @JsonProperty("id")
  @Builder.Default
  private String id = OK_ID;

  /**
   * HttpStatus код
   */
  @JsonProperty("httpCode")
  private Integer httpCode;

  /**
   * Классификация ошибки
   */
  @JsonProperty("message")
  @Builder.Default
  private String message = OK_MESSAGE;

  /**
   * Описание ошибки
   */
  @JsonProperty("description")
  @Builder.Default
  private String description = OK_DESCRIPTION;

  /**
   * Трейс запроса
   */
  @JsonProperty("traceId")
  private String traceId;

  @JsonIgnore
  public @Nullable String getMicroserviceId() {
    return Objects.nonNull(id) && id.length() >= MICROSERVICE_ID_LENGTH ?
            id.substring(0, MICROSERVICE_ID_LENGTH) : null;
  }

  @JsonIgnore
  public @Nullable String getNumber() {
    return Objects.nonNull(id) && id.length() > MICROSERVICE_ID_LENGTH ?
            id.substring(MICROSERVICE_ID_LENGTH) : null;
  }

  @JsonIgnore
  public boolean isError() {
    return Objects.nonNull(id) && !OK_ID.equals(id);
  }

  @JsonIgnore
  public void isValidOrThrow(Supplier<? extends RuntimeException> exceptionSupplier) {
    if (isError()) {
      throw exceptionSupplier.get();
    }
  }

}