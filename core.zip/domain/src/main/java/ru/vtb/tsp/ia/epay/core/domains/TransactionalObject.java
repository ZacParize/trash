package ru.vtb.tsp.ia.epay.core.domains;

import java.time.LocalDateTime;

public interface TransactionalObject {

  /**
   *  When the object was added to the system. System-generated only&
   */
  LocalDateTime getCreated();

  /**
   *  When the object was added to the system. System-generated only&
   */
  void setCreated(LocalDateTime created);

  /**
   *  When the object was last modified in the system. System-generated only&
   */
  LocalDateTime getModified();

  /**
   *  When the object was last modified in the system. System-generated only&
   */
  void setModified(LocalDateTime modified);
}
