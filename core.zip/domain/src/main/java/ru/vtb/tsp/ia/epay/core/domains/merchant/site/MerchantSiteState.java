package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.AllArgsConstructor;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import static java.util.stream.Collectors.toMap;

@AllArgsConstructor
public enum MerchantSiteState {

  DRAFT("Draft"),
  NOT_ACTIVE("Not Active"),
  ACTIVE("Active"),
  DELETED("Deleted"),
  BLOCKED("Blocked");

  private static final Map<String, MerchantSiteState> NAMES = Arrays.stream(MerchantSiteState.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(v.getName(), v))
      ).collect(toMap(Map.Entry::getKey, Map.Entry::getValue));

  private final String name;


  @JsonCreator
  public static MerchantSiteState fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown MerchantSite state name: " + name));
  }

  @JsonValue
  public String getName() {
    return name;
  }
}
