package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class Department {

  @NotEmpty
  @Size(max = 255)
  private String departmentRefCode;

  @NotEmpty
  @Size(max = 255)
  private String departmentName;

  @Size(max = 255)
  private String departmentEmail;

  @Size(max = 255)
  private String shortName;

  @Size(max = 255)
  private String address;

  @Size(max = 255)
  private String tpCode;

  private String tpBisCode;

}
