package ru.vtb.tsp.ia.epay.core.domains.customer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerState;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInfo implements Serializable, JsonObject {

  @JsonProperty("mstCustomerId")
  private String mstCustomerId;

  @JsonProperty("email")
  private String email;

  @JsonProperty("phone")
  private String phone;

  @JsonProperty("type")
  private CustomerType type;

  @JsonProperty("state")
  private CustomerState state;

}