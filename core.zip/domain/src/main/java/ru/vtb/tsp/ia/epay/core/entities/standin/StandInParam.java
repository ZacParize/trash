package ru.vtb.tsp.ia.epay.core.entities.standin;

import static ru.vtb.tsp.ia.epay.core.entities.standin.StandInParam.TABLE_NAME;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Table(TABLE_NAME)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class StandInParam {

  public static final String TABLE_NAME = "standin_params";

  @Id
  private Long id;

  @NotNull
  private String key;

  @NotEmpty
  @Column("data")
  @JsonProperty("data")
  private StandInParamValue data;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;


  @Column("modified_at")
  @JsonProperty("modifiedAt")
  private LocalDateTime modifiedAt;
}
