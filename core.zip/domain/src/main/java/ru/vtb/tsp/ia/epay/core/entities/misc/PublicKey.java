package ru.vtb.tsp.ia.epay.core.entities.misc;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Table("public_key")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PublicKey {
    @Id
    @Column("id")
    private Long id;

    @NotEmpty
    private PublicKeyData value;

    @NotNull
    @Column("date_create")
    @JsonProperty("dateCreate")
    private LocalDateTime dateCreate;


    @Column("date_update")
    @JsonProperty("dateUpdate")
    private LocalDateTime dateUpdate;
}
