package ru.vtb.tsp.ia.epay.core.entities.transaction;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.route.Flow;

@Table("transactions")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Transaction {

  @Id
  @Column("transaction_id")
  @JsonProperty("id")
  private String transactionId;

  @NotNull
  @MappedCollection(idColumn = "order_id")
  @JsonProperty("order")
  private Order order;

  @Column("flow")
  @MappedCollection(idColumn = "flow_id")
  @JsonProperty("flow")
  private Flow flow;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @NotNull
  @JsonProperty("amount")
  private Double amount;

  @JsonProperty("amountHold")
  private Double amountHold;

  @NotNull
  @MappedCollection(idColumn = "code")
  @JsonProperty("currency")
  private Currency currency;

  @NotEmpty
  @Column("mst_transaction_id")
  @JsonProperty("mstTransactionId")
  private String mstTransactionId;

  @NotEmpty
  @Column("code")
  @JsonProperty("code")
  private String code;

  @NotNull
  @MappedCollection(idColumn = "id")
  @JsonProperty("mst")
  private MerchantSite mst;

  @NotNull
  @JsonProperty("type")
  private TransactionType type;

  @NotNull
  @JsonProperty("state")
  private TransactionState state;

  @NotNull
  @JsonProperty("data")
  private TransactionPayload data;

  @Version
  @Builder.Default
  private int version = 0;

  public void setState(@Nullable TransactionState state) {
    this.state = state;
    Optional.ofNullable(data).ifPresent(payload -> payload.setStatus(state));
  }

  public void setType(@Nullable TransactionType type) {
    this.type = type;
    Optional.ofNullable(data).ifPresent(payload -> payload.setType(type));
  }

  public void setCreatedAt(@Nullable LocalDateTime createdAt) {
    this.createdAt = createdAt;
    Optional.ofNullable(data).ifPresent(payload -> payload.setCreatedAt(createdAt));
  }

  public boolean isAuthorized() {
    return isCardPayment() && TransactionState.isAuthorized(state);
  }

  public boolean isCompleted() {
    return TransactionState.isCompleted(state);
  }

  public boolean isProcessing() {
    return TransactionState.isProcessing(state);
  }

  public boolean isDeclined() {
    return TransactionState.isDeclined(state);
  }

  public boolean isPaid() {
    return isPayment() && TransactionState.isPaid(state);
  }

  public boolean isRefunded() {
    return isRefund() && TransactionState.isPaid(state);
  }

  public boolean isReversed() {
    return isCardPayment() && TransactionState.isReversed(state);
  }

  public boolean isConfirmed() {
    return isCardPayment() && TransactionState.isConfirmed(state);
  }

  public boolean isRefund() {
    return TransactionType.isRefund(type);
  }

  public boolean isPayment() {
    return TransactionType.isPayment(type);
  }

  public boolean isSbpPayment() {
    return TransactionType.isSbpPayment(type);
  }

  public boolean isSbpRefund() {
    return TransactionType.isSbpRefund(type);
  }

  public boolean isCardRefund() {
    return TransactionType.isCardRefund(type);
  }

  public boolean isCardPayment() {
    return TransactionType.isCardPayment(type);
  }

  public boolean isMirPayPayment() {
    return TransactionType.isMirPayPayment(type);
  }

  public boolean isMirPayRefund() {
    return TransactionType.isMirPayRefund(type);
  }

  public void isValidOrThrow(Supplier<? extends RuntimeException> exceptionSupplier) {
    if (Objects.nonNull(data)) {
      data.isValidOrThrow(exceptionSupplier);
    }
  }

  @JsonIgnore
  public Transaction getConnectedTransaction() {
    return Objects.nonNull(data) ? data.getConnectedTransaction() : null;
  }
}