package ru.vtb.tsp.ia.epay.core.entities.redis;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CardCacheDto implements Serializable {

    private String dpan;
    private String pan;
    private String cvv;
}
