package ru.vtb.tsp.ia.epay.core.domains.fiscalization;

public enum ReceiptOperator {

  OFD_1

}