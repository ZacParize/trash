package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 3DS comp ind.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSCompInd {

    N,
    Y,
    U

}
