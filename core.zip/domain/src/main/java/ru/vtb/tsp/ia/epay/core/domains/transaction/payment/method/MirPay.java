package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MirPay extends Payment {

  public static final String TYPE = "MIR_PAY";

  /**
   * Token Account Number
   */
  @JsonProperty("tan")
  private String tan;
  /**
   * Token Expiration Year. Параметр tey из токена карты из mirpay
   */
  @JsonProperty("expiryYear")
  private String expiryYear;
  /**
   * Authentication Value
   */
  @JsonProperty("cav")
  private String cav;
  /**
   * Уникальный идентификатор In-Application операции, сформированный платформой, в формате UUID
   */
  @JsonProperty("transId")
  private String transId;

  @JsonProperty("transactionCode")
  private String transactionCode;

  /**
   * TODO: change code when reveal implementation of Tokenization service
   *
   * @return a parameter that explicitly characterizes this payment
   */
  @Override
  public String getInfo() {
    return transactionCode;
  }

}
