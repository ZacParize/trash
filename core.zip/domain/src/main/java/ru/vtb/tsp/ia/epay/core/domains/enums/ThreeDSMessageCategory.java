package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

/**
 * 3DS Message category.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@RequiredArgsConstructor
@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSMessageCategory {

    PAYMENT("01"),
    NON_PAYMENT("02");

    private final String code;

    public static Optional<ThreeDSMessageCategory> findByCode(String code) {
        for (var val : ThreeDSMessageCategory.values()) {
            if (val.getCode().equals(code)) {
                return Optional.of(val);
            }
        }
        return Optional.empty();
    }

}
