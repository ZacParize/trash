package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "additionalDataType")
@JsonSubTypes({
        @JsonSubTypes.Type(value = ApplePay.class, name = ApplePay.TYPE),
        @JsonSubTypes.Type(value = GooglePay.class, name = GooglePay.TYPE),
        @JsonSubTypes.Type(value = SamsungPay.class, name = SamsungPay.TYPE),
        @JsonSubTypes.Type(value = Threeds.class, name = Threeds.TYPE)
})
public abstract class PaymentData implements Serializable {

    @JsonProperty("eci")
    private String eci;
    @JsonProperty("cavv")
    private String cavv;

}
