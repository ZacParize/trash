package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxSystem;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class DefaultSettings implements Serializable {

  private TaxSystem taxSystem;

  private TaxRate taxRate;

  private ProductType productType;

  private PaymentType paymentType;

  private String productName;

}