package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.util.Optional;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.With;
import ru.vtb.tsp.ia.epay.core.domains.Entity;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;
import ru.vtb.tsp.ia.epay.core.domains.enums.MerchantSiteType;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.validation.MerchantSiteConstraint;

@Data
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@With
@JsonIgnoreProperties(ignoreUnknown = true)
@MerchantSiteConstraint
public class MerchantSite extends Entity<String, MerchantSiteState> {

  @NotNull
  @JsonView(UpdatableJsonView.class)
  @JsonProperty("merchantId")
  private String merchantId;

  @JsonView(UpdatableJsonView.class)
  @JsonProperty("type")
  private MerchantSiteType type;

  @Size(max = 255)
  @JsonView(UpdatableJsonView.class)
  @JsonProperty("url")
  private String url;

  @NotEmpty
  @Size(max = 255)
  @JsonView(UpdatableJsonView.class)
  @JsonProperty("name")
  private String name;

  @NotEmpty
  @JsonView(UpdatableJsonView.class)
  @JsonProperty("login")
  private String login;

  @JsonView(UpdatableJsonView.class)
  @JsonProperty("externalApplicationId")
  private String externalApplicationId;

  @NotNull
  @JsonView(UpdatableJsonView.class)
  @JsonProperty("params")
  @Valid
  private MerchantSiteParams params;

  public MerchantSite() {
    super(UUID.randomUUID().toString());
  }

  public MerchantSite(String id) {
    super(id);
  }

  @JsonIgnore
  public boolean isEnableSbpPayment() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getSbpParams)
        .map(MerchantSiteSbpParams::isEnableSbpPayment)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableSbpPartialRefund() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getSbpParams)
        .map(MerchantSiteSbpParams::isEnablePartialRefund)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableC2aTransfer() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getTransferParams)
        .map(MerchantSiteTransferParams::isEnableC2aTransfer)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableA2cTransfer() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getTransferParams)
        .map(MerchantSiteTransferParams::isEnableA2cTransfer)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableCardPayment() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getCardParams)
        .map(MerchantSiteCardParams::isEnableCardPayment)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableCardPartialRefund() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getCardParams)
        .map(MerchantSiteCardParams::isEnablePartialRefund)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableCardFlowThreeDS() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getCardParams)
        .map(MerchantSiteCardParams::isEnableCardFlowThreeDS)
        .orElse(false);
  }

  @JsonIgnore
  public boolean isEnableTwoStagePayment() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getCardParams)
        .map(MerchantSiteCardParams::isEnableTwoStage)
        .orElse(false);
  }

  @JsonIgnore
  public String getTerminalId() {
    return Optional.ofNullable(params)
        .map(MerchantSiteParams::getCardParams)
        .map(MerchantSiteCardParams::getTerminalId)
        .orElse(null);
  }

}