package ru.vtb.tsp.ia.epay.core.domains;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@EqualsAndHashCode
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public abstract class Entity<I, S> implements StatefulObject<S>, TransactionalObject {

  private static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

  @NotNull
  @Getter
  @Setter
  private I id;

  @JsonView(UpdatableJsonView.class)
  @Getter
  @Setter
  private S state;

  @Getter
  @Setter
  @JsonFormat(shape = Shape.STRING, pattern = DATETIME_FORMAT)
  private LocalDateTime created;

  @Getter
  @Setter
  @JsonFormat(shape = Shape.STRING, pattern = DATETIME_FORMAT)
  private LocalDateTime modified;

  public Entity(I id) {
    this.id = id;
  }
}
