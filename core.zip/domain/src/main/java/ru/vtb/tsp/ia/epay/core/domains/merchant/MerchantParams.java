package ru.vtb.tsp.ia.epay.core.domains.merchant;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

import java.io.Serializable;

@Data
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantParams implements Serializable, JsonObject {
}