package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class GooglePay extends PaymentData {

    public static final String TYPE = "GOOGLEPAY";

    @JsonProperty("paymentToken")
    private String paymentToken;

    public GooglePay(String eci, String cavv, String paymentToken) {
        super(eci, cavv);
        this.paymentToken = paymentToken;
    }
}
