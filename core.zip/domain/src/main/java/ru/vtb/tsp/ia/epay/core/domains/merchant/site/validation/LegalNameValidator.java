package ru.vtb.tsp.ia.epay.core.domains.merchant.site.validation;

import java.util.Objects;
import java.util.regex.Pattern;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.LegalName;

public class LegalNameValidator implements ConstraintValidator<LegalNameConstraint, LegalName> {

  private static final String EMPTY = "";
  private static final int LEGAL_NAME_LENGTH = 35;
  private static final Pattern PATTERN = Pattern.compile("^[A-Za-z]{0," + LEGAL_NAME_LENGTH + "}$");

  @Override
  public boolean isValid(LegalName value, ConstraintValidatorContext context) {
    if (Objects.isNull(value)) {
      return true;
    }
    final var name = Objects.requireNonNullElse(value.getName(), EMPTY);
    final var opf = Objects.requireNonNullElse(value.getOpf(), EMPTY);
    return (name.length() + opf.length() + 1 <= LEGAL_NAME_LENGTH)
        && PATTERN.matcher(name).matches() && PATTERN.matcher(opf).matches();
  }

}