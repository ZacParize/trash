package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

/**
 * 3DS request authentificator ind.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@RequiredArgsConstructor
@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSReqAuthInd {

    PAYMENT("01"),
    SUBSCRIPTION("02"),
    PART_PAYMENT("03"),
    ADDING_CARD("04"),
    SAVING_CARD("05"),
    CARD_CHECKING("06");

    private final String code;

    public static Optional<ThreeDSReqAuthInd> findByCode(String code) {
        for (var val : ThreeDSReqAuthInd.values()) {
            if (val.getCode().equals(code)) {
                return Optional.of(val);
            }
        }
        return Optional.empty();
    }

}
