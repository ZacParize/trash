package ru.vtb.tsp.ia.epay.core.entities.route;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

import javax.validation.constraints.NotEmpty;

@Table("flows")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Flow {

    @Id
    @Column("flow_id")
    @JsonProperty("flowId")
    private Long flowId;

    @MappedCollection(idColumn = "id")
    @JsonProperty("mst")
    private MerchantSite mst;

    @NotEmpty
    @JsonProperty("name")
    private String name;

    @NotEmpty
    @JsonProperty("description")
    private String description;

}