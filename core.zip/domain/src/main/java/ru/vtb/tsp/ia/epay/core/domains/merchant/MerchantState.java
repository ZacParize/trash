package ru.vtb.tsp.ia.epay.core.domains.merchant;

import static java.util.stream.Collectors.toMap;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum
MerchantState {

  ACTIVE("Active"),
  DELETED("Deleted"),
  BLOCKED("Blocked");

  private static final Map<String, MerchantState> NAMES
      = Arrays.stream(MerchantState.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(v.getName(), v))
      ).collect(toMap(Map.Entry::getKey, Map.Entry::getValue));

  private final String name;


  @JsonCreator
  public static MerchantState fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown MerchantState name: " + name));
  }

  @JsonValue
  public String getName() {
    return name;
  }
}
