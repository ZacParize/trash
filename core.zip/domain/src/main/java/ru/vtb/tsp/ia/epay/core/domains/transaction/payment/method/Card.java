package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.enums.CofOperation;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.PaymentData;
import ru.vtb.tsp.ia.epay.tokenization.dto.domains.Binding;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Card extends Payment {

  public static final String TYPE = "CARD";

  @JsonProperty("encryptedPan")
  private String encryptedPan;
  @JsonProperty("expiryDate")
  private LocalDateTime expiryDate;
  @JsonProperty("encryptedCvv")
  private String encryptedCvv;
  @JsonProperty("cardHolder")
  private String cardHolder;
  @JsonProperty("additionalData")
  private PaymentData additionalData;

  @JsonProperty("email")
  private String email;

  /**
   * Маскированный дпан **** **** **** 1234
   */
  @JsonProperty("dpanMasked4digets")
  private String dpanMasked4digets;

  @JsonProperty("binding")
  private Binding binding;

  @JsonProperty("cofOperation")
  @Builder.Default
  private CofOperation cofOperation = CofOperation.NONE;

  @Override
  public String getInfo() {
    //TODO: change code when reveal implementation of Tokenization service
    return encryptedPan;
  }

}