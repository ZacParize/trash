package ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "paymentMethod")
@JsonSubTypes({
    @JsonSubTypes.Type(value = Card.class, name = Card.TYPE),
    @JsonSubTypes.Type(value = Invoice.class, name = Invoice.TYPE),
    @JsonSubTypes.Type(value = Token.class, name = Token.TYPE),
    @JsonSubTypes.Type(value = Sbp.class, name = Sbp.TYPE),
    @JsonSubTypes.Type(value = MirPay.class, name = MirPay.TYPE)
})
public abstract class Payment implements Serializable {

  public abstract String getInfo();

}
