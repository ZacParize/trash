package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@JsonFormat(shape = Shape.STRING)
@RequiredArgsConstructor
public enum TaxRate {

  VAT_ZERO("vat0"),
  VAT_PREFERENTIAL("vat10"),
  VAT_GENERAL("vat20"),
  VAT_PREFERENTIAL_CALC("vat110"),
  VAT_GENERAL_CALC("vat120"),
  NONE("none");

  private final String value;

  private static final Map<String, TaxRate> NAMES = Arrays.stream(TaxRate.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(v.getValue(), v)
      ))
      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

  public static TaxRate fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown TaxRate name: " + name));
  }
}
