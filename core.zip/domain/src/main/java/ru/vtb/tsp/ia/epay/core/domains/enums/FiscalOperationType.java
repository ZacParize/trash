package ru.vtb.tsp.ia.epay.core.domains.enums;

public enum FiscalOperationType {
  INCOME,
  INCOME_RETURN
}
