package ru.vtb.tsp.ia.epay.core.domains.enums;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ProductType {

  GOODS(1),
  EXCISE_GOODS(2),
  JOB(3),
  SERVICE(4),
  GAMBLING_BET(5),
  GAMBLING_WIN(6),
  LOTTERY_TICKET(7),
  LOTTERY_WIN(8),
  RID_ACCESS(9),
  ADVANCE(10),
  AGENT_REWARD(11),
  COMPOSITE_11(12),
  COMPOSITE_NONE_11(13),
  PROPERTY_LAW(14),
  NONE_OPERATIONAL_INCOME(15),
  TAX_REDUCTION(16),
  TRADE_FEE(17),
  RESORT_FEE(18),
  CAUTION_MONEY(19),
  EXPENSE_W_INCOME_REDUCTION(20),
  PENSION_INSUARACE(21),
  PENSION_INSUARACE_W_PAYMENTS(22),
  MEDICAL_INSUARACE(23),
  MEDICAL_INSUARACE_W_PAYMENTS(24),
  SOCIAL_INSUARANCE(25),
  CASINO(26),
  PAYING_AGENT(27),
  NO_MARKING_CODE(30),
  MARKING_CODE(31),
  NO_MARKING_CODE_EXCISE(32),
  MARKING_CODE_EXCISE(33);

  private final int code;

  private static final Map<String, ProductType> NAMES = Arrays.stream(ProductType.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(String.valueOf(v.getCode()), v)
      ))
      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

  public static ProductType fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown ProductType name: " + name));
  }

  public static ProductType fromCode(int code) {
    return Optional.ofNullable(NAMES.get(String.valueOf(code)))
        .orElseThrow(() -> new IllegalArgumentException("Unknown ProductType code: " + code));
  }
}