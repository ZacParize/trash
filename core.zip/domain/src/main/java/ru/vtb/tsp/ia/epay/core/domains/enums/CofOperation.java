package ru.vtb.tsp.ia.epay.core.domains.enums;

import lombok.Getter;
import org.springframework.util.ObjectUtils;

@Getter
public enum CofOperation {

  NONE("NONE"),
  INITIAL("INITIAL"),
  PAYMENT("PAYMENT"),
  DEACTIVATE("DEACTIVATE");

  CofOperation(String name) {
    this.name = name;
  }

  private String name;

  public static CofOperation fromName(String name) {
    if (!ObjectUtils.isEmpty(name)) {
      for (CofOperation s : CofOperation.values()) {
        if (s.name.equalsIgnoreCase(name)) {
          return s;
        }
      }
    }
    return CofOperation.NONE;
  }

}