package ru.vtb.tsp.ia.epay.core.entities.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Table("transaction_info")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionInfo {

    @Id
    @Column("transaction_info_id")
    @JsonProperty("id")
    private Long transactionInfoId;

    @NotNull
    @MappedCollection(idColumn = "transaction_id")
    @JsonProperty("transaction")
    private Transaction transaction;

    @NotEmpty
    @Column("key")
    @JsonProperty("key")
    private TransactionInfoKey key;

    @NotEmpty
    @Column("value")
    @JsonProperty("value")
    private String value;

    @NotNull
    @Column("created_at")
    @JsonProperty("createdAt")
    private LocalDateTime createdAt;

}