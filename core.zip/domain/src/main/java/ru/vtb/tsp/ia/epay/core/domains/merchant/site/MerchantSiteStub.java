package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import lombok.Data;

@Data
public class MerchantSiteStub {

  private String id;
  private String name;
  private String merchantId;
  private String url;
  private MerchantSiteState state;

  public MerchantSiteStub(MerchantSite merchantSite) {
    this.id = merchantSite.getId();
    this.name = merchantSite.getName();
    this.merchantId = merchantSite.getMerchantId();
    this.url = merchantSite.getUrl();
    this.state = merchantSite.getState();
  }
}
