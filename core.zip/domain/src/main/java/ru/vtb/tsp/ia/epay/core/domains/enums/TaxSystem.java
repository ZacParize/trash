package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum TaxSystem {

  GENERAL,
  SIMPLE_INCOME,
  SIMPLE_INCOME_EXPENSE,
  IMPUTED_INCOME,
  AGRICULTURAL,
  PATENT;

}
