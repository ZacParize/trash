package ru.vtb.tsp.ia.epay.core.domains.bundle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class FiscalInfo implements Serializable, JsonObject {

  String clientEmail;

}
