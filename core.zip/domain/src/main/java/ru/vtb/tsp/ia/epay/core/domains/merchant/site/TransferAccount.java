package ru.vtb.tsp.ia.epay.core.domains.merchant.site;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.time.LocalDate;
import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class TransferAccount {

  @NotEmpty
  @Size(min = 20, max = 20)
  private String accountNumber;

  @NotEmpty
  @Size(max = 5)
  private String accountBalanceNum;

  @Valid
  @NotNull
  private LegalName legalName;

  private LocalDate opened;

  private LocalDate closed;

  private String status;

  private String currency;

  @NotNull
  private Department department;

  @NotNull
  private Branch branch;

  @JsonProperty("isActive")
  private boolean active;

}
