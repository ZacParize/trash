package ru.vtb.tsp.ia.epay.core.domains.enums;

import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum PaymentType {

  FULL_PREPAYMENT("full_prepayment"),
  PARTIAL_PREPAYMENT("prepayment"),
  FULL_PAYMENT("full_payment"),
  PARTIAL_PAYMENT("partial_payment"),
  ADVANCE("advance"),
  CREDIT("credit"),
  CREDIT_PAYMENT("credit_payment");

  private final String value;

  private static final Map<String, PaymentType> NAMES = Arrays.stream(PaymentType.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(v.getValue(), v)
      ))
      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

  public static PaymentType fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown PaymentType name: " + name));
  }
}
