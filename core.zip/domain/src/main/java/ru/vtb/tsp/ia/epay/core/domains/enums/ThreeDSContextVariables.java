package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

/**
 * 3DS variables for using in context.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 29.10.2021
 */
@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSContextVariables {

    MK_ORDER_ID("MK_ORDER_ID"),
    MK_SESS_ID("MK_SESSION_ID"),
    TDS_URL("TDS_URL"),
    TDS_VERSION("TDS_3DS_VERSION"),
    TDS_THREEDS_VERSION("TDS_VERSION"),
    TDS_NEXT("TDS_NEXT_STEP"),
    TDS_BRAND("TDS_CARD_BRAND"),
    TDS_ACS("TDS_ACS_URL"),
    TDS_METHOD("TDS_METHOD_URL"),
    TDS_ARES("TDS_ARES"),
    TDS_CRES("TDS_CRES"),
    TDS_AREQ("TDS_AREQ"),
    TDS_PAREQ("TDS_PAREQ"),
    TDS_PARES("TDS_PARES"),
    TDS_CREQ("TDS_CREQ"),
    TDS_THREEDS_METHOD("TDS_3DS_METHOD"),
    TDS_MERCHANT_TID("TDS_MERCHANT_TRANS_ID"),
    TDS_METHOD_NOTIF("TDS_3DS_METHOD_NOTIFICATION"),
    TDS_SERVER_TID("TDS_3DS_SERVER_TRANS_ID"),
    REF_TYPE("TDS_REFINEMENT_TYPE"),
    CAVV("CAVV"),
    ECI("ECI"),
    XID("XID"),
    TDS_AREQ_3DS_VERSION("TDS_AREQ_VERSION"),
    TDS_AREQ_VERIF("TDS_AREQ_VERIFICATION"),
    TDS_CRES_3DS_VERSION("TDS_CRES_VERSION"),
    TDS_CRES_VERIF("TDS_CRES_VERIFICATION"),
    MD("MD"),
    TERM_URL("TERM_URL")
    ;

    private final String contextName;

    public String cname() {
         return contextName;
    }

    public static Optional<ThreeDSContextVariables> findByContextName(String contextName) {
        for (var val : ThreeDSContextVariables.values()) {
            if (val.getContextName().equals(contextName)) {
                return Optional.of(val);
            }
        }
        return Optional.empty();
    }
}
