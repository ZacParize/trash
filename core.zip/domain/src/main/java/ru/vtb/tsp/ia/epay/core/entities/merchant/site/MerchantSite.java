package ru.vtb.tsp.ia.epay.core.entities.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.Optional;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteCardParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteTransferParams;
import ru.vtb.tsp.ia.epay.core.entities.merchant.Merchant;

@Deprecated
@Table("merchant_sites")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSite {

    @Id
    @Column("id")
    @JsonProperty("id")
    private String id;

    @NotNull
    @MappedCollection(idColumn = "id")
    @JsonProperty("merchant")
    private Merchant merchant;

    @NotEmpty
    @Column("url")
    @JsonProperty("url")
    private String url;

    @NotEmpty
    @Column("name")
    @JsonProperty("name")
    private String name;

    @NotEmpty
    @Column("login")
    @JsonProperty("login")
    private String login;

    @Column("external_application_id")
    @JsonProperty("externalApplicationId")
    private String externalApplicationId;

    @NotNull
    @Column("params")
    @JsonProperty("params")
    private MerchantSiteParams params;

    @JsonIgnore
    public boolean isEnableSbpPayment() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getSbpParams)
            .map(MerchantSiteSbpParams::isEnableSbpPayment)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableSbpPartialRefund() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getSbpParams)
            .map(MerchantSiteSbpParams::isEnablePartialRefund)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableC2aTransfer() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getTransferParams)
            .map(MerchantSiteTransferParams::isEnableC2aTransfer)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableA2cTransfer() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getTransferParams)
            .map(MerchantSiteTransferParams::isEnableA2cTransfer)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableCardPayment() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::isEnableCardPayment)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableCardPartialRefund() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::isEnablePartialRefund)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableCardFlowThreeDS() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::isEnableCardFlowThreeDS)
            .orElse(false);
    }

    @JsonIgnore
    public boolean isEnableTwoStagePayment() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::isEnableTwoStage)
            .orElse(false);
    }

    @JsonIgnore
    public String getTerminalId() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::getTerminalId)
            .orElse(null);
    }

    @JsonIgnore
    public boolean isEnableMirPayment() {
        return Optional.ofNullable(params)
            .map(MerchantSiteParams::getCardParams)
            .map(MerchantSiteCardParams::isEnableMirPayment)
            .orElse(false);
    }

}