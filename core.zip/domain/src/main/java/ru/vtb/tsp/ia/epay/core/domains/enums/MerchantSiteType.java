package ru.vtb.tsp.ia.epay.core.domains.enums;

public enum MerchantSiteType {
  INTERNET_ACQUIRING,
  A2C_TRANSFER,
  C2A_TRANSFER
}
