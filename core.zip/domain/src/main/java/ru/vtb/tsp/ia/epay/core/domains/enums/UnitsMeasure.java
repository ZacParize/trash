package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import java.util.AbstractMap.SimpleEntry;
import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@JsonFormat(shape = Shape.STRING)
@RequiredArgsConstructor
public enum UnitsMeasure {

  SINGLE_ITEM(0),
  GRAMM(10),
  KILOGRAMM(11),
  TON(12),
  SANTIMETER(20),
  DECIMETER(21),
  METER(22),
  SQUARE_SANTIMETER(30),
  SQUARE_DECIMETER(31),
  SQUARE_METER(32),
  MILLILITER(40),
  LITER(41),
  CUBIC_METER(42),
  KILOWATT_HOUR(50),
  GIGACALORIE(51),
  HOURS_24(70),
  HOUR(71),
  MINUTE(72),
  SECOND(73),
  KILOBYTE(80),
  MEGABYTE(81),
  GIGABYTE(82),
  TERABYTE(83),
  OTHER(255);

  private final int code;

  private static final Map<String, UnitsMeasure> NAMES = Arrays.stream(UnitsMeasure.values())
      .flatMap(v -> Stream.of(
          new SimpleEntry<>(v.name(), v),
          new SimpleEntry<>(String.valueOf(v.getCode()), v)
      ))
      .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));

  public static UnitsMeasure fromName(String name) {
    Objects.requireNonNull(name);
    return Optional.ofNullable(NAMES.get(name))
        .orElseThrow(() -> new IllegalArgumentException("Unknown UnitsMeasure name: " + name));
  }

  public static UnitsMeasure fromCode(int code) {
    return Optional.ofNullable(NAMES.get(String.valueOf(code)))
        .orElseThrow(() -> new IllegalArgumentException("Unknown UnitsMeasure code: " + code));
  }
}
