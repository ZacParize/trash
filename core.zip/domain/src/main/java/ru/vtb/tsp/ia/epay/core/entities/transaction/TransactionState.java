package ru.vtb.tsp.ia.epay.core.entities.transaction;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TransactionState {

  NEW("NEW") /*Новая*/,
  AUTHORIZED("AUTHORIZED") /*Авторизован*/,
  DECLINED("DECLINED") /*Отклонена*/,
  CONFIRMED("CONFIRMED") /*Подтверждена*/,
  RECONCILED("RECONCILED") /*Проведена*/,
  REVERSED("REVERSED") /*Отмена холда*/,
  PAUSED("PAUSED") /*Приостановлен*/,
  PROCESSING("PROCESSING") /*В работе*/,
  SETTLED("SETTLED") /*Платеж осуществлен*/,
  SBP_PAYMENT_CREATED("SBP_PAYMENT_CREATED") /*Платеж создан в СБП*/,
  SBP_REFUND_CREATED("SBP_REFUND_CREATED") /*Возврат создан в СБП*/,
  PARTIALLY_CONFIRMED("PARTIALLY_CONFIRMED") /*Частично подтверждена*/,
  PARTIALLY_RECONCILED("PARTIALLY_RECONCILED") /*Частично проведена*/,
  MIR_PAY_PAYMENT_CREATED("MIR_PAY_PAYMENT_CREATED") /*По транзакции инициирована оплата через MirPay*/,
  CREATED("CREATED")/*Создана*/,
  FEE_ADDED("FEE_ADDED")/*Комиссия расчитана*/,
  HELD("HELD")/*Сумма перевода+комиссия захолдированы в ЦФТ*/,
  PAID("PAID")/*Выполнен p2pCredit в Мультикарте (перевод на карту физ. лица)*/,
  REJECTED("REJECTED")/*Мультикарта вернула отказ в проведении операции p2pCredit*/,
  HOLD_CANCELED("HOLD_CANCELED")/*Выполнена отмена холда в ЦФТ
    (средства возвращены с транзитного счёта филиала р/с на счёт мерчанта)*/,
  ABS_ERROR("ABS_ERROR")/*Ошибка при финальном переводе средств с транзитного
    счёта филиала р/с на транзитный счёт ГО*/;

  private final String value;

  protected static final List<TransactionState> TRANSFER_PROCESSING_STATES = List.of(NEW,
      FEE_ADDED, HELD, HOLD_CANCELED);

  protected static final List<TransactionState> PROCESSING_STATES = List.of(NEW, SBP_REFUND_CREATED,
      SBP_PAYMENT_CREATED, PROCESSING, PAUSED, AUTHORIZED, MIR_PAY_PAYMENT_CREATED);

  protected static final List<TransactionState> TRANSFER_PAYED_STATES = List.of(PAID);

  protected static final List<TransactionState> PAYED_STATES = List.of(SETTLED, RECONCILED,
      CONFIRMED, PARTIALLY_CONFIRMED, PARTIALLY_RECONCILED, REVERSED);

  protected static final List<TransactionState> DECLINED_STATES = List.of(DECLINED, REJECTED);

  protected static final List<TransactionState> TRANSFER_DECLINED_STATES = List.of(DECLINED, REJECTED);
  protected static final List<TransactionState> TRANSFER_ERROR_STATES= List.of(ABS_ERROR);

  protected static final List<TransactionState> TRANSFER_FINAL_STATES = Collections.unmodifiableList(
      Stream.concat(
          Stream.concat(TRANSFER_ERROR_STATES.stream(), TRANSFER_DECLINED_STATES.stream()),
          Stream.of(ABS_ERROR)).collect(Collectors.toList()));

  protected static final List<TransactionState> FINAL_STATES = Collections.unmodifiableList(
      Stream.concat(PAYED_STATES.stream(), DECLINED_STATES.stream())
          .collect(Collectors.toList()));

  protected static final List<TransactionState> FISCAL_STATES = List.of(CONFIRMED, RECONCILED);

  public static boolean isCompleted(@Nullable TransactionState state) {
    return Objects.nonNull(state) && FINAL_STATES.contains(state);
  }

  public static boolean isTransferCompleted(@Nullable TransactionState state) {
    return Objects.nonNull(state) && TRANSFER_FINAL_STATES.contains(state);
  }

  public static boolean isProcessing(@Nullable TransactionState state) {
    return Objects.nonNull(state) && PROCESSING_STATES.contains(state);
  }

  public static boolean isTransferProcessing(@Nullable TransactionState state) {
    return Objects.nonNull(state) && TRANSFER_PROCESSING_STATES.contains(state);
  }

  public static boolean isPaid(@Nullable TransactionState state) {
    return Objects.nonNull(state) && PAYED_STATES.contains(state);
  }

  public static boolean isTransferPaid(@Nullable TransactionState state) {
    return Objects.nonNull(state) && TRANSFER_PAYED_STATES.contains(state);
  }

  public static boolean isDeclined(@Nullable TransactionState state) {
    return Objects.nonNull(state) && DECLINED_STATES.contains(state);
  }

  public static boolean isTransferDeclined(@Nullable TransactionState state) {
    return Objects.nonNull(state) && TRANSFER_DECLINED_STATES.contains(state);
  }

  public static boolean isAuthorized(@Nullable TransactionState state) {
    return Objects.nonNull(state) && AUTHORIZED.equals(state);
  }

  public static boolean isReversed(@Nullable TransactionState state) {
    return Objects.nonNull(state) && REVERSED.equals(state);
  }

  public static boolean isConfirmed(@Nullable TransactionState state) {
    return Objects.nonNull(state) && CONFIRMED.equals(state);
  }

  public static boolean isFiscalState(@Nullable TransactionState state) {
    return Objects.nonNull(state) && FISCAL_STATES.contains(state);
  }
}