package ru.vtb.tsp.ia.epay.core.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class Subamount implements Serializable {

    @JsonProperty("typeId")
    private Long typeId;

    @JsonProperty("unitId")
    private Long unitId;

    @JsonProperty("amount")
    private Amount amount;

    @JsonProperty("comission")
    private Comission comission;

}