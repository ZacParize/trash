package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class MerchantSiteSbpParams implements Serializable {

    @JsonProperty("enableSbpPayment")
    private boolean enableSbpPayment;

    @JsonProperty("enablePartialRefund")
    private boolean enablePartialRefund;

    @JsonProperty("merchantId")
    private String merchantId;

    @JsonProperty("legalId")
    private String legalId;

    @JsonProperty("account")
    private String account;

    @JsonProperty("templateVersion")
    private String templateVersion;

    @JsonProperty("qrcType")
    private String qrcType;

    @JsonProperty("paymentPurpose")
    private String paymentPurpose;

    @JsonProperty("refundPurpose")
    private String refundPurpose;

}