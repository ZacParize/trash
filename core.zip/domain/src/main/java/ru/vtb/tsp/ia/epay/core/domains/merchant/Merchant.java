package ru.vtb.tsp.ia.epay.core.domains.merchant;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.With;
import ru.vtb.tsp.ia.epay.core.domains.Entity;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

import javax.validation.constraints.NotEmpty;
import java.util.UUID;

@AllArgsConstructor
@With
@Data
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Merchant extends Entity<String, MerchantState> {

    @NotEmpty
    @JsonProperty("name")
    @JsonView(UpdatableJsonView.class)
    private String name;

    @JsonView(UpdatableJsonView.class)
    @JsonProperty("mdmCode")
    private Long mdmCode;

    @JsonIgnore
    private MerchantParams params;

    public Merchant() {
        super(UUID.randomUUID().toString());
    }

    public Merchant(String id) {
        super(id);
    }
}