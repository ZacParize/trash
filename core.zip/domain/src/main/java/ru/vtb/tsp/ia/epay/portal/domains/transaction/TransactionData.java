package ru.vtb.tsp.ia.epay.portal.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionData implements Serializable {

  @JsonProperty("code")
  private String code;

  @JsonProperty("type")
  private TransactionType type;

  @JsonProperty("paymentId")
  private String paymentId;

  @JsonProperty("refundCodeLink")
  private String refundCodeLink;

  @JsonProperty("responseData")
  private ResponseData responseData;

  @JsonProperty("paymentData")
  private PaymentData paymentData;

  @JsonProperty("createdDate")
  private LocalDateTime createdDate;

  @JsonProperty("amount")
  private Amount amount;

  @JsonProperty("status")
  private TransactionStatus status;

  @JsonProperty("cardInfo")
  private CardInfoData cardInfo;

}