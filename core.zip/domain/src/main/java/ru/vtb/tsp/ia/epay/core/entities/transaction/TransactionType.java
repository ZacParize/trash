package ru.vtb.tsp.ia.epay.core.entities.transaction;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum TransactionType {

  APPLE_PAYMENT("APPLE_PAYMENT") /*Оплата с помощью Apple Pay*/,
  GOOGLE_PAYMENT("GOOGLE_PAYMENT") /*Оплата с помощью Google Pay*/,
  CARD_PAYMENT("CARD_PAYMENT") /*Оплата картой с 3DS*/,
  CARD_PAYMENT_WITHOUT_3DS("CARD_PAYMENT_WITHOUT_3DS") /*Оплата картой с 3DS*/,
  CARD_REFUND("CARD_REFUND") /*Возврат по картам*/,
  PARTIAL_CARD_REFUND("PARTIAL_CARD_REFUND") /*Частичный возврат по картам*/,
  SBP_PAYMENT("SBP_PAYMENT") /*Оплата СБП*/,
  INVOICE_PAYMENT("INVOICE_PAYMENT") /*Оплата инвойса*/,
  SBP_REFUND("SBP_REFUND") /*Возврат СБП*/,
  PARTIAL_SBP_REFUND("PARTIAL_SBP_REFUND") /*Частичный возврат СБП*/,
  CARD_PAYMENT_TWO_STAGE("CARD_PAYMENT_TWO_STAGE") /*Оплата картой двустадийка без 3DS*/,
  CARD_PAYMENT_TWO_STAGE_3DS("CARD_PAYMENT_TWO_STAGE_3DS") /*Оплата картой двустадийка c 3DS*/,
  A2C_TRANSFER("A2C_TRANSFER"), /*A2C выплата мерчантом на карту*/
  C2A_TRANSFER("C2A_TRANSFER"), /*С2A перевод с карты на счет*/
  GW_PAYMENT("GW_PAYMENT"), /*Оплата картой с готовой 3DS авторизацией и без 3DS*/
  COF_PAYMENT("COF_PAYMENT") /*Транзакция COF без 3DS*/,
  MIR_PAYMENT_WEB_BASED("MIR_PAYMENT_WEB_BASED") /*Транзакция Mir Pay*/,
  MIR_PAYMENT_WEB_BASED_REFUND("MIR_PAYMENT_WEB_BASED_REFUND") /*Возврат Mir Pay*/,
  PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND("PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND") /*Частичный
  Возврат Mir Pay*/;

  private final String value;

  protected static final List<TransactionType> CARD_PAYMENT_TYPES = List.of(CARD_PAYMENT,
      CARD_PAYMENT_WITHOUT_3DS, CARD_PAYMENT_TWO_STAGE,
      CARD_PAYMENT_TWO_STAGE_3DS, GW_PAYMENT, COF_PAYMENT);

  protected static final List<TransactionType> SBP_PAYMENT_TYPES = List.of(SBP_PAYMENT);

  protected static final List<TransactionType> MIR_PAY_PAYMENT_TYPES = List.of(
      MIR_PAYMENT_WEB_BASED);

  protected static final List<TransactionType> PAYMENT_TYPES = Stream.of(CARD_PAYMENT_TYPES,
          SBP_PAYMENT_TYPES,
          MIR_PAY_PAYMENT_TYPES)
      .flatMap(List::stream)
      .collect(Collectors.toList());

  protected static final List<TransactionType> SBP_REFUND_TYPES = List.of(SBP_REFUND,
      PARTIAL_SBP_REFUND);

  protected static final List<TransactionType> CARD_REFUND_TYPES = List.of(CARD_REFUND,
      PARTIAL_CARD_REFUND);

  protected static final List<TransactionType> MIR_PAY_REFUND_TYPES = List.of(
      MIR_PAYMENT_WEB_BASED_REFUND, PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND);

  protected static final List<TransactionType> REFUND_TYPES = Stream.of(SBP_REFUND_TYPES,
          CARD_REFUND_TYPES,
          MIR_PAY_REFUND_TYPES)
      .flatMap(List::stream)
      .collect(Collectors.toList());

  protected static final List<TransactionType> TRANSFER_TYPES = List.of(A2C_TRANSFER,
      C2A_TRANSFER);

  protected static final List<TransactionType> FISCAL_PAYMENT_TYPES = List.of(SBP_PAYMENT,
      CARD_PAYMENT, CARD_PAYMENT_WITHOUT_3DS, MIR_PAYMENT_WEB_BASED);

  protected static final List<TransactionType> FISCAL_REFUND_TYPES = List.of(SBP_REFUND,
      PARTIAL_SBP_REFUND, CARD_REFUND, PARTIAL_CARD_REFUND, MIR_PAYMENT_WEB_BASED_REFUND,
      PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND);

  public static boolean isRefund(@Nullable TransactionType type) {
    return Objects.nonNull(type) && REFUND_TYPES.contains(type);
  }

  public static boolean isPayment(@Nullable TransactionType type) {
    return Objects.nonNull(type) && PAYMENT_TYPES.contains(type);
  }

  public static boolean isSbpPayment(@Nullable TransactionType type) {
    return Objects.nonNull(type) && SBP_PAYMENT_TYPES.contains(type);
  }

  public static boolean isSbpRefund(@Nullable TransactionType type) {
    return Objects.nonNull(type) && SBP_REFUND_TYPES.contains(type);
  }

  public static boolean isCardRefund(@Nullable TransactionType type) {
    return Objects.nonNull(type) && CARD_REFUND_TYPES.contains(type);
  }

  public static boolean isCardPayment(@Nullable TransactionType type) {
    return Objects.nonNull(type) && CARD_PAYMENT_TYPES.contains(type);
  }

  public static boolean isTransfer(@Nullable TransactionType type) {
    return Objects.nonNull(type) && TRANSFER_TYPES.contains(type);
  }

  public static boolean isMirPayPayment(@Nullable TransactionType type) {
    return Objects.nonNull(type) && MIR_PAY_PAYMENT_TYPES.contains(type);
  }

  public static boolean isMirPayRefund(@Nullable TransactionType type) {
    return Objects.nonNull(type) && MIR_PAY_REFUND_TYPES.contains(type);
  }

  public static boolean isFiscalPaymentType(@Nullable TransactionType type) {
    return Objects.nonNull(type) && FISCAL_PAYMENT_TYPES.contains(type);
  }

  public static boolean isFiscalRefundType(@Nullable TransactionType type) {
    return Objects.nonNull(type) && FISCAL_REFUND_TYPES.contains(type);
  }
}