package ru.vtb.tsp.ia.epay.portal.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.portal.domains.merchant.MerchantSite;
import ru.vtb.tsp.ia.epay.portal.domains.order.OrderData;
import ru.vtb.tsp.ia.epay.portal.domains.order.OrderStatus;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionCallback implements Serializable {

  @JsonProperty("order")
  private OrderData order;

  @JsonProperty("transaction")
  private TransactionData transaction;

  public static boolean isRefund(@Nullable TransactionPayload payload) {
    return Objects.nonNull(payload) && TransactionType.isRefund(payload.getType());
  }

  public static Optional<TransactionCallback> map(@Nullable TransactionPayload payload) {
    if (Objects.isNull(payload)) {
      return Optional.empty();
    }
    final var currentTime = LocalDateTime.now(ZoneOffset.UTC);
    final CardInfoData cardInfoData;
    if (payload.getPaymentData() instanceof Card) {
      final var cardPaymentData = Optional.ofNullable((Card) payload.getPaymentData());
      cardInfoData = CardInfoData.builder()
          .number(cardPaymentData.map(Card::getDpanMasked4digets).orElse(null))
          .expirationDate(cardPaymentData.map(Card::getExpiryDate).orElse(null))
          .paymentSystem((String) payload.getContext().get(TransactionInfoKey.CARD_PAYSYSTEM.getValue()))
          .bank((String) payload.getContext().get(TransactionInfoKey.CARD_BANK.getValue()))
          .eci(cardPaymentData.map(Card::getAdditionalData)
              .map(ad -> ad instanceof Threeds ? ad.getEci() : null)
              .orElse(null))
          .rrn((String) payload.getContext().get(TransactionInfoKey.CARD_RRN.getValue()))
          .threeDS(cardPaymentData.map(Card::getAdditionalData)
              .map(ad -> ad instanceof Threeds ? ((Threeds) ad).getThreeDSData() : null)
              .map(ThreeDSData::getThreeDsVersion)
              .orElse(null))
          .build();
    } else {
      cardInfoData = null;
    }
    return Optional.ofNullable(TransactionCallback.builder()
        .transaction(TransactionData.builder()
            .code(payload.getTransactionCode())
            .type(payload.getType())
            .paymentId(payload.getPaymentId())
            .refundCodeLink(isRefund(payload) ?
                (String) payload.getOriginContext().getOrDefault("code", null) : null)
            .responseData(ResponseData.builder()
                .id(Optional.ofNullable(payload.getError())
                    .map(TransactionError::getId)
                    .orElse(null))
                .message(Optional.ofNullable(payload.getError())
                    .map(e -> String.format("%s (%s)",e.getDescription(), e.getId()))
                    .orElse(null))
                .build())
            .paymentData(PaymentData.builder()
                .type(payload.getPaymentData() instanceof Sbp ?
                    Sbp.TYPE : (payload.getPaymentData() instanceof Card ? Card.TYPE : null))
                .build())
            .createdDate(payload.getCreatedAt())
            .amount(payload.getAmount())
            .status(TransactionStatus.builder()
                .value(payload.getStatus())
                .date(currentTime)
                .build())
            .cardInfo(cardInfoData)
            .build())
        .order(OrderData.builder()
            .code(payload.getOrderInfo().getOrderCode())
            .name(payload.getOrderInfo().getName())
            .type(payload.getOrderInfo().getOrderType())
            .amount(payload.getOrderInfo().getAmount())
            .createdDate(payload.getOrderInfo().getCreatedAt())
            .expireDate(payload.getOrderInfo().getExpiredAt())
            .status(OrderStatus.builder()
                .value(payload.getOrderInfo().getOrderState())
                .date(currentTime)
                .build())
            .merchantOrderId(payload.getOrderInfo().getMstOrderId())
            .merchantSite(MerchantSite.builder()
                .merchantId(payload.getMerchant().getId())
                .mstId(payload.getMerchant().getMstId())
                .url(payload.getMerchant().getUrl())
                .build())
            .sourceSystem(payload.getOrderInfo().getSourceSystem())
            .build())
        .build());
  }

}