package ru.vtb.tsp.ia.epay.core.entities.order;

import javax.annotation.Nullable;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum OrderType {

  PAYMENT("PAYMENT") /*Платеж*/,
  TRANSFER("TRANSFER") /*Перевод a2c*/,
  TWO_STAGE("TWO_STAGE") /*Двустадийный*/;

  private final String value;

  public static boolean isPayment(@Nullable OrderType type) {
    return PAYMENT.equals(type);
  }

  public static boolean isTransfer(@Nullable OrderType type) {
    return TRANSFER.equals(type);
  }

  public static boolean isTwoStage(@Nullable OrderType type) {
    return TWO_STAGE.equals(type);
  }

}