package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum GatewayOperation {

    AUTH,
    CONFIRM,
    PAYOUT,
    REFUND,
    REVERSE,
    PAYMENT,
    SALE,
    TRANSFER,
    PARTIAL_REFUND,
    ACCOUNT_TO_CARD,
    CARD_TO_ACCOUNT

}
