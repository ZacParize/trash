package ru.vtb.tsp.ia.epay.core.domains.kafka.payloads;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.UUID;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import ru.vtb.tsp.ia.epay.core.domains.enums.FiscalOperationType;

@Value
@Builder(toBuilder = true)
@Jacksonized
public class FiscalizationTask implements Serializable {

  @JsonProperty
  private String type;

  @JsonProperty
  private FiscalOperationType operationType;

  @JsonProperty
  private UUID orderCode;

  @JsonProperty
  private UUID transactionCode;

  @JsonProperty
  private String mstId;
}
