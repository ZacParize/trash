package ru.vtb.tsp.ia.epay.core.entities.cardinfo;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PublicKeyData implements Serializable, JsonObject {

  @JsonProperty("panPublicKey")
  private String panPublicKey;

  @JsonProperty("cvvPublicKey")
  private String cvvPublicKey;
}
