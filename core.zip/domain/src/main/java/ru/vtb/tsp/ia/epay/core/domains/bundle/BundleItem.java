package ru.vtb.tsp.ia.epay.core.domains.bundle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.math.BigDecimal;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleItem implements Serializable, JsonObject {

  @JsonProperty
  int positionId;
  @JsonProperty
  String name;
  @JsonProperty
  String code;
  @JsonProperty
  String description;
  @JsonProperty
  Boolean shippable;
  @JsonProperty
  BigDecimal price;
  @JsonProperty
  UnitsMeasure measure;
  @JsonProperty
  BigDecimal quantity;
  @JsonProperty
  TaxParams taxParams;
  @JsonProperty
  PaymentType paymentType;
  @JsonProperty
  ProductType paymentSubject;
  @JsonProperty
  BigDecimal amount;
  @JsonProperty
  BigDecimal discount;
  @JsonProperty
  String userData;

}
