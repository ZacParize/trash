package ru.vtb.tsp.ia.epay.core.domains.fiscalization;

public enum ReceiptState {

 NEW, REGISTERED, PRINTED, REGISTRATION_ERROR, PRINT_ERROR

}