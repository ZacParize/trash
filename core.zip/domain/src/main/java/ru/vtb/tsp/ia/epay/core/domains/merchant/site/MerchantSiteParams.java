package ru.vtb.tsp.ia.epay.core.domains.merchant.site;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonView;
import java.io.Serializable;
import java.time.Duration;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonView(UpdatableJsonView.class)
public class MerchantSiteParams implements JsonObject, Serializable {

  @JsonProperty("mcc")
  private String mcc;

  @Size(max = 255)
  @JsonProperty("callbackUrl")
  private String callbackUrl;

  @JsonProperty("orderLifeTime")
  @JsonFormat(shape = JsonFormat.Shape.STRING)
  private Duration orderLifeTime;

  @JsonProperty("sbpParams")
  private MerchantSiteSbpParams sbpParams;

  @JsonProperty("cardParams")
  private MerchantSiteCardParams cardParams;

  @JsonProperty("transferParams")
  @Valid
  private MerchantSiteTransferParams transferParams;

  @JsonProperty("fiscalParams")
  @Valid
  private MerchantSiteFiscalParams fiscalParams;
  
}