package ru.vtb.tsp.ia.epay.portal.domains.order;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.portal.domains.merchant.MerchantSite;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderData implements Serializable {

    @JsonProperty("code")
    private String code;

    @JsonProperty("name")
    private String name;

    @JsonProperty("merchantOrderId")
    private String merchantOrderId;

    @JsonProperty("type")
    private OrderType type;

    @JsonProperty("merchantSite")
    private MerchantSite merchantSite;

    @JsonProperty("createdDate")
    private LocalDateTime createdDate;

    @JsonProperty("expireDate")
    private LocalDateTime expireDate;

    @JsonProperty("amount")
    private Amount amount;

    @JsonProperty("status")
    private OrderStatus status;

    @JsonProperty("sourceSystem")
    private SourceSystem sourceSystem;

}