package ru.vtb.tsp.ia.epay.core.entities.customer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

import javax.validation.constraints.NotEmpty;

@Table("customers")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Customer {

    @Id
    @Column("customer_id")
    @JsonProperty("id")
    private String customerId;

    @NotEmpty
    @Column("phone")
    @JsonProperty("phone")
    private String phone;

    @NotEmpty
    @Column("email")
    @JsonProperty("email")
    private String email;

}