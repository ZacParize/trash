package ru.vtb.tsp.ia.epay.core.entities.order;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.util.ObjectUtils;

@Getter
@RequiredArgsConstructor
public enum SourceSystem {

  IBLK("IBLK") /*ЛK paylink*/,
  ECOM("ECOM") /*e-commerce*/;

  private String name;

  SourceSystem(String name) {
    this.name = name;
  }

  public static SourceSystem findByName(String name) {
    if (!ObjectUtils.isEmpty(name)) {
      for (SourceSystem s : SourceSystem.values()) {
        if (s.name.equalsIgnoreCase(name)) {
          return s;
        }
      }
    }
    return SourceSystem.ECOM;
  }

}