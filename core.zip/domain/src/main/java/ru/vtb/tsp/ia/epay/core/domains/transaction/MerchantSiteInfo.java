package ru.vtb.tsp.ia.epay.core.domains.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteInfo implements Serializable {

    @JsonProperty("id")
    private String id;
    @JsonProperty("mstId")
    private String mstId;
    @JsonProperty("name")
    private String name;
    /**
     * URL используется для перенаправления кастомера на сайт мерчанта
     */
    @JsonProperty("url")
    private String url;
    @JsonProperty("logoUrl")
    private String logoUrl;
    @JsonProperty("shortInfo")
    private String shortInfo;
    /**
     * Пармаметры мерчантсайта
     */
    @JsonProperty("merchantSiteParams")
    private MerchantSiteParams merchantSiteParams;
}