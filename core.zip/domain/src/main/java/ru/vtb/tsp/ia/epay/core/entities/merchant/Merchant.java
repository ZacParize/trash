package ru.vtb.tsp.ia.epay.core.entities.merchant;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantParams;

import javax.validation.constraints.NotEmpty;

@Deprecated
@Table("merchants")
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Merchant {

    @Id
    @Column("id")
    @JsonProperty("id")
    private String id;

    @NotEmpty
    @Column("name")
    @JsonProperty("name")
    private String name;

    @Column("params")
    @JsonProperty("params")
    private MerchantParams params;

}