package ru.vtb.tsp.ia.epay.core.domains.merchant.site.validation;

import java.util.Objects;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import ru.vtb.tsp.ia.epay.core.domains.enums.MerchantSiteType;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;

public class MerchantSiteValidator
    implements ConstraintValidator<MerchantSiteConstraint, MerchantSite> {

  private static final String A2C_MCC = "6536";

  @Override
  public boolean isValid(MerchantSite value, ConstraintValidatorContext context) {
    if (Objects.isNull(value) || Objects.isNull(value.getParams())) {
      return true;
    }
    return !MerchantSiteType.A2C_TRANSFER.equals(value.getType())
        || (MerchantSiteType.A2C_TRANSFER.equals(value.getType())
          && A2C_MCC.equals(value.getParams().getMcc()));
  }

}