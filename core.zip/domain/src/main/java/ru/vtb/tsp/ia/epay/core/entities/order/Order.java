package ru.vtb.tsp.ia.epay.core.entities.order;

import static ru.vtb.tsp.ia.epay.core.entities.order.Order.TABLE_NAME;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.MappedCollection;
import org.springframework.data.relational.core.mapping.Table;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

@Table(TABLE_NAME)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
@Builder
@With
@JsonIgnoreProperties(ignoreUnknown = true)
public class Order {

  public static final String TABLE_NAME = "orders";

  @Id
  @Column("order_id")
  @JsonProperty("id")
  private String orderId;

  @NotNull
  @MappedCollection(idColumn = "id")
  @JsonProperty("mst")
  private MerchantSite mst;

  @Column("mst_order_id")
  @JsonProperty("mstOrderId")
  private String mstOrderId;

  @NotEmpty
  @Column("code")
  @JsonProperty("code")
  private String code;

  @NotEmpty
  @Column("name")
  @JsonProperty("name")
  private String name;

  @NotNull
  @JsonProperty("amount")
  private Double amount;

  @JsonProperty("amountHold")
  private Double amountHold;

  @NotNull
  @MappedCollection(idColumn = "code")
  @JsonProperty("currency")
  private Currency currency;

  @NotNull
  @JsonProperty("state")
  private OrderState state;

  //TODO: change to type
  @NotNull
  @JsonProperty("orderType")
  private OrderType orderType;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @NotNull
  @Column("changed_at")
  @JsonProperty("changedAt")
  private LocalDateTime changedAt;

  @Column("authorized_at")
  @JsonProperty("authorizedAt")
  private LocalDateTime authorizedAt;

  @Column("expired_at")
  @JsonProperty("expiredAt")
  private LocalDateTime expiredAt;

  @NotEmpty
  @JsonProperty("description")
  private String description;

  @Column("return_url")
  @JsonProperty("returnUrl")
  private String returnUrl;

  @Column("account")
  @JsonProperty("account")
  private String account;

  @Column("bic")
  @JsonProperty("bic")
  private String bic;

  @NotNull
  @JsonProperty("source_system")
  private SourceSystem sourceSystem;

  @Version
  @Builder.Default
  private int version = 0;

  @JsonProperty("bindingType")
  @Column("binding_type")
  private BindingType bindingType;

  @JsonProperty("bindingCategory")
  @Column("binding_category")
  private BindingCategory bindingCategory;

  @Column("binding_code")
  @JsonProperty("bindingCode")
  private UUID bindingCode;

  @Column("mst_customer_id")
  @JsonProperty("mstCustomerId")
  private String mstCustomerId;

  public static boolean hasProcessingTransactions(@Nullable List<Transaction> transactions) {
    return hasProcessingTransactions(transactions, null);
  }

  public static boolean hasProcessingTransactions(@Nullable List<Transaction> inclusiveTransactions,
      @Nullable List<Transaction> exclusiveTransactions) {
    if (ObjectUtils.isEmpty(inclusiveTransactions)) {
      return false;
    }
    if (ObjectUtils.isEmpty(exclusiveTransactions)) {
      exclusiveTransactions = Collections.emptyList();
    }
    final var tempTransactionIds = exclusiveTransactions.stream()
        .map(Transaction::getTransactionId).collect(Collectors.toSet());
    return inclusiveTransactions.stream()
        .anyMatch(tx -> tx.isProcessing() && !tempTransactionIds.contains(tx.getTransactionId()));
  }

  public static double calculatePayedAmount(@Nullable List<Transaction> inclusiveTransactions,
      @Nullable List<Transaction> exclusiveTransactions) {
    if (ObjectUtils.isEmpty(inclusiveTransactions)) {
      return 0d;
    }
    if (ObjectUtils.isEmpty(exclusiveTransactions)) {
      exclusiveTransactions = Collections.emptyList();
    }
    final var tempTransactionIds = exclusiveTransactions.stream()
        .map(Transaction::getTransactionId).collect(Collectors.toSet());
    return inclusiveTransactions.stream()
        .filter(tx -> tx.isPaid() && !tempTransactionIds.contains(tx.getTransactionId()))
        .map(Transaction::getAmount)
        .map(BigDecimal::valueOf)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .doubleValue();
  }

  public static double calculateRefundedAmount(@Nullable List<Transaction> inclusiveTransactions,
      @Nullable List<Transaction> exclusiveTransactions) {
    if (ObjectUtils.isEmpty(inclusiveTransactions)) {
      return 0d;
    }
    if (ObjectUtils.isEmpty(exclusiveTransactions)) {
      exclusiveTransactions = Collections.emptyList();
    }
    final var tempTransactionIds = exclusiveTransactions.stream()
        .map(Transaction::getTransactionId).collect(Collectors.toSet());
    return inclusiveTransactions.stream()
        .filter(tx -> tx.isRefunded() && !tempTransactionIds.contains(tx.getTransactionId()))
        .map(Transaction::getAmount)
        .map(BigDecimal::valueOf)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .doubleValue();
  }

  public static double calculateAuthorizedAmount(@Nullable List<Transaction> inclusiveTransactions,
      @Nullable List<Transaction> exclusiveTransactions) {
    if (ObjectUtils.isEmpty(inclusiveTransactions)) {
      return 0d;
    }
    if (ObjectUtils.isEmpty(exclusiveTransactions)) {
      exclusiveTransactions = Collections.emptyList();
    }
    final var tempTransactionIds = exclusiveTransactions.stream()
        .map(Transaction::getTransactionId).collect(Collectors.toSet());
    return inclusiveTransactions.stream()
        .filter(tx -> tx.isAuthorized() && !tempTransactionIds.contains(tx.getTransactionId()))
        .map(Transaction::getAmountHold)
        .map(BigDecimal::valueOf)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .doubleValue();
  }

  public static double calculateReversedAmount(@Nullable List<Transaction> inclusiveTransactions,
      @Nullable List<Transaction> exclusiveTransactions) {
    if (ObjectUtils.isEmpty(inclusiveTransactions)) {
      return 0d;
    }
    if (ObjectUtils.isEmpty(exclusiveTransactions)) {
      exclusiveTransactions = Collections.emptyList();
    }
    final var tempTransactionIds = exclusiveTransactions.stream()
        .map(Transaction::getTransactionId).collect(Collectors.toSet());
    return inclusiveTransactions.stream()
        .filter(tx -> tx.isReversed() && !tempTransactionIds.contains(tx.getTransactionId()))
        .map(Transaction::getAmountHold)
        .map(BigDecimal::valueOf)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .doubleValue();
  }

  public static double calculateRemainingRefundAmount(double amount,
      @Nullable List<Transaction> transactions) {
    return BigDecimal.valueOf(amount)
        .subtract(BigDecimal.valueOf(calculateRefundedAmount(transactions))).doubleValue();
  }

  public double calculateRemainingRefundAmount(@Nullable List<Transaction> transactions) {
    return Order.calculateRemainingRefundAmount(amount, transactions);
  }

  public static double calculateRemainingPayAmount(double amount,
      @Nullable List<Transaction> transactions) {
    return BigDecimal.valueOf(amount)
        .subtract(BigDecimal.valueOf(calculatePayedAmount(transactions))).doubleValue();
  }

  public double calculateRemainingPayAmount(@Nullable List<Transaction> transactions) {
    return calculateRemainingPayAmount(amount, transactions);
  }

  public static double calculatePayedAmount(@Nullable List<Transaction> transactions) {
    return calculatePayedAmount(transactions, null);
  }

  public static double calculateRefundedAmount(@Nullable List<Transaction> transactions) {
    return calculateRefundedAmount(transactions, null);
  }

  public static double calculateAuthorizedAmount(@Nullable List<Transaction> transactions) {
    return calculateAuthorizedAmount(transactions, null);
  }

  public static double calculateReversedAmount(@Nullable List<Transaction> transactions) {
    return calculateReversedAmount(transactions, null);
  }

  public boolean isTransfer() {
    return OrderType.isTransfer(orderType);
  }

  public boolean isPayment() {
    return OrderType.isPayment(orderType);
  }

  public boolean isCreated() {
    return OrderState.isCreated(state);
  }

  public boolean isCompleted() {
    return OrderState.isCompleted(state) || isExpired();
  }

  public boolean isPartiallyRefunded() {
    return OrderState.isPartiallyRefunded(state);
  }

  public boolean isPartiallyPaid() {
    return OrderState.isPartiallyPaid(state);
  }

  public boolean isPaid() {
    return OrderState.isPaid(state);
  }

  public boolean isRefunded() {
    return OrderState.isRefunded(state);
  }

  public boolean isPending() {
    return OrderState.isPending(state);
  }

  public boolean isDeclined() {
    return OrderState.isDeclined(state);
  }

  public boolean isCanceled() {
    return OrderState.isCanceled(state);
  }

  public boolean isClosed() {
    return OrderState.isClosed(state);
  }

  public boolean isExpired() {
    return OrderState.EXPIRED.equals(state)
        || (isCreated() && Objects.nonNull(expiredAt)
        && LocalDateTime.now(ZoneOffset.UTC).isAfter(expiredAt))
        || (Objects.isNull(expiredAt)
        && LocalDateTime.now(ZoneOffset.UTC)
        .isAfter(createdAt.plus(mst.getParams().getOrderLifeTime())));
  }

  public boolean isVoided() {
    return OrderState.isVoided(state);
  }
}