package ru.vtb.tsp.ia.epay.core.domains.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Optional;

/**
 * 3DS version.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 12.10.2021
 */
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ThreeDSVersion {

    V1_0,
    V2_0,
    V2_0_FRICTIONLESS,
    V2_0_CHALLENGE;

    public static Optional<ThreeDSVersion> findByName(String name) {
        for (var val : ThreeDSVersion.values()) {
            if (val.name().equals(name)) {
                return Optional.of(val);
            }
        }
        return Optional.empty();
    }
}
