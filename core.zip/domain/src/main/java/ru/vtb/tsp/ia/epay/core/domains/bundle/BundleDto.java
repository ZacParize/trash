package ru.vtb.tsp.ia.epay.core.domains.bundle;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleDto implements Serializable {

  @JsonProperty
  FiscalInfo fiscalInfo;
  @JsonProperty
  List<BundleItem> items;
  @JsonProperty
  LocalDateTime createdAt;
  @JsonProperty
  LocalDateTime updatedAt;

}
