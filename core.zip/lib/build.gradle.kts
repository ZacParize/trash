plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    repositories {
        maven {
            url = uri(extra["nexus.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    implementation(project(":domain"))

    //standin
    implementation("ru.vtb.smartreplication:smart-replication-proxy-core"){
        exclude(group="ru.vtb.smartreplication", module = "smart-replication-dto")
        exclude(group="ru.vtb.smartreplication", module = "smart-replication-core")
    }

    // Core api dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-sbpadapter-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-customer-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-tokenization-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-notificator-api")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.core:jackson-databind")

    // Apache
    implementation("org.apache.httpcomponents:httpclient")
    implementation("org.apache.commons:commons-text")

    // Spring components
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.kafka:spring-kafka")

    // Validation
    implementation("javax.validation:validation-api")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString() + "-lib"
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
            versionMapping {
                usage("java-api") {
                    fromResolutionOf("runtimeClasspath")
                }
                usage("java-runtime") {
                    fromResolutionResult()
                }
            }
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    enabled = true
}

tasks.bootJar {
    // Set bootJar file name
    enabled = false
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
    maxHeapSize = "1G"
}