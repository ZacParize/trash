package ru.vtb.tsp.ia.epay.core.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.enums.StandInVariables;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParam;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParamValue;
import ru.vtb.tsp.ia.epay.core.repositories.StandInParamsRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class StandInParamService {

  private final StandInParamsRepository paramsRepository;

  public boolean isReplicationEnabled() {
    return paramsRepository.findByKey(StandInVariables.SMART_REPLICATION_ENABLED.name())
        .map(p -> p.getData())
        .map(data -> Boolean.valueOf(data.toString())).orElse(true);
  }

  @Transactional(propagation = Propagation.REQUIRES_NEW)
  public StandInParam setReplicationEnabled(boolean enabled) {
    final var entity = StandInParam.builder()
        .key(Objects.requireNonNull(StandInVariables.SMART_REPLICATION_ENABLED.name(),
            "key is null"))
        .data(StandInParamValue.builder().value(enabled).build())
        .createdAt(LocalDateTime.now(ZoneOffset.UTC))
        .modifiedAt(LocalDateTime.now(ZoneOffset.UTC)).build();
    return paramsRepository.saveOrUpdate(entity);
  }

}
