package ru.vtb.tsp.ia.epay.core.services;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionInfoRepository;

@Service
@RequiredArgsConstructor
public class TransactionInfoService {

  private final TransactionInfoRepository transactionInfoRepository;

  public @NotNull Optional<Transaction> getByQrcId(@Nullable String qrcId) {
    return Optional.ofNullable(qrcId)
        .flatMap(qrId -> transactionInfoRepository.findByKeyAndValue(
                TransactionInfoKey.SBP_QR_ID, qrId, null)
            .stream()
            .findFirst()
            .map(TransactionInfo::getTransaction));
  }

  public @NotNull Optional<Transaction> getByMsgId(@Nullable String msgId) {
    return Optional.ofNullable(msgId)
        .flatMap(msId -> transactionInfoRepository
            .findByKeyAndValue(TransactionInfoKey.SBP_MSG_ID, msId, null)
            .stream()
            .findFirst()
            .map(TransactionInfo::getTransaction));
  }

  public @NotNull List<TransactionInfo> getByTransactionId(@Nullable String transactionId) {
    return Optional.ofNullable(transactionId)
        .map(transactionInfoRepository::findByTransactionId)
        .orElse(Collections.emptyList());
  }

  public @NotNull List<TransactionInfo> getByKeyAndState(
      @NotNull TransactionInfoKey key,
      @Nullable TransactionState transactionState,
      @Nullable LocalDateTime createdAt) {
    return Objects.isNull(key)
        ? Collections.emptyList() :
        transactionInfoRepository.findByKeyAndState(key, transactionState, createdAt);
  }

  public @NotNull List<TransactionInfo> getByKeyAndValueAndState(
      @NotNull TransactionInfoKey key,
      @Nullable String value,
      @Nullable TransactionState transactionState,
      @Nullable LocalDateTime createdAt) {
    return Objects.isNull(key)
        ? Collections.emptyList() :
        transactionInfoRepository.findByKeyAndValueAndState(key, value, transactionState,
            createdAt);
  }

  @Transactional
  public @NotNull Optional<TransactionInfo> saveOrUpdateInfo(
      @Nullable TransactionInfo transactionInfo) {
    return Optional.ofNullable(transactionInfo).map(transactionInfoRepository::insertOrUpdate);
  }

  @Transactional
  public @NotNull Optional<TransactionInfo> saveOrUpdateInfo(@Nullable String transactionId,
      @Nullable TransactionInfoKey key,
      @Nullable String value,
      @Nullable LocalDateTime createdAt) {
    return Optional.ofNullable(
        transactionInfoRepository.insertOrUpdate(transactionId, key, value, createdAt));
  }
}
