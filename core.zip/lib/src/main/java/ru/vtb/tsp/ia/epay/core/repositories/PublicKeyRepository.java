package ru.vtb.tsp.ia.epay.core.repositories;

import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;
import ru.vtb.tsp.ia.epay.core.entities.misc.PublicKey;

public interface PublicKeyRepository extends CrudRepository<PublicKey, Long> {

  Iterable<PublicKey> findAll();

  @Query("insert into public_key (id, value,date_create) values (:id, :value,now()) on conflict"
      + " (id) do update set value = :value, date_update=now() RETURNING *")
  PublicKey upsert(@NotNull @Param("id") Long id, @NotNull @Param("value") PublicKeyData value);

  default PublicKey saveOrUpdate(Long id, PublicKeyData value) {
    MDC.put(MDCKeySupplier.UNIQUE_KEY, UUID.randomUUID().toString());
    return upsert(id, value);
  }

  @Nullable
  PublicKey save(PublicKey entity);
}