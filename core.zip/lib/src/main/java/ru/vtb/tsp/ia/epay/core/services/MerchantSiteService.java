package ru.vtb.tsp.ia.epay.core.services;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.repositories.MerchantSiteRepository;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class MerchantSiteService {

  private final MerchantSiteRepository merchantSiteRepository;

  public @NotNull Optional<MerchantSite> getById(@Nullable String mstId) {
    return Optional.ofNullable(mstId).flatMap(merchantSiteRepository::findById);
  }

  public @NotNull List<MerchantSite> getByLogin(@Nullable String login) {
    return Optional.ofNullable(login)
        .map(merchantSiteRepository::findByLogin)
        .orElse(Collections.emptyList());
  }
}