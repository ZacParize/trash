package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowCommand;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

public interface FlowCommandRepository extends CrudRepository<FlowCommand, Long> {

    @NotNull
    @Override
    @Query("select fc.* from flow_commands fc order by fc.flow_command_id")
    List<FlowCommand> findAll();

    @NotNull
    @Query("select fc.* from flow_commands fc inner join " +
           "(select fp.* from flow_points fp inner join flows f on fp.flow_ref = f.flow_id where f.flow_id = :flowId) fp " +
           "on fp.flow_command_ref = fc.flow_command_id order by fp.rank")
    List<FlowCommand> findCommandsByFlow(@Nullable @Param("flowId") Long flowId);

    @NotNull
    @Query("select fc.* from flow_commands fc inner join " +
           "(select fp.* from flow_points fp inner join flows f on fp.flow_ref = f.flow_id where f.flow_id = :flowId order by fp.rank limit 1) fp " +
           "on fp.flow_command_ref = fc.flow_command_id")
    Optional<FlowCommand> findFirstCommandsInEachFlow(@Nullable @Param("flowId") Long flowId);

}