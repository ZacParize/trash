package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import ru.vtb.tsp.ia.epay.core.entities.route.Flow;

import javax.validation.constraints.NotNull;
import java.util.List;

public interface FlowRepository extends CrudRepository<Flow, Long> {

    @NotNull
    @Override
    @Query("select f.flow_id, " +
            "ms.id as mst_id, m.id as mst_merchant_id, m.name as mst_merchant_name, " +
            "m.params as mst_merchant_params, ms.url as mst_url, ms.name as mst_name, ms.login as mst_login, " +
            "ms.params as mst_params, f.name, f.description " +
            "from flows f " +
            "left join merchant_sites ms on ms.id = f.mst_ref " +
            "left join merchants m on ms.merch_ref = m.id order by f.flow_id")
    List<Flow> findAll();

}