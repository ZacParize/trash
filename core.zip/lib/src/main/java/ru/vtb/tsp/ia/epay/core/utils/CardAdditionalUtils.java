package ru.vtb.tsp.ia.epay.core.utils;

import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.ApplePay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.GooglePay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.SamsungPay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;

import java.util.Objects;
import java.util.Optional;

public final class CardAdditionalUtils {

  private CardAdditionalUtils() {}

  public static Optional<Threeds> getThreeds(TransactionPayload payload) {
    return getAdditionalData(payload, Threeds.class);
  }

  public static Optional<ApplePay> getApplePay(TransactionPayload payload) {
    return getAdditionalData(payload, ApplePay.class);
  }

  public static Optional<GooglePay> getGooglePay(TransactionPayload payload) {
    return getAdditionalData(payload, GooglePay.class);
  }

  public static Optional<SamsungPay> getSamsungPay(TransactionPayload payload) {
    return getAdditionalData(payload, SamsungPay.class);
  }

  private static <T> Optional<T> getAdditionalData(TransactionPayload payload, Class<T> dest) {
    Optional<Card> cardOptional = PayloadUtils.getCard(payload);
      if (cardOptional.isPresent() && Objects.nonNull(cardOptional.get().getAdditionalData())
          && cardOptional.get().getAdditionalData().getClass().isAssignableFrom(dest)) {
        return Optional.of((T) cardOptional.get().getAdditionalData());
      }
    return Optional.empty();
  }
}
