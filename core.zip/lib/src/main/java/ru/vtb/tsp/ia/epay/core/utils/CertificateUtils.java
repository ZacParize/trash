package ru.vtb.tsp.ia.epay.core.utils;

import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.time.ZoneId;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.naming.InvalidNameException;
import javax.naming.ldap.LdapName;
import javax.security.auth.x500.X500Principal;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.certificate.CertificateInfo;

@Slf4j
public class CertificateUtils {

  private static final String X509_CERT_TYPE = "X.509";
  private static final String CN = "CN";

  private CertificateUtils() {
  }

  public static @Nullable CertificateInfo getCertificateInfo(@Nullable KeyStore keyStore,
      @Nullable String keyStoreLocation,
      @Nullable String alias)
      throws NoSuchAlgorithmException, KeyStoreException {
    if (Objects.isNull(keyStore) || ObjectUtils.isEmpty(keyStoreLocation)
        || ObjectUtils.isEmpty(alias)) {
      return null;
    }
    final var x509Certificate = getX509Certificate(keyStore, alias);
    return CertificateInfo
        .builder()
        .notAfterDate(x509Certificate.getNotAfter().toInstant()
            .atZone(ZoneId.systemDefault())
            .toLocalDateTime())
        .serialNumber(x509Certificate.getSerialNumber())
        .allowedHosts(getAllowedHosts(x509Certificate))
        .commonName(getCommonName(x509Certificate))
        .resource(keyStoreLocation)
        .build();
  }


  private static @NotNull String getCommonName(@NotNull X509Certificate x509Certificate) {
    final var principalName = x509Certificate.getSubjectX500Principal().
        getName(X500Principal.RFC2253);

    //LdapName тоже использует формат RFC2253 для имен,
    // поэтому им и воспользуемся для поиска CN
    try {
      return new LdapName(principalName).getRdns()
          .stream()
          .filter(rdn -> CN.equalsIgnoreCase(rdn.getType()))
          .map(rdn -> rdn.getValue().toString())
          .findFirst()
          .orElse("");
    } catch (InvalidNameException e) {
      log.error("Error occurred while reading CN of the certificate: " +
              "serialNumber = {}, subjectPrincipal = {}, exceptionMessage = {}",
          x509Certificate.getSerialNumber(), principalName, e.getMessage());
      return "";
    }
  }

  private static @NotNull String getAllowedHosts(@NotNull X509Certificate x509Certificate) {
    try {
      return Optional.ofNullable(x509Certificate.getIssuerAlternativeNames())
          .map(Object::toString).orElse("");
    } catch (CertificateParsingException e) {
      log.error("Can't obtain list of hosts from certificate: {}",
          x509Certificate.getSerialNumber());
      return "";
    }
  }

  private static @NotNull X509Certificate getX509Certificate(@NotNull KeyStore keyStore,
      @NotNull String alias)
      throws NoSuchAlgorithmException, KeyStoreException {
    log.info("Getting info from certificate with alias {}", alias);
    final var certificate = keyStore.getCertificate(alias);
    if (Objects.isNull(certificate)) {
      log.error("There is no certificate with alias {} in the keystore", alias);
      throw new IllegalArgumentException(
          String.format("There is no certificate with alias %s in the keystore", alias));
    }
    final var certType = certificate.getType();
    log.info("Cert type: {}", certType);
    if (X509_CERT_TYPE.equals(certType) && certificate instanceof X509Certificate) {
      return ((X509Certificate) certificate);
    } else {
      log.error("Certificate with type {} is not supported", certType);
      throw new NoSuchAlgorithmException(
          String.format("Certificate with type %s is not supported", certType));
    }
  }
}