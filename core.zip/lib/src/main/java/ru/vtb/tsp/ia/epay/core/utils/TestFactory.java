package ru.vtb.tsp.ia.epay.core.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.Serializable;
import java.lang.reflect.Field;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.SneakyThrows;
import ru.vtb.tsp.ia.epay.core.domains.customer.CustomerInfo;
import ru.vtb.tsp.ia.epay.core.domains.enums.CofOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.OperationState;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.StorageVersion;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxClient;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxSystem;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.Branch;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.DefaultSettings;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.Department;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.LegalName;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteCardParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteFiscalParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteTransferParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.TransferAccount;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.TransferCommission;
import ru.vtb.tsp.ia.epay.core.domains.plugin.operation.Operation;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Route;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.ApplePay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.entities.route.Flow;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowCommand;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowPoint;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerState;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerType;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeaderImpl;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

public class TestFactory {

  public static Map<String, Object> toMap(Object subject, List<String> excludeFields)
      throws IllegalAccessException {
    if (Objects.isNull(subject)) {
      return Collections.emptyMap();
    }
    Field[] fields = subject.getClass().getDeclaredFields();
    final var result = new HashMap<String, Object>();
    final var excludes = Objects.requireNonNullElse(excludeFields, Collections.emptyList());
    for (Field field : fields) {
      if (excludes.contains(field.getName())) {
        continue;
      }
      field.setAccessible(true);
      result.put(field.getName(), field.get(subject));
    }
    return result;
  }

  public static Object clone(Object subject) throws IllegalAccessException {
    if (Objects.isNull(subject)) {
      return null;
    }
    final var result = new TransactionPayload();
    final var fields = subject.getClass().getDeclaredFields();
    for (Field field : fields) {
      field.setAccessible(true);
      field.set(result, field.get(subject));
    }
    return result;
  }

  public static @NotNull Order getEmptyOrder() {
    return new Order();
  }

  public static @NotNull Order getOrder() {
    return new Order(UUID.randomUUID().toString(),
        getMerchantSite(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        new Random().nextDouble() + 0.33d,
        0.0d,
        getCurrency(),
        OrderState.CREATED,
        OrderType.PAYMENT,
        LocalDateTime.now(ZoneOffset.UTC),
        LocalDateTime.now(ZoneOffset.UTC),
        LocalDateTime.now(ZoneOffset.UTC),
        LocalDateTime.now(ZoneOffset.UTC).plus(15L, ChronoUnit.MINUTES),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        SourceSystem.ECOM,
        0,
        BindingType.COMMON,
        BindingCategory.CIT,
        UUID.randomUUID(),
        UUID.randomUUID().toString()
    );
  }

  public static @NotNull Merchant getEmptyMerchant() {
    return new Merchant();
  }

  public static @NotNull Merchant getMerchant() {
    return new Merchant(UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        new MerchantParams());
  }

  public static @NotNull MerchantSite getEmptyMerchantSite() {
    return new MerchantSite();
  }

  public static @NotNull MerchantSite getMerchantSite() {
    return new MerchantSite(UUID.randomUUID().toString(),
        getMerchant(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        getMerchantSiteParams());
  }

  public static @NotNull MerchantSiteParams getMerchantSiteParams() {
    return new MerchantSiteParams(UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        Duration.of(30L, ChronoUnit.DAYS),
        getMerchantSiteSbpParams(),
        getMerchantSiteCardParams(),
        getMerchantSiteTransferParams(),
        getMerchantSiteFiscalParams()
        );
  }

  public static @NotNull MerchantSiteCardParams getMerchantSiteCardParams() {
    return MerchantSiteCardParams.builder()
        .enableCardFlowThreeDSOnMerchantSide(true)
        .enableCardFlowThreeDS(true)
        .enableCardPayment(true)
        .enableApplePayment(true)
        .enableGooglePayment(true)
        .enablePartialRefund(true)
        .enableTwoStage(true)
        .enablePaymentCheckboxesVisible(true)
        .merchantId(UUID.randomUUID().toString())
        .merchantName(UUID.randomUUID().toString())
        .terminalId(UUID.randomUUID().toString())
        .enableMirPayment(true)
        .build();
  }

  public static @NotNull MerchantSiteTransferParams getMerchantSiteTransferParams() {
    return MerchantSiteTransferParams.builder()
        .mid("12345678")
        .commission(TransferCommission.builder()
            .percent("10")
            .build())
        .account(TransferAccount.builder()
            .legalName(LegalName.builder()
                .name("\"НТЦ \"ЭЛЕКТРОН-СЕРВИС\"")
                .opf("ООО")
                .build())
            .accountBalanceNum("40702")
            .accountNumber("40702978700100000001")
            .active(true)
            .branch(Branch.builder()
                .departmentName("Филиал \"Центральный\" Банка ВТБ (публичное акционерное общество) в г.Москве")
                .correspondentNumber("30101810600000000957")
                .departmentBIC("044525411")
                .build())
            .opened(LocalDate.parse("2004-10-07"))
            .closed(LocalDate.parse("2026-07-31"))
            .currency("RUB")
            .department(Department.builder()
                .departmentRefCode("768078")
                .departmentName("дополнительный офис \"Петровский\" в г. Москве")
                .departmentEmail("mail@mail.ru")
                .shortName("Краткое наименование")
                .address("г.Красноярск, ул.Весны, д.26")
                .tpCode("123456")
                .tpBisCode("37_MIS")
                .build())
            .status("1")
            .build())
        .commission(TransferCommission.builder()
            .percent("5")
            .build())
        .build();
  }

  public static @NotNull MerchantSiteSbpParams getMerchantSiteSbpParams() {
    return new MerchantSiteSbpParams(true,
        true,
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString());
  }

  public static @NotNull MerchantSiteFiscalParams getMerchantSiteFiscalParams() {
    return MerchantSiteFiscalParams.builder()
        .defaultSettings(DefaultSettings.builder()
            .paymentType(PaymentType.FULL_PAYMENT)
            .productName(UUID.randomUUID().toString())
            .productType(ProductType.ADVANCE)
            .taxRate(TaxRate.VAT_GENERAL)
            .taxSystem(TaxSystem.GENERAL)
            .build())
        .email("test@test.ru")
        .inn("0000000000")
        .kktId(UUID.randomUUID().toString())
        .active(true)
        .login(UUID.randomUUID().toString())
        .taxClient(TaxClient.OFD_1)
        .storageVersion(StorageVersion.V_1_2)
        .url("https://test.com")
        .build();
  }

  public static @NotNull Currency getEmptyCurrency() {
    return new Currency();
  }

  public static @NotNull Currency getCurrency() {
    return new Currency(UUID.randomUUID().toString(),
        new Random().nextInt(),
        UUID.randomUUID().toString());
  }

  public static @NotNull Transaction getEmptyTransaction() {
    return new Transaction();
  }

  public static @NotNull Transaction getTransaction() {
    return getTransaction(getOrder());
  }

  public static @NotNull Transaction getTransaction(@Nullable Order order) {
    if (Objects.isNull(order)) {
      return null;
    }
    final var transactionPayload = getTransactionPayload();
    return new Transaction(UUID.randomUUID().toString(),
        order,
        transactionPayload.getRoute().getFlowPoints().iterator().next().getFlow(),
        LocalDateTime.now(ZoneOffset.UTC),
        order.getAmount(),
        order.getAmountHold(),
        order.getCurrency(),
        UUID.randomUUID().toString(),
        UUID.randomUUID().toString(),
        order.getMst(),
        TransactionType.SBP_PAYMENT,
        TransactionState.NEW,
        transactionPayload,
        0);
  }

  public static @NotNull TransactionInfo getEmptyTransactionInfo() {
    return new TransactionInfo();
  }

  public static @NotNull TransactionInfo getTransactionInfo(@Nullable Transaction transaction) {
    if (Objects.isNull(transaction)) {
      return null;
    }
    return new TransactionInfo(new Random().nextLong(),
        transaction,
        TransactionInfoKey.SBP_QR_LINK,
        UUID.randomUUID().toString(),
        LocalDateTime.now(ZoneOffset.UTC));
  }

  public static @NotNull TransactionInfo getTransactionInfo() {
    return getTransactionInfo(getTransaction());
  }

  public static @NotNull TransactionPayload getEmptyTransactionPayload() {
    return new TransactionPayload();
  }

  public static @NotNull TransactionPayload getTransactionPayload() {
    return getTransactionPayload(getOrder());
  }

  public static @NotNull TransactionPayload getTransactionPayload(@Nullable Order order) {
    final var flow = new Flow(1L, order.getMst(), UUID.randomUUID().toString(),
        UUID.randomUUID().toString());
    final var transaction = getEmptyTransactionPayload();
    final var context = new HashMap<String, Serializable>();
    context.put("type", "purchase");
    transaction.setTransactionId(UUID.randomUUID().toString());
    transaction.setContext(context);
    transaction.setRoute(new Route(0, new ArrayList<>(), new HashMap<>()));
    transaction.setPaymentId(UUID.randomUUID().toString());
    transaction.setAmount(new Amount(order.getAmount(), order.getCurrency().getCode()));
    LocalDateTime localDateTime = LocalDateTime.of(LocalDate.now(), LocalTime.now()).plusYears(10);
    transaction.setPaymentData(new Card("1234123412341234", localDateTime, "111", "TEST TEST",
        new ApplePay("test eci", "test cavv", "test token"),
        "example@example.com", "", null, CofOperation.NONE));
    transaction.getRoute().getFlowPoints().addAll(List.of(
        new FlowPoint(0L, flow, new FlowCommand(0L,
            "transaction != null && transaction.getContext() != null && transaction.getContext().containsKey(\"type\") && transaction.getContext().get(\"type\") == \"purchase\"",
            "Purchase flow check",
            "Checking whether transaction should go throughout purchase flow"), 0L,
            "epay.supervisor-topic", "Purchase flow info", "Apply purchase flow command"),
        new FlowPoint(1L, flow, new FlowCommand(1L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-cardinfo\")",
            "Card info check",
            "Checking whether transaction should go throughout card info service"), 1L,
            "epay.cardinfo-topic", "Card info", "Apply card info command"),
        new FlowPoint(2L, flow, new FlowCommand(2L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-comissions\")",
            "Commissions check",
            "Checking whether transaction should go throughout commissions check service"), 2L,
            "epay.comissions-topic", "Commissions info", "Apply commissions info command"),
        new FlowPoint(3L, flow, new FlowCommand(3L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-merchantplugin\")",
            "Merchant plugin",
            "Checking whether transaction should go throughout merchant plugin service"), 3L,
            "epay.merchantplugin-topic", "Merchant plugin info",
            "Apply merchant plugin info command"),
        new FlowPoint(4L, flow, new FlowCommand(4L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-router\")",
            "Router", "Checking whether transaction should go throughout router service"), 4L,
            "epay.router-topic", "Router info", "Apply router command"),
        new FlowPoint(5L, flow, new FlowCommand(5L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-3ds\")",
            "3DS", "Checking whether transaction should go throughout 3DS service"), 5L,
            "epay.3ds-topic", "3DS info", "Apply 3DS command"),
        new FlowPoint(6L, flow, new FlowCommand(6L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-gatewayadapter\")",
            "Gateway adapter",
            "Checking whether transaction should go throughout gateway adapter service"), 6L,
            "epay.gatewayadapter-topic", "Gateway info", "Apply gateway adapter command"),
        new FlowPoint(7L, flow, new FlowCommand(7L,
            "transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey(\"epay-tokenization\")",
            "Tokenization",
            "Checking whether transaction should go throughout tokenization service"), 7L,
            "epay.tokenization-topic", "Tokenization info", "Apply tokenization command")
    ));
    transaction.getRoute().setCurrentPoint(1);
    return transaction;
  }

  public static @NotNull Operation getEmptyOperation() {
    final var operationId = UUID.randomUUID().toString();
    return new Operation(operationId, OperationState.CREATED, getEmptyTransactionPayload());
  }

  public static @NotNull Operation getOperation() {
    final var operation = getEmptyOperation();
    operation.setTransaction(getEmptyTransactionPayload());
    return operation;
  }

  public static @NotNull TransactionPayload getTransactionAfterCardInfo() {
    final var transaction = getTransactionPayload();
    transaction.getContext().put("epay-cardinfo", "test value");
    return transaction;
  }

  @SneakyThrows(JsonProcessingException.class)
  public static @NotNull String emptyTransactionPayloadToString(
      @NotNull ObjectMapper objectMapper) {
    return objectMapper.writeValueAsString(getTransactionPayload());
  }

  @SneakyThrows(JsonProcessingException.class)
  public static @NotNull String emptyOperationToString(@NotNull ObjectMapper objectMapper) {
    return objectMapper.writeValueAsString(getOperation());
  }

  public static @NotNull CustomerInfo getCustomer(@Nullable String mstCustomerId) {
    return CustomerInfo.builder()
        .email(UUID.randomUUID().toString())
        .phone(UUID.randomUUID().toString())
        .state(CustomerState.ACTIVE)
        .type(CustomerType.GLOBAL)
        .mstCustomerId(mstCustomerId)
        .build();
  }

  public static @NotNull Notification getNotification() {
    final Random generator = new Random();
    return NotificationImpl.builder()
        .header(NotificationHeaderImpl.builder()
            .type(NotificationType.values()[generator.nextInt(NotificationType.values().length - 1)])
            .destination(Collections.emptyList())
            .code(UUID.randomUUID().toString())
            .sentAt(LocalDateTime.now())
            .build())
        .payload(UUID.randomUUID().toString())
        .build();
  }

}