package ru.vtb.tsp.ia.epay.core.services;

import java.util.Objects;
import java.util.function.Function;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;

@Slf4j
public abstract class PgNotificationService<N,R> {

  protected final JdbcTemplate template;

  public PgNotificationService(@Nullable JdbcTemplate template) {
    this.template = Objects.requireNonNull(template, "Pg jdbc template can't be null");
  }

  @Transactional
  public boolean notify(@Nullable String channel, @Nullable N payload) {
    if (ObjectUtils.isEmpty(channel) || Objects.isNull(payload)) {
      return false;
    }
    template.execute("NOTIFY " + channel + ", '" + payload + "'");
    return true;
  }

  public abstract R receive(@Nullable String channel,
      @Nullable Function<N, R> function);

}