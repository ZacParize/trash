package ru.vtb.tsp.ia.epay.core.utils;

import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Invoice;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Payment;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Token;

import java.util.Optional;

public final class PayloadUtils {

    private PayloadUtils() {}

    public static Optional<Card> getCard(TransactionPayload payload) {
        return getPaymentData(payload, Card.class);
    }

    public static Optional<Invoice> getInvoice(TransactionPayload payload) {
        return getPaymentData(payload, Invoice.class);
    }

    public static Optional<Sbp> getSbp(TransactionPayload payload) {
        return getPaymentData(payload, Sbp.class);
    }

    public static Optional<Token> getToken(TransactionPayload payload) {
        return getPaymentData(payload, Token.class);
    }

    public static Optional<MirPay> getMirPay(TransactionPayload payload) {
        return getPaymentData(payload, MirPay.class);
    }

    private static <T extends Payment> Optional<T> getPaymentData(TransactionPayload payload, Class<T> dest) {
        return Optional.ofNullable(payload)
                .map(TransactionPayload::getPaymentData)
                .filter(payment -> payment.getClass().isAssignableFrom(dest))
                .map(payment -> (T) payment);
    }

}
