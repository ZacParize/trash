package ru.vtb.tsp.ia.epay.core.repositories;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;

public interface TransactionInfoRepository extends CrudRepository<TransactionInfo, String> {

  String COMMON_SELECT =
      "select "
          + "    txi.transaction_info_id, "
          + "    tx.transaction_id as transaction_transaction_id, "
          + "    o.order_id as transaction_order_order_id, "
          + "    ms1.id as transaction_order_mst_id, "
          + "    m1.id as transaction_order_mst_merchant_id, "
          + "    m1.name as transaction_order_mst_merchant_name, "
          + "    m1.params as transaction_order_mst_merchant_params, "
          + "    ms1.url as transaction_order_mst_url, "
          + "    ms1.name as transaction_order_mst_name, "
          + "    ms1.login as transaction_order_mst_login, "
          + "    ms1.params as transaction_order_mst_params, "
          + "    o.mst_order_id as transaction_order_mst_order_id, "
          + "    o.code as transaction_order_code, "
          + "    o.name as transaction_order_name, "
          + "    o.amount as transaction_order_amount, "
          + "    o.order_type as transaction_order_order_type, "
          + "    co.code as transaction_order_currency_code, "
          + "    co.numeric_code as transaction_order_currency_numeric_code, "
          + "    co.name as transaction_order_currency_name, "
          + "    o.state as transaction_order_state, "
          + "    o.created_at as transaction_order_created_at, "
          + "    o.expired_at as transaction_order_expired_at, "
          + "    o.description as transaction_order_description, "
          + "    o.changed_at as transaction_order_changed_at, "
          + "    o.return_url as transaction_order_return_url, "
          + "    o.account as transaction_order_account, "
          + "    o.bic as transaction_order_bic, "
          + "    o.source_system as transaction_order_source_system, "
          + "    f.flow_id as transaction_flow_flow_id, "
          + "    ms2.id as transaction_flow_mst_id, "
          + "    m2.id as transaction_flow_mst_merchant_id, "
          + "    m2.name as transaction_flow_mst_merchant_name, "
          + "    m2.params as transaction_flow_mst_merchant_params, "
          + "    ms2.url as transaction_flow_mst_url, "
          + "    ms2.name as transaction_flow_mst_name, "
          + "    ms2.login as transaction_flow_mst_login, "
          + "    ms2.params as transaction_flow_mst_params, "
          + "    f.name as transaction_flow_name, "
          + "    f.description as transaction_flow_description, "
          + "    tx.created_at as transaction_created_at, "
          + "    tx.amount as transaction_amount, "
          + "    ctx.code as transaction_currency_code, "
          + "    ctx.numeric_code as transaction_currency_numeric_code, "
          + "    ctx.name as transaction_currency_name, "
          + "    tx.mst_transaction_id as transaction_mst_transaction_id, "
          + "    tx.code as transaction_code, "
          + "    tx.mst_ref as transaction_mst_id, "
          + "    m3.id as transaction_mst_merchant_id, "
          + "    m3.name as transaction_mst_merchant_name, "
          + "    m3.params as transaction_mst_merchant_params, "
          + "    ms3.url as transaction_mst_url, "
          + "    ms3.name as transaction_mst_name, "
          + "    ms3.login as transaction_mst_login, "
          + "    ms3.params as transaction_mst_params, "
          + "    tx.type as transaction_type, "
          + "    tx.state as transaction_state, "
          + "    tx.data as transaction_data, "
          + "    txi.key, "
          + "    txi.value, "
          + "    txi.created_at "
          + "from "
          + "    transaction_info txi "
          + "    inner join transactions tx on tx.transaction_id = txi.transaction_ref "
          + "    inner join orders o on tx.order_ref = o.order_id "
          + "    left join flows f on tx.flow_ref = f.flow_id "
          + "    inner join currencies co on o.currency_ref = co.code "
          + "    inner join currencies ctx on tx.currency_ref = ctx.code "
          + "    inner join merchant_sites ms1 on ms1.id = o.mst_ref "
          + "    left join merchant_sites ms2 on ms2.id = f.mst_ref "
          + "    inner join merchant_sites ms3 on ms3.id = tx.mst_ref "
          + "    inner join merchants m1 on ms1.merch_ref = m1.id "
          + "    left join merchants m2 on ms2.merch_ref = m2.id "
          + "    inner join merchants m3 on ms3.merch_ref = m3.id";

  @NotNull
  @Query(COMMON_SELECT + " where txi.transaction_info_id = :transactionInfoId")
  Optional<TransactionInfo> findByTransactionInfoId(
      @NotEmpty @Param("transactionInfoId") Long transactionInfoId);

  @NotNull
  @Query(COMMON_SELECT + " where txi.key = :key " +
      "and ((cast(:value as text) is not null and txi.value = cast(:value as text)) or txi.value is null) "
      +
      "and (to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS') is null or txi.created_at >= to_timestamp(:createdAt, 'YYYY-MM-DD HH24:MI:SS')) "
      +
      "order by txi.created_at desc")
  List<TransactionInfo> findByKeyAndValue(@NotNull @Param("key") TransactionInfoKey key,
      @Nullable @Param("value") String value,
      @Nullable @Param("createdAt") LocalDateTime createdAt);

  @NotNull
  @Query(COMMON_SELECT + " where txi.key = :key " +
      "and tx.state = :transactionState "
      +
      "and (to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS') is null or txi.created_at >= to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS')) "
      +
      "order by txi.created_at desc")
  List<TransactionInfo> findByKeyAndState(@NotNull @Param("key") TransactionInfoKey key,
      @Nullable @Param("transactionState") TransactionState transactionState,
      @Nullable @Param("createdAt") LocalDateTime createdAt);

  @NotNull
  @Query(COMMON_SELECT + " where txi.key = :key " +
      "and ((cast(:value as text) is not null and txi.value = cast(:value as text)) or txi.value is null) "
      +
      "and tx.state = :transactionState "
      +
      "and (to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS') is null or txi.created_at >= to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS')) "
      +
      "order by txi.created_at desc")
  List<TransactionInfo> findByKeyAndValueAndState(@NotNull @Param("key") TransactionInfoKey key,
      @Nullable @Param("value") String value,
      @Nullable @Param("transactionState") TransactionState transactionState,
      @Nullable @Param("createdAt") LocalDateTime createdAt);

  @NotNull
  @Override
  @Query(COMMON_SELECT + " order by txi.created_at desc")
  List<TransactionInfo> findAll();

  @NotNull
  @Query(COMMON_SELECT + " where txi.transaction_ref = :transactionId order by txi.created_at desc")
  List<TransactionInfo> findByTransactionId(@NotEmpty @Param("transactionId") String transactionId);


  @NotNull
  @Query(COMMON_SELECT + " where txi.transaction_ref = :transactionId and txi.key = :key")
  Optional<TransactionInfo> findByTransactionIdAndKey(
      @NotEmpty @Param("transactionId") String transactionId,
      @NotEmpty @Param("key") TransactionInfoKey key);

  @NotNull
  @Query("update transaction_info set value=:value where transaction_info_id=:transactionInfoId "
      + "RETURNING *")
  Optional<TransactionInfo> update(@NotEmpty @Param("transactionInfoId") Long transactionInfoId,
      @NotEmpty @Param("value") String value);

  @NotNull
  @Query("insert into transaction_info (transaction_ref, key, value, created_at) " +
      "values (:transaction, :key, :value, :createdAt) " +
      "RETURNING *")
  Optional<TransactionInfo> insert(@NotEmpty @Param("transaction") String transactionId,
      @NotEmpty @Param("key") TransactionInfoKey key,
      @NotEmpty @Param("value") String value,
      @NotNull @Param("createdAt") LocalDateTime createdAt);

  //TODO: remove in future versions
  @Deprecated
  @NotNull
  @Query("insert into transaction_info (transaction_ref, key, value, created_at) " +
      "values (:transaction, :key, :value, :createdAt) " +
      "on conflict (transaction_ref, key) do update set " +
      "value = :value RETURNING *")
  TransactionInfo saveOrUpdate(@NotEmpty @Param("transaction") String transactionId,
      @NotEmpty @Param("key") TransactionInfoKey key,
      @NotEmpty @Param("value") String value,
      @NotNull @Param("createdAt") LocalDateTime createdAt);

  //TODO: remove in future versions
  @Deprecated
  default @Nullable TransactionInfo saveOrUpdate(@Nullable TransactionInfo transactionInfo) {
    Objects.requireNonNull(transactionInfo, "Transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getTransaction(),
        "Transaction in transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getTransaction().getTransactionId(),
        "Transaction id in transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getKey(), "Transaction info key can't be null");
    MDC.put(MDCKeySupplier.UNIQUE_KEY, transactionInfo.getTransaction().getOrder().getOrderId());
    return findByTransactionInfoId(saveOrUpdate(transactionInfo.getTransaction().getTransactionId(),
        transactionInfo.getKey(),
        transactionInfo.getValue(),
        transactionInfo.getCreatedAt()).getTransactionInfoId()).orElse(null);
  }

  default @Nullable TransactionInfo insertOrUpdate(@Nullable TransactionInfo transactionInfo) {
    Objects.requireNonNull(transactionInfo, "Transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getTransaction(),
        "Transaction in transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getTransaction().getTransactionId(),
        "Transaction id in transaction info can't be null");
    Objects.requireNonNull(transactionInfo.getKey(),
        "Transaction info key can't be null");

    return findByTransactionIdAndKey(transactionInfo.getTransaction().getTransactionId(),
        transactionInfo.getKey())
        .map(inBaseInfo -> {
              MDC.put(MDCKeySupplier.UNIQUE_KEY, inBaseInfo.getTransaction().getOrder().getOrderId());
              return update(inBaseInfo.getTransactionInfoId(), transactionInfo.getValue())
                  .orElse(null);
            }
        )
        .orElseGet(
            () -> {
              MDC.put(MDCKeySupplier.UNIQUE_KEY,
                  transactionInfo.getTransaction().getOrder().getOrderId());
              return insert(transactionInfo.getTransaction().getTransactionId(),
                  transactionInfo.getKey(),
                  transactionInfo.getValue(),
                  transactionInfo.getCreatedAt())
                  .orElse(null);
            }
        );
  }

  default TransactionInfo insertOrUpdate(@Nullable String transactionId,
      @Nullable TransactionInfoKey key,
      @Nullable String value,
      @Nullable LocalDateTime createdAt) {
    return findByTransactionIdAndKey(transactionId, key)
        .flatMap(inBaseInfo -> update(inBaseInfo.getTransactionInfoId(), value))
        .orElseGet(() -> insert(
            Objects.requireNonNull(transactionId, "Transaction id can't be null"),
            Objects.requireNonNull(key, "Transaction info key can't be null"),
            value,
            Objects.requireNonNullElse(createdAt, LocalDateTime.now(ZoneOffset.UTC)))
            .orElse(null));
  }
}