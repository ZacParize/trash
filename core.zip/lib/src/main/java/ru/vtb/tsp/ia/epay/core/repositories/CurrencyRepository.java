package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Optional;

public interface CurrencyRepository extends CrudRepository<Currency, String> {

    @NotNull
    @Override
    @Query("select c.* from currencies c where c.code = :code")
    Optional<Currency> findById(@NotEmpty @Param("code") String code);

    @NotNull
    @Query("select c.* from currencies c where c.numeric_code = :numericCode")
    Optional<Currency> findByNumericCode(@Param("numericCode") int numericCode);

}