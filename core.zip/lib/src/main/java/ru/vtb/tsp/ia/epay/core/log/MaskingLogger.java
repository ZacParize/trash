package ru.vtb.tsp.ia.epay.core.log;

import org.slf4j.Logger;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import ru.vtb.tsp.ia.epay.core.utils.MaskUtils;

/**
 * Интерфейс предназначенный для маскирования персональных данных пользователей. Подключение:
 *
 * Настройка lombok.config: lombok.log.custom.declaration =
 * ru.vtb.tsp.ia.epay.core.log.MaskingLogger
 * ru.vtb.tsp.ia.epay.core.log.MaskingLoggerFactory.getLogger(TYPE)
 *
 * Для использования в аннотациях класса вместо @Slf4j добавляется: import lombok.CustomLog;
 *
 * @CustomLog
 */
public class MaskingLogger {

  private final Logger logger;

  public MaskingLogger(Logger logger) {
    this.logger = logger;
  }


  public void debug(String msg) {
    logger.debug(msg);
  }

  public void debug(String format, Object... arguments) {
    logger.debug(format, arguments);
  }

  public void mDebug(String msg) {
    msg = maskSensitiveInfo(msg);
    logger.debug(msg);
  }

  public void mDebug(String format, Object... arguments) {
    var msg = getFormattedMessage(format, arguments);
    logger.debug(msg);
  }

  public void info(String msg) {
    logger.info(msg);
  }

  public void info(String format, Object... arguments) {
    logger.info(format, arguments);
  }

  public void mInfo(String msg) {
    msg = maskSensitiveInfo(msg);
    logger.info(msg);
  }

  public void mInfo(String format, Object... arguments) {
    var msg = getFormattedMessage(format, arguments);
    logger.info(msg);
  }

  public void warn(String msg) {
    logger.warn(msg);
  }

  public void warn(String format, Object... arguments) {
    logger.warn(format, arguments);
  }

  public void mWarn(String msg) {
    msg = maskSensitiveInfo(msg);
    logger.warn(msg);
  }

  public void mWarn(String format, Object... arguments) {
    var msg = getFormattedMessage(format, arguments);
    logger.warn(msg);
  }

  public void error(String msg) {
    logger.error(msg);
  }

  public void error(String msg, Throwable t) {
    logger.error(msg, t);
  }

  public void error(String format, Object... arguments) {
    logger.error(format, arguments);
  }

  public void mError(String msg) {
    msg = maskSensitiveInfo(msg);
    logger.error(msg);
  }

  public void mError(String format, Object... arguments) {
    var msg = getFormattedMessage(format, arguments);
    logger.error(msg);
  }

  private String getFormattedMessage(String format, Object... arguments) {
    FormattingTuple tuple = MessageFormatter.arrayFormat(format, arguments);
    return maskSensitiveInfo(tuple.getMessage());
  }

  private String maskSensitiveInfo(String msg) {
    return MaskUtils.maskData(msg);
  }

}
