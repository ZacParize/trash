package ru.vtb.tsp.ia.epay.core.configurations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.SneakyThrows;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.util.ObjectUtils;

public class KafkaConfiguration {

  private static final String ACKS = "all";
  private static final int BATCH_SIZE = 16384;
  private static final int BUFFER_MEMORY = 33554432;
  private static final String COMPRESSION_TYPE = "gzip";
  private static final int RETRIES = 1;
  private static final int MAX_POLL_RECORDS = 1;
  private static final int FETCH_TIMEOUT = 500;
  private static final int TIMEOUT = 5000;
  private static final String SSL_MODE = "SSL";
  private static final String OFFSET_MODE = "earliest";
  //public static final String TRANSACTIONAL_ID = "epay-supervisor-tx-";

  public static void setSslProperties(@NotNull Map<String, Object> configuration,
      @Nullable String sslProtocol, @Nullable String sslTrustStoreType,
      @Nullable String sslTrustStoreLocation, @Nullable String sslTrustStorePassword,
      @Nullable String sslKeyStoreType, @Nullable String sslKeyStoreLocation,
      @Nullable String sslKeyStorePassword, @Nullable String sslKeyPassword) {
    if (ObjectUtils.isEmpty(configuration) || ObjectUtils.isEmpty(sslProtocol)) {
      return;
    }
    configuration.put(SslConfigs.SSL_PROTOCOL_CONFIG, sslProtocol);
    configuration.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, SSL_MODE);
    configuration.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, sslTrustStoreType);
    configuration.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, sslTrustStoreLocation);
    configuration.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, sslTrustStorePassword);
    configuration.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, sslKeyStoreType);
    configuration.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, sslKeyStoreLocation);
    configuration.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, sslKeyStorePassword);
    configuration.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, sslKeyPassword);
  }

  @SneakyThrows
  public static void createTopics(@NotEmpty Map<String, Object> configuration,
      @NotEmpty List<String> topics, int partitionsCount, int replicasCount) {
    if (ObjectUtils.isEmpty(configuration)) {
      return;
    }
    final var adminClient = AdminClient.create(configuration);
    final var names = adminClient.listTopics().names().get();
    final var newTopics = new ArrayList<NewTopic>();
    topics.forEach(topic -> {
      if (names.contains(topic) || newTopics.stream().map(NewTopic::name)
          .collect(Collectors.toList()).contains(topic)) {
        return;
      }
      newTopics.add(TopicBuilder.name(topic).partitions(partitionsCount)
          .replicas(replicasCount).build());
    });

    if (newTopics.size() > 0) {
      try {
        adminClient.createTopics(newTopics).all().get(TIMEOUT, TimeUnit.MILLISECONDS);
      } catch (Exception ex) {
        // nothing to do, topics already exist
      }
    }
  }

  public static @NotNull Map<String, Object> consumerConfig(@NotEmpty List<String> bootstrapServers,
      @NotEmpty String groupId, @NotEmpty String sslProtocol, @NotEmpty String sslTrustStoreType,
      @NotEmpty String sslTrustStoreLocation, @NotEmpty String sslTrustStorePassword,
      @NotEmpty String sslKeyStoreType, @NotEmpty String sslKeyStoreLocation,
      @NotEmpty String sslKeyStorePassword, @NotEmpty String sslKeyPassword) {
    final var configuration = getCommonConsumerConfiguration(bootstrapServers, groupId);
    setSslProperties(configuration, sslProtocol, sslTrustStoreType, sslTrustStoreLocation,
        sslTrustStorePassword, sslKeyStoreType, sslKeyStoreLocation, sslKeyStorePassword,
        sslKeyPassword);
    return configuration;
  }

  public static @NotNull Map<String, Object> consumerConfig(@NotEmpty List<String> bootstrapServers,
      @NotEmpty String groupId) {
    return getCommonConsumerConfiguration(bootstrapServers, groupId);
  }

  public static @NotNull Map<String, Object> producerConfig(@NotEmpty List<String> bootstrapServers,
      @NotEmpty String sslProtocol, @NotEmpty String sslTrustStoreType,
      @NotEmpty String sslTrustStoreLocation, @NotEmpty String sslTrustStorePassword,
      @NotEmpty String sslKeyStoreType, @NotEmpty String sslKeyStoreLocation,
      @NotEmpty String sslKeyStorePassword, @NotEmpty String sslKeyPassword) {
    final var configuration = getCommonProducerConfiguration(bootstrapServers);
    setSslProperties(configuration, sslProtocol, sslTrustStoreType, sslTrustStoreLocation,
        sslTrustStorePassword, sslKeyStoreType, sslKeyStoreLocation, sslKeyStorePassword,
        sslKeyPassword);

    return configuration;
  }

  public static @NotNull Map<String, Object> producerConfig(
      @NotEmpty List<String> bootstrapServers) {
    return getCommonProducerConfiguration(bootstrapServers);
  }

  public static HashMap<String, Object> getCommonProducerConfiguration(
      List<String> bootstrapServers) {
    final var configuration = new HashMap<String, Object>();
    configuration.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    configuration.put(ProducerConfig.ACKS_CONFIG, ACKS);
    configuration.put(JsonSerializer.ADD_TYPE_INFO_HEADERS, true);
    configuration.put(ProducerConfig.BATCH_SIZE_CONFIG, BATCH_SIZE);
    configuration.put(ProducerConfig.BUFFER_MEMORY_CONFIG, BUFFER_MEMORY);
    configuration.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configuration.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
    configuration.put(ProducerConfig.COMPRESSION_TYPE_CONFIG, COMPRESSION_TYPE);
    configuration.put(ProducerConfig.RETRIES_CONFIG, RETRIES);
    return configuration;
  }

  public static HashMap<String, Object> getCommonConsumerConfiguration(
      List<String> bootstrapServers,String groupId){
    final var configuration = new HashMap<String, Object>();
    configuration.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    configuration.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    configuration.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
    configuration.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
    configuration.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, MAX_POLL_RECORDS);
    configuration.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, FETCH_TIMEOUT);
    configuration.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG, true);
    configuration.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, TIMEOUT);
    configuration.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, TIMEOUT * 2);
    configuration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, OFFSET_MODE);
    configuration.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
    configuration.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG,
        KafkaProperties.IsolationLevel.READ_COMMITTED.toString().toLowerCase());
    configuration.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
    configuration.put(JsonDeserializer.VALUE_DEFAULT_TYPE, Object.class.getCanonicalName());
    return configuration;
  }

}