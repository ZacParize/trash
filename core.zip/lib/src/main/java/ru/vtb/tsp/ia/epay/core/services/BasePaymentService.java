package ru.vtb.tsp.ia.epay.core.services;

import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

/**
 * Base payment service interface.
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 29.09.2021
 */
public interface BasePaymentService {

    Boolean payment(TransactionPayload payload);
    Boolean paymentAndConfirm(TransactionPayload payload);
    Boolean refund(TransactionPayload payload);
    Boolean payout(TransactionPayload payload);
    Boolean transfer(TransactionPayload payload);

}