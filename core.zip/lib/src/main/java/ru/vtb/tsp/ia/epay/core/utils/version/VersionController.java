package ru.vtb.tsp.ia.epay.core.utils.version;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("/version")
@RequiredArgsConstructor
public class VersionController {

  private final VersionService versionService;

  @GetMapping(produces = APPLICATION_JSON_VALUE)
  public VersionHolder getAppVersion(@RequestParam(value = "printLog", required = false) Boolean printLog) {
    return versionService.getVersionData(printLog);
  }
}
