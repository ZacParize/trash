package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowPoint;

import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import java.util.List;

public interface FlowPointRepository extends CrudRepository<FlowPoint, Long> {

    String COMMON_SELECT =
                  "select "
                + "    fp.flow_point_id, "
                + "    f.flow_id as flow_flow_id, "
                + "    ms.id as mst_id, "
                + "    m.id as mst_merchant_id, "
                + "    m.name as mst_merchant_name, "
                + "    m.params as mst_merchant_params, "
                + "    ms.url as mst_url, "
                + "    ms.name as mst_name, "
                + "    ms.login as mst_login, "
                + "    ms.params as mst_params, "
                + "    f.name as flow_name, "
                + "    f.description as flow_description, "
                + "    fc.flow_command_id as flowCommand_flow_command_id, "
                + "    fc.command as flowCommand_command, "
                + "    fc.name as flowCommand_name, "
                + "    fc.description as flowCommand_description, "
                + "    fp.rank, "
                + "    fp.point, "
                + "    fp.name, "
                + "    fp.description "
                + "from "
                + "    flow_points fp "
                + "    inner join flows f on fp.flow_ref = f.flow_id "
                + "    inner join flow_commands fc on fp.flow_command_ref = fc.flow_command_id "
                + "    left join merchant_sites ms on ms.id = f.mst_ref "
                + "    left join merchants m on ms.merch_ref = m.id";

    @NotNull
    @Override
    @Query(COMMON_SELECT + " order by fp.rank")
    List<FlowPoint> findAll();

    @NotNull
    @Query(COMMON_SELECT + " where f.flow_id = :flowId order by fp.rank")
    List<FlowPoint> findByFlow(@Nullable @Param("flowId") Long flowId);
}