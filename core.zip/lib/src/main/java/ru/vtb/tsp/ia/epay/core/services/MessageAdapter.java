package ru.vtb.tsp.ia.epay.core.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Objects;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;

@Slf4j
@Service
@RequiredArgsConstructor
public class MessageAdapter {

  private final ObjectMapper objectMapper;

  /**
   * Transaction payload deserialization
   *
   * @param message Message for deserialization
   * @return Deserialized transaction payload
   * @deprecated Since 1.16.21 use {@link MessageAdapter#deserializeTransactionPayload(Object)}
   */
  @Deprecated(since = "1.16.21")
  public @Nullable TransactionPayload deserialize(@Nullable Object message) {
    return deserializeTransactionPayload(message);
  }

  private @Nullable <T> T convert(@Nullable Object message, @Nullable Class<T> clazz)
      throws JsonProcessingException {
    if (Objects.isNull(message) || Objects.isNull(clazz)) {
      return null;
    } else if (message instanceof String) {
      return objectMapper.readValue((String) message, clazz);
    } else {
      return objectMapper.convertValue(message, clazz);
    }
  }

  public @Nullable TransactionPayload deserializeTransactionPayload(@Nullable Object message) {
    try {
      final var transactionPayload =
          message instanceof TransactionPayload ? (TransactionPayload) message
              : convert(message, TransactionPayload.class);
      log.info("Transaction payload was successfully deserialized {}", transactionPayload);
      return transactionPayload;
    } catch (JsonProcessingException exception) {
      log.error("Transaction payload deserialization exception", exception);
      return null;
    }
  }

  public @Nullable Notification deserializeNotification(@Nullable Object message) {
    try {
      final var notification =
          message instanceof Notification ? (Notification) message
              : convert(message, NotificationImpl.class);
      log.info("Notification was successfully deserialized {}", notification);
      return notification;
    } catch (JsonProcessingException exception) {
      log.error("Notification deserialization exception", exception);
      return null;
    }
  }

}