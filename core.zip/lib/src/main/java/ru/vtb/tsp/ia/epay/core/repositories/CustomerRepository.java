package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.customer.Customer;

import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public interface CustomerRepository extends CrudRepository<Customer, String> {

     @NotNull
     @Override
     @Query("select c.* from customers c where c.customer_id = :customerId")
     Optional<Customer> findById(@NotEmpty @Param("customerId") String customerId);

     @NotNull
     @Override
     @Query("select c.* from customers c order by c.customer_id")
     List<Customer> findAll();

     @NotNull
     @Query("select c.* from customers c " +
            "where ((cast(:phone as text) is not null and c.phone = cast(:phone as text)) or c.phone is null)" +
            " and ((cast(:email as text) is not null and c.email = cast(:email as text)) or c.email is null) order by c.customer_id")
     List<Customer> findByPhoneAndEmail(@NotEmpty @Param("phone") String phone,
                                        @NotEmpty @Param("email") String email);

     @NotEmpty
     @Query("insert into customers (customer_id, email, phone) " +
            "values (:customerId, :email, :phone) " +
            "on conflict (customer_id) do update set " +
            "email = :email, phone = :phone RETURNING customer_id")
     String saveOrUpdate(@NotEmpty @Param("customerId") String customerId,
                         @NotNull @Param("email") String email,
                         @NotNull @Param("phone") String phone);

     default @Nullable Customer saveOrUpdate(@Nullable Customer customer) {
          Objects.requireNonNull(customer, "Customer can't be null");
          Objects.requireNonNull(customer.getEmail(), "Customer's email can't be null");
          Objects.requireNonNull(customer.getPhone(), "Customer's phone can't be null");
          return findById(saveOrUpdate(customer.getCustomerId(),
                                       customer.getEmail(),
                                       customer.getPhone())).orElse(null);
     }

}