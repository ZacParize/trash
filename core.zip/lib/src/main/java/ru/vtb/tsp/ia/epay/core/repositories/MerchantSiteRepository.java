package ru.vtb.tsp.ia.epay.core.repositories;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Optional;

public interface MerchantSiteRepository extends CrudRepository<MerchantSite, String> {

    @NotNull
    @Override
    @Query("select ms.id as id, m.id as merchant_id, m.name as merchant_name, m.params as merchant_params, " +
           "ms.url, ms.name, ms.login, ms.params " +
           "from merchant_sites ms " +
           "inner join merchants m on ms.merch_ref = m.id " +
           "where ms.id = :mstId " +
           "and m.state = 'Active' " +
           "and ms.state = 'Active' " +
           "order by ms.id")
    Optional<MerchantSite> findById(@NotEmpty @Param("mstId") String mstId);

    @NotNull
    @Query("select ms.id as id, m.id as merchant_id, m.name as merchant_name, m.params as merchant_params, " +
           "ms.url, ms.name, ms.login, ms.params " +
           "from merchant_sites ms " +
           "inner join merchants m on ms.merch_ref = m.id " +
           "where ms.login = :login " +
           "and m.state = 'Active' " +
           "and ms.state = 'Active' " +
           "order by ms.id")
    List<MerchantSite> findByLogin(@NotEmpty @Param("login") String login);

}