package ru.vtb.tsp.ia.epay.core.utils;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.utils.URLEncodedUtils;
import org.springframework.util.ObjectUtils;

public final class MaskUtils {

  private MaskUtils() {
  }

  private static final String PAN = "PAN";
  private static final String CVV2 = "CVV2";
  private static final String EMPTY_STRING = "";
  private static final String MASK_STRING = "*";
  private static final String JSON_PAN_REGEX = "\"pan\"\\s*:\\s*\"([0-9 ]+)\"";
  private static final String XML_PAN_REGEX = "<PAN>\\s*([0-9]+)\\s*<\\/PAN>";
  private static final String CVV_REGEX = "\"cvv\"\\s*:\\s*\"(\\d+)\"";
  private static final String SIMPLE_PRICE_REGEX = "amount=\\d+(\\.\\d+)?";
  private static final String PRICE_IN_JSON_REGEX =
      "\"(amount|amountHold)\"\\s*:\\s*\\{\"value\"\\s*:\\s*\\d+(\\.\\d+)?\\s*,";
  private static final String PRICE_IN_DTO_REGEX =
      "(amount|amountHold)=\\w+\\(value=\\d+(\\.\\d+)?\\s*,";
  private static final String PRICE_REGEX =
      String.format("(%s|%s|%s)", SIMPLE_PRICE_REGEX, PRICE_IN_JSON_REGEX, PRICE_IN_DTO_REGEX);
  private static final Pattern jsonPanPattern = Pattern.compile(JSON_PAN_REGEX);
  private static final Pattern xmlPanPattern = Pattern.compile(XML_PAN_REGEX);
  private static final Pattern cvvPattern = Pattern.compile(CVV_REGEX);
  private static final Pattern pricePattern = Pattern.compile(PRICE_REGEX);

  public static @NotNull String maskUri(@Nullable URI uri) {
    if (Objects.isNull(uri)) {
      return EMPTY_STRING;
    }
    final var pairs = URLEncodedUtils.parse(uri, StandardCharsets.UTF_8);
    final var newParams = new LinkedHashMap<String, String>(pairs.size());
    pairs.forEach(p ->
        newParams.put(p.getName(), maskRequestParam(p.getName(), p.getValue())));
    return newParams.size() > 0 ? newParams.entrySet()
        .stream()
        .map(p -> {
          if (Objects.isNull(p.getKey())) {
            return EMPTY_STRING;
          } else if (Objects.isNull(p.getValue())) {
            return p.getKey();
          } else {
            return p.getKey() + "=" + p.getValue();
          }
        })
        .collect(Collectors.joining("&")) : uri.toString();
  }

  private static @NotNull String mask(@NotNull Pattern pattern,
      @Nullable String body,
      int showFirstDigitCount,
      int showLastDigitCount) {
    if (ObjectUtils.isEmpty(body)) {
      return EMPTY_STRING;
    }
    final var matcher = pattern.matcher(body);
    if (matcher.find() && matcher.groupCount() > 0) {
      final var oldValue = matcher.group(1);
      final var newValue = mask(oldValue, showFirstDigitCount, showLastDigitCount);
      body = body.replaceAll(oldValue, newValue);
    }
    return body;
  }

  private static @NotNull String maskRequestParam(@Nullable String key,
      @Nullable String value) {
    if (ObjectUtils.isEmpty(key)) {
      return value;
    }
    return switch (key.toUpperCase()) {
      case PAN -> mask(value, 6, 4);
      case CVV2 -> mask(value, 0, 0);
      default -> value;
    };
  }

  public static @NotNull String maskData(@Nullable String body) {
    return Optional.ofNullable(body)
        .map(MaskUtils::maskPanJson)
        .map(MaskUtils::maskPanXml)
        .map(MaskUtils::maskCvv)
        .map(MaskUtils::maskPrice)
        .orElse(EMPTY_STRING);
  }

  private static @NotNull String maskPanJson(@Nullable String body) {
    return mask(jsonPanPattern, body, 6, 4);
  }

  private static @NotNull String maskPanXml(@Nullable String body) {
    return mask(xmlPanPattern, body, 6, 4);
  }

  private static @NotNull String maskCvv(@Nullable String body) {
    return mask(cvvPattern, body, 0, 0);
  }

  private static @NotNull String maskPrice(@Nullable String body) {
    if (ObjectUtils.isEmpty(body)) {
      return EMPTY_STRING;
    }
    final var matcher = pricePattern.matcher(body);
    while (matcher.find()) {
      final var oldValue = matcher.group();
      final var newValue = oldValue.replaceAll("\\d", "*");
      body = body.replace(oldValue, newValue);
    }
    return body;
  }

  public static @NotNull String mask(@Nullable String maskString,
      int showFirstDigitCount,
      int showLastDigitCount) {
    if (ObjectUtils.isEmpty(maskString)) {
      return EMPTY_STRING;
    } else {
      maskString = StringUtils.deleteWhitespace(maskString);
    }
    if (maskString.length() <= showFirstDigitCount + showLastDigitCount) {
      return StringUtils.repeat("*", maskString.length());
    }
    final var leftPart = StringUtils.left(maskString, showFirstDigitCount);
    final var maskedPart = StringUtils.repeat(MASK_STRING,
        maskString.length() - (showFirstDigitCount + showLastDigitCount));
    final var rightPart = StringUtils.right(maskString, showLastDigitCount);
    return leftPart + maskedPart + rightPart;
  }

}