package ru.vtb.tsp.ia.epay.core.repositories;

import java.time.LocalDateTime;
import java.util.Optional;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParam;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParamValue;

public interface StandInParamsRepository extends CrudRepository<StandInParam, Long> {

  @Query("insert into " + StandInParam.TABLE_NAME + " (key, data, created_at, modified_at) "
      + "values (:key, :data, :createdAt, :modifiedAt) on conflict (key) do update "
      + "set data = :data, modified_at = :modifiedAt RETURNING *")
  StandInParam saveOrUpdate(@NotNull @Param("key") String key,
      @NotNull @Param("data") StandInParamValue data,
      @NotNull @Param("createdAt") LocalDateTime createdAt,
      @NotNull @Param("modifiedAt") LocalDateTime modifiedAt);

  default StandInParam saveOrUpdate(StandInParam standInParam) {
    return saveOrUpdate(standInParam.getKey(),
        standInParam.getData(),
        standInParam.getCreatedAt(),
        standInParam.getModifiedAt());
  }

  @NotNull
  @Query("select p.key, p.data, p.created_at, p.modified_at from " + StandInParam.TABLE_NAME
      + " p where p.key = :key")
  Optional<StandInParam> findByKey(@NotEmpty @Param("key") String key);
}
