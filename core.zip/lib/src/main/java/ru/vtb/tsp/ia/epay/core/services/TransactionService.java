package ru.vtb.tsp.ia.epay.core.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.customer.CustomerInfo;
import ru.vtb.tsp.ia.epay.core.domains.enums.GatewayOperation;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.order.OrderInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.MerchantSiteInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Invoice;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Payment;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Token;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowPoint;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionRepository;
import ru.vtb.tsp.ia.epay.core.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerState;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerType;

@Slf4j
@Service
@RequiredArgsConstructor
public class TransactionService {

  private static final String POSTFIX = "-vpay";
  private static final String MST_TRANSACTION_ID = "mstTransactionId";

  private final TransactionInfoService transactionInfoService;
  private final TransactionRepository transactionRepository;

  public @NotNull Optional<Transaction> createMirPayPayment(@Nullable Order order) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, o.getAmount(), 0d, o.getCurrency(), null,
            TransactionType.MIR_PAYMENT_WEB_BASED));
  }

  public @NotNull Optional<Transaction> createMirPayRefund(@Nullable Order order,
      @Nullable String mstTransactionId) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, o.getAmount(), 0d, o.getCurrency(), mstTransactionId,
            TransactionType.MIR_PAYMENT_WEB_BASED_REFUND))
        .map(tx -> {
              tx.getData().setGatewayOperation(GatewayOperation.REFUND);
              return tx;
            }
        );
  }

  public @NotNull Optional<Transaction> createPartialMirPayRefund(@Nullable Order order,
      @Nullable Double amount, @Nullable String mstTransactionId) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, amount, 0d, o.getCurrency(), mstTransactionId,
            TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND))
        .map(tx -> {
              tx.getData().setGatewayOperation(GatewayOperation.PARTIAL_REFUND);
              return tx;
            }
        );
  }

  public @NotNull Optional<Transaction> createSbpPayment(@Nullable Order order) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, o.getAmount(), 0d, o.getCurrency(), null,
            TransactionType.SBP_PAYMENT));
  }

  public @NotNull Optional<Transaction> createSbpRefund(@Nullable Order order,
      @Nullable Double amount,
      @Nullable Currency currency,
      @Nullable String mstTransactionId) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, amount, 0d, currency, mstTransactionId,
            order.getAmount().equals(amount)
                ? TransactionType.SBP_REFUND
                : TransactionType.PARTIAL_SBP_REFUND)
        );
  }

  public @NotNull Optional<Transaction> createCardPayment(@Nullable Order order) {
    return Optional.ofNullable(order)
        .flatMap(o -> {
          final TransactionType transactionType;
          if (OrderType.PAYMENT.equals(o.getOrderType())) {
            //В ордере указан id связки -> платеж cof, идущий без 3DS по своему flow
            if (Objects.nonNull(o.getBindingCode())) {
              transactionType = TransactionType.COF_PAYMENT;
            } else {
              if (o.getMst().isEnableCardFlowThreeDS()) {
                transactionType = TransactionType.CARD_PAYMENT;
              } else {
                transactionType = TransactionType.CARD_PAYMENT_WITHOUT_3DS;
              }
            }
            return create(o, o.getAmount(), 0d, o.getCurrency(), null,
                transactionType)
                .map(tx -> {
                  tx.getData().setGatewayOperation(GatewayOperation.PAYMENT);
                  tx.getData().getContext().put(MST_TRANSACTION_ID, tx.getMstTransactionId());
                  return tx;
                });
          } else if (OrderType.TRANSFER.equals(o.getOrderType())) {
            final GatewayOperation gatewayOperation = GatewayOperation.ACCOUNT_TO_CARD;
            transactionType = TransactionType.A2C_TRANSFER;
            return create(o, o.getAmount(), 0d, o.getCurrency(), null,
                transactionType)
                .map(tx -> {
                  tx.getData().setGatewayOperation(gatewayOperation);
                  tx.getData().getOrderInfo().setAccount(o.getAccount());
                  tx.getData().getOrderInfo().setBic(o.getBic());
                  tx.getData().getContext().put(MST_TRANSACTION_ID, tx.getMstTransactionId());
                  return tx;
                });
          } else if (OrderType.TWO_STAGE.equals(o.getOrderType())) {
            transactionType = o.getMst().isEnableCardFlowThreeDS()
                ? TransactionType.CARD_PAYMENT_TWO_STAGE_3DS
                : TransactionType.CARD_PAYMENT_TWO_STAGE;
            return create(o, o.getAmount(), o.getAmount(), o.getCurrency(), null,
                transactionType)
                .map(tx -> {
                  tx = tx.withAmountHold(tx.getAmount());
                  tx.getData().setGatewayOperation(GatewayOperation.AUTH);
                  tx.getData().getContext().put(MST_TRANSACTION_ID, tx.getMstTransactionId());
                  return tx;
                });
          } else {
            log.error("Unknown order type {}", o.getOrderType());
            throw new IllegalArgumentException("Unknown order type " + o.getOrderType());
          }
        });
  }

  public @NotNull Optional<Transaction> createCardRefund(@Nullable Order order,
      @Nullable Double amount,
      @Nullable Currency currency,
      @Nullable String mstTransactionId) {
    return Optional.ofNullable(order)
        .flatMap(o -> create(o, amount, 0d, currency, mstTransactionId,
            TransactionType.CARD_REFUND))
        .map(tx -> {
          tx.getData().setGatewayOperation(GatewayOperation.REFUND);
          return tx;
        });
  }

  public @NotNull Optional<Transaction> createPartialCardRefund(@Nullable Order order,
      @Nullable Double amount,
      @Nullable Currency currency,
      @Nullable String mstTransactionId) {
    return Optional.ofNullable(order)
        .flatMap(
            o -> create(o, amount, 0d, currency, mstTransactionId,
                TransactionType.PARTIAL_CARD_REFUND))
        .map(tx -> {
          tx.getData().setGatewayOperation(GatewayOperation.PARTIAL_REFUND);
          return tx;
        });
  }

  private @NotNull Optional<Transaction> create(@Nullable Order order,
      @Nullable Double amount,
      @Nullable Double amountHold,
      @Nullable Currency currency,
      @Nullable String mstTransactionId,
      @NotNull TransactionType type) {
    if (Objects.isNull(order) || Objects.isNull(amount) || Objects.isNull(amountHold)
        || Objects.isNull(currency)) {
      return Optional.empty();
    }
    final Payment paymentData;
    if (TransactionType.SBP_PAYMENT.equals(type) || TransactionType.SBP_REFUND.equals(type)
        || TransactionType.PARTIAL_SBP_REFUND.equals(type)) {
      paymentData = new Sbp();
    } else if (TransactionType.CARD_PAYMENT.equals(type)
        || TransactionType.CARD_PAYMENT_WITHOUT_3DS.equals(type)
        || TransactionType.COF_PAYMENT.equals(type)
        || TransactionType.PARTIAL_CARD_REFUND.equals(type)
        || TransactionType.CARD_REFUND.equals(type)
        || TransactionType.A2C_TRANSFER.equals(type)
        || TransactionType.C2A_TRANSFER.equals(type)
        || TransactionType.CARD_PAYMENT_TWO_STAGE.equals(type)
        || TransactionType.CARD_PAYMENT_TWO_STAGE_3DS.equals(type)
    ) {
      paymentData = new Card();
    } else if (TransactionType.APPLE_PAYMENT.equals(type)
        || TransactionType.GOOGLE_PAYMENT.equals(type)) {
      paymentData = new Token();
    } else if (TransactionType.INVOICE_PAYMENT.equals(type)) {
      paymentData = new Invoice();
    } else if (TransactionType.MIR_PAYMENT_WEB_BASED.equals(type)
        || TransactionType.MIR_PAYMENT_WEB_BASED_REFUND.equals(type)
        || TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND.equals(type)) {
      paymentData = new MirPay();
    } else {
      log.error("Unknown type of transaction {}", type);
      throw new IllegalArgumentException("Unknown type of transaction " + type);
    }
    final var transactionId = UUID.randomUUID() + POSTFIX;
    final var createdAt = LocalDateTime.now(ZoneOffset.UTC);
    final var currentMstTransactionId = Objects.requireNonNullElse(mstTransactionId,
        UUID.randomUUID().toString());
    final var transactionCode = UUID.randomUUID().toString();
    return Optional.ofNullable(Transaction.builder()
        .transactionId(transactionId)
        .mst(order.getMst())
        .order(order)
        .flow(null)
        .createdAt(createdAt)
        .amount(amount)
        .amountHold(amountHold)
        .mstTransactionId(currentMstTransactionId)
        .code(transactionCode)
        .currency(currency)
        .type(type)
        .state(TransactionState.NEW)
        .version(0)
        .data(TransactionPayload.builder()
            .transactionId(transactionId)
            .paymentId(currentMstTransactionId)
            .description(order.getMstOrderId())
            .createdAt(createdAt)
            .type(type)
            .merchant(MerchantSiteInfo.builder()
                .id(order.getMst().getMerchant().getId())
                .mstId(order.getMst().getId())
                .name(ConverterUtils.convertToMstName(order))
                .merchantSiteParams(MerchantSiteParams.builder()
                    .callbackUrl(ConverterUtils.convertToCallbackUrl(order))
                    .fiscalParams(ConverterUtils.convertToFiscalParams(order))
                    .mcc(ConverterUtils.convertToMcc(order))
                    .orderLifeTime(ConverterUtils.convertToOrderLifeTime(order))
                    .sbpParams(ConverterUtils.convertToSbpParams(order))
                    .cardParams(ConverterUtils.convertToCardParams(order))
                    .transferParams(ConverterUtils.convertToTransferParams(order))
                    .build())
                .url(order.getMst().getUrl())
                .build())
            .status(TransactionState.NEW)
            .amount(Amount.builder()
                .value(amount)
                .currency(currency.getCode()).build())
            .amountHold(Amount.builder()
                .value(amountHold)
                .currency(currency.getCode()).build())
            .paymentData(paymentData)
            .subamounts(Collections.emptyList())
            .transactionCode(transactionCode)
            .orderInfo(OrderInfo.of(order))
            .context(new HashMap<>())
            .customerInfo(CustomerInfo.builder()
                .mstCustomerId(order.getMstCustomerId())
                .type(CustomerType.GLOBAL)
                .state(CustomerState.ACTIVE)
                .build())
            .build())
        .build());
  }

  public @NotNull Optional<Transaction> getById(@Nullable String transactionId) {
    return Optional.ofNullable(transactionId).flatMap(transactionRepository::findById);
  }

  public @NotNull Optional<Transaction> getByMstTransactionId(@Nullable String mstId,
      @Nullable String mstTransactionId) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(mstTransactionId)) {
      return Optional.empty();
    }
    return transactionRepository.findByMstTransactionId(mstId, mstTransactionId);
  }

  public @NotNull List<Transaction> getByOrderId(@Nullable String orderId) {
    return Optional.ofNullable(orderId)
        .map(transactionRepository::findByOrderId)
        .orElse(Collections.emptyList());
  }

  public @NotNull List<Transaction> getByOrderCode(@Nullable String orderCode) {
    return Optional.ofNullable(orderCode)
        .map(transactionRepository::findByOrderCode)
        .orElse(Collections.emptyList());
  }

  public boolean isExistsByOrderId(@Nullable String orderId) {
    return !getByOrderId(orderId).isEmpty();
  }

  public @NotNull List<Transaction> getWithQrcByOrderId(@Nullable String orderId) {
    return getByOrderId(orderId)
        .stream()
        .filter(tx -> transactionInfoService.getByTransactionId(tx.getTransactionId())
            .stream()
            .filter(txInfo -> TransactionInfoKey.SBP_QR_LINK.equals(txInfo.getKey()))
            .map(TransactionInfo::getTransaction)
            .findFirst()
            .isPresent())
        .collect(Collectors.toList());
  }

  public @NotNull List<Transaction> getByKeyAndState(
      @NotNull TransactionInfoKey key,
      @Nullable TransactionState transactionState,
      @Nullable LocalDateTime createdAt) {
    return transactionInfoService.getByKeyAndState(key, transactionState, createdAt)
        .stream()
        .map(TransactionInfo::getTransaction)
        .collect(Collectors.toList());
  }

  public @NotNull List<Transaction> getByKeyAndValueAndState(
      @NotNull TransactionInfoKey key,
      @Nullable String value,
      @Nullable TransactionState transactionState,
      @Nullable LocalDateTime createdAt) {
    return transactionInfoService.getByKeyAndValueAndState(key, value, transactionState, createdAt)
        .stream()
        .map(TransactionInfo::getTransaction)
        .collect(Collectors.toList());
  }

  @Transactional
  public @NotNull Optional<TransactionInfo> upsertInfo(@Nullable TransactionInfo transactionInfo) {
    return Optional.ofNullable(transactionInfo)
        .flatMap(transactionInfoService::saveOrUpdateInfo)
        .map(txInfo -> {
          log.info("Transaction info {} was inserted/updated", txInfo.getTransactionInfoId());
          return txInfo;
        });
  }

  @Transactional
  public @NotNull Optional<TransactionInfo> upsertInfo(@Nullable String transactionId,
      @Nullable TransactionInfoKey key,
      @Nullable String value,
      @Nullable LocalDateTime createdAt) {
    return transactionInfoService.saveOrUpdateInfo(transactionId, key, value, createdAt);
  }

  public @NotNull Optional<Transaction> getByCode(@Nullable String code) {
    return Optional.ofNullable(code).flatMap(transactionRepository::findByCode);
  }

  public @NotNull List<Transaction> getByState(@Nullable TransactionState state,
      @Nullable LocalDateTime createdAt) {
    if (Objects.isNull(state) || Objects.isNull(createdAt)) {
      return Collections.emptyList();
    }
    return transactionRepository.findByState(state, createdAt);
  }

  public @NotNull List<Transaction> getByStateAndType(@Nullable TransactionState state,
      @Nullable TransactionType type,
      @Nullable LocalDateTime createdAt) {
    if (Objects.isNull(state) || Objects.isNull(type) || Objects.isNull(createdAt)) {
      return Collections.emptyList();
    }
    return transactionRepository.findByStateAndType(state, type, createdAt);
  }

  public @NotNull Optional<Transaction> lockById(@Nullable String transactionId) {
    return Optional.ofNullable(transactionId).flatMap(transactionRepository::lockById);
  }

  public @NotNull Optional<Transaction> lockByCode(@Nullable String code) {
    return Optional.ofNullable(code).flatMap(transactionRepository::lockByCode);
  }

  public @NotNull Optional<Transaction> lockByMstTransactionId(@Nullable String mstId,
      @Nullable String mstTransactionId) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(mstTransactionId)) {
      return Optional.empty();
    }
    return transactionRepository.lockByMstTransactionId(mstId, mstTransactionId);
  }

  @Transactional
  public @NotNull Optional<Transaction> upsert(@Nullable Transaction transaction) {
    return Optional.ofNullable(transaction)
        .map(transactionRepository::saveOrUpdate)
        .map(tx -> {
          log.info("Transaction {} was inserted/updated", tx.getTransactionId());
          return tx;
        });
  }

  @Transactional
  public boolean updateDataById(@Nullable String transactionId,
      @Nullable TransactionPayload payload) {
    if (Objects.isNull(transactionId) || Objects.isNull(payload)) {
      return false;
    }
    if (transactionRepository.updateDataById(transactionId, payload)) {
      log.info("Transaction data {} was inserted/updated", transactionId);
      return true;
    } else {
      return false;
    }
  }

  @Transactional
  public boolean updateDataById(@Nullable Transaction transaction) {
    return Optional.ofNullable(transaction)
        .map(tx -> updateDataById(tx.getTransactionId(), tx.getData()))
        .orElse(false);
  }

  @Transactional
  public Optional<TransactionPayload> updateTransactionFlow(@NotNull TransactionPayload tp) {
    return this.getById(tp.getTransactionId())
        .flatMap(t -> this.upsert(t.withFlow(Objects.requireNonNullElse(t.getFlow(),
                tp.getRoute()
                    .getFlowPoints()
                    .stream()
                    .map(FlowPoint::getFlow)
                    .findFirst().orElse(null)))
            .withData(tp))
        ).map(tx -> Optional.of(tx.getData()))
        .orElseThrow(() -> new IllegalArgumentException(
            String.format("Incorrect transaction id %s, can't fill data", tp.getTransactionId())));
  }

  @Transactional
  public boolean updateStateById(@NotNull String transactionId, @NotNull TransactionState state) {
    return getById(transactionId).map(
        tx -> transactionRepository.updateStateById(transactionId, state,
            tx.getVersion())).orElse(false);
  }

}