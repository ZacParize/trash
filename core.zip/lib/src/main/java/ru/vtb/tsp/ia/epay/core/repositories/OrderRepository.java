package ru.vtb.tsp.ia.epay.core.repositories;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

public interface OrderRepository extends CrudRepository<Order, String> {

  String COMMON_SELECT =
      "select "
          + "    o.order_id, "
          + "    ms.id as mst_id, "
          + "    m.id as mst_merchant_id, "
          + "    m.name as mst_merchant_name, "
          + "    m.params as mst_merchant_params, "
          + "    ms.url as mst_url, "
          + "    ms.name as mst_name, "
          + "    ms.login as mst_login, "
          + "    ms.params as mst_params, "
          + "    o.mst_order_id, "
          + "    o.code, "
          + "    o.name, "
          + "    o.amount, "
          + "    o.amount_hold, "
          + "    c.code as currency_code, "
          + "    c.numeric_code as currency_numeric_code, "
          + "    c.name as currency_name, "
          + "    o.state, "
          + "    o.created_at, "
          + "    o.description, "
          + "    o.expired_at, "
          + "    o.order_type, "
          + "    o.changed_at, "
          + "    o.authorized_at, "
          + "    o.return_url, "
          + "    o.account, "
          + "    o.bic, "
          + "    o.source_system, "
          + "    o.version, "
          + "    o.binding_type, "
          + "    o.binding_category, "
          + "    o.binding_code, "
          + "    o.mst_customer_id"
          + " from "
          + "    orders o "
          + "    inner join currencies c on c.code = o.currency_ref "
          + "    inner join merchant_sites ms on ms.id = o.mst_ref "
          + "    inner join merchants m on ms.merch_ref = m.id";

  @NotNull
  @Query(COMMON_SELECT + " where o.order_id = :orderId for update of o")
  Optional<Order> lockById(@NotEmpty @Param("orderId") String orderId);

  @NotNull
  @Override
  @Query(COMMON_SELECT + " where o.order_id = :orderId")
  Optional<Order> findById(@NotEmpty @Param("orderId") String orderId);

  @NotNull
  @Query(COMMON_SELECT + " where o.code = :code for update of o")
  Optional<Order> lockByCode(@NotEmpty @Param("code") String code);

  @NotNull
  @Query(COMMON_SELECT + " where o.code = :code")
  Optional<Order> findByCode(@NotEmpty @Param("code") String code);

  @NotNull
  @Query(COMMON_SELECT + " where o.mst_ref = :mstId and o.mst_order_id = :mstOrderId for update of o")
  Optional<Order> lockByMstOrderId(@NotEmpty @Param("mstId") String mstId,
      @NotEmpty @Param("mstOrderId") String mstOrderId);

  @NotNull
  @Query(COMMON_SELECT + " where o.mst_ref = :mstId and o.mst_order_id = :mstOrderId")
  Optional<Order> findByMstOrderId(@NotEmpty @Param("mstId") String mstId,
      @NotEmpty @Param("mstOrderId") String mstOrderId);

  @NotEmpty
  @Query("insert into orders (order_id, mst_ref, mst_order_id, code, name, " +
      "amount, amount_hold, currency_ref, state, created_at, authorized_at, " +
      "description, expired_at, order_type, changed_at, return_url, account, bic, source_system, " +
      "version, binding_type, binding_category, binding_code, mst_customer_id) " +
      "values (:orderId, :mst, :mstOrderId, :code, :name, " +
      ":amount, :amountHold, :currency, :state, :createdAt, :authorizedAt, " +
      ":description, :expiredAt, :orderType, " +
      ":changedAt, :returnUrl, :account, :bic, :sourceSystem, :version, :bindingType,"+
      ":bindingCategory, :bindingCode, :mstCustomerId) " +
      "on conflict (order_id) do update set mst_ref = :mst, mst_order_id = :mstOrderId, " +
      "code = :code, name = :name, amount = :amount, amount_hold = :amountHold, currency_ref = :currency, " +
      "state = :state, created_at = :createdAt, authorized_at = :authorizedAt, " +
      "description = :description, expired_at = :expiredAt, order_type = :orderType, changed_at = :changedAt, " +
      "return_url = :returnUrl, account = :account, bic = :bic, source_system = :sourceSystem, " +
      "version = (:version + 1), binding_type = :bindingType, binding_category = :bindingCategory, "+
      "binding_code = :bindingCode, mst_customer_id = :mstCustomerId " +
      "where orders.version = :version RETURNING *")
  Order saveOrUpdate(@NotEmpty @Param("orderId") String orderId,
      @NotEmpty @Param("mst") String mst,
      @NotEmpty @Param("mstOrderId") String mstOrderId,
      @NotEmpty @Param("code") String code,
      @NotEmpty @Param("name") String name,
      @NotNull @Param("amount") Double amount,
      @NotNull @Param("amountHold") Double amountHold,
      @NotEmpty @Param("currency") String currency,
      @NotNull @Param("state") OrderState state,
      @NotNull @Param("createdAt") LocalDateTime createdAt,
      @NotNull @Param("authorizedAt") LocalDateTime authorizedAt,
      @Nullable @Param("description") String description,
      @Nullable @Param("expiredAt") LocalDateTime expiredAt,
      @NotNull @Param("orderType") OrderType orderType,
      @Nullable @Param("changedAt") LocalDateTime changedAt,
      @Nullable @Param("returnUrl") String returnUrl,
      @Nullable @Param("account") String account,
      @Nullable @Param("bic") String bic,
      @Nullable @Param("sourceSystem") SourceSystem sourceSystem,
      @Nullable @Param("version") Integer version,
      @Nullable@Param("bindingType") BindingType bindingType,
      @Nullable @Param("bindingCategory") BindingCategory bindingCategory,
      @Nullable @Param("bindingCode") UUID bindingCode,
      @Nullable @Param("mstCustomerId") String mstCustomerId);


  default @Nullable
  Order saveOrUpdate(@Nullable Order order) {
    Objects.requireNonNull(order, "Order can't be null");
    Objects.requireNonNull(order.getOrderId(), "Order id can't be null");
    Objects.requireNonNull(order.getMst(), "Order's merchant site can't be null");
    Objects.requireNonNull(order.getAmount(), "Order's amount can't be null");
    Objects.requireNonNull(order.getCurrency(), "Order's currency can't be null");
    Objects.requireNonNull(order.getCode(), "Order's code can't be null");
    Objects.requireNonNull(order.getState(), "Order's state can't be null");
    Objects.requireNonNull(order.getOrderType(), "Order type can't be null");
    Objects.requireNonNull(order.getSourceSystem(), "Order source system can't be null");
    //одинаковые changeKey попадают в одну партицию
    MDC.put(MDCKeySupplier.UNIQUE_KEY, order.getOrderId());
    final var entity = Optional.ofNullable(saveOrUpdate(
            findByMstOrderId(order.getMst().getId(), order.getMstOrderId())
                .map(Order::getOrderId)
                .orElse(order.getOrderId()),
            order.getMst().getId(),
            order.getMstOrderId(),
            order.getCode(),
            order.getName(),
            order.getAmount(),
            order.getAmountHold(),
            order.getCurrency().getCode(),
            order.getState(),
            Objects.requireNonNullElse(order.getCreatedAt(),
                LocalDateTime.now(ZoneOffset.UTC)),
            order.getAuthorizedAt(),
            order.getDescription(),
            order.getExpiredAt(),
            order.getOrderType(),
            Objects.requireNonNullElse(order.getChangedAt(),
                LocalDateTime.now(ZoneOffset.UTC)),
            order.getReturnUrl(),
            order.getAccount(),
            order.getBic(),
            order.getSourceSystem(),
            order.getVersion(),
            order.getBindingType(),
            order.getBindingCategory(),
            order.getBindingCode(),
            order.getMstCustomerId()))
        .orElseThrow(() -> new OptimisticLockingFailureException(order.getOrderId()));
    return findById(entity.getOrderId()).orElse(null);
  }

  @Modifying
  @Query("update orders set state = :state, changed_at = :changedAt, version = (:version + 1) " +
      "WHERE order_id = :orderId and version = :version")
  boolean updateStateById(
      @NotNull @Param("orderId") String orderId,
      @NotNull @Param("state") OrderState state,
      @NotNull @Param("changedAt") LocalDateTime changedAt,
      @NotNull @Param("version") int version);

  default boolean updateStateById(@NotNull @Param("orderId") String orderId,
      @NotNull @Param("state") OrderState state) {
    return findById(orderId)
        .map(o -> {
          MDC.put(MDCKeySupplier.UNIQUE_KEY, orderId);
          if (!updateStateById(orderId, state, LocalDateTime.now(ZoneOffset.UTC),
              o.getVersion())) {
            throw new OptimisticLockingFailureException(orderId);
          }
          return true;
        }).orElse(false);
  }

}