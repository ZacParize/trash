package ru.vtb.tsp.ia.epay.core.utils.version;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.lang.management.ManagementFactory;
import java.lang.management.RuntimeMXBean;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Date;

@Slf4j
@Service
@RequiredArgsConstructor
public class VersionService {

  @Value("${spring.application.name:}")
  private String component;

  @Value("${spring.profiles.active:}")
  private String springActiveProfile;

  private final GitVersion gitVersion;
  private VersionHolder versionHolder;

  @PostConstruct
  public void init() {
    versionHolder = new VersionHolder();
    versionHolder.setComponent(component);
    versionHolder.setEnvironment(springActiveProfile);

    versionHolder.setBranch(gitVersion.getBranch());
    versionHolder.setCommitId(gitVersion.getCommitId());
    versionHolder.setBuildVersion(gitVersion.getBuildVersion());
    versionHolder.setBuildTime(gitVersion.getBuildTime());
    versionHolder.setApiVersion(gitVersion.getApiVersion());

    RuntimeMXBean rb = ManagementFactory.getRuntimeMXBean();
    versionHolder.setStartTime(new Date(rb.getStartTime()));

    InetAddress ip;
    try {
      ip = InetAddress.getLocalHost();

      versionHolder.setServerIp(ip.getHostAddress());
      versionHolder.setServerHostName(ip.getHostName());
    } catch (UnknownHostException e) {
      log.error("Failed to get server IP address");
    }
  }

  public VersionHolder getVersionData(Boolean printLog) {
    if (Boolean.TRUE.equals(printLog)) {
      log.info("Version service is called: {}", versionHolder.toString());
    }
    return versionHolder;
  }
}
