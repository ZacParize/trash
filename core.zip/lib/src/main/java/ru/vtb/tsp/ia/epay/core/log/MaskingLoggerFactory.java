package ru.vtb.tsp.ia.epay.core.log;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MaskingLoggerFactory {

  public static MaskingLogger getLogger(Class<?> clazz) {
    Logger logger = LoggerFactory.getLogger(clazz);
    return new MaskingLogger(logger);
  }
}
