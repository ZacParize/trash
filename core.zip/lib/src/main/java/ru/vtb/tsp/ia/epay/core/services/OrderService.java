package ru.vtb.tsp.ia.epay.core.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.order.OrderInfo;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.repositories.OrderRepository;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {

  private final OrderRepository orderRepository;
  private final TransactionService transactionService;
  private final Function<Order, Order> checkIfOrderExpired = order -> {
    if (Objects.nonNull(order) && order.isPayment() && order.isExpired()
        && !OrderState.EXPIRED.equals(order.getState())) {
      order = upsert(order.withState(OrderState.EXPIRED))
          .orElseThrow(() -> new IllegalArgumentException("Can't change order state"));
    }
    return order;
  };

  public @NotNull Optional<Order> create(@Nullable Currency currency,
                                         @Nullable MerchantSite mst,
                                         @Nullable String mstOrderId,
                                         @Nullable Double amount,
                                         @Nullable Double amountHold,
                                         @Nullable LocalDateTime createdAt,
                                         @Nullable LocalDateTime authorizedAt,
                                         @Nullable LocalDateTime expiredAt,
                                         @Nullable OrderType type,
                                         @Nullable String name,
                                         @Nullable String description,
                                         @Nullable String returnUrl,
                                         @Nullable String account,
                                         @Nullable String bic,
                                         @Nullable SourceSystem sourceSystem,
                                         @Nullable BindingCategory bindingCategory,
                                         @Nullable BindingType bindingType,
                                         @Nullable UUID bindingCode,
                                         @Nullable String mstCustomerId) {
    if (Objects.isNull(currency) || Objects.isNull(mst) || ObjectUtils.isEmpty(mstOrderId)
        || Objects.isNull(amount) || Objects.isNull(type) || ObjectUtils.isEmpty(name)
        || (Objects.isNull(expiredAt) && !OrderType.isTransfer(type))) {
      return Optional.empty();
    }
    final var createDate = Objects.requireNonNullElse(createdAt, LocalDateTime.now(ZoneOffset.UTC));
    if (Objects.nonNull(expiredAt)) {
      if (createDate.isAfter(expiredAt)) {
        return Optional.empty();
      }
    }
    return Optional.of(Order.builder()
        .orderId(UUID.randomUUID().toString())
        .mst(mst)
        .mstOrderId(mstOrderId)
        .code(UUID.randomUUID().toString())
        .amount(amount)
        .amountHold(amountHold)
        .currency(currency)
        .state(OrderState.CREATED)
        .createdAt(createDate)
        .authorizedAt(authorizedAt)
        .changedAt(createDate)
        .orderType(type)
        .name(name)
        .description(description)
        .returnUrl(returnUrl)
        .account(account)
        .bic(bic)
        .sourceSystem(sourceSystem)
        .expiredAt(expiredAt)
        .bindingCategory(bindingCategory)
        .bindingCode(bindingCode)
        .bindingType(bindingType)
        .mstCustomerId(mstCustomerId)
        .build());
  }

  public @NotNull Optional<Order> lockById(@Nullable String orderId) {
    return Optional.ofNullable(orderId).flatMap(orderRepository::lockById).map(checkIfOrderExpired);
  }

  public @NotNull Optional<Order> getById(@Nullable String orderId) {
    return Optional.ofNullable(orderId).flatMap(orderRepository::findById).map(checkIfOrderExpired);
  }

  public @NotNull Optional<Order> lockByMstOrderId(@Nullable String mstId,
      @Nullable String mstOrderId) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(mstOrderId)) {
      return Optional.empty();
    }
    return orderRepository.lockByMstOrderId(mstId, mstOrderId).map(checkIfOrderExpired);
  }

  public @NotNull Optional<Order> getByMstOrderId(@Nullable String mstId,
      @Nullable String mstOrderId) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(mstOrderId)) {
      return Optional.empty();
    }
    return orderRepository.findByMstOrderId(mstId, mstOrderId).map(checkIfOrderExpired);
  }

  public @NotNull Optional<Order> lockByCode(@Nullable String code) {
    return Optional.ofNullable(code).flatMap(orderRepository::lockByCode).map(checkIfOrderExpired);
  }

  public @NotNull Optional<Order> getByCode(@Nullable String code) {
    return Optional.ofNullable(code).flatMap(orderRepository::findByCode).map(checkIfOrderExpired);
  }

  public boolean isTransactionExistsById(@Nullable String orderId) {
    return transactionService.isExistsByOrderId(orderId);
  }

  @Transactional
  public @NotNull Optional<Order> upsert(@Nullable Order order) {
    return Optional.ofNullable(order)
        .map(orderRepository::saveOrUpdate)
        .map(o -> {
          transactionService.getByOrderId(o.getOrderId())
              .stream()
              .filter(tx -> Objects.nonNull(tx.getData()))
              .forEach(tx -> {
                tx.getData().setOrderInfo(OrderInfo.of(tx.getOrder()));
                transactionService.updateDataById(tx);
              });
          return o;
        });
  }
}