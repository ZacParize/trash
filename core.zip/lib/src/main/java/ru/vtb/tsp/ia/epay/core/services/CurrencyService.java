package ru.vtb.tsp.ia.epay.core.services;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.repositories.CurrencyRepository;

@Service
@RequiredArgsConstructor
public class CurrencyService {

    private final CurrencyRepository currencyRepository;

    public @NotNull Optional<Currency> getById(@Nullable String id) {
        return Optional.ofNullable(id).flatMap(currencyRepository::findById);
    }

    public @NotNull Optional<Currency> getByNumericCode(int numericCode) {
        return currencyRepository.findByNumericCode(numericCode);
    }

}