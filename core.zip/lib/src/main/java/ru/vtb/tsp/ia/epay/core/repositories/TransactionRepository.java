package ru.vtb.tsp.ia.epay.core.repositories;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.jdbc.repository.query.Modifying;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.core.domains.order.OrderInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;

public interface TransactionRepository extends CrudRepository<Transaction, String> {

  String COMMON_SELECT =
      "select "
          + "    tx.transaction_id, "
          + "    o.order_id as order_order_id, "
          + "    ms1.id as order_mst_id, "
          + "    m1.id as order_mst_merchant_id, "
          + "    m1.name as order_mst_merchant_name, "
          + "    m1.params as order_mst_merchant_params, "
          + "    ms1.url as order_mst_url, "
          + "    ms1.name as order_mst_name, "
          + "    ms1.login as order_mst_login, "
          + "    ms1.params as order_mst_params, "
          + "    o.mst_order_id as order_mst_order_id, "
          + "    o.code as order_code, "
          + "    o.name as order_name, "
          + "    o.amount as order_amount, "
          + "    o.amount_hold as order_amount_hold, "
          + "    co.code as order_currency_code, "
          + "    co.numeric_code as order_currency_numeric_code, "
          + "    co.name as order_currency_name, "
          + "    o.state as order_state, "
          + "    o.created_at as order_created_at, "
          + "    o.description as order_description, "
          + "    o.order_type as order_order_type, "
          + "    o.expired_at as order_expired_at, "
          + "    o.return_url as order_return_url, "
          + "    o.account as order_account, "
          + "    o.bic as order_bic, "
          + "    o.source_system as order_source_system, "
          + "    o.version as order_version, "
          + "    o.binding_type as order_binding_type, "
          + "    o.binding_category as order_binding_category, "
          + "    o.binding_code as order_binding_code, "
          + "    o.mst_customer_id as order_mst_customer_id, "
          + "    f.flow_id as flow_flow_id, "
          + "    ms2.id as flow_mst_id, "
          + "    m2.id as flow_mst_merchant_id, "
          + "    m2.name as flow_mst_merchant_name, "
          + "    m2.params as flow_mst_merchant_params, "
          + "    ms2.url as flow_mst_url, "
          + "    ms2.name as flow_mst_name, "
          + "    ms2.login as flow_mst_login, "
          + "    ms2.params as flow_mst_params, "
          + "    f.name as flow_name, "
          + "    f.description as flow_description, "
          + "    tx.created_at, "
          + "    tx.amount, "
          + "    tx.amount_hold, "
          + "    ctx.code as currency_code, "
          + "    ctx.numeric_code as currency_numeric_code, "
          + "    ctx.name as currency_name, "
          + "    tx.mst_transaction_id, "
          + "    tx.code, "
          + "    tx.mst_ref as mst_id, "
          + "    m3.id as mst_merchant_id, "
          + "    m3.name as mst_merchant_name, "
          + "    m3.params as mst_merchant_params, "
          + "    ms3.url as mst_url, "
          + "    ms3.name as mst_name, "
          + "    ms3.login as mst_login, "
          + "    ms3.params as mst_params, "
          + "    tx.type, "
          + "    tx.state, "
          + "    tx.data, "
          + "    tx.version "
          + "from "
          + "    transactions tx "
          + "    inner join orders o on tx.order_ref = o.order_id "
          + "    left join flows f on tx.flow_ref = f.flow_id "
          + "    inner join currencies co on o.currency_ref = co.code "
          + "    inner join currencies ctx on tx.currency_ref = ctx.code "
          + "    inner join merchant_sites ms1 on ms1.id = o.mst_ref "
          + "    left join merchant_sites ms2 on ms2.id = f.mst_ref "
          + "    inner join merchant_sites ms3 on ms3.id = tx.mst_ref "
          + "    inner join merchants m1 on ms1.merch_ref = m1.id "
          + "    left join merchants m2 on ms2.merch_ref = m2.id "
          + "    inner join merchants m3 on ms3.merch_ref = m3.id";

  @NotNull
  @Query(COMMON_SELECT + " where tx.transaction_id = :transactionId for update of tx")
  Optional<Transaction> lockById(@NotEmpty @Param("transactionId") String transactionId);

  @NotNull
  @Query(COMMON_SELECT + " where tx.code = :code for update of tx")
  Optional<Transaction> lockByCode(@NotEmpty @Param("code") String transactionId);

  @NotNull
  @Query(COMMON_SELECT + " where tx.mst_ref = :mstId and tx.mst_transaction_id = :mstTransactionId for update of tx")
  Optional<Transaction> lockByMstTransactionId(@NotEmpty @Param("mstId") String mstId,
      @NotEmpty @Param("mstTransactionId") String mstTransactionId);

  @NotNull
  @Override
  @Query(COMMON_SELECT + " where tx.transaction_id = :transactionId")
  Optional<Transaction> findById(@NotEmpty @Param("transactionId") String transactionId);

  @NotNull
  @Override
  @Query(COMMON_SELECT + " where tx.transaction_id in (:transactionIds) order by tx.transaction_id")
  Iterable<Transaction> findAllById(
      @NotEmpty @Param("transactionIds") Iterable<String> transactionIds);

  @NotNull
  @Override
  @Query(COMMON_SELECT + " order by tx.transaction_id")
  List<Transaction> findAll();

  @NotNull
  @Query(COMMON_SELECT + " where o.order_id = :orderId order by tx.transaction_id")
  List<Transaction> findByOrderId(@NotEmpty @Param("orderId") String orderId);

  @NotNull
  @Query(COMMON_SELECT + " where o.code = :orderCode order by tx.transaction_id")
  List<Transaction> findByOrderCode(@NotEmpty @Param("orderCode") String orderCode);

  @NotNull
  @Query(COMMON_SELECT + " where tx.code = :code")
  Optional<Transaction> findByCode(@NotEmpty @Param("code") String code);

  @NotNull
  @Query(COMMON_SELECT + " where tx.state = :state "
      +
      "and tx.created_at >= to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS') "
      +
      "order by tx.transaction_id limit 1000")
  List<Transaction> findByState(@NotNull @Param("state") TransactionState state,
      @NotNull @Param("createdAt") LocalDateTime createdAt);

  @NotNull
  @Query(COMMON_SELECT + " where tx.state = :state "
      +
      "and tx.type = :type "
      +
      "and tx.created_at >= to_timestamp(cast(:createdAt as text), 'YYYY-MM-DD HH24:MI:SS') "
      +
      "order by tx.transaction_id limit 1000")
  List<Transaction> findByStateAndType(@NotNull @Param("state") TransactionState state,
      @NotNull @Param("type") TransactionType type,
      @NotNull @Param("createdAt") LocalDateTime createdAt);

  @NotNull
  @Query(COMMON_SELECT + " where tx.mst_ref = :mstId and tx.mst_transaction_id = :mstTransactionId")
  Optional<Transaction> findByMstTransactionId(@NotEmpty @Param("mstId") String mstId,
      @NotEmpty @Param("mstTransactionId") String mstTransactionId);

  @NotEmpty
  @Query(
      "insert into transactions (transaction_id, order_ref, flow_ref, created_at, amount, amount_hold, "
          +
          "currency_ref, mst_transaction_id, code, mst_ref, type, state, data, version) " +
          "values (:transactionId, :order, :flow, :createdAt, :amount, :amountHold, :currency, "
          +
          ":mstTransactionId, :code, :mst, :type, :state, :data, :version)" +
          "on conflict (transaction_id) do update set " +
          "transaction_id = :transactionId, order_ref = :order, flow_ref = :flow, created_at = :createdAt, "
          +
          "amount = :amount, amount_hold = :amountHold, currency_ref = :currency, "
          +
          "mst_transaction_id = :mstTransactionId, code = :code, mst_ref = :mst, type = :type, "
          +
          "state = :state, data = :data, version = (:version + 1)  "
          +
          "where transactions.version = :version RETURNING *")
  Transaction saveOrUpdate(@NotEmpty @Param("transactionId") String transactionId,
      @NotEmpty @Param("order") String orderRef,
      @Nullable @Param("flow") Long flow,
      @NotNull @Param("createdAt") LocalDateTime createdAt,
      @NotNull @Param("amount") Double amount,
      @NotNull @Param("amountHold") Double amountHold,
      @NotEmpty @Param("currency") String currency,
      @NotEmpty @Param("mstTransactionId") String mstTransactionId,
      @NotEmpty @Param("code") String code,
      @NotEmpty @Param("mst") String mstRef,
      @NotNull @Param("type") TransactionType type,
      @NotNull @Param("state") TransactionState state,
      @Param("data") TransactionPayload transaction,
      @Param("version") int version);

  default @Nullable
  Transaction saveOrUpdate(@Nullable Transaction transaction) {
    Objects.requireNonNull(transaction, "Transaction for update can't be null");
    Objects.requireNonNull(transaction.getOrder(), "Transaction's order can't be null");
    Objects.requireNonNull(transaction.getTransactionId(), "Transaction id can't be null");
    Objects.requireNonNull(transaction.getAmount(), "Transaction's amount can't be null");
    Objects.requireNonNull(transaction.getCurrency(), "Transaction's currency can't be null");
    Objects.requireNonNull(transaction.getCode(), "Transaction's code can't be null");
    Objects.requireNonNull(transaction.getState(), "Transaction's state can't be null");
    Objects.requireNonNull(transaction.getType(), "Transaction's type can't be null");
    Objects.requireNonNull(transaction.getMst(), "Transaction's mst can't be null");
    if (Objects.isNull(transaction.getCreatedAt())) {
      transaction.setCreatedAt(LocalDateTime.now(ZoneOffset.UTC));
    }
    if (Objects.nonNull(transaction.getData())) {
      if (Objects.isNull(transaction.getData().getOrderInfo())) {
        transaction.getData().setOrderInfo(OrderInfo.builder().build());
      }
      transaction.getData().setCreatedAt(transaction.getCreatedAt());
      transaction.getData().setStatus(transaction.getState());
      transaction.getData().setAmount(Amount.builder()
          .value(transaction.getAmount())
          .currency(transaction.getCurrency().getCode())
          .build());
      transaction.getData().setAmountHold(Amount.builder()
          .value(transaction.getAmountHold())
          .currency(transaction.getCurrency().getCode())
          .build());
      transaction.getData().setType(transaction.getType());
      transaction.getData().getOrderInfo().setOrderId(transaction.getOrder().getOrderId());
      transaction.getData().getOrderInfo().setOrderCode(transaction.getOrder().getCode());
      transaction.getData().getOrderInfo().setMstOrderId(transaction.getOrder().getMstOrderId());
      transaction.getData().getOrderInfo().setOrderState(transaction.getOrder().getState());
      transaction.getData().getOrderInfo().setDescription(transaction.getOrder().getDescription());
      transaction.getData().getOrderInfo().setName(transaction.getOrder().getName());
      transaction.getData().getOrderInfo().setExpiredAt(transaction.getOrder().getExpiredAt());
      transaction.getData().getOrderInfo().setOrderType(
          Objects.requireNonNull(transaction.getOrder().getOrderType(),
              "Order type can't be null"));
      transaction.getData().getOrderInfo().setBic(transaction.getOrder().getBic());
      transaction.getData().getOrderInfo().setAccount(transaction.getOrder().getAccount());
      transaction.getData().getOrderInfo()
          .setSourceSystem(transaction.getOrder().getSourceSystem());
      transaction.getData().getOrderInfo().setReturnUrl(transaction.getOrder().getReturnUrl());
    }
    MDC.put(MDCKeySupplier.UNIQUE_KEY, transaction.getOrder().getOrderId());
    final var entity = Optional.ofNullable(saveOrUpdate(transaction.getTransactionId(),
        transaction.getOrder().getOrderId(),
        transaction.getFlow() != null ? transaction.getFlow().getFlowId() : null,
        transaction.getCreatedAt(),
        transaction.getAmount(),
        transaction.getAmountHold(),
        transaction.getCurrency().getCode(),
        transaction.getMstTransactionId(),
        transaction.getCode(),
        transaction.getMst().getId(),
        transaction.getType(),
        transaction.getState(),
        transaction.getData(),
        transaction.getVersion())).orElseThrow(
        () -> new OptimisticLockingFailureException(transaction.getTransactionId()));
    return findById(entity.getTransactionId()).orElse(null);
  }

  default boolean updateDataById(@NotNull @Param("transactionId") String transactionId,
      @NotNull @Param("data") TransactionPayload data) {
    Objects.requireNonNull(transactionId, "Transaction id can't be null");
    Objects.requireNonNull(data, "Transaction's data can't be null");
    final var transactionForUpdate = lockById(transactionId).orElse(null);
    if (Objects.isNull(transactionForUpdate)) {
      return false;
    }
    if (Objects.isNull(data.getTransactionCode())) {
      data.setTransactionCode(transactionForUpdate.getCode());
    }
    if (Objects.isNull(data.getStatus())) {
      data.setStatus(transactionForUpdate.getState());
    }
    if (Objects.isNull(data.getType())) {
      data.setType(transactionForUpdate.getType());
    }
    if (Objects.isNull(data.getCreatedAt())) {
      data.setCreatedAt(transactionForUpdate.getCreatedAt());
    }
    if (Objects.isNull(data.getAmount())) {
      data.setAmount(Amount.builder()
          .value(transactionForUpdate.getAmount())
          .currency(transactionForUpdate.getCurrency().getCode())
          .build());
    }
    if (Objects.isNull(data.getAmountHold())) {
      data.setAmountHold(Amount.builder()
          .value(transactionForUpdate.getAmountHold())
          .currency(transactionForUpdate.getCurrency().getCode())
          .build());
    }
    return Objects.nonNull(
        saveOrUpdate(transactionForUpdate
            .withCode(data.getTransactionCode())
            .withCreatedAt(data.getCreatedAt())
            .withAmount(data.getAmount().getValue())
            .withAmountHold(data.getAmountHold().getValue())
            .withType(data.getType())
            .withState(data.getStatus())
            .withData(data)));
  }

  @Modifying
  @Query("update transactions set state = :state, " +
      "data = jsonb_set(data, '{status}', (('\"' || :state || '\"')::text)::jsonb), " +
      "version = (:version + 1) " +
      "WHERE transaction_id = :transactionId and version = :version")
  boolean updateStateById(@NotNull @Param("transactionId") String transactionId,
      @NotNull @Param("state") TransactionState state,
      @NotNull @Param("version") int version);

  default boolean updateStateById(@NotNull @Param("transactionId") String transactionId,
      @NotNull @Param("state") TransactionState state) {
    return findById(transactionId)
        .map(tx -> {
          MDC.put(MDCKeySupplier.UNIQUE_KEY, tx.getOrder().getOrderId());
          if (!updateStateById(tx.getTransactionId(), state, tx.getVersion())) {
            throw new OptimisticLockingFailureException(transactionId);
          }
          return true;
        }).orElse(false);
  }

  @Modifying
  @Query("update transactions set flow_ref = :flowId, " +
      "version = (:version + 1) " +
      "WHERE transaction_id = :transactionId and version = :version")
  boolean updateFlowById(@NotEmpty @Param("transactionId") String transactionId,
      @NotNull @Param("flowId") Long flowId,
      @NotNull @Param("version") int version);

}