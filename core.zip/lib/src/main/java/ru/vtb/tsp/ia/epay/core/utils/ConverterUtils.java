package ru.vtb.tsp.ia.epay.core.utils;

import java.time.Duration;
import javax.annotation.Nullable;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteCardParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteFiscalParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteTransferParams;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;

public final class ConverterUtils {

  private ConverterUtils() {}

  public static @Nullable String convertToCallbackUrl(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getCallbackUrl();
    } else {
      return null;
    }
  }

  public static @Nullable MerchantSiteFiscalParams convertToFiscalParams(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getFiscalParams();
    } else {
      return null;
    }
  }


  public static @Nullable String convertToMcc(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getMcc();
    } else {
      return null;
    }
  }

  public static @Nullable Duration convertToOrderLifeTime(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getOrderLifeTime();
    } else {
      return null;
    }
  }

  public static @Nullable String convertToMstName(@Nullable Order order) {
    if (order != null && order.getMst() != null) {
      return order.getMst().getName();
    } else {
      return null;
    }
  }

  public static @Nullable MerchantSiteSbpParams convertToSbpParams(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getSbpParams();
    } else {
      return null;
    }
  }

  public static @Nullable MerchantSiteCardParams convertToCardParams(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null) {
      return order.getMst().getParams().getCardParams();
    } else {
      return null;
    }
  }

  public static @Nullable MerchantSiteTransferParams convertToTransferParams(@Nullable Order order) {
    if (order != null && order.getMst() != null && order.getMst().getParams() != null
            && order.getMst().getParams().getTransferParams() != null) {
      return order.getMst().getParams().getTransferParams();
    } else {
      return null;
    }
  }

}