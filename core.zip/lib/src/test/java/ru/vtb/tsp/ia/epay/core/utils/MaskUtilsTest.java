package ru.vtb.tsp.ia.epay.core.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class MaskUtilsTest {

  @DisplayName("Should mask price")
  @ParameterizedTest
  @MethodSource("provideDataForLogMasking")
  void test_maskData(String input, String expected) {
    assertEquals(expected, MaskUtils.maskData(input));
  }


  static Stream<Arguments> provideDataForLogMasking() {
    return Stream.of(
        Arguments.of(
            "Some text amount=10, amount=11.0, amount=12",
            "Some text amount=**, amount=**.*, amount=**"
        ),
        Arguments.of(
            "some more text \"amountHold\": {\"value\": 0.0, \"currency\": \"RUB\"}",
            "some more text \"amountHold\": {\"value\": *.*, \"currency\": \"RUB\"}"
        ),
        Arguments.of(
            "some more text \"amount\": {\"value\": 300.0, \"currency\": \"RUB\"}",
            "some more text \"amount\": {\"value\": ***.*, \"currency\": \"RUB\"}"
        ),
        Arguments.of(
            "some more text amount=AmountRequestDto(value=2001.0, code=RUB)",
            "some more text amount=AmountRequestDto(value=****.*, code=RUB)"
        ),
        Arguments.of(
            "some more text amount=Amount(value=2001.0, currency=RUB)",
            "some more text amount=Amount(value=****.*, currency=RUB)"
        ),
        Arguments.of(
            "some more text amountHold=Amount(value=0.0, currency=RUB)",
            "some more text amountHold=Amount(value=*.*, currency=RUB)"
        )
    );
  }

}