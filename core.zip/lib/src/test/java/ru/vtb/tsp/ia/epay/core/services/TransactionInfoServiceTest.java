package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionInfoRepository;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

@ExtendWith(MockitoExtension.class)
public class TransactionInfoServiceTest {

    static TransactionInfoRepository TRANSACTION_INFO_REPOSITORY;

    static TransactionInfoService TRANSACTION_INFO_SERVICE;

    static Stream<Arguments> provideTransactionInfos() {
        return Stream.of(Arguments.of(TestFactory.getTransactionInfo()));
    }

    static Stream<Arguments> provideEmptyTransactionInfos() {
        return Stream.of(null, Arguments.of(TestFactory.getEmptyTransactionInfo()));
    }

    @BeforeEach
    void init() {
        TRANSACTION_INFO_REPOSITORY = Mockito.mock(TransactionInfoRepository.class);
        TRANSACTION_INFO_SERVICE = new TransactionInfoService(TRANSACTION_INFO_REPOSITORY);
    }

    @DisplayName("Should pass transaction info service get by transaction id")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_getByTransactionId(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.findByTransactionId(txInfo.getTransaction().getTransactionId()))
                .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_INFO_SERVICE
                .getByTransactionId(txInfo.getTransaction().getTransactionId());
        assertNotNull(testResult);
        assertIterableEquals(Collections.singletonList(txInfo), testResult);
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
                .findByTransactionId(txInfo.getTransaction().getTransactionId());
    }

    @DisplayName("Should pass transaction info service get by transaction id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactionInfos")
    void test_getByTransactionIdWithEmpty(TransactionInfo txInfo) {
        final var testResult = TRANSACTION_INFO_SERVICE
            .getByTransactionId(Optional.ofNullable(txInfo)
                .map(TransactionInfo::getTransaction)
                .map(Transaction::getTransactionId).orElse(null));
        assertNotNull(testResult);
        assertIterableEquals(Collections.emptyList(), testResult);
    }

    @DisplayName("Should pass transaction info service get by qrc id")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_getByQrcId(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndValue(any(), anyString(), any()))
                .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_INFO_SERVICE
                .getByQrcId(UUID.randomUUID().toString()).orElse(null);
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult);
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
                .findByKeyAndValue(any(), anyString(), any());
    }

    @DisplayName("Should pass transaction info service get by qrc id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactionInfos")
    void test_getByQrcIdWithEmpty(TransactionInfo txInfo) {
        final var testResult = TRANSACTION_INFO_SERVICE.getByQrcId(Optional.ofNullable(txInfo)
                .map(TransactionInfo::getValue).orElse(null)).orElse(null);;
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction info service get by msg id")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_getByMsgId(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndValue(any(), anyString(), any()))
                .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_INFO_SERVICE
                .getByMsgId(UUID.randomUUID().toString()).orElse(null);
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult);
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
                .findByKeyAndValue(any(), anyString(), any());
    }

    @DisplayName("Should pass transaction info service get by msg id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactionInfos")
    void test_getByMsgIdWithEmpty(TransactionInfo txInfo) {
        final var testResult = TRANSACTION_INFO_SERVICE.getByMsgId(Optional.ofNullable(txInfo)
                .map(TransactionInfo::getValue).orElse(null)).orElse(null);;
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction info service save")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_save(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.insertOrUpdate(txInfo)).thenReturn(txInfo);
        final var testResult = TRANSACTION_INFO_SERVICE.saveOrUpdateInfo(txInfo)
            .orElse(null);
        assertNotNull(testResult);
        assertEquals(txInfo, testResult);
        verify(TRANSACTION_INFO_REPOSITORY, times(1)).insertOrUpdate(txInfo);
    }

    @DisplayName("Should pass transaction info service save with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactionInfos")
    void test_saveWithEmpty(TransactionInfo txInfo) {
        final var testResult = TRANSACTION_INFO_SERVICE.saveOrUpdateInfo(txInfo)
                .map(TransactionInfo::getTransaction).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction info service get by key and state")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_getByKeyAndState(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndState(any(TransactionInfoKey.class),
                any(TransactionState.class), any()))
            .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_INFO_SERVICE
            .getByKeyAndState(txInfo.getKey(), txInfo.getTransaction().getState(),
                LocalDateTime.now(ZoneOffset.UTC));
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult.iterator().next().getTransaction());
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
            .findByKeyAndState(any(TransactionInfoKey.class), any(TransactionState.class), any());
    }

    @DisplayName("Should pass transaction info service get by key, value and state")
    @ParameterizedTest
    @MethodSource("provideTransactionInfos")
    void test_getByKeyAndValueAndState(TransactionInfo txInfo) {
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndValueAndState(any(TransactionInfoKey.class),
            anyString(), any(TransactionState.class), any()))
            .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_INFO_SERVICE
            .getByKeyAndValueAndState(txInfo.getKey(), txInfo.getValue(),
                txInfo.getTransaction().getState(), LocalDateTime.now(ZoneOffset.UTC));
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult.iterator().next().getTransaction());
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
            .findByKeyAndValueAndState(any(TransactionInfoKey.class), anyString(),
                any(TransactionState.class), any());
    }
}