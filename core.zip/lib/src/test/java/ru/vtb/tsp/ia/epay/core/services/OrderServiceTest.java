package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.repositories.OrderRepository;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionInfoRepository;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionRepository;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

@ExtendWith(MockitoExtension.class)
public class OrderServiceTest {

  static TransactionInfoRepository TRANSACTION_INFO_REPOSITORY;

  static TransactionInfoService TRANSACTION_INFO_SERVICE;

  static TransactionRepository TRANSACTION_REPOSITORY;

  static TransactionService TRANSACTION_SERVICE;

  static OrderRepository ORDER_REPOSITORY;

  static OrderService ORDER_SERVICE;

  static Stream<Arguments> provideOrders() {
    return Stream.of(Arguments.of(TestFactory.getOrder()));
  }

  static Stream<Arguments> provideOrdersAndTransactions() {
    final var order = TestFactory.getOrder();
    final var tx = TestFactory.getTransaction(order);
    return Stream.of(
        Arguments.of(order, null),
        Arguments.of(order, Collections.emptyList()),
        Arguments.of(order, Collections.singletonList(tx)));
  }

  static Stream<Arguments> provideEmptyOrders() {
    return Stream.of(null,
        Arguments.of(TestFactory.getEmptyOrder()));
  }

  @BeforeEach
  void init() {
    ORDER_REPOSITORY = Mockito.mock(OrderRepository.class);
    TRANSACTION_REPOSITORY = Mockito.mock(TransactionRepository.class);
    TRANSACTION_INFO_REPOSITORY = Mockito.mock(TransactionInfoRepository.class);
    TRANSACTION_INFO_SERVICE = new TransactionInfoService(TRANSACTION_INFO_REPOSITORY);
    TRANSACTION_SERVICE = new TransactionService(TRANSACTION_INFO_SERVICE, TRANSACTION_REPOSITORY);
    ORDER_SERVICE = new OrderService(ORDER_REPOSITORY, TRANSACTION_SERVICE);
  }

  @DisplayName("Should pass order service lock by code")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_lockByNumericCode(Order order) {
    when(ORDER_REPOSITORY.lockByCode(order.getCode())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.lockByCode(order.getCode()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).lockByCode(order.getCode());
  }

  @DisplayName("Should pass order service get by code")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_getByNumericCode(Order order) {
    when(ORDER_REPOSITORY.findByCode(order.getCode())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.getByCode(order.getCode()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).findByCode(order.getCode());
  }

  @DisplayName("Should pass order service lock by code with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_lockByNumericCodeWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.lockByCode(Optional.ofNullable(order)
        .map(Order::getCode).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service get by code with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_getByNumericCodeWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.getByCode(Optional.ofNullable(order)
        .map(Order::getCode).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service lock by mst order id")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_lockByMstOrderId(Order order) {
    when(ORDER_REPOSITORY.lockByMstOrderId(order.getMst().getId(),
        order.getMstOrderId())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.lockByMstOrderId(order.getMst().getId(),
        order.getMstOrderId()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).lockByMstOrderId(order.getMst().getId(),
        order.getMstOrderId());
  }

  @DisplayName("Should pass order service get by mst order id")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_getByMstOrderId(Order order) {
    when(ORDER_REPOSITORY.findByMstOrderId(order.getMst().getId(),
        order.getMstOrderId())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.getByMstOrderId(order.getMst().getId(),
        order.getMstOrderId()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).findByMstOrderId(order.getMst().getId(),
        order.getMstOrderId());
  }

  @DisplayName("Should pass order service lock by mst order id with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_lockByMstOrderIdWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.lockByMstOrderId(
        Optional.ofNullable(order).map(Order::getMst).map(MerchantSite::getId).orElse(null),
        Optional.ofNullable(order).map(Order::getMstOrderId).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service get by mst order id with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_getByMstOrderIdWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.getByMstOrderId(
        Optional.ofNullable(order).map(Order::getMst).map(MerchantSite::getId).orElse(null),
        Optional.ofNullable(order).map(Order::getMstOrderId).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service lock by id")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_lockById(Order order) {
    when(ORDER_REPOSITORY.lockById(order.getOrderId())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.lockById(order.getOrderId()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).lockById(order.getOrderId());
  }

  @DisplayName("Should pass order service get by id")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_getById(Order order) {
    when(ORDER_REPOSITORY.findById(order.getOrderId())).thenReturn(Optional.of(order));
    final var testResult = ORDER_SERVICE.getById(order.getOrderId()).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).findById(order.getOrderId());
  }

  @DisplayName("Should pass order service lock by id with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_lockByIdWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.lockById(Optional.ofNullable(order)
        .map(Order::getOrderId).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service get by id with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_getByIdWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.getById(Optional.ofNullable(order)
        .map(Order::getOrderId).orElse(null)).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service is exists by order id")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_isTransactionExistsById(Order order) {
    when(TRANSACTION_REPOSITORY.findByOrderId(order.getOrderId()))
        .thenReturn(Collections.singletonList(TestFactory.getTransaction(order)));
    assertTrue(ORDER_SERVICE.isTransactionExistsById(order.getOrderId()));
    verify(TRANSACTION_REPOSITORY, times(1)).findByOrderId(order.getOrderId());
  }

  @DisplayName("Should pass transaction service is exists by order id with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_isTransactionExistsByIdWithEmpty(Order order) {
    assertFalse(ORDER_SERVICE.isTransactionExistsById(Optional.ofNullable(order)
        .map(Order::getOrderId).orElse(null)));
  }

  @DisplayName("Should pass order service get by id")
  @ParameterizedTest
  @MethodSource("provideOrdersAndTransactions")
  void test_upsert(Order order, List<Transaction> transactions) {
    when(ORDER_REPOSITORY.saveOrUpdate(order)).thenReturn(order);
    when(TRANSACTION_REPOSITORY.findByOrderId(order.getOrderId()))
        .thenReturn(transactions);
    final var testResult = ORDER_SERVICE.upsert(order).orElse(null);
    assertNotNull(testResult);
    assertEquals(order, testResult);
    verify(ORDER_REPOSITORY, times(1)).saveOrUpdate(order);
  }

  @DisplayName("Should pass order service upsert with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_upsertWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.upsert(order).orElse(null);
    assertNull(testResult);
  }

  @DisplayName("Should pass order service create")
  @ParameterizedTest
  @MethodSource("provideOrders")
  void test_create(Order order) throws IllegalAccessException {
    final var testResult = ORDER_SERVICE.create(order.getCurrency(),
        order.getMst(),
        order.getMstOrderId(),
        order.getAmount(),
        order.getAmountHold(),
        order.getCreatedAt(),
        order.getAuthorizedAt(),
        order.getExpiredAt(),
        order.getOrderType(),
        order.getName(),
        order.getDescription(),
        order.getReturnUrl(),
        order.getAccount(),
        order.getBic(),
        order.getSourceSystem(),
        order.getBindingCategory(),
        order.getBindingType(),
        order.getBindingCode(),
        order.getMstCustomerId()
    ).orElse(null);
    final var excludeFields = List.of("orderId", "code", "changedAt");
    assertNotNull(testResult);
    final var expected = TestFactory.toMap(order, excludeFields);
    final var actual = TestFactory.toMap(testResult, excludeFields);
    assertEquals(expected, actual);
  }

  @DisplayName("Should pass order service upsert with null value")
  @ParameterizedTest
  @MethodSource("provideEmptyOrders")
  void test_createWithEmpty(Order order) {
    final var testResult = ORDER_SERVICE.create(
        Optional.ofNullable(order).map(Order::getCurrency).orElse(null),
        Optional.ofNullable(order).map(Order::getMst).orElse(null),
        Optional.ofNullable(order).map(Order::getMstOrderId).orElse(null),
        Optional.ofNullable(order).map(Order::getAmount).orElse(null),
        Optional.ofNullable(order).map(Order::getAmountHold).orElse(null),
        Optional.ofNullable(order).map(Order::getCreatedAt).orElse(null),
        Optional.ofNullable(order).map(Order::getAuthorizedAt).orElse(null),
        Optional.ofNullable(order).map(Order::getExpiredAt).orElse(null),
        Optional.ofNullable(order).map(Order::getOrderType).orElse(null),
        Optional.ofNullable(order).map(Order::getName).orElse(null),
        Optional.ofNullable(order).map(Order::getDescription).orElse(null),
        Optional.ofNullable(order).map(Order::getReturnUrl).orElse(null),
        Optional.ofNullable(order).map(Order::getAccount).orElse(null),
        Optional.ofNullable(order).map(Order::getBic).orElse(null),
        Optional.ofNullable(order).map(Order::getSourceSystem).orElse(null),
        Optional.ofNullable(order).map(Order::getBindingCategory).orElse(null),
        Optional.ofNullable(order).map(Order::getBindingType).orElse(null),
        Optional.ofNullable(order).map(Order::getBindingCode).orElse(null),
        Optional.ofNullable(order).map(Order::getMstCustomerId).orElse(null)
    ).orElse(null);
    assertNull(testResult);
  }

}