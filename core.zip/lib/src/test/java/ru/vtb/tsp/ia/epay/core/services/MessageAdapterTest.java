package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import ru.vtb.tsp.ia.epay.core.configurations.ObjectMapperConfiguration;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;

public class MessageAdapterTest {

  static ObjectMapper OBJECT_MAPPER;
  static MessageAdapter MESSAGE_ADAPTER;

  @BeforeAll
  static void init() {
    OBJECT_MAPPER = new ObjectMapperConfiguration().objectMapper();
    MESSAGE_ADAPTER = new MessageAdapter(new ObjectMapperConfiguration().objectMapper());
  }

  static Stream<Arguments> provideTransactionPayloadsForTransform() throws JsonProcessingException {
    final var payload = TestFactory.getTransactionPayload();
    final var payloadAsString = OBJECT_MAPPER.writeValueAsString(payload);
    return Stream.of(Arguments.of(null, null),
        Arguments.of(payload, payload),
        Arguments.of(payloadAsString, payload));
  }

  static Stream<Arguments> provideNotificationsForTransform() throws JsonProcessingException {
    final var notification = TestFactory.getNotification();
    final var payloadAsString = OBJECT_MAPPER.writeValueAsString(notification);
    return Stream.of(Arguments.of(null, null),
        Arguments.of(notification, notification),
        Arguments.of(payloadAsString, notification));
  }

  @DisplayName("Should pass message adapter deserializeTransaction when correct message")
  @ParameterizedTest
  @MethodSource("provideTransactionPayloadsForTransform")
  void test_transformPayload(Object message, TransactionPayload expected) {
    assertEquals(expected, MESSAGE_ADAPTER.deserializeTransactionPayload(message));
  }

  @DisplayName("Should pass message adapter deserializeNotification when correct message")
  @ParameterizedTest
  @MethodSource("provideNotificationsForTransform")
  void test_transform(Object message, Notification expected) {
    assertEquals(expected, MESSAGE_ADAPTER.deserializeNotification(message));
  }
}