package ru.vtb.tsp.ia.epay.core.entities.merchant.site;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

class MerchantSiteTest {

  static Stream<Arguments> provideCorrectMerchantSites() {
    return Stream.of(Arguments.of(TestFactory.getMerchantSite()),
        Arguments.of(TestFactory.getMerchantSite()),
        Arguments.of(TestFactory.getMerchantSite()));
  }

  @DisplayName("Should pass check merchant site is correct")
  @ParameterizedTest
  @MethodSource("provideCorrectMerchantSites")
  void test_isCorrectMerchantSite(MerchantSite merchantSite) {
    assertFalse(merchantSite.isEnableA2cTransfer());
    assertFalse(merchantSite.isEnableC2aTransfer());
    assertTrue(merchantSite.isEnableCardFlowThreeDS());
    assertTrue(merchantSite.isEnableCardPartialRefund());
    assertTrue(merchantSite.isEnableCardPayment());
    assertTrue(merchantSite.isEnableSbpPartialRefund());
    assertTrue(merchantSite.isEnableSbpPayment());
    assertTrue(merchantSite.isEnableTwoStagePayment());
    assertNotNull(merchantSite.getParams().getCardParams());
    assertEquals(merchantSite.getTerminalId(),
        merchantSite.getParams().getCardParams().getTerminalId());
    assertEquals(merchantSite.isEnableMirPayment(), merchantSite.getParams().getCardParams().isEnableMirPayment());
  }

}