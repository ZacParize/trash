package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.repositories.MerchantSiteRepository;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

@ExtendWith(MockitoExtension.class)
public class MerchantSiteServiceTest {

    static MerchantSiteRepository MERCHANT_SITE_REPOSITORY;

    static MerchantSiteService MERCHANT_SITE_SERVICE;

    static Stream<Arguments> provideMerchantSites() {
        return Stream.of(Arguments.of(TestFactory.getMerchantSite()));
    }

    static Stream<Arguments> provideEmptyMerchantSites() {
        return Stream.of(null,
                Arguments.of(TestFactory.getEmptyMerchantSite()));
    }

    @BeforeEach
    void init() {
        MERCHANT_SITE_REPOSITORY = Mockito.mock(MerchantSiteRepository.class);
        MERCHANT_SITE_SERVICE = new MerchantSiteService(MERCHANT_SITE_REPOSITORY);
    }

    @DisplayName("Should pass merchant site service get by login")
    @ParameterizedTest
    @MethodSource("provideMerchantSites")
    void test_getByLogin(MerchantSite mst) {
        when(MERCHANT_SITE_REPOSITORY.findByLogin(mst.getLogin())).thenReturn(Collections.singletonList(mst));
        final var testResult = MERCHANT_SITE_SERVICE.getByLogin(mst.getLogin());
        assertNotNull(testResult);
        assertIterableEquals(Collections.singletonList(mst), testResult);
        verify(MERCHANT_SITE_REPOSITORY, times(1)).findByLogin(mst.getLogin());
    }

    @DisplayName("Should pass merchant site service get by login with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyMerchantSites")
    void test_getByLoginWithEmpty(MerchantSite mst) {
        final var testResult = MERCHANT_SITE_SERVICE.getByLogin(Optional.ofNullable(mst)
                .map(MerchantSite::getLogin).orElse(null));
        assertNotNull(testResult);
        assertIterableEquals(Collections.emptyList(), testResult);
    }

    @DisplayName("Should pass merchant site service get by id")
    @ParameterizedTest
    @MethodSource("provideMerchantSites")
    void test_getById(MerchantSite mst) {
        final var optionalMst = Optional.of(mst);
        when(MERCHANT_SITE_REPOSITORY.findById(mst.getId())).thenReturn(optionalMst);
        final var testResult = MERCHANT_SITE_SERVICE.getById(mst.getId()).orElse(null);
        assertNotNull(testResult);
        assertEquals(mst, testResult);
        verify(MERCHANT_SITE_REPOSITORY, times(1)).findById(mst.getId());
    }

    @DisplayName("Should pass merchant site service get by id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyMerchantSites")
    void test_getByIdWithEmpty(MerchantSite mst) {
        final var testResult = MERCHANT_SITE_SERVICE.getById(Optional.ofNullable(mst)
                .map(MerchantSite::getId).orElse(null)).orElse(null);
        assertNull(testResult);
    }

}