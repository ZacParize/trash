package ru.vtb.tsp.ia.epay.core.entities.order;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

class OrderTest {

    static Stream<Arguments> provideTransferTypes() {
        return Stream.of(Arguments.of(OrderType.TRANSFER));
    }

    static Stream<Arguments> providePaymentTypes() {
        return Stream.of(Arguments.of(OrderType.PAYMENT));
    }

    static Stream<Arguments> provideCreatedStates() {
        return Stream.of(Arguments.of(OrderState.CREATED));
    }

    static Stream<Arguments> provideCompletedStates() {
        final var list = new ArrayList<Arguments>();
        OrderState.FINAL_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> providePartiallyRefundedStates() {
        return Stream.of(Arguments.of(OrderState.PARTIALLY_REFUNDED));
    }

    static Stream<Arguments> providePaidStates() {
        final var list = new ArrayList<Arguments>();
        OrderState.PAYED_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideRefundedStates() {
        final var list = new ArrayList<Arguments>();
        OrderState.REFUNDED_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideDeclinedStates() {
        final var list = new ArrayList<Arguments>();
        OrderState.DECLINED_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> providePayedTransactions() {
        final var list = new ArrayList<Transaction>();
        var transaction = TestFactory.getTransaction();
        transaction.setState(TransactionState.RECONCILED);
        var sum = BigDecimal.valueOf(transaction.getAmount());
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setState(TransactionState.CONFIRMED);
        sum = sum.add(BigDecimal.valueOf(transaction.getAmount()));
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.SBP_REFUND);
        transaction.setState(TransactionState.RECONCILED);
        return Stream.of(Arguments.of(sum.doubleValue(), list));
    }

    static Stream<Arguments> provideRefundedTransactions() {
        final var list = new ArrayList<Transaction>();
        var transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.SBP_REFUND);
        transaction.setState(TransactionState.RECONCILED);
        var sum = BigDecimal.valueOf(transaction.getAmount());
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_REFUND);
        transaction.setState(TransactionState.CONFIRMED);
        sum = sum.add(BigDecimal.valueOf(transaction.getAmount()));
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setState(TransactionState.RECONCILED);
        return Stream.of(Arguments.of(sum.doubleValue(), list));
    }

    static Stream<Arguments> provideReversedTransactions() {
        final var list = new ArrayList<Transaction>();
        var transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT_TWO_STAGE);
        transaction.setState(TransactionState.REVERSED);
        var sum = BigDecimal.valueOf(transaction.getAmountHold());
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_REFUND);
        transaction.setState(TransactionState.CONFIRMED);
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT);
        transaction.setState(TransactionState.RECONCILED);
        return Stream.of(Arguments.of(sum.doubleValue(), list));
    }

    static Stream<Arguments> provideAuthorizedTransactions() {
        final var list = new ArrayList<Transaction>();
        var transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT_TWO_STAGE);
        transaction.setState(TransactionState.AUTHORIZED);
        var sum = BigDecimal.valueOf(transaction.getAmountHold());
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_REFUND);
        transaction.setState(TransactionState.CONFIRMED);
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT);
        transaction.setState(TransactionState.RECONCILED);
        return Stream.of(Arguments.of(sum.doubleValue(), list));
    }

    static Stream<Arguments> provideConfirmedTransactions() {
        final var list = new ArrayList<Transaction>();
        var transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT_TWO_STAGE);
        transaction.setState(TransactionState.CONFIRMED);
        var sum = BigDecimal.valueOf(transaction.getAmount());
        list.add(transaction);
        transaction = TestFactory.getTransaction();
        transaction.setType(TransactionType.CARD_PAYMENT);
        transaction.setState(TransactionState.RECONCILED);
        return Stream.of(Arguments.of(sum.doubleValue(), list));
    }

    @DisplayName("Should pass check order is transfer")
    @ParameterizedTest
    @MethodSource("provideTransferTypes")
    void test_isTransfer(OrderType type) {
        assertTrue(Order.builder().orderType(type).build().isTransfer());
    }

    @DisplayName("Should pass check order is payment")
    @ParameterizedTest
    @MethodSource("providePaymentTypes")
    void test_isPayment(OrderType type) {
        assertTrue(Order.builder().orderType(type).build().isPayment());
    }

    @DisplayName("Should pass check order is created")
    @ParameterizedTest
    @MethodSource("provideCreatedStates")
    void test_isCreated(OrderState state) {
        assertTrue(Order.builder().state(state).build().isCreated());
    }

    @DisplayName("Should pass check order is in final states")
    @ParameterizedTest
    @MethodSource("provideCompletedStates")
    void test_isCompleted(OrderState state) {
        assertTrue(Order.builder().state(state).build().isCompleted());
    }

    @DisplayName("Should pass check order is partially refunded")
    @ParameterizedTest
    @MethodSource("providePartiallyRefundedStates")
    void test_isPartiallyRefunded(OrderState state) {
        assertTrue(Order.builder().state(state).build().isPartiallyRefunded());
    }

    @DisplayName("Should pass check order is paid")
    @ParameterizedTest
    @MethodSource("providePaidStates")
    void test_isPaid(OrderState state) {
        assertTrue(Order.builder().state(state).build().isPaid());
    }

    @DisplayName("Should pass check order is refunded")
    @ParameterizedTest
    @MethodSource("provideRefundedStates")
    void test_isRefunded(OrderState state) {
        assertTrue(Order.builder().state(state).build().isRefunded());
    }

    @DisplayName("Should pass check order is in declined states")
    @ParameterizedTest
    @MethodSource("provideDeclinedStates")
    void test_isDeclined(OrderState state) {
        assertTrue(Order.builder().state(state).build().isDeclined());
    }

    @DisplayName("Should pass check order calculate payed amount")
    @ParameterizedTest
    @MethodSource("providePayedTransactions")
    void test_calculatePayedAmount(double ideal, List<Transaction> transactions) {
        assertEquals(ideal, Order.calculatePayedAmount(transactions));
        assertEquals(ideal, Order.calculatePayedAmount(transactions, null));
        assertEquals(ideal, Order.calculatePayedAmount(transactions,
            Collections.singletonList(TestFactory.getTransaction())));
        assertEquals(0d, Order.calculateRemainingPayAmount(ideal, transactions));
    }

    @DisplayName("Should pass check order calculate payed amount")
    @ParameterizedTest
    @MethodSource("provideRefundedTransactions")
    void test_calculateRefundedAmount(double ideal, List<Transaction> transactions) {
        assertEquals(ideal, Order.calculateRefundedAmount(transactions));
        assertEquals(ideal, Order.calculateRefundedAmount(transactions, null));
        assertEquals(ideal, Order.calculateRefundedAmount(transactions,
            Collections.singletonList(TestFactory.getTransaction())));
        assertEquals(0d, Order.calculateRemainingRefundAmount(ideal, transactions));
    }

    @DisplayName("Should pass check order calculate reversed amount")
    @ParameterizedTest
    @MethodSource("provideReversedTransactions")
    void test_calculateReversedAmount(double ideal, List<Transaction> transactions) {
        assertEquals(ideal, Order.calculateReversedAmount(transactions));
        assertEquals(ideal, Order.calculateReversedAmount(transactions, null));
        assertEquals(ideal, Order.calculateReversedAmount(transactions,
            Collections.singletonList(TestFactory.getTransaction())));
    }

    @DisplayName("Should pass check order calculate authorized amount")
    @ParameterizedTest
    @MethodSource("provideAuthorizedTransactions")
    void test_calculateAuthorizedAmount(double ideal, List<Transaction> transactions) {
        assertEquals(ideal, Order.calculateAuthorizedAmount(transactions));
        assertEquals(ideal, Order.calculateAuthorizedAmount(transactions, null));
        assertEquals(ideal, Order.calculateAuthorizedAmount(transactions,
            Collections.singletonList(TestFactory.getTransaction())));
    }

    @DisplayName("Should pass check order calculate confirmed amount")
    @ParameterizedTest
    @MethodSource("provideConfirmedTransactions")
    void test_calculateConfirmedAmount(double ideal, List<Transaction> transactions) {
        assertEquals(ideal, Order.calculatePayedAmount(transactions));
        assertEquals(ideal, Order.calculatePayedAmount(transactions, null));
        assertEquals(ideal, Order.calculatePayedAmount(transactions,
            Collections.singletonList(TestFactory.getTransaction())));
    }

}