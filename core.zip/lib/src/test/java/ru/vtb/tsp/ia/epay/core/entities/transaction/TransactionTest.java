package ru.vtb.tsp.ia.epay.core.entities.transaction;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class TransactionTest {

    static Stream<Arguments> provideCardPaymentTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.CARD_PAYMENT_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideSbpPaymentTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.SBP_PAYMENT_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> providePaymentTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.PAYMENT_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideSbpRefundTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.SBP_REFUND_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideCardRefundTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.CARD_REFUND_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideRefundTypes() {
        final var list = new ArrayList<Arguments>();
        TransactionType.REFUND_TYPES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideProcessingStates() {
        final var list = new ArrayList<Arguments>();
        TransactionState.PROCESSING_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> providePayedTypesAndStates() {
        final var list = new ArrayList<Arguments>();
        TransactionState.PAYED_STATES.forEach(state ->
                TransactionType.PAYMENT_TYPES.forEach(type -> list.add(Arguments.of(type, state))));
        return list.stream();
    }

    static Stream<Arguments> provideDeclinedStates() {
        final var list = new ArrayList<Arguments>();
        TransactionState.DECLINED_STATES.forEach(state -> list.add(Arguments.of(state)));
        return list.stream();
    }

    static Stream<Arguments> provideCompletedTypesAndStates() {
        final var list = new ArrayList<Arguments>();
        TransactionState.FINAL_STATES.forEach(state ->
                TransactionType.PAYMENT_TYPES.forEach(type -> list.add(Arguments.of(type, state))));
        return list.stream();
    }

    @DisplayName("Should pass check transaction is in card payment types")
    @ParameterizedTest
    @MethodSource("provideCardPaymentTypes")
    void test_isCardPayment(TransactionType type) {
        assertTrue(Transaction.builder().type(type).build().isCardPayment());
    }

    @DisplayName("Should pass check transaction is in sbp payment types")
    @ParameterizedTest
    @MethodSource("provideSbpPaymentTypes")
    void test_isSbpPayment(TransactionType type) {
        assertTrue(Transaction.builder().type(type).build().isSbpPayment());
    }

    @DisplayName("Should pass check transaction is in payment types")
    @ParameterizedTest
    @MethodSource("providePaymentTypes")
    void test_isPayment(TransactionType type) {
        final var transaction = Transaction.builder().type(type).build();
        assertTrue(transaction.isPayment());
        assertTrue(transaction.isCardPayment()
            || transaction.isSbpPayment()
            || transaction.isMirPayPayment());
    }

    @DisplayName("Should pass check transaction is in sbp refund types")
    @ParameterizedTest
    @MethodSource("provideSbpRefundTypes")
    void test_isSbpRefund(TransactionType type) {
        assertTrue(Transaction.builder().type(type).build().isSbpRefund());
    }

    @DisplayName("Should pass check transaction is in card refund types")
    @ParameterizedTest
    @MethodSource("provideCardRefundTypes")
    void test_isCardRefund(TransactionType type) {
        assertTrue(Transaction.builder().type(type).build().isCardRefund());
    }

    @DisplayName("Should pass check transaction is in refund types")
    @ParameterizedTest
    @MethodSource("provideRefundTypes")
    void test_isRefund(TransactionType type) {
        final var transaction = Transaction.builder().type(type).build();
        assertTrue(transaction.isRefund());
        assertTrue(transaction.isCardRefund() || transaction.isSbpRefund() || transaction.isMirPayRefund());
    }

    @DisplayName("Should pass check transaction is in processing states")
    @ParameterizedTest
    @MethodSource("provideProcessingStates")
    void test_isProcessing(TransactionState state) {
        assertTrue(Transaction.builder().state(state).build().isProcessing());
    }

    @DisplayName("Should pass check transaction is in payed states")
    @ParameterizedTest
    @MethodSource("providePayedTypesAndStates")
    void test_isPaid(TransactionType type, TransactionState state) {
        assertTrue(Transaction.builder().type(type).state(state).build().isPaid());
    }

    @DisplayName("Should pass check transaction is in declined states")
    @ParameterizedTest
    @MethodSource("provideDeclinedStates")
    void test_isDeclined(TransactionState state) {
        assertTrue(Transaction.builder().state(state).build().isDeclined());
    }

    @DisplayName("Should pass check transaction is in completed states")
    @ParameterizedTest
    @MethodSource("provideCompletedTypesAndStates")
    void test_isCompleted(TransactionType type, TransactionState state) {
        final var transaction = Transaction.builder().type(type).state(state).build();
        assertTrue(transaction.isCompleted());
        assertTrue(transaction.isDeclined() || transaction.isPaid());
    }

}