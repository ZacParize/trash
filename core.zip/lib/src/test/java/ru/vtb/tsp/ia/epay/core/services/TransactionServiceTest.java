package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertIterableEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionInfoRepository;
import ru.vtb.tsp.ia.epay.core.repositories.TransactionRepository;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

@ExtendWith(MockitoExtension.class)
public class TransactionServiceTest {

    static TransactionInfoRepository TRANSACTION_INFO_REPOSITORY;

    static TransactionInfoService TRANSACTION_INFO_SERVICE;

    static TransactionRepository TRANSACTION_REPOSITORY;

    static TransactionService TRANSACTION_SERVICE;

    static Stream<Arguments> provideTransactions() {
        return Stream.of(Arguments.of(TestFactory.getTransaction(TestFactory.getOrder())));
    }

    static Stream<Arguments> provideEmptyTransactions() {
        return Stream.of(null, Arguments.of(TestFactory.getEmptyTransaction()));
    }

    static Stream<Arguments> provideTransactionsAndTransactionInfos() {
        return Stream.of(
                Arguments.of(TestFactory.getTransaction(TestFactory.getOrder()),
                        Collections.singletonList(TestFactory.getTransactionInfo())));
    }

    static Stream<Arguments> provideEmptyOrdersAndEmptyTransactions() {
        return Stream.of(
                Arguments.of(null, null),
                Arguments.of(TestFactory.getEmptyTransaction(), Collections.emptyList()),
                Arguments.of(TestFactory.getTransaction(TestFactory.getOrder()),
                        Collections.singletonList(TestFactory.getEmptyTransactionInfo())));
    }

    @BeforeEach
    void init() {
        TRANSACTION_REPOSITORY = Mockito.mock(TransactionRepository.class);
        TRANSACTION_INFO_REPOSITORY = Mockito.mock(TransactionInfoRepository.class);
        TRANSACTION_INFO_SERVICE = new TransactionInfoService(TRANSACTION_INFO_REPOSITORY);
        TRANSACTION_SERVICE = new TransactionService(TRANSACTION_INFO_SERVICE,
            TRANSACTION_REPOSITORY);
    }

    @DisplayName("Should pass transaction service lock by code")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_lockByCode(Transaction tx) {
        when(TRANSACTION_REPOSITORY.lockByCode(tx.getCode())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.lockByCode(tx.getCode()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).lockByCode(tx.getCode());
    }

    @DisplayName("Should pass transaction service get by code")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByCode(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByCode(tx.getCode())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.getByCode(tx.getCode()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).findByCode(tx.getCode());
    }

    @DisplayName("Should pass transaction service lock by code with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_lockByCodeWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.lockByCode(Optional.ofNullable(tx)
            .map(Transaction::getCode).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service get by code with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByCodeWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getByCode(Optional.ofNullable(tx)
                .map(Transaction::getCode).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service lock by id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_lockById(Transaction tx) {
        when(TRANSACTION_REPOSITORY.lockById(tx.getTransactionId())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.lockById(tx.getTransactionId()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).lockById(tx.getTransactionId());
    }

    @DisplayName("Should pass transaction service get by id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getById(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findById(tx.getTransactionId())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.getById(tx.getTransactionId()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).findById(tx.getTransactionId());
    }

    @DisplayName("Should pass transaction service lock by id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_lockByIdWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.lockById(
            Optional.ofNullable(tx).map(Transaction::getTransactionId).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service get by id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByIdWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getById(
                Optional.ofNullable(tx).map(Transaction::getTransactionId).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service get by state")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByState(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByState(tx.getState(), tx.getCreatedAt()))
            .thenReturn(Collections.singletonList(tx));
        final var testResult = TRANSACTION_SERVICE.getByState(
            tx.getState(),
            tx.getCreatedAt());
        assertNotNull(testResult);
        assertIterableEquals(Collections.singletonList(tx), testResult);
        verify(TRANSACTION_REPOSITORY, times(1))
            .findByState(tx.getState(), tx.getCreatedAt());
    }

    @DisplayName("Should pass transaction service get by state and type")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByStateAndType(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByStateAndType(tx.getState(), tx.getType(), tx.getCreatedAt()))
            .thenReturn(Collections.singletonList(tx));
        final var testResult = TRANSACTION_SERVICE.getByStateAndType(
            tx.getState(),
            tx.getType(),
            tx.getCreatedAt());
        assertNotNull(testResult);
        assertIterableEquals(Collections.singletonList(tx), testResult);
        verify(TRANSACTION_REPOSITORY, times(1))
            .findByStateAndType(tx.getState(), tx.getType(), tx.getCreatedAt());
    }

    @DisplayName("Should pass transaction service get by state with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByStateWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getByState(
            Optional.ofNullable(tx).map(Transaction::getState).orElse(null),
            Optional.ofNullable(tx).map(Transaction::getCreatedAt).orElse(null));
        assertNotNull(testResult);
        assertIterableEquals(Collections.emptyList(), testResult);
    }

    @DisplayName("Should pass transaction service get by state and type with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByStateAndTypeWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getByStateAndType(
            Optional.ofNullable(tx).map(Transaction::getState).orElse(null),
            Optional.ofNullable(tx).map(Transaction::getType).orElse(null),
            Optional.ofNullable(tx).map(Transaction::getCreatedAt).orElse(null));
        assertNotNull(testResult);
        assertIterableEquals(Collections.emptyList(), testResult);
    }

    @DisplayName("Should pass transaction service lock by mst order id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_lockByMstTransactionId(Transaction tx) {
        when(TRANSACTION_REPOSITORY.lockByMstTransactionId(tx.getMst().getId(),
            tx.getMstTransactionId())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.lockByMstTransactionId(tx.getMst().getId(),
            tx.getMstTransactionId()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).lockByMstTransactionId(tx.getMst().getId(),
            tx.getMstTransactionId());
    }

    @DisplayName("Should pass transaction service get by mst order id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByMstTransactionId(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByMstTransactionId(tx.getMst().getId(),
                tx.getMstTransactionId())).thenReturn(Optional.of(tx));
        final var testResult = TRANSACTION_SERVICE.getByMstTransactionId(tx.getMst().getId(),
                tx.getMstTransactionId()).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).findByMstTransactionId(tx.getMst().getId(),
                tx.getMstTransactionId());
    }

    @DisplayName("Should pass transaction service lock by mst order id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_lockByMstTransactionIdWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.lockByMstTransactionId(
            Optional.ofNullable(tx).map(Transaction::getMst).map(MerchantSite::getId).orElse(null),
            Optional.ofNullable(tx).map(Transaction::getMstTransactionId).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service get by mst order id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByMstTransactionIdWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getByMstTransactionId(
                Optional.ofNullable(tx).map(Transaction::getMst).map(MerchantSite::getId).orElse(null),
                Optional.ofNullable(tx).map(Transaction::getMstTransactionId).orElse(null)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service upsert")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_upsert(Transaction tx) {
        when(TRANSACTION_REPOSITORY.saveOrUpdate(tx)).thenReturn(tx);
        final var testResult = TRANSACTION_SERVICE.upsert(tx).orElse(null);
        assertNotNull(testResult);
        assertEquals(tx, testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).saveOrUpdate(tx);
    }

    @DisplayName("Should pass transaction service upsert with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_upsertWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.upsert(tx)
                .map(Transaction::getTransactionId).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass transaction service updateDataById")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_updateDataById(Transaction tx) {
        when(TRANSACTION_REPOSITORY.updateDataById(tx.getTransactionId(), tx.getData())).thenReturn(true);
        final var testResult = TRANSACTION_SERVICE.updateDataById(tx);
        assertTrue(testResult);
        verify(TRANSACTION_REPOSITORY, times(1))
                .updateDataById(tx.getTransactionId(), tx.getData());
    }

    @DisplayName("Should pass transaction service updateDataById with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_updateDataByIdWithEmpty(Transaction tx) {
        assertFalse(TRANSACTION_SERVICE.updateDataById(tx));
    }

    @DisplayName("Should pass transaction service get by order id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByOrderId(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByOrderId(tx.getOrder().getOrderId())).thenReturn(Collections.singletonList(tx));
        final var testResult = TRANSACTION_SERVICE.getByOrderId(tx.getOrder().getOrderId());
        assertNotNull(testResult);
        assertIterableEquals(Collections.singletonList(tx), testResult);
        verify(TRANSACTION_REPOSITORY, times(1)).findByOrderId(tx.getOrder().getOrderId());
    }

    @DisplayName("Should pass transaction service get by order id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_getByOrderIdWithEmpty(Transaction tx) {
        final var testResult = TRANSACTION_SERVICE.getByOrderId(
                Optional.ofNullable(tx).map(Transaction::getOrder).map(Order::getOrderId).orElse(null));
        assertNotNull(testResult);
        assertIterableEquals(Collections.emptyList(), testResult);
    }

    @DisplayName("Should pass transaction service is exists by order id")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_isExistsByOrderId(Transaction tx) {
        when(TRANSACTION_REPOSITORY.findByOrderId(tx.getOrder().getOrderId())).thenReturn(Collections.singletonList(tx));
        assertTrue(TRANSACTION_SERVICE.isExistsByOrderId(tx.getOrder().getOrderId()));
        verify(TRANSACTION_REPOSITORY, times(1)).findByOrderId(tx.getOrder().getOrderId());
    }

    @DisplayName("Should pass transaction service is exists by order id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyTransactions")
    void test_isExistsByOrderIdWithEmpty(Transaction tx) {
        assertFalse(TRANSACTION_SERVICE.isExistsByOrderId(Optional.ofNullable(tx)
                .map(Transaction::getOrder).map(Order::getOrderId).orElse(null)));
    }

    @DisplayName("Should pass transaction service get with qrc by order id")
    @ParameterizedTest
    @MethodSource("provideTransactionsAndTransactionInfos")
    void test_getWithQrcByOrderId(Transaction tx, List<TransactionInfo> txInfos) {
        when(TRANSACTION_REPOSITORY.findByOrderId(tx.getOrder().getOrderId()))
                .thenReturn(Collections.singletonList(tx));
        when(TRANSACTION_INFO_REPOSITORY.findByTransactionId(tx.getTransactionId())).thenReturn(txInfos);
        final var testResult = TRANSACTION_SERVICE.getWithQrcByOrderId(tx.getOrder().getOrderId());
        assertFalse(testResult.isEmpty());
        assertEquals(tx, testResult.iterator().next());
        verify(TRANSACTION_REPOSITORY, times(1)).findByOrderId(tx.getOrder().getOrderId());
    }

    @DisplayName("Should pass transaction service get with qrc by order id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyOrdersAndEmptyTransactions")
    void test_getWithQrcByOrderIdWithEmpty(Transaction tx, List<TransactionInfo> txInfos) {
        final var testResult = TRANSACTION_SERVICE.getWithQrcByOrderId(Optional.ofNullable(tx)
                        .map(Transaction::getOrder).map(Order::getOrderId).orElse(null));
        assertTrue(testResult.isEmpty());
    }

    @DisplayName("Should pass transaction service create mir pay payment")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createMirPayPayment(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "flow", "createdAt", "transactionId", "mstTransactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createMirPayPayment(tx.getOrder())
            .orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isMirPayPayment());
        assertEquals(TransactionType.MIR_PAYMENT_WEB_BASED, testResult.getType());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create mir pay refund")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createMirPayRefund(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "flow", "createdAt", "transactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createMirPayRefund(tx.getOrder(), tx.getMstTransactionId()).orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isMirPayRefund());
        assertEquals(testResult.getType(), TransactionType.MIR_PAYMENT_WEB_BASED_REFUND);
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create mir pay partial refund")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createPartialMirPayRefund(Transaction tx) throws IllegalAccessException {
        final var refundAmount = 100d;
        final var excludeFields = List.of("amount", "code", "data", "flow", "createdAt", "transactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createPartialMirPayRefund(tx.getOrder(),
            refundAmount, tx.getMstTransactionId()).orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isMirPayRefund());
        assertEquals(testResult.getType(), TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND);
        assertEquals(testResult.getAmount(), refundAmount);
        assertEquals(actual, expected);
    }


    @DisplayName("Should pass transaction service create sbp payment")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createSbpPayment(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "mstTransactionId",
                "flow", "createdAt", "transactionId");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createSbpPayment(tx.getOrder())
            .orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isSbpPayment());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create sbp refund")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createSbpRefund(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "flow", "createdAt", "transactionId", "type");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createSbpRefund(tx.getOrder(),
                tx.getAmount(), tx.getCurrency(), tx.getMstTransactionId()).orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isSbpRefund());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create card payment transaction")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createCardPayment(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data",
                "flow", "createdAt", "transactionId", "mstTransactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createCardPayment(tx.getOrder())
            .orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isCardPayment());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create card refund")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createCardRefund(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "flow", "createdAt", "transactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createCardRefund(tx.getOrder(),
                tx.getAmount(), tx.getCurrency(), tx.getMstTransactionId()).orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isCardRefund());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service create partial card refund")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    @SuppressWarnings("ConstantConditions")
    void test_createPartialCardRefund(Transaction tx) throws IllegalAccessException {
        final var excludeFields = List.of("code", "data", "flow", "createdAt",
            "transactionId", "type", "version");
        final var actual = TestFactory.toMap(tx, excludeFields);
        final var testResult = TRANSACTION_SERVICE.createPartialCardRefund(tx.getOrder(),
                tx.getAmount(), tx.getCurrency(), tx.getMstTransactionId()).orElse(null);
        final var expected = TestFactory.toMap(testResult, excludeFields);
        assertTrue(testResult.isCardRefund());
        assertEquals(actual, expected);
    }

    @DisplayName("Should pass transaction service get by key and state")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByKeyAndState(Transaction tx) {
        final var txInfo = TransactionInfo.builder()
            .key(TransactionInfoKey.SBP_QR_ID)
            .value(UUID.randomUUID().toString())
            .createdAt(LocalDateTime.now(ZoneOffset.UTC))
            .transactionInfoId(new Random().nextLong())
            .transaction(tx)
            .build();
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndState(any(TransactionInfoKey.class),
            any(TransactionState.class), any()))
            .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_SERVICE
            .getByKeyAndState(txInfo.getKey(), txInfo.getTransaction().getState(),
                LocalDateTime.now(ZoneOffset.UTC));
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult.iterator().next());
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
            .findByKeyAndState(any(TransactionInfoKey.class), any(TransactionState.class), any());
    }

    @DisplayName("Should pass transaction service get by key, value and state")
    @ParameterizedTest
    @MethodSource("provideTransactions")
    void test_getByKeyAndValueAndState(Transaction tx) {
        final var txInfo = TransactionInfo.builder()
            .key(TransactionInfoKey.SBP_QR_ID)
            .value(UUID.randomUUID().toString())
            .createdAt(LocalDateTime.now(ZoneOffset.UTC))
            .transactionInfoId(new Random().nextLong())
            .transaction(tx)
            .build();
        when(TRANSACTION_INFO_REPOSITORY.findByKeyAndValueAndState(any(TransactionInfoKey.class),
            anyString(), any(TransactionState.class), any()))
            .thenReturn(Collections.singletonList(txInfo));
        final var testResult = TRANSACTION_SERVICE
            .getByKeyAndValueAndState(txInfo.getKey(), txInfo.getValue(),
                txInfo.getTransaction().getState(), LocalDateTime.now(ZoneOffset.UTC));
        assertNotNull(testResult);
        assertEquals(txInfo.getTransaction(), testResult.iterator().next());
        verify(TRANSACTION_INFO_REPOSITORY, times(1))
            .findByKeyAndValueAndState(any(TransactionInfoKey.class), anyString(),
                any(TransactionState.class), any());
    }
}