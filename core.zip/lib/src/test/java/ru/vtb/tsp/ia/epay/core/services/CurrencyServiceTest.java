package ru.vtb.tsp.ia.epay.core.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.repositories.CurrencyRepository;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;

@ExtendWith(MockitoExtension.class)
public class CurrencyServiceTest {

    static CurrencyRepository CURRENCY_REPOSITORY;

    static CurrencyService CURRENCY_SERVICE;

    static Stream<Arguments> provideCurrencies() {
        return Stream.of(Arguments.of(TestFactory.getCurrency()));
    }

    static Stream<Arguments> provideEmptyCurrencies() {
        return Stream.of(null,
                Arguments.of(TestFactory.getEmptyCurrency()));
    }

    @BeforeEach
    void init() {
        CURRENCY_REPOSITORY = Mockito.mock(CurrencyRepository.class);
        CURRENCY_SERVICE = new CurrencyService(CURRENCY_REPOSITORY);
    }

    @DisplayName("Should pass currency service get by numeric code")
    @ParameterizedTest
    @MethodSource("provideCurrencies")
    void test_getByNumericCode(Currency currency) {
        when(CURRENCY_REPOSITORY.findByNumericCode(currency.getNumericCode())).thenReturn(Optional.of(currency));
        final var testResult = CURRENCY_SERVICE.getByNumericCode(currency.getNumericCode()).orElse(null);
        assertNotNull(testResult);
        assertEquals(currency, testResult);
        verify(CURRENCY_REPOSITORY, times(1)).findByNumericCode(currency.getNumericCode());
    }

    @DisplayName("Should pass currency service get by numeric code with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyCurrencies")
    void test_getByNumericCodeWithEmpty(Currency currency) {
        final var testResult = CURRENCY_SERVICE.getByNumericCode(Optional.ofNullable(currency)
                .map(Currency::getNumericCode).orElse(0)).orElse(null);
        assertNull(testResult);
    }

    @DisplayName("Should pass currency service get by id")
    @ParameterizedTest
    @MethodSource("provideCurrencies")
    void test_getById(Currency currency) {
        final var optionalCurrency = Optional.of(currency);
        when(CURRENCY_REPOSITORY.findById(currency.getCode())).thenReturn(optionalCurrency);
        final var testResult = CURRENCY_SERVICE.getById(currency.getCode()).orElse(null);
        assertNotNull(testResult);
        assertEquals(currency, testResult);
        verify(CURRENCY_REPOSITORY, times(1)).findById(currency.getCode());
    }

    @DisplayName("Should pass currency service get by id with null value")
    @ParameterizedTest
    @MethodSource("provideEmptyCurrencies")
    void test_getByIdWithEmpty(Currency currency) {
        final var testResult = CURRENCY_SERVICE.getById(Optional.ofNullable(currency)
                .map(Currency::getCode).orElse(null)).orElse(null);
        assertNull(testResult);
    }

}