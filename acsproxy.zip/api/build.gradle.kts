plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot").version("2.4.4")
}

apply(plugin = "io.spring.dependency-management")

java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

repositories {
    repositories {
        maven {
            url = uri(extra["nexus.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

dependencies {

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305:3.0.2")
    implementation("com.fasterxml.jackson.core:jackson-databind")

    //swagger2
    //implementation("io.springfox:springfox-boot-starter:3.0.0")

    //swagger open api 3.0
    implementation("org.springdoc:springdoc-openapi-ui:1.5.13")
    implementation("io.swagger.core.v3:swagger-annotations:2.1.11")

    // Validation
    implementation("javax.validation:validation-api:2.0.1.Final")
    implementation("commons-validator:commons-validator:1.7")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString() + "-api"
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }
    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    enabled = true
}

tasks.bootJar {
    // Set bootJar file name
    enabled = false
}