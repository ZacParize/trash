package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThreeDSDecisionCallbackDto implements Serializable {

    @JsonProperty("browserColorDepth")
    Integer browserColorDepth;

    @JsonProperty("browserLanguage")
    String browserLanguage;

    @JsonProperty("browserScreenHeight")
    Integer browserScreenHeight;

    @JsonProperty("browserScreenWidth")
    Integer browserScreenWidth;

    @JsonProperty("windowWidth")
    Integer windowWidth;

    @JsonProperty("windowHeight")
    Integer windowHeight;

    @JsonProperty("browserTZ")
    String browserTZ;

    @JsonProperty("browserJavaEnabled")
    Boolean browserJavaEnabled;

    @JsonProperty("browserIp")
    String browserIp;

    @JsonProperty("browserUserAgent")
    String browserUserAgent;

    @JsonProperty("accept")
    String accept;

    @JsonProperty("initiator")
    String initiator;
}