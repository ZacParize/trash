package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@EqualsAndHashCode(callSuper = false)
public class ThreeDSParesCallbackDto extends AbstractMessageWithPayload implements Serializable {
  @JsonProperty("pares")
  private String pares;
  @JsonProperty("md")
  private String md;
  @JsonProperty("isValid")
  private boolean isValid;
  @Override
  public String getPayload() {
    return pares;
  }
  @Override
  public void setPayload(String value) {
    this.pares=value;
  }
  @Override
  public void setIsValid(boolean value) {
    this.isValid=value;
  }

  @Override
  public boolean getIsValid() {
    return isValid;
  }

}
