package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThreeDSMethodCallbackDto extends AbstractMessageWithPayload implements Serializable {

  @JsonProperty("threeDSMethodData")
  private String threeDSMethodData;

  @JsonProperty("isValid")
  private boolean isValid;


  @Override
  public void setPayload(String value) {
    this.threeDSMethodData = value;
  }

  @Override
  public String getPayload() {
    return threeDSMethodData;
  }

  @Override
  public void setIsValid(boolean value) {
    this.isValid = value;
  }

  @Override
  public boolean getIsValid() {
    return this.isValid;
  }


  @Override
  public String getThreeDSSessionData() {
    return null;
  }

  @Override
  public String getMd() {
    return null;
  }

}