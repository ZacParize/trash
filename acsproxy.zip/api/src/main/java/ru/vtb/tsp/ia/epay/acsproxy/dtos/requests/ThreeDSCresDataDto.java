package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThreeDSCresDataDto implements PayloadWithThreeDSServerTransId, PayloadWithThreeDSSessionData, Serializable {

  @JsonProperty("threeDSServerTransID")
  private String threeDSServerTransID;

  @JsonProperty("threeDSSessionData")
  private String threeDSSessionData;

  @JsonProperty("isValid")
  private boolean isValid;

}