package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

public interface PayloadWithThreeDSServerTransId {

  String getThreeDSServerTransID();

}