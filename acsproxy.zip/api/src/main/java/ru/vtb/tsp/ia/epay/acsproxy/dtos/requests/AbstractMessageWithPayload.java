package ru.vtb.tsp.ia.epay.acsproxy.dtos.requests;

public  abstract class AbstractMessageWithPayload implements MessageWithPayload{
  public abstract void setPayload(String value);
  public abstract String getPayload();
  public abstract void setIsValid(boolean value);
  public abstract boolean getIsValid();
  public String getThreeDSSessionData(){
    return null;
  }
  public String getMd(){
    return null;
  }
}
