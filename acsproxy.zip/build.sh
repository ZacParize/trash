#!/bin/bash
function ComponentBuild() {
  gradle clean -i bootJar bootWar ${GRADLE_CLI_OPTIONS} -p "${1}"
}
"$@"