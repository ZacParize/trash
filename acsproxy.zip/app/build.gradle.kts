plugins {
    idea
    base
    java
    application
    war
    `maven-publish`
    checkstyle
    id("org.springframework.boot").version("2.4.4")
    id("org.sonarqube") version "3.3"
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")
apply(plugin = "io.spring.dependency-management")

val toolDir = "${project.buildDir}/tools"
val toolDependency by configurations.compileOnly
toolDependency.isCanBeResolved = true

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
    }
    all {
        resolutionStrategy.eachDependency {
            if (this.requested.group.equals("com.fasterxml.jackson.core")) {
                this.useVersion("2.12.4")
            }
        }
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencies {

    implementation(project(":api"))
    //Monitoring
    implementation("io.micrometer:micrometer-registry-prometheus")
    // Spring components
    implementation("org.springframework.boot:spring-boot-starter-actuator")

    // Javax annotations
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.12.4")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("org.springframework.boot:spring-boot-starter-webflux")
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("org.springframework.retry:spring-retry")
    compileOnly("javax.servlet:javax.servlet-api:4.0.1")
    providedRuntime("org.springframework.boot:spring-boot-starter-undertow")

    //Apache components
    implementation("org.apache.commons:commons-lang3:3.12.0")
    implementation("org.apache.httpcomponents:httpclient:4.5.13")

    // Validation
    implementation("com.google.code.findbugs:jsr305:3.0.2")
    implementation("javax.validation:validation-api:2.0.1.Final")
    implementation("commons-validator:commons-validator:1.7")
    toolDependency("ru.vtb.dev.corp.ia.epay:epay-build-tools:0.0.4")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api:5.7.2")
    testImplementation("org.testcontainers:junit-jupiter:1.16.3")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine:5.7.2")
}

var appMainClass = "ru.vtb.tsp.ia.epay.acsproxy.App"

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set(appMainClass)
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            artifact("build/libs/${project.name}.war")
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.jar {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
    manifest {
        attributes["Main-Class"] = appMainClass
    }
}

tasks.war {
    webInf.from("src/main/resources/web-inf/")
    webXml = file("src/main/resources/web.xml")
    // Set war file name
    archiveFileName.set("${project.name}.war")
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
}

val extractToolsDependency by tasks.register<Copy>("extractToolsDependency") {
    dependsOn(toolDependency)
    from(toolDependency.map {
        zipTree(it)
    })
    include("config/**")
    into(toolDir)
    includeEmptyDirs = false
}


tasks.withType<Checkstyle>().configureEach {
    dependsOn(extractToolsDependency)
    reports {
        xml.required.set(false)
        html.required.set(true)
    }
}

checkstyle {
    maxWarnings = 0
    isShowViolations = true
    isIgnoreFailures = false
    toolVersion = "9.3"
    configFile = file("${toolDir}/config/checkstyle/checkstyle.xml")
}

idea {
    // Download javadoc and sources
    module {
        isDownloadSources = true
        isDownloadJavadoc = true
    }
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
        property("sonar.exclusions", "src/main/resources/**/*," +
                "ru/vtb/tsp/ia/epay/acsproxy/**/*Dto.java," +
                "ru/vtb/tsp/ia/epay/acsproxy/**/*Abstract*.java," +
                "ru/vtb/tsp/ia/epay/acsproxy/**/*Config.java," +
                "ru/vtb/tsp/ia/epay/acsproxy/configs/**/*.java" +
                "ru/vtb/tsp/ia/epay/acsproxy/domain/*.java" +
                "ru/vtb/tsp/ia/epay/acsproxy/exceptions/*.java" +
                "ru/vtb/tsp/ia/epay/acsproxy/App.java" +
                "**/*.yaml," +
                "**/*.yml," +
                "**/*.xml")
    }
}