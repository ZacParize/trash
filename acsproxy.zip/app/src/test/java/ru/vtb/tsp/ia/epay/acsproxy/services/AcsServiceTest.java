package ru.vtb.tsp.ia.epay.acsproxy.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import lombok.var;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import ru.vtb.tsp.ia.epay.acsproxy.components.Validator;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.MessageWithPayload;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSCresCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSMethodCallbackDto;

@ExtendWith(MockitoExtension.class)
public class AcsServiceTest {

  static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
  static final CompressorService COMPRESSOR_SERVICE = new CompressorService();
  static final XmlSignatureValidator XML_SIGNATURE_VALIDATOR = new XmlSignatureValidator();
  static final Validator VALIDATOR = new Validator(OBJECT_MAPPER, COMPRESSOR_SERVICE,
      XML_SIGNATURE_VALIDATOR, true);

  static final AcsService ACS_SERVICE = new AcsService(null,
      VALIDATOR, "proxyUrl", "methodPath", "cresPath", "paresPath");

  static final TypeReference<Map<String, String>> MAP_TYPE_REFERENCE =
      new TypeReference<Map<String, String>>() {
      };

  @SneakyThrows
  static Stream<Arguments> provideCresCallbacks() {
    return Stream.of(
        Arguments.of(OBJECT_MAPPER.readValue(
            AcsServiceTest.class.getClassLoader()
                .getResourceAsStream("files/responses/3dsCresResponse1.txt"), MAP_TYPE_REFERENCE),
            OBJECT_MAPPER.readValue(AcsServiceTest.class.getClassLoader().getResourceAsStream(
                "files/responses/3dsCresResponse1.txt"), ThreeDSCresCallbackDto.class)),
        Arguments.of(OBJECT_MAPPER.readValue(
            AcsServiceTest.class.getClassLoader()
                .getResourceAsStream("files/responses/3dsCresResponse2.txt"), MAP_TYPE_REFERENCE),
            OBJECT_MAPPER.readValue(AcsServiceTest.class.getClassLoader().getResourceAsStream(
                "files/responses/3dsCresResponse2.txt"), ThreeDSCresCallbackDto.class)));
  }

  @DisplayName("Check Cres callbacks handling")
  @ParameterizedTest
  @MethodSource("provideCresCallbacks")
  void test_CresCallbacksSuccess(Map<String, String> params, MessageWithPayload response) {
    final var id = "testId";
    final var threeDSCallback = ACS_SERVICE.mapToThreeDSCresCallback(params, id);
    assertEquals(threeDSCallback, response);
  }

  @SneakyThrows
  static Stream<Arguments> provideMethodCallbacks() {
    return Stream.of(
        Arguments.of(new HashMap<String, String>() {
          {
            put("threeDSMethodData",
                "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6Ik0yRmpOMk5oWVRjdFlXRTBNaTB5TmpZekxUYzVNV0kiLCJ0"
                    + "aHJlZURTTWV0aG9kTm90aWZpY2F0aW9uVVJMIjoiaHR0cHM6Ly95YS5ydSJ9");
          }
        }, OBJECT_MAPPER.readValue(AcsServiceTest.class.getClassLoader().getResourceAsStream(
            "files/responses/3dsMethodResponse1.txt"), ThreeDSMethodCallbackDto.class)),
        Arguments.of(new HashMap<String, String>() {
          {
            put("threeDSMethodData", "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjNhYzdjYWE3LWFhNDItMjY2My03"
                + "OTFiLTJhYzA1YTU0MmM0YSIsInRocmVlRFNNZXRob2ROb3RpZmljYXRpb25VUkwiOiJodHRwczovL3l"
                + "hLnJ1In0=");
          }
        }, OBJECT_MAPPER.readValue(AcsServiceTest.class.getClassLoader().getResourceAsStream(
            "files/responses/3dsMethodResponse2.txt"), ThreeDSMethodCallbackDto.class)));
  }

  @SneakyThrows
  static Stream<Arguments> provideParesMethodCallbacks() {
    return Stream.of(
        Arguments.of(
            mapFromString(
                new String(Files.readAllBytes(Paths.get(
                    AcsServiceTest.class.getClassLoader()
                        .getResource("files/callbacks/3dsParesCallback1.txt").toURI())))
            )
        )
    );
  }

  @DisplayName("Check method callbacks handling")
  @ParameterizedTest
  @MethodSource("provideMethodCallbacks")
  void test_MethodCallbacksSuccess(Map<String, String> params, MessageWithPayload response) {
    final var id = "testId";
    final var threeDSCallback = ACS_SERVICE.mapToThreeDSMethodCallback(params, id);
    assertEquals(threeDSCallback, response);
  }

  @DisplayName("Check method callbacks handling")
  @ParameterizedTest
  @MethodSource("provideParesMethodCallbacks")
  void test_MethodCallbacksSuccess(Map<String, String> params) {
    final var testId = "a687fbdc-d5c1-11ec-9d64-0242ac120002";
    final var threeDSCallback = ACS_SERVICE.mapToThreeDSParesCallback(params, testId);
    assertEquals(threeDSCallback.getMd(), testId);
  }

  @DisplayName("Check method callbacks handling")
  @Test
  void test_EmptyParamsCallbacksSuccess() {
    final var id = "testId";
    final var params = new HashMap<String, String>();
    assertNull(ACS_SERVICE.mapToThreeDSMethodCallback(null, id));
    assertNull(ACS_SERVICE.mapToThreeDSCresCallback(null, id));
    assertNull(ACS_SERVICE.mapToThreeDSParesCallback(null, id));
    assertNull(ACS_SERVICE.mapToThreeDSMethodCallback(params, null));
    assertNull(ACS_SERVICE.mapToThreeDSCresCallback(params, null));
  }

  public static Map<String, String> mapFromString(String str) {
    Map<String, String> map = new HashMap<>();
    String[] pairs = str.split("&");
    for (int i = 0; i < pairs.length; i++) {
      String pair = pairs[i];
      String[] params = pair.split("=");
      map.put(params[0], params[1]);
    }
    return map;
  }
}