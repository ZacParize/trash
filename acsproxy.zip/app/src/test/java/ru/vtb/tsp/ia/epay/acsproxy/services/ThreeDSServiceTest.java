package ru.vtb.tsp.ia.epay.acsproxy.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Collections;
import java.util.stream.Stream;
import lombok.var;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.components.AsyncRestTemplate;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;

@ExtendWith(MockitoExtension.class)
class ThreeDSServiceTest {

  static AsyncRestTemplate ASYNC_REST_TEMPLATE;

  static ThreeDSService THREE_DS_SERVICE;

  @BeforeEach
  void init() {
    ASYNC_REST_TEMPLATE = Mockito.mock(AsyncRestTemplate.class);
    THREE_DS_SERVICE = new ThreeDSService(ASYNC_REST_TEMPLATE,  "proxyUrl", "methodPath");
  }

  static Stream<Arguments> providePostThreeDSDecisionCallbacks() {
    final var response = "testResponse";
    return Stream.of(Arguments.of(null, response),
                     Arguments.of(ThreeDSDecisionCallbackDto.builder().build(), response),
                     Arguments.of(ThreeDSDecisionCallbackDto.builder()
                         .browserColorDepth(1)
                         .browserLanguage("EN")
                         .browserScreenHeight(1)
                         .browserScreenWidth(1)
                         .windowWidth(1)
                         .windowHeight(1)
                         .browserTZ("timezone")
                         .browserJavaEnabled(Boolean.FALSE)
                         .browserIp("ip")
                         .browserUserAgent("userAgent")
                         .accept("*/*")
                         .initiator("initiator")
                         .build(), response));
  }

  @SuppressWarnings("unchecked")
  @DisplayName("Check threeDS decision callbacks")
  @ParameterizedTest
  @MethodSource("providePostThreeDSDecisionCallbacks")
  void test_ProvidePostThreeDSDecisionCallbacksSuccess(ThreeDSDecisionCallbackDto request,
                                                       String response) {
    final var id = "testId";
    final var responseCallback = Mono.justOrEmpty(response);
    when(ASYNC_REST_TEMPLATE.post(anyString(), any(), any(), any(Class.class), any()))
        .thenReturn(responseCallback);
    assertEquals(response,
        THREE_DS_SERVICE.postThreeDSDecision(Collections.emptyMap(), id, request).block());
  }

}