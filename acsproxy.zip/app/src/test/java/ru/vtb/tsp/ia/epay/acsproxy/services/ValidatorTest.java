package ru.vtb.tsp.ia.epay.acsproxy.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static ru.vtb.tsp.ia.epay.acsproxy.services.AcsServiceTest.mapFromString;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import lombok.var;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.components.Validator;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSCresDataDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSParesCallbackDto;

@ExtendWith(MockitoExtension.class)
class ValidatorTest {

  static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
  static final CompressorService COMPRESSOR_SERVICE = new CompressorService();
  static final XmlSignatureValidator XML_SIGNATURE_VALIDATOR = new XmlSignatureValidator();
  static final Validator VALIDATOR = new Validator(OBJECT_MAPPER, COMPRESSOR_SERVICE,
      XML_SIGNATURE_VALIDATOR, true);

  static final AcsService ACS_SERVICE = new AcsService(null,
      VALIDATOR, "proxyUrl", "methodPath", "cresPath", "paresPath");

  static Stream<Arguments> provideThreeDSServerTransIDBadCallbacks() {
    return Stream.of(
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres", null);
          }
        }),
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres",
                "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ICJmMDM4YjcxNS1kYzM1LTRkYWEtYWE1Mi05OTgyYjEyNjAzMz"
                    + "kwIiwKInRocmVlRFNTZXNzaW9uRGF0YSI6ICJaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTl"
                    + "RJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbU"
                    + "l4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQX"
                    + "daakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM0"
                    + "1UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016Tl"
                    + "MwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0"
                    + "ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9Uaz"
                    + "RNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd0"
                    + "1EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0"
                    + "dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR0"
                    + "16TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRm"
                    + "hMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE"
                    + "9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TW"
                    + "pZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaak"
                    + "F6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVX"
                    + "RaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMF"
                    + "pHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTl"
                    + "RJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbU"
                    + "l4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQX"
                    + "daakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM0"
                    + "1UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016Tl"
                    + "MwMFpHRmhMV0ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0"
                    + "ZoTlRJdE9UazRNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwMFpHRmhMV0ZoTlRJdE9Uaz"
                    + "RNbUl4TWpZd01EQXdaakF6T0dJM01UVXRaR016TlMwIiwKImFjc1RyYW5zSUQiOiAiNDk2ZTFjOD"
                    + "ktNjVhZi00ODQwLWJhYWItZjFkNzZiYjY2MzIzIiwKIm1lc3NhZ2VUeXBlIjogIkNSZXMiLAoibW"
                    + "Vzc2FnZVZlcnNpb24iOiAiMi4xLjAiLAoidHJhbnNTdGF0dXMiOiAiWSJ9");
          }
        }),
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres",
                "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ICIiLAoidGhyZWVEU1Nlc3Npb25EYXRhIjogIiIsCiJhY3NUc"
                    + "mFuc0lEIjogIjQ5NmUxYzg5LTY1YWYtNDg0MC1iYWFiLWYxZDc2YmI2NjMyMyIsCiJtZXNzYWdl"
                    + "VHlwZSI6ICJDUmVzIiwKIm1lc3NhZ2VWZXJzaW9uIjogIjIuMS4wIiwKInRyYW5zU3RhdHVzIjo"
                    + "gIlkifQ==");
          }
        })
    );
  }

  static String getRandomAlphabeticString(int targetLength) {
    final int leftLimit = 97; // letter 'a'
    final int rightLimit = 122; // letter 'z'
    final Random random = new Random();
    return random.ints(leftLimit, rightLimit + 1)
        .limit(targetLength)
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
        .toString();
  }

  @SneakyThrows
  @DisplayName("Should not pass threeDS server trans id validation")
  @ParameterizedTest
  @MethodSource("provideThreeDSServerTransIDBadCallbacks")
  void test_validateThreeDSServerTransIDFailCallbacks(Map<String, String> params) {
    final var id = "testId";
    final var callbackObject = ACS_SERVICE.mapToThreeDSCresCallback(
        params,
        id);
    assertNotNull(callbackObject);
    final var result = Objects.requireNonNull(
        VALIDATOR.validateThreeDSServerTransID(Mono.justOrEmpty(callbackObject),
            ThreeDSCresDataDto.class).block());
    if (Objects.nonNull(result)) {
      assertFalse(result.getIsValid());
    }
    final var result2 = VALIDATOR.validateThreeDSSessionData(Mono.justOrEmpty(callbackObject),
        ThreeDSCresDataDto.class).block();
    if (Objects.nonNull(result2)) {
      assertFalse(result.getIsValid());
    }
  }

  static Stream<Arguments> provideThreeDSServerTransIDCallbacks() {
    return Stream.of(
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres",
                "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6ICJmMDM4YjcxNS1kYzM1LTRkYWEtYWE1Mi05OTgyYjEyNjAz"
                    + "MzkiLAoidGhyZWVEU1Nlc3Npb25EYXRhIjogIlpqQXpPR0kzTVRVdFpHTXpOUzAwWkdGaExXRmh"
                    + "OVEl0T1RrNE1tSXhNall3TURBdyIsCiJhY3NUcmFuc0lEIjogIjQ5NmUxYzg5LTY1YWYtNDg0MC"
                    + "1iYWFiLWYxZDc2YmI2NjMyMyIsCiJtZXNzYWdlVHlwZSI6ICJDUmVzIiwKIm1lc3NhZ2VWZXJza"
                    + "W9uIjogIjIuMS4wIiwKInRyYW5zU3RhdHVzIjogIlkifQ==");
            put("threeDSSessionData", "33486606-b6c5-4c60-b386-502fd7037971");
          }
        }),
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres", "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6Ijc2OGE3OWE0LTc0OGYtNDBiYi05MjhlLTRhMGYxN"
                + "GJkZDk4YiIsImFjc1RyYW5zSUQiOiI1MjNlMGQzNy1kYjk0LTQ0YzEtYmYxNy00N2FmMzVlMmE4OWEi"
                + "LCJtZXNzYWdlVHlwZSI6IkNSZXMiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIiwidHJhbnNTdGF0dXM"
                + "iOiJZIn0");
            put("threeDSSessionData", "33486606-b6c5-4c60-b386-502fd703797e");
          }
        }),
        Arguments.of(new HashMap<String, String>() {
          {
            put("cres", "eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjZmMWE2M2VlLTQxMmMtNGRjYS05ZTM4LTRlNDZhM"
                + "zZkNjUwOSIsImFjc1RyYW5zSUQiOiI2NDNhYjIyYi1jMTY0LTQ1OTktODIzNS05ODBiZTc3NjUxMDEiL"
                + "CJtZXNzYWdlVHlwZSI6IkNSZXMiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIiwidHJhbnNTdGF0dXMi"
                + "OiJZIn0%3D");
            put("threeDSSessionData", "52a51e01-f598-41d3-8359-759d05e1a4a5");
          }
        }));
  }

  @SneakyThrows
  @DisplayName("Should pass threeDS server trans id validation")
  @ParameterizedTest
  @MethodSource("provideThreeDSServerTransIDCallbacks")
  void test_validateThreeDSServerTransIDSuccess(Map<String, String> params) {
    final var id = "testId";
    final var callbackObject = ACS_SERVICE.mapToThreeDSCresCallback(
        params,
        id);
    assertNotNull(callbackObject);
    assertNotNull(Objects.requireNonNull(
        VALIDATOR.validateThreeDSServerTransID(Mono.justOrEmpty(callbackObject),
            ThreeDSCresDataDto.class).block()).getPayload());
    assertNotNull(Objects.requireNonNull(
        VALIDATOR.validateThreeDSSessionData(Mono.justOrEmpty(callbackObject),
            ThreeDSCresDataDto.class).block()).getPayload());
  }

  @SneakyThrows
  static Stream<Arguments> provideThreeDSParesCallbacks() {
    return Stream.of(
        Arguments.of(
            mapFromString(
                new String(Files.readAllBytes(Paths.get(
                    AcsServiceTest.class.getClassLoader()
                        .getResource("files/callbacks/3dsParesCallback2.txt").toURI()))))
            )
        );
  }

  @SneakyThrows
  @DisplayName("Should pass threeDS server trans id validation")
  @ParameterizedTest
  @MethodSource("provideThreeDSParesCallbacks")
  void test_validateThreeDSPares(Map<String, String> params) {
    final var testId = "a687fbdc-d5c1-11ec-9d64-0242ac120002";
    final var threeDSCallback = ACS_SERVICE.mapToThreeDSParesCallback(params, testId);
    final var mono = VALIDATOR.validateParesData(
        Mono.justOrEmpty(threeDSCallback), ThreeDSParesCallbackDto.class);
    final var result = mono.block();
    assertNotNull(result.getPayload());
    assertTrue(result.getIsValid());
  }

  @SneakyThrows
  @DisplayName("Should pass threeDS incorrect md validation")
  @ParameterizedTest
  @MethodSource("provideThreeDSParesCallbacks")
  void test_validateThreeDSParesIncorrectMD(Map<String, String> params) {
    final var testId = "a687fbdc-d5c1-11ec-9d64-0242ac120002";
    final var testMD = testId + getRandomAlphabeticString(36);
    final var threeDSCallback = ACS_SERVICE.mapToThreeDSParesCallback(params, testId);
    assertNotNull(threeDSCallback);
    threeDSCallback.setMd(testMD);
    final var mono = VALIDATOR.validateParesData(
        Mono.justOrEmpty(threeDSCallback), ThreeDSParesCallbackDto.class);
    final var result = mono.block();
    assertNotNull(result);
    assertNull(result.getPayload());
    assertFalse(result.getIsValid());
    assertEquals(result.getMd(), testMD);
  }

}