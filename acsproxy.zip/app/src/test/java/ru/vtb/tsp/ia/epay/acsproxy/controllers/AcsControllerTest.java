package ru.vtb.tsp.ia.epay.acsproxy.controllers;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.UUID;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.services.AcsService;

@WebMvcTest(AcsController.class)
class AcsControllerTest {

  @MockBean
  private AcsService acsService;

  @Autowired
  private MockMvc mockMvc;

  @Test
  @DisplayName("POST /v1/threeds/cres/notification/{id}")
  void cresCalback() throws Exception {
    String id = UUID.randomUUID().toString();
    doReturn(Mono.empty()).when(acsService)
        .handleCresCallback(any(), any(), anyString());

    mockMvc.perform(post("/v1/threeds/cres/notification/" + id)
            .contentType(MediaType.APPLICATION_FORM_URLENCODED_VALUE)
            .content(
                "cres=eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6Ijc2OGE3OWE0LTc0OGYtNDBiYi05MjhlLTRhMGYxNGJ"
                    + "kZDk4YiIsImFjc1RyYW5zSUQiOiI1MjNlMGQzNy1kYjk0LTQ0YzEtYmYxNy00N2FmMzVlMmE4O"
                    + "WEiLCJtZXNzYWdlVHlwZSI6IkNSZXMiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMS4wIiwidHJhbnN"
                    + "TdGF0dXMiOiJZIn0%3D&threeDSSessionData=33486606-b6c5-4c60-b386-502fd703797e")
        )
        .andDo(print())
        .andExpect(status().isOk());
  }
}