package ru.vtb.tsp.ia.epay.acsproxy.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 06.05.2022
 */
public class JV8Util {

  public static <K, V> Map<K, V> mapOf(K key, V value) {
    final Map<K, V> map = new HashMap<>();
    map.put(key, value);
    return map;
  }

  public static <T> List<T> listOf(T ... values) {
    return Arrays.asList(values);
  }

  public static <T> T requireNonNullElse(T src, T defValue) {
    if (Objects.nonNull(src)) {
      return src;
    }
    return defValue;
  }


}
