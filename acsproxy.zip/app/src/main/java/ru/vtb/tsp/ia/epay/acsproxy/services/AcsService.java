package ru.vtb.tsp.ia.epay.acsproxy.services;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.components.AsyncRestTemplate;
import ru.vtb.tsp.ia.epay.acsproxy.components.Validator;
import ru.vtb.tsp.ia.epay.acsproxy.controllers.AcsController;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSCresCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSCresDataDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSMethodCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSMethodDataDto;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSParesCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.utils.JV8Util;

@Slf4j
@Service
public class AcsService {

  private static final String METHOD_PREFIX_KEY = "threeDSMethodData";
  private static final String CRES_PARAM_KEY = "cres";
  private static final String THREE_DS_SESSION_DATA_KEY = "threeDSSessionData";
  private static final String PARES_PREFIX_KEY = "PaRes";
  private static final String MD_PREFIX_KEY = "MD";
  private final AsyncRestTemplate asyncRestTemplate;
  private final Validator validator;
  private final String methodUrl;
  private final String cresUrl;
  private final String paresUrl;

  @Autowired
  public AcsService(AsyncRestTemplate asyncRestTemplate,
      Validator validator,
      @Value("${app.proxy.base-url}") String baseUrl,
      @Value("${app.proxy.endpoints.threeds-method-path}") String methodPath,
      @Value("${app.proxy.endpoints.threeds-cres-method-path}") String cresPath,
      @Value("${app.proxy.endpoints.threeds-pares-path}") String paresPath) {
    this.asyncRestTemplate = asyncRestTemplate;
    this.validator = validator;
    this.methodUrl = baseUrl + methodPath;
    this.cresUrl = baseUrl + cresPath;
    this.paresUrl = baseUrl + paresPath;
  }

  protected @Nullable ThreeDSMethodCallbackDto mapToThreeDSMethodCallback(
      @Nullable Map<String, String> params,
      @Nullable String id) {
    if (Objects.isNull(params) || ObjectUtils.isEmpty(id)) {
      return null;
    }
    final var builder = ThreeDSMethodCallbackDto.builder().isValid(true);
    getKey(params, METHOD_PREFIX_KEY)
        .ifPresent(key -> {
          String threedsMethodFormData = params.get(key);
          if (StringUtils.isNotEmpty(threedsMethodFormData)) {
            log.info("Received 3DS Method request: {} with id: {}", threedsMethodFormData, id);
            builder.threeDSMethodData(threedsMethodFormData);
          }
        });
    return builder.build();
  }

  protected @Nullable ThreeDSCresCallbackDto mapToThreeDSCresCallback(
      Map<String, String> params,
      @Nullable String id) {
    if (Objects.isNull(params) || ObjectUtils.isEmpty(id)) {
      return null;
    }
    final var builder = ThreeDSCresCallbackDto.builder().isValid(false);
    getKey(params, CRES_PARAM_KEY)
        .ifPresent(key -> {
          String cresFormData = params.get(key);
          if (StringUtils.isNotEmpty(cresFormData)) {
            log.info("Received CRES request: {} with id: {}", cresFormData, id);
            builder.cres(cresFormData);
          }
        });

    getKey(params, THREE_DS_SESSION_DATA_KEY)
        .ifPresent(key -> {
          String sessionData = params.get(key);
          if (StringUtils.isNotEmpty(sessionData)) {
            builder.threeDSSessionData(sessionData);
          }
        });
    return builder.build();
  }

  protected @Nullable ThreeDSParesCallbackDto mapToThreeDSParesCallback(
      @Nullable Map<String, String> params,
      @Nullable String id) {
    if (Objects.isNull(params) || ObjectUtils.isEmpty(id)) {
      return null;
    }
    final var builder = ThreeDSParesCallbackDto.builder();
    getKey(params, PARES_PREFIX_KEY).ifPresent(key -> {
      String paresFormData = params.get(key);
      if (StringUtils.isNotEmpty(paresFormData)) {
        log.info("Set PARES from request: {}", paresFormData);
        builder.pares(paresFormData);
      }
    });
    getKey(params, MD_PREFIX_KEY).ifPresent(key -> {
      String mdData = params.get(key);
      if (StringUtils.isNotEmpty(mdData)) {
        log.info("Set pares MD: {}", mdData);
        builder.md(mdData);
      }
    });
    return builder.build();
  }

  public @NotNull Mono<Void> handleMethodCallback(@Nullable Map<String, String> headers,
      @Nullable Map<String, String> param,
      @Nullable String id) {
    if (Objects.isNull(param) || ObjectUtils.isEmpty(id)) {
      return Mono.empty();
    }
    return asyncRestTemplate.post(methodUrl,
        headers,
        validator.validateThreeDSServerTransID(
            Mono.justOrEmpty(mapToThreeDSMethodCallback(param, id)),
            ThreeDSMethodDataDto.class
        ),
        Void.class,
        JV8Util.mapOf(AcsController.ID_PATH_VARIABLE, id));
  }

  public @NotNull Mono<Void> handleCresCallback(@Nullable Map<String, String> headers,
      Map<String, String> params,
      @Nullable String id) {
    if (Objects.isNull(params) || ObjectUtils.isEmpty(id)) {
      return Mono.empty();
    }
    /*
     *threeDSServerTransID - иденификатор который предоставлят ACS.
     *threeDSSessionData - код транзакции в бд ПЭК
     *Если проверка threeDSServerTransID успешна, а формат threeDSSessionData не успешен,
     *не передавать ичего на бэк
     *Если проверка threeDSServerTransID не успешна, а поверка формата threeDSSessionData успешна,
     *на бэкенд передать флаг=false - деклайнить транзакцию
     */
    return asyncRestTemplate.post(cresUrl,
        headers, validator.validateThreeDSSessionData(
            validator.validateThreeDSServerTransID(
                Mono.justOrEmpty(mapToThreeDSCresCallback(params, id)),
                ThreeDSCresDataDto.class), ThreeDSCresDataDto.class), Void.class,
        JV8Util.mapOf(AcsController.ID_PATH_VARIABLE, id));
  }

  public @NotNull Mono<Void> handleParesCallback(@Nullable Map<String, String> headers,
      @Nullable Map<String, String> params,
      @Nullable String id) {
    if (Objects.isNull(params)) {
      return Mono.empty();
    }
    return asyncRestTemplate.post(paresUrl, headers,
        validator.validateParesData(Mono.justOrEmpty(mapToThreeDSParesCallback(params, id)),
            ThreeDSParesCallbackDto.class),
        Void.class,
        JV8Util.mapOf(AcsController.ID_PATH_VARIABLE, id));
  }

  public Optional<String> getKey(Map<String, String> map, String value) {
    for (Entry<String, String> entry : map.entrySet()) {
      if (entry.getKey().equalsIgnoreCase(value)) {
        return Optional.of(entry.getKey());
      }
    }
    return Optional.empty();
  }
}