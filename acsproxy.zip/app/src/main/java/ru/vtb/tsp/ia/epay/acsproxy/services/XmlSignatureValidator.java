package ru.vtb.tsp.ia.epay.acsproxy.services;

import java.io.StringReader;
import javax.xml.crypto.dsig.XMLSignature;
import javax.xml.crypto.dsig.XMLSignatureFactory;
import javax.xml.crypto.dsig.dom.DOMValidateContext;
import javax.xml.parsers.DocumentBuilderFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

@Service
@Slf4j
public class XmlSignatureValidator {

  private static final String DOM = "DOM";
  private static final String SIGNATURE = "Signature";
  private static final String ID = "id";

  public boolean validateSignature(String paresXml) {
    if (ObjectUtils.isEmpty(paresXml)) {
      return false;
    }
    log.info("PARes for validation {}", paresXml);
    boolean isValid = false;
    try {
      final DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      dbf.setNamespaceAware(true);
      final InputSource is = new InputSource();
      is.setCharacterStream(new StringReader(paresXml));
      Document doc = dbf.newDocumentBuilder().parse(is);
      final NodeList nl = doc.getElementsByTagNameNS(XMLSignature.XMLNS, SIGNATURE);
      if (nl.getLength() == 0) {
        return true;
      }
      final NodeList elList = doc.getElementsByTagName("PARes");
      if (elList != null && elList.getLength() > 0
          && ((Element) elList.item(0)).hasAttribute(ID)) {
        Attr id = ((Element) elList.item(0)).getAttributeNode(ID);
        ((Element) elList.item(0)).setIdAttributeNode(id, true);
      }
      final DOMValidateContext valContext = new DOMValidateContext(
          new X509KeySelector(), nl.item(0));
      XMLSignatureFactory factory = XMLSignatureFactory.getInstance(DOM);
      XMLSignature signature = factory.unmarshalXMLSignature(valContext);
      isValid = signature.validate(valContext);
    } catch (Exception e) {
      log.error("Signature validation error {}", e.getMessage());
    }
    return isValid;
  }
}
