package ru.vtb.tsp.ia.epay.acsproxy.configs;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.Objects;
import javax.net.ssl.SSLContext;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustAllStrategy;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import reactor.util.annotation.Nullable;
import ru.vtb.tsp.ia.epay.acsproxy.utils.JV8Util;

@RequiredArgsConstructor
@Configuration
@Slf4j
public class RestTemplateConfig {

  private final ProxyConfig proxyConfig;
  private final RestTemplateBuilder builder;

  @Bean
  public RestTemplate restTemplate() {
    if (!proxyConfig.getSslEnabled() || Objects.isNull(proxyConfig.getSsl())) {
      log.info("Ssl enabled {}", proxyConfig.getSslEnabled());
      return new RestTemplate();
    } else {
      log.info("TLS certificate validation {}", proxyConfig.getSsl().getCertValidation());
    }
    if (proxyConfig.getSsl().getCertValidation()) {
      return restTemplate(builder, proxyConfig);
    } else {
      return restTemplateWithoutValidation(proxyConfig);
    }
  }

  public RestTemplate restTemplate(RestTemplateBuilder builder, ProxyConfig props) {
    if (Objects.nonNull(props) && JV8Util.requireNonNullElse(props.getSslEnabled(), false)) {
      final var socketFactory = new SSLConnectionSocketFactory(
          Objects.requireNonNull(getSSLContext(props)), NoopHostnameVerifier.INSTANCE);
      final CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory)
          .build();
      final var requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
      //requestFactory.setReadTimeout(props.getTimeout());
      //requestFactory.setConnectTimeout(props.getTimeout());
      RestTemplate restTemplate = builder.build();
      restTemplate.setRequestFactory(requestFactory);
      return restTemplate;
    } else {
      return builder.build();
    }
  }

  @SneakyThrows
  private RestTemplate restTemplateWithoutValidation(ProxyConfig proxyConfig) {
    TrustStrategy acceptingTrustStrategy = (X509Certificate[] chain, String authType) -> true;

    SSLContext sslContext = SSLContexts.custom()
        .loadTrustMaterial(null, acceptingTrustStrategy)
        .build();

    SSLConnectionSocketFactory csf = proxyConfig.getSsl().getTlsVerification()
        ? new SSLConnectionSocketFactory(sslContext)
        : new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
    CloseableHttpClient httpClient = HttpClients.custom()
        .setSSLSocketFactory(csf)
        .build();

    HttpComponentsClientHttpRequestFactory requestFactory =
        new HttpComponentsClientHttpRequestFactory();

    requestFactory.setHttpClient(httpClient);
    return new RestTemplate(requestFactory);
  }

  private static @Nullable String getKeyAlias(@Nullable ProxyConfig props,
      @Nullable KeyStore keyStore) {
    if (Objects.isNull(props) || !JV8Util.requireNonNullElse(props.getSslEnabled(), false)
        || Objects.isNull(keyStore)) {
      return null;
    }

    try {
      final var aliases = keyStore.aliases();
      for (var alias : Collections.list(aliases)) {
        log.info("Keystore aliases {}", alias);
        if (keyStore.isKeyEntry(alias)) {
          log.info("Keystore found alias {}", alias);
          return alias;
        }
      }
    } catch (KeyStoreException ex) {
      log.error("Error occurred during keystore loading alias", ex);
      throw new RestClientException("Error occurred during keystore loading alias", ex);
    }

    return null;
  }

  private static @Nullable KeyStore getKeystore(@Nullable ProxyConfig props) {
    if (Objects.isNull(props) || !JV8Util.requireNonNullElse(props.getSslEnabled(), false)) {
      return null;
    }

    try (var keyStoreInputStream = new FileInputStream(
        ResourceUtils.getFile(props.getSsl().getKeystorePath()))) {
      final var keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(keyStoreInputStream, props.getSsl().getKeystorePass().toCharArray());
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException ex) {
      log.error("Error occurred during keystore loading", ex);
      throw new RestClientException("Error occurred during keystore loading", ex);
    }
  }

  private static @Nullable SSLContext getSSLContext(@Nullable ProxyConfig props) {
    if (Objects.isNull(props) || !JV8Util.requireNonNullElse(props.getSslEnabled(), false)) {
      return null;
    }
    final var builder = new SSLContextBuilder();
    try {
      if (JV8Util.requireNonNullElse(props.getSsl().getClientAuth(), false)) {
        final var keyStore = getKeystore(props);
        final var keyAlias = getKeyAlias(props, keyStore);
        builder.loadKeyMaterial(keyStore, props.getSsl().getKeyPass().toCharArray(),
            ((aliases, socket) -> keyAlias));
      }
      if (JV8Util.requireNonNullElse(props.getSsl().getCertValidation(), false)) {
        builder.loadTrustMaterial(ResourceUtils.getFile(props.getSsl().getTruststorePath()),
            props.getSsl().getTruststorePass().toCharArray());
      } else {
        builder.loadTrustMaterial(null, TrustAllStrategy.INSTANCE);
      }
      return builder.build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException
        | KeyManagementException | UnrecoverableKeyException e) {
      log.error("Error occurred during SSL context creation", e);
      throw new RestClientException("Error occurred during SSL context creation", e);
    }
  }
}
