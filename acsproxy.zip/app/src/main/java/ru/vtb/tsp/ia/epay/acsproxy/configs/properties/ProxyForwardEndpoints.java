package ru.vtb.tsp.ia.epay.acsproxy.configs.properties;

import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class ProxyForwardEndpoints {

  @NotBlank
  private String threedsMethodPath;

  @NotBlank
  private String threedsCresMethodPath;

  @NotBlank
  private String threedsDecisionPath;

  @NotBlank
  private String threedsParesPath;

}