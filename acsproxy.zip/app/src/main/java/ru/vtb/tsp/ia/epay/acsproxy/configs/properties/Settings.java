package ru.vtb.tsp.ia.epay.acsproxy.configs.properties;

import lombok.Data;

@Data
public class Settings {

  private boolean validateParesSignature;

}