package ru.vtb.tsp.ia.epay.acsproxy.configs;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.springframework.classify.Classifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.NeverRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.reactive.config.WebFluxConfigurer;


@Slf4j
@Configuration
@RequiredArgsConstructor
public class AppConfig implements WebFluxConfigurer {

  private static final int MAX_RETRY_ATTEMPTS = 3;
  private final ProxyConfig proxyConfig;

  @PostConstruct
  public void print() {
    log.info("\n" + "Application settings:" + "\n" + proxyConfig);
  }

  private static Classifier<Throwable, RetryPolicy> configureStatusCodeBasedRetryPolicy() {
    final var simpleRetryPolicy = new SimpleRetryPolicy(MAX_RETRY_ATTEMPTS);
    final var neverRetryPolicy = new NeverRetryPolicy();
    return throwable -> {
      if (throwable instanceof HttpStatusCodeException) {
        switch (((HttpStatusCodeException) throwable).getStatusCode()) {
          case BAD_GATEWAY:
          case SERVICE_UNAVAILABLE:
          case INTERNAL_SERVER_ERROR:
          case GATEWAY_TIMEOUT:
            return simpleRetryPolicy;
          default:
            return neverRetryPolicy;
        }
      }
      return simpleRetryPolicy;
    };
  }

  @Bean
  public RetryTemplate retryTemplate() {
    final var policy = new ExceptionClassifierRetryPolicy();
    policy.setExceptionClassifier(configureStatusCodeBasedRetryPolicy());
    final var retryTemplate = new RetryTemplate();
    retryTemplate.setRetryPolicy(policy);
    return retryTemplate;
  }

  @Bean
  public ObjectMapper objectMapper() {
    final var objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
    objectMapper.enable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    objectMapper.enable(JsonParser.Feature.ALLOW_COMMENTS);
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapper.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    objectMapper.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
    objectMapper.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    objectMapper.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    return objectMapper;
  }


}