package ru.vtb.tsp.ia.epay.acsproxy.services;

import java.security.PublicKey;
import java.security.cert.X509Certificate;
import java.util.Objects;
import javax.xml.crypto.AlgorithmMethod;
import javax.xml.crypto.KeySelector;
import javax.xml.crypto.KeySelectorException;
import javax.xml.crypto.KeySelectorResult;
import javax.xml.crypto.XMLCryptoContext;
import javax.xml.crypto.XMLStructure;
import javax.xml.crypto.dsig.SignatureMethod;
import javax.xml.crypto.dsig.keyinfo.KeyInfo;
import javax.xml.crypto.dsig.keyinfo.X509Data;
/*
<ThreeDSecure>
  <Message id="xfm5_7_2.623846391">
    <PARes id="PARes.3960005.signed">
      <version>1.0.2</version>
      <Merchant>
        <acqBIN>544793</acqBIN>
        <merID>9223828001</merID>
      </Merchant>
      <Purchase>
        <xid>2fkNjvEw4Qc6LmS6qNw/OWPxkGk=</xid>
        <date>20160822 05:19:39</date>
        <purchAmount>10000</purchAmount>
        <currency>643</currency>
        <exponent>2</exponent>
      </Purchase>
      <pan>0000000000003352</pan>
      <TX>
        <time>20160822 14:20:11</time>
        <status>Y</status>
        <cavv>jFC65kf7wmidChAAM7ejBRgAAAA=</cavv>
        <eci>02</eci>
        <cavvAlgorithm>3</cavvAlgorithm>
      </TX>
    </PARes>
        <Signature xmlns="http://www.w3.org/2000/09/xmldsig#">
          <SignedInfo xmlns="http://www.w3.org/2000/09/xmldsig#">
            <CanonicalizationMethod Algorithm="http://www.w3.org/TR/2001/REC-xml-c14n-20010315"/>
            <SignatureMethod Algorithm="http://www.w3.org/2000/09/xmldsig#rsa-sha1"/>
            <Reference URI="#PARes.3960005.signed">
              <DigestMethod Algorithm="http://www.w3.org/2000/09/xmldsig#sha1"/>
              <DigestValue>QK+g03uW/PQmBCPmn5q8dhOGwuo=</DigestValue>
            </Reference>
          </SignedInfo>
          <SignatureValue>FN7e0h87r5IF0o84Z...</SignatureValue>
          <KeyInfo>
            <X509Data>
              <X509Certificate>MIIEkTCCA...</X509Certificate>
              <X509Certificate>MIIEgDCCA...</X509Certificate>
              <X509Certificate>MIIDzzCCA...</X509Certificate>
            </X509Data>
          </KeyInfo>
        </Signature>
  </Message>
</ThreeDSecure>
*/

public class X509KeySelector extends KeySelector {

  /*
   * Поиск/выбор подходящих (согласно алгоритму подписи) публичных ключей (в блоке  KeyInfo) в
   * подписанной xml для дальнейших операций над подписанным блоком
   */
  public KeySelectorResult select(KeyInfo keyInfo,
                                  KeySelector.Purpose purpose,
                                  AlgorithmMethod method,
                                  XMLCryptoContext context) throws KeySelectorException {
    if (Objects.nonNull(keyInfo) && Objects.nonNull(keyInfo.getContent())) {
      for (XMLStructure info : keyInfo.getContent()) {
        if (!(info instanceof X509Data)) {
          continue;
        }
        final X509Data x509Data = (X509Data) info;
        for (Object o : x509Data.getContent()) {
          if (!(o instanceof X509Certificate)) {
            continue;
          }
          final PublicKey key = ((X509Certificate) o).getPublicKey();
          if (algEquals(method.getAlgorithm(), key.getAlgorithm())) {
            return () -> key;
          }
        }
      }
    }
    throw new KeySelectorException("No key found");
  }

  static boolean algEquals(String algURI, String algName) {
    return (algName.equalsIgnoreCase("DSA")
        && algURI.equalsIgnoreCase(SignatureMethod.DSA_SHA1))
        || (algName.equalsIgnoreCase("RSA")
        && algURI.equalsIgnoreCase(SignatureMethod.RSA_SHA1));
  }
}
