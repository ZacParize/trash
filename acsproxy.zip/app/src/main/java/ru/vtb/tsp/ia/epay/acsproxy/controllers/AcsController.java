package ru.vtb.tsp.ia.epay.acsproxy.controllers;

import java.util.Map;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.services.AcsService;

@Validated
@RestController
@RequiredArgsConstructor
public class AcsController {

  public static final String ID_PATH_VARIABLE = "id";
  private static final String METHOD_NOTIFICATION = "/v1/threeds/method/notification/{id}";
  private static final String CRES_NOTIFICATION = "/v1/threeds/cres/notification/{id}";
  private static final String PARES_NOTIFICATION = "/v1/threeds/pares/notification/{id}";
  private final AcsService acsService;

  @PostMapping(path = METHOD_NOTIFICATION,
      consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  public ResponseEntity<Mono<Void>> doMethodProxy(@RequestHeader Map<String, String> headers,
      @PathVariable(ID_PATH_VARIABLE) @NotEmpty String id,
      @RequestParam @NotNull Map<String, String> param) {
    return ResponseEntity.ok(acsService.handleMethodCallback(headers, param, id));
  }

  @PostMapping(path = CRES_NOTIFICATION, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  public ResponseEntity<Mono<Void>> doCresProxy(@RequestHeader Map<String, String> headers,
      @PathVariable(ID_PATH_VARIABLE) @NotEmpty String id,
      @RequestParam @NotNull Map<String, String> param) {
    return ResponseEntity.ok(acsService.handleCresCallback(headers, param, id));
  }

  @PostMapping(path = PARES_NOTIFICATION, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
  public ResponseEntity<Mono<Void>> doParesProxy(@RequestHeader Map<String, String> headers,
      @PathVariable(ID_PATH_VARIABLE) @NotEmpty String id,
      @RequestParam @NotNull Map<String, String> param) {
    return ResponseEntity.ok(acsService.handleParesCallback(headers, param, id));
  }
}