package ru.vtb.tsp.ia.epay.acsproxy.components;

import java.util.Collections;
import java.util.Map;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.lang.Nullable;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.utils.JV8Util;

@Slf4j
@Component
public class AsyncRestTemplate {

  private final RestTemplate restTemplate;
  private final RetryTemplate retryTemplate;
  private final String hostHeader;

  public AsyncRestTemplate(RestTemplate restTemplate,
      RetryTemplate retryTemplate,
      @Value("${app.proxy.host-header}") String hostHeader) {
    this.restTemplate = restTemplate;
    this.retryTemplate = retryTemplate;
    this.hostHeader = hostHeader;
  }

  @SneakyThrows(RestClientException.class)
  public <T> @NotNull Mono<T> post(@NotBlank String uri,
      @Nullable Map<String, String> headers,
      @NotNull Mono<?> bodyCallback,
      @NotNull Class<T> responseType,
      @NotNull Map<String, ?> uriValues) {
    final var newHeaders = new HttpHeaders();
    newHeaders.put(HttpHeaders.ACCEPT,
        JV8Util.listOf(MimeTypeUtils.APPLICATION_JSON_VALUE, MimeTypeUtils.TEXT_PLAIN_VALUE));
    newHeaders.put(HttpHeaders.CONTENT_TYPE,
        Collections.singletonList(MimeTypeUtils.APPLICATION_JSON_VALUE));
    newHeaders.put(HttpHeaders.HOST, Collections.singletonList(hostHeader));
    if (!CollectionUtils.isEmpty(headers)) {
      newHeaders.put(HttpHeaders.CONTENT_LENGTH,
          Collections.singletonList(headers.get(HttpHeaders.CONTENT_LENGTH)));
    }
    return bodyCallback.mapNotNull(body -> retryTemplate.execute(
        context -> {
          try {
            return restTemplate.postForObject(uri,
                new HttpEntity<>(body, newHeaders),
                responseType,
                uriValues);
          } catch (HttpClientErrorException.NotFound ex) {
            log.error("Rest template received empty body {}", ex.getMessage());
            return null;
          } catch (Exception e) {
            log.error("Rest template error {}", e.getMessage());
            return null;
          }
        }));
  }

}
