package ru.vtb.tsp.ia.epay.acsproxy.utils;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource(value = "classpath:/git.properties", ignoreResourceNotFound = true)
@JsonAutoDetect(fieldVisibility = Visibility.NONE, getterVisibility = Visibility.NONE,
    setterVisibility = Visibility.NONE)
public class GitVersion {

  @JsonProperty
  @Value("${git.commit.id.abbrev:default}")
  private String commitIdAbbrev;

  @Value("${git.commit.user.email:default}")
  private String commitUserEmail;

  @Value("${git.commit.message.full:default}")
  private String commitMessageFull;

  @Getter
  @JsonProperty
  @Value("${git.commit.id:default}")
  private String commitId;

  @Value("${git.commit.message.short:default}")
  private String commitMessageShort;

  @Getter
  @Value("${git.build.user.name:default}")
  private String buildUserName;

  @Getter
  @Value("${git.build.version:default}")
  private String buildVersion;

  @Getter
  @Value("${git.api.version:default}")
  private String apiVersion;

  @Getter
  @Value("${git.commit.id.describe:default}")
  private String commitIdDescribe;

  @Getter
  @Value("${git.build.user.email:default}")
  private String buildUserEmail;

  @Getter
  @JsonProperty
  @Value("${git.branch:default}")
  private String branch;

  @JsonProperty
  @Value("${git.commit.time:default}")
  private String commitTime;

  @Getter
  @JsonProperty
  @Value("${git.build.time:default}")
  private String buildTime;

  @Value("${git.remote.origin.url:default}")
  private String remoteOriginUrl;
}
