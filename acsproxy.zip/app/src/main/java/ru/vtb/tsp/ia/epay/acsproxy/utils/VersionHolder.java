package ru.vtb.tsp.ia.epay.acsproxy.utils;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class VersionHolder {

  private static final String RFC3339 = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

  private String component;
  private String environment;
  private String buildVersion;
  private String branch;
  private String commitId;
  private String buildTime;

  @JsonFormat(shape = Shape.STRING, pattern = RFC3339)
  private Date startTime;

  private String serverIp;
  private String serverHostName;
  private String apiVersion;

  public Date getStartTime() {
    return startTime == null ? null : new Date(startTime.getTime());
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime == null ? null : new Date(startTime.getTime());
  }
}
