package ru.vtb.tsp.ia.epay.acsproxy.configs.properties;

import lombok.Data;

/**
 * Конфиг SSL.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 16.08.2021
 */
@Data
public class Ssl {

  //@NotBlank
  private String protocol;

  //@NotBlank
  private String truststorePath;

  //@NotBlank
  private String truststorePass;

  //@NotBlank
  private String truststoreType;

  //@NotBlank
  private String keystorePath;

  //@NotBlank
  private String keystorePass;

  //@NotBlank
  private String keystoreType;

  //@NotBlank
  private String keyPass;

  //@NotNull
  private Boolean clientAuth;

  //@NotNull
  private Boolean certValidation;

  private Boolean tlsVerification;

}