package ru.vtb.tsp.ia.epay.acsproxy.controllers;

import static org.springframework.util.MimeTypeUtils.TEXT_PLAIN_VALUE;

import java.nio.file.Files;
import java.nio.file.Paths;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.acsproxy.configs.ProxyConfig;

@Validated
@RestController
@RequiredArgsConstructor
public class TestController {

  private final ProxyConfig props;

  @PostMapping(path = "/test", produces = TEXT_PLAIN_VALUE)
  public ResponseEntity<String> test() {
    return ResponseEntity.ok("Truststore exists: "
        + Files.exists(Paths.get(props.getSsl().getTruststorePath())));
  }

}