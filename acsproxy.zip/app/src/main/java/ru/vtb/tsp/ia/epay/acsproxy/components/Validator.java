package ru.vtb.tsp.ia.epay.acsproxy.components;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Objects;
import java.util.regex.Pattern;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import lombok.var;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.util.annotation.Nullable;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.AbstractMessageWithPayload;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.PayloadWithThreeDSServerTransId;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.PayloadWithThreeDSSessionData;
import ru.vtb.tsp.ia.epay.acsproxy.services.CompressorService;
import ru.vtb.tsp.ia.epay.acsproxy.services.XmlSignatureValidator;
import ru.vtb.tsp.ia.epay.acsproxy.utils.JV8Util;

@Slf4j
@Component
public class Validator {

  private static final Pattern UUID_PATTERN = Pattern
      .compile("^[{]?[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}[}]?$");
  private static final Base64.Decoder DECODER = Base64.getDecoder();
  private static final AbstractMessageWithPayload ABSTRACT_MESSAGE_WITH_PAYLOAD = null;
  private static final String EMPTY_PAYLOAD = "";
  private final ObjectMapper objectMapper;
  private final CompressorService compressorService;
  private final XmlSignatureValidator xmlSignatureValidator;
  private final boolean validateParesSignature;

  public Validator(ObjectMapper objectMapper,
      CompressorService compressorService,
      XmlSignatureValidator xmlSignatureValidator,
      @Value("${app.proxy.settings.validate-pares-signature}") boolean validateParesSignature) {
    this.objectMapper = objectMapper;
    this.compressorService = compressorService;
    this.xmlSignatureValidator = xmlSignatureValidator;
    this.validateParesSignature = validateParesSignature;
  }


  public @NotNull Mono<? extends AbstractMessageWithPayload> validateThreeDSServerTransID(
      @Nullable Mono<? extends AbstractMessageWithPayload> message,
      @Nullable Class<? extends PayloadWithThreeDSServerTransId> payloadClass) {
    if (Objects.isNull(message) || Objects.isNull(payloadClass)) {
      return Mono.empty();
    }
    return message.map(req -> {
      try {
        final var data = objectMapper.readValue(DECODER
            .decode(
                safeDecode(JV8Util.requireNonNullElse(req.getPayload(), EMPTY_PAYLOAD))
            ), payloadClass);
        log.info("3DS data decrypted {}", data);
        req.setIsValid(true);
        if (!isValidGUID(data.getThreeDSServerTransID())) {
          log.error("ACS callback {} threeDS server trans id validation failed",
              data.getThreeDSServerTransID());
          req.setIsValid(false);
          req.setPayload(null);
          return req;
        }

        log.info("ACS callback {} threeDS server trans id successfully validated",
            data.getThreeDSServerTransID());
        return req;

      } catch (IOException ex) {
        log.error("Error occurred during 3DS data decryption {}", req.getPayload(), ex);
        req.setIsValid(false);
        req.setPayload(null);
        return req;
      }
    });
  }

  public @NotNull Mono<? extends AbstractMessageWithPayload> validateThreeDSSessionData(
      @Nullable Mono<? extends AbstractMessageWithPayload> message,
      @Nullable Class<? extends PayloadWithThreeDSSessionData> payloadClass) {
    if (Objects.isNull(message) || Objects.isNull(payloadClass)) {
      return Mono.empty();
    }
    return message.flatMap(req -> {
      try {
        if (!isValidGUID(req.getThreeDSSessionData())) {
          log.error("ACS callback {} threeDS session data validation failed",
              req.getThreeDSSessionData());
          return Mono.justOrEmpty(ABSTRACT_MESSAGE_WITH_PAYLOAD);
        }
        log.info("ACS callback {} threeDS session data successfully validated",
            req.getThreeDSSessionData());
        return Mono.justOrEmpty(req);
      } catch (Exception ex) {
        log.error("Error occurred during 3DS data decryption {}", req.getPayload(), ex);
        return Mono.justOrEmpty(ABSTRACT_MESSAGE_WITH_PAYLOAD);
      }
    });
  }

  public @NotNull Mono<? extends AbstractMessageWithPayload> validateParesData(
      @Nullable Mono<? extends AbstractMessageWithPayload> message,
      @Nullable Class<? extends Serializable> payloadClass) {
    if (Objects.isNull(message) || Objects.isNull(payloadClass)) {
      return Mono.empty();
    }
    return message.map(req -> {
      boolean isValid = isValidGUID(req.getMd());
      if (isValid) {
        if (validateParesSignature) {
          try {
            final var urlDecoded = safeDecode(req.getPayload());
            final var decode = compressorService.decompress(DECODER.decode(urlDecoded));
            isValid = xmlSignatureValidator.validateSignature(
                StringUtils.toEncodedString(decode, StandardCharsets.UTF_8));
          } catch (Exception e) {
            isValid = false;
          }
        }
      }
      req.setIsValid(isValid);
      req.setPayload(req.getIsValid() ? req.getPayload() : null);
      return req;
    });
  }

  public static boolean isValidGUID(String str) {
    if (StringUtils.isBlank(str)) {
      return false;
    }
    try {
      return UUID_PATTERN.matcher(str).matches();
    } catch (Exception e) {
      return false;
    }
  }

  public String safeDecode(String code) {
    return code.contains("%") ? URLDecoder.decode(code) : code;
  }
}