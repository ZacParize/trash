package ru.vtb.tsp.ia.epay.acsproxy.services;

import java.util.ArrayList;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Inflater;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CompressorService {

  public byte[] decompress(byte[] bytesToDecompress) {
    byte[] returnValues = null;
    final Inflater inflater = new Inflater();
    final int numberOfBytesToDecompress = bytesToDecompress.length;
    inflater.setInput(bytesToDecompress, 0, numberOfBytesToDecompress);
    final List<Byte> bytesDecompressedSoFar = new ArrayList<>();
    int numberOfBytesDecompressedThisTime;
    byte[] bytesDecompressedBuffer;
    try {
      while (!inflater.needsInput()) {
        bytesDecompressedBuffer = new byte[numberOfBytesToDecompress];
        numberOfBytesDecompressedThisTime = inflater.inflate(bytesDecompressedBuffer);
        for (int b = 0; b < numberOfBytesDecompressedThisTime; b++) {
          bytesDecompressedSoFar.add(bytesDecompressedBuffer[b]);
        }
      }
      returnValues = new byte[bytesDecompressedSoFar.size()];
      for (int b = 0; b < returnValues.length; b++) {
        returnValues[b] = bytesDecompressedSoFar.get(b);
      }
    } catch (DataFormatException e) {
      log.error("Pares unzip error {}", e.getMessage());
    } finally {
      inflater.end();
    }
    return returnValues;
  }

}