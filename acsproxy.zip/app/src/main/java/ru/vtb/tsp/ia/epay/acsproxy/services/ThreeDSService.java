package ru.vtb.tsp.ia.epay.acsproxy.services;

import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.components.AsyncRestTemplate;
import ru.vtb.tsp.ia.epay.acsproxy.controllers.ThreeDSController;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.utils.JV8Util;

@Slf4j
@Service
public class ThreeDSService {

  private static final String DEFAULT_VALUE = "";
  private static final String IP_HEADER = "Ip";
  private static final String X_REAL_IP_HEADER = "X-Real-IP";
  private static final String X_FORWARDED_FOR_HEADER = "X-Forwarded-For";
  private final AsyncRestTemplate asyncRestTemplate;
  private final String proxyUrl;

  @Autowired
  public ThreeDSService(AsyncRestTemplate asyncRestTemplate,
      @Value("${app.proxy.base-url}") String baseUrl,
      @Value("${app.proxy.endpoints.threeds-decision-path}") String path) {
    this.asyncRestTemplate = asyncRestTemplate;
    this.proxyUrl = baseUrl + path;
  }

  public @NotNull Mono<String> postThreeDSDecision(@NotNull Map<String, String> headers,
      @NotBlank String id,
      @NotNull ThreeDSDecisionCallbackDto requestBody) {
    if (Objects.isNull(requestBody)) {
      requestBody = ThreeDSDecisionCallbackDto.builder().build();
    }
    requestBody.setAccept(JV8Util.requireNonNullElse(headers.get(HttpHeaders.ACCEPT),
        JV8Util.requireNonNullElse(requestBody.getAccept(), DEFAULT_VALUE)));
    requestBody.setBrowserUserAgent(JV8Util.requireNonNullElse(headers.get(HttpHeaders.USER_AGENT),
        JV8Util.requireNonNullElse(requestBody.getBrowserUserAgent(), DEFAULT_VALUE)));
    requestBody.setBrowserIp(
        JV8Util.requireNonNullElse(requestBody.getBrowserIp(), getBrowserIp(headers)));
    log.info("3DS decision response {} processing {}", requestBody, id);
    return publish(headers, Mono.justOrEmpty(requestBody), id);
  }

  private String getBrowserIp(Map<String, String> header) {
    if (ObjectUtils.isEmpty(header)) {
      return DEFAULT_VALUE;
    }
    if (header.containsKey(IP_HEADER)) {
      return header.get(IP_HEADER);
    }
    if (header.containsKey(X_REAL_IP_HEADER)) {
      return header.get(X_REAL_IP_HEADER);
    }
    if (header.containsKey(X_FORWARDED_FOR_HEADER)) {
      return header.get(X_FORWARDED_FOR_HEADER);
    }
    return DEFAULT_VALUE;
  }

  public @NotNull Mono<String> publish(@NotNull Map<String, String> headers,
      @NotNull Mono<ThreeDSDecisionCallbackDto> request,
      @NotBlank String id) {
    return asyncRestTemplate.post(proxyUrl,
        headers,
        request,
        String.class,
        JV8Util.mapOf(ThreeDSController.ID_PATH_VARIABLE, id));
  }

}