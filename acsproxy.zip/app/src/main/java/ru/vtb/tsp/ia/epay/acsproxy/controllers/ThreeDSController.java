package ru.vtb.tsp.ia.epay.acsproxy.controllers;

import java.util.Map;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;
import ru.vtb.tsp.ia.epay.acsproxy.services.ThreeDSService;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class ThreeDSController {

  public static final String ID_PATH_VARIABLE = "id";
  private static final String THREEDS_DECISION = "/v1/transaction/{id}/threedsdecision";
  private final ThreeDSService service;

  @PostMapping(path = THREEDS_DECISION, produces = MediaType.APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<Mono<String>> doProxy(@RequestHeader Map<String, String> headers,
      @PathVariable(ID_PATH_VARIABLE) @NotEmpty String transactionId,
      @RequestBody @NotNull ThreeDSDecisionCallbackDto request) {
    headers.forEach((key, value) -> log.info("Header: < {} - {} >", key, value));
    return ResponseEntity.ok(service.postThreeDSDecision(headers, transactionId, request));
  }

}