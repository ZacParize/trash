package ru.vtb.tsp.ia.epay.acsproxy.configs;


import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.annotation.Validated;
import ru.vtb.tsp.ia.epay.acsproxy.configs.properties.ProxyForwardEndpoints;
import ru.vtb.tsp.ia.epay.acsproxy.configs.properties.Settings;
import ru.vtb.tsp.ia.epay.acsproxy.configs.properties.Ssl;

@Data
@Validated
@Configuration
@ConfigurationProperties(prefix = "app.proxy", ignoreUnknownFields = false)
public class ProxyConfig {

  @NotBlank
  private String baseUrl;

  @NotBlank
  private String hostHeader;

  @Positive
  private Integer timeout;

  @NotNull
  private Boolean sslEnabled;

  private Ssl ssl;

  private ProxyForwardEndpoints endpoints;

  private Settings settings;

}