package ru.vtb.tsp.ia.epay.acsproxy.controllers;

import java.io.IOException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.util.NestedServletException;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class ControllerExceptionHandler {

  @ExceptionHandler(IOException.class)
  public @NotNull ResponseEntity<?> handleIOException(@NotNull IOException ex) {
    log.error("Error occurred during handling ACS callback", ex);
    return ResponseEntity.ok().build();
  }

  @ExceptionHandler({ConnectException.class, MalformedURLException.class,
      UnknownHostException.class, NestedServletException.class})
  public @NotNull ResponseEntity<?> handleConnectException(@NotNull Exception ex) {
    log.error("Error occurred during proxy ACS callback", ex);
    return ResponseEntity.ok().build();
  }

  @ExceptionHandler(RuntimeException.class)
  public @NotNull ResponseEntity<?> handleConnectException(@NotNull RuntimeException ex) {
    log.error("Error occurred during request processing", ex);
    return ResponseEntity.ok().build();
  }

}