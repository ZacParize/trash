#!/bin/bash
function ComponentBuild() {
  gradle publish
}
"$@"