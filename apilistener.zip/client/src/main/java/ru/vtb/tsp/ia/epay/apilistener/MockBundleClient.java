package ru.vtb.tsp.ia.epay.apilistener;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Component
@ConditionalOnProperty(name = "bundle.mock", havingValue = "true")
public class MockBundleClient implements BundleApi {

  public BundleDto getByOrderCode(String orderCode) {
    return BundleDto.builder().build();
  }

  @Override
  public BundleDto getByTransactionCode(String transactionCode) {
    return BundleDto.builder().build();
  }
}