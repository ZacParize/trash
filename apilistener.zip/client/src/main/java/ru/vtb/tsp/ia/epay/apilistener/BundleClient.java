package ru.vtb.tsp.ia.epay.apilistener;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "bundleClient", url = "${bundle.url}", decode404 = true)
public interface BundleClient extends BundleApi {
}