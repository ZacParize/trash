package ru.vtb.tsp.ia.epay.apilistener.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.BundleClient;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Slf4j
@Component
@AllArgsConstructor
public class BundleClientImpl {

  private final BundleClient bundleClient;

  public BundleDto getByOrderCode(String orderCode) {
    log.info("Getting bundle by order code {}", orderCode);
    if (ObjectUtils.isEmpty(orderCode)) {
      return BundleDto.builder().build();
    }
    final var result = bundleClient.getByOrderCode(orderCode);
    log.info("Response {} bundle by order code {}", result, orderCode);
    return result;
  }

  public BundleDto getByTransactionCode(String txCode) {
    log.info("Bundle request by transactionCode = {}", txCode);
    if (ObjectUtils.isEmpty(txCode)) {
      return BundleDto.builder().build();
    }
    final var result = bundleClient.getByTransactionCode(txCode);
    log.info("Bundle result {} by transactionCode = {}", result, txCode);
    return result;
  }
}