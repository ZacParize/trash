plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}
configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("io.springfox", "springfox-bean-validators")
        exclude("io.springfox", "springfox-boot-starter")
        exclude("io.springfox", "springfox-core")
        exclude("io.springfox", "springfox-data-rest")
    }
}

repositories {
    repositories {
        maven {
            url = uri(extra["nexus.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
        maven {
            url = uri(extra["nexus.omni.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-domain")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")
    implementation("ru.vtb.dev.corp.ia.epay:epay-tokenization-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-fiscalization-api")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.core:jackson-databind")

    //swagger open api 3.0
    implementation("org.springdoc:springdoc-openapi-ui")
    implementation("io.swagger.core.v3:swagger-annotations")

    // Validation
    implementation("javax.validation:validation-api")
    implementation("commons-validator:commons-validator")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            versionMapping {
                usage("java-api") {
                    fromResolutionOf("runtimeClasspath")
                }
                usage("java-runtime") {
                    fromResolutionResult()
                }
            }
            artifactId = findProperty("app.name").toString() + "-api"
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

tasks.withType<Jar> {
    // Set jar file name
    enabled = true
}

tasks.bootJar {
    // Set bootJar file name
    enabled = false
}