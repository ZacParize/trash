package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SavedCardResponseDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  @JsonProperty("id")
  private String id;

  @JsonProperty("cardNumber")
  private String cardNumber;

  @JsonProperty("expirationDate")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime expirationDate;

  @JsonProperty("paymentSystem")
  private String paymentSystem;

  @JsonProperty("bank")
  private String bank;
}