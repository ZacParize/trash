package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PayLinkOrderObjectResponseDto implements Serializable {

  @JsonProperty("sourceSystem")
  private SourceSystem sourceSystem;

  public SourceSystem getSourceSystem() {
    return this.sourceSystem;
  }
}
