package ru.vtb.tsp.ia.epay.apilistener.dtos.requests;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
@RequiredArgsConstructor
public enum TypeRequest {

  @JsonProperty("card")
  CARD("card"),

  @JsonProperty("account")
  ACCOUNT("account");

  private final String value;

}