package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.DestinationRequestDto;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class A2cDestinationRequestDto<T extends Serializable> extends DestinationRequestDto<T> implements Serializable {
}
