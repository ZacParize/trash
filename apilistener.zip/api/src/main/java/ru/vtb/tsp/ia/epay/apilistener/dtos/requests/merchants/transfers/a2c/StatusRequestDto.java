package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class StatusRequestDto implements Serializable {

  @JsonProperty("changedAt")
  LocalDateTime changedAt;

  @JsonProperty("description")
  String description;
}
