package ru.vtb.tsp.ia.epay.apilistener.validation.bundle;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import java.io.IOException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;

public class TaxTypeDeserializer extends StdDeserializer<TaxRate> {

  public TaxTypeDeserializer() {
    this(TaxRate.class);
  }

  protected TaxTypeDeserializer(Class<?> vc) {
    super(vc);
  }

  @Override
  public TaxRate deserialize(JsonParser p, DeserializationContext ctxt) {
    try {
      return TaxRate.fromName(p.getValueAsString());
    } catch (IOException e) {
      throw new BundleValidationException(ApplicationException.BUNDLE_ERROR_TAXTYPE_REQUIRED);
    }
  }
}
