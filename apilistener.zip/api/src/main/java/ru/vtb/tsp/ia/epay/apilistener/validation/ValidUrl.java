package ru.vtb.tsp.ia.epay.apilistener.validation;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;

/**
 * The string must be an URL address.
 */
@Documented
@Constraint(validatedBy = UrlValidator.class)
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidUrl {

  /**
   * The message.
   */
  String message() default "URL is not valid";

  /**
   * The groups.
   */
  Class<?>[] groups() default {};

  /**
   * The payload.
   */
  Class<? extends Payload>[] payload() default {};

  /**
   * Allow local.
   */
  boolean allowLocal() default false;

  /**
   * Allow tld.
   */
  boolean allowTld() default false;

}
