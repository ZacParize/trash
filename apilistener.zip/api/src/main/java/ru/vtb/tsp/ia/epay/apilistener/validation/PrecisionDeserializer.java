package ru.vtb.tsp.ia.epay.apilistener.validation;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

public class PrecisionDeserializer extends StdDeserializer<Double> {

  private static final int SCALE = 2;

  public PrecisionDeserializer() {
    this(Double.class);
  }

  public PrecisionDeserializer(Class<?> vc) {
    super(vc);
  }

  @Override
  public Double deserialize(JsonParser p, DeserializationContext cxt) throws IOException {
    return BigDecimal.valueOf(p.getDoubleValue())
        .setScale(SCALE, RoundingMode.HALF_UP).doubleValue();
  }

}