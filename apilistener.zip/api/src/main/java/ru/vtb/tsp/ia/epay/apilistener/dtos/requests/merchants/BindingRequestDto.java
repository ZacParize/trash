package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BindingRequestDto implements Serializable {

  @JsonProperty("bindingType")
  private BindingType bindingType;

  @JsonProperty("operationType")
  private BindingCategory operationType;

  @JsonProperty("bindingId")
  private UUID bindingId;
}
