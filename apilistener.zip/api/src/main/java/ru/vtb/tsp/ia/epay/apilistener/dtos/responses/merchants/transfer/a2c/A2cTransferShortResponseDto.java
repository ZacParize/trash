package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.StatusResponseDto;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class A2cTransferShortResponseDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  @JsonProperty("orderId")
  protected String orderId;

  @JsonProperty("orderCode")
  protected String orderCode;

  @JsonProperty("createdAt")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  protected LocalDateTime createdAt;

  @JsonProperty("amount")
  protected AmountResponseDto amount;

  @JsonProperty("status")
  protected StatusResponseDto status;

  @JsonProperty("sourceSystem")
  protected SourceSystem sourceSystem;

}