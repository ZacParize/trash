package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.AbstractTransferRequest;

@Data
@NoArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class A2cTransferRequestDto extends AbstractTransferRequest<CardRequestDto> {

}