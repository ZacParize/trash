package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentObjectResponseDto implements Serializable {

  @JsonProperty("paymentId")
  private String paymentId;

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderName")
  private String orderName;

  @JsonProperty("createdAt")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
  private LocalDateTime createdAt;

  @JsonProperty("amount")
  private AmountResponseDto amount;

  @JsonProperty("status")
  private RefundStatusDto status;

  @JsonProperty("paymentData")
  private PaymentDataResponseDto paymentData;


}
