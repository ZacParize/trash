package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.math.BigDecimal;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.validation.bundle.TaxTypeDeserializer;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TaxParamsDto {

  @NotNull
  @JsonProperty("taxType")
  @JsonDeserialize(using = TaxTypeDeserializer.class)
  private TaxRate taxType;

  @PositiveOrZero
  @DecimalMax(value = "99999999.99", inclusive = true, message = "Значение taxSum не может быть больше 99999999.99")
  @Digits(integer = 8, fraction = 2, message = "Неверный формат числа")
  @JsonProperty("taxSum")
  private BigDecimal taxSum;

}
