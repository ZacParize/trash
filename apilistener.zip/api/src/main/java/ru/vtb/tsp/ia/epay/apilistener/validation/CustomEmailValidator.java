package ru.vtb.tsp.ia.epay.apilistener.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.validator.routines.EmailValidator;

/**
 * Checks that a given character sequence (e.g. string) is a well-formed email address.
 */
public class CustomEmailValidator implements ConstraintValidator<ValidEmail, String> {

  private EmailValidator validator;

  @Override
  public void initialize(ValidEmail annotation) {
    validator = EmailValidator.getInstance(annotation.allowLocal(), annotation.allowTld());
  }

  @Override
  public boolean isValid(String email, ConstraintValidatorContext context) {
    return email == null || validator.isValid(email);
  }
}