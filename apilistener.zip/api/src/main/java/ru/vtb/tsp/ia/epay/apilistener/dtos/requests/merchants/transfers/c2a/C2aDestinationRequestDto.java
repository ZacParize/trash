package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.c2a;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;
import lombok.EqualsAndHashCode;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.CustomerTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.DestinationRequestDto;

@Data
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class C2aDestinationRequestDto<T extends Serializable> extends
    DestinationRequestDto<T> implements Serializable {

  @JsonProperty("customer")
  CustomerTransferRequestDto customer;
}
