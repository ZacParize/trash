package ru.vtb.tsp.ia.epay.apilistener.dtos.requests;

public enum PaymentSystem {
  MIR,
  VISA,
  MC
}
