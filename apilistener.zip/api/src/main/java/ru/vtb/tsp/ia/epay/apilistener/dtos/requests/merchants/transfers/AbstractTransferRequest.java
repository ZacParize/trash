package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@SuperBuilder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public abstract class AbstractTransferRequest<T extends Serializable> implements Serializable {

  @NotNull
  @Size(max = 64)
  @JsonProperty("orderId")
  protected String orderId;

  @JsonProperty("description")
  @NotNull
  protected String description;

  @Valid
  @JsonProperty("amount")
  protected AmountRequestDto amount;

  @JsonProperty("source")
  protected SourceRequestDto source;

  @JsonProperty("destination")
  @Valid
  protected DestinationRequestDto<T> destination;
}
