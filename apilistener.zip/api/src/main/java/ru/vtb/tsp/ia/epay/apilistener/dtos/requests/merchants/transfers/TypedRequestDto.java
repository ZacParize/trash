package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.TypeRequest;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class TypedRequestDto<T extends Serializable> implements Serializable {

  @NotNull
  @JsonProperty("type")
  private TypeRequest type;

  @JsonProperty("object")
  @NotNull
  @Valid
  private T object;
}
