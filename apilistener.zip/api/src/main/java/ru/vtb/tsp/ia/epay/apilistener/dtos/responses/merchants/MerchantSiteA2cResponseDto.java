package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteA2cResponseDto implements Serializable {

  @JsonProperty("merchantId")
  protected String merchantId;

  @JsonProperty("mstId")
  protected String mstId;

  @JsonProperty("name")
  protected String name;

  @JsonProperty("account")
  protected String account;

}