package ru.vtb.tsp.ia.epay.apilistener.validation;

import java.util.Arrays;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

public class SourceSystemSubSetValidator
    implements ConstraintValidator<SourceSystemSubSet, SourceSystem> {

  private List<SourceSystem> listOfSubset;

  @Override
  public void initialize(SourceSystemSubSet constraint) {
    this.listOfSubset = Arrays.asList(constraint.anyOf());
  }

  @Override
  public boolean isValid(SourceSystem value, ConstraintValidatorContext context) {
    return value == null || listOfSubset.contains(value);
  }

}