package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypedResponseDto;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderObjectResponseDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderCode")
  private String orderCode;

  @JsonProperty("status")
  private OrderStatusDto status;

  @JsonProperty("createdAt")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime createdAt;

  @JsonProperty("payUrl")
  private String payUrl;

  @JsonProperty("expire")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime expire;

  @JsonProperty("amount")
  private AmountResponseDto amount;

  @JsonProperty("preparedPayments")
  private List<TypedResponseDto<? extends Serializable>> preparedPayments;

  @JsonProperty("transactions")
  private Map<String, List<TypedResponseDto<? extends Serializable>>> transactions;

  @JsonProperty("sourceSystem")
  private SourceSystem sourceSystem;

}