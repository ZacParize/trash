package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.c2a;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Valid
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountRequestDto implements Serializable {

  @NotNull
  @JsonProperty("account")
  String account;

  @NotNull
  @JsonProperty("bic")
  String bic;
}
