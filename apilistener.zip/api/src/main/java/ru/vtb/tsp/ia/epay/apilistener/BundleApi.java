package ru.vtb.tsp.ia.epay.apilistener;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.constraints.NotNull;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

public interface BundleApi {

  String ORDER_CODE_PATH_VARIABLE = "orderCode";
  String TX_CODE_PATH_VARIABLE = "transactionCode";

  @Operation(summary = "Get bundle by order code", description = "Get bundle by order code")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = BundleDto.class))
  })
  @GetMapping(path = "/api/v1/bundle/order/{" + ORDER_CODE_PATH_VARIABLE + "}",
      produces = APPLICATION_JSON_VALUE)
  @NotNull BundleDto getByOrderCode(@PathVariable(ORDER_CODE_PATH_VARIABLE) String orderCode);

  @Operation(summary = "Get bundle by transaction code", description = "Get bundle by transaction code")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = BundleDto.class))
  })
  @GetMapping(path = "/api/v1/bundle/refund/{" + TX_CODE_PATH_VARIABLE + "}",
      produces = APPLICATION_JSON_VALUE)
  @NotNull BundleDto getByTransactionCode(@PathVariable(TX_CODE_PATH_VARIABLE) String transactionCode);

}