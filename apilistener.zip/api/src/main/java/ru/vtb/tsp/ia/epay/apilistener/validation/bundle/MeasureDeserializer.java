package ru.vtb.tsp.ia.epay.apilistener.validation.bundle;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;

public class MeasureDeserializer extends StdDeserializer<UnitsMeasure> {

  public MeasureDeserializer() {
    this(UnitsMeasure.class);
  }

  protected MeasureDeserializer(Class<?> vc) {
    super(vc);
  }

  @Override
  public UnitsMeasure deserialize(JsonParser p, DeserializationContext ctxt) {
    try {
      return UnitsMeasure.fromName(p.getValueAsString());
    } catch (Exception e) {
      throw new BundleValidationException(ApplicationException.BUNDLE_ERROR_MEASURE);
    }
  }
}
