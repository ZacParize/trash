package ru.vtb.tsp.ia.epay.apilistener.validation;

import java.util.Arrays;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.util.ObjectUtils;

/**
 * Checks that a given character sequence (e.g. string) is a correct currency code from default
 * or custom list of codes.
 */
public class CurrencyUnitValidator implements ConstraintValidator<Currency, String> {

  private static final List<String> DEFAULT_CURRENCY_LIST = Arrays.asList("RUB", "USD", "EUR",
      "GBP", "JPY", "CHF", "CNY", "RUR");
  private List<String> customCurrencyUnits;

  @Override
  public void initialize(Currency annotation) {
    customCurrencyUnits = Arrays.asList(annotation.value());
  }

  @Override
  public boolean isValid(String value, ConstraintValidatorContext context) {
    if (value == null) {
      return false;
    }
    if (ObjectUtils.isEmpty(customCurrencyUnits)) {
      return DEFAULT_CURRENCY_LIST.contains(value);
    } else {
      return customCurrencyUnits.contains(value);
    }
  }
}