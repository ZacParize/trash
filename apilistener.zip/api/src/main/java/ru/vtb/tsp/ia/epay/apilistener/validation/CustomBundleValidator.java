package ru.vtb.tsp.ia.epay.apilistener.validation;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleItemRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.TaxParamsDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;

public class CustomBundleValidator implements
    ConstraintValidator<ValidBundle, BundleRequestDto> {

  private static final String NOT_NULL_VALIDATOR = "NotNullValidator";
  @Autowired
  private Validator validator;

  @Override
  public boolean isValid(BundleRequestDto value, ConstraintValidatorContext context) {
    if (Objects.isNull(value) || CollectionUtils.isEmpty(value.getItems())) {
      return true;
    }
    Set<ConstraintViolation<BundleItemRequestDto>> bundleConstraintViolations = new HashSet<>();
    Set<ConstraintViolation<TaxParamsDto>> taxParamsConstraintViolations = new HashSet<>();
    for (BundleItemRequestDto dto : value.getItems()) {
      bundleConstraintViolations.addAll(validator.validate(dto));
      taxParamsConstraintViolations.addAll(validator.validate(dto.getTaxParams()));
    }
    bundleConstraintViolations.stream().forEach(
        constraintViolation -> {
          final var fieldName = constraintViolation
              .getPropertyPath().toString().toLowerCase();
          switch (fieldName) {
            case "name" -> throwException(constraintViolation,
                ApplicationException.BUNDLE_ERROR_NAME_REQUIRED,
                ApplicationException.BUNDLE_ERROR_NAME);
            case "code" -> throw new BundleValidationException(
                ApplicationException.BUNDLE_ERROR_CODE);
            case "price" -> throwException(constraintViolation,
                ApplicationException.BUNDLE_ERROR_PRICE_REQUIRED,
                ApplicationException.BUNDLE_ERROR_PRICE);
            case "measure" -> throw new BundleValidationException(
                ApplicationException.BUNDLE_ERROR_MEASURE);
            case "quantity" -> throwException(constraintViolation,
                ApplicationException.BUNDLE_ERROR_QUANTITY_REQUIRED,
                ApplicationException.BUNDLE_ERROR_QUANTITY);
            case "positionid" -> throwException(constraintViolation,
                ApplicationException.BUNDLE_ERROR_POSITION_REQUIRED,
                ApplicationException.BUNDLE_ERROR_POSITION);
            case "amount" -> {
              throwException(constraintViolation,
                  ApplicationException.BUNDLE_ERROR_AMOUNT_REQUIRED,
                  ApplicationException.BUNDLE_ERROR_AMOUNT);
            }
          }
        }
    );
    taxParamsConstraintViolations.stream().forEach(constraintViolation -> {
      final var fieldName = constraintViolation
          .getPropertyPath().toString().toLowerCase();
      switch (fieldName) {
        case "taxtype" -> throw new BundleValidationException(
            ApplicationException.BUNDLE_ERROR_TAXTYPE_REQUIRED);
        case "taxsum" -> throw new BundleValidationException(
            ApplicationException.BUNDLE_ERROR_TAXSUM);
        case "discount" -> throw new BundleValidationException(
            ApplicationException.BUNDLE_ERROR_DISCOUNT);
        case "userdata" -> throw new BundleValidationException(
            ApplicationException.BUNDLE_ERROR_USERDATA);
      }
    });
    if (bundleConstraintViolations.size() > 0 || taxParamsConstraintViolations.size() > 0) {
      throw new BundleValidationException(ApplicationException.VALIDATION_ERROR);
    }
    return true;
  }

  private void throwException(ConstraintViolation<?> constraintViolation,
      ApplicationException notNullException, ApplicationException formatException) {
    constraintViolation.getConstraintDescriptor().getConstraintValidatorClasses()
        .forEach(c -> {
          if (NOT_NULL_VALIDATOR.equalsIgnoreCase(c.getSimpleName())) {
            throw new BundleValidationException(notNullException);
          } else {
            throw new BundleValidationException(formatException);
          }
        });
  }

}
