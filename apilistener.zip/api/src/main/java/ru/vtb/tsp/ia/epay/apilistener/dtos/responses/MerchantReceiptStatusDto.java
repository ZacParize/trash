package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantReceiptStatusDto {

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderCode")
  private UUID orderCode;

  @JsonProperty("receipts")
  private List<MerchantReceiptDataDto> receipts;


}
