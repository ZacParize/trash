package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.CryptoResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.MerchantSiteResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.TransactionResponseDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderInfoResponseDto implements Serializable {

  @JsonProperty("order")
  OrderInfoObjectResponseDto order;

  @JsonProperty("customer")
  OrderInfoCustomerResponseDto customer;

  @JsonProperty("merchantSite")
  MerchantSiteResponseDto merchantSite;

  @JsonProperty("transactions")
  List<TransactionResponseDto> transactions;

  @JsonProperty("crypto")
  CryptoResponseDto crypto;
}