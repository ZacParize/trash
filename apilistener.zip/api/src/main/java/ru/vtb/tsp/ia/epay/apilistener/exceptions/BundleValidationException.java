package ru.vtb.tsp.ia.epay.apilistener.exceptions;

import java.util.Optional;
import javax.validation.ConstraintDeclarationException;
import lombok.Getter;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ErrorDto;

@Getter
public class BundleValidationException extends ConstraintDeclarationException {

  protected ApplicationException exception;
  private String traceId;

  public BundleValidationException() {
  }

  public BundleValidationException(ApplicationException exception) {
    this.exception = exception;
  }

  public BundleValidationException(ApplicationException exception, String traceId) {
    this.exception = exception;
    this.traceId = traceId;
  }

  public BundleValidationException(String message) {
    super(message);
  }

  public BundleValidationException(String traceId, String message, Throwable cause) {
    super(message, cause);
    this.traceId = traceId;
  }

  public BundleValidationException(String traceId, Throwable cause) {
    super(cause);
    this.traceId = traceId;
  }

  public String getId() {
    return Optional.ofNullable(exception).map(ApplicationException::getId).orElse(null);
  }

  public Integer getHttpCode() {
    return Optional.ofNullable(exception).map(ApplicationException::getHttpCode).orElse(null);
  }

  public String getMessage() {
    return Optional.ofNullable(exception).map(ApplicationException::getMessage).orElse(null);
  }

  public String getDescription() {
    return Optional.ofNullable(exception).map(ApplicationException::getDescription).orElse(null);
  }

  public ErrorDto toDto() {
    return ErrorDto.builder()
        .id(getId())
        .message(getMessage())
        .description(getDescription() + " (" + getId() + ")")
        .traceId(traceId)
        .build();
  }

}