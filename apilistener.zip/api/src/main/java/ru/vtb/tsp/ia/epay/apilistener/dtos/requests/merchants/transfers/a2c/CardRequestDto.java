package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardRequestDto implements Serializable {

  @NotBlank
  @Size(max = 1024)
  @JsonProperty("encryptedPan")
  private String encryptedPan;

}