package ru.vtb.tsp.ia.epay.apilistener.dtos.threeds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 25.10.2021
 */
@Data
@JsonIgnoreProperties
public class ThreeDSParesCallbackPost implements Serializable {

    @JsonProperty("pares")
    private String pares;
    @JsonProperty("md")
    private String md;
    @JsonProperty("isValid")
    private boolean isValid;
}
