package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderInfoObjectResponseDto implements Serializable {

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("name")
  private String name;

  @JsonProperty("state")
  private OrderState state;

  @JsonProperty("type")
  private OrderType type;

  @JsonProperty("secondsToExpire")
  private Long secondsToExpire;

  @JsonProperty("amount")
  private AmountResponseDto amount;

  @JsonProperty("remainingAmount")
  private AmountResponseDto remainingAmount;

  @JsonProperty("backUrl")
  private String backUrl;

  @JsonInclude(Include.NON_NULL)
  @JsonProperty("returnUrl")
  private String returnUrl;

}