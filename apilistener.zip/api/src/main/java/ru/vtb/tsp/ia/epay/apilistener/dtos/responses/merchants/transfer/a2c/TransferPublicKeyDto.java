package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class TransferPublicKeyDto implements Serializable, JsonObject {
  @JsonProperty("value")
  private String value;
}
