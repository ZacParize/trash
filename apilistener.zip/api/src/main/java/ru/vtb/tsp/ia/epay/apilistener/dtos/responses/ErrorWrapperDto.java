package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorWrapperDto implements Serializable {

  @JsonProperty("error")
  private ErrorDto error;

  public static ErrorWrapperDto of(ErrorDto errorDto) {
    return Optional.ofNullable(errorDto)
        .map(error -> ErrorWrapperDto.builder()
            .error(ErrorDto.builder()
                .id(error.getId())
                .message(error.getMessage())
                .description(error.getDescription())
                .traceId(error.getTraceId())
                .build())
            .build())
        .orElse(null);
  }

}
