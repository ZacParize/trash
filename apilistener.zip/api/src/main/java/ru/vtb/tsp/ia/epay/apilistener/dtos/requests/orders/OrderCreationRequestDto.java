package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BindingRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.CustomerRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentTypeRequest;

import ru.vtb.tsp.ia.epay.apilistener.validation.ValidBundle;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidUrl;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderCreationRequestDto implements Serializable {

  @NotNull
  @Size(max = 64)
  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderName")
  private String orderName;

  @JsonProperty("expire")
  private LocalDateTime expire;

  @Valid
  @JsonProperty("customer")
  private CustomerRequestDto customer;

  @Valid
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @JsonProperty("returnPaymentData")
  private PaymentTypeRequest returnPaymentData;

  @JsonProperty("sourceSystem")
  private SourceSystem sourceSystem;

  @ValidUrl
  @Size(max = 255)
  @JsonProperty("returnUrl")
  private String returnUrl;

  @JsonProperty("binding")
  private BindingRequestDto binding;

  @JsonProperty("bundle")
  @ValidBundle
  private BundleRequestDto bundle;
}