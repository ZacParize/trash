package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerTransferRequestDto implements Serializable {

  @Size(max = 35)
  @NotBlank
  @JsonProperty("fullname")
  private String fullname;

  @Size(max = 35)
  @NotBlank
  @JsonProperty("name")
  private String name;

  @Size(max = 35)
  @NotBlank
  @JsonProperty("surname")
  private String surname;
}
