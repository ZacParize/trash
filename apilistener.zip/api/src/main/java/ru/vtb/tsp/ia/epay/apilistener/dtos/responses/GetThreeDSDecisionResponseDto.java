package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetThreeDSDecisionResponseDto implements Serializable {

  /**
   * Флаг определяющий Challenge Flow или Frictionless
   */
  @JsonProperty("isChallengeFlow")
  private Boolean isChallengeFlow;

  /**
   * Какие-то данные (Challenge Flow)
   */
  @JsonProperty("threeDSSessionData")
  private String threeDSSessionData;

  /**
   * CReq полученный от мультикарты для передачи в ACS (Challenge Flow)
   */
  @JsonProperty("cReq")
  private String cReq;

  /**
   * URL сайта мерчанта (Challenge Flow)
   */
  @JsonProperty("backUrl")
  @Deprecated
  private String merchantUrl;

  /**
   * Статус запроса (PENDING/SUCCESS)
   */
  @JsonProperty("threeDSDecisionStatus")
  private String threeDSDecisionStatus;

  /**
   * URL для переадресации покупателя на страницу доп.  аутентификации покупателя на странице ACS
   * при ChallengeFlow
   */
  @JsonProperty("otpPageUrl")
  private String otpPageUrl;

}