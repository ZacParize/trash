package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = "JSON Web Key")
public class MirPayJsonWebKeyDto implements Serializable {

  /**
   * Серийный номер сертификата X.509, число в hex формате.
   */
  @JsonProperty("kid")
  private String kid;

  /**
   * Семейство криптографических алгоритмов, используемых с ключом. Допустимые значения - RSA.
   */
  @JsonProperty("kty")
  private String kty;

  /**
   * Допустимое использование открытого ключа. "sig" – проверка подписи данных. "enc" – шифрование
   * данных
   */
  @JsonProperty("use")
  private String use;

  /**
   * Цепочка сертификатов X.509. Первая запись в массиве — это конечный сертификат ТСП. Также
   * обязательно присутствие сертификата промежуточного Удостоверяющего центра: • Acquirer SubCA –
   * при схеме взаимодействия ТСП с Эквайрером напрямую • Concentrator SubCA – при схеме
   * взаимодействия ТСП через Агрегатора
   */
  @JsonProperty("x5c")
  private List<String> x5c;
}
