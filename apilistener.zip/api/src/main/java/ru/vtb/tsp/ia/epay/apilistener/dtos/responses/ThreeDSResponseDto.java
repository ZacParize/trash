package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(nullable = true)
public class ThreeDSResponseDto implements Serializable {

  @JsonProperty("isEnabled")
  @Schema(name = "isEnabled", defaultValue = "false", example = "true")
  private boolean isEnabled;

  @JsonProperty("version")
  @Schema(name = "version", defaultValue = "null", nullable = true, example = "1.0")
  private String version;

  @JsonProperty("isChallengeFlowPassed")
  private boolean isChallengeFlowPassed;

}