package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentCardRequest implements PaymentRequest, Serializable {

  @Size(max = 64)
  @NotBlank
  private String orderId;
  @NotNull
  private UUID orderCode;
  @Valid
  @NotNull
  private CardPaymentData paymentData;

}
