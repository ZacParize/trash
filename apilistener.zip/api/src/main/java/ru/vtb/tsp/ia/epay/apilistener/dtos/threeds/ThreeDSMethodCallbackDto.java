package ru.vtb.tsp.ia.epay.apilistener.dtos.threeds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ThreeDSMethodCallbackDto implements Serializable {

  @JsonProperty("threeDSMethodData")
  private String threeDSMethodData;

  @JsonProperty("isValid")
  private boolean isValid;
}
