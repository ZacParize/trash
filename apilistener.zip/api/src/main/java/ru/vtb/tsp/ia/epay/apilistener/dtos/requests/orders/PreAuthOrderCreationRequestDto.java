package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.CustomerRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidUrl;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PreAuthOrderCreationRequestDto implements Serializable {

  @NotNull
  @Size(max = 64)
  @JsonProperty("orderId")
  private String orderId;

  @Size(max = 255)
  @JsonProperty("orderName")
  private String orderName;

  @JsonProperty("expire")
  private LocalDateTime expire;

  @Valid
  @JsonProperty("customer")
  private CustomerRequestDto customer;

  @Valid
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @ValidUrl
  @Size(max = 255)
  @JsonProperty("returnUrl")
  private String returnUrl;

}
