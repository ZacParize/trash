package ru.vtb.tsp.ia.epay.apilistener.dtos.requests;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@JsonFormat(
    shape = Shape.STRING
)
public enum Version3DS {
  V1_0,
  V2_0
}
