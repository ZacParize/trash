package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderStatusDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
@EqualsAndHashCode(callSuper = false)
@JsonIgnoreProperties(ignoreUnknown = true)
public class PreparedPaymentsObjectDto implements Serializable {

  @JsonProperty("url")
  private String url;
  @JsonProperty("amount")
  private AmountResponseDto amount;
  @JsonProperty("status")
  private OrderStatusDto status;

}
