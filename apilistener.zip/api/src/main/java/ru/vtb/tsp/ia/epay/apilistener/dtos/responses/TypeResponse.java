package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum TypeResponse {

  @JsonProperty("ORDER")
  ORDER("order"),

  @JsonProperty("REFUND")
  REFUND("refund"),

  @JsonProperty("PAYMENT")
  PAYMENT("payment"),

  @JsonProperty("TRANSFER")
  TRANSFER("transfer");

  private final String value;

}