package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSResponseDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema
public class TransactionResponseDto implements Serializable {

  @JsonProperty("paymentMethod")
  private String paymentMethod;

  @JsonProperty("transactionCode")
  private String transactionCode;

  @JsonProperty("transactionStatus")
  private String transactionStatus;

  @JsonProperty("createdAt")
  private String createdAt;

  @JsonProperty("threeDS")
  @Schema(name = "threeDS")
  private ThreeDSResponseDto threeDS;

  @JsonProperty("amount")
  @Schema(name = "amount")
  private AmountResponseDto amount;

}