package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AuditBundleDto {
    private String positionId;
    private String name;
    private String price;
    private String quantity;
    private String taxType;
    private String amount;

    @Override
    public String toString() {
        return "{" +
                "positionId: " + positionId + ", " +
                "name: " + name + ", " +
                "price: " + price + ", " +
                "quantity: " + quantity + ", " +
                "taxType: " + taxType + ", " +
                "amount: " + amount +
                "}";
    }
}
