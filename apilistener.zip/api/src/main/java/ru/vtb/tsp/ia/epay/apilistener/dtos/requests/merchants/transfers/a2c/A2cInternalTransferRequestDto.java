package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.DestinationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.validation.SourceSystemSubSet;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class A2cInternalTransferRequestDto implements Serializable {

  @Size(max = 64)
  @NotBlank
  @JsonProperty("orderId")
  private String orderId;

  @Size(max = 255)
  @NotBlank
  @JsonProperty("description")
  private String description;

  @Valid
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @Valid
  @JsonProperty("destination")
  protected DestinationRequestDto<CardRequestDto> destination;

  @NotNull
  @SourceSystemSubSet(anyOf = { SourceSystem.IBLK })
  @JsonProperty("sourceSystem")
  private SourceSystem sourceSystem;

}