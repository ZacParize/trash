package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.List;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleRequestDto implements Serializable {

  @Valid
  private FiscalInfoDto fiscalInfo;

  @Valid
  private List<BundleItemRequestDto> items;

}
