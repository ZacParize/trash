package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.Valid;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidEmail;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema
public class CardPaymentRequestDto implements PaymentRequest, Serializable {

  @ValidEmail
  @JsonProperty("email")
  @Schema(name = "email", nullable = true, defaultValue = "null", example = "example@example.com")
  private String email;

  @Valid
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @JsonProperty("encryptedPan")
  private String encryptedPan;

  @JsonProperty("expiryDate")
  private String expiryDate;

  @JsonProperty("encryptedCvv")
  private String encryptedCvv;

  @JsonProperty("cardHolder")
  private String cardHolder;

  @JsonProperty("rememberCard")
  private Boolean rememberCard;

  @JsonIgnore
  private String mstOrderCode;

}