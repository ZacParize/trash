package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.MerchantSiteA2cResponseDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
@SuperBuilder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class A2cTransferExtendedResponseDto extends A2cTransferShortResponseDto {

  @JsonProperty("description")
  protected String description;

  @JsonProperty("merchantSite")
  protected MerchantSiteA2cResponseDto merchantSite;

}