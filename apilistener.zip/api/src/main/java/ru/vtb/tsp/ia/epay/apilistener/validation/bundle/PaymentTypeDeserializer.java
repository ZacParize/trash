package ru.vtb.tsp.ia.epay.apilistener.validation.bundle;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;

public class PaymentTypeDeserializer extends StdDeserializer<PaymentType> {

  public PaymentTypeDeserializer() {
    this(PaymentType.class);
  }

  protected PaymentTypeDeserializer(Class<?> vc) {
    super(vc);
  }

  @Override
  public PaymentType deserialize(JsonParser p, DeserializationContext ctxt) {
    try {
      return PaymentType.fromName(p.getValueAsString());
    } catch (Exception e) {
      throw new BundleValidationException(ApplicationException.BUNDLE_PAYMENT_TYPE_ERROR);
    }

  }
}
