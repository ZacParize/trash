package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import lombok.EqualsAndHashCode;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@SuperBuilder(toBuilder = true)
@ToString(callSuper = true)
@JsonInclude(Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@JsonIgnoreProperties(value = {"sourceSystem"}, ignoreUnknown = true)
public class OrderObjectIgnoreSourceSystemResponseDto extends OrderObjectResponseDto {

}