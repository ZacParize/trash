package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidEmail;

@Data
@Valid
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerRequestDto implements Serializable {

  @ValidEmail
  @JsonProperty("email")
  private String email;

  @Size(max = 255)
  @JsonProperty("customerId")
  private String customerId;

  @Size(max = 16)
  @JsonProperty("phone")
  private String phone;

}