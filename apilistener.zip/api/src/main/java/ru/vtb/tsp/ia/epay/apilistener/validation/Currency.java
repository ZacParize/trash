package ru.vtb.tsp.ia.epay.apilistener.validation;


import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.CONSTRUCTOR;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import javax.validation.Constraint;
import javax.validation.Payload;
import ru.vtb.tsp.ia.epay.apilistener.validation.Currency.List;

/**
 * The string must be correct currency unit.
 */
@Documented
@Constraint(validatedBy = CurrencyUnitValidator.class)
@Repeatable(List.class)
@Target({METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE})
@Retention(RUNTIME)
public @interface Currency {

  String message() default "currency unit is not valid";
  Class<?>[] groups() default { };
  Class<? extends Payload>[] payload() default { };
  /**
   * The currency unit codes (e.g. USD, EUR...) being accepted.
   */
  String[] value() default { };
  /**
   * Defines several {@code @Currency} annotations on the same element.
   */
  @Target({ METHOD, FIELD, ANNOTATION_TYPE, CONSTRUCTOR, PARAMETER, TYPE_USE })
  @Retention(RUNTIME)
  @Documented
  public @interface List {
    Currency[] value();
  }
}
