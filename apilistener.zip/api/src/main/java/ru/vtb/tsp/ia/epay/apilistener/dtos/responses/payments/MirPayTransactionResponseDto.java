package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = "Информация о созданной транзакции Mir Pay")
public class MirPayTransactionResponseDto implements Serializable {

  @JsonProperty("paymentMethod")
  private String paymentMethod;

  @JsonProperty("transactionCode")
  private String transactionCode;

  @JsonProperty("transactionStatus")
  private String transactionStatus;

  @JsonProperty("createdAt")
  private String createdAt;

  /**
   * Universal link для оплаты заказа через Mir Pay.
   */
  @JsonProperty("mirPayLink")
  private String mirPayLink;

}