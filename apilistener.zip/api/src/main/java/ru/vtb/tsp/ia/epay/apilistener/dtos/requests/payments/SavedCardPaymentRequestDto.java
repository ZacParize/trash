package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidEmail;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema
public class SavedCardPaymentRequestDto implements Serializable {

  //nullable в сваггере
  @ValidEmail
  @JsonProperty("email")
  @Schema(name = "email", defaultValue = "null", nullable = true, example = "example@example.com")
  private String email;

  @Valid
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @NotNull
  @JsonProperty("savedCardId")
  @Schema(name = "savedCardId", defaultValue = "savedCardId", nullable = true)
  private String savedCardId;
}