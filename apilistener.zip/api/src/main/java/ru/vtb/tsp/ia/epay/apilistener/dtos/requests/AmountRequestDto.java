package ru.vtb.tsp.ia.epay.apilistener.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.io.Serializable;
import javax.validation.constraints.Max;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.validation.Currency;
import ru.vtb.tsp.ia.epay.apilistener.validation.PrecisionDeserializer;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AmountRequestDto implements Serializable {

  @NotNull
  @Positive
  @Max(10_000_000_000L)
  @JsonProperty("value")
  @JsonDeserialize(using = PrecisionDeserializer.class)
  private Double value;

  @NotNull
  @Currency
  @JsonProperty("code")
  private String code;
}