package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum PaymentTypeResponse {

  @JsonProperty("sbp")
  SBP("sbp"),

  @JsonProperty("card")
  CARD("card"),

  @JsonProperty("invoice")
  INVOICE("invoice"),

  @JsonProperty("mir_pay")
  MIR_PAY("mir_pay");

  private final String value;

}