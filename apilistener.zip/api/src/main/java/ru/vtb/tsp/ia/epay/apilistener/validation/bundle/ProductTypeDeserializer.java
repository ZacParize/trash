package ru.vtb.tsp.ia.epay.apilistener.validation.bundle;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;

public class ProductTypeDeserializer extends StdDeserializer<ProductType> {

  public ProductTypeDeserializer() {
    this(ProductType.class);
  }

  protected ProductTypeDeserializer(Class<?> vc) {
    super(vc);
  }

  @Override
  public ProductType deserialize(JsonParser p, DeserializationContext ctxt) {
    try {
      return ProductType.fromName(p.getValueAsString());
    } catch (Exception e) {
      throw new BundleValidationException(ApplicationException.BUNDLE_PAYMENT_SUBJECT_ERROR);
    }
  }
}
