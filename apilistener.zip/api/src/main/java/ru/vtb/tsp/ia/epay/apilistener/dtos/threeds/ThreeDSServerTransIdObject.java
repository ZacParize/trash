package ru.vtb.tsp.ia.epay.apilistener.dtos.threeds;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * .
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 25.10.2021
 */
@Data
@JsonIgnoreProperties
public class ThreeDSServerTransIdObject implements Serializable {

    @JsonProperty("threeDSServerTransId")
    private String threeDSServerTransId;

}
