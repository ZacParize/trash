package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serializable;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = "Данные о конечных сертификатах ТСП в формате JWKS (JSON Web Key Set)")
public class MirPayJsonWebKeySetDto implements Serializable {

  @JsonProperty("keys")
  private List<MirPayJsonWebKeyDto> keys;

}
