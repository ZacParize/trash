package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class TypeTransactionResponseDto<T extends Serializable> implements Serializable {

  @JsonProperty("object")
  private Map<String, List<T>> object;

}
