package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@SuperBuilder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundObjectResponseDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  @JsonProperty("refundId")
  private String refundId;

  @JsonProperty("paymentId")
  private String paymentId;

  @JsonProperty("paymentCode")
  private String txnId;

  @JsonProperty("orderId")
  private String orderId;

  @JsonProperty("orderCode")
  private String orderCode;

  @JsonProperty("createdAt")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime createdAt;

  @JsonProperty("status")
  private RefundStatusDto status;

  @JsonProperty("amount")
  private AmountResponseDto amount;

}