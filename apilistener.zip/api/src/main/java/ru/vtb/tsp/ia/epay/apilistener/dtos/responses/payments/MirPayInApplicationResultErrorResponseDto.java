package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Builder;
import lombok.Data;

/**
 * Модель ответа на основе RFC 7807.
 */
@Data
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@Schema(description = "Модель ответа на основе RFC 7807 при подтверждении оплаты Mir Pay")
public class MirPayInApplicationResultErrorResponseDto {

  /**
   * HTTP-код сгенерированный исходным сервером для конкретно этого типа проблемы.
   */
  @JsonProperty("status")
  Integer status;

  /**
   * Короткое описание проблемы на английском языке для чтения инженерами (обычно не
   * локализированное).
   */
  @JsonProperty("title")
  String title;

  /**
   * Человекочитаемое объяснение, характерное для конкретно этого случая.
   */
  @JsonProperty("detail")
  String detail;

}
