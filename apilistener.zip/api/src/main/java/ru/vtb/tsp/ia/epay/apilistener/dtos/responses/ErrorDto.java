package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import java.util.Optional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorDto implements Serializable {

  @JsonProperty("id")
  private String id;

  @JsonProperty("message")
  private String message;

  @JsonProperty("description")
  private String description;

  @JsonProperty("traceId")
  private String traceId;

  public static ErrorDto of(TransactionError txError) {
    return Optional.ofNullable(txError)
        .map(error -> ErrorDto.builder()
            .id(error.getId())
            .message(error.getMessage())
            .description(error.getDescription())
            .traceId(error.getTraceId())
            .build())
        .orElse(null);
  }

}