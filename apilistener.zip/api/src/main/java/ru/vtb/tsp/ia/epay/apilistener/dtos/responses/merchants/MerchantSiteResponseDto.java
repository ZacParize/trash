package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentVisibilityDto;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteResponseDto implements Serializable {

  @JsonProperty("name")
  private String name;

  @JsonProperty("url")
  private String url;

  @JsonProperty("logoUrl")
  private String logoUrl;

  @JsonProperty("shortInfo")
  private String shortInfo;

  @JsonProperty("paymentVisibility")
  private PaymentVisibilityDto paymentVisibility;
}