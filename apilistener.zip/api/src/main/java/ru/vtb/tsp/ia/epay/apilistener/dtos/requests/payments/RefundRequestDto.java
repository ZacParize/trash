package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.validation.ValidBundle;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class RefundRequestDto implements RefundRequest, Serializable {

  /**
   * мерчантский id транзакции
   */
  @JsonProperty("refundId")
  private String refundId;

  /**
   * code исходной транзакции
   */
  @JsonProperty("paymentId")
  private String paymentId;

  @Valid
  @NotNull
  @JsonProperty("amount")
  private AmountRequestDto amount;

  @JsonProperty("bundle")
  @ValidBundle
  private BundleRequestDto bundle;

}