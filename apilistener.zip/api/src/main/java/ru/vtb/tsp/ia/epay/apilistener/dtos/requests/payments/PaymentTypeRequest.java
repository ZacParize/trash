package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum PaymentTypeRequest {

  @JsonProperty("sbp")
  SBP("sbp"),

  @JsonProperty("invoice")
  INVOICE("invoice");

  private final String value;

}