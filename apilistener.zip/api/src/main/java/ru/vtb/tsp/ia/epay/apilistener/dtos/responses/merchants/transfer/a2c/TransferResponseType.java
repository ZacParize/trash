package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@JsonFormat(shape = JsonFormat.Shape.STRING)
@RequiredArgsConstructor
public enum TransferResponseType {

  @JsonProperty("TRANSFER")
  TRANSFER("transfer");

  private final String value;

}