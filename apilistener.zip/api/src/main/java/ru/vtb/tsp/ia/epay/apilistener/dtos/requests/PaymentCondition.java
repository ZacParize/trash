package ru.vtb.tsp.ia.epay.apilistener.dtos.requests;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;


@AllArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum PaymentCondition {
  SSL_SECURED("4"),
  FULL_3D_SECURE("5");

  @Getter
  private final String code;
}
