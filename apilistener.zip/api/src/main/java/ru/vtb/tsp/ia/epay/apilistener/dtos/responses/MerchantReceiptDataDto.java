package ru.vtb.tsp.ia.epay.apilistener.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptData;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptState;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptType;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.OfdErrorPayload;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantReceiptDataDto {

  @JsonProperty("uuid")
  private UUID uuid;
  @JsonProperty("operation")
  private ReceiptType operation;
  @JsonProperty("status")
  private ReceiptState status;
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;
  @JsonProperty("data")
  private ReceiptData data;
  @JsonProperty("ofdError")
  private OfdErrorPayload ofdError;

}
