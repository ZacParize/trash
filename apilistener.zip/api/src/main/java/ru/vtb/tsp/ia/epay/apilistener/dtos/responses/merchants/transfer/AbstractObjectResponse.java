package ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder(toBuilder = true)
public abstract class AbstractObjectResponse {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  @JsonProperty("orderId")
  protected String orderId;

  @JsonProperty("orderCode")
  protected String orderCode;

  @JsonProperty("createdAt")
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = DATE_TIME_FORMAT)
  protected LocalDateTime createdAt;

  @JsonProperty("status")
  protected StatusResponseDto status;
}
