package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.io.Serializable;
import java.math.BigDecimal;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;
import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import ru.vtb.tsp.ia.epay.apilistener.validation.bundle.MeasureDeserializer;
import ru.vtb.tsp.ia.epay.apilistener.validation.bundle.PaymentTypeDeserializer;
import ru.vtb.tsp.ia.epay.apilistener.validation.bundle.ProductTypeDeserializer;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;

@Value
@Builder(toBuilder = true)
@Jacksonized
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleItemRequestDto implements Serializable {

  @Positive
  @NotNull
  @JsonProperty("positionId")
  private Integer positionId;

  @Size(max = 255)
  @NotBlank
  @JsonProperty("name")
  private String name;

  @Size(max = 255)
  @JsonProperty("code")
  private String code;

  @Size(max = 255)
  @JsonProperty("description")
  private String description;

  @JsonProperty("shippable")
  private boolean shippable;

  @NotNull
  @PositiveOrZero
  @DecimalMax(value = "42949672.95", inclusive = true, message = "Значение price не может быть "
      + "больше 42949672.95" )
  @Digits(integer = 8, fraction = 2, message = "Неверный формат числа" )
  @JsonProperty("price")
  private BigDecimal price;

  @JsonProperty("measure")
  @JsonDeserialize(using = MeasureDeserializer.class)
  private UnitsMeasure measure;

  @NotNull
  @DecimalMax(value = "99999.999", inclusive = true, message = "Значение quantity не может быть "
      + "больше 99999.999")
  @Digits(integer = 5, fraction = 3, message = "Неверный формат числа")
  @JsonProperty("quantity")
  private BigDecimal quantity;

  @Valid
  @NotNull
  @JsonProperty("taxParams")
  private TaxParamsDto taxParams;


  @JsonProperty("paymentType")
  @JsonDeserialize(using = PaymentTypeDeserializer.class)
  private PaymentType paymentType;

  @JsonProperty("paymentSubject")
  @JsonDeserialize(using = ProductTypeDeserializer.class)
  private ProductType paymentSubject;

  @NotNull
  @PositiveOrZero
  @DecimalMax(value = "42949672.95", inclusive = true, message = "Значение amount не может быть больше 42949672.95")
  @Digits(integer = 8, fraction = 2, message = "Неверный формат числа")
  @JsonProperty("amount")
  private BigDecimal amount;

  @PositiveOrZero
  @DecimalMax(value = "100.00", inclusive = true, message = "Значение discount не может быть больше 100.00")
  @JsonProperty("discount")
  private BigDecimal discount;

  @Size(max = 255)
  @JsonProperty("userData")
  private String userData;
}
