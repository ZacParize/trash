package ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.PaymentCondition;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.PaymentSystem;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.Version3DS;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardPaymentData implements Serializable {

  @NotBlank
  private String terminalId;
  @Size(max = 1024)
  @NotBlank
  private String encryptedPan;
  @Size(max = 1024)
  @NotBlank
  private String encryptedCvv;
  @NotBlank
  private String expiryDate;
  @NotNull
  private PaymentCondition condition;
  private String cavv;
  private String xid;
  private String eci;
  private Version3DS v3ds;
  @Size(max = 255)
  @NotBlank
  private String bank;
  @NotNull
  private PaymentSystem paymentSystem;
  @Valid
  @NotNull
  private AmountRequestDto amount;
}
