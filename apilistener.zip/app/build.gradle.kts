plugins {
    idea
    base
    java
    groovy
    application
    `maven-publish`
    checkstyle
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")

val toolDir = "${project.buildDir}/tools"
val toolDependency by configurations.compileOnly
toolDependency.isCanBeResolved = true

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
        exclude("io.springfox", "springfox-bean-validators")
        exclude("io.springfox", "springfox-boot-starter")
        exclude("io.springfox", "springfox-core")
        exclude("io.springfox", "springfox-data-rest")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    implementation(project(":api"))

    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-customer-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-customer-client")
    implementation("ru.vtb.dev.corp.ia.epay:epay-tokenization-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-notificator-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-acsproxy-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-sbpadapter-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-fiscalization-api")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-domain")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")
    toolDependency("ru.vtb.dev.corp.ia.epay:epay-build-tools")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")

    // Spring components
    implementation("org.springframework.kafka:spring-kafka")
    implementation("org.springframework.boot:spring-boot-starter-integration")
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
    implementation("org.springframework.boot:spring-boot-starter-web")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("org.springframework.boot:spring-boot-starter-security")
    implementation("org.springframework.cloud:spring-cloud-starter-openfeign")
    runtimeOnly("org.springframework.boot:spring-boot-starter-undertow")

    implementation("io.github.openfeign:feign-jackson:11.8")

    //Apache components
    implementation("org.apache.commons:commons-lang3")
    implementation("org.apache.httpcomponents:httpclient")

    // Google components
    implementation("com.google.zxing:javase")

    //swagger open api 3.0
    implementation("org.springdoc:springdoc-openapi-ui")
    implementation("io.swagger.core.v3:swagger-annotations")

    // Tracing
    implementation("ru.vtb.tstr:tstr-starter")

    // Monitoring
    implementation("io.micrometer:micrometer-registry-prometheus")
    implementation("io.github.openfeign:feign-micrometer")

    // Logging
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("com.vlkan.log4j2:log4j2-logstash-layout")
    implementation("ru.vtb.infra.logging:log4j2-integration")

    // Database driver
    implementation("org.postgresql:postgresql")

    // audit
    implementation("ru.vtb.omni:audit-lib-servlet-context")
    implementation("ru.vtb.omni:audit-lib-in-memory-storage")
    implementation("ru.vtb.omni:audit-lib-kafka-sender")
    implementation("ru.vtb.omni:audit-lib-freemarker-template-resolver")

    // Validation
    implementation("javax.validation:validation-api")
    implementation("commons-validator:commons-validator")

    // Kafka streams
    implementation("org.apache.kafka:kafka-streams")

    // Reactive streams
    implementation("io.projectreactor:reactor-core")
    implementation("io.projectreactor.kafka:reactor-kafka")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Mapstruct
    annotationProcessor("org.mapstruct:mapstruct-processor")
    implementation("org.mapstruct:mapstruct")

    //standin
    implementation("ru.vtb.smartreplication:smart-replication-producer-lib")
    implementation("ru.vtb.smartreplication:smart-replication-client-jdbc")
    implementation("ru.vtb.smartreplication:smart-replication-core-etcd-support-starter")
    implementation("io.grpc:grpc-core")
    implementation("io.grpc:grpc-netty")
    implementation("io.grpc:grpc-protobuf")
    implementation("io.grpc:grpc-stub")
    implementation("io.grpc:grpc-grpclb")
    implementation("net.jodah:failsafe")

    //JWT
    implementation("com.nimbusds:nimbus-jose-jwt")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:kafka")
    testImplementation("org.testcontainers:postgresql")
    testImplementation("org.testcontainers:junit-jupiter")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")

    // Use Spock framework for Tests
    implementation("org.codehaus.groovy:groovy")
    implementation("org.codehaus.groovy:groovy-all")
    testImplementation("org.spockframework:spock-core")
    testImplementation("org.spockframework:spock-spring")
    testImplementation("org.testcontainers:spock")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/groovy")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set("ru.vtb.tsp.ia.epay.apilistener.App")
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
    testLogging {
        events.add(org.gradle.api.tasks.testing.logging.TestLogEvent.FAILED)
        exceptionFormat = org.gradle.api.tasks.testing.logging.TestExceptionFormat.SHORT
    }
}

val extractToolsDependency by tasks.register<Copy>("extractToolsDependency") {
    dependsOn(toolDependency)
    from(toolDependency.map {
        zipTree(it)
    })
    include("config/**")
    into(toolDir)
    includeEmptyDirs = false
}


tasks.withType<Checkstyle>().configureEach {
    dependsOn(extractToolsDependency)
    reports {
        xml.required.set(false)
        html.required.set(true)
    }
}

checkstyle {
    maxWarnings = 0
    isShowViolations = true
    isIgnoreFailures = false
    toolVersion = "9.3"
    configFile = file("${toolDir}/config/checkstyle/checkstyle.xml")
}

idea {
    // Download javadoc and sources
    module {
        isDownloadSources = true
        isDownloadJavadoc = true
    }
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
        property("sonar.exclusions", "src/main/resources/**/*," +
                "ru/vtb/tsp/ia/epay/apilistener/**/*Dto.java," +
                "ru/vtb/tsp/ia/epay/apilistener/**/*Abstract*.java," +
                "ru/vtb/tsp/ia/epay/apilistener/**/*Config.java," +
                "ru/vtb/tsp/ia/epay/apilistener/configs/**/*.java" +
                "ru/vtb/tsp/ia/epay/apilistener/domain/*.java" +
                "ru/vtb/tsp/ia/epay/apilistener/exceptions/*.java" +
                "ru/vtb/tsp/ia/epay/apilistener/App.java" +
                "**/*.yaml," +
                "**/*.yml," +
                "**/*.xml")
    }
}