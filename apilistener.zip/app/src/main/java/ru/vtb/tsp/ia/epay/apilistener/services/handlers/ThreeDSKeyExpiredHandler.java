package ru.vtb.tsp.ia.epay.apilistener.services.handlers;

import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSTransactionService;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Slf4j
@Component
@RequiredArgsConstructor
public class ThreeDSKeyExpiredHandler implements EventHandler {

  private static final String THREEDS_DECISION_COMPLETE = "3DS_DECISION_COMPLETE";

  private final ThreeDSTransactionService threeDSTransactionService;
  private final KafkaService kafkaService;

  public Optional<Transaction> handle(@Nullable String code) {
    return threeDSTransactionService.proceed3DSMethodExpiredKey(code)
        .map(transaction -> {
          Optional.of(transaction).ifPresent(tx -> {
            if (tx.getData().getContext().containsKey(THREEDS_DECISION_COMPLETE)) {
              kafkaService.sendToBox(tx.getData());
            }
          });
          return transaction;
        });
  }

  @Override
  public NotificationType getHandleType() {
    return NotificationType.THREEDS_METHOD_TIMEOUT;
  }
}
