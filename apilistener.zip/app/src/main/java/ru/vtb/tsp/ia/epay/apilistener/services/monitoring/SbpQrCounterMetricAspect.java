package ru.vtb.tsp.ia.epay.apilistener.services.monitoring;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.Arrays;
import java.util.Objects;
import java.util.function.Consumer;
import javax.annotation.Nullable;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentTypeRequest;

@Aspect
@Component
public class SbpQrCounterMetricAspect {

  private static final String SUCCESS_METRIC_NAME = "sbp_qr_codes_success";
  private static final String SUCCESS_METRIC_DESCRIPTION =
      "Number of successfully created sbp qr codes";
  private static final String ERROR_METRIC_NAME = "sbp_qr_codes_error";
  private static final String ERROR_METRIC_DESCRIPTION =
      "Number of errors when create sbp qr codes";
  private final Counter successCounter;
  private final Counter errorCounter;

  public SbpQrCounterMetricAspect(MeterRegistry meterRegistry) {
    this.successCounter = Counter.builder(SUCCESS_METRIC_NAME)
        .description(SUCCESS_METRIC_DESCRIPTION).register(meterRegistry);
    this.errorCounter = Counter.builder(ERROR_METRIC_NAME)
        .description(ERROR_METRIC_DESCRIPTION).register(meterRegistry);
  }

  private void increaseCounter(@Nullable JoinPoint joinPoint,
      @Nullable Consumer<PaymentTypeRequest> consumer) {
    if (Objects.isNull(joinPoint) || Objects.isNull(consumer)) {
      return;
    }
    Arrays.stream(joinPoint.getArgs())
        .filter(param -> param instanceof OrderCreationRequestDto)
        .map(param -> ((OrderCreationRequestDto) param).getReturnPaymentData())
        .filter(PaymentTypeRequest.SBP::equals)
        .forEach(consumer);
  }

  private void increaseSuccessCounter(@Nullable JoinPoint joinPoint) {
    increaseCounter(joinPoint, (param) -> successCounter.increment());
  }

  private void increaseErrorCounter(@Nullable JoinPoint joinPoint) {
    increaseCounter(joinPoint, (param) -> errorCounter.increment());
  }

  @Pointcut("@annotation(ru.vtb.tsp.ia.epay.apilistener.services.monitoring.SbpQrCounterMetric)")
  protected void callMethod() {
    //Pointcut
  }

  @AfterReturning("callMethod()")
  public void sendCounterMetric(JoinPoint joinPoint) {
    increaseSuccessCounter(joinPoint);
  }

  @AfterThrowing("callMethod()")
  public void sendErrorMetric(JoinPoint joinPoint) {
    increaseErrorCounter(joinPoint);
  }

}