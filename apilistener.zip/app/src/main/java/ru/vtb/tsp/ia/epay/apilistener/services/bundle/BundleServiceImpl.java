package ru.vtb.tsp.ia.epay.apilistener.services.bundle;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.mapper.BundleMapper;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.repository.BundleRepository;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class BundleServiceImpl implements BundleService {

  private final BundleRepository bundleRepository;
  private final BundleMapper bundleMapper;

  @Override
  @Transactional
  public BundleDto create(UUID orderCode, BundleRequestDto bundleRequestDto) {
    final var entity = bundleMapper.requestDtoToEntity(bundleRequestDto);
    entity.setId(UUID.randomUUID());
    entity.setOrderRef(orderCode);
    final var saved = bundleRepository.saveOrUpdate(entity);
    return bundleMapper.fromEntity(saved);
  }

  @Override
  public BundleDto getBundleByOrderCode(String orderId) {
    final var bundle = bundleRepository.findByOrderCode(orderId);
    return bundleMapper.fromEntity(bundle);
  }
}
