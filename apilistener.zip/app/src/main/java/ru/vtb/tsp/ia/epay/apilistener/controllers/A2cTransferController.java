package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.A2cInternalTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c.A2cTransferExtendedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c.A2cTransferShortResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class A2cTransferController {

  public static final String BASE_PATH = "/internal-transfers";

  public static final String INTERNAL_TRANSFER = BASE_PATH + "/account-to-card";

  private static final String ORDER_ID_PATH_VARIABLE = "orderId";

  private static final String INTERNAL_TRANSFERS_ORDER_ID = BASE_PATH
      + "/{" + ORDER_ID_PATH_VARIABLE + "}";

  private final OrderServiceFacade orderServiceFacade;
  private final KafkaService kafkaService;
  private final PaymentService paymentService;

  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = A2cTransferExtendedResponseDto.class))
  })
  @PostMapping(path = "${app.api.prefix}" + INTERNAL_TRANSFER, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<TypedResponseDto<A2cTransferExtendedResponseDto>> create(
      @RequestBody @NotNull @Valid A2cInternalTransferRequestDto a2cRequestDto) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received create a2c transfer request {}, merchant site id {}", a2cRequestDto, mst);
    return paymentService.createA2cTransfer(a2cRequestDto, mst)
        .map(dto -> {
          kafkaService.sendOrderToPortal(dto.getOrder());
          kafkaService.sendToBox(dto.getTransaction().getData());
          return dto.getOrder();
        })
        .map(o -> ResponseEntity.ok(ConverterUtils.convertToA2cTransferExtended(o)))
        .orElseThrow(() -> new ValidationException("Can't create a2c transfer " + a2cRequestDto));
  }

  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = A2cTransferShortResponseDto.class))
  })
  @GetMapping(path = "${app.api.prefix}" + INTERNAL_TRANSFERS_ORDER_ID,
      produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<?> getOrder(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank @Size(max = 64) String orderId) {
    final var mstId = ((MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal()).getId();
    log.info("Received get a2c transfer request by id {}, merchant site id {}", orderId, mstId);
    return orderServiceFacade.getByMstOrderId(mstId, orderId)
        .map(o -> ResponseEntity.ok(ConverterUtils.convertToA2cTransferShort(o)))
        .orElseThrow(() -> new ValidationException("Incorrect a2c transfer id " + orderId));
  }

}