package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay;

import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_INVALID_INPUT_DATA;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentProcessDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayTokenDecoder;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.IPaymentGateway;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayGateway implements IPaymentGateway {

  private final IMirPayPayment mirPayPayment;
  private final IMirPayRefund mirPayRefund;
  private final MirPayTokenDecoder mirPayTokenDecoder;
  private final PaymentVerifier paymentVerifier;

  @Override
  public GatewayType getGatewayType() {
    return GatewayType.MIR_PAY;
  }

  @Override
  public Optional<Transaction> pay(PaymentRequest request) {
    if (request instanceof MirPayPaymentRequestDto requestDto) {
      return mirPayPayment.startProcessPayment(requestDto.getMstOrderCode(), requestDto.getAmount(),
          requestDto.getEmail());
    } else if (request instanceof MirPayPaymentProcessDto processDto) {
      final var orderCode = processDto.getOrderCode();
      final var merchantId = processDto.getMerchantId();
      final var callback = processDto.getCallback();
      paymentVerifier.checkOrderIdsNotNull(orderCode, callback)
          .ifCheckFailedThrow(
              (message) -> new MirPayServiceException(MIR_PAY_INVALID_INPUT_DATA, message)
          );
      paymentVerifier.checkCallbackOrderId(orderCode, callback)
          .ifCheckFailedThrow(
              (message) -> new MirPayServiceException(MIR_PAY_INVALID_INPUT_DATA, message)
          );
      final var mirPayDecodedJWT = mirPayTokenDecoder.decodeJWE(callback.getCryptogram());
      log.info("Mir Pay: cryptogram successfully decrypted for order with code '{}'", orderCode);

      return mirPayPayment.confirmProcessPayment(orderCode, merchantId, mirPayDecodedJWT);
    }
    log.error("Mir Pay payment: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }

  @Override
  public Optional<Transaction> refund(RefundRequest request, Transaction tx, MerchantSite mst) {
    if (request instanceof RefundRequestDto refundReq) {
      return mirPayRefund.registerRefund(refundReq, tx, mst.getId());
    }
    log.error("Mir Pay refund: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }
}