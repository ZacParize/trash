package ru.vtb.tsp.ia.epay.apilistener.services;

import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSCresCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSMethodCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSParesCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSTransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class ThreeDSCallbackService {

  private static final String DECISION_COMPLETE = "3DS_DECISION_COMPLETE";
  private final KafkaService kafkaService;
  private final ThreeDSTransactionService threeDsTransactionService;

  public @NotNull Optional<String> proceed3DSMethod(@Nullable String code,
      @NotNull ThreeDSMethodCallbackDto request) {
    return threeDsTransactionService.proceed3DSMethodTransaction(code, request)
        .map(tx -> {
          if (tx.getData().getContext().containsKey(DECISION_COMPLETE)) {
            kafkaService.sendToBox(tx.getData());
          }
          return Optional.of(tx.getTransactionId());
        }).orElse(Optional.empty());
  }

  public @NotNull Optional<String> proceed3DSCres(@Nullable String code,
      @NotNull ThreeDSCresCallbackPost request) {
    return threeDsTransactionService.proceed3DSCresTransaction(code, request)
        .map(tx -> {
          kafkaService.sendToBox(tx.getData());
          return Optional.of(tx.getCode());
        }).orElse(Optional.empty());
  }

  @AuditProcess("TSPACQ_BOX_ACS_PARES_CALLBACK_FLC")
  public @NotNull Optional<String> proceed3DSPares(@Nullable String code,
      @NotNull ThreeDSParesCallbackPost request) {
    return threeDsTransactionService.process3DSParesTransaction(code, request)
        .map(tx -> {
          kafkaService.sendToBox(tx.getData());
          return Optional.of(tx.getCode());
        }).orElse(Optional.empty());
  }

  public boolean correctTransId(@Nullable String body, @Nullable String key) {
    if (StringUtils.isEmpty(body)) {
      return false;
    }
    final var decoded = Base64.getDecoder().decode(URLDecoder.decode(body, StandardCharsets.UTF_8));
    if (ArrayUtils.isEmpty(decoded)) {
      return false;
    }
    final var decodedString = new String(decoded);
    return !decodedString.matches("\"" + key + "\"\\s{0,}:\\s{0,}\"\"");
  }

  @AuditProcess("TSPACQ_BOX_ACS_CALLBACK_FLC")
  public void validate3DSMethodCallback(String transactionId, Boolean threeDSServerTransId) {
    if (StringUtils.isEmpty(transactionId)) {
      log.error("transactionId must not be empty!");
    }
  }

  @AuditProcess("TSPACQ_BOX_ACS_CRES_CALLBACK_FLC")
  public void validateCresCallback(String transactionId, Boolean acsTransId) {
    if (StringUtils.isEmpty(transactionId)) {
      log.error("transactionId must not be empty!");
    }
  }


}
