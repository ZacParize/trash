package ru.vtb.tsp.ia.epay.apilistener.services.verifier;

import java.util.function.Function;
import java.util.function.Supplier;
import lombok.extern.slf4j.Slf4j;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;

@Slf4j
public class CheckResult {

  private final boolean value;
  private final String error;

  public CheckResult(boolean value) {
    this.value = value;
    this.error = "";
  }

  public CheckResult(boolean value, String error) {
    this.value = value;
    this.error = error;
  }

  public <X extends Exception> boolean ifCheckFailedThrow(Supplier<? extends X> exceptionSupplier)
      throws X {
    if (value) {
      return value;
    }
    throw exceptionSupplier.get();
  }

  public <X extends Exception> boolean ifCheckFailedThrow(
      Function<String, ? extends X> stringFunction)
      throws X {
    if (value) {
      return value;
    }
    throw stringFunction.apply(error);
  }

  public <X extends Exception> boolean ifCheckFailedLogAndThrow(String type,
      Supplier<? extends X> exceptionSupplier) throws X {
    if (value) {
      return value;
    }
    log.error("[{}], {}", type, error);
    throw exceptionSupplier.get();
  }

  public <X extends Exception> boolean ifCheckFailedLogAndThrow(
      Supplier<? extends X> exceptionSupplier)
      throws X {
    if (value) {
      return value;
    }
    log.error("{}", error);
    throw exceptionSupplier.get();
  }

  public <X extends Exception> boolean ifCheckFailedLogAndThrow(String type,
      Function<String, ? extends X> stringFunction)
      throws X {
    if (value) {
      return value;
    }
    log.error("[{}], {}", type, error);
    throw stringFunction.apply(error);
  }

  public <X extends Exception> boolean ifCheckFailedLogAndThrowServiceException(String type,
      ApplicationException applicationException
  ) throws X {
    if (value) {
      return value;
    }
    log.error("[{}], {}", type, error);
    throw new ServiceException(applicationException);
  }

  public <X extends Exception> boolean ifCheckFailedLogAndThrowServiceException(
      ApplicationException applicationException
  ) throws X {
    if (value) {
      return value;
    }
    log.error("{}", error);
    throw new ServiceException(applicationException);
  }
}
