package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class InternalException extends ServiceException {

  {
    this.exception = ApplicationException.INTERNAL_ERROR;
  }

  public InternalException() {
  }

  public InternalException(String message) {
    super(message);
  }

  public InternalException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public InternalException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}