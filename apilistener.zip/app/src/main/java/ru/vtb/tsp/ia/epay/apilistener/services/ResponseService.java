package ru.vtb.tsp.ia.epay.apilistener.services;

import java.io.Serializable;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentTypeRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentTypeResponse;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.SbpPaymentResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
public class ResponseService {

  private final TransactionService transactionService;
  private final PaymentService paymentService;
  private final String payformUrl;

  public ResponseService(PaymentService paymentService,
      @Value("${app.payform.url}") @NotBlank String payformUrl,
      TransactionService transactionService) {
    this.paymentService = paymentService;
    this.payformUrl = payformUrl;
    this.transactionService = transactionService;
  }

  public @NotNull TypedResponseDto<OrderObjectResponseDto> toOrderResponse(
      @NotNull Order order,
      @Nullable PaymentTypeRequest paymentData) {
    final var transactionList = transactionService.getByOrderId(order.getOrderId());
    String qrUrl;
    // Создаем СПБ шную транзакцию только тогда когда на контроллер
    // пришел параметр returnPaymentData = "sbp"
    if (PaymentTypeRequest.SBP.equals(paymentData)) {
      qrUrl = paymentService.getQr(order.getOrderId()).orElse(null);

      final var sbpPaymentResponseDto = SbpPaymentResponseDto.builder()
          .url(qrUrl)
          .build();
      return ConverterUtils.convert(order, PaymentTypeResponse.SBP,
          payformUrl + "?order-id=" + order.getCode(), sbpPaymentResponseDto, transactionList);
    } else {
      return ConverterUtils.convert(order, null, payformUrl + "?order-id=" + order.getCode(),
          null, transactionList);
    }
  }

  public ResponseEntity<?> toRefundResponse(String mstId, String refundId) {
    return transactionService.getByMstTransactionId(mstId, refundId)
        .map(txn -> ResponseEntity.<Serializable>ok(ConverterUtils.convertToRefundResponse(txn)))
        .orElseThrow(() -> new ValidationException("Incorrect refund id " + refundId));
  }
}