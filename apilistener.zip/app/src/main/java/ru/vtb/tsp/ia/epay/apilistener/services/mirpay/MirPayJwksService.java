package ru.vtb.tsp.ia.epay.apilistener.services.mirpay;

import java.util.Collections;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayJsonWebKeyDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayJsonWebKeySetDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayJwksService {

  public static final String KTY_TYPE_RSA = "RSA";

  /**
   * Сертификат промежуточного Удостоверяющего центра Агрегатора (Concentrator SubCA).
   */
  private final String nspkCertificateInBase64;
  /**
   * Серийный номер сертификата X.509 НСПК [PK.NSPK.1], число в hex формате
   */
  private final String nspkCertificateSerialNumber;

  /**
   * Получение сертификата ТСП.
   */
  public MirPayJsonWebKeySetDto getJwks() {
    var certificates = Collections.singletonList(nspkCertificateInBase64);
    MirPayJsonWebKeyDto key = MirPayJsonWebKeyDto.builder()
        .kid(nspkCertificateSerialNumber)
        .kty(KTY_TYPE_RSA)
        .x5c(certificates)
        .build();
    return MirPayJsonWebKeySetDto.builder()
        .keys(Collections.singletonList(key))
        .build();
  }
}
