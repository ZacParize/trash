package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface ICardRefund {

  @NotNull Optional<Transaction> registerRefund(@Nullable Transaction transaction,
      @Nullable String refundId,
      @Nullable AmountRequestDto amount);

}
