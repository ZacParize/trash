package ru.vtb.tsp.ia.epay.apilistener.services.bundle.repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.entity.Bundle;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleItem;
import ru.vtb.tsp.ia.epay.core.domains.bundle.FiscalInfo;

public interface BundleRepository extends CrudRepository<Bundle, UUID> {

  String COMMON_SELECT =
      "select "
          + "t.id, "
          + "t.order_ref, "
          + "t.fiscal_info, "
          + "t.items, "
          + "t.created_at, "
          + "t.updated_at, "
          + "t.version "
          + "from " + Bundle.TABLE + " t ";

  @Query(COMMON_SELECT + " where t.order_ref = :orderCode")
  Bundle findByOrderCode(@NotNull @Param("orderCode") String orderCode);


  @NotEmpty
  @Query("insert into " + Bundle.TABLE + " (id, "
      + "order_ref, "
      + "fiscal_info, "
      + "items,"
      + "created_at, "
      + "version) "
      + "values (:id, "
      + ":orderRef, "
      + ":fiscalInfo, "
      + ":items, "
      + "now(), "
      + ":version) "
      + "on conflict (id) do update set "
      + "fiscal_info = :fiscalInfo, "
      + "items = :items, "
      + "updated_at = now(),  "
      + "version = (:version + 1) "
      + "where " + Bundle.TABLE + ".version = :version RETURNING *")
  Bundle saveOrUpdate(@NotEmpty @Param("id") UUID id,
      @NotNull @Param("orderRef") UUID orderRef,
      @NotNull @Param("fiscalInfo") FiscalInfo fiscalInfo,
      @NotNull @Param("items") List<BundleItem> items,
      @Param("version") int version);

  default @NotNull Bundle saveOrUpdate(Bundle bundle) {
    Objects.requireNonNull(bundle, "Bundle for update can't be null");
    Objects.requireNonNull(bundle.getId(), "Bundle id can't be null");
    Objects.requireNonNull(bundle.getOrderRef(), "Bundle order id can't be null");
    Objects.requireNonNull(bundle.getItems(), "Bundle items can't be null");

    final var entity = Optional.ofNullable(saveOrUpdate(
            bundle.getId(),
            bundle.getOrderRef(),
            bundle.getFiscalInfo(),
            bundle.getItems(),
            Objects.requireNonNullElse(bundle.getVersion(), 0)))
        .orElseThrow(() -> new OptimisticLockingFailureException(bundle.getId().toString()));
    return findById(entity.getId())
        .orElseThrow(
            () -> new NoSuchElementException("Can't find bundle by id " + entity.getId()));
  }
}
