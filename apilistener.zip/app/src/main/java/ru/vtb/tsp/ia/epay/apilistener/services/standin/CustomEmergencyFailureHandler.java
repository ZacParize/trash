package ru.vtb.tsp.ia.epay.apilistener.services.standin;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;
import ru.vtb.smartreplication.client.producer.EnableReplicationResolver;
import ru.vtb.smartreplication.client.producer.handler.CustomReplicationPropertiesProvider;
import ru.vtb.smartreplication.client.producer.handler.DefaultEmergencyFailureHandler;
import ru.vtb.smartreplication.client.producer.handler.ReplicationFailureType;
import ru.vtb.smartreplication.core.exception.SmartReplicationException;
import ru.vtb.tsp.ia.epay.apilistener.configs.converters.StandInObjectMapper;
import ru.vtb.tsp.ia.epay.core.domains.enums.StandInVariables;

@Slf4j
public class CustomEmergencyFailureHandler extends DefaultEmergencyFailureHandler {

  private static final String QUERY = "insert into standin_params (key, data, created_at, "
      + "modified_at) values "
      + "(:key, to_jsonb(:data::jsonb), "
      + "to_timestamp(cast(:createdAt as text),'YYYY-MM-DD HH24:MI:SS'), "
      + "to_timestamp(cast(:modifiedAt as text),'YYYY-MM-DD HH24:MI:SS')) "
      + "on conflict (key) do update "
      + "set data = to_jsonb(:data::jsonb), "
      + "modified_at = to_timestamp(cast(:modifiedAt as text),'YYYY-MM-DD HH24:MI:SS')";
  private final StandInObjectMapper standInObjectMapper = new StandInObjectMapper();

  private final PlatformTransactionManager emergencyTransactionManager;
  private final NamedParameterJdbcTemplate emergencyJdbcTemplate;

  public CustomEmergencyFailureHandler(
      EnableReplicationResolver enableReplicationResolver,
      CustomReplicationPropertiesProvider customReplicationPropertiesProvider,
      int maxReplicationErrors, int errorPeriodInSeconds,
      PlatformTransactionManager emergencyTransactionManager,
      NamedParameterJdbcTemplate emergencyJdbcTemplate) {
    super(enableReplicationResolver, customReplicationPropertiesProvider, maxReplicationErrors,
        errorPeriodInSeconds);
    this.emergencyTransactionManager = emergencyTransactionManager;
    this.emergencyJdbcTemplate = emergencyJdbcTemplate;
  }

  @Override
  public void handleException(ReplicationFailureType replicationFailureType,
      SmartReplicationException smartReplicationException) {
    log.error("Replication error occurred:", smartReplicationException);

    switch (replicationFailureType) {
      case KAFKA_ERROR -> super.handleKafkaError(smartReplicationException);
      case ETCD_INITIALIZATION_ERROR ->
          super.handleEtcdInitializationError(smartReplicationException);
      case ETCD_GET_CHANGE_SOURCE_ERROR ->
          handleEtcdGetChangeSourceError(smartReplicationException);
      default -> throw smartReplicationException;
    }
  }

  @Override
  public void handleEtcdGetChangeSourceError(
      SmartReplicationException smartReplicationException) {
    log.debug("Handling {}. ", ReplicationFailureType.ETCD_GET_CHANGE_SOURCE_ERROR);
    TransactionTemplate txTemplate = new TransactionTemplate(emergencyTransactionManager);
    txTemplate.setPropagationBehavior(TransactionDefinition.PROPAGATION_REQUIRES_NEW);
    txTemplate.execute(new TransactionCallback<Integer>() {
      @Override
      public Integer doInTransaction(TransactionStatus status) {
        try {
          log.info("Set standIn replication error: ETCD_GET_CHANGE_SOURCE_ERROR");
          return emergencyJdbcTemplate.update(QUERY, getParamMap());
        } catch (Exception e) {
          status.setRollbackOnly();
          throw e;
        }
      }
    });
  }

  private Map<String, Object> getParamMap() {
    final var map = new HashMap<String, Object>();
    try {
      map.put("data",
          standInObjectMapper.create().writeValueAsString(Map.of("value", false)));
    } catch (Exception e) {
      log.error("Failed to serialize standIn params", e);
    }
    map.put("key", StandInVariables.SMART_REPLICATION_ENABLED.name());
    map.put("createdAt", LocalDateTime.now(ZoneOffset.UTC));
    map.put("modifiedAt", LocalDateTime.now(ZoneOffset.UTC));
    return map;
  }

}
