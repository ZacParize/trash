package ru.vtb.tsp.ia.epay.apilistener.services.handlers;

import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

/**
 * Переведение транзакции, созданной для Mir Pay, в статус DECLINED по истечению времени,
 * определенном в declineCheckDelay.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MirPayTransactionDeclineCheckHandler implements EventHandler {

  private final TransactionService transactionService;

  @Transactional
  public Optional<Transaction> handle(@Nullable String code) {
    return transactionService.lockByCode(code)
        .filter(tx -> TransactionState.NEW.equals(tx.getState())
            && TransactionType.MIR_PAYMENT_WEB_BASED.equals(tx.getType()))
        .flatMap(tx -> {
          log.info("Mir Pay: decline expired transaction {}", tx.getTransactionId());
          return transactionService.upsert(tx.withState(TransactionState.DECLINED));
        });
  }

  @Override
  public NotificationType getHandleType() {
    return NotificationType.MIR_PAY_DECLINE_CHECK_TIMEOUT;
  }

}
