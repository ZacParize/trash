package ru.vtb.tsp.ia.epay.apilistener.services.handlers;

import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Component
@RequiredArgsConstructor
public class ThreeDSTransactionExpiredHandler implements EventHandler {

  private final TransactionService transactionService;

  @Transactional
  public Optional<Transaction> handle(@Nullable String code) {
    return transactionService.lockByCode(code)
        .filter(tx -> !tx.isAuthorized() && !tx.isCompleted())
        .flatMap(tx -> transactionService.upsert(tx.withState(TransactionState.DECLINED)));
  }

  @Override
  public NotificationType getHandleType() {
    return NotificationType.OTP_PAGE_TIMEOUT;
  }
}
