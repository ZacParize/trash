package ru.vtb.tsp.ia.epay.apilistener.controllers.api;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSCresCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSMethodCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSParesCallbackPost;

public interface ThreeDSApi {

  @Operation(summary = "Callback threeDS Cres",
      description = "Callback for threeDS Cres notification",
      tags = {"threeDSCallbacks"}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successful operation"),
      @ApiResponse(responseCode = "400", description = "Invalid ID supplied"),
      @ApiResponse(responseCode = "404", description = "URL not found"),
      @ApiResponse(responseCode = "500", description = "Server Error"),
      @ApiResponse(responseCode = "502", description = "Bad Gateway")})
  ResponseEntity<Void> threeDSCresCallback(
      @Parameter(in = ParameterIn.PATH, description = "ID of the URL",
          required = true, schema = @Schema()) String id,
      @Parameter(in = ParameterIn.DEFAULT, description = "Order object req",
          required = true, schema = @Schema()) ThreeDSCresCallbackPost body);


  @Operation(summary = "Callback threeDS method",
      description = "Callback for threeDS method notification",
      tags = {"threeDSCallbacks"}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successful operation"),
      @ApiResponse(responseCode = "400", description = "Invalid ID supplied"),
      @ApiResponse(responseCode = "404", description = "URL not found"),
      @ApiResponse(responseCode = "500", description = "Server Error"),
      @ApiResponse(responseCode = "502", description = "Bad Gateway")})
  ResponseEntity<Void> threeDSMethodCallback(
      @Parameter(in = ParameterIn.PATH, description = "ID of the URL",
          required = true, schema = @Schema()) String id,
      @Parameter(in = ParameterIn.DEFAULT, description = "Order object req",
          required = true, schema = @Schema()) ThreeDSMethodCallbackDto body);


  @Operation(summary = "Callback threeDS paRes",
      description = "Callback for threeDS paRes notification",
      tags = {"threeDSCallbacks"}
  )
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "Successful operation"),
      @ApiResponse(responseCode = "400", description = "Invalid ID supplied"),
      @ApiResponse(responseCode = "404", description = "URL not found"),
      @ApiResponse(responseCode = "500", description = "Server Error"),
      @ApiResponse(responseCode = "502", description = "Bad Gateway")})
  ResponseEntity<Void> threeDSParesCallback(
      @Parameter(in = ParameterIn.PATH, description = "ID of the URL",
          required = true, schema = @Schema()) String id,
      @Parameter(in = ParameterIn.DEFAULT, description = "Order object req",
          required = true, schema = @Schema()) ThreeDSParesCallbackPost body);

}

