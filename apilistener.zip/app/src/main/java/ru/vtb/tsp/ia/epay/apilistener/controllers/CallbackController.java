package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayInApplicationResultRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentProcessDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayJsonWebKeySetDto;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayJwksService;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;


@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class CallbackController {

  public static final String X_CORRELATION_ID_HEADER = "X-Correlation-ID";
  public static final String SBP_BASE_PATH = "/sbp/callback";
  private static final String ORDER_ID_PATH_VARIABLE = "orderId";
  private static final String MERCHANT_ID_PATH_VARIABLE = "merchantId";
  public static final String MIR_PAY_IN_APPLICATION_BASE_PATH = "/In-Application";
  private static final String POST_SBP_CALLBACK_PAYMENT = SBP_BASE_PATH + "/payment";
  private static final String POST_SBP_CONFIRM_CALLBACK_REFUND = SBP_BASE_PATH + "/refund/confirm";
  private static final String POST_SBP_COMPLETE_CALLBACK_REFUND =
      SBP_BASE_PATH + "/refund/complete";
  private static final String PUT_MIR_PAY_PAYMENT_DATA_PREPARATION_RESULT_CALLBACK =
      MIR_PAY_IN_APPLICATION_BASE_PATH + "/merchants/{" + MERCHANT_ID_PATH_VARIABLE + "}"
          + "/orders/{" + ORDER_ID_PATH_VARIABLE + "}";
  public static final String MIR_PAY_JWKS_BASE_PATH = "/jwks";
  public static final String MIR_PAY_GET_JWKS_BASE_PATH = MIR_PAY_JWKS_BASE_PATH + "/{"
      + MERCHANT_ID_PATH_VARIABLE
      + "}-jwks.json";

  private final PaymentService paymentService;

  private final MirPayJwksService mirPayJwksService;

  @PostMapping(path = "${app.api.prefix}" + POST_SBP_CALLBACK_PAYMENT,
      produces = APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_SBP_PAYMENT_CALLBACK_FROM_SBP")
  public @NotNull ResponseEntity<Void> completePaymentCallback(
      @RequestBody @NotNull @Valid SbpPaymentStatusResponseDto callback) {
    log.info("Received sbp payment callback {}", callback);
    paymentService.processSbpPayment(callback);
    log.info("Successfully processed sbp payment callback {}", callback);
    return ResponseEntity.ok().build();
  }

  @PostMapping(path = "${app.api.prefix}" + POST_SBP_CONFIRM_CALLBACK_REFUND,
      produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<Void> confirmRefundCallback(
      @RequestBody @NotNull @Valid SbpConfirmRefundCallbackDto callback) {
    log.info("Received sbp confirm refund callback {}", callback);
    paymentService.registerSbpRefund(callback);
    log.info("Successfully processed sbp confirm refund callback {}", callback);
    return ResponseEntity.ok().build();
  }

  @PostMapping(path = "${app.api.prefix}" + POST_SBP_COMPLETE_CALLBACK_REFUND,
      produces = APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_SBP_REFUND_CALLBACK_FROM_SBP")
  public @NotNull ResponseEntity<Void> completeRefundCallback(
      @RequestBody @NotNull @Valid SbpRefundStatusResponseDto callback) {
    log.info("Received sbp complete refund callback {}", callback);
    paymentService.registerSbpRefund(callback);
    log.info("Successfully processed sbp refund callback {}", callback);
    return ResponseEntity.ok().build();
  }

  @PutMapping(path = "${app.api.prefix}" + PUT_MIR_PAY_PAYMENT_DATA_PREPARATION_RESULT_CALLBACK,
      produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<Void> mirPayPaymentDataPreparationResultCallback(
      @RequestHeader(X_CORRELATION_ID_HEADER) String correlationIdHeader,
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String orderCode,
      @PathVariable(MERCHANT_ID_PATH_VARIABLE) @NotBlank String merchantId,
      @RequestBody @NotNull @Valid MirPayInApplicationResultRequestDto callback) {
    log.info("Mir Pay: received payment data preparation result callback for order id '{}'",
        orderCode);
    final var processDto = MirPayPaymentProcessDto.builder()
        .callback(callback)
        .merchantId(merchantId)
        .orderCode(orderCode) //order code tcp
        .build();
    paymentService.registerPayment(processDto, GatewayType.MIR_PAY);
    log.info("Mir Pay: successfully processed payment data preparation result callback");
    HttpHeaders headers = new HttpHeaders();
    headers.add(X_CORRELATION_ID_HEADER, correlationIdHeader);
    return ResponseEntity.status(HttpStatus.ACCEPTED)
        .headers(headers)
        .build();
  }

  @GetMapping(path = MIR_PAY_GET_JWKS_BASE_PATH,
      produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<MirPayJsonWebKeySetDto> getJwks(
      @PathVariable(MERCHANT_ID_PATH_VARIABLE) @NotBlank String merchantId
  ) {
    log.info("Mir Pay: request received to generate jwks for merchant id '{}'", merchantId);
    MirPayJsonWebKeySetDto jwks = mirPayJwksService.getJwks();
    log.info("Mir Pay: jwks successfully generated for merchant id '{}'", merchantId);
    return new ResponseEntity<>(jwks, HttpStatus.OK);
  }

}