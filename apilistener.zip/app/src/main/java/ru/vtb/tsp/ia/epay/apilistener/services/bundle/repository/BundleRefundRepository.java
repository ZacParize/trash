package ru.vtb.tsp.ia.epay.apilistener.services.bundle.repository;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.entity.BundleRefund;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleItem;
import ru.vtb.tsp.ia.epay.core.domains.bundle.FiscalInfo;

public interface BundleRefundRepository extends CrudRepository<BundleRefund, UUID> {

  String COMMON_SELECT =
      "select "
          + "t.id, "
          + "t.order_ref, "
          + "t.transaction_ref, "
          + "t.fiscal_info, "
          + "t.items, "
          + "t.created_at, "
          + "t.updated_at, "
          + "t.version "
          + "from " + BundleRefund.TABLE + " t ";

  @Query(COMMON_SELECT + " where t.order_ref = :orderCode")
  List<BundleRefund> findAllByOrderCode(@NotNull @Param("orderCode") String orderCode);

  @Query(COMMON_SELECT + " where t.transaction_ref = :txCode")
  BundleRefund findByTxCode(@NotNull @Param("txCode") String txCode);

  @NotEmpty
  @Query("insert into " + BundleRefund.TABLE + " (id, "
      + "order_ref, "
      + "transaction_ref, "
      + "fiscal_info, "
      + "items,"
      + "created_at, "
      + "version) "
      + "values (:id, "
      + ":orderRef, "
      + ":transactionRef, "
      + ":fiscalInfo, "
      + ":items, "
      + "now(), "
      + ":version) "
      + "on conflict (transaction_ref) do update set "
      + "fiscal_info = :fiscalInfo, "
      + "items = :items, "
      + "updated_at = now(),  "
      + "version = (:version + 1) "
      + "where " + BundleRefund.TABLE + ".version = :version RETURNING *")
  BundleRefund saveOrUpdate(@NotEmpty @Param("id") UUID id,
      @NotNull @Param("orderRef") UUID orderRef,
      @NotNull @Param("transactionRef") UUID transactionRef,
      @NotNull @Param("fiscalInfo") FiscalInfo fiscalInfo,
      @NotNull @Param("items") List<BundleItem> items,
      @Param("version") int version);

  default @NotNull BundleRefund saveOrUpdate(BundleRefund bundle) {
    Objects.requireNonNull(bundle, "Bundle for update can't be null");
    Objects.requireNonNull(bundle.getId(), "Bundle id can't be null");
    Objects.requireNonNull(bundle.getOrderRef(), "Bundle order code can't be null");
    Objects.requireNonNull(bundle.getTransactionRef(), "Bundle transaction code can't be null");
    Objects.requireNonNull(bundle.getItems(), "Bundle items can't be null");

    final var entity = Optional.ofNullable(saveOrUpdate(
            bundle.getId(),
            bundle.getOrderRef(),
            bundle.getTransactionRef(),
            bundle.getFiscalInfo(),
            bundle.getItems(),
            Objects.requireNonNullElse(bundle.getVersion(), 0)))
        .orElseThrow(() -> new OptimisticLockingFailureException(bundle.getId().toString()));
    return findById(entity.getId())
        .orElseThrow(
            () -> new NoSuchElementException("Can't find bundle by id " + entity.getId()));
  }
}
