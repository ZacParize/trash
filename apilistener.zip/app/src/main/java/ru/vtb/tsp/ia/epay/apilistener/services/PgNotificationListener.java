package ru.vtb.tsp.ia.epay.apilistener.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.services.handlers.EventHandler;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Slf4j
@Component
@RequiredArgsConstructor
public class PgNotificationListener {

  private final Map<NotificationType, EventHandler> handlers =
      new EnumMap<>(NotificationType.class);

  private final ObjectMapper objectMapper;

  public void register(NotificationType type, EventHandler handler) {
    handlers.put(type, handler);
  }

  @KafkaListener(topics = NotificationAddress.Constants.APILISTENER_ADDRESS,
      containerFactory = "kafkaListenerContainerFactory")
  public void onMessage(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      if (Objects.nonNull(record.value())) {
        final Notification message = record.value() instanceof Notification
            ? (Notification) record.value()
            : objectMapper.convertValue(record.value(), NotificationImpl.class);
        handlers.get(message.getType()).handle((String) message.getPayload());
        EventHandler handler = handlers.get(message.getType());
        if (Objects.nonNull(handler)) {
          log.info("Handle message {}", message.getType());
          handler.handle((String) message.getPayload());
        } else {
          log.error("No handler for event type {}", message.getType());
        }
      }
    } catch (Exception ex) {
      log.error("Notification key {} can't be processed", record.key(), ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }

}