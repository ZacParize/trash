package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.StringReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSCresCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSMethodCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSParesCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.CompressorService;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.core.utils.CardAdditionalUtils;

@Service
@Slf4j
@RequiredArgsConstructor
public class ThreeDSTransactionService {

  public static final String NEXT = "TDS_NEXT_STEP";
  private static final String TDS_ORIGINAL_PAREQ = "TDS_ORIGINAL_PAREQ";
  private static final String PARES = "PARES";
  private static final String THREEDS_TDS_MD_KEY = "TDS_MD";
  private static final String THREEDS_TDS_PARES_KEY = "TDS_PARES";
  private static final String PARES_XID_XPATH = "/ThreeDSecure/Message/PARes/Purchase/xid";
  private static final String PAREQ_XID_XPATH = "/ThreeDSecure/Message/PAReq/Purchase/xid";
  private static final String THREEDS_TDS_CRES_KEY = "TDS_CRES";
  private static final String TDS_NEXT = "TDS_NEXT_STEP";
  private static final String THREEDS_CRES = "CRES";
  private static final String THREEDS_COMPIND_KEY = "3DS_COMP_IND";
  private static final String THREEDS_COMPIND_SUCCESS = "Y";
  private static final String THREEDS_COMPIND_FAILURE = "N";
  private static final String THREEDS_COMP_IND_KEY = "3DS_COMP_IND";
  private static final String THREE_DS_SERVER_TRANS_ID = "threeDSServerTransID";
  private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE =
      new TypeReference<>() {
      };

  private final TransactionService transactionService;
  private final CompressorService compressorService;
  private final ObjectMapper objectMapper;


  @Transactional
  public @NotNull Optional<Transaction> proceed3DSMethodTransaction(@Nullable String code,
      @NotNull ThreeDSMethodCallbackDto request) {
    return transactionService.lockByCode(code)
        .map(tx -> {
          if (tx.isCompleted()
              || tx.getData().getContext().containsKey(THREEDS_COMPIND_KEY)) {
            return Optional.of(tx);
          }
          if (!request.isValid()) {
            log.info("Transaction id {} ares is not valid", tx.getTransactionId());
            transactionService.upsert(tx.withState(TransactionState.DECLINED));
            return Optional.of(tx);
          } else {
            if (compareThreeDsServerTransId(request.getThreeDSMethodData(),
                (String) tx.getData().getContext()
                    .get(ThreeDSContextVariables.TDS_SERVER_TID.cname()))) {
              final var threeDSData = CardAdditionalUtils.getThreeds(tx.getData())
                  .orElseThrow(TransactionNotFoundException::new).getThreeDSData();
              final var threeDSCompInd = threeDSData.getThreeDSCompInd();
              if (StringUtils.isNotEmpty(threeDSCompInd)) {
                return null;
              } else {
                threeDSData.setThreeDSCompInd(THREEDS_COMPIND_SUCCESS);
                threeDSData.setThreeDSMethodData(request.getThreeDSMethodData());
                threeDSData.setOperation(ThreeDSAdapterOperation.AREQ);
                tx.getData().getContext().put(THREEDS_COMPIND_KEY, THREEDS_COMPIND_SUCCESS);
                log.info("Transaction id {} ares is valid", tx.getTransactionId());
                transactionService.upsert(tx);
              }
            } else {
              log.error("threeDSServerTransID in ares and in transaction {} is not equals",
                  tx.getTransactionId());
              transactionService.upsert(tx.withState(TransactionState.DECLINED));
              return Optional.of(tx);
            }
            return Optional.of(tx);
          }
        }).orElse(Optional.empty());
  }

  public Optional<Transaction> proceed3DSMethodExpiredKey(String code) {
    return transactionService.lockByCode(code)
        .map(tx -> {
          final var threeds = CardAdditionalUtils.getThreeds(tx.getData())
              .orElseThrow(TransactionNotFoundException::new);
          final var threeDSCompInd = threeds.getThreeDSData().getThreeDSCompInd();
          if (StringUtils.isNotEmpty(threeDSCompInd)) {
            return null;
          }
          log.info("Lock transaction id {} and set 3DS compInd {}", tx.getTransactionId(),
              THREEDS_COMPIND_FAILURE);
          threeds.getThreeDSData().setThreeDSCompInd(THREEDS_COMPIND_FAILURE);
          tx.getData().getContext().put(THREEDS_COMP_IND_KEY, THREEDS_COMPIND_FAILURE);
          return transactionService.upsert(tx).orElse(null);
        });
  }

  @Transactional
  public Optional<Transaction> process3DSParesTransaction(@Nullable String code,
      @NotNull ThreeDSParesCallbackPost request) {
    return transactionService.lockByCode(code)
        .map(tx -> {
          if (tx.isCompleted() || (tx.getData().getContext().containsKey(THREEDS_TDS_MD_KEY)
              && tx.getData().getContext().containsKey(THREEDS_TDS_PARES_KEY))) {
            return Optional.of(tx);
          }
          if (request.isValid()) {
            String urlDecodedPares = request.getPares().contains("%")
                ? URLDecoder.decode(request.getPares(), StandardCharsets.UTF_8)
                : request.getPares();
            if (compareParesAndPareq(urlDecodedPares,
                (String) tx.getData().getContext().get(TDS_ORIGINAL_PAREQ))) {
              final var threeDSData = CardAdditionalUtils.getThreeds(tx.getData())
                  .orElseThrow(TransactionNotFoundException::new).getThreeDSData();
              threeDSData.setOperation(ThreeDSAdapterOperation.PARES);
              tx.getData().getContext().put(NEXT, PARES);
              tx.getData().getContext().put(THREEDS_TDS_MD_KEY, request.getMd());
              tx.getData().getContext().put(THREEDS_TDS_PARES_KEY, urlDecodedPares);
              log.info("Transaction id {} pares is valid", tx.getTransactionId());
              transactionService.upsert(tx);
            } else {
              log.error("Transaction id {} pares and pareq is not equals", tx.getTransactionId());
              transactionService.upsert(tx.withState(TransactionState.DECLINED));
            }
            return Optional.of(tx);
          } else {
            log.info("Transaction id {} pares is not valid", tx.getCode());
            transactionService.upsert(tx.withState(TransactionState.DECLINED));
            return Optional.of(tx);
          }
        }).orElse(Optional.empty());
  }

  @Transactional
  public @NotNull Optional<Transaction> proceed3DSCresTransaction(@Nullable String code,
      @NotNull ThreeDSCresCallbackPost request) {
    return transactionService.lockByCode(code)
        .map(tx -> {
          if (tx.isCompleted()
              || tx.getData().getContext().containsKey(THREEDS_TDS_CRES_KEY)) {
            log.error("Transaction id {} is in final state", tx.getTransactionId());
            return Optional.of(tx);
          }
          if (request.isValid()) {
            if (compareThreeDsServerTransId(request.getCres(),
                (String) tx.getData().getContext()
                    .get(ThreeDSContextVariables.TDS_SERVER_TID.cname()))) {
              final var threeDSData = CardAdditionalUtils.getThreeds(tx.getData())
                  .orElseThrow(TransactionNotFoundException::new).getThreeDSData();
              threeDSData.setOperation(ThreeDSAdapterOperation.CRES);
              tx.getData().getContext().put(THREEDS_TDS_CRES_KEY, request.getCres());
              tx.getData().getContext().put(TDS_NEXT, THREEDS_CRES);
              log.info("Transaction id {} cres is valid", tx.getTransactionId());
              transactionService.upsert(tx);
            } else {
              log.error("threeDSServerTransID in cres and in transaction {} is not equals",
                  tx.getTransactionId());
              transactionService.upsert(tx.withState(TransactionState.DECLINED));
            }
            return Optional.of(tx);
          } else {
            log.error("Transaction id {} cres is not valid", tx.getTransactionId());
            transactionService.upsert(tx.withState(TransactionState.DECLINED));
            return Optional.of(tx);
          }
        }).orElse(Optional.empty());
  }

  private boolean compareThreeDsServerTransId(String cres, String threeDsServerTransId) {
    return Optional.of(cres).map(value -> {
      try {
        final var map = objectMapper.readValue(
            Base64.getDecoder().decode(URLDecoder.decode(value, StandardCharsets.UTF_8)),
            MAP_TYPE_REFERENCE);
        return StringUtils.equalsIgnoreCase((String) map.get(THREE_DS_SERVER_TRANS_ID),
            threeDsServerTransId);
      } catch (IOException e) {
        log.error("Error mapping cres to map {}", e.getMessage());
        return false;
      }
    }).orElse(false);
  }

  private boolean compareParesAndPareq(String urlDecodedPares, String encodedPareq) {
    if (StringUtils.isBlank(urlDecodedPares) || StringUtils.isBlank(encodedPareq)) {
      return false;
    }
    Optional<String> pareqXid = getNodeValue(
        StringUtils.toEncodedString(compressorService.decode(encodedPareq),
            StandardCharsets.UTF_8), PAREQ_XID_XPATH);
    Optional<String> paresXid = getNodeValue(
        StringUtils.toEncodedString(compressorService.decode(urlDecodedPares),
            StandardCharsets.UTF_8), PARES_XID_XPATH);

    if (pareqXid.isPresent() && paresXid.isPresent()) {
      return Objects.equals(pareqXid.get(), paresXid.get());
    }
    return false;
  }

  private Optional<String> getNodeValue(String value, String path) {
    return Optional.ofNullable(value).map(v -> {
      String result = null;
      try {
        DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = builderFactory.newDocumentBuilder();
        Document xmlDocument = builder.parse(new InputSource(new StringReader(v)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        result = ((Node) xpath.compile(path)
            .evaluate(xmlDocument, XPathConstants.NODE)).getFirstChild().getNodeValue();
      } catch (Exception e) {
        log.error("Error parsing pares/pareq {}", e.getMessage());
      }
      return result;
    });
  }
}
