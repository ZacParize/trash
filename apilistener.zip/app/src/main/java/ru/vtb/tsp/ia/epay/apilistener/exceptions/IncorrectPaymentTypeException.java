package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class IncorrectPaymentTypeException extends RuntimeException {

  public IncorrectPaymentTypeException() {
    super();
  }

  public IncorrectPaymentTypeException(String message) {
    super(message);
  }

  public IncorrectPaymentTypeException(String message, Throwable cause) {
    super(message, cause);
  }

  public IncorrectPaymentTypeException(Throwable cause) {
    super(cause);
  }

  public IncorrectPaymentTypeException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
