package ru.vtb.tsp.ia.epay.apilistener.services.standin;

import io.etcd.jetcd.Client;
import java.time.Duration;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;
import ru.vtb.smartreplication.configuration.etcd.AbstractEtcdConfigurationManager;
import ru.vtb.smartreplication.model.ChangeSource;
import ru.vtb.smartreplication.model.ChangeSourceVersioned;

public class MockEtcdConfigurationManager extends AbstractEtcdConfigurationManager {

  private static final Map<String, ChangeSource> CHANGE_SOURCE_MAP = new ConcurrentHashMap<>();
  private static final Map<String, ChangeSource> PREV_CHANGE_SOURCE_MAP = new ConcurrentHashMap<>();
  protected final AtomicReference<Boolean> replicationStatus = new AtomicReference<>(true);

  public MockEtcdConfigurationManager(Client client, long connectionTimeoutMs) {
    super(null, 0L);
  }

  @Override
  public void start() {
  }

  @Override
  public void stop() {

  }

  @Override
  public long setChangeSource(String owner, ChangeSource changeSource, long version) {
    CHANGE_SOURCE_MAP.put(owner, changeSource);
    return version + 1;
  }

  @Override
  public void setChangeSource(String owner, ChangeSource changeSource) {
    CHANGE_SOURCE_MAP.put(owner, changeSource);
  }

  @Override
  public ChangeSource getChangeSource(String owner) {
    return Objects.isNull(CHANGE_SOURCE_MAP.get(owner)) ? ChangeSource.MAIN
        : CHANGE_SOURCE_MAP.get(owner);
  }

  @Override
  public ChangeSourceVersioned getChangeSourceVersioned(String owner) {
    return ChangeSourceVersioned.builder()
        .changeSource(CHANGE_SOURCE_MAP.get(owner))
        .version(0)
        .build();
  }

  @Override
  public void setPrevChangeSource(String owner, ChangeSource changeSource) {
    PREV_CHANGE_SOURCE_MAP.put(owner, changeSource);
  }

  @Override
  public ChangeSource getPrevChangeSource(String owner) {
    return PREV_CHANGE_SOURCE_MAP.get(owner);
  }

  @Override
  public void createOwner(String changeOwner, ChangeSource initChangeSource) {

  }

  @Override
  public List<String> getOwners() {
    return List.of("efcp");
  }

  @Override
  public void deleteOwner(String owner) {

  }

  @Override
  public void createTopicEndpoint(String topicName, String endpointName) {

  }

  @Override
  public void deleteTopicEndpoint(String topic, String endpoint) {

  }

  @Override
  public boolean ownerExists(String owner) {
    return true;
  }

  @Override
  public boolean previousStateExists(String owner) {
    return !PREV_CHANGE_SOURCE_MAP.isEmpty();
  }

  @Override
  public boolean endpointExists(String topicName, String endpointName) {
    return false;
  }

  @Override
  public void pauseConsumer(String owner, String endpoint) {

  }

  @Override
  public void resumeConsumer(String owner, String endpoint) {

  }

  @Override
  public boolean isConsumerPaused(String owner, String endpoint) {
    return true;
  }

  @Override
  public boolean isConsumerGroupPaused(String consumerGroup) {
    return false;
  }

  @Override
  public void pauseProducer(String topic) {

  }

  @Override
  public void resumeProducer(String topic) {

  }

  @Override
  public boolean isProducerPaused(String topic) {
    return false;
  }

  @Override
  public List<String> getSelfCheckerResumeConsumers() {
    return Collections.emptyList();
  }

  @Override
  public List<String> getSelfCheckerPauseConsumers() {
    return Collections.emptyList();
  }

  @Override
  public List<String> getSelfCheckerTombstoneConsumers() {
    return null;
  }

  @Override
  public void createSelfCheckerPauseNode(UUID uuid) {

  }

  @Override
  public void deleteSelfCheckerPauseNode(UUID uuid) {

  }

  @Override
  public void createSelfCheckerResumeNode(UUID uuid) {

  }

  @Override
  public void deleteSelfCheckerResumeNode(UUID uuid) {

  }

  @Override
  public void createSelfCheckerTombstoneNode(UUID uuid) {

  }

  @Override
  public void deleteSelfCheckerTombstoneNode(UUID uuid) {

  }

  @Override
  public void saveSelfCheckerConsumerInfo(UUID uuid, byte[] data, Duration duration) {

  }

  @Override
  public byte[] getSelfCheckerConsumerInfo(UUID uuid, Duration duration) {
    return new byte[0];
  }

  @Override
  public List<byte[]> getSelfCheckConsumersInfo(Duration duration) {
    return null;
  }

  @Override
  public void createSelfCheckerRoots() {

  }

  @Override
  public void watchStandInStatus(String owner, AtomicReference<ChangeSource> changeSource,
      Supplier<Boolean> isCustomReplicationEnabled) {

  }

  @Override
  public void watchEnableReplicationStatus(String owner,
      AtomicReference<Boolean> isReplicationEnabled, Supplier<Boolean> isCustomReplicationEnabled) {

  }

  @Override
  public boolean getEnableReplicationStatus(String owner) {
    return replicationStatus.get();
  }

  @Override
  public void setEnableReplicationStatus(String owner, boolean status) {
    replicationStatus.set(status);
  }
}
