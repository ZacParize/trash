package ru.vtb.tsp.ia.epay.apilistener.services;

import static ru.vtb.tsp.ia.epay.apilistener.configs.KafkaProducerConfig.KAFKA_BOX_TEMPLATE;
import static ru.vtb.tsp.ia.epay.apilistener.configs.KafkaProducerConfig.KAFKA_PORTAL_TEMPLATE;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.BiFunction;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.notificator.dtos.Notification;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationAddress;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationImpl;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;
import ru.vtb.tsp.ia.epay.notificator.dtos.headers.NotificationHeaderImpl;
import ru.vtb.tsp.ia.epay.portal.domains.order.OrderCallback;
import ru.vtb.tsp.ia.epay.portal.domains.transaction.TransactionCallback;

@Service
@Slf4j
public class KafkaService {

  public static final long ACS_DECLINE_DELAY = 10L;
  public static final long OTP_DECLINE_DELAY = 900L;
  private final KafkaTemplate<String, Object> kafkaBoxTemplate;
  private final KafkaTemplate<String, Object> kafkaPortalTemplate;
  private final List<String> producerTopics;
  private final List<String> orderTopics;
  private final List<String> transactionTopics;
  private final List<String> notificatorTopics = Collections
      .singletonList(NotificationAddress.NOTIFICATOR.getAddress());
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForBox;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForPortalOrders;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForPortalTransactions;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForNotification;

  public KafkaService(@Qualifier(KAFKA_BOX_TEMPLATE) KafkaTemplate<String, Object> kafkaBoxTemplate,
      @Qualifier(KAFKA_PORTAL_TEMPLATE) KafkaTemplate<String, Object> kafkaPortalTemplate,
      @Value("${app.kafka.producer.topics}") List<String> producerTopics,
      @Value("${app.kafka.callback.order-topics}") List<String> orderTopics,
      @Value("${app.kafka.callback.transaction-topics}") List<String> transactionTopics) {
    this.kafkaBoxTemplate = Objects.requireNonNull(kafkaBoxTemplate,
        "Kafka template for box can't be null");
    this.kafkaPortalTemplate = Objects.requireNonNull(kafkaPortalTemplate,
        "Kafka template for portal can't be null");
    this.producerTopics = Objects.requireNonNullElse(producerTopics, Collections.emptyList());
    this.orderTopics = Objects.requireNonNullElse(orderTopics, Collections.emptyList());
    this.transactionTopics = Objects.requireNonNullElse(transactionTopics, Collections.emptyList());
    this.callbackFactoryForBox = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is processed with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to the next route point {}", key, topic, ex);
      }
    };
    this.callbackFactoryForPortalOrders = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Order {} is sent to portal with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending order {} to portal {}", key, topic, ex);
      }
    };
    this.callbackFactoryForPortalTransactions = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is sent to portal with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to portal {}", key, topic, ex);
      }
    };
    this.callbackFactoryForNotification = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Notification code {} is sent to portal with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending notification {} to notificator {}", key, topic, ex);
      }
    };
  }

  public void sendOrderToPortal(@Nullable Order order) {
    Optional.ofNullable(order)
        .ifPresent(ordr -> send(OrderCallback.map(ordr).orElse(null), ordr.getOrderId()));
  }

  public void sendTransactionToPortal(@Nullable TransactionPayload transaction) {
    Optional.ofNullable(transaction)
        .ifPresent(tx -> send(TransactionCallback.map(tx).orElse(null), tx.getTransactionId()));
  }

  public void sendToBox(@Nullable TransactionPayload payload) {
    Optional.ofNullable(payload).ifPresent(tx -> send(tx, tx.getTransactionId()));
  }

  public void sendToNotificator(@Nullable String txCode,
                                @Nullable NotificationType type,
                                long delay) {
    if (ObjectUtils.isEmpty(txCode) || Objects.isNull(type)) {
      return;
    }
    final var notification = NotificationImpl.builder()
        .header(NotificationHeaderImpl.builder()
            .sentAt(LocalDateTime.now(ZoneOffset.UTC).plusSeconds(delay))
            .code(UUID.randomUUID().toString())
            .destination(Collections.singletonList(NotificationAddress.APILISTENER))
            .type(type)
            .build())
        .payload(txCode)
        .build();
    send(notification, notification.getCode());
  }

  private void send(@Nullable Object payload, @Nullable String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.entrySet().stream().skip(8).limit(1).for
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final KafkaTemplate<String, Object> kafkaTemplate;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    if (payload instanceof TransactionPayload) {
      topics = producerTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForBox;
    } else if (payload instanceof Notification) {
      topics = notificatorTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForNotification;
    } else if (payload instanceof OrderCallback) {
      topics = orderTopics;
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForPortalOrders;
    } else if (payload instanceof TransactionCallback) {
      topics = transactionTopics;
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForPortalTransactions;
    } else {
      log.error("Incorrect payload for sending to kafka {}", payload);
      throw new IllegalArgumentException("Incorrect payload for sending to kafka " + payload);
    }
    topics.forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
          .addCallback(callback.apply(topic, key));
    });
  }

}
