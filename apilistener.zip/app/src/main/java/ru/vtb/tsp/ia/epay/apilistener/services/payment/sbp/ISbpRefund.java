package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;

public interface ISbpRefund {

  @NotNull Optional<Transaction> registerRefund(@NotNull RefundRequestDto requestDto,
      @Nullable Transaction transaction,
      @Nullable String mstId);

  @NotNull Optional<Transaction> processCompleteRefund(
      @Nullable SbpRefundStatusResponseDto request);

  @NotNull Optional<Transaction> processConfirmRefund(
      @Nullable SbpConfirmRefundCallbackDto request);

}
