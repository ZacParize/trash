package ru.vtb.tsp.ia.epay.apilistener.services.clients.key.pan;

import javax.validation.constraints.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.apilistener.services.PublicKeyDto;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.ExtPrometheusMertics;

@ExtPrometheusMertics
public interface PanKeyApi {

  @GetMapping(path = "/getPublicKey", produces = "application/json")
  @NotNull ResponseEntity<PublicKeyDto> getKey(@RequestHeader HttpHeaders httpHeaders);

}