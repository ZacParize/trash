package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class KeysNotFoundException extends ServiceException {

  {
    this.exception = ApplicationException.KEYS_NOT_FOUND;
  }

  public KeysNotFoundException() {
  }

  public KeysNotFoundException(String message) {
    super(message);
  }

  public KeysNotFoundException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public KeysNotFoundException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}