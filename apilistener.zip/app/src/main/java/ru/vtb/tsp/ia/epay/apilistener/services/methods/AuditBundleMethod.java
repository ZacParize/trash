package ru.vtb.tsp.ia.epay.apilistener.services.methods;

import freemarker.ext.beans.BeanModel;
import freemarker.template.TemplateMethodModelEx;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AuditBundleDto;
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.AuditBundleMapper;
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.AuditBundleMapperImpl;

public class AuditBundleMethod implements TemplateMethodModelEx {

  private static final String EMPTY_RESULT = "";
  private final AuditBundleMapper mapper = new AuditBundleMapperImpl();

  @Override
  public Object exec(List arguments) {
    if (arguments.isEmpty()) {
      return EMPTY_RESULT;
    } else {
      BeanModel model = (BeanModel) arguments.get(0);
      OrderCreationRequestDto requestDto = (OrderCreationRequestDto) model.getAdaptedObject(
          OrderCreationRequestDto.class);

      if (Objects.isNull(requestDto.getBundle()) || CollectionUtils.isEmpty(
          requestDto.getBundle().getItems())) {
        return EMPTY_RESULT;
      }

      List<AuditBundleDto> result = new ArrayList<>();

      requestDto.getBundle().getItems()
          .forEach(bundle -> result.add(mapper.mapBundleItemRequestDtoToAuditBundleDto(bundle)));

      return result.toString();
    }
  }
}
