package ru.vtb.tsp.ia.epay.apilistener.services;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CompressorService {

  private static final Base64.Encoder ENCODER = Base64.getEncoder();

  public byte[] decode(String base64) {
    return decompress(Base64.getDecoder().decode(base64));
  }

  /**
   * PARES в запросе закодирован в BASE64 и сжат zlib.
   *
   * @param bytesToDecompress -массив байт раскодированного PARES из Base64.
   * @return - массив распакованного  ZLIBом  пареса, фактически готовый читаемый xml
   */
  public byte[] decompress(byte[] bytesToDecompress) {
    byte[] returnValues = null;
    Inflater inflater = new Inflater();
    int numberOfBytesToDecompress = bytesToDecompress.length;
    inflater.setInput(bytesToDecompress, 0, numberOfBytesToDecompress);
    int bufferSizeInBytes = numberOfBytesToDecompress;
    int numberOfBytesDecompressedSoFar = 0;
    List<Byte> bytesDecompressedSoFar = new ArrayList<Byte>();
    try {
      while (inflater.needsInput() == false) {
        byte[] bytesDecompressedBuffer = new byte[bufferSizeInBytes];
        int numberOfBytesDecompressedThisTime = inflater.inflate(bytesDecompressedBuffer);
        numberOfBytesDecompressedSoFar += numberOfBytesDecompressedThisTime;
        for (int b = 0; b < numberOfBytesDecompressedThisTime; b++) {
          bytesDecompressedSoFar.add(bytesDecompressedBuffer[b]);
        }
      }
      returnValues = new byte[bytesDecompressedSoFar.size()];
      for (int b = 0; b < returnValues.length; b++) {
        returnValues[b] = (byte) (bytesDecompressedSoFar.get(b));
      }
    } catch (DataFormatException e) {
      log.error("Pares unzip error {}", e.getMessage());
    } finally {
      inflater.end();
    }
    return returnValues;
  }

  public String decompressToString(byte[] bytesToDecompress) {
    byte[] bytesDecompressed = this.decompress(bytesToDecompress);
    String returnValue = null;
    returnValue = new String(bytesDecompressed, 0, bytesDecompressed.length,
        StandardCharsets.UTF_8);
    return returnValue;
  }

  public String compress(byte[] bytesToCompress) {
    Deflater deflater = new Deflater();
    deflater.setInput(bytesToCompress);
    deflater.finish();
    byte[] bytesCompressed = new byte[Short.MAX_VALUE];
    int numberOfBytesAfterCompression = deflater.deflate(bytesCompressed);
    byte[] returnValues = new byte[numberOfBytesAfterCompression];
    System.arraycopy(bytesCompressed, 0, returnValues, 0, numberOfBytesAfterCompression);
    return ENCODER.encodeToString(returnValues);
  }
}
