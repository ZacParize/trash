package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface ICardPayment {

  @NotNull Optional<Transaction> processPayment(@NotNull Order order);

  @NotNull Optional<Transaction> processPayment(@Nullable String orderCode,
      @Nullable AmountRequestDto amount,
      @Nullable String email,
      @Nullable String encryptedPan,
      @Nullable String encryptedCvv,
      @Nullable String cardHolder,
      @Nullable String expiryDate);

  @NotNull Optional<Transaction> processPayment(PaymentCardRequest paymentCardRequest,
      MerchantSite merchantSite);

  @NotNull Optional<Transaction> completeTwoStageCardPayment(@Nullable String mstId,
      @Nullable String mstOrderId,
      @NotNull AmountRequestDto amount);
}
