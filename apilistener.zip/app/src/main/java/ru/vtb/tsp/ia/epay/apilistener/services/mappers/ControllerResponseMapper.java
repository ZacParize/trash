package ru.vtb.tsp.ia.epay.apilistener.services.mappers;

import org.mapstruct.Mapper;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectIgnorePreparedPaymentsAndSourceSystemResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectIgnoreSourceSystemAndTransactionsResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectIgnoreSourceSystemResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectResponseDto;

@Mapper(componentModel = "spring")
public interface ControllerResponseMapper {

  TypedResponseDto<OrderObjectIgnoreSourceSystemResponseDto>
      mapOrderToIgnoreSourceSystemResponseDto(TypedResponseDto<OrderObjectResponseDto> response);

  TypedResponseDto<OrderObjectIgnorePreparedPaymentsAndSourceSystemResponseDto>
      mapOrderToIgnoreSourceSystemAndPreparedPaymentsResponseDto(
          TypedResponseDto<OrderObjectResponseDto> response);

  TypedResponseDto<OrderObjectIgnoreSourceSystemAndTransactionsResponseDto>
      mapOrderObjectIgnoreSourceSystemAndTransactionsResponseDto(
          TypedResponseDto<OrderObjectResponseDto> response);

}