package ru.vtb.tsp.ia.epay.apilistener.services.bundle;

import java.util.UUID;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

public interface BundleService {

  BundleDto create(UUID orderCode, BundleRequestDto bundle);

  BundleDto getBundleByOrderCode(String orderId);
}
