package ru.vtb.tsp.ia.epay.apilistener.services.clients.fiscalization;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "fiscalizationApiClient",
    url = "${app.fiscalization-domain.url}", decode404 = true)
@ConditionalOnProperty(name = "app.fiscalization-domain.mock", havingValue = "false")
public interface FiscalizationApiClient extends FiscalizationApi {

}