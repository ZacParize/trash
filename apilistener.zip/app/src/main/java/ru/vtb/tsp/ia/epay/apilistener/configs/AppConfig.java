package ru.vtb.tsp.ia.epay.apilistener.configs;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Slf4j
@Configuration
@EnableKafka
@EnableTransactionManagement
@EnableScheduling
@ComponentScan({"ru.vtb.tsp.ia.epay.apilistener", "ru.vtb.tsp.ia.epay.core",
    "ru.vtb.tsp.ia.epay.customer.implementations"})
@EnableCaching(proxyTargetClass = true)
@RequiredArgsConstructor
public class AppConfig {
}