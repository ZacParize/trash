package ru.vtb.tsp.ia.epay.apilistener.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.entities.customer.Customer;
import ru.vtb.tsp.ia.epay.core.repositories.CustomerRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class CustomerService {

  private final CustomerRepository customerRepository;

  public @NotNull List<Customer> getByPhoneAndEmail(@Nullable String phone,
      @Nullable String email) {
    if (Objects.isNull(phone) || Objects.isNull(email)) {
      return Collections.emptyList();
    }
    final var customers = new ArrayList<Customer>();
    customerRepository.findByPhoneAndEmail(phone, email).forEach(c ->
        customers.add(Customer.builder()
            .customerId(c.getCustomerId())
            .email(c.getEmail())
            .phone(c.getPhone()).build()));
    return customers;
  }

  @Transactional
  public @Nullable Optional<Customer> upsert(@Nullable String phone, @Nullable String email) {
    if (ObjectUtils.isEmpty(phone) || ObjectUtils.isEmpty(email)) {
      return Optional.empty();
    }
    return Optional.ofNullable(
        customerRepository.saveOrUpdate(Customer.builder().customerId(UUID.randomUUID().toString())
            .email(email)
            .phone(phone).build()));
  }
}