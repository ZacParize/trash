package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;

public interface ISbpPayment {

  @NotNull Optional<Transaction> processPayment(@NotNull SbpPaymentStatusResponseDto request);

  @NotNull Optional<String> getQr(@Nullable String orderId);
}
