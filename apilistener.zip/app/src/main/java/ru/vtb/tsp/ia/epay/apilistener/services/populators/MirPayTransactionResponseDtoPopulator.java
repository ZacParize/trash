package ru.vtb.tsp.ia.epay.apilistener.services.populators;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayTransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.services.LinksService;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@Component
@RequiredArgsConstructor
public class MirPayTransactionResponseDtoPopulator {

  private final LinksService linksService;

  public @NotNull MirPayTransactionResponseDto populate(@NotNull Transaction transaction) {
    Objects.requireNonNull(transaction, "Transaction can't be null");

    final var responseBuilder = MirPayTransactionResponseDto.builder();
    final var paymentMethod =
        ConverterUtils.getPaymentMethod(transaction.getData().getPaymentData());
    final var transactionStatus = Optional.ofNullable(transaction.getState())
        .map(Enum::name)
        .orElse(null);
    final var createdAt = Optional.ofNullable(transaction.getCreatedAt())
        .map(LocalDateTime::toString)
        .orElse(null);
    final var mirPayLink = linksService.createMirPayLink(transaction.getOrder());

    return responseBuilder.paymentMethod(paymentMethod)
        .transactionCode(transaction.getCode())
        .transactionStatus(transactionStatus)
        .createdAt(createdAt)
        .mirPayLink(mirPayLink)
        .build();
  }

}
