package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class OperationNotSupported extends ServiceException {

  {
    this.exception = ApplicationException.OPERATION_NOT_SUPPORTED_ERROR;
  }

  public OperationNotSupported() {
  }

  public OperationNotSupported(String message) {
    super(message);
  }

  public OperationNotSupported(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public OperationNotSupported(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}