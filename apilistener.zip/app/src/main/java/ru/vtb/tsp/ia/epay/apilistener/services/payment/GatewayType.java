package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.A2C_TRANSFER;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.C2A_TRANSFER;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_PAYMENT;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_PAYMENT_TWO_STAGE;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_PAYMENT_TWO_STAGE_3DS;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_PAYMENT_WITHOUT_3DS;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.COF_PAYMENT;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.GW_PAYMENT;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.MIR_PAYMENT_WEB_BASED;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.MIR_PAYMENT_WEB_BASED_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_CARD_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_SBP_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.SBP_PAYMENT;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.SBP_REFUND;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import java.util.Arrays;
import java.util.Set;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;


@Getter
@RequiredArgsConstructor
@JsonFormat(shape = Shape.OBJECT)
public enum GatewayType {
  CARD(Set.of(
      CARD_PAYMENT,
      CARD_PAYMENT_WITHOUT_3DS,
      CARD_REFUND,
      PARTIAL_CARD_REFUND,
      CARD_PAYMENT_TWO_STAGE,
      CARD_PAYMENT_TWO_STAGE_3DS,
      COF_PAYMENT,
      GW_PAYMENT)),

  SBP(Set.of(
      SBP_PAYMENT,
      SBP_REFUND,
      PARTIAL_SBP_REFUND)),

  TRANSFER(Set.of(
      A2C_TRANSFER,
      C2A_TRANSFER)),

  MIR_PAY(Set.of(
      MIR_PAYMENT_WEB_BASED,
      MIR_PAYMENT_WEB_BASED_REFUND,
      PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND));

  private final Set<TransactionType> states;

  public static GatewayType fromTxType(TransactionType txType) {
    return Arrays.stream(GatewayType.values())
        .filter(v -> v.getStates().contains(txType))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Unknown TransactionType: " + txType));
  }

}
