package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.Objects;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.PreAuthOrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.Card2StageCompleteRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.TwoStagePaymentRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectIgnoreSourceSystemResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.RefundObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.TransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.services.ResponseService;
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.ControllerResponseMapper;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.OrderCounterMetric;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.SbpQrCounterMetric;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class MerchantController {

  private static final String ORDERS_PATH = "/orders";
  private static final String ORDER_ID_PATH_VARIABLE = "orderId";
  private static final String REFUND_ID_PATH_VARIABLE = "refundId";
  private static final String GET_ORDERS_PATH = "/orders/{" + ORDER_ID_PATH_VARIABLE + "}";
  private static final String POST_CREATE_REFUNDS_PATH = "/refunds";
  private static final String GET_REFUNDS_PATH = "/refunds/{" + REFUND_ID_PATH_VARIABLE + "}";
  private static final String POST_CREATE_PREAUTH_ORDERS_PATH =
      ORDERS_PATH + "/preauth";
  private static final String POST_PAYMENTS_COMPLETE_PATH = ORDERS_PATH
      + "/complete/{" + ORDER_ID_PATH_VARIABLE + "}";
  private static final String PAYMENTS_PATH = "/payments";

  private final OrderServiceFacade orderServiceFacade;
  private final PaymentService paymentService;
  private final KafkaService kafkaService;
  private final ResponseService responseService;
  private final ControllerResponseMapper mapper;

  @AuditProcess("TSPACQ_BOX_CREATE_ORDER")
  @PostMapping(path = "${app.api.prefix}"
      + ORDERS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = OrderObjectIgnoreSourceSystemResponseDto.class))
  })
  @SbpQrCounterMetric
  @OrderCounterMetric
  public @NotNull ResponseEntity<?> createOrder(
      @RequestBody @NotNull @Valid OrderCreationRequestDto creationRequestDto) {
    log.info("Received create order request {}", creationRequestDto);
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    final var order = orderServiceFacade.getByMstOrderId(mst.getId(),
            creationRequestDto.getOrderId())
        .orElseGet(() -> orderServiceFacade.create(creationRequestDto, mst, SourceSystem.ECOM)
            .map(ord -> {
              kafkaService.sendOrderToPortal(ord);
              return ord;
            })
            .map(ord -> {
              if (Objects.nonNull(creationRequestDto.getBinding())) {
                paymentService.registerPayment(ord, GatewayType.CARD);
              }
              return ord;
            })
            .orElseThrow(() -> new ValidationException("Can't create order " + creationRequestDto))
        );
    return ResponseEntity.ok(mapper.mapOrderObjectIgnoreSourceSystemAndTransactionsResponseDto(
        responseService.toOrderResponse(order, creationRequestDto.getReturnPaymentData())));
  }

  @AuditProcess("TSPACQ_BOX_CREATE_2STAGE_ORDER")
  @PostMapping(path = "${app.api.prefix}"
      + POST_CREATE_PREAUTH_ORDERS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = OrderObjectIgnoreSourceSystemResponseDto.class))
  })
  @OrderCounterMetric
  public @NotNull ResponseEntity<?> createPreAuthOrder(
      @RequestBody @NotNull @Valid PreAuthOrderCreationRequestDto creationRequestDto) {
    log.info("Received pre auth create order request {}", creationRequestDto);
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    if (!mst.isEnableTwoStagePayment()) {
      log.warn("Merchant site id = {} with disabled two stage payment", mst.getId());
      throw new OperationNotSupported();
    }
    final var order = orderServiceFacade.getByMstOrderId(mst.getId(),
            creationRequestDto.getOrderId())
        .orElseGet(() -> orderServiceFacade.create(creationRequestDto, mst, SourceSystem.ECOM)
            .map(ord -> {
              kafkaService.sendOrderToPortal(ord);
              return ord;
            })
            .orElseThrow(
                () -> new ValidationException("Can't create order " + creationRequestDto)));
    return ResponseEntity.ok(mapper.mapOrderToIgnoreSourceSystemResponseDto(
        responseService.toOrderResponse(order, null)));
  }

  @GetMapping(path = "${app.api.prefix}" + GET_ORDERS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = OrderObjectIgnoreSourceSystemResponseDto.class))
  })
  public @NotNull ResponseEntity<?> getOrder(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String mstOrderId) {
    log.info("Received get order request {}", mstOrderId);
    final var mstId = ((MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal()).getId();
    log.info("Received get order request merchant site id {}", mstId);
    return orderServiceFacade.getByMstOrderId(mstId, mstOrderId)
        .map(order -> responseService.toOrderResponse(order, null))
        .map(mapper::mapOrderToIgnoreSourceSystemResponseDto)
        .map(ResponseEntity::ok)
        .orElseThrow(() -> new ValidationException("Incorrect order id " + mstOrderId));
  }

  @GetMapping(path = "${app.api.prefix}" + GET_REFUNDS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = RefundObjectResponseDto.class))
  })
  public @NotNull ResponseEntity<?> getRefund(
      @PathVariable(REFUND_ID_PATH_VARIABLE) @NotBlank String refundId) {
    log.info("Received get refund request {}", refundId);
    final var mstId = ((MerchantSite) SecurityContextHolder.getContext()
        .getAuthentication().getPrincipal()).getId();
    return responseService.toRefundResponse(mstId, refundId);
  }

  @AuditProcess("TSPACQ_BOX_REFUND_FROM_MERCHANT")
  @PostMapping(path = "${app.api.prefix}"
      + POST_CREATE_REFUNDS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = RefundObjectResponseDto.class))
  })
  public @NotNull ResponseEntity<?> createRefund(
      @RequestBody @NotNull @Valid RefundRequestDto refundRequestDto) {
    log.info("Received create refund request {}", refundRequestDto);
    final var merchantSite = ((MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal());
    log.info("Received create refund request merchant site id {}", merchantSite.getId());
    return paymentService.registerRefund(refundRequestDto, merchantSite)
        .map(ConverterUtils::convertToRefundResponse)
        .map(ResponseEntity::ok)
        .orElseThrow(
            () -> new ValidationException("Can't create refund " + refundRequestDto));
  }

  @AuditProcess("TSPACQ_BOX_COMPLETE_2STAGE_ORDER")
  @PostMapping(path = "${app.api.prefix}" + POST_PAYMENTS_COMPLETE_PATH,
      produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<?> completeTwoStageCardPayment(
      @NotBlank @Size(min = 1, max = 64) @PathVariable(ORDER_ID_PATH_VARIABLE) String mstOrderId,
      @RequestBody @NotNull @Valid TwoStagePaymentRequest request) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received two stage complete request mst order id {} from merchant site id {}",
        mstOrderId, mst.getId());
    final var card2StageCompleteRequestDto = Card2StageCompleteRequestDto.builder()
        .amount(request.getAmount())
        .mstId(mst.getId())
        .mstOrderId(mstOrderId)
        .build();
    return paymentService.registerPayment(card2StageCompleteRequestDto, GatewayType.CARD)
        .map(Transaction::getOrder)
        .map(order -> responseService.toOrderResponse(order, null))
        .map(mapper::mapOrderToIgnoreSourceSystemAndPreparedPaymentsResponseDto)
        .map(ResponseEntity::ok)
        .orElseThrow(() -> new ValidationException("Incorrect mst order id " + mstOrderId));
  }

  @AuditProcess("TSPACQ_BOX_ECOMMERCE_CANCEL_ORDER")
  @PostMapping(path = "${app.api.prefix}" + ORDERS_PATH + "/{mstOrderId}/cancel",
      produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> cancelOrder(@NotBlank @PathVariable("mstOrderId") String mstOrderId) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received cancel order with merchant order id {} from merchant site id {}", mstOrderId,
        mst.getId());
    return paymentService.cancelOrder(mst.getId(), mstOrderId)
        .map(order -> responseService.toOrderResponse(order, null))
        .map(mapper::mapOrderToIgnoreSourceSystemAndPreparedPaymentsResponseDto)
        .map(ResponseEntity::ok)
        .orElseThrow(() -> new ValidationException("Incorrect mst order code " + mstOrderId));
  }

  @AuditProcess("TSPACQ_BOX_PAYMENTS")
  @PostMapping(path = "${app.api.prefix}" + PAYMENTS_PATH, produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> payment(@Valid @RequestBody PaymentCardRequest paymentCardRequest) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received common card payment with merchant order id {} from merchant site id {}",
        paymentCardRequest.getOrderId(),
        mst.getId());
    return paymentService.registerPayment(paymentCardRequest, mst, GatewayType.CARD)
        //.processCardPayment(paymentCardRequest, mst)
        .map(ConverterUtils::buildTransactionResponse)
        .map(ResponseEntity::ok)
        .orElseThrow(TransactionNotFoundException::new);
  }
}