package ru.vtb.tsp.ia.epay.apilistener.configs.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Properties of 3DS.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.10.2021
 */
@Data
@Configuration
@ConfigurationProperties("threeds")
public class ThreedsProperties {
  private boolean pareqUrlEncoded;
  private boolean paresUrlEncoded;
  private ThreedsAcsLinks acsLinks;
  private boolean pareqRemoveTab;
}
