package ru.vtb.tsp.ia.epay.apilistener.services.threeds;

import java.io.Serializable;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.GetThreeDSDecisionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.PostThreeDSDecisionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.LinksService;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSDecisionService;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSAdapterOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.BrowserInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.core.utils.CardAdditionalUtils;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Service
@RequiredArgsConstructor
public class ThreeDSDecisionServiceImpl implements ThreeDSDecisionService {

  private final TransactionService transactionService;
  private final KafkaService kafkaService;
  private final LinksService linksService;
  private static final String TDS_ACS_URL = "TDS_ACS_URL";

  @Override
  public PostThreeDSDecisionResponseDto fill3DSDataFrom3DSDecision(
      ThreeDSDecisionCallbackDto decision,
      String transactionCode) {
    final var trx = transactionService.getByCode(transactionCode);
    if (trx.isEmpty()) {
      throw new TransactionNotFoundException();
    }
    return trx
        .map(transaction -> {
          ConverterUtils.checkTransactionWithError(transaction);
          CardAdditionalUtils.getThreeds(transaction.getData())
              .map(Threeds::getThreeDSData)
              .ifPresent(threeDSData -> {
                final var info = mapThreeDSDecisionToBrowserInfo(decision);
                threeDSData.setBrowserInfo(info);
                threeDSData.setDeviceChannel("02");
                threeDSData.setThreeDSRequestorUrl(transaction.getMst().getUrl());
                threeDSData.setOperation(ThreeDSAdapterOperation.AREQ);
                threeDSData.setMcc(transaction.getMst().getParams().getMcc());
                threeDSData.setMerchantName(transaction.getMst().getName());
                threeDSData.setNotificationUrlCres(
                    linksService.createLinkThreeDsCres(transactionCode));
              });
          return transaction;
        })
        .map(transaction -> {
          transaction.getData().getContext().put("3DS_DECISION_COMPLETE", Boolean.TRUE);
          return transaction;
        }).flatMap(transactionService::upsert)
        .map(transaction -> {
          Map<String, Serializable> context = transaction.getData().getContext();
          if (context.containsKey("3DS_DECISION_COMPLETE") && context.containsKey("3DS_COMP_IND")) {
            kafkaService.sendToBox(transaction.getData());
          }
          return PostThreeDSDecisionResponseDto.builder().isExecuted(true).build();
        })
        .orElse(PostThreeDSDecisionResponseDto.builder().isExecuted(false).build());
  }

  @Override
  public GetThreeDSDecisionResponseDto getThreedsDecisionStatus(String transactionCode) {
    final var trx = transactionService.getByCode(transactionCode);
    if (trx.isEmpty()) {
      throw new TransactionNotFoundException();
    }
    return trx
        .map(transaction -> {
          ConverterUtils.checkTransactionWithError(transaction);
          return transaction;
        })
        .map(Transaction::getData)
        .map(payload -> {
          final var response = new GetThreeDSDecisionResponseDto();
          response.setThreeDSDecisionStatus(calculateResponseStatus(payload));
          fillFlowBasedData(payload, response);
          return response;
        })
        .orElseThrow(TransactionNotFoundException::new);
  }

  private String calculateResponseStatus(TransactionPayload payload) {
    return getFlowVersion(payload)
        .filter(threeDSVersion -> !ThreeDSVersion.V2_0.equals(threeDSVersion))
        .map(threeDSVersion -> "SUCCESS")
        .orElse("PENDING");
  }

  private void fillFlowBasedData(TransactionPayload payload,
      GetThreeDSDecisionResponseDto response) {
    getFlowVersion(payload)
        .ifPresent(version -> {
          switch (version) {
            case V2_0_FRICTIONLESS: {
              fillFrictionlessFlowData(payload, response);
              break;
            }
            case V2_0_CHALLENGE: {
              fillChallengeFlowData(payload, response);
              break;
            }
            default: {
            }
          }
        });
  }

  private Optional<ThreeDSVersion> getFlowVersion(TransactionPayload payload) {
    return CardAdditionalUtils.getThreeds(payload)
        .map(Threeds::getThreeDSData)
        .map(ThreeDSData::getThreeDsVersion);
  }

  private void fillFrictionlessFlowData(TransactionPayload payload,
      GetThreeDSDecisionResponseDto response) {
    response.setIsChallengeFlow(false);
  }

  private void fillChallengeFlowData(TransactionPayload payload,
      GetThreeDSDecisionResponseDto response) {
    response.setIsChallengeFlow(true);
    response.setMerchantUrl(payload.getMerchant().getUrl());
    final var context = payload.getContext();
    if (context.containsKey(ThreeDSContextVariables.TDS_CREQ.cname()) && !ObjectUtils.isEmpty(
        context.get(ThreeDSContextVariables.TDS_CREQ.cname()))) {
      response.setCReq((String) context.get(ThreeDSContextVariables.TDS_CREQ.cname()));

      kafkaService.sendToNotificator(payload.getTransactionCode(),
          NotificationType.OTP_PAGE_TIMEOUT, KafkaService.OTP_DECLINE_DELAY);
    }
    response.setThreeDSSessionData(payload.getTransactionCode());
    response.setOtpPageUrl((String) payload.getContext().get(TDS_ACS_URL));
  }

  private BrowserInfo mapThreeDSDecisionToBrowserInfo(ThreeDSDecisionCallbackDto source) {
    final var info = new BrowserInfo();
    info.setColorDepth(notEmptyOrNull(source.getBrowserColorDepth()));
    info.setIp(notEmptyOrNull(source.getBrowserIp()));
    info.setLanguage(notEmptyOrNull(source.getBrowserLanguage()));
    info.setJavaEnabled(notEmptyOrNull(source.getBrowserJavaEnabled()));
    info.setScreenHeight(notEmptyOrNull(source.getBrowserScreenHeight()));
    info.setScreenWidth(notEmptyOrNull(source.getBrowserScreenWidth()));
    info.setTz(notEmptyOrNull(source.getBrowserTZ()));
    info.setUserAgent(notEmptyOrNull(source.getBrowserUserAgent()));
    info.setWindowHeight(notEmptyOrNull(source.getWindowHeight()));
    info.setWindowsWidth(notEmptyOrNull(source.getWindowWidth()));
    info.setAcceptHeader(notEmptyOrNull(source.getAccept()));
    return info;
  }

  private <T> String notEmptyOrNull(T data) {
    if (data instanceof String && StringUtils.isNotEmpty((String) data)) {
      return (String) data;
    }
    if (Objects.nonNull(data)) {
      if (data instanceof Integer) {
        return ((Integer) data).toString();
      }
      if (data instanceof Boolean) {
        return ((Boolean) data).toString();
      }
    }
    return null;
  }
}
