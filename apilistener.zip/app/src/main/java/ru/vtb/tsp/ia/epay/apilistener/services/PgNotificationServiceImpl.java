package ru.vtb.tsp.ia.epay.apilistener.services;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoUnit;
import java.util.function.Function;
import javax.annotation.Nullable;
import org.postgresql.PGConnection;
import org.postgresql.PGNotification;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.services.handlers.PgNotificationHandler;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.PgNotificationService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Service
public class PgNotificationServiceImpl extends PgNotificationService<PGNotification, String> {

  private static final int DELAY = 500;
  private final int responseTimeout;
  private final int responseTimeoutWithoutDelay;
  private final TransactionService transactionService;

  public PgNotificationServiceImpl(JdbcTemplate template,
      @Value("${app.api.response-timeout}") int responseTimeout,
      TransactionService transactionService) {
    super(template);
    this.responseTimeout = responseTimeout;
    this.responseTimeoutWithoutDelay = this.responseTimeout - DELAY;
    this.transactionService = transactionService;
  }

  @Override
  public String receive(@Nullable String channel,
      @Nullable Function<PGNotification, String> function) {
    if (ObjectUtils.isEmpty(channel) || ObjectUtils.isEmpty(function)
        || !(function instanceof final PgNotificationHandler pgNotificationFunction)) {
      return null;
    }
    return template.execute((Connection c) -> {
      c.createStatement().execute("LISTEN " + channel);
      final var pgConnection = c.unwrap(PGConnection.class);
      PGNotification[] nts;
      final var finishTime = LocalDateTime.now(ZoneOffset.UTC)
          .plus(responseTimeout, ChronoUnit.MILLIS);
      final var result = new StringBuilder();
      while (!Thread.currentThread().isInterrupted()
          && finishTime.isAfter(LocalDateTime.now(ZoneOffset.UTC))
          && result.isEmpty()) {
        nts = pgConnection.getNotifications(responseTimeoutWithoutDelay);
        if (nts == null || nts.length == 0) {
          continue;
        }
        for (PGNotification nt : nts) {
          result.append(pgNotificationFunction.apply(nt));
        }
      }
      final var qrCode = result.toString();
      if (ObjectUtils.isEmpty(qrCode)) {
        transactionService.updateStateById(pgNotificationFunction.getTransactionId(),
            TransactionState.DECLINED);
        throw new ServiceException(ApplicationException.QR_GENERATION_ERROR);
      } else {
        return qrCode;
      }
    });
  }

}