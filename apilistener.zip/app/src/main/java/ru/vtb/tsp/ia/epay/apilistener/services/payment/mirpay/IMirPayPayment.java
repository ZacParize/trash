package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayJWT;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface IMirPayPayment {

  /**
   * Создание транзакции для MirPay в статусе NEW.
   */
  @NotNull Optional<Transaction> startProcessPayment(@Nullable String orderCode,
      @Nullable AmountRequestDto amount,
      @Nullable String email);

  /**
   * Обновление транзакции для MirPay, перевод в статус MIR_PAY_PAYMENT_CREATED. Ожидание выполнения
   * оплаты на стороне Мультикарты
   */
  @NotNull Optional<Transaction> confirmProcessPayment(@NotBlank String orderCode,
      @NotBlank String merchantId,
      @NotNull MirPayJWT mirPayJWT);
}
