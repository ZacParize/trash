package ru.vtb.tsp.ia.epay.apilistener.filters;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.opentracing.Tracer;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.MimeTypeUtils;
import org.springframework.util.ObjectUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ErrorWrapperDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.services.AuditFilterService;

@Slf4j
@RequiredArgsConstructor
public class AntiReplyTokenFilter extends OncePerRequestFilter {

  private static final Base64.Decoder BASE64_DECODER = Base64.getDecoder();
  private static final String JTI = "jti";
  private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE =
      new TypeReference<>() {
      };
  private final ObjectMapper objectMapper;
  private final AuditFilterService auditFilterService;
  private final Tracer tracer;

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain filterChain) {
    try {
      log.info("filter {}, request {} url {}",
          this.getClass().getSimpleName(), request.getMethod(), request.getRequestURI());
      final var header = request.getHeader(HttpHeaders.AUTHORIZATION);
      final var token = header.split(" ")[1].trim();
      final var chunks = token.split("\\.");

      if (chunks.length <= 1) {
        log.error("Invalid token, chunks length after splitting {}", chunks.length);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        return;
      }

      final var claims = objectMapper.readValue(
          new String(BASE64_DECODER.decode(chunks[1])), MAP_TYPE_REFERENCE);
      final var jti = (String) claims.get(JTI);

      log.info("Anti replay jti {}", jti);
      if (ObjectUtils.isEmpty(jti)) {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        return;
      }

      final var antiReplayResponse = auditFilterService.getAntiReplayResponse(jti).getBody();

      if (Objects.isNull(antiReplayResponse) || Boolean.FALSE.equals(
          antiReplayResponse.getStatus())) {
        response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        return;
      }
      filterChain.doFilter(request, response);
    } catch (ServiceException ex) {
      log.error("Error occurred during request processing", ex);
      response.setStatus(ex.getHttpCode());
      response.setHeader(HttpHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON_VALUE);
      setCustomResponseBody(ex, response, objectMapper,
          tracer.scopeManager().activeSpan().context().toTraceId());
    } catch (Exception ex) {
      log.error("EPA authorization failed", ex);
      response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
    } finally {
      SecurityContextHolder.clearContext();
    }
  }

  public static void setCustomResponseBody(@Nullable ServiceException ex,
      @Nullable HttpServletResponse response,
      @Nullable ObjectMapper objectMapper,
      @Nullable String traceId) {
    try {
      if (Objects.isNull(ex) || Objects.isNull(response) || Objects.isNull(objectMapper)) {
        return;
      }
      final var errorDto = ex.toDto();
      if (Objects.isNull(errorDto.getTraceId()) && Objects.nonNull(traceId)) {
        errorDto.setTraceId(traceId);
      }
      response.setCharacterEncoding(StandardCharsets.UTF_8.name());
      response.getWriter().write(objectMapper.writeValueAsString(ErrorWrapperDto.of(errorDto)));
    } catch (Exception e) {
      log.error("Error occurred during form response body", e);
    }
  }
}
