package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.core.domains.TransferRequest;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface ITransfer {

  default Optional<Transaction> transfer(TransferRequest request) {
    throw new OperationNotSupported();
  }

}
