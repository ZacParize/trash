package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class ReceiptsNotFoundException extends ServiceException {

  {
    this.exception = ApplicationException.RECEIPTS_NOT_FOUND;
  }

  public ReceiptsNotFoundException() {
  }

  public ReceiptsNotFoundException(String message) {
    super(message);
  }

  public ReceiptsNotFoundException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public ReceiptsNotFoundException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}
