package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class OrderNotFoundException extends ServiceException {

  {
    this.exception = ApplicationException.ORDER_NOT_FOUND;
  }

  public OrderNotFoundException() {
  }

  public OrderNotFoundException(String message) {
    super(message);
  }

  public OrderNotFoundException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public OrderNotFoundException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}