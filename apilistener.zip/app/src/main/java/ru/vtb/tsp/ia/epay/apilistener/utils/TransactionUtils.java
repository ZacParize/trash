package ru.vtb.tsp.ia.epay.apilistener.utils;

import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public class TransactionUtils {

  public static final String MST_TRANSACTION_ID = "mstTransactionId";

  //TODO: remove that shit
  public static void setOriginalContext(Transaction oldTx, Transaction newTx) {
    var originalContext = oldTx.getData().getContext();
    originalContext.put("transactionId", oldTx.getTransactionId());
    originalContext.put("code", oldTx.getCode());
    originalContext.put("mstTransactionId", oldTx.getMstTransactionId());
    originalContext.put("transactionType", oldTx.getType().getValue());
    originalContext.put("transactionState", oldTx.getState().getValue());
    originalContext.put("gatewayOperation", oldTx.getData().getGatewayOperation());
    newTx.getData().getContext().put(MST_TRANSACTION_ID, newTx.getMstTransactionId());
    newTx.getData().setOriginContext(originalContext);
  }
}
