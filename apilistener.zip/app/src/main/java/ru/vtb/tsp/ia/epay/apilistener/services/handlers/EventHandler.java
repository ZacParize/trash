package ru.vtb.tsp.ia.epay.apilistener.services.handlers;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import ru.vtb.tsp.ia.epay.apilistener.services.PgNotificationListener;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

public interface EventHandler {

  /**
   * Обработка поступающих событий.
   */
  Optional<Transaction> handle(String txCode);

  /**
   * Тип нотификации.
   */
  NotificationType getHandleType();

  /**
   * Регистрация слушателя.
   */
  @Autowired
  default void registerHandler(PgNotificationListener listener) {
    listener.register(getHandleType(), this);
  }

}
