package ru.vtb.tsp.ia.epay.apilistener.services;

import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Service
public class AuditResponseService {

  private static final String AUDIT_CREATE_C2A_TRANSFER_RESPONSE =
      "TSPACQ_BOX_C2A_CREATE_TRANSFER_RESPONSE";

  @AuditProcess(AUDIT_CREATE_C2A_TRANSFER_RESPONSE)
  public Transaction createC2aTransfer(Transaction tx) {
    return tx;
  }

}