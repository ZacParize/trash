package ru.vtb.tsp.ia.epay.apilistener.services.a2c;

import lombok.Builder;
import lombok.Data;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Data
@Builder
public class TransferDto {

  private Order order;
  private Transaction transaction;

}
