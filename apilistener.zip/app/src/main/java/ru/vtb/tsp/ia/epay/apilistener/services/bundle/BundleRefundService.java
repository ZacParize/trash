package ru.vtb.tsp.ia.epay.apilistener.services.bundle;

import java.util.List;
import java.util.UUID;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

public interface BundleRefundService {

  BundleDto create(UUID orderCode, UUID txCode, BundleRequestDto bundle);

  BundleDto create(UUID orderCode, UUID txCode, BundleDto bundle);

  BundleDto getBundleByTxCode(String txCode);

  List<BundleDto> getBundlesByOrderCode(String orderCode);
}
