package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class IncorrectCustomerException extends ServiceException {

  {
    this.exception = ApplicationException.INCORRECT_CUSTOMER_DATA;
  }

  public IncorrectCustomerException() {
  }

  public IncorrectCustomerException(String message) {
    super(message);
  }

  public IncorrectCustomerException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public IncorrectCustomerException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}