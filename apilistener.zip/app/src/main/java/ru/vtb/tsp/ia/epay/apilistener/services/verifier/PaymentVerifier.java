package ru.vtb.tsp.ia.epay.apilistener.services.verifier;

import java.math.BigDecimal;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayInApplicationResultRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@Component
@RequiredArgsConstructor
public class PaymentVerifier {

  private static final Double ZERO = 0d;

  public CheckResult checkAccessMirPay(Order order) {
    if (order.getMst().isEnableMirPayment()) {
      return new CheckResult(true);
    }
    final var error = String.format("Merchant site '%s' hasn't access to Mir Pay payments",
        order.getMst().getId());
    return new CheckResult(false, error);
  }

  public CheckResult checkAccessCardPayment(Order order) {
    if (order.getMst().isEnableCardPayment()) {
      return new CheckResult(true);
    }
    final var error = String.format("Merchant site '%s' hasn't access to card payments",
        order.getMst().getId());
    return new CheckResult(false, error);
  }

  public CheckResult checkAccessSbpPayment(Order order) {
    if (order.getMst().isEnableSbpPayment()) {
      return new CheckResult(true);
    }
    final var error = String.format("Merchant site '%s' hasn't access to sbp payments",
        order.getMst().getId());
    return new CheckResult(false, error);
  }

  public CheckResult checkAccessCardPartialRefund(Transaction transaction) {
    if (transaction.getOrder().getMst().isEnableCardPartialRefund()) {
      return new CheckResult(true);
    }
    final var error = String.format("Merchant site '%s' hasn't access to card partial refund",
        transaction.getOrder().getMst().getId());
    return new CheckResult(false, error);
  }

  public CheckResult checkAccessSbpPartialRefund(Order order, Double amount,
      Double remainingRefundAmount) {
    if (amount.compareTo(remainingRefundAmount) < 0 && !order.getMst().isEnableSbpPartialRefund()) {
      final var error = String.format("Merchant site '%s' hasn't access to sbp partial refund",
          order.getMst().getId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTerminalId(Order order) {
    if (Objects.isNull(order.getMst().getParams())
        || Objects.isNull(order.getMst().getParams().getCardParams())
        || ObjectUtils.isEmpty(order.getMst().getParams().getCardParams()
        .getTerminalId())) {
      final var error = String.format("Merchant site '%s' hasn't terminal id",
          order.getMst().getId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkHasNonDeclinedTransaction(
      List<Transaction> processingOrderTransactions,
      String orderId) {
    Predicate<Transaction> nonDeclinedTransaction = tr -> tr.isAuthorized()
        || tr.isSbpPayment()
        || tr.isSbpRefund();
    if (processingOrderTransactions.stream().anyMatch(nonDeclinedTransaction)) {
      final var error = String.format("Order '%s' has transactions in process", orderId);
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkOrderRemainingAmount(
      AmountRequestDto amount,
      Order order,
      double remainingPayAmount) {
    if (amount.getValue().compareTo(remainingPayAmount) != 0) {
      final var error = String.format(
          "Payment amount does not match the amount required for order '%s'",
          order.getOrderId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTransactionMerchantId(String merchantId, Transaction mirPayTransaction) {
    if (mirPayTransaction.getMst().getMerchant().getId().equals(merchantId)) {
      return new CheckResult(true);
    }
    final var error = String.format(
        "Merchant id's '%s'(actual) and '%s'(requested) for transaction '%s' does not match",
        mirPayTransaction.getMst().getMerchant().getId(),
        merchantId,
        mirPayTransaction.getTransactionId());
    return new CheckResult(false, error);
  }

  public CheckResult checkExpirationDate(String expiryYear) {
    if (expiryYear.length() == 4) {
      return new CheckResult(true);
    }
    final var error = String.format("Expiration date '%s' has the wrong format", expiryYear);
    return new CheckResult(false, error);
  }

  public CheckResult checkOrderHasSameCurrency(Order order, Currency currency) {
    if (order.getCurrency().equals(currency)) {
      return new CheckResult(true);
    }
    final var error = String.format(
        "Required currency '%s' and request currency '%s' is different for order '%s'",
        order.getCurrency().getCode(), currency.getCode(), order.getOrderId());
    return new CheckResult(false, error);
  }

  public CheckResult checkTransactionHasSameCurrency(Transaction transaction, Currency currency) {
    if (transaction.getCurrency().equals(currency)) {
      return new CheckResult(true);
    }
    final var error = String.format(
        "Required currency '%s' and request currency '%s' is different for transaction '%s'",
        transaction.getCurrency().getCode(), currency.getCode(), transaction.getTransactionId());
    return new CheckResult(false, error);
  }

  public CheckResult checkOrderIsNotExpired(Order order) {
    if (order.isExpired()) {
      final var error = String.format("Order '%s' is already expired", order.getOrderId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkMirPayTransactionNotPaid(Transaction transaction) {
    if (!transaction.isPaid() || !transaction.isMirPayPayment()) {
      final var error = String.format("Transaction '%s' in status '%s' and type '%s'",
          transaction.getTransactionId(),
          transaction.getState().getValue(),
          transaction.getType().getValue());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTransactionHasSameMerchantSiteId(Transaction transaction, String mstId) {
    if (!Objects.equals(transaction.getMst().getId(), mstId)
        || !Objects.equals(transaction.getOrder().getMst().getId(), mstId)) {
      final var error = String.format("Merchant site id '%s' for transaction '%s' does not match",
          mstId, transaction.getTransactionId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkOrderProcessingTransaction(Order order,
      List<Transaction> orderTransactions) {
    if (Order.hasProcessingTransactions(orderTransactions)) {
      final var error = String.format("Order '%s' has transactions in processing",
          order.getOrderId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkOrderIdsNotNull(String orderId,
      MirPayInApplicationResultRequestDto callback) {
    return Objects.isNull(orderId) || Objects.isNull(callback.getOrderId())
        ? new CheckResult(false, "Order id can't be null")
        : new CheckResult(true);
  }

  public CheckResult checkCallbackOrderId(String orderId,
      MirPayInApplicationResultRequestDto callback) {
    return !orderId.equals(callback.getOrderId())
        ? new CheckResult(false, "Order id's do not match")
        : new CheckResult(true);
  }

  public CheckResult checkSingleTransaction(List<Transaction> authTxList) {
    return authTxList.size() > 1
        ? new CheckResult(false, "Transaction not single.")
        : new CheckResult(true);
  }

  public CheckResult checkTransactionExists(List<Transaction> authTxList) {
    return authTxList.isEmpty()
        ? new CheckResult(false, "Transactions not found.")
        : new CheckResult(true);
  }

  public CheckResult checkCompleteAmountBiggerHoldAmount(long completeAmount, long holdAmount) {
    if (completeAmount > holdAmount) {
      final var error = String.format("Complete amount '%s' is bigger than hold amount '%s'.",
          completeAmount, holdAmount);
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTransferAvailable(MerchantSite mst) {
    if (Objects.isNull(mst.getParams().getTransferParams())) {
      final var error = String.format("Transfers for merchant site '%s' is not available",
          mst.getId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTerminalIdMarked(Order order) {
    if (Objects.isNull(order.getMst().getParams())
        || Objects.isNull(order.getMst().getParams().getCardParams())
        || ObjectUtils.isEmpty(order.getMst().getParams().getCardParams()
        .getTerminalId())) {
      final var error = String.format("Merchant site '%s' hasn't terminal id",
          order.getMst().getId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkMerchantSiteHasAccessToOrder(MerchantSite merchantSite, Order order) {
    if (order.getMst().getId().equalsIgnoreCase(merchantSite.getId())) {
      return new CheckResult(true);
    }
    final var error = String.format("Merchant site '%s' hasn't access to current order",
        order.getMst().getId());
    return new CheckResult(false, error);
  }

  public CheckResult checkPaymentAndOrderForOrderIDMatch(
      PaymentCardRequest paymentCardRequest, Order order) {
    if (order.getMstOrderId().equalsIgnoreCase(paymentCardRequest.getOrderId())) {
      return new CheckResult(true);
    }
    final var error = String.format("Order '%s' not match with request orderId '%s'",
        order.getOrderId(),
        paymentCardRequest.getOrderId());
    return new CheckResult(false, error);
  }

  public CheckResult checkOrderType(Order order, OrderType type) {
    if (type.equals(order.getOrderType())) {
      return new CheckResult(true);
    }
    final var error = String.format("Order '%s' should has '%s' type", order.getOrderId(), type);
    return new CheckResult(false, error);
  }

  public CheckResult checkPaymentAndOrderForTerminalIDMatch(
      PaymentCardRequest paymentCardRequest, Order order) {
    if (!order.getMst().getParams().getCardParams().getTerminalId()
        .equalsIgnoreCase(paymentCardRequest.getPaymentData().getTerminalId())) {
      final var error = String.format("Terminal id '%s' does not match the one passed '%s'",
          order.getMst().getId(),
          paymentCardRequest.getPaymentData().getTerminalId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTransactionIsCardPayed(Transaction transaction) {
    if (!transaction.isPaid() || !transaction.isCardPayment()) {
      final var error = String.format(
          "Parent transaction '%s' in status '%s' or not card transaction at all",
          transaction.getTransactionId(), transaction.getState().getValue());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkTransactionIsSbpPayed(Transaction transaction) {
    if (!transaction.isPaid() || !transaction.isSbpPayment()) {
      final var error = String.format("Transaction '%s' in status '%s'",
          transaction.getTransactionId(),
          transaction.getState().getValue());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkOrderNotRefunded(Transaction transaction) {
    if (transaction.getOrder().isRefunded()) {
      final var error = String.format("Order '%s' is already refunded",
          transaction.getOrder().getOrderId());
      return new CheckResult(false, error);
    }
    return new CheckResult(true);
  }

  public CheckResult checkRefundAmount(Double refundAmount, Double remainingRefundAmount) {
    return checkRefundAmount(
        BigDecimal.valueOf(refundAmount),
        BigDecimal.valueOf(remainingRefundAmount)
    );
  }

  public CheckResult checkRefundAmount(BigDecimal refundAmount, BigDecimal remainingRefundAmount) {
    if (BigDecimal.ZERO.compareTo(refundAmount) >= 0) {
      return new CheckResult(false, "Refund amount is less than or equal to zero");
    }
    if (BigDecimal.ZERO.equals(remainingRefundAmount)) {
      return new CheckResult(false, "Nothing to refund");
    }
    if (refundAmount.compareTo(remainingRefundAmount) > 0) {
      return new CheckResult(false,
          "Refund amount is greater than remaining refund amount");
    }
    return new CheckResult(true);
  }

  public CheckResult checkRefundAmountForPaymentTransaction(Transaction paymentTransaction,
      Double refundAmount) {
    if (paymentTransaction.getAmount().compareTo(refundAmount) < 0) {
      return new CheckResult(false,
          "Refund amount is more than required for the payment transaction");
    }
    return new CheckResult(true);
  }

  public CheckResult checkCanMakeFullRefund(String orderId, List<Transaction> orderTransactions) {
    final var refundedAmount = Order.calculateRefundedAmount(orderTransactions);
    if (ZERO.equals(refundedAmount)) {
      return new CheckResult(true);
    }
    final var error = String.format("Can't make full refund for order '%s'", orderId);
    return new CheckResult(false, error);
  }

}