package ru.vtb.tsp.ia.epay.apilistener.services.monitoring;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class OrderCounterMetricAspect {

  private static final String SUCCESS_METRIC_NAME = "TSPACQ_CREATE_ORDER_COUNT";
  private static final String ERROR_METRIC_NAME = "TSPACQ_CREATE_ORDER_ERROR";
  private final Counter successCounter;
  private final Counter errorCounter;

  public OrderCounterMetricAspect(MeterRegistry meterRegistry) {
    this.successCounter = Counter.builder(SUCCESS_METRIC_NAME).register(meterRegistry);
    this.errorCounter = Counter.builder(ERROR_METRIC_NAME).register(meterRegistry);
  }

  @Pointcut("@annotation(ru.vtb.tsp.ia.epay.apilistener.services.monitoring.OrderCounterMetric)")
  protected void callsMethods() {
    //Pointcut
  }

  @AfterReturning("callsMethods()")
  public void sendCounterMetric() {
    successCounter.increment();
  }

  @AfterThrowing("callsMethods()")
  public void sendErrorMetric() {
    errorCounter.increment();
  }

}