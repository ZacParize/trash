package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay;


import java.math.BigDecimal;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.apilistener.utils.TransactionUtils;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayRefundService implements IMirPayRefund {

  private static final String MIR_PAY_TYPE = "Mir Pay";
  private final TransactionService transactionService;
  private final PaymentVerifier paymentVerifier;

  @Override
  public Optional<Transaction> registerRefund(@NotNull RefundRequestDto refundReq,
                                              @Nullable Transaction transaction,
                                              @Nullable String mstId) {
    final var amount = Optional.of(refundReq.getAmount())
        .map(AmountRequestDto::getValue)
        .orElse(null);
    final var refundId = refundReq.getRefundId();

    if (Objects.isNull(transaction) || Objects.isNull(amount)) {
      return Optional.empty();
    }
    final var currency = transaction.getCurrency();

    paymentVerifier.checkTransactionHasSameMerchantSiteId(transaction, mstId)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.TRANSACTION_NOT_FOUND);

    paymentVerifier.checkMirPayTransactionNotPaid(transaction)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.INCORRECT_PARENT_TRANSACTION);

    final var order = transaction.getOrder();

    paymentVerifier.checkOrderNotRefunded(transaction)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.ORDER_REFUNDED_ERROR);

    paymentVerifier.checkOrderIsNotExpired(order)
        .ifCheckFailedLogAndThrow(MIR_PAY_TYPE, () -> new OperationNotSupported());

    paymentVerifier.checkOrderHasSameCurrency(order, currency)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.CURRENCY_IS_NOT_ALLOWED);

    paymentVerifier.checkTransactionHasSameCurrency(transaction, currency)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.CURRENCY_IS_NOT_ALLOWED);

    var orderTransactions = transactionService.getByOrderId(order.getOrderId());

    paymentVerifier.checkOrderProcessingTransaction(order, orderTransactions)
        .ifCheckFailedLogAndThrowServiceException(MIR_PAY_TYPE, ApplicationException.IN_PROCESS);

    Predicate<Transaction> isRefundedMirPayTransaction =
        tr -> TransactionType.isMirPayRefund(tr.getType())
            && TransactionState.CONFIRMED.equals(tr.getState());

    final var refundAmount = BigDecimal.valueOf(amount);
    final var parentTransactionAmount = BigDecimal.valueOf(transaction.getAmount());
    final var alreadyRefundedAmount = BigDecimal.valueOf(orderTransactions.stream()
        .filter(isRefundedMirPayTransaction)
        .map(Transaction::getAmount)
        .map(BigDecimal::valueOf)
        .reduce(BigDecimal.ZERO, BigDecimal::add)
        .doubleValue());
    final var remainingRefundAmount = parentTransactionAmount.subtract(alreadyRefundedAmount);

    paymentVerifier.checkRefundAmount(refundAmount, remainingRefundAmount)
        .ifCheckFailedLogAndThrowServiceException(
            MIR_PAY_TYPE, ApplicationException.INCORRECT_AMOUNT
        );

    boolean isPartial = refundAmount.compareTo(parentTransactionAmount) < 0;

    return Optional.of(transaction)
        .map(
            oldTr -> {
              Optional<Transaction> refundTr = isPartial
                  ? transactionService.createPartialMirPayRefund(oldTr.getOrder(), amount, refundId)
                  : transactionService.createMirPayRefund(oldTr.getOrder(), refundId);
              return refundTr.flatMap(
                  tx -> {
                    TransactionUtils.setOriginalContext(oldTr, tx);
                    log.info(
                        "Mir Pay: created transaction id '{}', mstTrId '{}', code '{}', type '{}'",
                        tx.getTransactionId(), tx.getMstTransactionId(), tx.getCode(),
                        tx.getType());
                    return transactionService.upsert(tx);
                  }
              );
            }
        )
        .orElseThrow(() -> new ServiceException(ApplicationException.INTERNAL_ERROR));
  }
}
