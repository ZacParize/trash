package ru.vtb.tsp.ia.epay.apilistener.services;

import static ru.vtb.tsp.ia.epay.apilistener.services.KafkaService.ACS_DECLINE_DELAY;
import static ru.vtb.tsp.ia.epay.apilistener.services.KafkaService.OTP_DECLINE_DELAY;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.configs.MirPayConfig;
import ru.vtb.tsp.ia.epay.apilistener.configs.properties.ThreedsProperties;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSMethodDataResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayTokenGenerator;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType;

@Slf4j
@Service
@RequiredArgsConstructor
public class LinksService {

  private static final Base64.Encoder ENCODER = Base64.getEncoder();
  private final ObjectMapper mapper;
  private final KafkaService kafkaService;
  private final String notificationMethodUrl;
  private final String notificationParesUrl;
  private final String notificationCresUrl;
  private final MirPayTokenGenerator mirPayTokenGenerator;
  private final MirPayConfig mirPayConfig;

  @Autowired
  public LinksService(ObjectMapper mapper,
      KafkaService kafkaService,
      ThreedsProperties properties,
      MirPayTokenGenerator mirPayTokenGenerator,
      MirPayConfig mirPayConfig) {
    this.mapper = mapper;
    this.kafkaService = kafkaService;
    this.notificationMethodUrl = properties.getAcsLinks().getNotificationMethodUrl();
    this.notificationParesUrl = properties.getAcsLinks().getNotificationParesUrl();
    this.notificationCresUrl = properties.getAcsLinks().getNotificationCresUrl();
    this.mirPayTokenGenerator = mirPayTokenGenerator;
    this.mirPayConfig = mirPayConfig;
  }

  public String createLinkThreeDsMethod(String txCode) {
    final var link = createLink(txCode, notificationMethodUrl);
    kafkaService.sendToNotificator(txCode,
        NotificationType.THREEDS_METHOD_TIMEOUT, ACS_DECLINE_DELAY);
    return link;
  }

  public String createLinkThreeDsCres(String txCode) {
    return createLink(txCode, notificationCresUrl);
  }

  public String createLinkThreeDsPares(String txCode) {
    kafkaService.sendToNotificator(txCode,
        NotificationType.OTP_PAGE_TIMEOUT, OTP_DECLINE_DELAY);
    return createLink(txCode, notificationParesUrl);
  }

  private String createLink(String txCode, String link) {
    return Optional.ofNullable(txCode)
        .map(uuid -> link.replaceAll("\\{linkid}", uuid))
        .orElse("");
  }

  public String prepareLink(String transId, String txCode) {
    final var threeDSData = ThreeDSMethodDataResponseDto.builder()
        .threeDSServerTransID(transId)
        .threeDSMethodNotificationURL(createLinkThreeDsMethod(txCode))
        .build();
    try {
      return ENCODER.encodeToString(mapper.writeValueAsString(threeDSData)
          .getBytes(StandardCharsets.UTF_8));
    } catch (JsonProcessingException ex) {
      log.error("Can't serialize 3DS method data {}, transaction code {}", transId, txCode, ex);
      return null;
    }
  }

  public String createMirPayLink(Order order) {
    return mirPayConfig.getUniversalLinkUrlPrefix() + mirPayTokenGenerator.getMirPayJWT(order);
  }
}