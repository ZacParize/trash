package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.PGNotification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.handlers.PgNotificationHandler;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.PgNotificationService;
import ru.vtb.tsp.ia.epay.core.services.TransactionInfoService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpChannel;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;

@Slf4j
@Service
public class SbpPaymentService implements ISbpPayment {

  private final TransactionService transactionService;
  private final TransactionInfoService transactionInfoService;
  private final OrderService orderService;
  private final ObjectMapper objectMapper;
  private final KafkaService kafkaService;
  private final PgNotificationService<PGNotification, String> pgNotificationService;
  private final PaymentVerifier paymentVerifier;

  public SbpPaymentService(
      @NotNull TransactionService transactionService,
      @NotNull TransactionInfoService transactionInfoService,
      @NotNull OrderService orderService,
      @NotNull ObjectMapper objectMapper,
      @NotNull KafkaService kafkaService,
      @NotNull PgNotificationService<PGNotification, String> pgNotificationService,
      @NotNull PaymentVerifier paymentVerifier) {
    this.transactionService = transactionService;
    this.transactionInfoService = transactionInfoService;
    this.orderService = orderService;
    this.objectMapper = objectMapper;
    this.kafkaService = kafkaService;
    this.pgNotificationService = pgNotificationService;
    this.paymentVerifier = paymentVerifier;
  }

  @Override
  @Transactional
  public Optional<Transaction> processPayment(SbpPaymentStatusResponseDto request) {
    return transactionInfoService.getByQrcId(request.getQrcId())
        .flatMap(tx -> transactionService.lockById(tx.getTransactionId()))
        .filter(tx -> !tx.getOrder().isCompleted() && !tx.isCompleted())
        .flatMap(tx -> {
          Optional.ofNullable(tx.getData())
              .map(TransactionPayload::getPaymentData)
              .ifPresent(pd -> {
                if (!(pd instanceof Sbp)) {
                  log.error(
                      "Received SBP callback " + request + " but transaction hasn't SBP type");
                  throw new OperationNotSupported();
                }
                final var sbpPd = (Sbp) pd;
                sbpPd.setStatus(request.getQState());
                sbpPd.setOperationId(request.getOperationId());
              });
          return getNewTransactionByQStateAndTransaction(request, tx);
        });
  }

  private Optional<Transaction> getNewTransactionByQStateAndTransaction(
      SbpPaymentStatusResponseDto request, Transaction tx) {
    return switch (request.getQState()) {
      case OK -> transactionService.upsert(tx.withState(TransactionState.RECONCILED))
          .map(newTx -> processSuccessPayment(newTx, request));
      case InProgress, CREATED -> {
        log.info("Nothing to do with transaction id {}", tx.getTransactionId());
        yield Optional.empty();
      }
      case Canceled -> transactionService.upsert(tx.withState(TransactionState.DECLINED))
          .map(newTx -> processErrorPayment(newTx, request));
      case NTST -> {
        log.info("Transaction id {} with qrcId {} has not found in SBP",
            tx.getTransactionId(), request.getQrcId());
        tx.getData().setError(TransactionError.builder()
            .id(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getId())
            .httpCode(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getHttpCode())
            .description(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getDescription())
            .message(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getMessage())
            .traceId(tx.getCode())
            .build());
        yield transactionService.upsert(tx.withState(TransactionState.DECLINED))
            .map(newTx -> processErrorPayment(newTx, request));
      }
      default -> {
        log.info("Transaction id {} has unknown error in SBP", tx.getTransactionId());
        tx.getData().setError(TransactionError.builder()
            .id(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getId())
            .httpCode(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getHttpCode())
            .description(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getDescription())
            .message(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getMessage())
            .traceId(tx.getCode())
            .build());
        yield transactionService.upsert(tx.withState(TransactionState.DECLINED))
            .map(newTx -> processErrorPayment(newTx, request));
      }
    };
  }

  @Override
  public Optional<String> getQr(@Nullable String orderId) {
    return orderService.getById(orderId)
        .flatMap(order -> {
          paymentVerifier.checkAccessSbpPayment(order)
              .ifCheckFailedLogAndThrow(InternalException::new);
          var transaction = transactionService
              .getWithQrcByOrderId(order.getOrderId())
              .stream()
              .filter(tx -> !tx.isDeclined())
              .findAny();
          if (order.isCompleted() || transaction.isPresent()) {
            return transaction.map(tx -> tx.getData().getPaymentData().getInfo());
          }
          transaction = transactionService.upsert(transactionService
              .createSbpPayment(order)
              .orElse(null));
          transaction.ifPresent(tx -> kafkaService.sendToBox(tx.getData()));
          return transaction.map(tx ->
              pgNotificationService.receive(SbpChannel.SBP_QR_CHANNEL.getValue(),
                  new PgNotificationHandler(objectMapper, tx)));
        });
  }

  private @NotNull Transaction processSuccessPayment(@NotNull Transaction newTx,
                                                     @NotNull SbpPaymentStatusResponseDto request) {
    transactionInfoService.saveOrUpdateInfo(TransactionInfo.builder()
        .transaction(newTx)
        .key(TransactionInfoKey.SBP_OPERATION_ID)
        .value(request.getOperationId())
        .createdAt(LocalDateTime.now(ZoneOffset.UTC))
        .build());
    log.info("Transaction id {} is payed by SBP", newTx.getTransactionId());
    final var isFullRefund = newTx.getCurrency().equals(newTx.getOrder().getCurrency())
        && newTx.getAmount().equals(newTx.getOrder().getAmount());
    orderService.upsert(newTx.getOrder()
        .withState(isFullRefund ? OrderState.PAID : OrderState.PARTIALLY_PAID));
    log.info("Order id {} payed by SBP", newTx.getOrder().getOrderId());
    return transactionService.getById(newTx.getTransactionId()).orElseThrow(() -> {
      log.error("Transaction id {} is not found", newTx.getTransactionId());
      throw new TransactionNotFoundException();
    });
  }

  private @NotNull Transaction processErrorPayment(@NotNull Transaction newTx,
                                                   @NotNull SbpPaymentStatusResponseDto request) {
    transactionInfoService.saveOrUpdateInfo(TransactionInfo.builder()
        .transaction(newTx)
        .key(TransactionInfoKey.SBP_OPERATION_ID)
        .value(request.getOperationId())
        .createdAt(LocalDateTime.now(ZoneOffset.UTC))
        .build());
    log.info("Transaction id {} not payed by SBP", newTx.getTransactionId());
    return newTx;
  }

}