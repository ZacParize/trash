package ru.vtb.tsp.ia.epay.apilistener.services.mirpay;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MirPayJWT {

  /**
   * Token Account Number.
   */
  private String tan;
  /**
   * Authentication Value (NSPK-InApp криптограмма). Передается в авторизационном запросе [0100]
   * Эквайрером в ПЛ-048.ЭЛ-22.
   */
  private String cav;
  /**
   * Token Expiration Year. Последние две (2) цифры года срока окончания действия токена. Возможные
   * значения: 18-99
   */
  private Integer tey;
  /**
   * Token Expiration Month. Порядковый номер месяца в году срока окончания действия токена.
   * Возможные значения: 1-12
   */
  private Integer tem;
  /**
   * Уникальный идентификатор In-Application операции, сформированный Платформой, в формате UUID.
   * Передается в авторизационном запросе [0100] Эквайрером в ПЛ-048.ЭЛ-23.
   */
  private String transId;
  /**
   * Идентификатор ТСП (MerchantId).
   */
  private String merchantId;
  /**
   * Cертификат X.509 в Base64 открытого ключа ТСП [PK.MERCH_ID.1].
   */
  private String mx5c;
  /**
   * Уникальный идентификатор заказа/транзакции на стороне ТСП.
   */
  private String orderId;
  /**
   * Сумма платежа, полученная от ТСП. Сумма указывается в минимальных единицах валюты без
   * десятичного разделителя и лидирующих нулей
   */
  private Integer sum;
  /**
   * Валюта платежа, полученная от ТСП.
   */
  private Integer cur;
  /**
   * Тип источника, через который инициирована In-Application операция. Допустимые значения:
   * ISDK (In-Application SDK).
   * DL (Deep link)
   * UL (Universal link).
   * TR (In-Application Mir HCE SDK).
   */
  private String media;

}
