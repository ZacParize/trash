package ru.vtb.tsp.ia.epay.apilistener.exceptions;

import static ru.vtb.tsp.ia.epay.apilistener.controllers.CallbackController.X_CORRELATION_ID_HEADER;

import io.opentracing.Tracer;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ErrorDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ErrorResponse;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayInApplicationResultErrorResponseDto;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;

@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class CommonRestExceptionHandler extends ResponseEntityExceptionHandler {

  //
  private static final ServiceException UNKNOWN_SERVICE_EXCEPTION =
      new ServiceException(ApplicationException.UNKNOWN_ERROR);

  private final Tracer tracer;

  @ExceptionHandler(Exception.class)
  public @NotNull ResponseEntity<ErrorResponse<?>> handleException(@Nullable Exception ex) {
    if (ex instanceof TransactionException) {
      return handleTransactionException((TransactionException) ex);
    } else if (ex instanceof ServiceException) {
      return handleServiceException((ServiceException) ex);
    } else {
      final var httpStatus = HttpStatus.INTERNAL_SERVER_ERROR.value();
      return ResponseEntity.status(httpStatus).body(new ErrorResponse<>(
          new ServiceException(ApplicationException.INTERNAL_ERROR,
              tracer.scopeManager().activeSpan().context().toTraceId()).toDto()));
    }
  }

  @ExceptionHandler(TransactionException.class)
  public @NotNull ResponseEntity<ErrorResponse<?>> handleTransactionException(
      @Nullable TransactionException ex) {
    final var errorDto = Optional.ofNullable(ex)
        .map(TransactionException::getTransactionError)
        .map(ErrorDto::of)
        .orElse(UNKNOWN_SERVICE_EXCEPTION.toDto());
    final var httpStatus = Optional.ofNullable(ex)
        .map(TransactionException::getTransactionError)
        .map(TransactionError::getHttpCode)
        .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());
    if (Objects.isNull(errorDto.getTraceId())) {
      errorDto.setTraceId(tracer.scopeManager().activeSpan().context().toTraceId());
    }
    return ResponseEntity.status(httpStatus).body(new ErrorResponse<>(errorDto));
  }

  @ExceptionHandler(ServiceException.class)
  public @NotNull ResponseEntity<ErrorResponse<?>> handleServiceException(
      @Nullable ServiceException ex) {
    log.error(ex.getMessage(), ex);
    final var errorDto = Optional.ofNullable(ex)
        .map(ServiceException::toDto)
        .orElse(UNKNOWN_SERVICE_EXCEPTION.toDto());
    if (Objects.isNull(errorDto.getTraceId())) {
      errorDto.setTraceId(tracer.scopeManager().activeSpan().context().toTraceId());
    }
    final var httpStatus = Optional.ofNullable(ex)
        .map(ServiceException::getHttpCode)
        .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());
    return ResponseEntity.status(httpStatus).body(new ErrorResponse<>(errorDto));
  }

  @ExceptionHandler(BundleValidationException.class)
  public @NotNull ResponseEntity<ErrorResponse<?>> handleServiceException(
      @Nullable BundleValidationException ex) {
    log.error(ex.getMessage(), ex);
    final var errorDto = Optional.ofNullable(ex)
        .map(BundleValidationException::toDto)
        .orElse(UNKNOWN_SERVICE_EXCEPTION.toDto());
    if (Objects.isNull(errorDto.getTraceId())) {
      errorDto.setTraceId(tracer.scopeManager().activeSpan().context().toTraceId());
    }
    final var httpStatus = Optional.ofNullable(ex)
        .map(BundleValidationException::getHttpCode)
        .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());
    return ResponseEntity.status(httpStatus).body(new ErrorResponse<>(errorDto));
  }

  @ExceptionHandler(MirPayServiceException.class)
  public @NotNull ResponseEntity<MirPayInApplicationResultErrorResponseDto>
  handleMirPayServiceException(@Nullable MirPayServiceException ex, WebRequest request) {
    HttpHeaders headers = new HttpHeaders();
    headers.add(X_CORRELATION_ID_HEADER, request.getHeader(X_CORRELATION_ID_HEADER));

    if (Objects.isNull(ex)) {
      log.error("Mir Pay unknown error");
      var unknownError = MirPayInApplicationResultErrorResponseDto.builder()
          .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
          .title(ApplicationException.UNKNOWN_ERROR.getDescription())
          .detail(ApplicationException.UNKNOWN_ERROR.getMessage())
          .build();
      return ResponseEntity.status(unknownError.getStatus())
          .headers(headers)
          .body(unknownError);
    }
    log.error("Mir Pay error: '{}. {}'", ex.getMessage(), ex.getErrorExplanation());
    return ResponseEntity.status(ex.getHttpCode())
        .headers(headers)
        .body(ex.toDto());
  }

  @Override
  protected @NonNull ResponseEntity<Object> handleMethodArgumentNotValid(
      @Nullable MethodArgumentNotValidException ex,
      @NonNull HttpHeaders headers,
      @NonNull HttpStatus status,
      @NonNull WebRequest request) {
    log.error(ex.getMessage(), ex);
    return ResponseEntity.status(status)
        .headers(headers)
        .body(new ErrorResponse<>(new ServiceException(ApplicationException.VALIDATION_ERROR,
            tracer.scopeManager().activeSpan().context().toTraceId()).toDto()));
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
      HttpHeaders headers, HttpStatus status, WebRequest request) {
    if (ex.getMostSpecificCause() instanceof BundleValidationException) {
      final var bundleValidationException = (BundleValidationException) ex.getMostSpecificCause();
      final var errorDto = bundleValidationException.toDto();
      errorDto.setTraceId(tracer.scopeManager().activeSpan().context().toTraceId());
      final var httpStatus = Optional.ofNullable(bundleValidationException)
          .map(BundleValidationException::getHttpCode)
          .orElse(HttpStatus.INTERNAL_SERVER_ERROR.value());
      return ResponseEntity.status(httpStatus).body(new ErrorResponse<>(errorDto));
    }
    return getCommonResponseEntity(status, headers, ApplicationException.VALIDATION_ERROR);
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(Exception ex,
      @Nullable Object body,
      @Nullable HttpHeaders headers,
      @NotNull HttpStatus status,
      @Nullable WebRequest request) {
    log.error(ex.getMessage(), ex);
    if (status.is4xxClientError()) {
      return getCommonResponseEntity(status, headers, ApplicationException.VALIDATION_ERROR);
    } else {
      return getCommonResponseEntity(status, headers, ApplicationException.INTERNAL_ERROR);
    }
  }


  private ResponseEntity getCommonResponseEntity(HttpStatus status, HttpHeaders headers,
      ApplicationException applicationException) {
    return ResponseEntity.status(status)
        .headers(headers)
        .body(new ErrorResponse<>(new ServiceException(applicationException,
            tracer.scopeManager().activeSpan().context().toTraceId()).toDto()));
  }

}