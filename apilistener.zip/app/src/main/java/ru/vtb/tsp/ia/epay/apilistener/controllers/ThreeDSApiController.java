package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import java.util.Optional;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.apilistener.controllers.api.ThreeDSApi;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSCresCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSMethodCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.threeds.ThreeDSParesCallbackPost;
import ru.vtb.tsp.ia.epay.apilistener.services.ThreeDSCallbackService;

@Slf4j
@RestController
@RequiredArgsConstructor
public class ThreeDSApiController implements ThreeDSApi {

  private static final String ID_PATH_VARIABLE = "id";
  private static final String BASE_PATH = "/threeds";
  private static final String CRES_PATH =
      BASE_PATH + "/cres/notification/{" + ID_PATH_VARIABLE + "}";
  private static final String METHOD_PATH =
      BASE_PATH + "/method/notification/{" + ID_PATH_VARIABLE + "}";
  private static final String PARES_PATH =
      BASE_PATH + "/pares/notification/{" + ID_PATH_VARIABLE + "}";
  private static final String SERVER_TRANS_ID = "threeDSServerTransID";
  private static final String ACS_TRANS_ID = "acsTransID";

  private final ThreeDSCallbackService threeDSCallbackService;

  @PostMapping(value = "${app.api.prefix}" + CRES_PATH, consumes = APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> threeDSCresCallback(
      @PathVariable(ID_PATH_VARIABLE) String id,
      @Valid @RequestBody ThreeDSCresCallbackPost body) {
    log.info("3DS cres, id = {}, body = {}", id, body);
    threeDSCallbackService.validateCresCallback(id,
        threeDSCallbackService.correctTransId(
            Optional.ofNullable(body)
                .map(ThreeDSCresCallbackPost::getCres)
                .orElse(null), ACS_TRANS_ID));
    return threeDSCallbackService.proceed3DSCres(id, body)
        .map(tx -> ResponseEntity.ok())
        .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND))
        .build();
  }

  @PostMapping(value = "${app.api.prefix}" + METHOD_PATH, consumes = APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> threeDSMethodCallback(
      @PathVariable(ID_PATH_VARIABLE) String id,
      @Valid @RequestBody ThreeDSMethodCallbackDto body) {
    log.info("3DS method, id = {}, body = {}", id, body);
    threeDSCallbackService.validate3DSMethodCallback(id,
        threeDSCallbackService.correctTransId(
            Optional.ofNullable(body)
                .map(ThreeDSMethodCallbackDto::getThreeDSMethodData)
                .orElse(null), SERVER_TRANS_ID));
    return threeDSCallbackService.proceed3DSMethod(id, body)
        .map(tx -> ResponseEntity.ok())
        .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND))
        .build();
  }

  @PostMapping(value = "${app.api.prefix}" + PARES_PATH, consumes = APPLICATION_JSON_VALUE)
  public ResponseEntity<Void> threeDSParesCallback(
      @PathVariable(ID_PATH_VARIABLE) String id,
      @Valid @RequestBody ThreeDSParesCallbackPost body) {
    log.info("3DS pares, id = {}, body = {}", id, body);
    return threeDSCallbackService.proceed3DSPares(id, body)
        .map(tx -> ResponseEntity.ok())
        .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND))
        .build();
  }

}