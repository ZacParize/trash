package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import org.springframework.beans.factory.annotation.Autowired;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;

public interface IPaymentGateway extends IPayment, IRefund, ITransfer, IStatusPayment {

  GatewayType getGatewayType();

  @Autowired
  default void register(PaymentService paymentService) {
    paymentService.register(this);
  }
}
