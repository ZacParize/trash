package ru.vtb.tsp.ia.epay.apilistener.services.mappers;

import org.mapstruct.Mapper;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.MerchantReceiptDataDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptStatusDto;

@Mapper(componentModel = "spring")
public interface ReceiptStatusMapper {

  MerchantReceiptDataDto toEntity(ReceiptStatusDto dto);

}
