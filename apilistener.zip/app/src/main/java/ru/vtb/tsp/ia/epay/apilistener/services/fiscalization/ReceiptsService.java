package ru.vtb.tsp.ia.epay.apilistener.services.fiscalization;

import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.MerchantReceiptStatusDto;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

public interface ReceiptsService {

  MerchantReceiptStatusDto getReceiptStatus(MerchantSite mst, String mstOrderId);

}
