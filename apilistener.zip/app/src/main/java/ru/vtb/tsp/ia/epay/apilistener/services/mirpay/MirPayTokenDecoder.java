package ru.vtb.tsp.ia.epay.apilistener.services.mirpay;

import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_INTERNAL_SERVER_ERROR;
import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_INVALID_INPUT_DATA;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.crypto.RSADecrypter;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jwt.JWTClaimsSet;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.text.ParseException;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException;

@Slf4j
@Service
public class MirPayTokenDecoder {

  private final RSADecrypter rsaDecrypter;
  private final RSASSAVerifier jwsVerifier;

  /**
   * Constructor consumes keys for creating verifier and decrypter.
   *
   * @param appregPrivateKey приватный ключ ТСП [SK.APPREG.1].
   * @param nspkPublicKey публичный ключ НСПК [PK.NSPK.1].
   */
  public MirPayTokenDecoder(
      PrivateKey appregPrivateKey,
      RSAPublicKey nspkPublicKey) {
    this.rsaDecrypter = new RSADecrypter(appregPrivateKey);
    this.jwsVerifier = new RSASSAVerifier(nspkPublicKey);
  }

  /**
   * Расшифровывает полученные в JWE данные In-Application операции с помощью своего приватного
   * ключа [SK.APPREG.1], сгенерированного для регистрации в сервисе In-Application, и проверяет
   * подпись с помощью сертификата публичного ключа НСПК [PK.NSPK.1].
   */
  @NotNull
  public MirPayJWT decodeJWE(@NotNull String cryptogram) {
    validateImputeData(cryptogram);
    try {
      final var jweObject = JWEObject.parse(cryptogram);
      jweObject.decrypt(rsaDecrypter);
      final var jwsObject = jweObject.getPayload().toJWSObject();
      verifyJws(jwsObject);
      final var jwtString = jwsObject.getPayload().toString();
      final var jwtClaimsSet = JWTClaimsSet.parse(jwtString);
      return buildMirPayJwt(jwtClaimsSet);
    } catch (ParseException | JOSEException e) {
      final var message = String.format("Failure to decode cryptogram '%s'.", e.getMessage());
      log.error(message, e);
      throw new MirPayServiceException(MIR_PAY_INTERNAL_SERVER_ERROR, message);
    }
  }

  private void validateImputeData(String cryptogram) {
    if (ObjectUtils.isEmpty(cryptogram) || cryptogram.trim().isEmpty()) {
      throw new MirPayServiceException(MIR_PAY_INVALID_INPUT_DATA, "Passed JWE is empty");
    }
  }

  private void verifyJws(JWSObject jwsObject) throws JOSEException {
    if (!jwsObject.verify(jwsVerifier)) {
      throw new MirPayServiceException(MIR_PAY_INTERNAL_SERVER_ERROR,
          "The signature was not verified by PK.NSPK.1");
    }
  }

  private MirPayJWT buildMirPayJwt(JWTClaimsSet jwtClaimsSet) throws ParseException {
    return MirPayJWT.builder()
        .tan(jwtClaimsSet.getStringClaim("tan"))
        .cav(jwtClaimsSet.getStringClaim("cav"))
        .tey(jwtClaimsSet.getIntegerClaim("tey"))
        .tem(jwtClaimsSet.getIntegerClaim("tem"))
        .transId(jwtClaimsSet.getStringClaim("transId"))
        .merchantId(jwtClaimsSet.getStringClaim("mId"))
        // Cертификат X.509 в Base64 открытого ключа ТСП [PK.MERCH_ID.1]
        .mx5c(jwtClaimsSet.getStringClaim("mx5c"))
        .orderId(jwtClaimsSet.getStringClaim("orderId"))
        .sum(jwtClaimsSet.getIntegerClaim("sum"))
        .cur(jwtClaimsSet.getIntegerClaim("cur"))
        .media(jwtClaimsSet.getStringClaim("media"))
        .build();
  }
}
