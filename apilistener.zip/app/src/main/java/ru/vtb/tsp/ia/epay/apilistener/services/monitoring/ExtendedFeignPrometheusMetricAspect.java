package ru.vtb.tsp.ia.epay.apilistener.services.monitoring;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tag;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.data.util.Pair;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Component
@Aspect
public class ExtendedFeignPrometheusMetricAspect {

  private static final String METRIC_NAME = "feign_Client_http_response_code_ext";
  private static final String HTTP_METHOD = "httpMethod";
  private static final String METHOD = "method";
  private static final String URI = "uri";
  private MeterRegistry meterRegistry;

  public ExtendedFeignPrometheusMetricAspect(MeterRegistry meterRegistry) {
    this.meterRegistry = meterRegistry;
  }

  @Pointcut("@within(ExtPrometheusMertics)")
  public void extPrometheusPointCut() {
  }

  @Before("extPrometheusPointCut()")
  public void process(JoinPoint joinPoint) {
    Signature signature = joinPoint.getSignature();
    MethodSignature methodSignature = (MethodSignature) signature;
    Method method = methodSignature.getMethod();
    List<Annotation> annotationList = Arrays.asList(method.getAnnotations());
    getPair(annotationList)
        .ifPresent(pair -> {
          Counter.builder(METRIC_NAME)
              .tags(List.of(Tag.of(HTTP_METHOD, pair.getSecond().name()),
                  Tag.of(METHOD, method.getName()),
                  Tag.of(URI, StringUtils.join(Arrays.asList(pair.getFirst()), " "))))
              .register(meterRegistry).increment();
        });
  }

  private Optional<Pair<String[], HttpMethod>> getPair(List<Annotation> annotationList) {
    for (Annotation ann : annotationList) {
      if (ann instanceof GetMapping) {
        return Optional.of(Pair.of(((GetMapping) ann).path(), HttpMethod.GET));
      } else if (ann instanceof PostMapping) {
        return Optional.of(Pair.of(((PostMapping) ann).path(), HttpMethod.POST));
      } else if (ann instanceof PatchMapping) {
        return Optional.of(Pair.of(((PatchMapping) ann).path(), HttpMethod.PATCH));
      } else if (ann instanceof PutMapping) {
        return Optional.of(Pair.of(((PutMapping) ann).path(), HttpMethod.PUT));
      } else if (ann instanceof DeleteMapping) {
        return Optional.of(Pair.of(((DeleteMapping) ann).path(), HttpMethod.DELETE));
      } else if (ann instanceof RequestMapping) {
        RequestMethod[] requestMethod = ((RequestMapping) ann).method();
        if (requestMethod.length > 0) {
          return Optional.of(Pair.of(((RequestMapping) ann).path(),
              HttpMethod.valueOf(requestMethod[0].name())));
        } else {
          return Optional.of(Pair.of(((RequestMapping) ann).path(),
              HttpMethod.GET));
        }
      }
    }
    return Optional.empty();
  }
}
