package ru.vtb.tsp.ia.epay.apilistener.exceptions;

import lombok.Getter;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;

@Getter
public class TransactionException extends RuntimeException {

  private final TransactionError transactionError;

  public TransactionException(TransactionError transactionError) {
    this.transactionError = transactionError;
  }

  public TransactionException(String message,
      TransactionError transactionError) {
    super(message);
    this.transactionError = transactionError;
  }

  public TransactionException(String message, Throwable cause,
      TransactionError transactionError) {
    super(message, cause);
    this.transactionError = transactionError;
  }

  public TransactionException(Throwable cause,
      TransactionError transactionError) {
    super(cause);
    this.transactionError = transactionError;
  }

}
