package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.apilistener.utils.TransactionUtils;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.services.CurrencyService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardRefundService implements ICardRefund {

  private final CurrencyService currencyService;
  private final TransactionService transactionService;
  private final PaymentVerifier paymentVerifier;

  @Transactional
  public @NotNull Optional<Transaction> registerRefund(@Nullable Transaction transaction,
      @Nullable String refundId, AmountRequestDto amount) {
    if (Objects.isNull(transaction) || ObjectUtils.isEmpty(refundId)) {
      return Optional.empty();
    } else {
      final var paidAmount = convertMoney(transaction.getAmount());
      final var refundAmount = convertMoney(amount.getValue());
      if (refundAmount == paidAmount) {
        return registerFullRefund(transaction, refundId);
      } else if (refundAmount < paidAmount) {
        return registerPartialRefund(transaction, refundId, amount);
      } else {
        throw new ServiceException(ApplicationException.INCORRECT_AMOUNT);
      }
    }
  }

  @AuditProcess("TSPACQ_BOX_FULL_REFUND_MERCHANT")
  private Optional<Transaction> registerFullRefund(@Nullable Transaction transaction,
      @Nullable String refundId) {
    if (Objects.isNull(transaction) || ObjectUtils.isEmpty(refundId)) {
      return Optional.empty();
    }
    final var orderTransactions = transactionService
        .getByOrderId(transaction.getOrder().getOrderId());
    final var amountRequestDto = AmountRequestDto.builder()
        .code(transaction.getOrder().getCurrency().getCode())
        .value(transaction.getOrder().getAmount())
        .build();
    if (!canRefund(transaction, amountRequestDto, orderTransactions)) {
      return Optional.empty();
    }
    // can make full refund
    paymentVerifier.checkCanMakeFullRefund(transaction.getOrder().getOrderId(), orderTransactions)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
    return Optional.of(transaction)
        .map(oldTx -> transactionService.createCardRefund(oldTx.getOrder(),
                oldTx.getOrder().getAmount(),
                oldTx.getOrder().getCurrency(),
                refundId)
            .flatMap(newTx -> {
              TransactionUtils.setOriginalContext(oldTx, newTx);
              return transactionService.upsert(newTx);
            }))
        .orElseThrow(() -> new ServiceException(ApplicationException.INTERNAL_ERROR));
  }

  @AuditProcess("TSPACQ_BOX_PARTIAL_REFUND_MERCHANT")
  private Optional<Transaction> registerPartialRefund(@Nullable Transaction transaction,
      @Nullable String refundId,
      @Nullable AmountRequestDto amount) {
    if (Objects.isNull(transaction) || ObjectUtils.isEmpty(refundId)
        || Objects.isNull(amount) || Objects.isNull(amount.getValue())
        || ObjectUtils.isEmpty(amount.getCode())) {
      return Optional.empty();
    }
    final var orderTransactions = transactionService
        .getByOrderId(transaction.getOrder().getOrderId());
    if (!canRefund(transaction, amount, orderTransactions)) {
      return Optional.empty();
    }
    // check refund amount for payment transaction
    paymentVerifier.checkRefundAmountForPaymentTransaction(transaction, amount.getValue())
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
    // mst settings allow to make partial refund
    paymentVerifier.checkAccessCardPartialRefund(transaction)
        .ifCheckFailedLogAndThrowServiceException(
            ApplicationException.PARTIAL_REFUND_NOT_SUPPORTED
        );
    return transactionService.createPartialCardRefund(transaction.getOrder(),
            amount.getValue(),
            transaction.getOrder().getCurrency(),
            refundId)
        .map(newTx -> {
          TransactionUtils.setOriginalContext(transaction, newTx);
          return transactionService.upsert(newTx).orElseThrow(TransactionNotFoundException::new);
        });
  }

  private boolean canRefund(@Nullable Transaction transaction,
      @Nullable AmountRequestDto amount,
      @Nullable List<Transaction> orderTransactions) {
    if (Objects.isNull(transaction) || Objects.isNull(amount) || Objects.isNull(amount.getValue())
        || ObjectUtils.isEmpty(amount.getCode()) || ObjectUtils.isEmpty(orderTransactions)) {
      return false;
    }
    // parent transaction was payed by card
    paymentVerifier.checkTransactionIsCardPayed(transaction)
        .ifCheckFailedLogAndThrowServiceException(
            ApplicationException.INCORRECT_PARENT_TRANSACTION
        );
    // order is not refunded
    paymentVerifier.checkOrderNotRefunded(transaction)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.ORDER_REFUNDED_ERROR);
    final var currency = currencyService.getById(amount.getCode())
        .orElseThrow(() -> new ServiceException(ApplicationException.CURRENCY_IS_NOT_ALLOWED));
    // order has the same currency
    paymentVerifier.checkOrderHasSameCurrency(transaction.getOrder(), currency)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.CURRENCY_IS_NOT_ALLOWED);
    // transaction has the same currency
    paymentVerifier.checkTransactionHasSameCurrency(transaction, currency)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.CURRENCY_IS_NOT_ALLOWED);
    final var remainingRefundAmount =
        transaction.getOrder().calculateRemainingRefundAmount(orderTransactions);
    // check refund amount
    paymentVerifier.checkRefundAmount(amount.getValue(),  remainingRefundAmount)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
    // order has transactions which are in processing
    paymentVerifier.checkOrderProcessingTransaction(transaction.getOrder(), orderTransactions)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.IN_PROCESS);
    return true;
  }

  private long convertMoney(Double value) {
    return Objects.isNull(value)
        ? 0L
        : Math.round(value * 100);
  }
}
