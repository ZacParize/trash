package ru.vtb.tsp.ia.epay.apilistener.utils;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AmountResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.CryptoResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSResponseDto.ThreeDSResponseDtoBuilder;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypeResponse;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.TypedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.MerchantSiteA2cResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.MerchantSiteResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.StatusResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c.A2cTransferExtendedResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.a2c.A2cTransferShortResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.c2a.C2aObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderInfoCustomerResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderInfoObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderInfoResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderStatusDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentDataResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentTypeResponse;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.PaymentVisibilityDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.RefundObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.RefundStatusDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.TransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionException;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteTransferParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.TransferAccount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Payment;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.customer.Customer;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;

@Slf4j
public abstract class ConverterUtils {

  private static final int QR_IMAGE_SIZE = 180;
  private static final String QR_IMAGE_FORMAT = "png";
  private static final String PAYMENTS = "payments";
  private static final String REFUNDS = "refunds";

  private static void fillA2cTransferBaseResponse(
      @Nullable TypedResponseDto<? extends A2cTransferShortResponseDto> object,
      @Nullable Order order) {
    Objects.requireNonNull(order);
    Objects.requireNonNull(object);
    Objects.requireNonNull(object.getObject());
    object.setType(TypeResponse.TRANSFER);
    object.getObject().setOrderId(order.getMstOrderId());
    object.getObject().setOrderCode(order.getCode());
    object.getObject().setCreatedAt(order.getCreatedAt());
    object.getObject().setAmount(AmountResponseDto.builder()
        .code(order.getCurrency().getCode())
        .value(order.getAmount())
        .build());
    object.getObject().setStatus(StatusResponseDto.builder()
        .value(order.getState().getValue())
        .description(order.getState().getValue())
        .changedAt(order.getCreatedAt())
        .build());
    object.getObject().setSourceSystem(SourceSystem.IBLK);
  }

  public static @NotNull TypedResponseDto<A2cTransferShortResponseDto> convertToA2cTransferShort(
      @NotNull Order order) {
    final var object = new TypedResponseDto<A2cTransferShortResponseDto>();
    object.setObject(new A2cTransferShortResponseDto());
    fillA2cTransferBaseResponse(object, order);
    return object;
  }

  public static @NotNull TypedResponseDto<A2cTransferExtendedResponseDto>
      convertToA2cTransferExtended(@NotNull Order order) {
    final var object = new TypedResponseDto<A2cTransferExtendedResponseDto>();
    object.setObject(new A2cTransferExtendedResponseDto());
    fillA2cTransferBaseResponse(object, order);
    final var payload = (A2cTransferExtendedResponseDto) object.getObject();
    payload.setDescription(order.getName());
    payload.setMerchantSite(MerchantSiteA2cResponseDto.builder()
        .merchantId(order.getMst().getMerchant().getId())
        .mstId(order.getMst().getId())
        .name(order.getMst().getName())
        .account(Optional.ofNullable(order.getMst().getParams())
            .map(MerchantSiteParams::getTransferParams)
            .map(MerchantSiteTransferParams::getAccount)
            .map(TransferAccount::getAccountNumber).orElse(null))
        .build());
    return object;
  }

  public static @NotNull TypedResponseDto<C2aObjectResponseDto> convertToC2aTransferResponse(
      @NotNull Order order, @Nullable String payUrl) {
    return TypedResponseDto.<C2aObjectResponseDto>builder()
        .type(TypeResponse.TRANSFER)
        .object(C2aObjectResponseDto.builder()
            .orderId(order.getMstOrderId())
            .orderCode(order.getCode())
            .createdAt(order.getCreatedAt())
            .payUrl(payUrl)
            .status(StatusResponseDto.builder()
                .value(order.getState().getValue())
                .description(order.getState().getValue())
                .changedAt(order.getCreatedAt())
                .build())
            .build())
        .build();
  }

  public static @Nullable TransactionResponseDto convert(@Nullable Transaction transaction,
      boolean skipTransactionError) {
    if (Objects.isNull(transaction)) {
      return null;
    }
    if (!skipTransactionError) {
      checkTransactionWithError(transaction);
    }
    ThreeDSResponseDtoBuilder threeDSResponseDtoBuilder = ThreeDSResponseDto.builder();
    threeDSResponseDtoBuilder.isEnabled(Boolean.TRUE.equals(
        transaction.getMst().isEnableCardFlowThreeDS())
    );
    final var responseBuilder = TransactionResponseDto.builder();
    if (transaction.getData().getPaymentData() instanceof Card
        && ((Card) transaction.getData().getPaymentData()).getAdditionalData() instanceof Threeds) {
      final var threeds = ((Threeds) ((Card) transaction.getData()
          .getPaymentData()).getAdditionalData()).getThreeDSData();
      threeDSResponseDtoBuilder.version(
          threeds.getThreeDsVersion() != null ? threeds.getThreeDsVersion().name() : null);
      /*
       * V2_0_CHALLENGE шаг аналогичен V1_0
       */
      if (ThreeDSVersion.V2_0_CHALLENGE.equals(threeds.getThreeDsVersion())
          || ThreeDSVersion.V1_0.equals(threeds.getThreeDsVersion())) {
        threeDSResponseDtoBuilder.isChallengeFlowPassed(
            (transaction.isCompleted()
                || TransactionState.AUTHORIZED.equals(transaction.getState()))
                && !transaction.isDeclined());
      }
    }
    final var paymentMethod = getPaymentMethod(transaction.getData().getPaymentData());
    final var transactionStatus = Optional.ofNullable(transaction.getState())
        .map(Enum::name)
        .orElse(null);
    final var currency = Optional.ofNullable(transaction.getCurrency())
        .map(Currency::getCode)
        .orElse(null);
    final var amount = AmountResponseDto.builder()
        .value(transaction.getAmount())
        .code(currency)
        .build();
    final var createdAt = Optional.ofNullable(transaction.getCreatedAt())
        .map(LocalDateTime::toString)
        .orElse(null);

    return responseBuilder.paymentMethod(paymentMethod)
        .transactionCode(transaction.getCode())
        .amount(amount)
        .transactionStatus(transactionStatus)
        .createdAt(createdAt)
        .threeDS(threeDSResponseDtoBuilder.build())
        .build();
  }

  public static @Nullable TransactionResponseDto convert(@Nullable Transaction transaction) {
    return convert(transaction, false);
  }

  public static @Nullable <T extends Serializable> TypedResponseDto<OrderObjectResponseDto> convert(
      @Nullable Order order,
      @Nullable Enum<?> type,
      @Nullable String payUrl,
      @Nullable T object,
      @Nullable List<Transaction> transactionList) {
    if (Objects.isNull(order)) {
      return null;
    }
    final var builder = OrderObjectResponseDto
        .builder()
        .orderId(order.getMstOrderId())
        .orderCode(order.getCode())
        .transactions(ConverterUtils.convertTransaction(transactionList))
        .expire(order.getExpiredAt())
        .status(OrderStatusDto.builder()
            .value(order.getState().getValue())
            .description(order.getState().getValue())
            .changedAt(order.getCreatedAt())
            .build())
        .createdAt(order.getCreatedAt())
        .payUrl(payUrl)
        .sourceSystem(order.getSourceSystem())
        .amount(AmountResponseDto.builder()
            .value(order.getAmount())
            .code(order.getCurrency().getCode())
            .build());
    if (Objects.nonNull(type)) {
      builder.preparedPayments(Collections.singletonList(
          TypedResponseDto.builder()
              .type(type)
              .object(object)
              .build()));
    }
    return TypedResponseDto.<OrderObjectResponseDto>builder()
        .type(TypeResponse.ORDER)
        .object(builder.build()).build();
  }

  public static @Nullable OrderInfoResponseDto convert(@Nullable Order order,
      @Nullable List<Transaction> transactions,
      @Nullable Customer customer,
      @NotNull Optional<PublicKeyData> crypto) {
    if (Objects.isNull(order)) {
      return null;
    }

    final var orderResponse = OrderInfoObjectResponseDto.builder()
        .orderId(order.getMstOrderId())
        .name(order.getName())
        .state(order.getState())
        .type(order.getOrderType())
        .secondsToExpire(calculateSecondsToExpire(order))
        .amount(AmountResponseDto.builder()
            .value(order.getAmount())
            .code(order.getCurrency().getCode()).build())
        .remainingAmount(AmountResponseDto.builder()
            .code(order.getCurrency().getCode())
            .value(0d /*order.calculateRemainingPayAmount(transactions)*/)
            .build())
        .backUrl(order.getMst().getUrl())
        .returnUrl(order.getReturnUrl())
        .build();

    final var customerResponse = OrderInfoCustomerResponseDto.builder()
        .id(Objects.nonNull(customer) ? customer.getCustomerId() : null)
        .email(Objects.nonNull(customer) ? customer.getEmail() : null)
        .savedCards(Collections.emptyList()).build();

    final List<TransactionResponseDto> transactionsResponse = new ArrayList<>();
    if (!CollectionUtils.isEmpty(transactions)) {
      transactions.forEach(tx -> transactionsResponse.add(convert(tx, true)));
    }

    final var merchantSiteResponse = MerchantSiteResponseDto.builder()
        .name(order.getMst().getName())
        .paymentVisibility(PaymentVisibilityDto
            .builder()
            .isApplePaymentVisible(false)
            .isCardPaymentVisible(
                order.getMst().isEnableCardPayment())
            .isSbpPaymentVisible(
                order.getMst().isEnableSbpPayment())
            .isGooglePaymentVisible(false)
            .isPaymentCheckboxesVisible(false)
            .isMirPaymentVisible(order.getMst().isEnableMirPayment())
            .build())
        .url(order.getMst().getUrl()).build();

    return OrderInfoResponseDto.builder()
        .order(orderResponse)
        .customer(customerResponse)
        .merchantSite(merchantSiteResponse)
        .transactions(transactionsResponse)
        .crypto(CryptoResponseDto.builder()
            .cvvPublicKey(crypto.map(PublicKeyData::getCvvPublicKey).orElse(null))
            .panPublicKey(crypto.map(PublicKeyData::getPanPublicKey).orElse(null))
            .build())
        .build();
  }

  public static String getPaymentMethod(Payment paymentData) {
    if (paymentData instanceof Card) {
      return PaymentTypeResponse.CARD.getValue();
    } else if (paymentData instanceof MirPay) {
      return PaymentTypeResponse.MIR_PAY.getValue();
    } else {
      return PaymentTypeResponse.SBP.getValue();
    }
  }

  public static Map<String, List<TypedResponseDto<? extends Serializable>>> convertTransaction(
      List<Transaction> transactions) {
    return Optional.ofNullable(transactions)
        .filter(ObjectUtils::isNotEmpty)
        .map(list -> {
          final var map = new HashMap<String, List<TypedResponseDto<? extends Serializable>>>();
          list.forEach(tx -> {
            if (tx.isRefund()) {
              addRefund(map, tx);
            } else {
              addPayment(map, tx);
            }
          });
          return map;
        }).orElse(null);
  }

  public static @Nullable String convertToQrCode(@Nullable String text) {
    return Optional.ofNullable(text)
        .map(txt -> {
          try (var bos = new ByteArrayOutputStream()) {
            final var matrix = new MultiFormatWriter().encode(txt, BarcodeFormat.QR_CODE,
                QR_IMAGE_SIZE, QR_IMAGE_SIZE);
            MatrixToImageWriter.writeToStream(matrix, QR_IMAGE_FORMAT, bos);
            return Base64.getEncoder().encodeToString(bos.toByteArray());
          } catch (IOException | WriterException ex) {
            log.error("Error occurred during qr generation by text {}", txt, ex);
            return null;
          }
        })
        .orElse(null);
  }

  public static @NotNull TypedResponseDto<RefundObjectResponseDto> convertToRefundResponse(
      @Nullable Transaction transaction) {
    if (Objects.isNull(transaction)) {
      return null;
    }
    //Пока отключаем проброс ошибки, в дальнейшем в случае наличия ошибки будем заполнять отдельное
    //поле в респонсе
    //checkTransactionWithError(transaction);
    return TypedResponseDto.<RefundObjectResponseDto>builder()
        .type(TypeResponse.REFUND)
        .object(RefundObjectResponseDto.builder()
            .txnId(transaction.getCode())
            .paymentId(transaction.getMstTransactionId())
            .createdAt(transaction.getCreatedAt())
            .orderId(transaction.getOrder().getMstOrderId())
            .orderCode(transaction.getOrder().getCode())
            .status(RefundStatusDto.builder()
                .value(transaction.getState().getValue())
                .changedAt(transaction.getCreatedAt())
                .description(transaction.getState().getValue())
                .build())
            .refundId(transaction.getData().getPaymentId())
            .amount(AmountResponseDto.builder()
                .value(transaction.getAmount())
                .code(Objects.nonNull(transaction.getCurrency())
                    ? transaction.getCurrency().getCode() : null)
                .build())
            .build())
        .build();
  }

  private static Long calculateSecondsToExpire(@NotNull Order order) {
    return Optional.ofNullable(order.getExpiredAt())
        .map(exp -> {
          final var secondsToExpire = order.getExpiredAt()
              .minusSeconds(LocalDateTime.now(ZoneOffset.UTC).getSecond())
              .getLong(ChronoField.SECOND_OF_DAY);
          return secondsToExpire >= 0 ? secondsToExpire : 0L;
        }).orElse(0L);
  }

  public static void checkTransactionWithError(@Nullable Transaction transaction) {
    if (Objects.isNull(transaction)) {
      return;
    }
    if (Objects.nonNull(transaction.getData())
        && Objects.nonNull(transaction.getData().getError())) {
      throw new TransactionException(transaction.getData().getError());
    }
  }

  private static void addPayment(Map<String, List<TypedResponseDto<? extends Serializable>>> map,
      Transaction tx) {
    final var list = map.getOrDefault(PAYMENTS, new ArrayList<>());
    var paymentObject = buildTransactionResponse(tx);
    list.add(paymentObject);
    map.put(PAYMENTS, list);
  }

  public static TypedResponseDto<?> buildTransactionResponse(Transaction tx) {
    return TypedResponseDto.<PaymentObjectResponseDto>builder()
        .type(TypeResponse.PAYMENT)
        .object(PaymentObjectResponseDto.builder()
            .paymentId(tx.getCode())
            .orderId(tx.getOrder().getMstOrderId())
            .orderName(tx.getOrder().getName())
            .createdAt(tx.getCreatedAt())
            .amount(AmountResponseDto.builder()
                .value(tx.getAmount())
                .code(Objects.nonNull(tx.getCurrency()) ? tx.getCurrency().getCode() : null)
                .build())
            .paymentData(PaymentDataResponseDto.builder()
                .type(getPaymentTypeResponse(tx.getType()))
                .build())
            .status(RefundStatusDto.builder()
                .value(tx.getState().getValue())
                .description(tx.getState().getValue())
                .changedAt(LocalDateTime.now(ZoneOffset.UTC))
                .build())
            .build())
        .build();
  }

  private static PaymentTypeResponse getPaymentTypeResponse(TransactionType type) {
    if (TransactionType.isSbpPayment(type)) {
      return PaymentTypeResponse.SBP;
    } else if (TransactionType.isMirPayPayment(type) || TransactionType.isMirPayRefund(type)) {
      return PaymentTypeResponse.MIR_PAY;
    } else {
      return PaymentTypeResponse.CARD;
    }
  }

  private static void addRefund(Map<String, List<TypedResponseDto<? extends Serializable>>> map,
      Transaction tx) {
    final var list = map.getOrDefault(REFUNDS, new ArrayList<>());
    var refundObject =
        TypedResponseDto.<RefundObjectResponseDto>builder()
            .type(TypeResponse.REFUND)
            .object(RefundObjectResponseDto.builder()
                .refundId(tx.getMstTransactionId())
                .txnId(tx.getCode())
                .paymentId(tx.getData().getPaymentId())
                .orderId(tx.getOrder().getMstOrderId())
                .orderCode(tx.getOrder().getCode())
                .createdAt(tx.getCreatedAt())
                .amount(AmountResponseDto.builder()
                    .value(tx.getAmount())
                    .code(Objects.nonNull(tx.getCurrency()) ? tx.getCurrency().getCode() : null)
                    .build())
                .status(RefundStatusDto.builder()
                    .value(tx.getState().getValue())
                    .description(tx.getState().getValue())
                    .changedAt(LocalDateTime.now(ZoneOffset.UTC))
                    .build())
                .build())
            .build();
    list.add(refundObject);
    map.put(REFUNDS, list);
  }
}