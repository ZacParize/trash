package ru.vtb.tsp.ia.epay.apilistener.services.bundle;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.mapper.BundleRefundMapper;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.repository.BundleRefundRepository;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class BundleRefundServiceImpl implements BundleRefundService {

  private final BundleRefundRepository bundleRefundRepository;
  private final BundleRefundMapper bundleRefundMapper;

  @Override
  @Transactional
  public BundleDto create(UUID orderCode, UUID txCode, BundleRequestDto bundle) {
    final var entity = bundleRefundMapper.requestDtoToEntity(bundle);
    entity.setId(UUID.randomUUID());
    entity.setOrderRef(orderCode);
    entity.setTransactionRef(txCode);
    final var saved = bundleRefundRepository.saveOrUpdate(entity);
    return bundleRefundMapper.fromEntity(saved);
  }

  @Override
  @Transactional
  public BundleDto create(UUID orderCode, UUID txCode, BundleDto bundle) {
    final var entity = bundleRefundMapper.dtoToEntity(bundle);
    entity.setId(UUID.randomUUID());
    entity.setOrderRef(orderCode);
    entity.setTransactionRef(txCode);
    final var saved = bundleRefundRepository.saveOrUpdate(entity);
    return bundleRefundMapper.fromEntity(saved);
  }

  @Override
  public BundleDto getBundleByTxCode(String txCode) {
    final var bundle = bundleRefundRepository.findByTxCode(txCode);
    return bundleRefundMapper.fromEntity(bundle);
  }

  @Override
  public List<BundleDto> getBundlesByOrderCode(String orderCode) {
    return bundleRefundRepository.findAllByOrderCode(orderCode).stream()
        .map(bundleRefundMapper::fromEntity)
        .collect(Collectors.toList());
  }
}
