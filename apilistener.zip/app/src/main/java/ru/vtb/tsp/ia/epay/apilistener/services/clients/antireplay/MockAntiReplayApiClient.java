package ru.vtb.tsp.ia.epay.apilistener.services.clients.antireplay;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AntiReplayResponseDto;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.anti-replay.mock", havingValue = "true")
public class MockAntiReplayApiClient implements AntiReplayApi {

  @Override
  public ResponseEntity<AntiReplayResponseDto> getStatus(HttpHeaders httpHeaders, String id) {
    log.info("Anti replay request {}", id);
    return ResponseEntity.ok(AntiReplayResponseDto.builder().jti(id).status(true).build());
  }
}