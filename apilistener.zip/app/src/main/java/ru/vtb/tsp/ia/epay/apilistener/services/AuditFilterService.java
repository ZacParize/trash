package ru.vtb.tsp.ia.epay.apilistener.services;

import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AntiReplayResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.services.clients.antireplay.AntiReplayApi;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService;

@Slf4j
@Service
public class AuditFilterService {

  private static final String MERCHANT_AUTHORIZATION = "Merchant-Authorization";

  private final MerchantSiteService merchantSiteService;
  private final AntiReplayApi antiReplayApi;
  private final String systemUser;

  public AuditFilterService(MerchantSiteService merchantSiteService,
      AntiReplayApi antiReplayApi,
      @Value("${app.paylink.system-user}") String systemUser) {
    this.merchantSiteService = merchantSiteService;
    this.antiReplayApi = antiReplayApi;
    this.systemUser = systemUser;
  }

  @AuditProcess(value = "TSPACQ_BOX_JWT_EPA_AUTH")
  public MerchantSite getMerchantSite(HttpServletRequest request, String clientId) {
    MerchantSite loggedMst;
    if (clientId.isBlank()) {
      log.error("Empty clienId");
      throw new ServiceException(ApplicationException.INCORRECT_CLIENT_ID);
    }
    if (systemUser.equals(clientId)) {
      log.info("SYSTEM USER login success");
      final var mstId = request.getHeader(MERCHANT_AUTHORIZATION);
      if (ObjectUtils.isEmpty(mstId)) {
        log.error("Empty Merchant-Authorization header");
        throw new ServiceException(ApplicationException.MERCHANT_SITE_NOT_FOUND, null);
      }
      loggedMst = merchantSiteService.getById(mstId).stream().mapToInt().reduce().orElseThrow(() -> {
        log.error("No merchant site by id = {}", mstId);
        throw new ServiceException(ApplicationException.MERCHANT_SITE_NOT_FOUND, null);
      });
    } else {

      final var listOfMstByLogin = merchantSiteService.getByLogin(clientId);
      if (ObjectUtils.isEmpty(listOfMstByLogin)) {
        log.error("Incorrect client_id {}", clientId);
        throw new ServiceException(ApplicationException.INCORRECT_CLIENT_ID);
      }
      if (listOfMstByLogin.size() == 1) {
        loggedMst = listOfMstByLogin.iterator().next();
      } else {
        final var mstHeader = request.getHeader(MERCHANT_AUTHORIZATION);
        if (ObjectUtils.isEmpty(mstHeader)) {
          log.error("Empty Merchant-Authorization header");
          throw new ServiceException(ApplicationException.MERCHANT_SITE_NOT_FOUND);
        }
        loggedMst = listOfMstByLogin.stream()
            .filter(mst -> mstHeader.equals(mst.getId()))
            .findFirst()
            .orElseThrow(() -> {
              log.error("No merchant sites by client_id {} with Merchant-Authorization {}",
                  clientId, mstHeader);
              return new ServiceException(ApplicationException.INCORRECT_CLIENT_ID);
            });
      }
    }
    return loggedMst;
  }

  public ResponseEntity<AntiReplayResponseDto> getAntiReplayResponse(String jti) {
    return antiReplayApi.getStatus(HttpHeaders.EMPTY, jti);
  }
}