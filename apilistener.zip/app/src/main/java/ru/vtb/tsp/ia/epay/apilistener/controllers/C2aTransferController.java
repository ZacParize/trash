package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.c2a.C2aTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.merchants.transfer.c2a.C2aObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;

@Slf4j
@RestController
@Validated
public class C2aTransferController {

  public static final String AUDIT_CREATE_TRANSFER_REQUEST =
      "TSPACQ_BOX_C2A_CREATE_TRANSFER_REQUEST";
  private static final String TRANSFERS = "/transfers";
  private static final String POST_CREATE_TRANSFER = TRANSFERS + "/card-to-account";
  private final PaymentService paymentService;
  private final String payformUrl;

  public C2aTransferController(
      PaymentService paymentService,
      @Value("${app.payform.url}") @NotBlank String payformUrl) {
    this.paymentService = paymentService;
    this.payformUrl = payformUrl;
  }

  @PostMapping(path = "${app.api.prefix}"
      + POST_CREATE_TRANSFER, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = C2aObjectResponseDto.class))
  })
  public @NotNull ResponseEntity<?> createTransfer(
      @RequestBody @NotNull @Valid C2aTransferRequestDto c2aTransferRequestDto) {
    log.info("Received create transfer request {}", c2aTransferRequestDto);
    return paymentService.createOrder(c2aTransferRequestDto,
            (MerchantSite) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
        .map(o -> ResponseEntity.ok(ConverterUtils.convertToC2aTransferResponse(o, getPayUrl(o))))
        .orElseThrow(
            () -> new ValidationException("Can't create transfer " + c2aTransferRequestDto));
  }


  private @NotNull String getPayUrl(@NotNull Order order) {
    return payformUrl + "?transfer-id=" + order.getCode();
  }
}
