package ru.vtb.tsp.ia.epay.apilistener.services.clients.fiscalization;

import java.util.List;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.ExtPrometheusMertics;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptStatusDto;

@ExtPrometheusMertics
public interface FiscalizationApi {

  static final String RECEIPT_STATUS_PATH = "/api/v1/receipts/{orderCode}/status";
  static final String APPLICATION_JSON = "application/json";

  @GetMapping(path = RECEIPT_STATUS_PATH, produces = APPLICATION_JSON)
  @NotNull ResponseEntity<List<ReceiptStatusDto>> getStatus(
      @PathVariable("orderCode") UUID orderCode);

}