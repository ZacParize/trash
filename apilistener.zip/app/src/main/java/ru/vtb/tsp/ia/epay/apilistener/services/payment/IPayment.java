package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface IPayment {

  default Optional<Transaction> pay(PaymentRequest request) {
    throw new OperationNotSupported();
  }

  default Optional<Transaction> pay(PaymentRequest request, MerchantSite mst) {
    throw new OperationNotSupported();
  }

  default Optional<Transaction> pay(Order order) {
    throw new OperationNotSupported();
  }

}
