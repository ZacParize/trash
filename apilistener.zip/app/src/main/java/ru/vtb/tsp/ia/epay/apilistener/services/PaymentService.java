package ru.vtb.tsp.ia.epay.apilistener.services;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.controllers.C2aTransferController;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.AbstractTransferRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.A2cInternalTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OrderNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.a2c.TransferDto;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.IPaymentGateway;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.apilistener.utils.TransactionUtils;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.core.domains.enums.CofOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.GatewayOperation;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;


@Slf4j
@Service
@Validated
@RequiredArgsConstructor
public class PaymentService {

  private final Map<GatewayType, IPaymentGateway> paymentGateways = new HashMap<>();

  private final TransactionService transactionService;
  private final OrderServiceFacade orderServiceFacade;
  private final BundleServiceFacade bundleServiceFacade;
  private final KafkaService kafkaService;
  private final PaymentVerifier paymentVerifier;

  public void register(IPaymentGateway gateway) {
    paymentGateways.put(gateway.getGatewayType(), gateway);
  }

  public @NotNull Optional<Transaction> registerPayment(PaymentRequest paymentRequest,
      MerchantSite mst, GatewayType provider) {
    log.info("Payment request {} MerchantSite id {}, {} payment in process",
        paymentRequest.getClass(), mst.getId(), provider.name());
    return paymentGateways.get(provider).pay(paymentRequest, mst)
        .map(tx -> {
          if (!tx.isPaid()) {
            kafkaService.sendToBox(tx.getData());
            log.info("Transaction id {}, {} payment is registered",
                tx.getTransactionId(), provider.name());
          }
          return Optional.of(tx);
        }).orElse(Optional.empty());
  }

  public @NotNull Optional<Transaction> registerPayment(PaymentRequest paymentRequest,
      GatewayType provider) {
    log.info("Payment request {}, {} payment in process", paymentRequest.getClass(),
        provider.name());
    return paymentGateways.get(provider).pay(paymentRequest)
        .map(tx -> {
          if (!tx.isPaid()) {
            kafkaService.sendToBox(tx.getData());
            log.info("Transaction id {}, {} payment is registered",
                tx.getTransactionId(), provider.name());
          }
          return Optional.of(tx);
        }).orElse(Optional.empty());
  }

  public @NotNull Optional<Transaction> registerPayment(Order order, GatewayType provider) {
    log.info("Payment request for order id {}, {} payment in process", order.getOrderId(),
        provider.name());
    return paymentGateways.get(provider).pay(order)
        .map(tx -> {
          if (!tx.isPaid()) {
            kafkaService.sendToBox(tx.getData());
            log.info("Transaction id {}, {}} payment is registered",
                tx.getTransactionId(), provider.name());
          }
          return Optional.of(tx);
        }).orElse(Optional.empty());
  }

  public @NotNull Optional<Transaction> registerMirPayPayment(PaymentRequest paymentRequest) {
    log.info("Payment request {}, {} payment in process", paymentRequest.getClass(),
        GatewayType.MIR_PAY);
    return paymentGateways.get(GatewayType.MIR_PAY).pay(paymentRequest);
  }

  public void processSbpPayment(PaymentRequest paymentRequest) {
    paymentGateways.get(GatewayType.SBP).pay(paymentRequest)
        .filter(Transaction::isCompleted)
        .ifPresent(tx -> {
          log.info("Transaction id {} SBP payment is processed", tx.getTransactionId());
          kafkaService.sendTransactionToPortal(tx.getData());
          kafkaService.sendToBox(tx.getData());
        });
  }

  public @NotNull Optional<String> getQr(@Nullable String orderId) {
    return paymentGateways.get(GatewayType.SBP).status(orderId);
  }

  public void registerSbpRefund(RefundRequest refundRequest) {
    paymentGateways.get(GatewayType.SBP).refund(refundRequest);
  }

  @Transactional
  public @NotNull Optional<Transaction> registerRefund(RefundRequestDto refundReq,
      MerchantSite mst) {
    if (ObjectUtils.isEmpty(refundReq.getPaymentId())
        || ObjectUtils.isEmpty(refundReq.getRefundId())) {
      return Optional.empty();
    }
    return transactionService.getByCode(refundReq.getPaymentId())
        .filter(paymentTx -> paymentTx.getData().getMerchant().getMstId().equals(mst.getId()))
        .map(paymentTx -> {
          final var gatewayType = GatewayType.fromTxType(paymentTx.getType());
          log.info("{}: register refund for transaction with id '{}' and refund id '{}'.",
              gatewayType.name(), paymentTx.getTransactionId(), refundReq.getRefundId());
          return paymentGateways.get(gatewayType).refund(refundReq, paymentTx, mst)
              .map(refundTx -> {
                bundleServiceFacade.createBundleRefund(refundReq, refundTx, mst);
                kafkaService.sendToBox(refundTx.getData());
                log.info("{}: refund transaction with id '{}' send to kafka.", gatewayType,
                    refundTx.getTransactionId());
                return refundTx;
              });
        })
        .orElseThrow(() -> new ServiceException(ApplicationException.TRANSACTION_NOT_FOUND, null));
  }

  private @NotNull Order cancelOrder(@Nullable Order orderToCancel) {
    return Optional.ofNullable(orderToCancel)
        .filter(order -> order.isCreated() || order.isPending())
        .map(order -> {
          final var transactions = transactionService.getByOrderId(order.getOrderId());
          final var processedTxs = transactions.stream()
              .filter(tx -> tx.isProcessing() || tx.isAuthorized()).toList();
          if (processedTxs.isEmpty()) {
            return orderServiceFacade.upsert(order.withState(OrderState.CANCELED))
                .map(o -> {
                  log.info("Order id {} was canceled", o.getOrderId());
                  return o;
                })
                .orElse(null);
          }
          if (order.isPending()) {
            final var authTxList = transactions.stream()
                .filter(Transaction::isAuthorized).toList();
            paymentVerifier.checkTransactionExists(authTxList)
                .ifCheckFailedThrow(() -> new TransactionNotFoundException());
            paymentVerifier.checkSingleTransaction(authTxList)
                .ifCheckFailedThrow(() -> new InternalException());
            transactionService.createCardRefund(order,
                    authTxList.get(0).getAmountHold(),
                    authTxList.get(0).getCurrency(),
                    UUID.randomUUID().toString())
                .flatMap(tx -> {
                  TransactionUtils.setOriginalContext(authTxList.get(0), tx);
                  tx.getData().setGatewayOperation(GatewayOperation.REVERSE);
                  return transactionService.upsert(tx)
                      .map(newTx -> {
                        kafkaService.sendToBox(newTx.getData());
                        log.info("Transaction id {} card reverse is registered",
                            newTx.getTransactionId());
                        return newTx;
                      });
                })
                .orElseThrow(TransactionNotFoundException::new);
          }
          return order;
        }).orElseThrow(OrderNotFoundException::new);
  }

  @Transactional
  public @NotNull Optional<Order> cancelOrder(@Nullable String mstId, @Nullable String mstOrderId) {
    return orderServiceFacade.lockByMstOrderId(mstId, mstOrderId)
        .filter(order -> order.getMst().getId().equals(mstId))
        .map(this::cancelOrder);
  }

  @Transactional
  public @NotNull Optional<Order> cancelOrderFromLK(@Nullable String mstId,
      @Nullable String mstOrderId) {
    return orderServiceFacade.lockByMstOrderId(mstId, mstOrderId)
        .filter(order -> order.getMst().getId().equals(mstId))
        .map(this::cancelOrder);
  }

  @Transactional
  public Optional<TransferDto> createA2cTransfer(A2cInternalTransferRequestDto dto,
      MerchantSite mst) {
    paymentVerifier.checkTransferAvailable(mst)
        .ifCheckFailedLogAndThrow(() -> new OperationNotSupported());
    return orderServiceFacade.createA2c(dto, mst)
        .map(order ->
            TransferDto.builder()
                .transaction(transactionService.createCardPayment(order)
                    .map(tx -> {
                      tx.getData().setPaymentData(Card.builder()
                          .cofOperation(CofOperation.NONE)
                          .encryptedPan(
                              dto.getDestination().getPaymentData().getObject().getEncryptedPan())
                          .build());
                      transactionService.upsert(tx);
                      return tx;
                    }).orElse(null))
                .order(order)
                .build()
        );
  }

  @AuditProcess(C2aTransferController.AUDIT_CREATE_TRANSFER_REQUEST)
  @Transactional
  public Optional<Order> createOrder(AbstractTransferRequest<?> dto, MerchantSite mst) {
    if (mst.isEnableC2aTransfer()) {
      return orderServiceFacade.create(dto, mst);
    } else {
      log.error("C2a transfer for merchant site {} is not available", mst.getId());
      throw new OperationNotSupported();
    }
  }
}