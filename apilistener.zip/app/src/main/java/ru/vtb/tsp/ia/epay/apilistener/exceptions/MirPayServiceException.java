package ru.vtb.tsp.ia.epay.apilistener.exceptions;

import lombok.Getter;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayInApplicationResultErrorResponseDto;

@Getter
public class MirPayServiceException extends RuntimeException {

  /**
   * Человекочитаемое объяснение, характерное для конкретно этого случая.
   */
  private final String errorExplanation;
  /**
   * httpCode - HTTP-код сгенерированный исходным сервером для конкретно этого типа проблемы.
   * message - Короткое описание проблемы на английском языке для чтения инженерами (обычно не
   * локализированное).
   */
  private final ApplicationException exception;

  public MirPayServiceException(ApplicationException exception, String errorMessage) {
    this.errorExplanation = errorMessage;
    this.exception = exception;
  }

  public String getId() {
    return exception.getId();
  }

  public Integer getHttpCode() {
    return exception.getHttpCode();
  }

  public String getMessage() {
    return exception.getMessage();
  }

  public String getDescription() {
    return exception.getDescription();
  }

  public MirPayInApplicationResultErrorResponseDto toDto() {
    return MirPayInApplicationResultErrorResponseDto.builder()
        .status(getHttpCode())
        .title(getDescription())
        .detail(this.errorExplanation)
        .build();
  }
}
