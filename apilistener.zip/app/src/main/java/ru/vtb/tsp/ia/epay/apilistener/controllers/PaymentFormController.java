package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.Objects;
import java.util.Optional;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.EmailRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.CardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.SavedCardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ExecutionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.GetThreeDSDecisionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.PostThreeDSDecisionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.PublicKeyDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSMethodResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.ThreeDSTransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.OrderInfoResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayTransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.QrCodeResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.TransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OrderNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.AuditResponseService;
import ru.vtb.tsp.ia.epay.apilistener.services.LinksService;
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.services.PublicKeyService;
import ru.vtb.tsp.ia.epay.apilistener.services.ValidationService;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSDecisionService;
import ru.vtb.tsp.ia.epay.apilistener.services.populators.MirPayTransactionResponseDtoPopulator;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class PaymentFormController {

  private static final String PUBLIC_KEY = "/public-key";
  private static final String ID_PATH_VARIABLE = "id";
  private static final String ORDER_ID_PATH_VARIABLE = "orderId";
  private static final String TRANSFER_ID_PATH_VARIABLE = "transferId";
  private static final String TRANSACTION_CODE_PATH_VARIABLE = "transactionCode";
  private static final String GET_QR_CODE_PATH = "/order/{" + ORDER_ID_PATH_VARIABLE + "}/sbp-link";
  private static final String GET_ORDER_PATH = "/order/{" + ORDER_ID_PATH_VARIABLE + "}";
  private static final String GET_TRANSACTION_PATH =
      "/transaction/{" + TRANSACTION_CODE_PATH_VARIABLE + "}";
  private static final String POST_CARD_PAYMENT_PATH =
      "/order/{" + ORDER_ID_PATH_VARIABLE + "}/transaction/card";
  private static final String POST_MIR_PAY_PAYMENT_PATH =
      "/order/{" + ORDER_ID_PATH_VARIABLE + "}/transaction/mir-pay";
  private static final String POST_TRANSFER_PATH =
      "/transfer/{" + TRANSFER_ID_PATH_VARIABLE + "}/transaction/card";
  private static final String POST_SAVED_CARD_PAYMENT_PATH =
      "/order/{" + ORDER_ID_PATH_VARIABLE + "}/transaction/saved-card";
  private static final String POST_SEND_EMAIL_PATH =
      "/transaction/{" + TRANSACTION_CODE_PATH_VARIABLE + "}/email";
  private static final String GET_THREE_DS_TRANSACTION_PATH =
      "/transaction/{" + TRANSACTION_CODE_PATH_VARIABLE + "}/threeds";
  private static final String GET_THREE_DS_METHOD_PATH =
      "/transaction/{" + TRANSACTION_CODE_PATH_VARIABLE + "}/threedsmethod";
  private static final String POST_THREE_DS_DECISION_PATH =
      "/transaction/{" + TRANSACTION_CODE_PATH_VARIABLE + "}/threedsdecision";
  private static final String DELETE_SAVED_CARD_PATH = "/card/{" + ID_PATH_VARIABLE + "}";

  private final OrderServiceFacade orderServiceFacade;
  private final TransactionService transactionService;
  private final LinksService linksService;
  private final PaymentService paymentService;
  private final PublicKeyService publicKeyService;
  private final ValidationService validationService;
  private final ThreeDSDecisionService threeDSDecisionService;
  private final AuditResponseService auditResponseService;
  private final MirPayTransactionResponseDtoPopulator mirPayTransactionResponseDtoPopulator;

  @GetMapping(path = "${app.api.prefix}" + PUBLIC_KEY, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<PublicKeyDto> getPublicKey() {
    return ResponseEntity.ok(publicKeyService.getPublicKeyDto());
  }

  @GetMapping(path = "${app.api.prefix}" + GET_ORDER_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<OrderInfoResponseDto> getOrder(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String orderCode) {
    log.info("Received get order info request {}", orderCode);
    return orderServiceFacade.getByCode(orderCode)
        .map(order -> ResponseEntity.ok(ConverterUtils.convert(order,
            transactionService.getByOrderId(order.getOrderId()),
            null,
            publicKeyService.getPublicKey())))
        .orElseThrow(OrderNotFoundException::new);
  }

  @GetMapping(path = "${app.api.prefix}" + GET_QR_CODE_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = QrCodeResponseDto.class))
  })
  public @NotNull ResponseEntity<?> createQr(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String orderCode) {
    log.info("Received create qr request {}", orderCode);
    return orderServiceFacade.getByCode(orderCode)
        .map(order -> ResponseEntity.ok(QrCodeResponseDto.builder()
            .link(Optional.ofNullable(order.getOrderId())
                .flatMap(paymentService::getQr)
                .orElse(null))
            .build())
        ).orElseThrow(InternalException::new);
  }

  @GetMapping(path = "${app.api.prefix}" + GET_TRANSACTION_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<TransactionResponseDto> getTransaction(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String transactionCode) {
    log.info("Received get transaction request {}", transactionCode);
    return transactionService.getByCode(transactionCode)
        .map(ConverterUtils::convert)
        .map(ResponseEntity::ok)
        .orElseThrow(TransactionNotFoundException::new);
  }

  @AuditProcess("TSPACQ_BOX_CARD_PAYMENT")
  @PostMapping(path = "${app.api.prefix}"
      + POST_CARD_PAYMENT_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<TransactionResponseDto> payByCard(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String mstOrderCode,
      @RequestBody @NotNull CardPaymentRequestDto cardRequest) {
    validationService.validatePaymentRequestDto(mstOrderCode, cardRequest);
    log.info("Received payment card request for order {}", mstOrderCode);
    cardRequest.setMstOrderCode(mstOrderCode);
    return paymentService.registerPayment(cardRequest, GatewayType.CARD)
        .map(ConverterUtils::convert)
        .map(ResponseEntity::ok)
        .orElseThrow(TransactionNotFoundException::new);
  }

  @AuditProcess(value = "TSPACQ_BOX_MIR_PAY_PAYMENT", techSectionCodes = {"fin_gen"})
  @PostMapping(path = "${app.api.prefix}" + POST_MIR_PAY_PAYMENT_PATH,
      produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MirPayTransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<MirPayTransactionResponseDto> startPaymentByMirPay(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String mstOrderCode,
      @RequestBody @NotNull MirPayPaymentRequestDto mirPayRequest) {
    log.info("Mir Pay: received start payment request for order '{}'", mstOrderCode);
    mirPayRequest.setMstOrderCode(mstOrderCode);
    return paymentService.registerMirPayPayment(mirPayRequest)
        .map(mirPayTransactionResponseDtoPopulator::populate)
        .map(ResponseEntity::ok)
        .orElseThrow(TransactionNotFoundException::new);
  }

  @PostMapping(path = "${app.api.prefix}"
      + POST_TRANSFER_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<TransactionResponseDto> transferToAccount(
      @PathVariable(TRANSFER_ID_PATH_VARIABLE) @NotBlank String mstOrderCode,
      @RequestBody @NotNull CardPaymentRequestDto cardRequest) {
    log.info("Received transfer card to account request for transfer {}", mstOrderCode);
    cardRequest.setMstOrderCode(mstOrderCode);
    return paymentService.registerPayment(cardRequest, GatewayType.CARD)
        .map(auditResponseService::createC2aTransfer)
        .map(ConverterUtils::convert)
        .map(ResponseEntity::ok)
        .orElseThrow(TransactionNotFoundException::new);
  }

  @PostMapping(path = "${app.api.prefix}"
      + POST_SAVED_CARD_PAYMENT_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<TransactionResponseDto> payBySavedCard(
      @PathVariable(ORDER_ID_PATH_VARIABLE) @NotBlank String orderId,
      @RequestBody @NotNull @Valid SavedCardPaymentRequestDto cardRequest) {
    return new ResponseEntity<>(TransactionResponseDto.builder().build(), HttpStatus.OK);
  }

  @GetMapping(path = "${app.api.prefix}"
      + GET_THREE_DS_TRANSACTION_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<ThreeDSTransactionResponseDto> getThreeDS(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String code) {
    return transactionService.getByCode(code)
        .map(transaction -> {
          final var bldr = ThreeDSTransactionResponseDto.builder();
          final var context = transaction.getData().getContext();
          if (context.containsKey(ThreeDSContextVariables.TDS_ACS.cname()) && !ObjectUtils.isEmpty(
              context.get(ThreeDSContextVariables.TDS_ACS.cname()))) {
            bldr.acsUrl((String) context.get(ThreeDSContextVariables.TDS_ACS.cname()));
          }
          bldr.md(transaction.getCode());
          bldr.termUrl(linksService.createLinkThreeDsPares(code));
          if (context.containsKey(ThreeDSContextVariables.TDS_PAREQ.cname())
              && !ObjectUtils.isEmpty(context.get(ThreeDSContextVariables.TDS_PAREQ.cname()))) {
            bldr.paReq((String) context.get(ThreeDSContextVariables.TDS_PAREQ.cname()));
          }
          return ResponseEntity.ok(bldr.build());
        })
        .orElseThrow(TransactionNotFoundException::new);

  }

  @AuditProcess("TSPACQ_BOX_THREEDS_METHOD")
  @GetMapping(path = "${app.api.prefix}"
      + GET_THREE_DS_METHOD_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<ThreeDSMethodResponseDto> getThreeDSMethod(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String transactionCode) {
    log.info("3DS method, code = {}", transactionCode);
    final var transaction = transactionService.getByCode(transactionCode).orElse(null);
    if (Objects.isNull(transaction)) {
      throw new TransactionNotFoundException();
    }

    final var data = ((Threeds) ((Card) transaction.getData()
        .getPaymentData()).getAdditionalData()).getThreeDSData();

    if (StringUtils.isEmpty(data.getNotificationUrl())) {
      throw new TransactionNotFoundException();
    }
    String transId = (String) transaction.getData().getContext()
        .getOrDefault(ThreeDSContextVariables.TDS_SERVER_TID.cname(), "");
    return ResponseEntity.ok(ThreeDSMethodResponseDto.builder()
        .threeDSMethodNotificationURL(data.getNotificationUrl())
        .threeDSMethodData(linksService.prepareLink(transId, transaction.getCode()))
        .build());
  }

  @AuditProcess("TSPACQ_BOX_POST_THREEDS_DECISION")
  @PostMapping(path = "${app.api.prefix}"
      + POST_THREE_DS_DECISION_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<PostThreeDSDecisionResponseDto> postThreeDSDecision(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String transactionCode,
      @RequestBody @NotNull ThreeDSDecisionCallbackDto threeDSDecision) {
    log.info("3DS decision, post, code = {}, body = {}", transactionCode, threeDSDecision);
    return Optional.ofNullable(threeDSDecisionService
            .fill3DSDataFrom3DSDecision(threeDSDecision, transactionCode))
        .map(ResponseEntity::ok)
        .orElseThrow(InternalError::new);
  }

  @AuditProcess("TSPACQ_BOX_GET_THREEDS_DECISION")
  @GetMapping(path = "${app.api.prefix}"
      + POST_THREE_DS_DECISION_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<GetThreeDSDecisionResponseDto> getThreeDSDecision(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String transactionCode) {
    log.info("3DS decision, get, code = {}", transactionCode);
    return Optional.ofNullable(threeDSDecisionService.getThreedsDecisionStatus(transactionCode))
        .map(ResponseEntity::ok)
        .orElseThrow(InternalError::new);
  }

  @PostMapping(path = "${app.api.prefix}" + POST_SEND_EMAIL_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<ExecutionResponseDto> sendEmail(
      @PathVariable(TRANSACTION_CODE_PATH_VARIABLE) @NotBlank String transactionId,
      @RequestBody @NotNull EmailRequestDto email) {
    return ResponseEntity.ok(ExecutionResponseDto.builder().isExecuted(Boolean.TRUE).build());
  }

  @DeleteMapping(path = "${app.api.prefix}"
      + DELETE_SAVED_CARD_PATH, produces = APPLICATION_JSON_VALUE)
  public @NotNull ResponseEntity<ExecutionResponseDto> deleteSavedCard(
      @PathVariable(ID_PATH_VARIABLE) @NotEmpty String id) {
    return ResponseEntity.ok(ExecutionResponseDto.builder().isExecuted(Boolean.TRUE).build());
  }
}