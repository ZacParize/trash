package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.IPaymentGateway;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class SbpGateway implements IPaymentGateway {

  private final ISbpPayment sbpPayment;
  private final ISbpRefund sbpRefund;
  private final KafkaService kafkaService;

  @Override
  public GatewayType getGatewayType() {
    return GatewayType.SBP;
  }

  @Override
  public Optional<Transaction> pay(PaymentRequest request) {
    if (request instanceof SbpPaymentStatusResponseDto sbpPaymentStatusResponseDto) {
      return sbpPayment.processPayment(sbpPaymentStatusResponseDto)
          .filter(Transaction::isCompleted)
          .flatMap(tx -> {
            kafkaService.sendTransactionToPortal(tx.getData());
            kafkaService.sendToBox(tx.getData());
            return Optional.of(tx);
          });
    }
    log.error("Spb payment: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }

  @Override
  public Optional<Transaction> refund(RefundRequest request, Transaction tx, MerchantSite mst) {
    if (request instanceof RefundRequestDto refundReq) {
      return sbpRefund.registerRefund(refundReq, tx, mst.getId());
    }
    log.error("Spb refund: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }

  @Override
  public void refund(RefundRequest request) {
    if (request instanceof SbpConfirmRefundCallbackDto sbpConfirmRefundCallbackDto) {
      sbpRefund.processConfirmRefund(sbpConfirmRefundCallbackDto)
          .ifPresent(tx -> {
            if (!tx.isCompleted()) {
              kafkaService.sendToBox(tx.getData());
            }
          });
      return;
    } else if (request instanceof SbpRefundStatusResponseDto sbpRefundStatusResponseDto) {
      sbpRefund.processCompleteRefund(sbpRefundStatusResponseDto)
          .ifPresent(tx -> {
            if (tx.isCompleted()) {
              kafkaService.sendTransactionToPortal(tx.getData());
            }
            kafkaService.sendToBox(tx.getData());
          });
      return;
    }
    log.error("Spb refund: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }

  @Override
  public Optional<String> status(String id) {
    return sbpPayment.getQr(id);
  }
}