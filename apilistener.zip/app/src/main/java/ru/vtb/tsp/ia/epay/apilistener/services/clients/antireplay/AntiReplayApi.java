package ru.vtb.tsp.ia.epay.apilistener.services.clients.antireplay;

import javax.validation.constraints.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AntiReplayResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.ExtPrometheusMertics;


@ExtPrometheusMertics
public interface AntiReplayApi {

  @GetMapping(path = "/jti?{id}", produces = "application/json")
  @NotNull ResponseEntity<AntiReplayResponseDto> getStatus(
      @RequestHeader HttpHeaders httpHeaders, @PathVariable("id") String id);

}