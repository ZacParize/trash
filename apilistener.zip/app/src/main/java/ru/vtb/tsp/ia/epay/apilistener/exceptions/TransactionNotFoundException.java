package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class TransactionNotFoundException extends ServiceException {

  {
    this.exception = ApplicationException.TRANSACTION_NOT_FOUND;
  }

  public TransactionNotFoundException() {
  }

  public TransactionNotFoundException(String message) {
    super(message);
  }

  public TransactionNotFoundException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public TransactionNotFoundException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}