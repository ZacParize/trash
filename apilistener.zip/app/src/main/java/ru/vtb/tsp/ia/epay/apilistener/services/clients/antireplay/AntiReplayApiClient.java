package ru.vtb.tsp.ia.epay.apilistener.services.clients.antireplay;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;

@ConditionalOnProperty(name = "app.anti-replay.mock", havingValue = "false")
@FeignClient(name = "antiReplayApiClient", url = "${app.anti-replay.url}", decode404 = true)
public interface AntiReplayApiClient extends AntiReplayApi {
}