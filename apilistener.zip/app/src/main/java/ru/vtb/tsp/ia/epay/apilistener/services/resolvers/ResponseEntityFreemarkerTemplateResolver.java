package ru.vtb.tsp.ia.epay.apilistener.services.resolvers;

import static org.springframework.util.CollectionUtils.isEmpty;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import freemarker.template.Configuration;
import freemarker.template.TemplateMethodModelEx;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import ru.vtb.omni.audit.lib.api.enums.AudLibEventClass;
import ru.vtb.omni.audit.lib.resolver.FreeMarkerTemplateResolver;
import ru.vtb.tsp.ia.epay.apilistener.services.methods.AuditBundleMethod;

@Slf4j
@Component
@ConditionalOnProperty(prefix = "audit", name = "enabled", havingValue = "true")
@Primary
public class ResponseEntityFreemarkerTemplateResolver extends FreeMarkerTemplateResolver {

  private static final String MERCHANT_AUTHORIZATION = "Merchant-Authorization";
  private static final String SUB = "sub";
  private static final String FREEMARKER_CONFIG = "auditFreeMarkerConfiguration";
  private static final String MERCH_AUTH = "merchAuth";
  private static final String CLIENT_ID = "clientId";
  private static final Base64.Decoder BASE64_DECODER = Base64.getDecoder();
  private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE =
      new TypeReference<>() {
      };

  private final ObjectMapper objectMapper;

  public ResponseEntityFreemarkerTemplateResolver(
      @Qualifier(FREEMARKER_CONFIG) Configuration configuration,
      ObjectMapper objectMapper) {
    super(configuration);
    this.objectMapper = objectMapper;
  }

  @Override
  protected String toMessage(String eventCode, AudLibEventClass eventClass, String messageTemplate,
      Map<String, Object> model) {
    addMerchantAuthorization(model);
    addClientId(model);
    addCustomMethod(model, new AuditBundleMethod());
    return super.toMessage(eventCode, eventClass, messageTemplate, model);
  }

  private void addMerchantAuthorization(Map<String, Object> model) {
    getHeader(MERCHANT_AUTHORIZATION).ifPresent(merchAuth -> model.put(MERCH_AUTH, merchAuth));
  }

  @SneakyThrows
  private void addClientId(Map<String, Object> model) {
    getHeader(HttpHeaders.AUTHORIZATION)
        .ifPresent(token -> {
          final var tokenData = jsonDataFromToken(token);
          if (!isEmpty(tokenData) && tokenData.containsKey(SUB)) {
            model.put(CLIENT_ID, tokenData.get(SUB));
          }
        });
  }

  private Optional<String> getHeader(String name) {
    return Optional.ofNullable(RequestContextHolder.getRequestAttributes())
        .filter(ServletRequestAttributes.class::isInstance)
        .map(attr -> ((ServletRequestAttributes) attr).getRequest().getHeader(name))
        .filter(StringUtils::isNotEmpty);
  }

  @SneakyThrows
  private Map<String, Object> jsonDataFromToken(String b64) {
    final var splittedToken = b64.split("\\.");
    if (splittedToken.length < 2) {
      log.error("Token is incorrect");
      return Collections.emptyMap();
    }
    return objectMapper.readValue(new String(BASE64_DECODER.decode(splittedToken[1])),
        MAP_TYPE_REFERENCE);
  }

  /**
   * Добавляет метод для фримаркера. В модель добавляем название метода и класс, реализующий
   * интерфейс TemplateMethodModelEx
   *
   * @param model         модель
   * @param methodModelEx класс, в котором реализован метод
   */
  private void addCustomMethod(Map<String, Object> model, TemplateMethodModelEx methodModelEx) {
    model.put("getBundle", methodModelEx);
  }
}