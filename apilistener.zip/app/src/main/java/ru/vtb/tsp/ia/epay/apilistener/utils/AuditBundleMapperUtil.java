package ru.vtb.tsp.ia.epay.apilistener.utils;

import java.util.Optional;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleItemRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.TaxParamsDto;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;

@Mapper(componentModel = "spring")
public abstract class AuditBundleMapperUtil {

  @Named("getTextType")
  public static String getTextType(BundleItemRequestDto bundleItemRequest) {
    return Optional.of(bundleItemRequest)
        .map(BundleItemRequestDto::getTaxParams)
        .map(TaxParamsDto::getTaxType)
        .map(TaxRate::getValue)
        .orElse("");
  }
}
