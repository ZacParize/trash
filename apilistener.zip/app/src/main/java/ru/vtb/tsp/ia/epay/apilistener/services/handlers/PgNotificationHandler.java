package ru.vtb.tsp.ia.epay.apilistener.services.handlers;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.PGNotification;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.notifications.SbpQrNotificationDto;

@Slf4j
public class PgNotificationHandler implements Function<PGNotification, String> {

  private final ObjectMapper mapper;
  private final Transaction transaction;

  public PgNotificationHandler(@Nullable ObjectMapper mapper,
                               @Nullable Transaction transaction) {
    this.mapper = Objects.requireNonNull(mapper, "Object mapper can't be null");
    this.transaction = Objects.requireNonNull(transaction, "Transaction can't be null");
  }

  public @Nullable String getTransactionId() {
    return transaction.getTransactionId();
  }

  @Override
  public @Nullable String apply(@Nullable PGNotification notification) {
    return Optional.ofNullable(notification)
        .map(PGNotification::getParameter)
        .map(p -> {
          try {
            log.info("Pg notification parameter {}", p);
            return mapper.readValue(p.getBytes(StandardCharsets.UTF_8),
                SbpQrNotificationDto.class);
          } catch (IOException ex) {
            log.error("Exception during pg notification processing", ex);
            return null;
          }
        })
        .filter(nt -> Objects.nonNull(nt.getTransactionId())
            && nt.getTransactionId().equals(transaction.getTransactionId()))
        .map(nt -> {
          log.info("Qr code {} for transaction id {} was received", nt.getQrLink(),
              nt.getTransactionId());
          return nt.getQrLink();
        }).orElse(null);
  }
}
