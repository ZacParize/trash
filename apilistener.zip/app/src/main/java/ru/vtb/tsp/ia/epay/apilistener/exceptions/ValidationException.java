package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class ValidationException extends ServiceException {

  {
    this.exception = ApplicationException.VALIDATION_ERROR;
  }

  public ValidationException() {
  }

  public ValidationException(String message) {
    super(message);
  }

  public ValidationException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public ValidationException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}