package ru.vtb.tsp.ia.epay.apilistener.services.mirpay;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.util.Base64;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import java.net.URI;
import java.security.PrivateKey;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.configs.MirPayConfig;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayTokenGenerator {

  public static final String UNIVERSAL_LINK = "UL";

  /**
   * Сертификат промежуточного Удостоверяющего центра Агрегатора (Concentrator SubCA).
   */
  private final String nspkCertificateInBase64;

  /**
   * Серийный номер сертификата X.509 НСПК [PK.NSPK.1], число в hex формате
   */
  private final String nspkCertificateSerialNumber;

  /**
   * Приватный ключ ТСП.
   */
  private final PrivateKey appregPrivateKey;

  private final MirPayConfig mirPayConfig;

  /**
   * Получение JWT, который подписанный закрытым ключом ТСП.
   */
  public @NotNull String getMirPayJWT(@NotNull Order order) {
    try {
      long issuedAt = System.currentTimeMillis();
      var merchantId = order.getMst().getMerchant().getId();
      JWSHeader header = buildJwsHeader(merchantId);
      JWTClaimsSet claimsSet = buildJwtClaimsSet(order, issuedAt);
      SignedJWT signedJWT = signJwtWithPrivateTspKey(header, claimsSet);
      return signedJWT.serialize();
    } catch (JOSEException e) {
      log.error("Mir Pay: error while generating jwt for order {}: {}", order.getMst().getId(),
          e.getMessage(), e);
      throw new InternalException();
    }
  }

  private JWSHeader buildJwsHeader(String merchantId) {
    var jwksURL = getJwksURL(merchantId);
    var certificates = getCertificates();
    return new JWSHeader
        .Builder(JWSAlgorithm.PS256)
        .type(JOSEObjectType.JWT)
        .keyID(nspkCertificateSerialNumber)
        .jwkURL(URI.create(jwksURL))
        .x509CertChain(certificates)
        .build();
  }

  private String getJwksURL(String merchantId) {
    return String.format("%s/%s-jwks.json", mirPayConfig.getJwksUrlPrefix(), merchantId);
  }

  private List<Base64> getCertificates() {
    return Collections.singletonList(new Base64(nspkCertificateInBase64));
  }

  private JWTClaimsSet buildJwtClaimsSet(Order order, long issuedAt) {
    var orderCode = order.getCode();
    var issueTime = new Date(issuedAt);
    var merchantId = order.getMst().getMerchant().getId();
    var expirationTime = new Date(issuedAt + mirPayConfig.getTokenExpirationDuration());
    var callBackUrl = String.format("%s/api/v1/In-Application/merchants/%s/orders/%s",
        mirPayConfig.getCallBackHost(), merchantId, orderCode);
    log.info("Mir Pay: call back url '{}'", callBackUrl);

    return new JWTClaimsSet.Builder()
        .issuer(merchantId)
        .issueTime(issueTime)
        .expirationTime(expirationTime)
        .claim("orderId", orderCode)
        .claim("sum", order.getAmount())
        .claim("cur", order.getCurrency().getCode())
        .claim("media", UNIVERSAL_LINK)
        .claim("rurl", callBackUrl)
        .build();
  }

  private SignedJWT signJwtWithPrivateTspKey(JWSHeader header, JWTClaimsSet claimsSet)
      throws JOSEException {
    SignedJWT signedJWT = new SignedJWT(header, claimsSet);
    JWSSigner signer = new RSASSASigner(appregPrivateKey);
    signedJWT.sign(signer);
    return signedJWT;
  }

}
