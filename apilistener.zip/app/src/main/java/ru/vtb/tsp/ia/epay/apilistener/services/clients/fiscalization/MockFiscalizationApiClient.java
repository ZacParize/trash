package ru.vtb.tsp.ia.epay.apilistener.services.clients.fiscalization;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptStatusDto;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.fiscalization-domain.mock", havingValue = "true")
public class MockFiscalizationApiClient implements FiscalizationApi {

  @Override
  public ResponseEntity<List<ReceiptStatusDto>> getStatus(UUID orderCode) {
    return ResponseEntity.ok(new ArrayList<>());
  }
}
