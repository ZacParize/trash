package ru.vtb.tsp.ia.epay.apilistener.services;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import javax.annotation.PostConstruct;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.configs.properties.PublicKeyProperties;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.PublicKeyDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.KeysNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.clients.key.cvv.CvvKeyApi;
import ru.vtb.tsp.ia.epay.apilistener.services.clients.key.pan.PanKeyApi;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;
import ru.vtb.tsp.ia.epay.core.entities.misc.PublicKey;
import ru.vtb.tsp.ia.epay.core.repositories.PublicKeyRepository;

@Slf4j
@Service
@Transactional
@RequiredArgsConstructor
public class PublicKeyService {

  private static final int TIMEOUT = 5000;
  private static final TimeUnit TIMEUNIT = TimeUnit.MILLISECONDS;
  private static final Long PUBLIC_KEY_ID = 1L;
  private static final String PAN_PUBLIC_KEY = "panPublicKey";
  private static final String CVV_PUBLIC_KEY = "cvvPublicKey";
  private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(2);

  private final PublicKeyRepository publicKeyRepository;
  private final CvvKeyApi cvvKeyApi;
  private final PanKeyApi panKeyApi;
  private final PublicKeyProperties properties;

  @Cacheable(value = "publicKeyDto", unless = "#result == null")
  public PublicKeyDto getPublicKeyDto() {
    log.info("Receive public key request");
    return getPublicKey()
        .map(data -> {
          log.info("Receive public key response {}", data);
          return PublicKeyDto.builder()
              .cvvPublicKey(data.getCvvPublicKey())
              .panPublicKey(data.getPanPublicKey())
              .build();
        })
        .orElseThrow(KeysNotFoundException::new);
  }

  @Cacheable(value = "publicKey", unless = "#result == null")
  public Optional<PublicKeyData> getPublicKey() {
    return getPublicKeyList()
        .stream()
        .findAny()
        .flatMap(f -> f.stream().findFirst())
        .stream()
        .findFirst()
        .map(f -> PublicKeyData.builder()
            .cvvPublicKey(f.getValue().getCvvPublicKey())
            .panPublicKey(f.getValue().getPanPublicKey())
            .build());
  }

  public @NotNull Optional<List<PublicKey>> getPublicKeyList() {
    return Optional.of(StreamSupport.stream(publicKeyRepository.findAll().spliterator(), false)
        .collect(Collectors.toList()));
  }

  @PostConstruct
  @Scheduled(cron = "0 0 23 * * ?")
  @Transactional
  public void init() {
    if (!properties.isEnabled()) {
      log.info("Public key uploading isn't enabled");
      return;
    }
    log.info("Start public key uploading");
    final var countDownLatch = new CountDownLatch(2);
    final var result = new ConcurrentHashMap<String, String>();
    try {
      EXECUTOR_SERVICE.invokeAll(List.of(
          new ThreadWorker<>(() -> Objects.requireNonNull(
              panKeyApi.getKey(HttpHeaders.EMPTY).getBody()).getPublicKey(),
              countDownLatch, result, PAN_PUBLIC_KEY),
          new ThreadWorker<>(() -> Objects.requireNonNull(
              cvvKeyApi.getKey(HttpHeaders.EMPTY).getBody()).getPublicKey(),
              countDownLatch, result, CVV_PUBLIC_KEY)
      ), TIMEOUT, TIMEUNIT);
      if (!countDownLatch.await(TIMEOUT, TIMEUNIT)) {
        log.info("Await public key uploading");
        return;
      }
      final var cvvPublicKey = result.get(CVV_PUBLIC_KEY);
      final var panPublicKey = result.get(PAN_PUBLIC_KEY);
      if (Objects.nonNull(cvvPublicKey) && Objects.nonNull(panPublicKey)) {
        PublicKeyData publicKeyData = PublicKeyData.builder()
            .cvvPublicKey(cvvPublicKey)
            .panPublicKey(panPublicKey)
            .build();
        publicKeyRepository.saveOrUpdate(PUBLIC_KEY_ID, publicKeyData);
        log.info("Success public key uploading");
      } else {
        log.info("Public key isn't uploaded");
      }
    } catch (InterruptedException e) {
      log.error("Error occurred during getting public key", e);
    }
  }

  @AllArgsConstructor
  private static class ThreadWorker<T> implements Callable<T> {

    private final Supplier<T> supplier;
    private final CountDownLatch countDownLatch;
    private final Map<String, T> map;
    private final String key;

    @Override
    public T call() {
      try {
        log.info("Processing {} request", key);
        map.put(key, supplier.get());
        return supplier.get();
      } finally {
        countDownLatch.countDown();
      }
    }
  }
}
