package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.GetThreeDSDecisionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.PostThreeDSDecisionResponseDto;

/**
 * Service for 3DS.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.03.2022
 */
public interface ThreeDSDecisionService {

  PostThreeDSDecisionResponseDto fill3DSDataFrom3DSDecision(ThreeDSDecisionCallbackDto decision,
      String transactionCode);

  GetThreeDSDecisionResponseDto getThreedsDecisionStatus(String transactionCode);
}
