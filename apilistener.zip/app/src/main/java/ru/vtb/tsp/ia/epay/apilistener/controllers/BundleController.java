package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.apilistener.BundleApi;
import ru.vtb.tsp.ia.epay.apilistener.services.BundleServiceFacade;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Slf4j
@RestController
@RequiredArgsConstructor
public class BundleController implements BundleApi {

  private final BundleServiceFacade bundleService;

  @GetMapping(path = "${app.api.prefix}" + "/bundle/order/{" + ORDER_CODE_PATH_VARIABLE + "}",
      produces = APPLICATION_JSON_VALUE)
  public BundleDto getByOrderCode(@PathVariable(ORDER_CODE_PATH_VARIABLE) String orderCode) {
    log.info("Bundle request by orderCode = {}", orderCode);
    final var result = bundleService.getBundleByOrderCode(orderCode);
    log.info("Bundle result {} by orderCode = {}", result, orderCode);
    return result;
  }

  @GetMapping(path = "${app.api.prefix}" + "/bundle/refund/{" + TX_CODE_PATH_VARIABLE + "}",
      produces = APPLICATION_JSON_VALUE)
  public BundleDto getByTransactionCode(@PathVariable(TX_CODE_PATH_VARIABLE) String txCode) {
    log.info("Bundle request by transactionCode = {}", txCode);
    final var result = bundleService.getBundleByTxCode(txCode);
    log.info("Bundle result {} by transactionCode = {}", result, txCode);
    return result;
  }
}