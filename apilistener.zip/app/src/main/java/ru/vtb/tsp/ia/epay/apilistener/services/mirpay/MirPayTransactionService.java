package ru.vtb.tsp.ia.epay.apilistener.services.mirpay;

import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayTransactionService {

  private final TransactionService transactionService;

  /**
   * Возвращает список переданных транзакций, предварительно переведя все транзакции с типом MirPay
   * в статус DECLINED.
   */
  public @NotNull List<Transaction> declineMirPayTransactions(
      @NotNull List<Transaction> orderTransactions) {
    return orderTransactions.stream()
        .filter(isActiveMirPayTransaction())
        .findFirst()
        .flatMap(this::updateToDeclinedStatus)
        .map(mirPayTx -> collectOtherTransactions(orderTransactions, mirPayTx))
        .orElse(orderTransactions);
  }

  private static Predicate<Transaction> isActiveMirPayTransaction() {
    return tr -> TransactionType.isMirPayPayment(tr.getType())
        && !TransactionState.isCompleted(tr.getState());
  }

  private Optional<Transaction> updateToDeclinedStatus(Transaction tr) {
    tr.getData().setStatus(TransactionState.DECLINED);
    log.info("Mir Pay: decline transaction with id '{}'", tr.getTransactionId());
    return transactionService.upsert(tr.withState(TransactionState.DECLINED));
  }

  private List<Transaction> collectOtherTransactions(
      List<Transaction> orderTransactions,
      Transaction mirPayTx) {
    return orderTransactions.stream()
        .filter(tx -> !tx.getTransactionId().equals(mirPayTx.getTransactionId()))
        .collect(Collectors.toList());
  }

}
