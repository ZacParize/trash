package ru.vtb.tsp.ia.epay.apilistener.exceptions;

public class MerchantSettingsException extends ServiceException {

  {
    this.exception = ApplicationException.MERCHANT_SETTINGS_ERROR;
  }

  public MerchantSettingsException() {
  }

  public MerchantSettingsException(String message) {
    super(message);
  }

  public MerchantSettingsException(String traceId, String message, Throwable cause) {
    super(traceId, message, cause);
  }

  public MerchantSettingsException(String traceId, Throwable cause) {
    super(traceId, cause);
  }

}
