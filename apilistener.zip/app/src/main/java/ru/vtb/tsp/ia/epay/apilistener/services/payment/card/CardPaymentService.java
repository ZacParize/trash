package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.PaymentCondition;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OrderNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayTransactionService;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.core.domains.enums.CofOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.GatewayOperation;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Amount;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card.CardBuilder;
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.CurrencyService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.tokenization.dto.domains.Binding;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardPaymentService implements ICardPayment {

  private final OrderService orderService;
  private final CurrencyService currencyService;
  private final TransactionService transactionService;
  private final MirPayTransactionService mirPayTransactionService;
  private final PaymentVerifier paymentVerifier;

  @Override
  @Transactional
  public Optional<Transaction> processPayment(Order order) {
    //TODO обсудить дополнительную валидацию,часть проверок сделана на стадии создания ордера
    return transactionService.createCardPayment(order)
        .flatMap(tx -> {
          tx.getData().setPaymentData(Card.builder()
              .binding(Binding.builder()
                  .bindingCode(order.getBindingCode())
                  .category(order.getBindingCategory())
                  .type(order.getBindingType())
                  .build())
              .cofOperation(getCofOperation(order, tx))
              .build());
          return transactionService.upsert(tx);
        });
  }

  @Transactional
  @Override
  public @NotNull Optional<Transaction> processPayment(@Nullable String orderCode,
      @Nullable AmountRequestDto amount,
      @Nullable String email,
      @Nullable String encryptedPan,
      @Nullable String encryptedCvv,
      @Nullable String cardHolder,
      @Nullable String expiryDate) {
    if (Objects.isNull(orderCode) || Objects.isNull(amount)) {
      return Optional.empty();
    }
    return orderService.getByCode(orderCode)
        .filter(order -> !order.isCompleted())
        .map(order -> {
          // card payments should be enabled for mst
          paymentVerifier.checkAccessCardPayment(order)
              .ifCheckFailedLogAndThrow(InternalException::new);
          // terminal id must be marked
          paymentVerifier.checkTerminalIdMarked(order)
              .ifCheckFailedLogAndThrow(InternalException::new);
          // check currency
          final var currency = currencyService.getById(amount.getCode())
              .orElseThrow(() -> new ServiceException(
                  ApplicationException.CURRENCY_IS_NOT_ALLOWED));
          paymentVerifier.checkOrderHasSameCurrency(order, currency)
              .ifCheckFailedLogAndThrow(InternalException::new);
          // check if processing transaction exists
          var orderTransactions = transactionService.getByOrderId(order.getOrderId());

          // decline Mir Pay transaction if present
          orderTransactions = mirPayTransactionService.declineMirPayTransactions(orderTransactions);

          // order has transactions which are in processing
          paymentVerifier.checkOrderProcessingTransaction(order, orderTransactions)
              .ifCheckFailedLogAndThrowServiceException(ApplicationException.IN_PROCESS);
          // pay amount is less than order amount
          final var remainingPayAmount = order
              .calculateRemainingPayAmount(orderTransactions);
          //todo равноценная замена?
          paymentVerifier.checkOrderRemainingAmount(amount, order, remainingPayAmount)
              .ifCheckFailedLogAndThrow(InternalException::new);
          return transactionService.createCardPayment(order)
              .flatMap(tx -> {
                tx.getData().setPaymentData(Card.builder()
                    .email(email)
                    .encryptedPan(encryptedPan)
                    .encryptedCvv(encryptedCvv)
                    .cardHolder(cardHolder)
                    .cofOperation(getCofOperation(order, tx))
                    .expiryDate(Optional.ofNullable(expiryDate)
                        .map(
                            expDate -> YearMonth.parse(expDate, DateTimeFormatter.ofPattern("MMyy"))
                                .atDay(1).atStartOfDay())
                        .orElseThrow(() -> new ServiceException(ApplicationException.CARD_EXPIRED)))
                    .build());
                return transactionService.upsert(tx);
              });
        }).orElseThrow(InternalException::new);
  }

  @Override
  public Optional<Transaction> processPayment(PaymentCardRequest paymentCardRequest,
      MerchantSite merchantSite) {
    boolean orderPaid = orderService.getByCode(paymentCardRequest.getOrderCode().toString())
        .filter(Order::isPaid)
        .isPresent();
    if (orderPaid) {
      return transactionService.getByOrderCode(paymentCardRequest.getOrderCode().toString())
          .stream().findFirst();
    }
    return orderService.lockByCode(paymentCardRequest.getOrderCode().toString())
        .filter(order -> !order.isCompleted())
        .map(order -> {
          paymentVerifier.checkMerchantSiteHasAccessToOrder(merchantSite, order)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          //Merchant order ID should be equals with payment request order ID
          paymentVerifier.checkPaymentAndOrderForOrderIDMatch(paymentCardRequest, order)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          //order should be PAYMENT type
          paymentVerifier.checkOrderType(order, OrderType.PAYMENT)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          // card payments should be enabled for mst
          paymentVerifier.checkAccessCardPayment(order)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          // terminal id must be marked
          paymentVerifier.checkTerminalIdMarked(order)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          // terminal id must be equals
          paymentVerifier.checkPaymentAndOrderForTerminalIDMatch(paymentCardRequest, order)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          // check currency
          final var currency = currencyService.getById(paymentCardRequest.getPaymentData()
                  .getAmount().getCode())
              .orElseThrow(() -> new ServiceException(
                  ApplicationException.CURRENCY_IS_NOT_ALLOWED));
          paymentVerifier.checkOrderHasSameCurrency(order, currency)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          final var processingPaymentTransactionExist = transactionService
              .getByOrderCode(order.getCode())
              .stream().findFirst()
              .filter(Transaction::isPayment)
              .filter(transaction -> transaction.isConfirmed() || transaction.isProcessing());

          // return if processing transaction exists
          if (processingPaymentTransactionExist.isPresent()) {
            return processingPaymentTransactionExist;
          }
          var orderTransactions = transactionService
              .getByOrderId(order.getOrderId());
          // pay amount is less than order amount
          final var remainingPayAmount = order
              .calculateRemainingPayAmount(orderTransactions);
          AmountRequestDto amountRequestDto = paymentCardRequest.getPaymentData().getAmount();
          paymentVerifier.checkOrderRemainingAmount(amountRequestDto, order, remainingPayAmount)
              .ifCheckFailedLogAndThrow(ValidationException::new);
          // decline Mir Pay transaction if present
          orderTransactions = mirPayTransactionService.declineMirPayTransactions(orderTransactions);

          // order has transactions which are in processing
          paymentVerifier.checkOrderProcessingTransaction(order, orderTransactions)
              .ifCheckFailedLogAndThrow(() -> new ValidationException(
                  ApplicationException.IN_PROCESS.getMessage()));

          CardBuilder cardBuilder = Card.builder()
              .encryptedPan(paymentCardRequest.getPaymentData().getEncryptedPan())
              .encryptedCvv(paymentCardRequest.getPaymentData().getEncryptedCvv())
              .expiryDate(Optional.ofNullable(paymentCardRequest.getPaymentData().getExpiryDate())
                  .map(
                      expDate -> YearMonth.parse(expDate, DateTimeFormatter.ofPattern("MMyy"))
                          .atDay(1).atStartOfDay())
                  .orElseThrow(() -> new ValidationException(
                      ApplicationException.CARD_EXPIRED.getMessage())));
          Threeds threeds = new Threeds();

          if (paymentCardRequest.getPaymentData().getCondition()
              == PaymentCondition.FULL_3D_SECURE) {
            threeds.setCavv(
                Objects.requireNonNullElseGet(
                    paymentCardRequest.getPaymentData().getCavv(),
                    () -> {
                      throw new ValidationException();
                    }));
            threeds.setXid(
                Objects.requireNonNullElseGet(
                    paymentCardRequest.getPaymentData().getXid(),
                    () -> {
                      throw new ValidationException();
                    }));
            threeds.setEci(paymentCardRequest.getPaymentData().getEci());
            ThreeDSVersion.findByName(paymentCardRequest.getPaymentData().getV3ds().name())
                .ifPresentOrElse(version -> {
                  threeds.setThreeDSData(new ThreeDSData());
                  threeds.getThreeDSData().setThreeDsVersion(version);
                }, ValidationException::new);
            cardBuilder.additionalData(threeds);
          }
          return transactionService.createCardPayment(order)
              .flatMap(tx -> {
                tx.getData().getContext().put(ThreeDSContextVariables.TDS_BRAND.name(),
                    paymentCardRequest.getPaymentData().getPaymentSystem().name());
                tx.getData().getContext().put(TransactionInfoKey.CARD_PAYSYSTEM.getValue(),
                    paymentCardRequest.getPaymentData().getPaymentSystem().name());
                tx.getData().getContext().put(TransactionInfoKey.CARD_BANK.getValue(),
                    paymentCardRequest.getPaymentData().getBank());
                tx.setType(TransactionType.GW_PAYMENT);
                tx.getData().setGatewayOperation(GatewayOperation.PAYMENT);
                tx.getData().setPaymentData(cardBuilder.build());
                return transactionService.upsert(tx);
              });
        })
        .orElseThrow(OrderNotFoundException::new);
  }

  @Transactional
  public @NotNull Optional<Transaction> completeTwoStageCardPayment(
      @Nullable String mstId,
      @Nullable String mstOrderId, @NotNull AmountRequestDto amount) {
    return orderService.lockByMstOrderId(mstId, mstOrderId)
        .filter(Order::isPending)
        .map(order -> transactionService.getByOrderId(order.getOrderId()))
        .flatMap(txs -> {
          final var authorizedTxs = txs.stream()
              .filter(Transaction::isAuthorized).toList();
          if (authorizedTxs.isEmpty()) {
            return Optional.empty();
          }
          paymentVerifier.checkSingleTransaction(authorizedTxs)
              .ifCheckFailedLogAndThrow(InternalException::new);
          final var tx = authorizedTxs.get(0);
          final long completeAmount = convertMoney(amount.getValue());
          final long holdAmount = convertMoney(tx.getAmountHold());
          paymentVerifier.checkCompleteAmountBiggerHoldAmount(completeAmount, holdAmount)
              .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
          // TODO: possible gateway operation is complete
          tx.getData().setGatewayOperation(GatewayOperation.CONFIRM);
          tx.getData().setAmount(Amount.builder()
              .value(amount.getValue())
              .currency(amount.getCode())
              .build());
          return transactionService.upsert(tx.withAmount(amount.getValue()));
        });
  }

  private long convertMoney(Double value) {
    return Objects.isNull(value)
        ? 0L
        : Math.round(value * 100);
  }

  private CofOperation getCofOperation(Order order, Transaction tx) {
    return switch (tx.getType()) {
      case COF_PAYMENT -> CofOperation.PAYMENT;
      case CARD_PAYMENT -> (Objects.nonNull(order.getBindingCategory())
          && Objects.nonNull(order.getBindingType())) ? CofOperation.INITIAL
          : CofOperation.NONE;
      default -> CofOperation.NONE;
    };
  }
}
