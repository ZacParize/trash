package ru.vtb.tsp.ia.epay.apilistener.configs.properties;

import lombok.Data;

/**
 * Callback links.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.10.2021
 */
@Data
public class ThreedsAcsLinks {

  private String notificationMethodUrl;
  private String notificationCresUrl;
  private String notificationParesUrl;

}
