package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay;


import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_FORBIDDEN;
import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_INVALID_INPUT_DATA;
import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_NOT_FOUND;
import static ru.vtb.tsp.ia.epay.apilistener.utils.TransactionUtils.MST_TRANSACTION_ID;
import static ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType.MIR_PAY_DECLINE_CHECK_TIMEOUT;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.apilistener.configs.MirPayConfig;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayJWT;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.core.domains.enums.GatewayOperation;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.CurrencyService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class MirPayPaymentService implements IMirPayPayment {

  private static final String MIR_PAY_TYPE = "Mir Pay";
  private final KafkaService kafkaService;
  private final OrderService orderService;
  private final MirPayConfig mirPayConfig;
  private final CurrencyService currencyService;
  private final TransactionService transactionService;
  private final PaymentVerifier paymentVerifier;

  @Transactional
  @Override
  public @NotNull Optional<Transaction> startProcessPayment(
      @Nullable String orderCode,
      @Nullable AmountRequestDto amount,
      @Nullable String email) {
    if (Objects.isNull(orderCode) || Objects.isNull(amount)) {
      return Optional.empty();
    }
    return orderService.getByCode(orderCode)
        .filter(order -> !order.isCompleted())
        .map(order -> {
          paymentVerifier.checkAccessMirPay(order)
              .ifCheckFailedLogAndThrow(MIR_PAY_TYPE, () -> new InternalException());

          paymentVerifier.checkTerminalId(order)
              .ifCheckFailedLogAndThrow(MIR_PAY_TYPE, () -> new InternalException());

          final var currency = findCurrencyOrThrowException(amount);

          paymentVerifier.checkOrderHasSameCurrency(order, currency)
              .ifCheckFailedLogAndThrowServiceException(
                  MIR_PAY_TYPE, ApplicationException.CURRENCY_IS_NOT_ALLOWED);

          final var allOrderTransactions = transactionService.getByOrderId(order.getOrderId());
          declineOldTransactions(allOrderTransactions, order);

          final var remainingPayAmount = order.calculateRemainingPayAmount(allOrderTransactions);
          paymentVerifier.checkOrderRemainingAmount(amount, order, remainingPayAmount)
              .ifCheckFailedLogAndThrowServiceException(
                  MIR_PAY_TYPE, ApplicationException.INCORRECT_AMOUNT);

          return transactionService.createMirPayPayment(order)
              .flatMap(tx -> {
                var paymentData = MirPay.builder()
                    .transactionCode(tx.getCode())
                    .build();
                tx.getData().setPaymentData(paymentData);
                final var delay = mirPayConfig.getDeclineCheckDelay();
                kafkaService.sendToNotificator(tx.getCode(), MIR_PAY_DECLINE_CHECK_TIMEOUT, delay);
                log.info("Mir Pay: created transaction id '{}', mstTrId '{}', code '{}', type '{}'",
                    tx.getTransactionId(), tx.getMstTransactionId(), tx.getCode(), tx.getType());
                return transactionService.upsert(tx);
              });
        }).orElseThrow(() -> new ServiceException(ApplicationException.ORDER_NOT_FOUND));
  }

  private Currency findCurrencyOrThrowException(AmountRequestDto amount) {
    return currencyService.getById(amount.getCode())
        .orElseThrow(() -> new ServiceException(
                ApplicationException.CURRENCY_IS_NOT_ALLOWED
            )
        );
  }

  @Transactional
  @Override
  public Optional<Transaction> confirmProcessPayment(
      @NotBlank String orderCode,
      @NotBlank String merchantId,
      @NotNull MirPayJWT mirPayJWT) {
    return orderService.getByCode(orderCode)
        .map(order -> {
          if (order.isCompleted()) {
            final var message = String.format("Order with code '%s' completed", order.getOrderId());
            throw new MirPayServiceException(MIR_PAY_FORBIDDEN, message);
          }
          final var allOrderTransactions = transactionService.getByOrderId(order.getOrderId());
          final var mirPayTransaction = getNewMirPayTransaction(allOrderTransactions);
          paymentVerifier.checkTransactionMerchantId(merchantId, mirPayTransaction)
              .ifCheckFailedLogAndThrow(MIR_PAY_TYPE,
                  (message) -> new MirPayServiceException(MIR_PAY_FORBIDDEN, message));
          final var tem = String.valueOf(mirPayJWT.getTem());
          final var expiryYear = buildExpiryYear(mirPayJWT, tem);
          paymentVerifier.checkExpirationDate(expiryYear)
              .ifCheckFailedLogAndThrow(MIR_PAY_TYPE, (message) ->
                  new MirPayServiceException(MIR_PAY_INVALID_INPUT_DATA, message));
          var paymentData = buildPaymentData(mirPayJWT, mirPayTransaction, expiryYear);
          mirPayTransaction.getData().setPaymentData(paymentData);
          mirPayTransaction.getData().setGatewayOperation(GatewayOperation.PAYMENT);
          mirPayTransaction.getData().getContext()
              .put(MST_TRANSACTION_ID, mirPayTransaction.getMstTransactionId());
          return transactionService.upsert(
              mirPayTransaction.withState(TransactionState.MIR_PAY_PAYMENT_CREATED)
          );
        }).orElseThrow(() -> {
          var message = String.format("Order with code '%s' not found", orderCode);
          return new MirPayServiceException(MIR_PAY_NOT_FOUND, message);
        });
  }

  private MirPay buildPaymentData(
      MirPayJWT mirPayJWT,
      Transaction mirPayTransaction,
      String expiryYear) {
    return MirPay.builder()
        .transactionCode(mirPayTransaction.getCode())
        .cav(mirPayJWT.getCav())
        .expiryYear(expiryYear)
        .transId(mirPayJWT.getTransId())
        .tan(mirPayJWT.getTan())
        .build();
  }

  private String buildExpiryYear(MirPayJWT mirPayJWT, String tem) {
    //Создание даты окончания формата YYMM
    return new StringBuilder()
        .append(mirPayJWT.getTey())
        .append(tem.length() == 1 ? '0' + tem : tem)
        .toString();
  }

  private void declineOldTransactions(List<Transaction> allOrderTransactions, Order order) {
    final List<Transaction> processingOrderTransactions = getProcessingTransactions(
        allOrderTransactions);
    if (CollectionUtils.isNotEmpty(processingOrderTransactions)) {
      paymentVerifier.checkHasNonDeclinedTransaction(
              processingOrderTransactions,
              order.getOrderId())
          .ifCheckFailedLogAndThrowServiceException(
              MIR_PAY_TYPE, ApplicationException.IN_PROCESS);
      processingOrderTransactions.forEach(this::declineTransaction);
    }
  }

  private void declineTransaction(Transaction tr) {
    tr.getData().setStatus(TransactionState.DECLINED);
    log.info("Mir Pay: decline '{}' transaction with type '{}'", tr.getTransactionId(),
        tr.getType());
    transactionService.upsert(tr.withState(TransactionState.DECLINED));
  }

  private Transaction getNewMirPayTransaction(List<Transaction> allOrderTransactions) {
    Predicate<Transaction> isNewMirPayTransaction =
        tr -> TransactionType.isMirPayPayment(tr.getType())
            && TransactionState.NEW.equals(tr.getState());
    return allOrderTransactions.stream()
        .filter(isNewMirPayTransaction)
        .findFirst()
        .orElseThrow(
            () -> new MirPayServiceException(MIR_PAY_NOT_FOUND, "Mir Pay transaction not found"));
  }

  private List<Transaction> getProcessingTransactions(List<Transaction> inclusiveTransactions) {
    return Optional.ofNullable(inclusiveTransactions)
        .map(list -> list.stream()
            .filter(tr -> !TransactionState.isCompleted(tr.getState()))
            .collect(Collectors.toList()))
        .orElseGet(Collections::emptyList);
  }
}
