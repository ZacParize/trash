package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.MerchantReceiptStatusDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MerchantSettingsException;
import ru.vtb.tsp.ia.epay.apilistener.services.fiscalization.ReceiptsService;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class ReceiptsController {

  private static final String RECEIPT_ID_PATH_VARIABLE = "orderId";
  private static final String RECEIPTS_PATH = "/receipts/{" + RECEIPT_ID_PATH_VARIABLE + "}/status";

  private final ReceiptsService receiptsService;

  @GetMapping(path = "${app.api.prefix}" + RECEIPTS_PATH,
      produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantReceiptStatusDto.class))
  })
  public @NotNull ResponseEntity<?> getReceiptStatus(@PathVariable("orderId") String mstOrderId) {
    log.info("Received receipt status request mstOrderId: {}", mstOrderId);
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    if (Objects.isNull(mst.getParams().getFiscalParams())
        || Objects.isNull(mst.getParams().getFiscalParams().getInn())) {
      throw new MerchantSettingsException();
    }
    return ResponseEntity.ok(receiptsService.getReceiptStatus(mst, mstOrderId));
  }

}