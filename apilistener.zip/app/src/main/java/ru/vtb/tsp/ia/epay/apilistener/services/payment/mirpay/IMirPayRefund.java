package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay;

import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface IMirPayRefund {

  /**
   * Возврат средств для MirPay.
   */
  @NotNull Optional<Transaction> registerRefund(@Nullable RefundRequestDto requestDto,
      @Nullable Transaction transaction,
      @Nullable String mstId);

}
