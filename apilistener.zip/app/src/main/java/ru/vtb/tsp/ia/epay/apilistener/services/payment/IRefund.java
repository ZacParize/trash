package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

public interface IRefund {

  default Optional<Transaction> refund(RefundRequest request, Transaction tx, MerchantSite mst) {
    throw new OperationNotSupported();
  }

  default void refund(RefundRequest request) {
    throw new OperationNotSupported();
  }

}
