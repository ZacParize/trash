package ru.vtb.tsp.ia.epay.apilistener.services.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleItemRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.AuditBundleDto;
import ru.vtb.tsp.ia.epay.apilistener.utils.AuditBundleMapperUtil;

@Mapper(componentModel = "spring", uses = AuditBundleMapperUtil.class)
public interface AuditBundleMapper {

  @Mapping(target = "positionId", source = "positionId", defaultValue = "")
  @Mapping(target = "name", source = "name", defaultValue = "")
  @Mapping(target = "price", source = "price", defaultValue = "")
  @Mapping(target = "quantity", source = "quantity", defaultValue = "")
  @Mapping(target = "taxType", source = "bundleItemRequest", qualifiedByName = "getTextType")
  @Mapping(target = "amount", source = "amount", defaultValue = "")
  AuditBundleDto mapBundleItemRequestDtoToAuditBundleDto(BundleItemRequestDto bundleItemRequest);
}
