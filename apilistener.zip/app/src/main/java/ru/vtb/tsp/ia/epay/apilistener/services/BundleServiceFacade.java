package ru.vtb.tsp.ia.epay.apilistener.services;


import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.CARD_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.MIR_PAYMENT_WEB_BASED_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_CARD_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.PARTIAL_SBP_REFUND;
import static ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType.SBP_REFUND;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleItemRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.FiscalInfoDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.TaxParamsDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.BundleValidationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.BundleRefundService;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.BundleService;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.mapper.BundleRefundMapper;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleItem;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteFiscalParams;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;

@Slf4j
@Service
@RequiredArgsConstructor
public class BundleServiceFacade {

  private static final List<TransactionType> FULL_REFUND_BUNDLE = List.of(
      CARD_REFUND,
      SBP_REFUND,
      MIR_PAYMENT_WEB_BASED_REFUND);
  private static final List<TransactionType> PARTIAL_REFUND_BUNDLE = List.of(
      PARTIAL_CARD_REFUND,
      PARTIAL_SBP_REFUND,
      PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND);

  private final BundleService bundleService;
  private final BundleRefundService bundleRefundService;
  private final BundleRefundMapper refundMapper;

  public BundleDto getBundleByOrderCode(String orderId) {
    return bundleService.getBundleByOrderCode(orderId);
  }

  public BundleDto getBundleByTxCode(String orderId) {
    return bundleRefundService.getBundleByTxCode(orderId);
  }

  public void createBundle(UUID orderCode, OrderCreationRequestDto dto, MerchantSite mst) {
    if (validateBundle(dto, mst)) {
      createBundle(orderCode, dto.getBundle());
    } else {
      log.info("Bundle is not valid, order code: {}", orderCode);
    }
  }

  private void createBundle(UUID orderCode, BundleRequestDto bundleReq) {
    log.info("Request bundle create with order code {}", orderCode);
    bundleService.create(orderCode, bundleReq);
    log.info("Bundle created with order code {}", orderCode);
  }

  public void createBundleRefund(RefundRequestDto requestDto, Transaction refundTx,
      MerchantSite mst) {
    validateBundleRefundAndGet(requestDto, refundTx, mst)
        .ifPresent(bundleRefund ->
            createBundleRefund(UUID.fromString(refundTx.getOrder().getCode()),
                UUID.fromString(refundTx.getCode()), bundleRefund));
  }

  private void createBundleRefund(UUID orderCode, UUID txCode, BundleDto dto) {
    log.info("Request bundle refund create with order code {}", orderCode);
    bundleRefundService.create(orderCode, txCode, dto);
    log.info("Bundle refund created with order code {}", orderCode);
  }

  public boolean validateBundle(OrderCreationRequestDto dto, MerchantSite mst) {
    boolean result = false;
    if (isActiveFiscal(mst)) {
      log.info("Fiscal operations ENABLED for merchant site {}", mst.getId());
      if (bundleIsEmpty(dto)) {
        log.info("Bundle is empty, order id {}", dto.getOrderId());
        dto.setBundle(createDefaultBundle(mst.getParams().getFiscalParams(), dto.getAmount()));
        log.info("Default bundle prepare completed, order id {}", dto.getOrderId());
        result = true;
      } else {
        final var bundleAmount = getTotalBundleAmount(dto.getBundle());
        final var orderAmount = BigDecimal.valueOf(dto.getAmount().getValue())
            .setScale(2, RoundingMode.HALF_UP);
        if (bundleAmount.compareTo(orderAmount) != 0) {
          log.error("Bundle's amount {} not equals with order's amount {}, mstId {}, orderId {}",
              bundleAmount, orderAmount, mst.getId(), dto.getOrderId());
          throw new ValidationException();
        }
        checkEmailAndSet(dto.getBundle(), mst);
        result = true;
      }
    } else {
      log.warn("Fiscal operations DISABLED for merchant site {}", mst.getId());
    }
    return result;
  }

  public Optional<BundleDto> validateBundleRefundAndGet(RefundRequestDto refundRequestDto,
      Transaction refundTx, MerchantSite mst) {
    if (isActiveFiscal(mst)) {
      log.info("Fiscal operations ENABLED for merchant site {}", mst.getId());
      final var orderCode = refundTx.getOrder().getCode();
      final var originBundle = bundleService.getBundleByOrderCode(orderCode);
      final var refundAmount = BigDecimal.valueOf(refundRequestDto.getAmount()
          .getValue()).setScale(2, RoundingMode.HALF_UP);
      final var totalBundleAmount = getTotalBundleAmount(originBundle);

      final var isValidBundle = totalBundleAmount.compareTo(refundAmount) == 0
          || (totalBundleAmount.compareTo(refundAmount) > 0
          && isValidPartialBundle(orderCode, originBundle, refundRequestDto));
      if (!isValidBundle) {
        log.error("Bundle's refund validation error, paymentId {}, refundId {}, mstId = {}",
            refundRequestDto.getPaymentId(), refundRequestDto.getRefundId(), mst.getId());
        throw new ValidationException();
      }
      checkEmailAndSet(refundRequestDto.getBundle(), mst);
      if (FULL_REFUND_BUNDLE.contains(refundTx.getType())) {
        return Optional.of(originBundle);
      } else if (PARTIAL_REFUND_BUNDLE.contains(refundTx.getType())
          && refundTx.getOrder().isPayment()) {
        return Optional.of(refundMapper.requestToBundleDto(refundRequestDto.getBundle()));
      }
      log.warn("Bundle refund not support transaction type {}, transaction id {}",
          refundTx.getType(), refundTx.getTransactionId());
    } else {
      log.warn("Fiscal operations DISABLED for merchant site {}", mst.getId());
    }
    return Optional.empty();
  }

  private boolean isValidPartialBundle(String orderCode, BundleDto originBundle,
      RefundRequestDto refundRequestDto) {
    boolean result = false;
    if (Objects.isNull(refundRequestDto.getBundle()) && Objects.nonNull(originBundle)) {
      log.warn("Partial refund: Bundle is empty, order code {}", orderCode);
      throw new ServiceException(ApplicationException.BUNDLE_EMPTY);
    }
    for (BundleItemRequestDto item : refundRequestDto.getBundle().getItems()) {
      final var calculatedAmount = item.getPrice().multiply(item.getQuantity())
          .setScale(2, RoundingMode.HALF_UP);
      final var itemAmount = item.getAmount().setScale(2, RoundingMode.HALF_UP);
      if (calculatedAmount.compareTo(itemAmount) != 0) {
        log.error("Bundle refund item amount not equals with calculated amount,"
            + " order code {}, refundId {}, paymentId {}",
            orderCode, refundRequestDto.getRefundId(), refundRequestDto.getPaymentId());
        throw new ValidationException();
      }
    }
    final var totalRequestRefundBundleAmount = getTotalBundleAmount(refundRequestDto.getBundle());
    final var refundAmount = BigDecimal.valueOf(refundRequestDto.getAmount()
        .getValue()).setScale(2, RoundingMode.HALF_UP);
    if (refundAmount.compareTo(totalRequestRefundBundleAmount) != 0) {
      log.error("Bundle's refund amount not equals with request amount, paymentId {}, refundId {}",
          refundRequestDto.getPaymentId(), refundRequestDto.getRefundId());
      throw new ValidationException();
    }

    final var totalOriginBundleAmount = getTotalBundleAmount(originBundle);
    final var refundBundles = bundleRefundService.getBundlesByOrderCode(orderCode);
    final var refundedBundleAmount = refundBundles.stream()
        .map(this::getTotalBundleAmount)
        .reduce(BigDecimal::add)
        .orElse(BigDecimal.ZERO)
        .setScale(2, RoundingMode.HALF_UP);

    final var subAmount = totalOriginBundleAmount.subtract(refundedBundleAmount);
    if (totalRequestRefundBundleAmount.compareTo(subAmount) <= 0) {
      log.info("Request refund with partial bundle can be processing");
      result = true;
    }
    return result;
  }

  private BigDecimal getTotalBundleAmount(BundleDto bundle) {
    return bundle.getItems().stream()
        .map(BundleItem::getAmount)
        .reduce(BigDecimal::add)
        .orElse(BigDecimal.ZERO)
        .setScale(2, RoundingMode.HALF_UP);
  }

  private BigDecimal getTotalBundleAmount(BundleRequestDto bundle) {
    return bundle.getItems().stream()
        .map(BundleItemRequestDto::getAmount)
        .reduce(BigDecimal::add)
        .orElse(BigDecimal.ZERO)
        .setScale(2, RoundingMode.HALF_UP);
  }

  private BundleRequestDto createDefaultBundle(MerchantSiteFiscalParams fiscalParams,
      AmountRequestDto amount) {
    final var defaultSettings = fiscalParams.getDefaultSettings();
    final var orderAmount = BigDecimal.valueOf(amount.getValue()).setScale(2, RoundingMode.HALF_UP);
    final var taxType = defaultSettings.getTaxRate();

    final var taxParamsDtoBuilder = TaxParamsDto.builder()
        .taxType(taxType);

    final var defaultBundle = BundleItemRequestDto.builder()
        .positionId(1)
        .paymentType(defaultSettings.getPaymentType())
        .paymentSubject(defaultSettings.getProductType())
        .amount(orderAmount)
        .name(Objects.requireNonNull(defaultSettings.getProductName(),
            () -> {
              throw new BundleValidationException(
                  ApplicationException.BUNDLE_DEFAULT_SETTINGS_ERROR);
            }))
        .price(orderAmount)
        .measure(UnitsMeasure.SINGLE_ITEM)
        .quantity(BigDecimal.ONE)
        .taxParams(taxParamsDtoBuilder.build())
        .build();
    return BundleRequestDto.builder()
        .fiscalInfo(FiscalInfoDto.builder()
            .clientEmail(fiscalParams.getEmail())
            .build())
        .items(Collections.singletonList(defaultBundle))
        .build();
  }

  public static boolean isActiveFiscal(MerchantSite mst) {
    return Objects.nonNull(mst.getParams().getFiscalParams())
        && mst.getParams().getFiscalParams().isActive();
  }

  private boolean bundleIsEmpty(OrderCreationRequestDto dto) {
    return Objects.isNull(dto.getBundle()) || dto.getBundle().getItems().isEmpty();
  }

  private void checkEmailAndSet(BundleRequestDto bundleReq, MerchantSite mst) {
    if (Objects.nonNull(bundleReq) && isEmptyFiscalEmail(bundleReq)) {
      bundleReq.setFiscalInfo(
          FiscalInfoDto.builder()
              .clientEmail(mst.getParams().getFiscalParams().getEmail())
              .build());
    }
  }

  private boolean isEmptyFiscalEmail(BundleRequestDto bundleReq) {
    return Objects.isNull(bundleReq.getFiscalInfo())
        || Strings.isEmpty(bundleReq.getFiscalInfo().getClientEmail());
  }
}
