package ru.vtb.tsp.ia.epay.apilistener.services.payment.transfer;

import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.IPaymentGateway;
import ru.vtb.tsp.ia.epay.core.domains.TransferRequest;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@Service
public class TransferGateway implements IPaymentGateway {

  @Override
  public GatewayType getGatewayType() {
    return GatewayType.TRANSFER;
  }

  @Override
  public Optional<Transaction> transfer(TransferRequest request) {
    return Optional.empty();
  }
}
