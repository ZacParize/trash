package ru.vtb.tsp.ia.epay.apilistener.services.payment;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;

public interface IStatusPayment {

  default Optional<String> status(String id) {
    throw new OperationNotSupported();
  }
}
