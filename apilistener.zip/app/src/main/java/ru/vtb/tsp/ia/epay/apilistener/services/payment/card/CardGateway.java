package ru.vtb.tsp.ia.epay.apilistener.services.payment.card;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.Card2StageCompleteRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.CardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType;
import ru.vtb.tsp.ia.epay.apilistener.services.payment.IPaymentGateway;
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest;
import ru.vtb.tsp.ia.epay.core.domains.RefundRequest;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;

@Slf4j
@Service
@RequiredArgsConstructor
public class CardGateway implements IPaymentGateway {

  private final ICardPayment cardPayment;
  private final ICardRefund cardRefund;

  @Override
  public GatewayType getGatewayType() {
    return GatewayType.CARD;
  }

  @Override
  public Optional<Transaction> pay(PaymentRequest request, MerchantSite mst) {
    if (request instanceof PaymentCardRequest paymentCardRequest) {
      return cardPayment.processPayment(paymentCardRequest, mst);
    } else {
      log.error("Card payment: Not support current request type {}", request.getClass());
      throw new OperationNotSupported();
    }
  }

  @Override
  public Optional<Transaction> pay(PaymentRequest request) {
    if (request instanceof CardPaymentRequestDto cardReq) {
      return cardPayment.processPayment(
          cardReq.getMstOrderCode(),
          cardReq.getAmount(),
          cardReq.getEmail(),
          cardReq.getEncryptedPan(),
          cardReq.getEncryptedCvv(),
          cardReq.getCardHolder(),
          cardReq.getExpiryDate());
    } else if (request instanceof Card2StageCompleteRequestDto completeReq) {
      return cardPayment.completeTwoStageCardPayment(
          completeReq.getMstId(),
          completeReq.getMstOrderId(),
          completeReq.getAmount());
    } else {
      log.error("Card payment: Not support current request type {}", request.getClass());
      throw new OperationNotSupported();
    }
  }

  @Override
  public Optional<Transaction> pay(Order order) {
    if (Objects.nonNull(order.getBindingCategory()) && Objects.nonNull(order.getBindingType())) {
      if (Objects.nonNull(order.getBindingCode())) {
        return cardPayment.processPayment(order);
      } else {
        return Optional.empty();
      }
    }
    log.error("COF payment: Not valid binding params in order code {}", order.getCode());
    throw new OperationNotSupported();
  }

  @Override
  public Optional<Transaction> refund(RefundRequest request, Transaction tx, MerchantSite mst) {
    if (request instanceof RefundRequestDto cardReq) {
      return cardRefund.registerRefund(tx, cardReq.getRefundId(), cardReq.getAmount());
    }
    log.error("Card refund: Not support current request type {}", request.getClass());
    throw new OperationNotSupported();
  }
}