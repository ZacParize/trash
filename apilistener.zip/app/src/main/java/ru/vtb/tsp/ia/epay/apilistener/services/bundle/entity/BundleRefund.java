package ru.vtb.tsp.ia.epay.apilistener.services.bundle.entity;

import static ru.vtb.tsp.ia.epay.apilistener.services.bundle.entity.BundleRefund.TABLE;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleItem;
import ru.vtb.tsp.ia.epay.core.domains.bundle.FiscalInfo;

@Table(TABLE)
@NoArgsConstructor
@AllArgsConstructor
@Data
@EqualsAndHashCode
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleRefund {

  public static final String TABLE = "bundle_refund";

  @Id
  @NotNull
  @JsonProperty("id")
  private UUID id;

  @Column("order_ref")
  @JsonProperty("orderRef")
  private UUID orderRef;

  @Column("transaction_ref")
  @JsonProperty("transactionRef")
  private UUID transactionRef;

  @Column("fiscal_info")
  @JsonProperty("fiscalInfo")
  private FiscalInfo fiscalInfo;

  @Column("items")
  @JsonProperty("items")
  private List<BundleItem> items;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @NotNull
  @Column("updated_at")
  @JsonProperty("updatedAt")
  private LocalDateTime updatedAt;

  @Version
  private int version = 0;
}
