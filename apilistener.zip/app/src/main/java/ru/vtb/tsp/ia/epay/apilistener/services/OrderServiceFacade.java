package ru.vtb.tsp.ia.epay.apilistener.services;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Function;
import java.util.function.Supplier;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.CustomerRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.AbstractTransferRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.A2cInternalTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.c2a.AccountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.c2a.C2aTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.PreAuthOrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentTypeRequest;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.IncorrectCustomerException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.services.CurrencyService;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerState;
import ru.vtb.tsp.ia.epay.customer.dtos.enums.CustomerType;
import ru.vtb.tsp.ia.epay.customer.dtos.requests.CustomerToMerchantRequestDto;
import ru.vtb.tsp.ia.epay.customer.dtos.responses.CustomerToMerchantResponseDto;
import ru.vtb.tsp.ia.epay.customer.implementations.CustomerToMerchantClientImpl;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

@Slf4j
@Service
public class OrderServiceFacade {

  private static final Supplier<String> MERCHANT_SETTINGS_ERROR = () -> {
    throw new ServiceException(ApplicationException.MERCHANT_SETTINGS_ERROR);
  };
  private static final long TIMEOUT_IN_MILLIS = 10000;
  private final OrderService orderService;
  private final CurrencyService currencyService;
  private final ValidationService validationService;
  private final Function<Order, Order> logIfOrderExpired;
  private final CustomerToMerchantClientImpl customerService;
  private final BundleServiceFacade bundleServiceFacade;
  private final boolean cofToggle;

  public OrderServiceFacade(@NotNull OrderService orderService,
      @NotNull CurrencyService currencyService,
      @NotNull ValidationService validationService,
      @NotNull CustomerToMerchantClientImpl customerService,
      @NotNull BundleServiceFacade bundleServiceFacade,
      @Value("${toggle.cof}") Boolean cofToggle) {
    this.orderService = orderService;
    this.currencyService = currencyService;
    this.validationService = validationService;
    this.logIfOrderExpired = order -> {
      if (!order.isTransfer() && this.validationService.isOrderExpired(order)) {
        log.info("Order {} was expired", order.getOrderId());
      }
      return order;
    };
    this.customerService = customerService;
    this.bundleServiceFacade = bundleServiceFacade;
    this.cofToggle = cofToggle;
  }

  public @NotNull Optional<Order> getById(@Nullable String orderId) {
    return orderService.getById(orderId).map(logIfOrderExpired);
  }

  public @NotNull Optional<Order> getByMstOrderId(@Nullable String mstId,
      @Nullable String mstOrderId) {
    return orderService.getByMstOrderId(mstId, mstOrderId).map(logIfOrderExpired);
  }

  public @NotNull Optional<Order> getByCode(@Nullable String code) {
    return orderService.getByCode(code).map(logIfOrderExpired);
  }

  @Transactional
  public @NotNull Optional<Order> upsert(@Nullable Order order) {
    if (Objects.isNull(order)) {
      return Optional.empty();
    }
    try {
      return orderService.upsert(order)
          .map(newOrder -> {
            log.info("Order {} was inserted/updated", newOrder.getOrderId());
            return newOrder;
          });
    } catch (Exception ex) {
      log.error("Order {} was not inserted/updated", order.getOrderId(), ex);
      throw new OperationNotSupported(ex.getCause().getMessage());
    }
  }

  private CustomerToMerchantResponseDto getCustomerAsync(
      @NotNull CustomerRequestDto dto,
      @NotNull String merchantId,
      @NotNull String mstId) {
    if (Objects.isNull(dto)) {
      return null;
    }
    try {
      return CompletableFuture.supplyAsync(() ->
              customerService.upsertAndGet(
                  CustomerToMerchantRequestDto.builder()
                      .merchantId(mstId)
                      .mstCustomerId(dto.getCustomerId())
                      .mstId(merchantId)
                      .customer(ru.vtb.tsp.ia.epay.customer.dtos.requests
                          .CustomerRequestDto.builder()
                          .state(CustomerState.ACTIVE)
                          .type(CustomerType.GLOBAL)
                          .phone(dto.getPhone())
                          .email(dto.getEmail())
                          .build())
                      .build()))
          .get(TIMEOUT_IN_MILLIS, TimeUnit.MILLISECONDS);
    } catch (InterruptedException | ExecutionException | TimeoutException ex) {
      throw new InternalException(ex.getMessage());
    }
  }


  public @NotNull Optional<Order> createA2c(
      @Nullable A2cInternalTransferRequestDto requestDto,
      @Nullable MerchantSite mst) {
    if (Objects.isNull(mst)) {
      return Optional.empty();
    }
    return Optional.ofNullable(requestDto)
        .flatMap(req -> create(req.getOrderId(),
            mst,
            Optional.ofNullable(req.getAmount()).map(AmountRequestDto::getCode).orElse(null),
            Optional.ofNullable(req.getAmount()).map(AmountRequestDto::getValue).orElse(null),
            0d,
            null,
            null,
            OrderType.TRANSFER,
            null,
            req.getDescription(),
            req.getDescription(),
            null,
            null,
            null,
            req.getSourceSystem(),
            null,
            null,
            null,
            null));
  }

  @Deprecated
  public Optional<Order> create(@Nullable AbstractTransferRequest<?> transferRequest,
      @Nullable MerchantSite mst) {
    String returnUrl = null;
    String account = null;
    String bic = null;
    if (transferRequest instanceof C2aTransferRequestDto) {
      returnUrl = ((C2aTransferRequestDto) transferRequest).getReturnUrl();
      account = ((AccountRequestDto) transferRequest.getDestination().getPaymentData()
          .getObject()).getAccount();
      bic = ((AccountRequestDto) transferRequest.getDestination().getPaymentData().getObject())
          .getBic();
    }
    SourceSystem sourceSystem = SourceSystem.ECOM;
    /*if (transferRequest.getClass().equals(A2cInternalTransferRequestDto.class)) {
      sourceSystem = ((A2cInternalTransferRequestDto) transferRequest).getSourceSystem();
    }*/
    return create(Optional.ofNullable(transferRequest).map(AbstractTransferRequest::getOrderId)
            .orElse(null),
        mst,
        Optional.ofNullable(transferRequest).map(AbstractTransferRequest::getAmount)
            .map(AmountRequestDto::getCode).orElse(null),
        Optional.ofNullable(transferRequest).map(AbstractTransferRequest::getAmount)
            .map(AmountRequestDto::getValue).orElse(null),
        0d,
        null,
        null,
        OrderType.TRANSFER,
        null,
        Optional.ofNullable(transferRequest).map(AbstractTransferRequest::getDescription)
            .orElse(null),
        Optional.ofNullable(transferRequest).map(AbstractTransferRequest::getDescription)
            .orElse(null),
        returnUrl,
        account,
        bic,
        sourceSystem,
        null,
        null,
        null,
        null
    );
  }


  @Transactional
  public @NotNull Optional<Order> create(@Nullable String mstOrderId,
      @Nullable MerchantSite mst,
      @Nullable String currencyCode,
      @Nullable Double amount,
      @Nullable Double amountHold,
      @Nullable LocalDateTime authorizedAt,
      @Nullable LocalDateTime expireAt,
      @Nullable OrderType orderType,
      @Nullable PaymentTypeRequest paymentData,
      @Nullable String name,
      @Nullable String description,
      @Nullable String returnUrl,
      @Nullable String account,
      @Nullable String bic,
      @Nullable SourceSystem sourceSystem,
      @Nullable String mstCustomerId,
      @Nullable BindingType bindingType,
      @Nullable BindingCategory operationType,
      @Nullable UUID bindingId) {
    if (Objects.isNull(mstOrderId) || Objects.isNull(mst) || Objects.isNull(currencyCode)
        || Objects.isNull(amount) || Objects.isNull(orderType) || Objects.isNull(name)) {
      return Optional.empty();
    }
    if (OrderType.PAYMENT.equals(orderType) && Objects.nonNull(expireAt)
        && LocalDateTime.now(ZoneOffset.UTC).isAfter(expireAt)) {
      log.error("Incorrect expire date {} of order {}", expireAt, mstOrderId);
      throw new OperationNotSupported();
    }
    if (PaymentTypeRequest.SBP.equals(paymentData) && !mst.isEnableSbpPayment()) {
      log.error("SBP payment for merchant site {} is not available", mst.getId());
      throw new OperationNotSupported();
    }
    final var existedOrder = getByMstOrderId(mst.getId(), mstOrderId);
    if (existedOrder.isPresent()) {
      log.error("Order of mst {} with order id {} already exists", mst.getId(), mstOrderId);
      return existedOrder;
    }
    final var currency = currencyService.getById(currencyCode)
        .orElseThrow(() -> {
          log.error("Incorrect currency code {}", currencyCode);
          return new OperationNotSupported();
        });
    if (Objects.nonNull(amountHold) && amount.compareTo(amountHold) < 0) {
      log.error("Incorrect amount hold {} for order {}", amountHold, mstOrderId);
      throw new OperationNotSupported();
    }
    log.info("Received mst id {} creation {} {}", mst.getId(), orderType.getValue(), mstOrderId);
    //TODO: refactor - concurrency problem
    final var createdAt = LocalDateTime.now(ZoneOffset.UTC);
    final var result = orderService.create(
            currency,
            mst,
            mstOrderId,
            amount,
            amountHold,
            createdAt,
            authorizedAt,
            getExpired(mst, createdAt, expireAt, orderType),
            orderType,
            name,
            description,
            returnUrl,
            account,
            bic,
            sourceSystem,
            operationType,
            bindingType,
            bindingId,
            mstCustomerId)
        .flatMap(this::upsert);
    result.ifPresent(order -> log.info("Created {} id {}", orderType.getValue(),
        order.getOrderId()));
    return result;
  }

  @Transactional
  public @NotNull Optional<Order> create(@Nullable OrderCreationRequestDto dto,
      @Nullable MerchantSite mst,
      @Nullable SourceSystem sourceSystem) {
    if (Objects.isNull(dto) || Objects.isNull(mst)) {
      return Optional.empty();
    }
    var mstCustomerId = Optional.ofNullable(dto.getCustomer())
        .map(CustomerRequestDto::getCustomerId)
        .orElse(null);
    BindingType bindingType = null;
    BindingCategory bindingCategory = null;
    UUID bindingId = null;

    // TODO: remove toggle
    if (cofToggle) {
      if (Objects.nonNull(dto.getBinding())) {
        bindingType = dto.getBinding().getBindingType();
        bindingCategory = dto.getBinding().getOperationType();
        bindingId = dto.getBinding().getBindingId();
        if (Objects.nonNull(bindingType) && Objects.nonNull(bindingCategory)) {
          // card payment should be enabled for cof
          if (!mst.isEnableCardPayment()) {
            log.error("Merchant site {} hasn't access to card payments", mst.getId());
            throw new InternalException();
          }
          // terminal id should be marked for cof
          if (ObjectUtils.isEmpty(mst.getTerminalId())) {
            log.error("Merchant site {} hasn't terminal id", mst.getId());
            throw new InternalException();
          }
          // customer must be if we have bindingType, operationType
          if (Objects.isNull(dto.getCustomer())
              || Objects.isNull(dto.getCustomer().getCustomerId())
              || Objects.isNull(dto.getCustomer().getEmail())) {
            throw new IncorrectCustomerException();
          }
        }
      }
      if (Objects.nonNull(dto.getCustomer())
          && Objects.nonNull(dto.getCustomer().getEmail())
          && Objects.nonNull(mstCustomerId)) {
        mstCustomerId = getCustomerAsync(dto.getCustomer(), mst.getMerchant().getId(),
            mst.getId()).getMstCustomerId();
      }
    }

    final var order = create(dto.getOrderId(),
        mst,
        Optional.ofNullable(dto.getAmount()).map(AmountRequestDto::getCode).orElse(null),
        Optional.ofNullable(dto.getAmount()).map(AmountRequestDto::getValue).orElse(null),
        0d,
        null,
        dto.getExpire(),
        OrderType.PAYMENT,
        dto.getReturnPaymentData(),
        dto.getOrderName(),
        dto.getOrderName(),
        dto.getReturnUrl(),
        null,
        null,
        sourceSystem,
        mstCustomerId,
        bindingType,
        bindingCategory,
        bindingId);

    order.ifPresent(o -> bundleServiceFacade.createBundle(UUID.fromString(o.getCode()), dto, mst));
    return order;
  }

  public @NotNull Optional<Order> create(@Nullable PreAuthOrderCreationRequestDto dto,
      @Nullable MerchantSite mst,
      @Nullable SourceSystem sourceSystem) {
    if (Objects.isNull(dto) || Objects.isNull(mst)) {
      return Optional.empty();
    }
    var mstCustomerId = Optional.ofNullable(dto.getCustomer())
        .map(CustomerRequestDto::getCustomerId)
        .orElse(null);
    if (Objects.nonNull(dto.getCustomer()) && Objects.nonNull(dto.getCustomer().getCustomerId())
        && ObjectUtils.isEmpty(dto.getCustomer().getEmail())) {
      mstCustomerId = getCustomerAsync(dto.getCustomer(), mst.getMerchant().getId(),
          mst.getId()).getMstCustomerId();
    }
    return create(dto.getOrderId(),
        mst,
        Optional.ofNullable(dto.getAmount())
            .map(AmountRequestDto::getCode).orElse(null),
        Optional.ofNullable(dto.getAmount())
            .map(AmountRequestDto::getValue).orElse(null),
        Optional.ofNullable(dto.getAmount())
            .map(AmountRequestDto::getValue).orElse(null),
        LocalDateTime.now(ZoneOffset.UTC),
        dto.getExpire(),
        OrderType.TWO_STAGE,
        null,
        dto.getOrderName(),
        dto.getOrderName(),
        dto.getReturnUrl(),
        null,
        null,
        sourceSystem,
        mstCustomerId,
        null,
        null,
        null);
  }

  public Optional<Order> lockByMstOrderId(@Nullable String mstId, @Nullable String mstOrderId) {
    return orderService.lockByMstOrderId(mstId, mstOrderId);
  }

  private LocalDateTime getExpired(MerchantSite mst, LocalDateTime createdAt,
      LocalDateTime expireAt, OrderType orderType) {
    if (!OrderType.isTransfer(orderType)) {
      return Objects.nonNull(expireAt) ? expireAt :
          createdAt.plus(Objects.requireNonNull(mst.getParams().getOrderLifeTime(),
              MERCHANT_SETTINGS_ERROR));
    } else {
      return null;
    }
  }
}