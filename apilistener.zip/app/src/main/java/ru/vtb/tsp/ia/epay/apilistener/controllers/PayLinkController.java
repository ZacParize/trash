package ru.vtb.tsp.ia.epay.apilistener.controllers;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.TwoStagePaymentRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.orders.PayLinkOrderObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.RefundObjectResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.TransactionResponseDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService;
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade;
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService;
import ru.vtb.tsp.ia.epay.apilistener.services.ResponseService;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.OrderCounterMetric;
import ru.vtb.tsp.ia.epay.apilistener.services.monitoring.SbpQrCounterMetric;
import ru.vtb.tsp.ia.epay.apilistener.utils.ConverterUtils;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;

@Slf4j
@RestController
@Validated
@RequiredArgsConstructor
public class PayLinkController {

  public static final String PAYLINK = "/paylink";
  public static final String PAYLINK_ORDERS_PATH = PAYLINK + "/orders";
  public static final String PAYLINK_REFUNDS_PATH = PAYLINK + "/refunds";
  private static final String ORDER_ID_PATH_VARIABLE = "orderId";
  private static final String POST_PAYMENTS_COMPLETE_PATH = PAYLINK + "/orders/complete/{"
      + ORDER_ID_PATH_VARIABLE + "}";

  private final OrderServiceFacade orderServiceFacade;
  private final KafkaService kafkaService;
  private final ResponseService responseService;
  private final PaymentService paymentService;
  private final MerchantController merchantController;

  @AuditProcess("TSPACQ_BOX_PAYLINK_CREATE_ORDER")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = PayLinkOrderObjectResponseDto.class))
  })
  @PostMapping(path = "${app.api.prefix}" + PAYLINK_ORDERS_PATH,
      produces = APPLICATION_JSON_VALUE)
  @SbpQrCounterMetric
  @OrderCounterMetric
  public @NotNull ResponseEntity<?> createOrder(
      @RequestBody @NotNull @Valid OrderCreationRequestDto request) {
    log.info("Received create order request {}", request);
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    if (Objects.equals(request.getSourceSystem(), SourceSystem.ECOM)) {
      throw new OperationNotSupported();
    }
    final var order = orderServiceFacade.getByMstOrderId(mst.getId(), request.getOrderId())
        .orElseGet(() -> orderServiceFacade.create(request, mst,
                Objects.requireNonNullElse(request.getSourceSystem(), SourceSystem.IBLK))
            .map(ord -> {
              kafkaService.sendOrderToPortal(ord);
              return ord;
            })
            .orElseThrow(() -> new ValidationException("Can't create order " + request)));
    return ResponseEntity.ok(
        responseService.toOrderResponse(order, request.getReturnPaymentData()));
  }

  @AuditProcess("TSPACQ_BOX_PAYLINK_GET_ORDER")
  @GetMapping(path = "${app.api.prefix}" + PAYLINK_ORDERS_PATH + "/{orderId}",
      produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> getPayLinkOrder(
      @PathVariable("orderId") String orderId) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received get order PayLink request id {} from merchant site id {}", orderId,
        mst.getId());
    return orderServiceFacade.getByMstOrderId(mst.getId(), orderId)
        .map(order ->
            ResponseEntity.<Serializable>ok(responseService.toOrderResponse(order, null)))
        .orElseThrow(() -> new ValidationException("Incorrect order id " + orderId));
  }

  @AuditProcess("TSPACQ_BOX_PAYLINK_GET_REFUND")
  @GetMapping(path = "${app.api.prefix}"
      + PAYLINK_REFUNDS_PATH + "/{refundId}", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> getPayLinkRefund(@PathVariable("refundId") String refundId) {
    final var mstId = ((MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal()).getId();
    log.info("Received get refund PayLink request id {} from merchant site id {}", refundId, mstId);
    return responseService.toRefundResponse(mstId, refundId);
  }

  @AuditProcess("TSPACQ_BOX_PAYLINK_CREATE_REFUND")
  @PostMapping(path = "${app.api.prefix}"
      + PAYLINK_REFUNDS_PATH, produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = RefundObjectResponseDto.class))
  })
  public @NotNull ResponseEntity<?> createRefund(
      @RequestBody @NotNull @Valid RefundRequestDto refundRequestDto) {
    log.info("Received create refund paylink request {}", refundRequestDto);
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    refundRequestDto.setRefundId(UUID.randomUUID().toString());
    return paymentService.registerRefund(refundRequestDto, mst)
        .map(txn -> ResponseEntity.<Serializable>ok(ConverterUtils.convertToRefundResponse(txn)))
        .orElseThrow(
            () -> new ValidationException(
                "Can't create paylink refund " + refundRequestDto));
  }

  @AuditProcess("TSPACQ_BOX_PAYLINK_CANCEL_ORDER")
  @PostMapping(path = "${app.api.prefix}" + PAYLINK_ORDERS_PATH + "/{orderId}/cancel",
      produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<?> cancelOrder(
      @PathVariable(ORDER_ID_PATH_VARIABLE) String mstOrderId) {
    final var mst = (MerchantSite) SecurityContextHolder.getContext().getAuthentication()
        .getPrincipal();
    log.info("Received cancel order PayLink request id {} from merchant site id {}", mstOrderId,
        mst.getId());
    final var order = paymentService.cancelOrderFromLK(mst.getId(), mstOrderId)
        .map(o -> {
          kafkaService.sendOrderToPortal(o);
          return o;
        })
        .orElseThrow(() -> new ValidationException("Incorrect mst order id " + mstOrderId));
    return ResponseEntity.<Serializable>ok(responseService.toOrderResponse(order, null));
  }

  @PostMapping(path = "${app.api.prefix}" + POST_PAYMENTS_COMPLETE_PATH,
      produces = APPLICATION_JSON_VALUE)
  @ApiResponse(responseCode = "200", content = {
      @Content(mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TransactionResponseDto.class))
  })
  public @NotNull ResponseEntity<?> completeTwoStageCardPayment(
      @NotBlank @Size(min = 1, max = 64) @PathVariable(ORDER_ID_PATH_VARIABLE) String mstOrderId,
      @RequestBody @NotNull @Valid TwoStagePaymentRequest request) {
    return merchantController.completeTwoStageCardPayment(mstOrderId, request);
  }
}