package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported;
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionInfoService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;

@Slf4j
@Service
public class SbpRefundService implements ISbpRefund {

  private final TransactionService transactionService;
  private final TransactionInfoService transactionInfoService;
  private final OrderService orderService;
  private final PaymentVerifier paymentVerifier;

  public SbpRefundService(
      @NotNull TransactionService transactionService,
      @NotNull TransactionInfoService transactionInfoService,
      @NotNull OrderService orderService,
      @NotNull PaymentVerifier paymentVerifier) {
    this.transactionService = transactionService;
    this.transactionInfoService = transactionInfoService;
    this.orderService = orderService;
    this.paymentVerifier = paymentVerifier;
  }

  @Override
  @Transactional
  public Optional<Transaction> registerRefund(@NotNull RefundRequestDto requestDto,
                                              @Nullable Transaction transaction,
                                              @Nullable String mstId) {
    final var refundId = requestDto.getRefundId();
    final var amount = Optional.ofNullable(requestDto.getAmount()).map(AmountRequestDto::getValue)
        .orElse(null);

    if (Objects.isNull(transaction) || Objects.isNull(amount)) {
      return Optional.empty();
    }
    final var currency = transaction.getCurrency();

    // mst of transaction is the same as mst of order and the same as mst of refund
    paymentVerifier.checkTransactionHasSameMerchantSiteId(transaction, mstId)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.TRANSACTION_NOT_FOUND);
    // parent transaction was payed by sbp
    paymentVerifier.checkTransactionIsSbpPayed(transaction)
        .ifCheckFailedLogAndThrowServiceException(
            ApplicationException.INCORRECT_PARENT_TRANSACTION
        );
    final var order = transaction.getOrder();
    // order is not refunded
    paymentVerifier.checkOrderNotRefunded(transaction)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.ORDER_REFUNDED_ERROR);
    // order is not expired
    paymentVerifier.checkOrderIsNotExpired(order)
        .ifCheckFailedLogAndThrow(OperationNotSupported::new);
    // order has the same currency
    paymentVerifier.checkOrderHasSameCurrency(order, currency)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.CURRENCY_IS_NOT_ALLOWED);
    // transaction has the same currency
    paymentVerifier.checkTransactionHasSameCurrency(transaction, currency)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.CURRENCY_IS_NOT_ALLOWED);
    final var orderTransactions = transactionService
        .getByOrderId(order.getOrderId());
    final var remainingRefundAmount = order
        .calculateRemainingRefundAmount(orderTransactions);
    // check refund amount
    paymentVerifier.checkRefundAmount(amount, remainingRefundAmount)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
    paymentVerifier.checkRefundAmountForPaymentTransaction(transaction, amount)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.INCORRECT_AMOUNT);
    // mst settings allow to make partial refund
    paymentVerifier.checkAccessSbpPartialRefund(order, amount, remainingRefundAmount)
        .ifCheckFailedLogAndThrowServiceException(
            ApplicationException.PARTIAL_REFUND_NOT_SUPPORTED
        );
    // order has no transactions which are in processing
    paymentVerifier.checkOrderProcessingTransaction(order, orderTransactions)
        .ifCheckFailedLogAndThrowServiceException(ApplicationException.IN_PROCESS);
    return transactionService.createSbpRefund(transaction.getOrder(),
            amount,
            currency,
            refundId)
        .map(newTx -> {
          final Sbp oldPaymentData = (Sbp) transaction.getData().getPaymentData();
          final Sbp newPaymentData = (Sbp) newTx.getData().getPaymentData();
          newPaymentData.setOperationId(oldPaymentData.getOperationId());
          newPaymentData.setPrtry(oldPaymentData.getPrtry());
          transaction.getData().getContext().put("transactionId", transaction.getTransactionId());
          transaction.getData().getContext().put("code", transaction.getCode());
          transaction.getData().getContext()
              .put("mstTransactionId", transaction.getMstTransactionId());
          transaction.getData().getContext()
              .put("transactionType", transaction.getType().getValue());
          transaction.getData().getContext()
              .put("transactionState", transaction.getState().getValue());
          newTx.getData().setOriginContext(transaction.getData().getContext());
          return transactionService.upsert(newTx);
        })
        .orElseThrow(InternalException::new);
  }

  @Override
  @Transactional
  public Optional<Transaction> processCompleteRefund(
      @Nullable SbpRefundStatusResponseDto response) {
    return Optional.ofNullable(response)
        .flatMap(res -> transactionInfoService.getByMsgId(res.getMsgId()))
        .flatMap(tx -> transactionService.lockById(tx.getTransactionId()))
        .filter(tx -> !tx.isCompleted())
        .flatMap(tx -> {
          if (Qstate.ACWP.equals(response.getTxSts()) || Qstate.OK.equals(response.getTxSts())) {
            return processSuccessRefund(tx);
          } else {
            return processErrorRefund(response, tx);
          }
        });
  }

  @Override
  @Transactional
  public Optional<Transaction> processConfirmRefund(
      @Nullable SbpConfirmRefundCallbackDto request) {
    return Optional.ofNullable(request)
        .flatMap(req -> {
          if (Qstate.RCVD.equals(request.getTxSts())) {
            return transactionInfoService.getByMsgId(req.getMsgId())
                .filter(tx -> !tx.isCompleted());
          } else {
            return transactionInfoService.getByMsgId(req.getMsgId())
                .flatMap(tx -> transactionService.lockById(tx.getTransactionId()))
                .filter(tx -> !tx.isCompleted())
                .map(tx -> {
                  processErrorRefund(SbpRefundStatusResponseDto.builder()
                      .msgId(req.getMsgId())
                      .prtry(req.getPrtry())
                      .txSts(req.getTxSts())
                      .addtlInf(req.getAddtlInf())
                      .build(), tx);
                  log.info("Transaction id {} is not refunded by SBP", tx.getTransactionId());
                  return tx;
                });
          }
        });
  }

  private Optional<Transaction> processSuccessRefund(Transaction transaction) {
    return Optional.ofNullable(transaction)
        .filter(tx -> !tx.isCompleted())
        .flatMap(tx -> transactionService.upsert(tx.withState(TransactionState.RECONCILED)))
        .map(tx -> {
          log.info("Transaction id {} is refunded by SBP", tx.getTransactionId());
          final var isFullRefund = Order.calculateRefundedAmount(
              transactionService.getByOrderId(tx.getOrder().getOrderId()),
              Collections.singletonList(tx)) + tx.getAmount() >= tx.getOrder().getAmount();
          orderService.upsert(tx.getOrder()
              .withState(isFullRefund ? OrderState.REFUNDED : OrderState.PARTIALLY_REFUNDED));
          log.info("Order id {} refunded by SBP", tx.getOrder().getOrderId());
          return transactionService.getById(tx.getTransactionId()).orElseThrow();
        });
  }

  private Optional<Transaction> processErrorRefund(SbpRefundStatusResponseDto requestDto,
                                                   Transaction transaction) {
    if (ObjectUtils.isEmpty(requestDto.getPrtry())) {
      return Optional.empty();
    }
    transaction.getData().setError(TransactionError.builder()
        .id(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getId())
        .httpCode(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getHttpCode())
        .message(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getMessage())
        .description(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getDescription())
        .traceId(transaction.getCode())
        .build());
    return transactionService.upsert(transaction.withState(TransactionState.DECLINED))
        .map(utx -> {
          log.info("Transaction id {} is not refunded by SBP", utx.getTransactionId());
          return utx;
        });
  }
}