package ru.vtb.tsp.ia.epay.apilistener.services;

import java.util.Objects;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.omni.audit.validation.service.AuditObjectValidator;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.CardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;

@Service
@RequiredArgsConstructor
public class ValidationService {

  private final AuditObjectValidator auditObjectValidator;

  @AuditProcess("TSPACQ_BOX_PAYMENT_VALIDATION")
  public void validatePaymentRequestDto(String mstOrderId, Object dto) {
    try {
      auditObjectValidator.validate(dto);
      final var expireDate = ((CardPaymentRequestDto) dto).getExpiryDate();
      if (Objects.equals(4, StringUtils.length(expireDate))) {
        final var month = expireDate.substring(0, 2);
        final var year = expireDate.substring(expireDate.length() - 2);
        if ((Integer.parseInt(month) < 1) || (Integer.parseInt(month) > 12)) {
          throw new ValidationException();
        }
      } else {
        throw new ValidationException();
      }
    } catch (Exception ex) {
      throw new ValidationException(ex.getMessage());
    }
  }

  @AuditProcess("TSPACQ_BOX_ORDER_LIFETIME_OUT")
  public boolean isOrderExpired(@Nullable Order order) {
    return Objects.nonNull(order) && order.isExpired();
  }
}
