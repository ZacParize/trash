package ru.vtb.tsp.ia.epay.apilistener.services.fiscalization;

import java.util.UUID;
import java.util.stream.Collectors;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.MerchantReceiptStatusDto;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OrderNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ReceiptsNotFoundException;
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade;
import ru.vtb.tsp.ia.epay.apilistener.services.clients.fiscalization.FiscalizationApi;
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.ReceiptStatusMapper;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;

@Service
@Slf4j
@RequiredArgsConstructor
public class ReceiptsServiceImpl implements ReceiptsService {

  private final OrderServiceFacade orderServiceFacade;
  private final FiscalizationApi fiscalizationApi;
  private final ReceiptStatusMapper receiptStatusMapper;


  public MerchantReceiptStatusDto getReceiptStatus(MerchantSite mst, @NotNull String mstOrderId) {
    return orderServiceFacade.getByMstOrderId(mst.getId(), mstOrderId)
        .map(o -> {
          final var response = fiscalizationApi.getStatus(UUID.fromString(o.getCode()));
          if (response.getStatusCode().is2xxSuccessful()) {
            if (!CollectionUtils.isEmpty(response.getBody())) {
              return MerchantReceiptStatusDto.builder()
                  .orderId(mstOrderId)
                  .orderCode(UUID.fromString(o.getCode()))
                  .receipts(response.getBody()
                      .stream()
                      .map(receiptStatusMapper::toEntity).collect(Collectors.toList()))
                  .build();
            }
          }
          throw new ReceiptsNotFoundException();
        }).orElseThrow(OrderNotFoundException::new);
  }
}
