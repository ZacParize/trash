package ru.vtb.tsp.ia.epay.apilistener.services.clients.key.cvv;

import java.util.UUID;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.apilistener.services.PublicKeyDto;

@Slf4j
@Component
@ConditionalOnProperty(name = "app.public-key.cvv-mock", havingValue = "true")
public class MockCvvKeyApiClient implements CvvKeyApi {

  private static final String CVV_KEY = UUID.randomUUID().toString();
  private static final PublicKeyDto PUBLIC_KEY = new PublicKeyDto(CVV_KEY);

  @Override
  public ResponseEntity<PublicKeyDto> getKey(HttpHeaders httpHeaders) {
    log.info("Tokenization mock get cvv key {}", CVV_KEY);
    return ResponseEntity.ok(PUBLIC_KEY);
  }
}