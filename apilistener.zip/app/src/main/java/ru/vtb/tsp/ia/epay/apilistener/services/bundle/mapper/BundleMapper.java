package ru.vtb.tsp.ia.epay.apilistener.services.bundle.mapper;

import org.mapstruct.Mapper;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.entity.Bundle;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Mapper(componentModel = "spring")
public interface BundleMapper {

  BundleDto fromEntity(Bundle entity);

  Bundle requestDtoToEntity(BundleRequestDto requestDto);

}
