package ru.vtb.tsp.ia.epay.apilistener.services;

import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PublicKeyDto implements Serializable {

  String publicKey;

}