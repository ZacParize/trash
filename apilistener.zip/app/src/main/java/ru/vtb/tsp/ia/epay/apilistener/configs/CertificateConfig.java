package ru.vtb.tsp.ia.epay.apilistener.configs;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class CertificateConfig {

  /**
   * SK.APPREG.1 - приватный ключ ТСП (SK.MERCH_ID.1) / он же приватный ключ Агрегатора.
   */
  @Bean
  public PrivateKey appregPrivateKey(MirPayConfig mirPayConfig)
      throws InvalidKeySpecException, NoSuchAlgorithmException {
    return mirPayConfig.getCertFromFile()
        ? getRSAPrivateKeyFromFile(mirPayConfig.getAppregPrivateKeyPath())
        : getRSAPrivateKey(mirPayConfig.getAppregPrivateKey());
  }

  /**
   * PK.NSPK.1 - сертификат X.509 в Base64 публичного ключа НСПК / он же Cертификат промежуточного
   * Удостоверяющего центра Агрегатора (Concentrator SubCA).
   */
  @Bean
  public String nspkCertificateInBase64(MirPayConfig mirPayConfig) {
    return mirPayConfig.getCertFromFile()
        ? getContent(mirPayConfig.getNspkCertificatePath())
        : mirPayConfig.getNspkCertificate();
  }

  /**
   * PK.NSPK.1 - сертификат X.509 в Base64 публичного ключа НСПК / он же Cертификат промежуточного
   * Удостоверяющего центра Агрегатора (Concentrator SubCA).
   */
  @Bean
  public X509Certificate nspkCertificate(String nspkCertificateInBase64)
      throws IOException, CertificateException {
    byte[] content = Base64.getDecoder().decode(nspkCertificateInBase64);
    try (ByteArrayInputStream bis = new ByteArrayInputStream(content)) {
      CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
      return (X509Certificate) certificateFactory.generateCertificate(bis);
    }
  }

  /**
   * Публичный ключ НСПК [PK.NSPK.1].
   */
  @Bean
  public RSAPublicKey nspkPublicKey(X509Certificate nspkCertificate) {
    return (RSAPublicKey) nspkCertificate.getPublicKey();
  }

  /**
   * Серийный номер сертификата X.509 НСПК [PK.NSPK.1], число в hex формате.
   */
  @Bean
  public String nspkCertificateSerialNumber(X509Certificate nspkCertificate) {
    return nspkCertificate.getSerialNumber().toString(16);
  }


  private PrivateKey getRSAPrivateKeyFromFile(String pathToFile)
      throws InvalidKeySpecException, NoSuchAlgorithmException {
    return getRSAPrivateKey(getContent(pathToFile));
  }

  private PrivateKey getRSAPrivateKey(String base64Content)
      throws InvalidKeySpecException, NoSuchAlgorithmException {
    final var content = Base64.getDecoder().decode(base64Content);
    final var keyFactory = KeyFactory.getInstance("RSA");
    final var privateKeySpec = new PKCS8EncodedKeySpec(content);
    return keyFactory.generatePrivate(privateKeySpec);
  }

  private String getContent(String pathToFile) {
    log.info("Mir Pay: try to load content from file '{}'", pathToFile);
    try (var lines = Files.lines(Path.of(pathToFile))) {
      return lines.filter(line -> !line.startsWith("-----BEGIN") && !line.startsWith("-----END"))
          .collect(Collectors.joining());
    } catch (IOException ex) {
      log.error("Mir Pay: error occurred during file '{}' loading", pathToFile, ex);
      throw new ApplicationContextException("Error occurred during file loading", ex);
    }
  }
}
