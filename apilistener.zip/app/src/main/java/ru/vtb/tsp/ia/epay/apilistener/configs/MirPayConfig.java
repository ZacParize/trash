package ru.vtb.tsp.ia.epay.apilistener.configs;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@NoArgsConstructor
@AllArgsConstructor
@ConfigurationProperties("mirpay")
public class MirPayConfig {

  /**
   * Префикс ендпоинта для перехода с пейформы на MIR PAY.
   */
  private String universalLinkUrlPrefix;

  /**
   * Префикс ендпоинта, где размещает данные о конечных сертификатах ТСП, поддерживающих технологию.
   * Web-based In-Application.
   */
  private String jwksUrlPrefix;

  /**
   * Хост куда прийдет call Back Payment data preparation Result Service API.
   */
  private String callBackHost;

  /**
   * Время истечения жизни токена.
   */
  private Long tokenExpirationDuration;

  /**
   * Время проверки трензакции MIR PAY с момента ее создания.
   */
  private Long declineCheckDelay;

  /**
   * TRUE - загрузка сертификатов из файлов, FALSE - из параметров.
   */
  private Boolean certFromFile;

  /**
   * Приватный ключ [SK.APPREG.1], сгенерированный для регистрации в сервисе In-Application.
   */
  private String appregPrivateKeyPath;

  /**
   * Сертификат публичного ключа НСПК [PK.NSPK.1], он же сертификат промежуточного Удостоверяющего
   * центра Агрегатора (Concentrator SubCA).
   */
  private String nspkCertificatePath;

  private String appregPrivateKey;

  private String nspkCertificate;

}
