package ru.vtb.tsp.ia.epay.apilistener.services.clients.key.pan;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Profile;

@Profile("!local")
@FeignClient(name = "panKeyApiClient", url = "${app.public-key.url}", decode404 = true)
public interface PanKeyApiClient extends PanKeyApi {
}