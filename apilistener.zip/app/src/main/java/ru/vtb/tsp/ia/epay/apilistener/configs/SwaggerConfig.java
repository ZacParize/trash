package ru.vtb.tsp.ia.epay.apilistener.configs;

import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.media.StringSchema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.security.SecurityScheme.Type;
import org.springdoc.core.customizers.OperationCustomizer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.ia.epay.apilistener.filters.JwtTokenFilter;

@Configuration
@ConditionalOnExpression("${springdoc.swagger-ui.enabled:true}")
public class SwaggerConfig {

  @Value("${swagger.header-token:#{null}}")
  private String headerToken;

  @Bean
  public OpenAPI customOpenApi() {
    return new OpenAPI()
        .addSecurityItem(new SecurityRequirement().addList(HttpHeaders.AUTHORIZATION))
        .components(new Components()
            .addSecuritySchemes(HttpHeaders.AUTHORIZATION, new SecurityScheme()
                .name(HttpHeaders.AUTHORIZATION)
                .type(Type.HTTP)
                .scheme("bearer")))
        .info(new Info().title("apiListener API")
            .version("1"));
  }

  @Bean
  public OperationCustomizer customize() {
    return (operation, handlerMethod) -> {
      Parameter parameter2 = new Parameter()
          .in(ParameterIn.HEADER.toString())
          .required(true)
          .description(JwtTokenFilter.MERCHANT_AUTHORIZATION)
          .example(headerToken)
          .name(JwtTokenFilter.MERCHANT_AUTHORIZATION).schema(new StringSchema());
      operation.addParametersItem(parameter2);
      return operation;
    };
  }

}