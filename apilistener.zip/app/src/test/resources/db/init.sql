create schema epay;

create table if not exists public_key
(
    id serial PRIMARY KEY not null,
    value text not null,
    date_create timestamp not null default now(),
    date_update timestamp
);

INSERT INTO public_key
(id, value, date_create, date_update)
VALUES(1, 'MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA9B5X7ukF8AIzMkFObxh8V/Gu0kJ+a+v4p/Rc9wnYufMFmXJyY8O/4IYBO/VIoz+z+N36Uny95L2vj4le4OxwqtYE/pvT4EMzVSW+//eGuXePnd8KOV/MzV5xNHM5AxIiiWxSICGjaMvRd5o29L4hRPHMxH/BGHJYV/hdV9R1PDbRdlnvZwtx1GtAI8YUaCy3p8+smyZhnhTke17JBA8AOh4jz1bbA1GGjm3LvXfOxEYcN3Hq2FQBy1niC3o15Fj14VNxn9DwILzuW2DF5g46wvtIDdke4o80K1C1TlV+C50HPlUhjbquJgzdNT8kv0MH2pZ7c3EsDtFr2DZVYTeT5wIDAQAB', '2021-12-03 17:15:00.034', '2021-12-03 18:10:00.007');