package ru.vtb.tsp.ia.epay.apilistener.services

import ru.vtb.tsp.ia.epay.core.entities.merchant.Merchant
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite
import ru.vtb.tsp.ia.epay.core.repositories.MerchantSiteRepository
import ru.vtb.tsp.ia.epay.core.services.MerchantSiteService
import spock.lang.Specification

class MerchantSiteServiceTest extends Specification {

    MerchantSiteRepository merchantSiteRepository = Mock()
    def service = new MerchantSiteService(merchantSiteRepository)

    def "getById"() {
        given:
        def mstId = "MSTID123"
        def ms = MerchantSite.builder()
                .id(mstId)
                .name("name")
                .merchant(Merchant.builder()
                        .name("name")
                        .id("id")
                        .build())
                .build()

        when:
        def result = service.getById(mstId)

        then:
        1 * merchantSiteRepository.findById(_) >> Optional.of(ms)
        assert result.get().getId() == "MSTID123"
        assert result.get().getName() == "name"
    }
}