package ru.vtb.tsp.ia.epay.apilistener.controllers

import groovy.json.JsonSlurper
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContextHolder
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.filters.JwtTokenFilter
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService
import ru.vtb.tsp.ia.epay.apilistener.services.ResponseService
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.ControllerResponseMapper
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post

class PayLinkControllerTest extends AbstractControllerTest {

    def payformUrl = "http://localhost:8989"

    OrderServiceFacade orderServiceFacade = Mock()
    TransactionService transactionService = Mock()
    PaymentService paymentService = Mock()
    KafkaService kafkaService = Mock()
    MerchantController merchantController = Mock()
    def responseService = new ResponseService(paymentService, payformUrl, transactionService)
    def paylinkController = new PayLinkController(orderServiceFacade, kafkaService,
            responseService, paymentService, merchantController)

    def setup() {
        initMock(responseService)
        initMock(paylinkController)

    }

    def "success create order"() {
        given:
        def requestDto = Utils.createOrderCreationRequest()
        def order = Utils.getOrder(SourceSystem.IBLK, null)
        def mst = Utils.getMerchantSite()
        setSecurityContext()
        orderServiceFacade.create(requestDto, mst, SourceSystem.IBLK) >> Optional.of(order)
        orderServiceFacade.getByMstOrderId(mst.getId(), requestDto.getOrderId()) >> Optional.empty()

        when:
        def response = mvc.perform(post("/api/v1/paylink/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId())
                .content(mapper.writeValueAsString(requestDto)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def "get paylink order"() {
        given:
        def order = Utils.getOrder(SourceSystem.IBLK, null)
        def mst = Utils.getMerchantSite()
        setSecurityContext()
        orderServiceFacade.getByMstOrderId(_, _) >> Optional.of(order)
        responseService.toOrderResponse(order, null,
                order.getSourceSystem()) >> ResponseEntity.ok(order)

        when:
        def response = mvc.perform(get("/api/v1/paylink/orders/1")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId()))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def "get paylink refund"() {
        given:
        setSecurityContext()
        def trx = Utils.getNewTransaction(TransactionType.CARD_REFUND)
        transactionService.getByMstTransactionId(_, _) >> trx

        when:
        def response = mvc.perform(get("/api/v1/paylink/refunds/1")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, "MSTID"))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'REFUND'
                object.refundId == 'MST-PAYMENT-ID'
                object.orderId == 'MSTID-ORD-001'
                object.amount.value == 120
                object.amount.code == 'RUB'
            }
        }
    }

    def "cancel paylink order"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CANCELED)
        def mst = Utils.getMerchantSite()
        setSecurityContext()
        paymentService.cancelOrderFromLK(mst.getId(), order.getMstOrderId()) >> Optional.of(order)
        responseService.toOrderResponse(order, null,
                order.getSourceSystem()) >> ResponseEntity.ok(order)

        when:
        def response = mvc.perform(post("/api/v1/paylink/orders/"
                + order.getMstOrderId() + "/cancel")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId()))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def setSecurityContext() {
        final var authentication = new UsernamePasswordAuthenticationToken(Utils.getMerchantSite(),
                null,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")))
        SecurityContextHolder.getContext().setAuthentication(authentication)
    }
}
