package ru.vtb.tsp.ia.epay.apilistener.services

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.*
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.CardGateway
import ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay.MirPayGateway
import ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp.SbpGateway
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite
import ru.vtb.tsp.ia.epay.core.entities.order.Order
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import ru.vtb.tsp.ia.epay.core.utils.TestFactory
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto
import spock.lang.Specification

import static ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException.MIR_PAY_INVALID_INPUT_DATA

class PaymentServiceTest extends Specification {

    TransactionService transactionService = Mock()
    OrderServiceFacade orderService = Mock()
    BundleServiceFacade bundleServiceFacade = Mock()
    KafkaService kafkaService = Mock()
    PaymentVerifier paymentVerifier = new PaymentVerifier()
    CardGateway cardGateway = Mock()
    SbpGateway sbpGateway = Mock()
    MirPayGateway mirPayGateway = Mock()

    def service = new PaymentService(transactionService, orderService, bundleServiceFacade,
            kafkaService, paymentVerifier)

    def setup() {
        cardGateway.getGatewayType() >> GatewayType.CARD
        sbpGateway.getGatewayType() >> GatewayType.SBP
        mirPayGateway.getGatewayType() >> GatewayType.MIR_PAY
        service.register(cardGateway)
        service.register(sbpGateway)
        service.register(mirPayGateway)
    }

    def "successful create card refund"() {
        given:
        def transaction = Utils.getConfirmedTransaction()
        def currency = Optional.of(Utils.getCurrency())
        def refundTx = Utils.getNewTransaction(TransactionType.CARD_REFUND)
        def txMstId = "mstTxId-123"
        def refundId = "REF123"
        def amount = AmountRequestDto.builder()
                .code(currency.get().code)
                .value(120D)
                .build()
        def refundRequestDto = RefundRequestDto.builder()
                .paymentId(txMstId)
                .refundId(refundId)
                .amount(amount)
                .build()
        def mst = MerchantSite.builder().id("TESTMSTID1").build()

        when:
        def result = service.registerRefund(refundRequestDto, mst)

        then:
        1 * transactionService.getByCode(_) >> transaction
        1 * cardGateway.refund(_, _, _) >> refundTx
        0 * sbpGateway.refund(_, _, _)
        0 * mirPayGateway.refund(_, _, _)
        1 * bundleServiceFacade.createBundleRefund(_, _, _)
        1 * kafkaService.sendToBox(_)

        and:
        result.get().getType() == TransactionType.CARD_REFUND
    }

    def "processSbpPayment"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto()
        def tx = Transaction.builder()
                .data(TransactionPayload.builder().build())
                .transactionId(UUID.randomUUID().toString())
                .amount(1d)
                .state(TransactionState.CONFIRMED)
                .currency(Currency.builder()
                        .code("RUB")
                        .name("RUB")
                        .build())
                .order(Order.builder()
                        .mstOrderId("1")
                        .orderId(UUID.randomUUID().toString())
                        .build())
                .build()

        when:
        service.processSbpPayment(dto)

        then:
        1 * sbpGateway.pay(dto) >> Optional.of(tx)
    }

    def "create QR code"() {
        given:
        def orderId = UUID.randomUUID().toString()

        def qr = "http://qrLink"

        when:
        def result = service.getQr(orderId)

        then:
        1 * sbpGateway.status(_) >> Optional.of(qr)

        and:
        assert result.get() == "http://qrLink"
    }

    def "processSbpCompleteRefund"() {
        given:
        def statusResponseDto = new SbpRefundStatusResponseDto()
        def tx = Transaction.builder()
                .data(TransactionPayload.builder().build())
                .transactionId(UUID.randomUUID().toString())
                .amount(1d)
                .state(TransactionState.CONFIRMED)
                .currency(Currency.builder()
                        .code("RUB")
                        .name("RUB")
                        .build())
                .order(Order.builder()
                        .mstOrderId("1")
                        .orderId(UUID.randomUUID().toString())
                        .build())
                .build()

        when:
        service.registerSbpRefund(statusResponseDto)

        then:
        1 * sbpGateway.refund(_)
    }

    def "complete 2 stage order"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder()
        def transaction = TestFactory.getTransaction(order)
        def amount = Utils.getAmountRequest(order.amount, order.currency.code)
        def completeRequestDto = Card2StageCompleteRequestDto.builder()
                .mstId(mst.getId())
                .mstOrderId(order.getMstOrderId())
                .amount(amount)
                .build()
        when:
        def result = service.registerPayment(completeRequestDto, GatewayType.CARD)

        then:
        1 * cardGateway.pay(_ as Card2StageCompleteRequestDto) >> Optional.of(transaction)
        1 * kafkaService.sendToBox(_)

        assert result.get().getOrder().getOrderId() == order.getOrderId()
        assert result.get().getOrder().getState() == order.getState()
    }

    def "throw exception for complete 2 stage order"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder()
        def amount = Utils.getAmountRequest(order.amountHold + 100D, order.currency.code)
        def completeRequestDto = Card2StageCompleteRequestDto.builder()
                .mstId(mst.getId())
                .mstOrderId(order.getMstOrderId())
                .amount(amount)
                .build()
        cardGateway.pay(_ as Card2StageCompleteRequestDto) >> {
            throw new ServiceException(ApplicationException.INCORRECT_AMOUNT)
        }

        when:
        service.registerPayment(completeRequestDto, GatewayType.CARD)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "INCORRECT_AMOUNT"
        0 * kafkaService.sendToBox(_)
    }

    def "cancel one stage order from lk"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder()
        order.mst = mst

        when:
        def result = service.cancelOrderFromLK(mst.getId(), order.getMstOrderId())

        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(order)
        1 * transactionService.getByOrderId(_) >> []
        1 * orderService.upsert(_) >> Optional.of(order.withState(OrderState.CANCELED))
        0 * transactionService.getByCode(_)
        0 * cardGateway.refund(_, _, _)
        0 * kafkaService.sendToBox(_)
        assert result.get().getOrderId() == "12345678"
        assert result.get().getState() == OrderState.CANCELED
    }

    def "cancel 2 stage order"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder()
        order.mst = mst
        def pendingOrder = order.withState(OrderState.PENDING)
        def transaction = Utils.getAuthorizedTransaction()
        transaction.ifPresent(tx -> tx.mst = mst)
        def refundTx = Utils.getNewTransaction(TransactionType.CARD_REFUND)

        when:
        def result = service.cancelOrder(mst.getId(), order.getMstOrderId())

        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(pendingOrder)
        1 * transactionService.getByOrderId(_) >> [transaction.get()]
        1 * transactionService.createCardRefund(_, _, _, _) >> refundTx
        1 * transactionService.upsert(_) >> refundTx
        1 * kafkaService.sendToBox(_)
        assert result.get().getOrderId() == "12345678"
        assert result.get().getState() == OrderState.PENDING
    }

    def "success start mir pay payment"() {
        given:
        def email = Utils.EMAIL
        def orderCode = "12345678"
        def amount = Utils.getAmountRequest(100D, "RUB")
        def tx = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
        def mirPayPaymentRequestDto = MirPayPaymentRequestDto.builder()
                .mstOrderCode(orderCode)
                .email(email)
                .amount(amount)
                .build()

        when:
        service.registerPayment(mirPayPaymentRequestDto, GatewayType.MIR_PAY)

        then:
        1 * mirPayGateway.pay(mirPayPaymentRequestDto) >> Optional.of(tx)
    }

    def "throw exception if the order id's does not match"() {
        given:
        def orderCode = "123456"
        def merchantId = "TESTMSTID1"
        def jwe = "test_jwt"
        def message = "MIR_PAY_INVALID_INPUT_DATA"
        def callBackBody = MirPayInApplicationResultRequestDto.builder()
                .orderId(orderCode)
                .cryptogram(jwe)
                .build()
        def callBackBodyRequestDto = MirPayPaymentProcessDto.builder()
                .callback(callBackBody)
                .merchantId(merchantId)
                .orderCode(orderCode)
                .build()
        mirPayGateway.pay(callBackBodyRequestDto) >> {
            throw new MirPayServiceException(MIR_PAY_INVALID_INPUT_DATA, message)
        }

        when:
        service.registerPayment(callBackBodyRequestDto, GatewayType.MIR_PAY)

        then:
        def exception = thrown(MirPayServiceException)
        exception.getMessage() == message
    }

    def "success confirm mir pay payment"() {
        given:
        def orderId = "123456"
        def merchantId = "TESTMSTID1"
        def jwe = "test_jwt"
        def callback = MirPayInApplicationResultRequestDto.builder()
                .orderId(orderId)
                .cryptogram(jwe)
                .build()
        def processDto = MirPayPaymentProcessDto.builder()
                .callback(callback)
                .merchantId(merchantId)
                .orderCode(orderId)
                .build()
        def tx = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()

        when:
        service.registerPayment(processDto, GatewayType.MIR_PAY)

        then:
        1 * mirPayGateway.pay(_ as MirPayPaymentProcessDto) >> Optional.of(tx)
        1 * kafkaService.sendToBox(tx.getData())
    }
}
