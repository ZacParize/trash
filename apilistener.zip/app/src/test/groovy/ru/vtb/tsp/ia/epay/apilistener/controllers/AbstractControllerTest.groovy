package ru.vtb.tsp.ia.epay.apilistener.controllers

import com.fasterxml.jackson.core.JsonParser
import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.databind.MapperFeature
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import io.opentracing.util.GlobalTracer
import org.springframework.test.web.servlet.MockMvc
import ru.vtb.tsp.ia.epay.apilistener.exceptions.CommonRestExceptionHandler
import spock.lang.Specification

import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup

abstract class AbstractControllerTest extends Specification {

    ObjectMapper mapper = new ObjectMapper()
    MockMvc mvc

    def initMock(Object controller) {
        mapper.registerModule(new JavaTimeModule())
                .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
                .enable(SerializationFeature.INDENT_OUTPUT)
                .enable(MapperFeature.DEFAULT_VIEW_INCLUSION)
                .enable(JsonParser.Feature.ALLOW_COMMENTS)
                .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
                .configure(SerializationFeature.WRAP_ROOT_VALUE, false)
                .configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false)
                .enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
                .enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT)

        mvc = standaloneSetup(controller)
                .setControllerAdvice(new CommonRestExceptionHandler(GlobalTracer.get()))
                .addPlaceholderValue("app.api.prefix", "api/v1")
                .build()
    }
}
