package ru.vtb.tsp.ia.epay.apilistener.services

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.services.bundle.BundleService
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem
import ru.vtb.tsp.ia.epay.core.services.CurrencyService
import ru.vtb.tsp.ia.epay.core.services.OrderService
import ru.vtb.tsp.ia.epay.customer.dtos.requests.CustomerToMerchantRequestDto
import ru.vtb.tsp.ia.epay.customer.dtos.responses.CustomerToMerchantResponseDto
import ru.vtb.tsp.ia.epay.customer.feigns.customer.MockCustomerToMerchantApiClient
import ru.vtb.tsp.ia.epay.customer.implementations.CustomerToMerchantClientImpl
import ru.vtb.tsp.ia.epay.customer.implementations.mappers.CustomerToMerchantMapper
import spock.lang.Specification

class OrderServiceFacadeTest extends Specification {

    OrderService orderService = Mock()
    CurrencyService currencyService = Mock()
    ValidationService validationService = Mock()
    BundleServiceFacade bundleServiceFacade = Mock()
    CustomerToMerchantClientImpl customerService = new CustomerToMerchantClientImpl(
            new MockCustomerToMerchantApiClient(),
            new CustomerToMerchantMapper() {
                @Override
                CustomerToMerchantRequestDto mapResponseToRequestDto(CustomerToMerchantResponseDto dto) {
                    return CustomerToMerchantRequestDto.builder().build();
                }
            });
    def service = new OrderServiceFacade(orderService, currencyService, validationService, customerService, bundleServiceFacade,false)

    def "getById"() {
        given:
        def orderId = "12345678"
        def order = Utils.getOrder()

        when:
        def result = service.getById(orderId)

        then:
        1 * orderService.getById(_) >> Optional.of(order)
        assert result.get().getOrderId() == "12345678"
        assert result.get().getName() == "Test product"
    }

    def "upsert"() {
        given:
        def order = Utils.getOrder()

        when:
        def result = service.upsert(order)

        then:
        1 * orderService.upsert(_) >> Optional.of(order)
        assert result.get().getOrderId() == "12345678"
        assert result.get().getName() == "Test product"
    }

    def "create"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder()
        def request = Utils.createOrderCreationRequestDto("12345678", 5000D)
        orderService.getByMstOrderId(mst.getId(), request.getOrderId()) >> Optional.empty()
        when:
        def result = service.create(request, mst, SourceSystem.ECOM)

        then:
        1 * currencyService.getById(_) >> Optional.of(new Currency())
        1 * orderService.upsert(_) >> Optional.of(order)
        1 * orderService.create(_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_,_) >> Optional.of(order)
        assert result.get().getOrderId() == "12345678"
        assert result.get().getName() == "Test product"
    }
}