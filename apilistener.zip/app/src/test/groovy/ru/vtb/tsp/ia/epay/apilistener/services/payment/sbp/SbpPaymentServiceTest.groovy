package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp

import com.fasterxml.jackson.databind.ObjectMapper
import org.postgresql.PGNotification
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp.SbpPaymentService
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp
import ru.vtb.tsp.ia.epay.core.entities.order.Order
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfo
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.services.OrderService
import ru.vtb.tsp.ia.epay.core.services.PgNotificationService
import ru.vtb.tsp.ia.epay.core.services.TransactionInfoService
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate
import spock.lang.Specification

class SbpPaymentServiceTest extends Specification {
    TransactionService transactionService = Mock()
    TransactionInfoService transactionInfoService = Mock()
    OrderService orderService = Mock()
    ObjectMapper objectMapper = Mock()
    KafkaService kafkaService = Mock()
    PgNotificationService<PGNotification, String> pgNotificationService = Mock()
    PaymentVerifier paymentVerifier = new PaymentVerifier()

    def service = new SbpPaymentService(transactionService, transactionInfoService, orderService,
            objectMapper, kafkaService, pgNotificationService, paymentVerifier)

    def "processSbpPayment_whenQStateCreated_thenReturnEmpty"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.CREATED)
        def tx = Utils.createSbpTransactionPaid()
        when:
        def payment = service.processPayment(dto)

        then:
        transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        transactionService.lockById(_) >> Optional.of(tx)
        assert payment.isEmpty()
    }

    def "processSbpPayment_whenQStateInProgress_thenReturnEmpty"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.InProgress)
        def tx = Utils.createSbpTransactionPaid()
        when:
        def payment = service.processPayment(dto)

        then:
        transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        transactionService.lockById(_) >> Optional.of(tx)
        assert payment.isEmpty()
    }

    def "processSbpPayment_whenQStateOK_thenReturnTransaction"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.OK)
        def tx = Utils.createSbpTransactionPaid()
        def newTx = tx.withState(TransactionState.RECONCILED)
        when:
        def payment = service.processPayment(dto)

        then:
        1 * transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                obj.state == TransactionState.RECONCILED
                return Optional.of(obj)
            }
        }
        1 * transactionService.getById(_) >> Optional.of(newTx)
        1 * transactionInfoService.saveOrUpdateInfo(_ as TransactionInfo) >> { TransactionInfo obj ->
            {
                assert obj.key == TransactionInfoKey.SBP_OPERATION_ID
                return Optional.of(obj)
            }
        }
        1 * orderService.upsert(_ as Order) >> { Order obj -> Optional.of(obj) }
        and:
        payment.get() == newTx
    }

    def "processSbpPayment_whenQStateCancelled_thenReturnTransaction"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.Canceled)
        def tx = Utils.createSbpTransactionPaid()
        when:
        def payment = service.processPayment(dto)

        then:
        1 * transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                obj.state == TransactionState.DECLINED
                return Optional.of(obj)
            }
        }
        1 * transactionInfoService.saveOrUpdateInfo(_ as TransactionInfo) >> { TransactionInfo obj ->
            {
                assert obj.key == TransactionInfoKey.SBP_OPERATION_ID
                return Optional.of(obj)
            }
        }
        and:
        payment.get() == tx.withState(TransactionState.DECLINED)
    }

    def "processSbpPayment_whenQStateNTST_thenReturnTransaction"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.NTST)
        def tx = Utils.createSbpTransactionPaid()
        when:
        service.processPayment(dto)

        then:
        1 * transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                assert obj.data.error == TransactionError.builder()
                        .id(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getId())
                        .httpCode(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getHttpCode())
                        .description(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getDescription())
                        .message(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getMessage())
                        .traceId(tx.getCode())
                        .build()
                return Optional.of(obj)
            }
        }
        1 * transactionInfoService.saveOrUpdateInfo(_ as TransactionInfo) >>
                { TransactionInfo obj ->
                    {
                        assert obj.key == TransactionInfoKey.SBP_OPERATION_ID
                        return Optional.of(obj)
                    }
                }
    }

    def "processSbpPayment_whenQStateOther_thenReturnTransaction"() {
        given:
        def dto = Utils.createTestSbpPaymentStatusResponseDto(
                "anId", "operationId", "orderid", "requestId",
                "qrcId", "qreason", Qstate.NTST)
        def tx = Utils.createSbpTransactionPaid()
        when:
        service.processPayment(dto)

        then:
        1 * transactionInfoService.getByQrcId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                assert obj.data.error == TransactionError.builder()
                        .id(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getId())
                        .httpCode(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getHttpCode())
                        .description(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getDescription())
                        .message(ApplicationException.SBP_PAYMENT_EXECUTION_ERROR.getMessage())
                        .traceId(tx.getCode())
                        .build()
                return Optional.of(obj)
            }
        }
        1 * transactionInfoService.saveOrUpdateInfo(_ as TransactionInfo) >>
                { TransactionInfo obj ->
                    {
                        assert obj.key == TransactionInfoKey.SBP_OPERATION_ID
                        return Optional.of(obj)
                    }
                }
    }

    def "getQr_whenMerchantSiteHasntAccessSbp_thenProcessErrorRefund"() {
        given:
        def order = Utils.getOrder()
        order.getMst().getParams().getSbpParams().setEnableSbpPayment(false)

        when:
        service.getQr("orderId")

        then:
        1 * orderService.getById(_) >> Optional.of(order)
        thrown(InternalException)
    }

    def "getQr_whenTransactionAlreadyPresent_thenReturnQrFromPaymentInfo"() {
        given:
        def order = Utils.getOrder()
        order.getMst().getParams().getSbpParams().setEnableSbpPayment(true)
        def tx = Utils.createSbpTransaction()
        tx.getData().setPaymentData(Sbp.builder()
                .prtry("prtry")
                .msgId("msgId")
                .operationId("operationId")
                .phone("phone")
                .qrcId("qrcId")
                .qrLink("qrLink")
                .requestId("requestId")
                .status(Qstate.OK)
                .build())
        when:
        def qr = service.getQr("orderId")

        then:
        1 * orderService.getById(_) >> Optional.of(order)
        1 * transactionService.getWithQrcByOrderId(_) >> List.of(tx)
        and:
        qr == Optional.of(tx.getData().getPaymentData().getInfo())
    }

    def "getQr_whenTransactionNotPresent_thenReturnQrFromNotificationMessage"() {
        given:
        def order = Utils.getOrder()
        order.getMst().getParams().getSbpParams().setEnableSbpPayment(true)
        def tx = Utils.createSbpTransaction()
        def testQr = "testQr"

        when:
        def qr = service.getQr("orderId")

        then:
        1 * orderService.getById(_) >> Optional.of(order)
        1 * transactionService.getWithQrcByOrderId(_) >> List.of()
        1 * transactionService.createSbpPayment(order) >> Optional.of(tx)
        1 * transactionService.upsert(_) >> Optional.of(tx)
        1 * kafkaService.sendToBox(_)
        1 * pgNotificationService.receive(_, _) >> testQr
        and:
        qr == Optional.of(testQr)
    }

    def "getQr_whenTransactionNotPresentTxNotCreated_thanReturnOptionalEmpty"() {
        given:
        def order = Utils.getOrder()
        order.getMst().getParams().getSbpParams().setEnableSbpPayment(true)

        when:
        def qr = service.getQr("orderId")

        then:
        1 * orderService.getById(_) >> Optional.of(order)
        1 * transactionService.getWithQrcByOrderId(_) >> List.of()
        1 * transactionService.createSbpPayment(order) >> Optional.empty()
        0 * kafkaService.sendToBox(_)
        1 * transactionService.upsert(null) >> Optional.empty()
        and:
        qr.isEmpty()
    }
}
