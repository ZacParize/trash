package ru.vtb.tsp.ia.epay.apilistener;

import com.nimbusds.jose.EncryptionMethod;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWEAlgorithm;
import com.nimbusds.jose.JWEEncrypter;
import com.nimbusds.jose.JWEHeader;
import com.nimbusds.jose.JWEObject;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import java.io.Serializable;
import java.math.BigDecimal;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicReference;
import javax.annotation.Nullable;
import ru.vtb.tsp.ia.epay.apilistener.configs.MirPayConfig;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.PaymentCondition;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.PaymentSystem;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.TypeRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BindingRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleItemRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.BundleRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.CustomerRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.ReceiptCustomerRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.RefundReceiptCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.TaxParamsDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.CustomerTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.DestinationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.SourceRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.TypedRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.A2cInternalTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.A2cTransferRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.merchants.transfers.a2c.CardRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.orders.OrderCreationRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.CardPaymentData;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.CardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.PaymentCardRequest;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.SavedCardPaymentRequestDto;
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.TwoStagePaymentRequest;
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayJWT;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxClient;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxSystem;
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSContextVariables;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptData;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptState;
import ru.vtb.tsp.ia.epay.core.domains.fiscalization.ReceiptType;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.DefaultSettings;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteCardParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteFiscalParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteTransferParams;
import ru.vtb.tsp.ia.epay.core.domains.transaction.MerchantSiteInfo;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Sbp;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency;
import ru.vtb.tsp.ia.epay.core.entities.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType;
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem;
import ru.vtb.tsp.ia.epay.core.entities.route.Flow;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptStatusDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingCategory;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.BindingType;

public class Utils {

  public static final String MERCH_ID = "testMerch";
  public static final String MST_ID = "testMstId";
  public static final String RUB = "RUB";
  public static final Double PRICE = 100d;
  public static final String ENC_CVV = "1234567";
  public static final String ENC_PAN = "1234567890";
  public static final String SAVED_CARD_ID = "11111111111111";
  public static final String EMAIL = "test@testtest.com";
  public static final String PHONE = "+79876543210";
  private static final AtomicReference<Long> CURRENT_TIME = new AtomicReference<>(
      System.currentTimeMillis());

  public static OrderCreationRequestDto createOrderCreationRequest() {
    return createOrderCreationRequestDto(UUID.randomUUID().toString(), PRICE);
  }

  public static A2cInternalTransferRequestDto createTransferCreationRequest() {
    return createTransferCreationRequestDto(UUID.randomUUID().toString(), PRICE);
  }

  public static Currency getCurrency() {
    return getCurrency(643, RUB, "RUB");
  }

  public static Currency getCurrency(int numericCode, String code, String name) {
    return Currency.builder()
        .numericCode(numericCode)
        .code(code)
        .name(name)
        .build();
  }

  public static MerchantSiteCardParams getMerchantSiteCardParams() {
    return MerchantSiteCardParams.builder()
        .terminalId("12345")
        .enableApplePayment(false)
        .enableGooglePayment(false)
        .enableCardPayment(true)
        .enableCardFlowThreeDS(true)
        .enablePartialRefund(true)
        .enablePaymentCheckboxesVisible(true)
        .enableTwoStage(false)
        .enableMirPayment(true)
        .merchantId("testMerchantId")
        .merchantName("testMerchantName")
        .build();
  }

  public static MerchantSiteParams getMerchantSiteParams() {
    return MerchantSiteParams.builder()
        .callbackUrl("http://localhost/callback")
        .orderLifeTime(Duration.ofMillis(60_000_000))
        .mcc("testMcc")
        .cardParams(getMerchantSiteCardParams())
        .sbpParams(MerchantSiteSbpParams.builder()
            .merchantId("testMerchantId")
            .enablePartialRefund(true)
            .enableSbpPayment(true)
            .account("testAccount")
            .qrcType("qrCodeType")
            .legalId("testLegalId")
            .paymentPurpose("testPaymentPurpose")
            .refundPurpose("testRefundPurpose")
            .templateVersion("testVersion")
            .build())
        .transferParams(MerchantSiteTransferParams.builder()
            .a2cTransferParams(getA2cTransferParams())
            .enableA2cTransfer(true)
            .enableC2aTransfer(false)
            .build())
        .fiscalParams(MerchantSiteFiscalParams.builder()
            .defaultSettings(DefaultSettings.builder()
                .paymentType(PaymentType.FULL_PAYMENT)
                .productName("test")
                .taxSystem(TaxSystem.GENERAL)
                .taxRate(TaxRate.NONE)
                .build())
            .active(true)
            .email("test@test.com")
            .login("login")
            .kktId("1")
            .taxClient(TaxClient.OFD_1)
            .url("http://test.com")
            .inn("111")
            .build())
        .build();
  }

  public static MerchantSite getMerchantSite() {
    return MerchantSite.builder()
        .merchant(Merchant.builder().id(MERCH_ID).build())
        .id(MST_ID)
        .name("testName")
        .login("testLogin")
        .params(getMerchantSiteParams())
        .build();
  }

  private static Map<String, Serializable> getA2cTransferParams() {
    final var map = new HashMap<String, Serializable>();
    map.put("FPTTI", "Payment Transaction");
    map.put("SNAME", "Romashka LLC");
    map.put("SFNAME", "OAO");
    map.put("SLNAME", "Gde dengi");
    map.put("BICCODE", "044525187");
    map.put("FSOURCE", "08");
    map.put("MRPPHONE", "+7001234567");
    return map;
  }

  public static PublicKeyData getPublicKeyData() {
    return PublicKeyData.builder()
        .cvvPublicKey("12345678")
        .panPublicKey("12345678")
        .build();
  }

  public static Order getOrder() {
    return getOrder(SourceSystem.ECOM, "http://localhost/action.php?name=qwerty");
  }

  public static Order getOrder(String mstId) {
    return getOrder(SourceSystem.ECOM, "http://localhost/action.php?name=qwerty", mstId);
  }

  public static Order getOrder(SourceSystem sourceSystem, String returnUrl) {
    return getOrder(sourceSystem, returnUrl, "TESTMSTID1");
  }

  public static Order getOrder(SourceSystem sourceSystem, String returnUrl, String mstId) {
    return Order.builder()
        .orderId("12345678")
        .code("f89c5c4f-d35f-4965-b645-8d0c0e8f752e")
        .mstOrderId("MSTID-ORD-001")
        .mst(MerchantSite.builder()
            .id(mstId)
            .name("Test mst")
            .url("http://localhost")
            .params(getMerchantSiteParams())
            .merchant(Merchant.builder()
                .id("MERCHANT-ID1")
                .name("OOO AOA")
                .build())
            .build())
        .name("Test product")
        .amount(120.00D)
        .amountHold(120.00D)
        .currency(getCurrency())
        .state(OrderState.CREATED)
        .createdAt(LocalDateTime.now())
        .expiredAt(LocalDateTime.now().plusYears(100))
        .returnUrl(returnUrl)
        .sourceSystem(sourceSystem)
        .build();
  }

  public static List<ReceiptStatusDto> getReceiptStatusList() {
    return List.of(ReceiptStatusDto.builder()
        .uuid(UUID.randomUUID())
        .orderCode(UUID.randomUUID())
        .operation(ReceiptType.INCOME)
        .status(ReceiptState.PRINTED)
        .createdAt(LocalDateTime.now())
        .data(ReceiptData.builder()
            .fiscalDocumentNumber(1L)
            .fiscalSign("test")
            .fnNumber("1")
            .fnsUrl("http://ya.ru")
            .kktRegId("1")
            .ofdInn("1")
            .receiptDatetime(LocalDateTime.now())
            .shiftNumber(1L)
            .totalSum(new BigDecimal(1))
            .build())
        .build());
  }

  public static Order getOrderWithNullReturnUrl() {
    return getOrder(SourceSystem.ECOM, null);
  }

  public static A2cTransferRequestDto getTransferRequestDto() {
    return A2cTransferRequestDto.builder()
        .description("description")
        .orderId("1")
        .amount(AmountRequestDto.builder().code("RUB").value(100d).build())
        .source(SourceRequestDto.builder()
            .customer(CustomerTransferRequestDto.builder()
                .fullname("fullname")
                .surname("surname")
                .name("name")
                .build())
            .build())
        .destination(DestinationRequestDto.<CardRequestDto>builder()
            .paymentData(TypedRequestDto.<CardRequestDto>builder()
                .object(CardRequestDto.builder()
                    .encryptedPan("1111111111111111")
                    .build())
                .build())
            .build())
        .build();
  }

  public static Order getTransfer() {
    return Order.builder()
        .orderId(UUID.randomUUID().toString())
        .state(OrderState.CREATED)
        .mstOrderId("1")
        .createdAt(LocalDateTime.now())
        .description("description")
        .code(UUID.randomUUID().toString())
        .mst(getMerchantSite())
        .currency(getCurrency())
        .amount(100d)
        .build();
  }

  public static OrderCreationRequestDto createOrderCreationRequestDto(String orderId,
      Double price) {
    return OrderCreationRequestDto.builder()
        .orderId(orderId)
        .customer(CustomerRequestDto.builder()
            .email("test@testvtb.com")
            .customerId(UUID.randomUUID().toString())
            .build())
        .amount(AmountRequestDto.builder().code(RUB).value(price).build())
        .binding(BindingRequestDto.builder().bindingType(BindingType.COMMON)
            .operationType(BindingCategory.MIT).build())
        .orderName("Test description")
        .returnUrl("http://localhost/action.php?name=qwerty")
        .build();
  }

  public static OrderCreationRequestDto createOrderWithBundleCreationRequestDto() {
    return createOrderWithBundleCreationRequestDto(UUID.randomUUID().toString(), PRICE);
  }

  public static OrderCreationRequestDto createOrderWithBundleCreationRequestDto(String orderId,
      Double price) {
    return OrderCreationRequestDto.builder()
        .orderId(orderId)
        .customer(CustomerRequestDto.builder()
            .email("test@testvtb.com")
            .customerId(UUID.randomUUID().toString())
            .build())
        .amount(AmountRequestDto.builder().code(RUB).value(price).build())
        .binding(BindingRequestDto.builder().bindingType(BindingType.COMMON)
            .operationType(BindingCategory.MIT).build())
        .orderName("Test description")
        .returnUrl("http://localhost/action.php?name=qwerty")
        .bundle(BundleRequestDto.builder()
            .items(List.of(createBundle()))
            .build())
        .build();
  }

  public static BundleItemRequestDto createBundle() {
    return BundleItemRequestDto.builder()
        .name("name")
        .code("code")
        .description("description")
        .price(BigDecimal.valueOf(100))
        .measure(UnitsMeasure.SINGLE_ITEM)
        .positionId(1)
        .quantity(BigDecimal.valueOf(1))
        .shippable(false)
        .taxParams(TaxParamsDto.builder()
            .taxType(TaxRate.VAT_GENERAL)
            .taxSum(BigDecimal.valueOf(0))
            .build())
        .amount(BigDecimal.valueOf(1))
        .discount(BigDecimal.valueOf(0))
        .paymentSubject(ProductType.GOODS)
        .paymentType(PaymentType.FULL_PAYMENT)
        .userData("userData")
        .build();
  }

  public static A2cInternalTransferRequestDto createTransferCreationRequestDto(String orderId,
      Double price) {
    return A2cInternalTransferRequestDto.builder()
        .orderId(orderId)
        .description("Test name")
        .amount(AmountRequestDto.builder().code(RUB).value(price).build())
        .destination(DestinationRequestDto.<CardRequestDto>builder()
            .paymentData(TypedRequestDto.<CardRequestDto>builder()
                .type(TypeRequest.CARD)
                .object(CardRequestDto.builder()
                    .encryptedPan(UUID.randomUUID().toString())
                    .build())
                .build())
            .build())
        .sourceSystem(SourceSystem.IBLK)
        .build();
  }

  public static OrderCreationRequestDto getOrderCreationRequestDto(
      String email,
      Double price,
      String currencyCode,
      String returnUrl) {
    return OrderCreationRequestDto.builder()
        .orderId("12345678")
        .customer(CustomerRequestDto.builder().email(email).build())
        .amount(AmountRequestDto.builder().code(currencyCode).value(price).build())
        .orderName("Test description")
        .returnUrl(returnUrl)
        .build();
  }

  public static CardPaymentRequestDto createTestCardPaymentRequestDto() {
    return CardPaymentRequestDto.builder()
        .email(EMAIL)
        .amount(AmountRequestDto.builder().value(PRICE).code(RUB).build())
        .encryptedCvv(ENC_CVV)
        .rememberCard(false)
        .encryptedPan(ENC_PAN)
        .expiryDate("1230")
        .build();

  }

  public static SavedCardPaymentRequestDto createTestSavedCardPaymentRequestDto() {
    return SavedCardPaymentRequestDto.builder()
        .savedCardId(SAVED_CARD_ID)
        .amount(AmountRequestDto.builder().code(RUB).value(PRICE).build())
        .email(EMAIL)
        .build();
  }

  public static RefundRequestDto createTestRefundCreationRequestDto() {
    return createTestRefundCreationRequestDto("1", "TESTMSTID1-12345-4");
  }

  public static RefundRequestDto createTestRefundCreationRequestDto(String refundId,
      String paymentId) {
    return RefundRequestDto.builder()
        .refundId(refundId)
        .paymentId(paymentId)
        .amount(AmountRequestDto.builder()
            .code("RUB")
            .value(100D)
            .build())
        .build();
  }

  public static RefundRequestDto getRefundCreationRequestDto(Double value,
      String currencyCode) {
    final var customerDto = ReceiptCustomerRequestDto.builder().email(EMAIL).phone(PHONE).build();
    final var receiptDto = RefundReceiptCreationRequestDto.builder().customer(customerDto)
        .taxSystem(1L).build();
    return RefundRequestDto.builder()
        .refundId("1")
        .paymentId("TESTMSTID1-12345-4")
        .amount(AmountRequestDto.builder()
            .value(value)
            .code(currencyCode)
            .build())
        .build();
  }

  public static AmountRequestDto getAmountRequest() {
    return getAmountRequest(100d, "RUB");
  }

  public static AmountRequestDto getAmountRequest(@Nullable Double value,
      @Nullable String currencyCode) {
    return AmountRequestDto.builder().code(currencyCode).value(value).build();
  }

  public static TwoStagePaymentRequest getTwoStagePaymentRequest(@Nullable Double value,
      @Nullable String currencyCode) {
    return TwoStagePaymentRequest.builder()
        .amount(getAmountRequest(value, currencyCode))
        .build();
  }

  public static SbpPaymentStatusResponseDto createTestSbpPaymentStatusResponseDto() {
    return createTestSbpPaymentStatusResponseDto("anId", "operationId", "orderid", "requestId",
        "qrcId", "qreason", Qstate.CREATED);
  }

  public static SbpPaymentStatusResponseDto createTestSbpPaymentStatusResponseDto(
      String anId,
      String operationId,
      String orderId,
      String requestId,
      String qrcId,
      String qreason,
      Qstate qstate) {
    return SbpPaymentStatusResponseDto.builder()
        .anId(anId)
        .operationId(operationId)
        .orderId(orderId)
        .requestId(requestId)
        .qrcId(qrcId)
        .qReason(qreason)
        .qState(qstate)
        .build();
  }

  public static Optional<Transaction> getEmptyTransaction() {
    HashMap<String, Serializable> context = new HashMap<>();
    context.put(ThreeDSContextVariables.TDS_ACS.cname(), "test");
    TransactionPayload data = TransactionPayload.builder()
        .context(context)
        .build();
    Transaction tx = Transaction.builder()
        .transactionId("123456-vpay")
        .order(getOrder())
        .flow(new Flow())
        .createdAt(LocalDateTime.now())
        .amount(120D)
        .currency(getCurrency())
        .mstTransactionId("order-123")
        .code("testCode")
        .mst(new MerchantSite())
        .type(TransactionType.CARD_PAYMENT)
        .state(TransactionState.NEW)
        .data(data)
        .build();
    return Optional.ofNullable(tx);
  }

  public static Optional<Transaction> getNewTransaction(TransactionType type) {
    HashMap<String, Serializable> context = new HashMap<>();
    context.put(ThreeDSContextVariables.TDS_ACS.cname(), "test");
    TransactionPayload data = TransactionPayload.builder()
        .context(context)
        .paymentId("MST-PAYMENT-ID")
        .build();
    return getNewTransaction(type, data);
  }

  public static Optional<Transaction> getNewTransaction(TransactionType type,
      TransactionPayload data) {
    Transaction tx = Transaction.builder()
        .transactionId("123456-vpay")
        .order(getOrder())
        .flow(new Flow())
        .createdAt(LocalDateTime.now())
        .amount(120D)
        .currency(getCurrency())
        .mstTransactionId("order-123")
        .code("code123")
        .mst(new MerchantSite())
        .type(type)
        .state(TransactionState.NEW)
        .data(data)
        .build();
    return Optional.ofNullable(tx);
  }

  public static Optional<Transaction> getConfirmedTransaction() {
    HashMap<String, Serializable> context = new HashMap<>();
    context.put("test", "test");
    TransactionPayload data = TransactionPayload.builder()
        .context(context)
        .merchant(MerchantSiteInfo.builder()
            .mstId("TESTMSTID1")
            .build())
        .build();
    Transaction tx = Transaction.builder()
        .transactionId("123456-vpay")
        .order(getOrder())
        .flow(new Flow())
        .createdAt(LocalDateTime.now())
        .amount(120D)
        .currency(getCurrency())
        .mstTransactionId("order-123")
        .code("code123")
        .mst(getOrder().getMst())
        .type(TransactionType.CARD_PAYMENT)
        .state(TransactionState.CONFIRMED)
        .data(data)
        .build();

    return Optional.ofNullable(tx);
  }

  public static Optional<Transaction> getAuthorizedTransaction() {
    HashMap<String, Serializable> context = new HashMap<>();
    context.put("test", "test");
    TransactionPayload data = TransactionPayload.builder()
        .context(context)
        .build();
    Transaction tx = Transaction.builder()
        .transactionId("123456-vpay")
        .order(getOrder())
        .flow(new Flow())
        .createdAt(LocalDateTime.now())
        .amount(120D)
        .currency(getCurrency())
        .mstTransactionId("order-123")
        .code("code123")
        .mst(getOrder().getMst())
        .type(TransactionType.CARD_PAYMENT_TWO_STAGE)
        .state(TransactionState.AUTHORIZED)
        .data(data)
        .build();

    return Optional.ofNullable(tx);
  }

  public static Optional<Transaction> createEmptyTransactionWithError() {
    TransactionError error = TransactionError.builder()
        .id(ApplicationException.UNKNOWN_ERROR.getId())
        .httpCode(400)
        .description(ApplicationException.UNKNOWN_ERROR.getDescription())
        .message(ApplicationException.UNKNOWN_ERROR.getMessage())
        .traceId("merch-tx-id")
        .build();
    TransactionPayload data = TransactionPayload.builder().error(error).build();
    Transaction tx = Transaction.builder()
        .transactionId("123456-vpay")
        .order(new Order())
        .flow(new Flow())
        .createdAt(LocalDateTime.now())
        .amount(120D)
        .currency(getCurrency())
        .mstTransactionId("testCode")
        .code("order-123")
        .mst(new MerchantSite())
        .type(TransactionType.CARD_PAYMENT)
        .state(TransactionState.NEW)
        .data(data)
        .build();
    return Optional.ofNullable(tx);
  }

  public static Long nextId() {
    return CURRENT_TIME.accumulateAndGet(System.currentTimeMillis(),
        (prev, next) -> next > prev ? next : prev + 1) % 10000000000L;
  }

  public static MirPayPaymentRequestDto createTestMirPayPaymentRequestDto() {
    return MirPayPaymentRequestDto.builder()
        .email(EMAIL)
        .amount(AmountRequestDto.builder().value(PRICE).code(RUB).build())
        .build();

  }

  public static MirPayJWT getMirPayJWT() {
    return getMirPayJWT("123456", "000000000000001");
  }

  public static MirPayJWT getMirPayJWT(String orderCode, String merchantId) {
    return MirPayJWT.builder()
        .tan("2200123456789123486")
        .cav("3D6FC826A08C82B89780029F69670FDDCF299B")
        .tey(29)
        .tem(3)
        .transId("5ab52487-177f-464b-b695-2954ffc44a13")
        .merchantId(merchantId)
        .mx5c("ZhaBxDTFVDARMfTOYqtRCw==")
        .orderId(orderCode)
        .sum(1000)
        .cur(643)
        .media("ISDK")
        .build();
  }

  public static MirPayConfig createTestMirPayConfiguration() {
    return new MirPayConfig("http:/localhost/ul",
        "http:/localhost/jwks",
        "http://callBackHost",
        3600000L,
        300L,
        false,
        "",
        "",
        "",
        "");
  }

  public static KeyPair generateNewKeyPair() {
    try {
      KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA");
      keyGenerator.initialize(2048);
      return keyGenerator.genKeyPair();
    } catch (Exception e) {
      throw new RuntimeException("Error generate test key pair", e);
    }
  }

  public static String getJWE(MirPayJWT jwt, PrivateKey nspkPrivateKey,
      RSAPublicKey appregPublicKey) throws JOSEException {
    JWSHeader header = new JWSHeader
        .Builder(JWSAlgorithm.PS256)
        .build();

    JWTClaimsSet claimsSet = new JWTClaimsSet.Builder()
        .claim("tan", jwt.getTan())
        .claim("cav", jwt.getCav())
        .claim("tey", jwt.getTey())
        .claim("tem", jwt.getTem())
        .claim("transId", jwt.getTransId())
        .claim("mId", jwt.getMerchantId())
        .claim("mx5c", jwt.getMx5c())
        .claim("orderId", jwt.getOrderId())
        .claim("sum", jwt.getSum())
        .claim("cur", jwt.getCur())
        .claim("media", jwt.getMedia())
        .build();

    SignedJWT signedJWT = new SignedJWT(header, claimsSet);
    JWSSigner signer = new RSASSASigner(nspkPrivateKey);
    signedJWT.sign(signer);

    String jwtString = signedJWT.serialize();
    JWEObject jweObject = new JWEObject(
        new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, EncryptionMethod.A256GCM)
            .contentType("JWT")
            .build(),
        new Payload(jwtString)
    );
    JWEEncrypter encrypter = new RSAEncrypter(appregPublicKey);
    jweObject.encrypt(encrypter);
    return jweObject.serialize();
  }

  public static Transaction createSbpTransactionPaid() {
    return createSbpTransaction(
        TransactionState.PAID,
        TransactionType.SBP_PAYMENT,
        OrderState.PROCESSING);
  }

  public static Transaction createSbpTransaction() {
    return createSbpTransaction(
        TransactionState.RECONCILED,
        TransactionType.SBP_PAYMENT,
        OrderState.PROCESSING);
  }

  public static Transaction createSbpTransaction(
      TransactionState transactionState,
      TransactionType transactionType,
      OrderState orderState) {
    return Transaction.builder()
        .data(TransactionPayload.builder()
            .paymentData(Sbp.builder()
                .build())
            .context(new HashMap<>())
            .build())
        .transactionId(UUID.randomUUID().toString())
        .amount(100d)
        .type(transactionType)
        .state(transactionState)
        .currency(getCurrency())
        .mst(getMerchantSite())
        .order(Order.builder()
            .mstOrderId("1")
            .state(orderState)
            .expiredAt(LocalDateTime.now().plusDays(2))
            .mst(getMerchantSite())
            .amount(100d)
            .currency(getCurrency())
            .orderId(UUID.randomUUID().toString())
            .build())
        .build();
  }

  public static SbpRefundStatusResponseDto createTestSbpRefundStatusResponseDto(
      Qstate state) {
    return SbpRefundStatusResponseDto.builder()
        .addtlInf("addtlInf")
        .msgId("msgId")
        .prtry("prtry")
        .txSts(state)
        .build();
  }

  public static SbpConfirmRefundCallbackDto createTestSbpConfirmRefundCallbackDto(
      Qstate state
  ) {
    return SbpConfirmRefundCallbackDto.builder()
        .addtlInf("addtlInf")
        .prtry("prtry")
        .msgId("msgId")
        .fio("fio")
        .txSts(state)
        .build();
  }

  public static PaymentCardRequest createTestPaymentRequest() {
    return PaymentCardRequest.builder()
        .orderId("orderId")
        .orderCode(UUID.randomUUID())
        .paymentData(CardPaymentData.builder()
            .terminalId("termId")
            .encryptedPan("encryptedPan")
            .encryptedCvv("encryptedCvv")
            .expiryDate("1230")
            .condition(PaymentCondition.SSL_SECURED)
            .cavv("cavv")
            .xid("xid")
            .eci("eci")
            .bank("bank")
            .paymentSystem(PaymentSystem.VISA)
            .amount(AmountRequestDto.builder().code("RUB").value(100d).build())
            .build())
        .build();
  }

  public static Order getCardPaymentOrder(
      String orderCode, String mstOrderId, OrderType type, OrderState state) {
    return Order.builder()
        .orderId("12345678")
        .code(orderCode)
        .mstOrderId(mstOrderId)
        .mst(MerchantSite.builder()
            .id("TESTMSTID1")
            .name("Test mst")
            .url("http://localhost")
            .params(getMerchantSiteParams())
            .merchant(Merchant.builder()
                .id("MERCHANT-ID1")
                .name("OOO AOA")
                .build())
            .build())
        .name("Test product")
        .amount(120.00D)
        .amountHold(120.00D)
        .currency(getCurrency())
        .state(state)
        .orderType(type)
        .createdAt(LocalDateTime.now())
        .expiredAt(LocalDateTime.now().plusYears(100))
        .returnUrl("http://localhost/action.php?name=qwerty")
        .sourceSystem(SourceSystem.ECOM)
        .build();
  }

  public static RefundRequestDto getRefundRequestDto(Transaction tx) {
    return RefundRequestDto.builder()
        .refundId("refundId")
        .paymentId(tx.getTransactionId())
        .amount(AmountRequestDto.builder()
            .value(tx.getAmount())
            .code(tx.getCurrency().getName())
            .build())
        .build();
  }
}