package ru.vtb.tsp.ia.epay.apilistener.configs

import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.context.ActiveProfiles
import org.testcontainers.containers.GenericContainer
import org.testcontainers.spock.Testcontainers
import spock.lang.Specification

@ActiveProfiles('integration')
@Testcontainers
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = TestConfig.class)
abstract class AbstractBaseIT extends Specification {

    @Autowired
    protected ObjectMapper objectMapper

    private static final String POSTGRES_USER = 'postgres'
    private static final String POSTGRES_PASSWORD = 'password'
    private static final int POSTGRES_PORT = 5432
    private static final String POSTGRES_CONTAINER = 'epay'
    private static final String POSTGRES_DB = 'epay'
    private static final String POSTGRES_IMAGE = 'nexus-ci.corp.dev.vtb/efcp-docker-lib/testcontainers/postgres:latest'

    static {
        GenericContainer postgresContainer = new GenericContainer(POSTGRES_IMAGE)
                .withNetworkAliases(POSTGRES_CONTAINER)
                .withExposedPorts(POSTGRES_PORT)
                .withEnv('POSTGRES_USER': POSTGRES_USER)
                .withEnv('POSTGRES_PASSWORD': POSTGRES_PASSWORD)
                .withEnv('POSTGRES_DB': POSTGRES_DB)
        postgresContainer.start()
        System.setProperty('spring.datasource.url', String.format('jdbc:postgresql://%s:%s/%s',
                postgresContainer.getContainerIpAddress(),
                postgresContainer.getFirstMappedPort(),
                POSTGRES_DB))
        System.setProperty('spring.datasource.username', POSTGRES_USER)
        System.setProperty('spring.datasource.password', POSTGRES_PASSWORD)
    }

    def "test"() {
        when:
        print("Tests is working")

        then:
        assert true
    }
}
