package ru.vtb.tsp.ia.epay.apilistener.controllers

import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayInApplicationResultRequestDto
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.MirPayPaymentProcessDto
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayJwksService
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.callbacks.SbpConfirmRefundCallbackDto
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpPaymentStatusResponseDto
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.refunds.SbpRefundStatusResponseDto
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print

class CallbackControllerTest extends AbstractControllerTest {

    PaymentService paymentService = Mock()

    MirPayJwksService mirPayJwksService = Mock()

    def callbackController = new CallbackController(paymentService, mirPayJwksService)

    def setup() {
        initMock(callbackController)
    }

    def "test paymentCallback"() {
        given:
        def callbackRequestDto = SbpPaymentStatusResponseDto.builder()
                .anId("testAnId")
                .qId("testQId")
                .orderId("testOrderId")
                .operationId("testOperationId")
                .qState(Qstate.OK)
                .qReason("testQReason")
                .qrcId("testQrcId")
                .requestId("testRequestId")
                .build()

        when:
        def response = mvc.perform(
                post("/api/v1/sbp/callback/payment")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(callbackRequestDto)))
                .andDo(print())
                .andReturn().response

        then:
        1 * paymentService.processSbpPayment(_)
        response.status == HttpStatus.OK.value()
    }

    def "test confirmRefundCallback"() {
        given:
        def callbackRequestDto = SbpConfirmRefundCallbackDto.builder()
                .msgId('1234')
                .txSts(Qstate.OK)
                .fio("fio")
                .prtry("123")
                .build()

        when:
        def response = mvc.perform(
                post("/api/v1/sbp/callback/refund/confirm")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(callbackRequestDto)))
                .andDo(print())
                .andReturn().response

        then:
        1 * paymentService.registerSbpRefund(_)
        response.status == HttpStatus.OK.value()
    }

    def "test completeRefundCallback"() {
        given:
        def callbackRequestDto = SbpRefundStatusResponseDto.builder()
                .msgId('1234')
                .txSts(Qstate.OK)
                .prtry("123")
                .build()

        when:
        def response = mvc.perform(
                post("/api/v1/sbp/callback/refund/complete")
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(callbackRequestDto)))
                .andDo(print())
                .andReturn().response

        then:
        1 * paymentService.registerSbpRefund(_)
        response.status == HttpStatus.OK.value()
    }

    def "test mirPayPaymentDataPreparationResultCallback"() {
        given:
        def orderCode = "test_order_id"
        def merchantId = "test_merchant_id"
        def xCorrelationIdHeader = "test_x_correlation_id_header"
        def request = MirPayInApplicationResultRequestDto.builder()
                .orderId(orderCode)
                .cryptogram("test_cryptogram")
                .build()

        when:
        def response = mvc.perform(
                put(String.format("/api/v1/In-Application/merchants/%s/orders/%s", merchantId,
                        orderCode))
                        .header(CallbackController.X_CORRELATION_ID_HEADER, xCorrelationIdHeader)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(request)))
                .andDo(print())
                .andReturn().response

        then:
        1 * paymentService.registerPayment(_ as MirPayPaymentProcessDto, GatewayType.MIR_PAY)
        response.status == HttpStatus.ACCEPTED.value()
        response.getHeader(CallbackController.X_CORRELATION_ID_HEADER) == xCorrelationIdHeader
    }

    def "test getJwks"() {
        given:
        def merchantId = "test_merchant_id"

        when:
        def response = mvc.perform(
                get(String.format("/jwks/%s-jwks.json", merchantId))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        1 * mirPayJwksService.getJwks()
        response.status == HttpStatus.OK.value()
    }
}
