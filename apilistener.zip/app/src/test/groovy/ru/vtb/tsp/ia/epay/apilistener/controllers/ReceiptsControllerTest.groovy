package ru.vtb.tsp.ia.epay.apilistener.controllers

import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.web.bind.annotation.PathVariable
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.filters.JwtTokenFilter
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade
import ru.vtb.tsp.ia.epay.apilistener.services.clients.fiscalization.FiscalizationApi
import ru.vtb.tsp.ia.epay.apilistener.services.fiscalization.ReceiptsServiceImpl
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.ReceiptStatusMapper
import spock.lang.Unroll

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get

class ReceiptsControllerTest extends AbstractControllerTest {

    static final String AUTH_HEADER_VALUE = "TESTMSTID1"

    OrderServiceFacade orderServiceFacade = Mock()
    ReceiptStatusMapper receiptStatusMapper = Mock()
    FiscalizationApi fiscalizationApi = new FiscalizationApi() {
        @Override
        ResponseEntity<List<ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptStatusDto>> getStatus(@PathVariable("orderCode") UUID orderCode) {
            return ResponseEntity.ok(Utils.getReceiptStatusList());
        }
    }
    ReceiptsServiceImpl receiptsService = new ReceiptsServiceImpl(orderServiceFacade,
            fiscalizationApi, receiptStatusMapper)
    def receiptsController = new ReceiptsController(receiptsService)

    def setup() {
        initMock(receiptsController)
    }

    def setSecurityContext() {
        final var authentication = new UsernamePasswordAuthenticationToken(Utils.getMerchantSite(),
                null,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")))
        SecurityContextHolder.getContext().setAuthentication(authentication)
    }

    def "get receipt state"() {
        given:
        def mstOrderId = 'MSTID-ORD-001'
        def mstId = 'testMstId'
        def order = Utils.getOrder(mstId)
        orderServiceFacade.getByMstOrderId(mstId, order.getMstOrderId()) >> Optional.of(order)
        setSecurityContext()
        when:
        def response = mvc.perform(get("/api/v1/receipts/"
                + order.getMstOrderId() + "/status")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE))
                .andReturn().response
        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')
    }

    @Unroll
    def "get receipt state with exception"() {
        given:
        def mstOrderId = 'MSTID-ORD-001'
        def mstId = 'test'
        def order = Utils.getOrder(mstId)
        def fiscalResponse = ResponseEntity.ok(Utils.getReceiptStatusList())
        orderServiceFacade.getByMstOrderId(mstId, order.getMstOrderId()) >> Optional.of(order)
        setSecurityContext()
        when:
        def response = mvc.perform(get("/api/v1/receipts/"
                + order.getMstOrderId() + "/status")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE))
                .andReturn().response
        then:
        response.status == HttpStatus.INTERNAL_SERVER_ERROR.value()
        response.contentType.contains('application/json')
    }
}
