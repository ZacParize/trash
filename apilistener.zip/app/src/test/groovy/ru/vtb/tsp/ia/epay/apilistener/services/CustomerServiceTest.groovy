package ru.vtb.tsp.ia.epay.apilistener.services

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.core.entities.customer.Customer
import ru.vtb.tsp.ia.epay.core.repositories.CustomerRepository
import spock.lang.Specification

class CustomerServiceTest extends Specification {

    CustomerRepository customerRepository = Mock()
    def service = new CustomerService(customerRepository)

    private static final String EMAIL = Utils.nextId() + "@testtest.com"
    private static final String PHONE = "+7" + Utils.nextId()

    def "upsert"() {
        given:
        def customer = Customer.builder()
                .email(EMAIL)
                .phone(PHONE)
                .build()

        when:
        def result = service.upsert(PHONE, EMAIL)

        then:
        1 * customerRepository.saveOrUpdate(_) >> customer
        assert result.get().getEmail() == EMAIL
        assert result.get().getPhone() == PHONE
    }

    def "getByPhoneAndEmail"() {
        given:
        def customer = Customer.builder()
                .email(EMAIL)
                .phone(PHONE)
                .build()

        when:
        def result = service.getByPhoneAndEmail(PHONE, EMAIL)

        then:
        1 * customerRepository.findByPhoneAndEmail(_, _) >> [customer]
        assert result[0].getEmail() == EMAIL
        assert result[0].getPhone() == PHONE
    }
}
