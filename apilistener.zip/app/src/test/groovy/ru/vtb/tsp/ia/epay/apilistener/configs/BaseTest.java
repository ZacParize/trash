package ru.vtb.tsp.ia.epay.apilistener.configs;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Testcontainers;

@Testcontainers
@Slf4j
public class BaseTest {
  //@Container
  //public static KafkaContainer kafkaContainer = ConfluentKafkaContainer.getInstance();

  //@Container
  //public static PostgresqlContainer postgresqlContainer = PostgresqlContainer.getInstance();

  @Test
  public void startTest() {
    log.info("Tests is working");
  }
}