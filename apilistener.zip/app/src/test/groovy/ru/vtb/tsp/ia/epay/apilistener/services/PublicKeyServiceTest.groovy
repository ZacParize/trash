package ru.vtb.tsp.ia.epay.apilistener.services

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import ru.vtb.tsp.ia.epay.apilistener.configs.properties.PublicKeyProperties
import ru.vtb.tsp.ia.epay.apilistener.services.clients.key.cvv.MockCvvKeyApiClient
import ru.vtb.tsp.ia.epay.apilistener.services.clients.key.pan.MockPanKeyApiClient
import ru.vtb.tsp.ia.epay.core.repositories.PublicKeyRepository
import spock.lang.Specification

class PublicKeyServiceTest extends Specification {
    PublicKeyRepository publicKeyRepository = Mock()
    ResponseEntity<PublicKeyDto> entity =
            new ResponseEntity(new PublicKeyDto("test"), HttpStatus.OK)
    def publicKeyProperties = PublicKeyProperties
            .builder()
            .certValidation(false)
            .clientAuth(false)
            .enabled(true)
            .url("https://test")
            .build()
    def publicKeyService = new PublicKeyService(publicKeyRepository,
            new MockCvvKeyApiClient(), new MockPanKeyApiClient(), publicKeyProperties)

    def "test public key"() {
        when:
        publicKeyService.init()
        then:
        1 * publicKeyRepository.saveOrUpdate(_, _)
    }
}