package ru.vtb.tsp.ia.epay.apilistener.services.payment.card

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ValidationException
import ru.vtb.tsp.ia.epay.apilistener.services.mirpay.MirPayTransactionService
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.entities.merchant.Merchant
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.order.OrderType
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.CurrencyService
import ru.vtb.tsp.ia.epay.core.services.OrderService
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import ru.vtb.tsp.ia.epay.core.utils.TestFactory
import spock.lang.Specification

class CardPaymentServiceTest extends Specification {

    OrderService orderService = Mock()
    CurrencyService currencyService = Mock()
    TransactionService transactionService = Mock()
    MirPayTransactionService mirPayTransactionService = Mock()
    PaymentVerifier paymentVerifier = new PaymentVerifier()

    def service = new CardPaymentService(orderService, currencyService, transactionService,
            mirPayTransactionService, paymentVerifier)


    def "throw exception for complete with wrong amount"() {
        given:
        def mst = Utils.getMerchantSite()
        def order = Utils.getOrder().withState(OrderState.PENDING)
        def transaction = TestFactory.getTransaction(order)
                .withState(TransactionState.AUTHORIZED)
                .withType(TransactionType.CARD_PAYMENT_TWO_STAGE)

        def amount = Utils.getAmountRequest(order.amountHold + 100D, order.currency.code)
        orderService.lockByMstOrderId(_ as String, _ as String) >> Optional.of(order)
        transactionService.getByOrderId(_ as String) >> [transaction]

        when:
        service.completeTwoStageCardPayment(mst.getId(), order.getMstOrderId(), amount)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "INCORRECT_AMOUNT"
    }

    def "process payment for order when all ok then return transaction"() {
        given:
        def order = Utils.getOrder()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT)
        when:
        service.processPayment(order)
        then:
        1 * transactionService.createCardPayment(_) >> transaction
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }

    def "process payment for multi params when all complete then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.REFUNDED)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        thrown(InternalException)
    }

    def "process payment when order created disabled card payment then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        order.getMst().getParams().getCardParams().setEnableCardPayment(false)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        thrown(InternalException)
    }

    def "process payment when not marked terminal then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(null)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        thrown(InternalException)
    }

    def "process payment when empty currency then throw ServiceException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId("4")
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.empty()
        def e = thrown(ServiceException)
        e.message == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
    }

    def "process payment when incorrect currency then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        def currency = Utils.getCurrency(645, "RU", "RU")

        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        thrown(InternalException)
    }

    def "process payment when has processing transaction then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        def currency = Utils.getCurrency()
        def transaction = Utils.getConfirmedTransaction().get().withState(TransactionState.PROCESSING)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of(transaction)
        def e = thrown(ServiceException)
        e.message == ApplicationException.IN_PROCESS.message
    }

    def "process payment when pay amount is less than order amount then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        def currency = Utils.getCurrency()
        def transaction = Utils.getConfirmedTransaction().get()
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(100.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "01-02-2040")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of(transaction)
        def e = thrown(InternalException)
    }

    def "process payment when date incorrect then throw InternalException"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        def currency = Utils.getCurrency()
        def transaction = Utils.getConfirmedTransaction().get().withAmount(100D)
        def newTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(20.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", null)
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of(transaction)
        1 * transactionService.createCardPayment(_) >> newTransaction
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.CARD_EXPIRED.message
    }

    def "process payment when all correct then return Transaction"() {
        given:
        def order = Utils.getOrder().withState(OrderState.CREATED)
        def currency = Utils.getCurrency()
        def transaction = Utils.getConfirmedTransaction().get().withAmount(100D)
        def newTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT)
        when:
        service.processPayment("orderCode", Utils.getAmountRequest(20.0, "RUB"), "email", "encryptedPan", "encryptedCvv", "cardHolder", "1110")
        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of(transaction)
        1 * transactionService.createCardPayment(_) >> newTransaction
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }

    def "process payment by paymentRequest when mst id incorrect then throw ValidationException"() {
        given:
        def order = Utils.getOrder()
                .withState(OrderState.CREATED)
                .withMst(MerchantSite.builder()
                        .merchant(Merchant.builder().id("544848").build())
                        .id("15154")
                        .build())

        when:
        service.processPayment(Utils.createTestPaymentRequest(), Utils.getMerchantSite())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when Merchant order ID incorrect then throw ValidationException"() {
        given:
        def order = Utils.getCardPaymentOrder("test", "test", OrderType.PAYMENT, OrderState.CREATED)

        when:
        service.processPayment(Utils.createTestPaymentRequest(), order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when incorrect order type then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.TRANSFER, OrderState.CREATED)

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when card payment disabled then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setEnableCardPayment(false)

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when terminal id not marked then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(null)

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when terminal id not match then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId() + "1")

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when currency not exist then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency()

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.empty()
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.CURRENCY_IS_NOT_ALLOWED.getMessage()
    }

    def "process payment by paymentRequest when currency not equal then throw ValidationException"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency(484, "dd", "dd")

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when processing transaction exists then return"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()

        when:
        def payment = service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderCode(_) >> List.of(transaction)
        and:
        payment.get() == transaction
    }

    def "process payment by paymentRequest when pay amount is less than throw exceptiom"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
                .withAmount(20)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
                .withState(TransactionState.CREATED)

        when:
        def payment = service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderCode(_) >> List.of()
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        and:
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when has processing transaction than throw exception"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
                .withAmount(100)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
                .withState(TransactionState.PROCESSING)

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderCode(_) >> List.of()
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of(transaction)
        and:
        thrown(ValidationException)
    }

    def "process payment by paymentRequest when all ok than return transaction"() {
        given:
        def request = Utils.createTestPaymentRequest()
        def order = Utils.getCardPaymentOrder(request.getOrderCode().toString(),
                request.getOrderId(), OrderType.PAYMENT, OrderState.CREATED)
                .withAmount(100)
        order.getMst().getParams().getCardParams().setTerminalId(request.getPaymentData().getTerminalId())
        def currency = Utils.getCurrency()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
        def newTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()

        when:
        service.processPayment(request, order.getMst())

        then:
        1 * orderService.getByCode(_) >> Optional.of(order)
        1 * orderService.lockByCode(_) >> Optional.of(order)
        1 * currencyService.getById(_) >> Optional.of(currency)
        1 * transactionService.getByOrderCode(_) >> List.of()
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * mirPayTransactionService.declineMirPayTransactions(_) >> List.of()
        1 * transactionService.createCardPayment(_) >> Optional.of(newTransaction)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }
    def "complete two stage card payment when transaction not authorized then return transaction"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
                .withAmountHold(100d)
        def order = Utils.getOrder().withState(OrderState.PENDING)
        when:
        def payment = service.completeTwoStageCardPayment("mstId", "mstOrderId", amountRequest)
        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(order)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        payment.isEmpty()
    }

    def "complete two stage card payment when transaction not authorized then throw InternalException"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getAuthorizedTransaction().get()
                .withAmountHold(100d)
        def anotherTransaction = Utils.getAuthorizedTransaction().get()
        def order = Utils.getOrder().withState(OrderState.PENDING)
        when:
        service.completeTwoStageCardPayment("mstId", "mstOrderId", amountRequest)
        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(order)
        1 * transactionService.getByOrderId(_) >> List.of(transaction, anotherTransaction)
        thrown(InternalException)
    }

    def "complete two stage card payment when amount is bigger than hold amount then throw InternalException"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getAuthorizedTransaction().get()
                .withAmountHold(80d)
        def order = Utils.getOrder().withState(OrderState.PENDING)
        when:
        service.completeTwoStageCardPayment("mstId", "mstOrderId", amountRequest)
        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(order)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.INCORRECT_AMOUNT.message
    }

    def "complete two stage card payment when all ok then return transaction"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getAuthorizedTransaction().get()
                .withAmountHold(100d)
        def order = Utils.getOrder().withState(OrderState.PENDING)
        when:
        service.completeTwoStageCardPayment("mstId", "mstOrderId", amountRequest)
        then:
        1 * orderService.lockByMstOrderId(_, _) >> Optional.of(order)
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }

}
