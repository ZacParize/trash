package ru.vtb.tsp.ia.epay.apilistener.services.mirpay

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException
import spock.lang.Specification
import spock.lang.Unroll

import java.security.interfaces.RSAPublicKey

class MirPayTokenDecoderTest extends Specification {

    def appregKeyPair = Utils.generateNewKeyPair()
    def nspkKeyPair = Utils.generateNewKeyPair()

    def appregPrivateKey = appregKeyPair.getPrivate()
    def appregPublicKey = (RSAPublicKey) appregKeyPair.getPublic()

    def nspkPrivateKey = nspkKeyPair.getPrivate()
    def nspkPublicKey = (RSAPublicKey) nspkKeyPair.getPublic()
    MirPayTokenDecoder service = new MirPayTokenDecoder(appregPrivateKey, nspkPublicKey)

    @Unroll
    def "throw exception if JWE is '#cryptogram'"(String cryptogram) {
        when:
        service.decodeJWE(cryptogram)

        then:
        def exception = thrown(MirPayServiceException)
        exception.getMessage() == "MIR_PAY_INVALID_INPUT_DATA"

        where:
        cryptogram << [null, "", " "]
    }

    def "decode Mir Pay JWE"() {
        given:
        def expectedMirPayJWT = Utils.getMirPayJWT()
        def cryptogram = Utils.getJWE(expectedMirPayJWT, nspkPrivateKey, appregPublicKey)

        when:
        def actualMirPayJWT = service.decodeJWE(cryptogram)

        then:
        assert actualMirPayJWT.getTan() == expectedMirPayJWT.getTan()
        assert actualMirPayJWT.getCav() == expectedMirPayJWT.getCav()
        assert actualMirPayJWT.getTey() == expectedMirPayJWT.getTey()
        assert actualMirPayJWT.getTem() == expectedMirPayJWT.getTem()
        assert actualMirPayJWT.getTransId() == expectedMirPayJWT.getTransId()
        assert actualMirPayJWT.getMerchantId() == expectedMirPayJWT.getMerchantId()
        assert actualMirPayJWT.getMx5c() == expectedMirPayJWT.getMx5c()
        assert actualMirPayJWT.getOrderId() == expectedMirPayJWT.getOrderId()
        assert actualMirPayJWT.getSum() == expectedMirPayJWT.getSum()
        assert actualMirPayJWT.getCur() == expectedMirPayJWT.getCur()
        assert actualMirPayJWT.getMedia() == expectedMirPayJWT.getMedia()
    }
}
