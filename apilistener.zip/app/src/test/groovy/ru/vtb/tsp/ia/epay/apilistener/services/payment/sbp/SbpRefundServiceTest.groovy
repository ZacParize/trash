package ru.vtb.tsp.ia.epay.apilistener.services.payment.sbp

import org.apache.commons.lang3.StringUtils
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.OperationNotSupported
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteSbpParams
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.OrderService
import ru.vtb.tsp.ia.epay.core.services.TransactionInfoService
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import ru.vtb.tsp.ia.epay.sbpadapter.enums.Qstate
import spock.lang.Specification

import java.time.LocalDateTime

class SbpRefundServiceTest extends Specification {

    TransactionService transactionService = Mock()
    TransactionInfoService transactionInfoService = Mock()
    OrderService orderService = Mock()
    PaymentVerifier paymentVerifier = new PaymentVerifier()

    def service = new SbpRefundService(transactionService, transactionInfoService, orderService, paymentVerifier)

    def "registerRefund_whenAmountNull_thenReturnEmpty"() {
        given:
        def tx = Utils.createSbpTransaction()
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .build()

        when:
        def refund = service.registerRefund(refundRequestDto, tx, 'testMstId')

        then:
        0 * transactionService.createSbpRefund(_, _, _, _)
        0 * transactionService.upsert(_)
        assert refund.isEmpty()
    }

    def "registerRefund_whenTransactionMerchantSiteIdNotSameAsRefund_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction()
        def refundRequestDto = Utils.getRefundRequestDto(tx)

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId() + 'mstId')

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.TRANSACTION_NOT_FOUND.message
    }

    def "registerRefund_whenTransactionNotSpbPayed_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.APPLE_PAYMENT,
                OrderState.PAID)
        def refundRequestDto = Utils.getRefundRequestDto(tx)

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.INCORRECT_PARENT_TRANSACTION.message
    }

    def "registerRefund_whenTransactionRefunded_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.REFUNDED)
        def refundRequestDto = Utils.getRefundRequestDto(tx)

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.ORDER_REFUNDED_ERROR.message
    }

    def "registerRefund_whenOrderAlreadyExpired_thenThrowException"() {
        given:
        def transaction = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def tx = transaction.withOrder(transaction.getOrder()
                .withExpiredAt(LocalDateTime.now().minusDays(1)))
        def refundRequestDto = Utils.getRefundRequestDto(tx)

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        thrown(OperationNotSupported)
    }

    @Deprecated
    def "registerRefund_whenOrderHasDifferentCurrency_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def badCurrency = tx.getCurrency().withCode("TEST")
        def badTx = tx.withCurrency(badCurrency)
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 2.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, badTx, badTx.getMst().getId())

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
    }

    @Deprecated
    def "registerRefund_whenTransactionHasDifferentCurrency_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def currency = Utils.getCurrency()
        tx = tx.withCurrency(currency.withCode("TEST"))
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 2.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
    }

    def "registerRefund_whenIncorrectRefundAmount_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 0.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        def e = thrown(ServiceException)
        e.message == ApplicationException.INCORRECT_AMOUNT.message
    }

    def "registerRefund_whenPartialRefundNotAllowed_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def mst = tx.getOrder().getMst()
        def params = mst.getParams()
        params.setSbpParams(MerchantSiteSbpParams.builder()
                .merchantId("testMerchantId")
                .enablePartialRefund(false)
                .enableSbpPayment(true)
                .account("testAccount")
                .qrcType("qrCodeType")
                .legalId("testLegalId")
                .paymentPurpose("testPaymentPurpose")
                .refundPurpose("testRefundPurpose")
                .templateVersion("testVersion")
                .build())
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 50.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        1 * transactionService.getByOrderId(_) >> List.of(Utils.createSbpTransaction())
        def e = thrown(ServiceException)
        e.message == ApplicationException.PARTIAL_REFUND_NOT_SUPPORTED.message
    }

    def "registerRefund_whenTransactionProcessing_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def transaction = Utils.createSbpTransaction(
                TransactionState.PROCESSING, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 100.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        def e = thrown(ServiceException)
        e.message == ApplicationException.IN_PROCESS.message
    }

    def "registerRefund_whenAmountBiggerRemainingRefundAmount_thenThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        tx = tx.withAmount(1.0)
        def transaction = Utils.createSbpTransaction()
                .withAmount(1.0)
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 10.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        def e = thrown(ServiceException)
        e.message == ApplicationException.INCORRECT_AMOUNT.message
    }

    def "registerRefund_whenSpbRefundNotCreated_thenReturnThrowException"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def transaction = Utils.createSbpTransaction()
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 100d, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * transactionService.createSbpRefund(_, _, _, _) >> Optional.empty()
        thrown(InternalException)
    }

    def "registerRefund_whenAllCorrect_thenReturnRefundTransaction"() {
        given:
        def tx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def transaction = Utils.createSbpTransaction()
        def newTx = Utils.createSbpTransaction(
                TransactionState.CONFIRMED, TransactionType.SBP_PAYMENT,
                OrderState.CREATED)
        def refundRequestDto = RefundRequestDto.builder()
                .refundId("refundId")
                .paymentId(tx.getTransactionId())
                .amount(new AmountRequestDto(value: 100.0, code: 'RUB'))
                .build()

        when:
        service.registerRefund(refundRequestDto, tx, tx.getMst().getId())

        then:
        1 * transactionService.getByOrderId(_) >> List.of(transaction)
        1 * transactionService.createSbpRefund(_, _, _, _) >> Optional.of(newTx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                assert obj.getData().getOriginContext().get("transactionId") == tx.getTransactionId()
                assert obj.getData().getOriginContext().get("code") == tx.getCode()
                assert obj.getData().getOriginContext().get("mstTransactionId") == tx.getMstTransactionId()
                assert obj.getData().getOriginContext().get("transactionType") == tx.getType().getValue()
                assert obj.getData().getOriginContext().get("transactionState") == tx.getState().getValue()
                return Optional.of(obj)
            }
        }
    }

    def "processCompleteRefund_whenQStateCorrect_thenReturnReconciledTransaction"(Qstate qState) {
        given:
        def dto = Utils.createTestSbpRefundStatusResponseDto(qState)
        def tx = Utils.createSbpTransactionPaid()

        when:
        def payment = service.processCompleteRefund(dto)

        then:
        1 * transactionInfoService.getByMsgId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                transactionService.getById(_) >> Optional.of(obj)
                obj.state == TransactionState.RECONCILED
                return Optional.of(obj)
            }
        }
        1 * transactionService.getByOrderId(_) >> List.of(tx)
        1 * orderService.upsert(_) >> Optional.of(tx.getOrder())
        where:
        qState << [Qstate.ACWP, Qstate.OK]
    }

    def "processCompleteRefund_whenErrorQState_thenReturnDeclinedTransaction"(
            Qstate qState) {
        given:
        def dto = Utils.createTestSbpRefundStatusResponseDto(qState)
        def tx = Utils.createSbpTransactionPaid()
        when:
        def payment = service.processCompleteRefund(dto)

        then:
        1 * transactionInfoService.getByMsgId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                obj.state == TransactionState.DECLINED
                return Optional.of(obj)
            }
        }
        where:
        qState << [Qstate.CREATED, Qstate.InProgress]
    }

    def "processCompleteRefund_whenErrorQStateAndEmptyPrtry_thenReturnDeclinedTransaction"() {
        given:
        def dto = Utils.createTestSbpRefundStatusResponseDto(Qstate.CREATED)
        dto.setPrtry(StringUtils.EMPTY)
        def tx = Utils.createSbpTransactionPaid()
        when:
        def payment = service.processCompleteRefund(dto)

        then:
        1 * transactionInfoService.getByMsgId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        and:
        payment.isEmpty()
    }


    def "processConfirmRefund_whenQStateRCVD_thenReturnTransactionByMsgId"() {
        given:
        def dto = Utils.createTestSbpConfirmRefundCallbackDto(Qstate.RCVD)
        def tx = Utils.createSbpTransactionPaid()
        when:
        service.processConfirmRefund(dto)

        then:
        1 * transactionInfoService.getByMsgId(_) >> Optional.of(tx)
    }

    def "processConfirmRefund_whenQStateNotRCVD_thenProcessErrorRefund"() {
        given:
        def dto = Utils.createTestSbpConfirmRefundCallbackDto(Qstate.CREATED)
        def tx = Utils.createSbpTransactionPaid()
        when:
        service.processConfirmRefund(dto)

        then:
        1 * transactionInfoService.getByMsgId(_) >> Optional.of(tx)
        1 * transactionService.lockById(_) >> Optional.of(tx)
        1 * transactionService.upsert(_ as Transaction) >> { Transaction obj ->
            {
                obj.state == TransactionState.DECLINED
                return Optional.of(obj)
            }
        }
    }

}
