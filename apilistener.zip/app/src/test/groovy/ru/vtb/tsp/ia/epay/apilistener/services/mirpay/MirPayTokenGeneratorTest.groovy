package ru.vtb.tsp.ia.epay.apilistener.services.mirpay

import com.nimbusds.jose.JOSEObjectType
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.crypto.RSASSAVerifier
import com.nimbusds.jose.util.Base64
import com.nimbusds.jwt.SignedJWT
import ru.vtb.tsp.ia.epay.apilistener.Utils
import spock.lang.Specification

import java.security.interfaces.RSAPublicKey

class MirPayTokenGeneratorTest extends Specification {

    def nspkCertificateInBase64 = "test_2"
    def nspkCertificateSerialNumber = "87EFD0C"
    def mirPayConfig = Utils.createTestMirPayConfiguration()
    def tcpKeyPair = Utils.generateNewKeyPair()
    def tcpPrivateKey = tcpKeyPair.getPrivate()
    def tcpPublicKey = (RSAPublicKey) tcpKeyPair.getPublic()

    MirPayTokenGenerator service = new MirPayTokenGenerator(nspkCertificateInBase64, nspkCertificateSerialNumber, tcpPrivateKey, mirPayConfig)

    def "generate Mir Pay JWT"() {
        given:
        def orderEntity = Utils.getOrder()
                .withOrderId("TEST_ID")
                .withCode("TEST_CODE")

        when:
        def result = service.getMirPayJWT(orderEntity)
        def signedJWT = SignedJWT.parse(result)

        then:
        def jwsVerifier = new RSASSAVerifier(tcpPublicKey)
        assert signedJWT.verify(jwsVerifier)

        def jwsHeader = signedJWT.getHeader()
        assert jwsHeader.getJWKURL() == URI.create("http:/localhost/jwks/MERCHANT-ID1-jwks.json")
        assert jwsHeader.getType() == JOSEObjectType.JWT
        assert jwsHeader.getKeyID() == nspkCertificateSerialNumber
        assert jwsHeader.getAlgorithm() == JWSAlgorithm.PS256
        assert jwsHeader.getX509CertChain() == Collections.singletonList(new Base64(nspkCertificateInBase64))

        def jwtClaimsSet = signedJWT.getJWTClaimsSet()
        assert jwtClaimsSet.getIssuer() == orderEntity.getMst().getMerchant().getId()
        assert jwtClaimsSet.getIssueTime() != null
        assert jwtClaimsSet.getExpirationTime() != null
        assert jwtClaimsSet.getStringClaim("orderId") == orderEntity.getCode()
        assert jwtClaimsSet.getDoubleClaim("sum") == orderEntity.getAmount()
        assert jwtClaimsSet.getStringClaim("cur") == orderEntity.getCurrency().getCode()
        assert jwtClaimsSet.getStringClaim("media") == "UL"
        assert jwtClaimsSet.getStringClaim("rurl") == "http://callBackHost/api/v1/In-Application/merchants/MERCHANT-ID1/orders/TEST_CODE"
    }
}
