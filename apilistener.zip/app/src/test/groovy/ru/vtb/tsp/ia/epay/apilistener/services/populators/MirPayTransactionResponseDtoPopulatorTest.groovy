package ru.vtb.tsp.ia.epay.apilistener.services.populators


import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.services.LinksService
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import spock.lang.Specification

class MirPayTransactionResponseDtoPopulatorTest extends Specification {

    LinksService linksService = Mock()
    MirPayTransactionResponseDtoPopulator populator = new MirPayTransactionResponseDtoPopulator(linksService)

    def "populate MirPayTransactionResponseDto"() {
        given:
        def mirPayLink = 'test_link'
        def order = Utils.getOrder()
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.NEW)
                .withOrder(order)
        def paymentData = MirPay.builder()
                .transactionCode(mirPayTr.getCode())
                .build()
        mirPayTr.getData().setPaymentData(paymentData)

        linksService.createMirPayLink(order) >> mirPayLink

        when:
        def result = populator.populate(mirPayTr)

        then:
        assert result.getTransactionCode() == mirPayTr.getCode()
        assert result.getTransactionStatus() == 'NEW'
        assert result.getPaymentMethod() == 'mir_pay'
        assert result.getMirPayLink() == mirPayLink
    }
}