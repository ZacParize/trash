package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.configs.MirPayConfig
import ru.vtb.tsp.ia.epay.apilistener.exceptions.InternalException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.MirPayServiceException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.CurrencyService
import ru.vtb.tsp.ia.epay.core.services.OrderService
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import ru.vtb.tsp.ia.epay.notificator.dtos.NotificationType
import spock.lang.Specification
import spock.lang.Unroll

class MirPayPaymentServiceTest extends Specification {

    KafkaService kafkaService = Mock()
    OrderService orderService = Mock()
    MirPayConfig mirPayConfig = Mock()
    CurrencyService currencyService = Mock()
    TransactionService transactionService = Mock()
    PaymentVerifier mirPayVerifier = new PaymentVerifier()

    def service = new MirPayPaymentService(kafkaService, orderService, mirPayConfig,
            currencyService, transactionService, mirPayVerifier)

    def "throw exception for expired order"() {
        given:
        def orderCode = "12345678"
        def order = Utils.getOrder().withState(OrderState.EXPIRED)
        def amount = Utils.getAmountRequest(100D, "RUB")

        orderService.getByCode(orderCode) >> Optional.of(order)

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "ORDER_NOT_FOUND"
    }

    def "throw exception if mir pay payment is not enabled"() {
        given:
        def orderCode = "12345678"
        def cardParams = Utils.getMerchantSiteCardParams()
        cardParams.setEnableMirPayment(Boolean.FALSE)
        def merchantSiteParams = Utils.getMerchantSiteParams()
        merchantSiteParams.setCardParams(cardParams)
        def merchantSite = Utils.getMerchantSite().withParams(merchantSiteParams)
        def order = Utils.getOrder().withMst(merchantSite)
        def amount = Utils.getAmountRequest(100D, "RUB")

        orderService.getByCode(orderCode) >> Optional.of(order)

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        def exception = thrown(InternalException)
        exception.getMessage() == "INTERNAL_ERROR"
    }

    @Unroll
    def "throw exception if order has '#transactionType' transaction"() {
        given:
        def orderCode = "12345678"
        def order = Utils.getOrder()
        def amount = Utils.getAmountRequest(120D, "RUB")
        def nonDeclinedTr = Utils.getNewTransaction(transactionType).get().withState(transactionState)

        orderService.getByCode(orderCode) >> Optional.of(order)
        currencyService.getById(amount.getCode()) >> Optional.of(Utils.getCurrency())
        transactionService.getByOrderId(order.getOrderId()) >> List.of(nonDeclinedTr)

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "TRANSACTION_IN_PROCESS"

        where:
        transactionType              | transactionState
        TransactionType.CARD_PAYMENT | TransactionState.AUTHORIZED
        TransactionType.SBP_PAYMENT  | TransactionState.SBP_PAYMENT_CREATED
        TransactionType.SBP_REFUND   | TransactionState.SBP_REFUND_CREATED
    }

    def "throw exception if currency order and request currency is different"() {
        given:
        def orderCode = "12345678"
        def order = Utils.getOrder()
        def amount = Utils.getAmountRequest(100D, "USD")

        orderService.getByCode(orderCode) >> Optional.of(order)
        currencyService.getById(amount.getCode()) >> Optional.of(Utils.getCurrency(6434, "USD", "USD"))

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "INCORRECT_CURRENCY"
    }

    @Unroll
    def "throw exception if payment amount '#amountValue' than it's need 100D"(Double amountValue) {
        given:
        def orderCode = "12345678"
        def order = Utils.getOrder().withAmount(100D)
        def amount = Utils.getAmountRequest(amountValue, "RUB")

        orderService.getByCode(orderCode) >> Optional.of(order)
        currencyService.getById(amount.getCode()) >> Optional.of(Utils.getCurrency())

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "INCORRECT_AMOUNT"

        where:
        amountValue << [99D, 101D]
    }

    def "success start process mir pay payment"() {
        given:
        def declineCheckDelay = 300L
        def orderCode = "12345678"
        def order = Utils.getOrder()
        def amount = Utils.getAmountRequest(120D, "RUB")
        def tx = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
        def cardTx = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()

        mirPayConfig.getDeclineCheckDelay() >> declineCheckDelay
        orderService.getByCode(orderCode) >> Optional.of(order)
        currencyService.getById(amount.getCode()) >> Optional.of(Utils.getCurrency())
        transactionService.getByOrderId(order.getOrderId()) >> List.of(cardTx)

        when:
        service.startProcessPayment(orderCode, amount, Utils.EMAIL)

        then:
        1 * transactionService.upsert(cardTx.withState(TransactionState.DECLINED)) >> Optional.of(cardTx)
        1 * transactionService.createMirPayPayment(order) >> Optional.of(tx)
        1 * kafkaService.sendToNotificator(tx.getCode(), NotificationType.MIR_PAY_DECLINE_CHECK_TIMEOUT, declineCheckDelay)
        1 * transactionService.upsert(tx) >> Optional.of(tx)
    }

    def "throw exception if mir py order is completed"() {
        given:
        def mirPayJWT = Utils.getMirPayJWT()
        def order = Utils.getOrder().withState(OrderState.PAID)
        orderService.getByCode(mirPayJWT.getOrderId()) >> Optional.of(order)

        when:
        service.confirmProcessPayment(mirPayJWT.getOrderId(), Utils.MERCH_ID, mirPayJWT)

        then:
        def exception = thrown(MirPayServiceException)
        exception.getMessage() == "MIR_PAY_FORBIDDEN"
    }

    def "throw exception if the merchant id's does not match"() {
        given:
        def order = Utils.getOrder()
        def mirPayJWT = Utils.getMirPayJWT()
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.NEW)
                .withMst(Utils.getMerchantSite())
        mirPayTr.getData().setPaymentData(
                MirPay.builder()
                        .transactionCode(mirPayTr.getCode())
                        .cav(mirPayJWT.getCav())
                        .expiryYear(mirPayJWT.getTey().toString())
                        .transId(mirPayJWT.getTransId())
                        .tan(mirPayJWT.getTan())
                        .build()
        )
        orderService.getByCode(mirPayJWT.getOrderId()) >> Optional.of(order)
        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayTr)

        when:
        service.confirmProcessPayment(mirPayJWT.getOrderId(), "other_merchant_id", mirPayJWT)

        then:
        def exception = thrown(MirPayServiceException)
        exception.getMessage() == "MIR_PAY_FORBIDDEN"
    }

    def "throw exception if mir py transaction with NEW state doesn't exist"() {
        given:
        def mirPayJWT = Utils.getMirPayJWT()
        def order = Utils.getOrder()
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.MIR_PAY_PAYMENT_CREATED)
                .withMst(Utils.getMerchantSite())
        orderService.getByCode(mirPayJWT.getOrderId()) >> Optional.of(order)
        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayTr)

        when:
        service.confirmProcessPayment(mirPayJWT.getOrderId(), Utils.MERCH_ID, mirPayJWT)

        then:
        def exception = thrown(MirPayServiceException)
        exception.getMessage() == "MIR_PAY_NOT_FOUND"
    }

    def "success confirm process mir pay payment"() {
        given:
        def order = Utils.getOrder()
        def mirPayJWT = Utils.getMirPayJWT()
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.NEW)
                .withMst(Utils.getMerchantSite())
        mirPayTr.getData().setPaymentData(
                MirPay.builder()
                        .transactionCode(mirPayTr.getCode())
                        .cav(mirPayJWT.getCav())
                        .expiryYear(mirPayJWT.getTey().toString())
                        .transId(mirPayJWT.getTransId())
                        .tan(mirPayJWT.getTan())
                        .build()
        )
        orderService.getByCode(mirPayJWT.getOrderId()) >> Optional.of(order)
        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayTr)

        when:
        service.confirmProcessPayment(mirPayJWT.getOrderId(), Utils.MERCH_ID, mirPayJWT)

        then:
        1 * transactionService.upsert(mirPayTr.withState(TransactionState.MIR_PAY_PAYMENT_CREATED)) >> Optional.of(mirPayTr)
    }

}
