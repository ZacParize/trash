package ru.vtb.tsp.ia.epay.apilistener.services

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.core.entities.currency.Currency
import ru.vtb.tsp.ia.epay.core.repositories.CurrencyRepository
import ru.vtb.tsp.ia.epay.core.services.CurrencyService
import spock.lang.Specification

class CurrencyServiceTest extends Specification {

    CurrencyRepository currencyRepository = Mock()
    def service = new CurrencyService(currencyRepository)

    def "when getById then get response"() {
        given:
        def currency = Currency.builder()
                .code(Utils.RUB)
                .name(Utils.RUB)
                .numericCode(1)
                .build()

        when:
        def result = service.getById(Utils.RUB)

        then:
        1 * currencyRepository.findById(Utils.RUB) >> Optional.of(currency)
        assert result.get().getCode() == Utils.RUB
        assert result.get().getName() == Utils.RUB
        assert result.get().getNumericCode() == 1
    }
}
