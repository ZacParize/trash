package ru.vtb.tsp.ia.epay.apilistener.services.mirpay


import spock.lang.Specification

class MirPayJwksServiceTest extends Specification {

    def nspkCertificateInBase64 = "test_2"
    def nspkCertificateSerialNumber = "87EFD0C"

    MirPayJwksService service = new MirPayJwksService(nspkCertificateInBase64, nspkCertificateSerialNumber)

    def "generate Mir Pay JWKS"() {
        when:
        def jwks = service.getJwks()

        then:
        assert jwks.getKeys().size() == 1

        def key = jwks.getKeys().get(0)
        assert key.getKid() == nspkCertificateSerialNumber
        assert key.getKty() == "RSA"
        assert key.getUse() == null
        assert key.getX5c() == Collections.singletonList(nspkCertificateInBase64)
    }
}
