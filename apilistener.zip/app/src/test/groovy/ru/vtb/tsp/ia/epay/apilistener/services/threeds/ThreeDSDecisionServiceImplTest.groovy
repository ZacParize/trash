package ru.vtb.tsp.ia.epay.apilistener.services.threeds

import ru.vtb.tsp.ia.epay.acsproxy.dtos.requests.ThreeDSDecisionCallbackDto
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.exceptions.TransactionNotFoundException
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.LinksService
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSDecisionService
import ru.vtb.tsp.ia.epay.core.domains.enums.ThreeDSVersion
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.additional.Threeds
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card
import ru.vtb.tsp.ia.epay.core.domains.transaction.threeds.ThreeDSData
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Specification
/**
 *
 * @author Rustam Valiev <RValiev@inno.tech>
 * @since 27.03.2022
 */
class ThreeDSDecisionServiceImplTest extends Specification {

    TransactionService transactionService = Mock()
    KafkaService kafkaService = Mock()
    LinksService linksService = Mock()
    ThreeDSDecisionService service = new ThreeDSDecisionServiceImpl(transactionService, kafkaService, linksService)

    def "Fill3DSDataFrom3DSDecision"() {
        given:
        def transactionId = UUID.randomUUID().toString().concat("_vpay")
        def decision = ThreeDSDecisionCallbackDto.builder()
                .windowWidth(640)
                .windowHeight(480)
                .initiator("user")
                .browserUserAgent("agent")
                .browserTZ("tz")
                .browserScreenWidth(1024)
                .browserScreenHeight(768)
                .browserLanguage("ru-RU")
                .browserJavaEnabled(false)
                .browserIp("1.2.3.4")
                .browserColorDepth(2)
                .accept("application/json")
                .build()
        def transaction = getTransaction(transactionId, ThreeDSVersion.V2_0)
        when:
        def result = service.fill3DSDataFrom3DSDecision(decision, transactionId)
        then:
        1 * transactionService.getByCode(transactionId) >> Optional.of(transaction)
        1 * transactionService.upsert(_) >> Optional.of(transaction)
        assert Boolean.TRUE.equals(result.isExecuted)
    }

    def "Fill3DSDataFrom3DSDecisionMustThrownNotFoundException"() {
        given:
        def transactionId = ""
        when:
        service.fill3DSDataFrom3DSDecision(null, transactionId)
        then:
        1 * transactionService.getByCode(transactionId) >> Optional.empty()
        thrown(TransactionNotFoundException)
    }

    def "GetThreedsDecisionStatus"() {
        given:
        def transactionId = UUID.randomUUID().toString().concat("_vpay")
        def transaction = getTransaction(transactionId, ThreeDSVersion.V2_0_FRICTIONLESS)
        when:
        def result = service.getThreedsDecisionStatus(transactionId)
        then:
        1 * transactionService.getByCode(transactionId) >> Optional.of(transaction)
        assert Boolean.FALSE.equals(result.getIsChallengeFlow())
        assert Objects.isNull(result.getCReq())
        assert Objects.isNull(result.getMerchantUrl())
        assert Objects.isNull(result.getThreeDSSessionData())
        assert "SUCCESS".equals(result.getThreeDSDecisionStatus())
    }

    def "GetThreedsDecisionStatusMustThrownNotFoundException"() {
        given:
        def transactionId = ""
        when:
        service.getThreedsDecisionStatus(transactionId)
        then:
        1 * transactionService.getByCode(transactionId) >> Optional.empty()
        thrown(TransactionNotFoundException)
    }

    private Transaction getTransaction(String trId, ThreeDSVersion threeDSVersion) {
        return Transaction.builder()
                .transactionId(trId)
                .mst(Utils.getMerchantSite())
                .order(Utils.getOrder())
                .data(payload(trId, threeDSVersion))
                .build()
    }

    private TransactionPayload payload(String trId, ThreeDSVersion tdsVersion) {
        return TransactionPayload.builder()
                .transactionId(trId)
                .context(new HashMap<String, Serializable>())
                .paymentData(card(tdsVersion))
                .build()
    }

    private Card card(ThreeDSVersion tdsVersion) {
        return Card.builder()
                .additionalData(threeds(tdsVersion))
                .build()
    }

    private Threeds threeds(ThreeDSVersion version) {
        def tds = new Threeds()
        tds.setThreeDSData(data(version))
        return tds
    }

    private ThreeDSData data(ThreeDSVersion version) {
        def tdsd = new ThreeDSData()
        tdsd.setThreeDsVersion(version)
        return tdsd
    }
}
