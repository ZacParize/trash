package ru.vtb.tsp.ia.epay.apilistener.services.payment.card

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.CurrencyService
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Specification

class CardRefundServiceTest extends Specification {

    CurrencyService currencyService = Mock()
    TransactionService transactionService = Mock()
    PaymentVerifier paymentVerifier = new PaymentVerifier()

    def service = new CardRefundService(currencyService, transactionService, paymentVerifier)


    def "register refund when transaction or refundId is null then return empty result"(
            Transaction transaction, String refundId
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        when:
        def refundTransaction = service.registerRefund(transaction, refundId, amountRequest)
        then:
        assert refundTransaction.isEmpty()
        where:
        transaction                   | refundId
        null                          | "677676"
        null                          | null
        Transaction.builder().build() | null
    }

    def "register refund when amount paid amount refund and transaction not payed then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.INCORRECT_PARENT_TRANSACTION.message
        where:
        amountValue << [100D, 120D]

    }

    def "register refund when amount paid amount refund and order is already refunded then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.REFUNDED))
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.ORDER_REFUNDED_ERROR.message
        where:
        amountValue << [100D, 120D]
    }


    def "register refund when amount paid amount refund and order hasnt currency then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.empty()
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid amount refund and order has another currency then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency(455, "t", "u")
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid amount refund and transaction has another currency then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
                .withCurrency(Utils.getCurrency(455, "t", "u"))
        def oldTransaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.CURRENCY_IS_NOT_ALLOWED.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid amount refund and incorrect amount then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        amountRequest.setValue(-20d)
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.INCORRECT_AMOUNT.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid > amount refund and order has processing transactions then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        def oldTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get()
        transaction = transaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.IN_PROCESS.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid amount refund and order hasn't anything to refund then throw ServiceException"(
            Double amountValue
    ) {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(amountValue)
        transaction = transaction.withOrder(transaction.getOrder().withAmount(0d))
        def oldTransaction = Utils.getConfirmedTransaction().get()
        oldTransaction = oldTransaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID)
                .withAmount(0d))
                .withAmount(0d)
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.INCORRECT_AMOUNT.message
        where:
        amountValue << [100D, 120D]
    }

    def "register refund when amount paid > amount refund and amount is less than remaining refund amount then throw ServiceException"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
        transaction = transaction.withOrder(transaction.getOrder().withAmount(30d))
        def oldTransaction = Utils.getConfirmedTransaction().get()
        oldTransaction = oldTransaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID)
                .withAmount(30d))
                .withAmount(10d)
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.INCORRECT_AMOUNT.message
    }

    def "register refund when amount paid > amount refund and settings not allow to make partial refund then throw ServiceException"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
        transaction.getOrder().getMst().getParams().getCardParams().setEnablePartialRefund(false)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        oldTransaction = oldTransaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        1 * transactionService.getByOrderId(_) >> List.of(oldTransaction)
        1 * currencyService.getById(_) >> Optional.of(currency)
        def e = thrown(ServiceException)
        e.getMessage() == ApplicationException.PARTIAL_REFUND_NOT_SUPPORTED.message
    }

    def "register refund when amount paid > amount refund and all is ok then return transaction"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
        def oldTransaction = Utils.getConfirmedTransaction().get()
        oldTransaction = oldTransaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        def newTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT)
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        transactionService.getByOrderId(_) >> List.of(oldTransaction)
        currencyService.getById(_) >> Optional.of(currency)
        transactionService.createPartialCardRefund(_, _, _, _) >> newTransaction
        transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }

    def "register refund when amount paid = amount refund and all is ok then return transaction"() {
        given:
        def amountRequest = Utils.getAmountRequest()
        def transaction = Utils.getConfirmedTransaction().get()
                .withAmount(100d)
        def oldTransaction = Utils.getConfirmedTransaction().get()
        oldTransaction = oldTransaction.withOrder(oldTransaction.getOrder().withState(OrderState.PAID))
        def currency = Utils.getCurrency()
        def newTransaction = Utils.getNewTransaction(TransactionType.CARD_PAYMENT)
        when:
        service.registerRefund(transaction, "refundId", amountRequest)
        then:
        transactionService.getByOrderId(_) >> List.of(oldTransaction)
        currencyService.getById(_) >> Optional.of(currency)
        transactionService.createCardRefund(_, _, _, _) >> newTransaction
        transactionService.upsert(_ as Transaction) >> { Transaction obj -> Optional.of(obj) }
    }


}
