package ru.vtb.tsp.ia.epay.apilistener.services.payment.mirpay

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.AmountRequestDto
import ru.vtb.tsp.ia.epay.apilistener.dtos.requests.payments.RefundRequestDto
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ServiceException
import ru.vtb.tsp.ia.epay.apilistener.services.verifier.PaymentVerifier
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Specification

class MirPayRefundServiceTest extends Specification {

    TransactionService transactionService = Mock()
    PaymentVerifier mirPayVerifier = new PaymentVerifier()

    def service = new MirPayRefundService(transactionService, mirPayVerifier)

    def "success full refund process mir pay payment, full payment amount is 120D"() {
        given:
        def merchantSite = Utils.getMerchantSite()
        def refundId = UUID.randomUUID().toString()
        def refundAmount = 120D
        def mstId = merchantSite.getId()

        def order = Utils.getOrder().withMst(merchantSite)
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def mirPayRefundTr = Utils.getNewTransaction(TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND).get()
                .withAmount(refundAmount)
                .withState(TransactionState.NEW)
                .withOrder(order)
                .withMst(merchantSite)
        def refundRequestDto = RefundRequestDto.builder()
                .paymentId(mirPayTr.getTransactionId())
                .refundId(refundId)
                .amount(new AmountRequestDto(value: refundAmount, code: 'RUB'))
                .build()

        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayTr)

        when:
        service.registerRefund(refundRequestDto, mirPayTr, mstId)

        then:
        1 * transactionService.createMirPayRefund(mirPayTr.getOrder(), refundId) >> Optional.of(mirPayRefundTr)
        1 * transactionService.upsert(mirPayRefundTr) >> Optional.of(mirPayRefundTr)
    }

    def "success partial refund process mir pay payment, full payment amount is 120D, refund 100D"() {
        given:
        def merchantSite = Utils.getMerchantSite()
        def refundId = UUID.randomUUID().toString()
        def refundAmount = 100D
        def mstId = merchantSite.getId()

        def order = Utils.getOrder().withMst(merchantSite)
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def mirPayPartialRefundTr = Utils.getNewTransaction(TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND).get()
                .withAmount(refundAmount)
                .withState(TransactionState.NEW)
                .withOrder(order)
                .withMst(merchantSite)
        def refundRequestDto = RefundRequestDto.builder()
                .paymentId(mirPayTr.getTransactionId())
                .refundId(refundId)
                .amount(new AmountRequestDto(value: refundAmount, code: 'RUB'))
                .build()

        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayTr)

        when:
        service.registerRefund(refundRequestDto, mirPayTr, mstId)

        then:
        1 * transactionService.createPartialMirPayRefund(mirPayTr.getOrder(), refundAmount, refundId) >> Optional.of(mirPayPartialRefundTr)
        1 * transactionService.upsert(mirPayPartialRefundTr) >> Optional.of(mirPayPartialRefundTr)
    }

    def "success partial refund process mir pay payment, full payment amount is 120D,second refund 60D"() {
        given:
        def merchantSite = Utils.getMerchantSite()
        def refundId = UUID.randomUUID().toString()
        def refundAmount = 60D
        def mstId = merchantSite.getId()

        def order = Utils.getOrder().withMst(merchantSite)
        def mirPayPaymentTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def mirPayFirstRefundTr = Utils.getNewTransaction(TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND).get()
                .withAmount(50D)
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def mirPaySecondRefundTr = Utils.getNewTransaction(TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND).get()
                .withAmount(refundAmount)
                .withState(TransactionState.NEW)
                .withOrder(order)
                .withMst(merchantSite)
        def refundRequestDto = RefundRequestDto.builder()
                .paymentId(mirPayPaymentTr.getTransactionId())
                .refundId(refundId)
                .amount(new AmountRequestDto(value: refundAmount, code: 'RUB'))
                .build()

        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayPaymentTr, mirPayFirstRefundTr)

        when:
        service.registerRefund(refundRequestDto, mirPayPaymentTr, mstId)

        then:
        1 * transactionService.createPartialMirPayRefund(mirPayPaymentTr.getOrder(), refundAmount, refundId) >> Optional.of(mirPaySecondRefundTr)
        1 * transactionService.upsert(mirPaySecondRefundTr) >> Optional.of(mirPaySecondRefundTr)
    }

    def "throw exception for partial refund process mir pay payment, full payment amount is 120D, second refund 71D"() {
        given:
        def merchantSite = Utils.getMerchantSite()
        def refundId = UUID.randomUUID().toString()
        def refundAmount = 71D
        def mstId = merchantSite.getId()

        def order = Utils.getOrder().withMst(merchantSite)
        def mirPayPaymentTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def mirPayFirstRefundTr = Utils.getNewTransaction(TransactionType.PARTIAL_MIR_PAYMENT_WEB_BASED_REFUND).get()
                .withAmount(50D)
                .withState(TransactionState.CONFIRMED)
                .withOrder(order)
                .withMst(merchantSite)
        def refundRequestDto = RefundRequestDto.builder()
                .paymentId(mirPayPaymentTr.getTransactionId())
                .refundId(refundId)
                .amount(new AmountRequestDto(value: refundAmount, code: 'RUB'))
                .build()

        transactionService.getByOrderId(order.getOrderId()) >> List.of(mirPayPaymentTr, mirPayFirstRefundTr)

        when:
        service.registerRefund(refundRequestDto, mirPayPaymentTr, mstId)

        then:
        def exception = thrown(ServiceException)
        exception.getMessage() == "INCORRECT_AMOUNT"
    }
}
