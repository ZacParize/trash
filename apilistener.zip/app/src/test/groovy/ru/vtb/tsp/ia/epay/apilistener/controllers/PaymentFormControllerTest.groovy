package ru.vtb.tsp.ia.epay.apilistener.controllers

import groovy.json.JsonSlurper
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.dtos.responses.payments.MirPayTransactionResponseDto
import ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
import ru.vtb.tsp.ia.epay.apilistener.services.*
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType
import ru.vtb.tsp.ia.epay.apilistener.services.payment.card.ThreeDSDecisionService
import ru.vtb.tsp.ia.epay.apilistener.services.populators.MirPayTransactionResponseDtoPopulator
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.MirPay
import ru.vtb.tsp.ia.epay.core.entities.order.Order
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService

import java.nio.charset.StandardCharsets

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath

class PaymentFormControllerTest extends AbstractControllerTest {

    OrderServiceFacade orderServiceFacade = Mock()
    TransactionService transactionService = Mock()
    LinksService linksService = Mock()
    PaymentService paymentService = Mock()
    PublicKeyService publicKeyService = Mock()
    ValidationService validationService = Mock()
    ThreeDSDecisionService threeDSDecisionService = Mock()
    AuditResponseService auditResponseService = Mock()
    MirPayTransactionResponseDtoPopulator mirPayTransactionResponseDtoPopulator = Mock()

    def paymentController = new PaymentFormController(orderServiceFacade, transactionService,
            linksService, paymentService, publicKeyService, validationService,
            threeDSDecisionService, auditResponseService,
            mirPayTransactionResponseDtoPopulator)

    def setup() {
        initMock(paymentController)
    }

    def "get order"() {
        given:
        def orderCode = UUID.randomUUID().toString()
        def pKey = Utils.getPublicKeyData();
        def orderEntity = Utils.getOrder()
        def tx = Utils.getEmptyTransaction()

        orderServiceFacade.getByCode(orderCode) >> Optional.of(orderEntity)
        transactionService.getByOrderId(orderCode) >> [tx.get()]
        publicKeyService.getPublicKey() >> Optional.of(pKey)

        when:
        def response = mvc.perform(get("/api/v1/order/" + orderCode)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                order.orderId == 'MSTID-ORD-001'
                order.name == 'Test product'
                order.state == 'CREATED'
                order.backUrl == 'http://localhost'
                order.returnUrl == 'http://localhost/action.php?name=qwerty'
                transactions.paymentMethod == 'CARD_PAYMENT'
                transactions.transactionId == 'order-123'
                transactions.transactionStatus == 'NEW'
                crypto.publicKey = '1234567890'
            }
        }
    }

    def "get order with null returnUrl"() {
        given:
        def orderCode = UUID.randomUUID().toString()
        def pKey = Utils.getPublicKeyData();
        def orderEntity = Utils.getOrderWithNullReturnUrl()
        def tx = Utils.getEmptyTransaction()

        orderServiceFacade.getByCode(orderCode) >> Optional.of(orderEntity)
        transactionService.getByOrderId(orderCode) >> [tx.get()]
        publicKeyService.getPublicKey() >> Optional.of(pKey)

        when:
        def response = mvc.perform(get("/api/v1/order/" + orderCode)
                .contentType(MediaType.APPLICATION_JSON)
                .characterEncoding("UTF8"))
                .andDo(print())
                .andExpect(jsonPath('$.order.returnUrl').doesNotExist())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

    }

    def "get QR code"() {
        given:
        def uuid = UUID.randomUUID().toString()
        def qrString = "http://localhost"

        orderServiceFacade.getByCode(uuid) >> Optional.of(new Order(orderId: uuid))
        paymentService.getQr(uuid) >> Optional.of(qrString)

        when:
        def response = mvc.perform(
                get(String.format("/api/v1/order/%s/sbp-link", uuid))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                link == 'http://localhost'
            }
        }
    }

    def "get transaction"() {
        given:
        def uuid = UUID.randomUUID().toString()
        def tx = Utils.getConfirmedTransaction()

        transactionService.getByCode(uuid) >> tx

        when:
        def response = mvc.perform(
                get("/api/v1/transaction/" + uuid)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                paymentMethod == 'CARD_PAYMENT'
                transaction == 'order-123'
                transactionStatus == 'NEW'
                threeDS.isEnabled == true
                threeDS.version == null
            }
        }
    }

    def "pay by card"() {
        given:
        def uuid = UUID.randomUUID().toString()
        def paymentRequestDto = Utils.createTestCardPaymentRequestDto()
        def txResponse = Utils.getConfirmedTransaction()
        paymentRequestDto.setMstOrderCode(uuid)
        paymentService.registerPayment(paymentRequestDto, GatewayType.CARD) >> txResponse

        when:
        def response = mvc.perform(
                post(String.format("/api/v1/order/%s/transaction/card", uuid))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(paymentRequestDto)))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                paymentMethod == 'CARD'
                transactionId == uuid
                transactionStatus == 'NEW'
                threeDS.isEnabled == true
                threeDS.version == null
            }
        }
    }

    def "pay by saved card"() {
        given:
        def uuid = UUID.randomUUID().toString()
        def savedCardRequest = Utils.createTestSavedCardPaymentRequestDto()

        when:
        def response = mvc.perform(
                post(String.format("/api/v1/order/%s/transaction/saved-card", uuid))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(savedCardRequest)))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')
    }

    def "getThreeDS"() {
        given:
        def uuid = UUID.randomUUID().toString()
        def tx = Utils.getEmptyTransaction()

        transactionService.getByCode(uuid) >> tx

        when:
        def response = mvc.perform(
                get(String.format("/api/v1/transaction/%s/threeds", uuid))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')
    }

    def "get TransactionException with ErrorResponse"() {
        given:
        def txId = '123456-vpay'
        def transaction = Utils.createEmptyTransactionWithError();
        def json = '{"error":{"id":"10000000001","message":"UNKNOWN_ERROR","description":"Неизвестная ошибка",' +
                '"traceId":"merch-tx-id"}}'
        transactionService.getByCode(txId) >> transaction

        when:
        def response = mvc.perform(
                get("/api/v1/transaction/" + txId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding(StandardCharsets.UTF_8))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.BAD_REQUEST.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                error.id == ApplicationException.UNKNOWN_ERROR.getId()
                error.message == ApplicationException.UNKNOWN_ERROR.getMessage()
            }
        }
    }

    def "handle TransactionException with null in details"() {
        given:
        def txId = '123456-vpay'
        def transaction = Utils.createEmptyTransactionWithError();
        def json = '{"error":{"code":"10000000001","description":"Неизвестная ошибка","traceId":"merch-tx-id","details":null}}'
        transactionService.getByCode(txId) >> transaction

        when:
        def response = mvc.perform(
                get("/api/v1/transaction/" + txId)
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8"))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.BAD_REQUEST.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                error.id == ApplicationException.UNKNOWN_ERROR.getId()
                error.message == ApplicationException.UNKNOWN_ERROR.getMessage()
            }
        }
    }

    def "post - start payment by Mir Pay"() {
        given:
        def paymentData = MirPay.builder()
                .transactionCode("code123")
                .build()
        def mirPayTr = Utils.getConfirmedTransaction().get()
                .withType(TransactionType.MIR_PAYMENT_WEB_BASED)
                .withState(TransactionState.NEW)
                .withData(TransactionPayload.builder()
                        .paymentData(paymentData)
                        .build()
                )
        def mirPayPaymentRequestDto = Utils.createTestMirPayPaymentRequestDto()
        def orderCode = "12345678"
        def responseDto = MirPayTransactionResponseDto.builder()
            .paymentMethod('MIR_PAY' )
            .transactionCode(mirPayTr.getCode())
            .transactionStatus('NEW')
            .mirPayLink("test_link")
            .build()
        mirPayPaymentRequestDto.setMstOrderCode(orderCode)
        paymentService.registerMirPayPayment(mirPayPaymentRequestDto) >> Optional.of(mirPayTr)
        mirPayTransactionResponseDtoPopulator.populate(mirPayTr) >> responseDto

        when:
        def response = mvc.perform(
                post(String.format("/api/v1/order/%s/transaction/mir-pay", orderCode))
                        .contentType(MediaType.APPLICATION_JSON)
                        .characterEncoding("UTF8")
                        .content(mapper.writeValueAsString(mirPayPaymentRequestDto)))
                .andDo(print())
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                paymentMethod == 'MIR_PAY'
                transactionStatus == 'NEW'
                mirPayLink == 'test_link'
            }
        }
    }
}
