package ru.vtb.tsp.ia.epay.apilistener.services.mirpay

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Specification

class MirPayTransactionServiceTest extends Specification {

    TransactionService transactionService = Mock()
    MirPayTransactionService service = new MirPayTransactionService(transactionService)

    def "decline transaction if exist and update actual transactions"() {
        given:
        def mirPayTx = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get().withTransactionId("123401-vpay")
        def cardTx = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get().withTransactionId("123402-vpay")
        def sbpTx = Utils.getNewTransaction(TransactionType.SBP_PAYMENT).get().withTransactionId("123403-vpay")
        def orderTransactions = List.of(mirPayTx, cardTx, sbpTx)

        transactionService.upsert(mirPayTx.withState(TransactionState.DECLINED)) >> Optional.of(mirPayTx)

        when:
        def updatedTransactions = service.declineMirPayTransactions(orderTransactions)

        then:
        updatedTransactions.size() == 2
        updatedTransactions == List.of(cardTx, sbpTx)
    }

    def "doesn't decline transaction if it doesn't exist"() {
        given:
        def googleTx = Utils.getNewTransaction(TransactionType.GOOGLE_PAYMENT).get().withTransactionId("123401-vpay")
        def cardTx = Utils.getNewTransaction(TransactionType.CARD_PAYMENT).get().withTransactionId("123402-vpay")
        def sbpTx = Utils.getNewTransaction(TransactionType.SBP_PAYMENT).get().withTransactionId("123403-vpay")
        def orderTransactions = List.of(googleTx, cardTx, sbpTx)

        when:
        def updatedTransactions = service.declineMirPayTransactions(orderTransactions)

        then:
        updatedTransactions.size() == 3
        updatedTransactions == orderTransactions
        0 * transactionService.upsert(_ as Transaction)
    }

}
