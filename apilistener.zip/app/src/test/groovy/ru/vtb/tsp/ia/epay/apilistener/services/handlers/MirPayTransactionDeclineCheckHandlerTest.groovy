package ru.vtb.tsp.ia.epay.apilistener.services.handlers

import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Specification
import spock.lang.Unroll

class MirPayTransactionDeclineCheckHandlerTest extends Specification {

    TransactionService transactionService = Mock()
    MirPayTransactionDeclineCheckHandler handler = new MirPayTransactionDeclineCheckHandler(transactionService)

    @Unroll
    def "handle MIR_PAYMENT_WEB_BASED event and decline tr"() {
        given:
        def trCode = '123456'
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.NEW)
        transactionService.lockByCode(trCode) >> Optional.of(mirPayTr)

        when:
        handler.handle(trCode)

        then:
        1 * transactionService.upsert(mirPayTr.withState(TransactionState.DECLINED)) >> Optional.of(mirPayTr)
    }

    @Unroll
    def "no handle MIR_PAYMENT_WEB_BASED event with no suitable state"() {
        given:
        def trCode = '123456'
        def mirPayTr = Utils.getNewTransaction(TransactionType.MIR_PAYMENT_WEB_BASED).get()
                .withState(TransactionState.MIR_PAY_PAYMENT_CREATED)
        transactionService.lockByCode(trCode) >> Optional.of(mirPayTr)

        when:
        handler.handle(trCode)

        then:
        0 * transactionService.upsert(_ as Transaction) >> Optional.of(mirPayTr)
    }
}
