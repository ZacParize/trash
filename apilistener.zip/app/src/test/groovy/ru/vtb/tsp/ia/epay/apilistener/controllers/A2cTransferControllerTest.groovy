package ru.vtb.tsp.ia.epay.apilistener.controllers

import groovy.json.JsonSlurper
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContextHolder
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.filters.JwtTokenFilter
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService
import ru.vtb.tsp.ia.epay.apilistener.services.a2c.TransferDto

import ru.vtb.tsp.ia.epay.core.services.TransactionService

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post

class A2cTransferControllerTest extends AbstractControllerTest {

    static final String AUTH_HEADER_VALUE = "TESTMSTID1"

    OrderServiceFacade orderServiceFacade = Mock()
    KafkaService kafkaService = Mock()
    TransactionService transactionService = Mock()
    PaymentService paymentService =Mock()
    def a2cTransferController = new A2cTransferController(orderServiceFacade, kafkaService,
            paymentService)

    def setup() {
        initMock(a2cTransferController)
    }

    def "get transfer"() {
        given:
        def mstOrderId = 'MSTID-ORD-001'
        def mstId = 'testMstId'
        def order = Utils.getOrder()
        orderServiceFacade.getByMstOrderId(mstId, mstOrderId) >> Optional.of(order)
        setSecurityContext()

        when:
        def response = mvc.perform(get("/api/v1"
                + A2cTransferController.BASE_PATH + "/" + mstOrderId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'TRANSFER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def "success create transfer"() {
        given:
        def requestDto = Utils.createTransferCreationRequest()
        def order = Utils.getOrder()
        def mst = Utils.getMerchantSite()
        def tx = Utils.getEmptyTransaction()
        def dto = TransferDto.builder()
                .order(order)
                .transaction(tx.get())
                .build();
        transactionService.createCardPayment(order) >> tx
        paymentService.createA2cTransfer(requestDto, mst) >> Optional.of(dto)
        orderServiceFacade
                .getByMstOrderId(mst.getId(), requestDto.getOrderId()) >> Optional.empty()
        setSecurityContext()

        when:
        def response = mvc.perform(post("/api/v1"
                + A2cTransferController.INTERNAL_TRANSFER)
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId())
                .content(mapper.writeValueAsString(requestDto)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'TRANSFER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def setSecurityContext() {
        final var authentication = new UsernamePasswordAuthenticationToken(Utils.getMerchantSite(),
                null,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")))
        SecurityContextHolder.getContext().setAuthentication(authentication)
    }

}