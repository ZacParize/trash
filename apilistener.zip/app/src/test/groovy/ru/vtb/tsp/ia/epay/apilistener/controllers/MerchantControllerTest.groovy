package ru.vtb.tsp.ia.epay.apilistener.controllers

import groovy.json.JsonSlurper
import org.mapstruct.factory.Mappers
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.security.core.context.SecurityContextHolder
import ru.vtb.tsp.ia.epay.apilistener.Utils
import ru.vtb.tsp.ia.epay.apilistener.filters.JwtTokenFilter
import ru.vtb.tsp.ia.epay.apilistener.services.KafkaService
import ru.vtb.tsp.ia.epay.apilistener.services.OrderServiceFacade
import ru.vtb.tsp.ia.epay.apilistener.services.PaymentService
import ru.vtb.tsp.ia.epay.apilistener.services.ResponseService
import ru.vtb.tsp.ia.epay.apilistener.services.mappers.ControllerResponseMapper
import ru.vtb.tsp.ia.epay.apilistener.services.payment.GatewayType
import ru.vtb.tsp.ia.epay.core.domains.PaymentRequest
import ru.vtb.tsp.ia.epay.core.entities.merchant.site.MerchantSite
import ru.vtb.tsp.ia.epay.core.entities.order.Order
import ru.vtb.tsp.ia.epay.core.entities.order.SourceSystem
import ru.vtb.tsp.ia.epay.core.services.TransactionService
import spock.lang.Unroll

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post

class MerchantControllerTest extends AbstractControllerTest {

    static final String AUTH_HEADER_VALUE = "TESTMSTID1"
    static final String CURRENCY_VALUE_MSG = "must be greater than 0"
    static final String NOT_NULL_MSG = "must not be null"
    static final String CURRENCY_UNIT_MSG = "currency unit is not valid"
    static final String EMAIL_MSG = "must be a well-formed email address"
    static final String RETURN_URL_MSG = "URL is not valid"
    static final String AMOUNT_CODE = "amount.code"
    static final String AMOUNT_VALUE = "amount.value"
    static final String EMAIL_FIELD = "customer.email"
    static final String RETURN_URL_FIELD = "returnUrl"
    def payformUrl = "http://localhost:8989"

    OrderServiceFacade orderServiceFacade = Mock()
    TransactionService transactionService = Mock()
    PaymentService paymentService = Mock()
    KafkaService kafkaService = Mock()
    ControllerResponseMapper controllerResponseMapper = Mappers.getMapper(ControllerResponseMapper.class);
    def responseService = new ResponseService(paymentService, payformUrl, transactionService)
    def merchantController = new MerchantController(orderServiceFacade,
            paymentService, kafkaService, responseService, controllerResponseMapper)

    def setup() {
        initMock(responseService)
        initMock(merchantController)

    }

    def "get order"() {
        given:
        def mstOrderId = 'MSTID-ORD-001'
        def mstId = 'testMstId'
        def order = Utils.getOrder()
        orderServiceFacade.getByMstOrderId(mstId, mstOrderId) >> Optional.of(order)
        setSecurityContext()

        when:
        def response = mvc.perform(get("/api/v1/orders/" + mstOrderId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    def "success create order"() {
        given:
        def requestDto = Utils.createOrderCreationRequest()
        def order = Utils.getOrder()
        def mst = Utils.getMerchantSite()
        orderServiceFacade.create(requestDto, mst, SourceSystem.ECOM) >> Optional.of(order)
        orderServiceFacade
                .getByMstOrderId(mst.getId(), requestDto.getOrderId()) >> Optional.empty()
        setSecurityContext()

        when:
        def response = mvc.perform(post("/api/v1/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId())
                .content(mapper.writeValueAsString(requestDto)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == 'MSTID-ORD-001'
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == 5000D
                object.amount.code == 'RUB'
            }
        }
    }

    @Unroll
    def "create order with validation exception"() {
        given:
        def requestDto = Utils.getOrderCreationRequestDto(email,
                currency, currencyCode, returnUrl)
        def mst = Utils.getMerchantSite()
        orderServiceFacade.create(requestDto, mst, SourceSystem.ECOM) >> Optional.of(new Order())
        setSecurityContext()

        when:
        def response = mvc.perform(post("/api/v1/orders")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId())
                .content(mapper.writeValueAsString(requestDto)))
                .andReturn().response

        then:
        response.status == HttpStatus.BAD_REQUEST.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                error.id == ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
                        .VALIDATION_ERROR.getId()
            }
        }

        where:
        email           | currency | currencyCode | returnUrl           | fieldName        | validationMsg      | errorDetailsSize
        "test@_test,ru" | 300.50D  | "RUB"        | "http://localhost/" | EMAIL_FIELD      | EMAIL_MSG          | 1
        "test@test.ru"  | 300.50D  | "RUB"        | "localhost"         | RETURN_URL_FIELD | RETURN_URL_MSG     | 1
        "test@test.ru"  | 300.50D  | "RUB"        | "http://localhost"  | RETURN_URL_FIELD | RETURN_URL_MSG     | 1
        "test@test.ru"  | 300.50D  | "RUB"        | "ftp://localhost"   | RETURN_URL_FIELD | RETURN_URL_MSG     | 1
        "test@test.ru"  | 300.50D  | "RUD"        | "http://localhost/" | AMOUNT_CODE      | CURRENCY_UNIT_MSG  | 1
        "test@test.ru"  | -300.50D | "RUS"        | "http://localhost/" | AMOUNT_VALUE     | CURRENCY_VALUE_MSG | 2
        "tes90_ru"      | -300.50D | "AAA"        | "http://localhost/" | EMAIL_FIELD      | EMAIL_MSG          | 3
        null            | -300.50D | "AAA"        | "http://localhost/" | AMOUNT_VALUE     | CURRENCY_VALUE_MSG | 2
        null            | null     | "RUB"        | "http://localhost/" | AMOUNT_VALUE     | NOT_NULL_MSG       | 1
        null            | 100D     | "AAA"        | "http://localhost/" | AMOUNT_CODE      | NOT_NULL_MSG       | 1
    }

    def "success create refund"() {
        given:
        def dto = Utils.createTestRefundCreationRequestDto()
        def transaction = Utils.getEmptyTransaction()
        paymentService.registerRefund(_, _ as MerchantSite) >> transaction
        setSecurityContext()

        when:
        def response = mvc.perform(post("/api/v1/refunds")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE)
                .content(mapper.writeValueAsString(dto)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'REFUND'
                object.paymentId == 'order-123'
                object.orderId == 'MSTID-ORD-001'
                object.status.value == 'NEW'
            }
        }
    }

    @Unroll
    def "create refund with #msg"() {
        given:
        def dto = Utils.getRefundCreationRequestDto(currency, currencyCode)
        def transaction = Utils.getEmptyTransaction()
        paymentService.registerRefund(dto, _ as MerchantSite) >> transaction


        when:
        def response = mvc.perform(post("/api/v1/refunds")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE)
                .content(mapper.writeValueAsString(dto)))
                .andReturn().response

        then:
        response.status == HttpStatus.BAD_REQUEST.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                error.id == ru.vtb.tsp.ia.epay.apilistener.exceptions.ApplicationException
                        .VALIDATION_ERROR.getId()
            }
        }

        where:
        msg                      | currency | currencyCode | fieldName    | validationMsg      | errorDetailsSize
        "invalid currency value" | -300.50D | "RUB"        | AMOUNT_VALUE | CURRENCY_VALUE_MSG | 1
        "invalid currency code"  | 300.50D  | "RUD"        | AMOUNT_CODE  | CURRENCY_UNIT_MSG  | 1
        "invalid currency code"  | 200.50D  | "UUS"        | AMOUNT_CODE  | CURRENCY_UNIT_MSG  | 1
    }

    def "success complete 2 stage order"() {
        given:
        setSecurityContext()
        def paymentId = "testPaymentId"
        def tx = Utils.getEmptyTransaction()
        def order = Utils.getOrder()
        def dto = Utils.getTwoStagePaymentRequest(order.amount, order.currency.code)
        paymentService.registerPayment(_ as PaymentRequest, GatewayType.CARD) >> tx

        when:
        def response = mvc.perform(post("/api/v1/orders/complete/" + paymentId)
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, AUTH_HEADER_VALUE)
                .content(mapper.writeValueAsString(dto)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                type == 'ORDER'
                object.orderId == order.mstOrderId
                object.payUrl == 'http://localhost:8989?order-id=MSTID-ORD-001'
                object.amount.value == dto.amount.value
                object.amount.code == dto.amount.code
            }
        }
    }

    def setSecurityContext() {
        final var authentication = new UsernamePasswordAuthenticationToken(Utils.getMerchantSite(),
                null,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER")))
        SecurityContextHolder.getContext().setAuthentication(authentication)
    }

    def "disabled 2 stage payment when create order return error"() {
        given:
        def requestDto = Utils.createOrderCreationRequest()
        def mst = Utils.getMerchantSite()
        setSecurityContext()

        when:
        def response = mvc.perform(post("/api/v1/orders/preauth")
                .contentType(MediaType.APPLICATION_JSON)
                .header(JwtTokenFilter.MERCHANT_AUTHORIZATION, mst.getId())
                .content(mapper.writeValueAsString(requestDto)))
                .andReturn().response

        then:
        response.status == HttpStatus.BAD_REQUEST.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                error.id == '10000002'
                error.message == 'OPERATION_NOT_SUPPORTED_ERROR'
            }
        }
    }
}
