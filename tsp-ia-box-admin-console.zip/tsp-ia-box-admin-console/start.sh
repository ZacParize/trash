#!/bin/sh

sh /opt/update_cacerts.sh

java -XshowSettings:vm -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/dumps/main-app-oom.bin -Xlog:gc*:file=/dumps/main-app-gc.log::filecount=10,filesize=10m -jar \
  -XX:+UseContainerSupport -XX:MaxRAMPercentage=50 \
  -Dfile.encoding=UTF8 \
  -Djavax.net.ssl.trustStore=/opt/cacerts \
  -Djava.net.ssl.trustStorePassword="changeit" \
  /opt/app.jar