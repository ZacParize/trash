#!/bin/sh

if [ -z ${JVM_TRUSTSTORE_PATH+x} ]; then
  echo "JVM_TRUSTSTORE_PATH is unset, skipping its import";
else
  echo "JVM_TRUSTSTORE_PATH is set to '$JVM_TRUSTSTORE_PATH', trying to import it into cacerts"
  keytool -importkeystore \
    -srckeystore "$JVM_TRUSTSTORE_PATH" \
    -srcstorepass "$JVM_TRUSTSTORE_PASSWORD" \
    -srcstoretype PKCS12 \
    -destkeystore /opt/cacerts \
    -deststoretype JKS \
    -deststorepass "changeit" \
    -v
fi

echo "======= content of the pki directory $CA_SSL_DIRECTORY ======"
ls -lha $CA_SSL_DIRECTORY

echo "======= all .crt files will be imported from $CA_SSL_DIRECTORY ======"
for file in $CA_SSL_DIRECTORY/*.crt
do
  if [ -f "$file" ]; then
    filename=$(basename -- "$file")
    filename="${filename%%.*}"
    echo "=====> [$file] will be imported under the [$filename] alias"
    keytool -v -importcert -noprompt \
      -file "$file" \
      -alias $filename \
      -deststorepass "changeit" \
      -keystore  /opt/cacerts
  fi
done

echo "======= all .crt files have be imported into /opt/cacerts ======"
keytool -list -storepass "changeit" -keystore /opt/cacerts