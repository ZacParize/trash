CREATE table if not exists additional_site_params (
    id                      bigserial primary key,
    mdm_code                bigint not null,
    site_id                 varchar(64) not null,
    params                  jsonb
);

create index if not exists additional_site_params_site_id_idx
    on additional_site_params(site_id);

create index if not exists additional_site_params_mdm_code_idx
    on additional_site_params(mdm_code);