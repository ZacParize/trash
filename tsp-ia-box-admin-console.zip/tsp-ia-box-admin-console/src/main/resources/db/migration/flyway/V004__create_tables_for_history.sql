create table if not exists sites_status_history (
    status_id bigserial primary key not null,
    mst_id varchar(128) not null,
    "user" varchar(128) not null,
    created timestamptz not null,
    state varchar(64) not null,
    reason text
);

create index if not exists sites_status_history_mst_id_idx ON sites_status_history(mst_id);