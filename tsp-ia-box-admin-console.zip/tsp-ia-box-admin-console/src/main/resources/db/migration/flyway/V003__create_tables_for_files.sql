create table if not exists status_files (
    file_id bigserial primary key not null,
    status_id bigint,
    "user" varchar(128) not null,
    created timestamptz not null,
    ecm_id uuid not null
);

create index if not exists status_files_status_id_idx ON status_files(status_id);
create index if not exists status_files_css_id_idx ON status_files(ecm_id);