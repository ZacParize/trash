alter table if exists status_files
    add column if not exists file_name varchar(255);

alter table if exists status_files
    add column if not exists file_size bigint;