CREATE table if not exists openapi_codes (
    id                      bigserial primary key,
    mdm_code                bigint not null,
    org_code                varchar(32) not null unique,
    external_application_id varchar(255) not null
);

create index if not exists openapi_codes_external_application_id_idx
    on openapi_codes(external_application_id);