package ru.vtb.tsp.ia.epay.adminconsole.clients.epa;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;
import ru.vtb.tsp.ia.epay.adminconsole.dto.epa.EpaAccessToken;

/**
 * Client for EPA.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 27.06.2022
 */
public interface EpaClient extends Checker {

  /**
   * EPA Token create.
   *
   * @return - token
   */
  Optional<EpaAccessToken> getToken();

}
