package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SiteDto {

  private String id;
  private StateDto state;
  private OffsetDateTime created;
  private OffsetDateTime modified;
  private String url;
  private String name;
  private String login;
  private String externalApplicationId;
  private SiteParamsDto params;
  private String phone;
  private String email;
  private Boolean partnershipChannel;
  private String partnershipName;
  private String tessaTicketId;

}
