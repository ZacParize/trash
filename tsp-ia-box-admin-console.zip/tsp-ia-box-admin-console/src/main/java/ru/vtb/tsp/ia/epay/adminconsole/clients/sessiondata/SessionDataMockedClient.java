package ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Response;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.ObjectNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JsonUtils;

@Conditional(OnlyDevOrLocal.class)
@RequiredArgsConstructor
@Component
@Slf4j
public class SessionDataMockedClient implements SessionDataClient {

  private static final String DATA = "{\n"
      + "    \"k3_frkk_service@region.vtb.ru\": {\n"
      + "        \"client\": \"{\\\"organization\\\":{\\\"mdmCode\\\":\\\"1258477387\\\","
      + "\\\"mdmPkbClient\\\":\\\"1258477387\\\",\\\"slxId\\\":\\\"L6UJ9A00TZ32\\\","
      + "\\\"fullName\\\":\\\"АКЦИОНЕРНОЕ ОБЩЕСТВО \\\\\\\"ВРЕМЯ ВПЕРЕД\\\\\\\"\\\","
      + "\\\"shortName\\\":\\\"АО \\\\\\\"ВРЕМЯ ВПЕРЕД\\\\\\\"\\\",\\\"inn\\\":\\\"7204752509\\\","
      + "\\\"ogrn\\\":\\\"1111000000451\\\",\\\"isInBlackList\\\":false,"
      + "\\\"isInYellowList\\\":false,\\\"isInRedList\\\":false,"
      + "\\\"clientTypeCode\\\":\\\"Client\\\",\\\"clientTypeName\\\":\\\"Клиент\\\","
      + "\\\"clientSegmentId\\\":null,\\\"clientSegmentName\\\":null},"
      + "\\\"representative\\\":null}\",\n"
      + "        \"currentProcess\": \"{\\\"serviceId\\\":\\\"1372\\\","
      + "\\\"serviceAccount\\\":\\\"k3_frkk_service@region.vtb.ru\\\","
      + "\\\"nextServiceId\\\":\\\"1434\\\",\\\"requestId\\\":null,"
      + "\\\"productId\\\":\\\"79302ff3-6e26-450e-b6c5-0ce542cb0d01\\\","
      + "\\\"processName\\\":\\\"acquiringAdminConsole\\\",\\\"leadId\\\":null,"
      + "\\\"urlAttributes\\\":{}}\"\n"
      + "    }\n"
      + "}";

  @Qualifier("epaIgClient")
  private final EpaClient epaClient;

  @Override
  public Optional<SessionData> getSessionData(String token) {
    try {
      final var data = JsonUtils.mapper().readValue(DATA, Response.class);
      return extractSessionData(data);
    } catch (JsonProcessingException e) {
      log.error("Response extraction error", e);
      return Optional.empty();
    }
  }

  private Optional<SessionData> extractSessionData(Response response) {
    return response.values()
        .stream()
        .findFirst()
        .map(s -> {
          if (Objects.isNull(s.getRawClient())) {
            throw new ObjectNotFoundException();
          }
          try {
            final var client = JsonUtils.mapper().readValue(s.getRawClient(), Client.class);
            s.setClient(client);
            return s;
          } catch (JsonProcessingException e) {
            log.error("SessionData extraction error", e);
            return null;
          }
        });
  }


  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("SessionDataMockedClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
