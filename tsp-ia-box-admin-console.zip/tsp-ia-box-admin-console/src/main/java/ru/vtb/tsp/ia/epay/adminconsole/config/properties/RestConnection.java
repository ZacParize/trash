package ru.vtb.tsp.ia.epay.adminconsole.config.properties;

import java.io.Serializable;
import lombok.Data;

@Data
public class RestConnection implements Serializable {

  private String host;
  private Boolean sslEnabled;
  private Ssl ssl;
  private Boolean tykEnabled;

}
