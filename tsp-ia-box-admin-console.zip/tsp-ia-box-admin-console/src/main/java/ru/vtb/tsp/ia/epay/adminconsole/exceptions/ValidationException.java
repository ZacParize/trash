package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 21.07.2022
 */
@Data
public class ValidationException extends IdentifiedException {

  private String field;
  private String description = "Ошибка валидации запроса";
  private final Integer httpCode = 400;
  private final String id = "0120005035";
  private final String errorMessage = "Validation error";

  public ValidationException(String description, String field) {
    this.field = field;
    if (StringUtils.isNotEmpty(description)) {
      this.description += " [" + description + "]";
    }
  }
}
