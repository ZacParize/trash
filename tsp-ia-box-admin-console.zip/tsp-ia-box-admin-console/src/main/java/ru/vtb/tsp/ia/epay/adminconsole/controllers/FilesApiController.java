package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.api.FilesApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.EcmService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.FileUtils;

@RestController
@RequiredArgsConstructor
@RequestMapping
@Slf4j
public class FilesApiController implements FilesApi {

  private final EcmService ecmService;

  @Override
  public ResponseEntity<FileMetaInfoDto> uploadFile(MultipartFile file) {
    return ecmService.uploadFile(file).map(ResponseEntity::ok)
        .orElse(ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<Resource> downloadFile(UUID uuid) {
    return ecmService.downloadFile(uuid)
        .map(resource -> {
          final var disp = FileUtils
              .createContentDisposition(resource.getFilename());
          return ResponseEntity.ok()
              .contentType(MediaType.APPLICATION_OCTET_STREAM)
              .header(HttpHeaders.CONTENT_DISPOSITION, disp.get().toString())
              .body(resource);
        })
        .orElse(ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<Void> deleteFile(UUID ecmUuid) {
    ecmService.deleteFiles(ecmUuid);
    return ResponseEntity.ok().build();
  }
}
