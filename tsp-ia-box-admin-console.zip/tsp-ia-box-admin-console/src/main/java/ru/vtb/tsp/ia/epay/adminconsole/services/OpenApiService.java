package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsRequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.LegalEntityDto;

public interface OpenApiService {

  Optional<LegalEntityDto> createLegalEntity(String jwt);

  Optional<CredentialsResponseDto> createCredentials(String jwt, CredentialsRequestDto requestDto);

}
