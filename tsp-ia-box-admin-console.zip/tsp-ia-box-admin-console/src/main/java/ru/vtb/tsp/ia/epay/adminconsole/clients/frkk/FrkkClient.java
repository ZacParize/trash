package ru.vtb.tsp.ia.epay.adminconsole.clients.frkk;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.UserInfo;

public interface FrkkClient extends Checker {

  @Deprecated
  Optional<UserInfo> getUserInfo(String token);
  Optional<UserInfo> getUserInfo();
}
