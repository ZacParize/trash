package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.http.MediaType.APPLICATION_OCTET_STREAM_VALUE;
import static org.springframework.http.MediaType.MULTIPART_FORM_DATA_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.headers.Header;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.UUID;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserGroup;

@Validated
@Tag(name = "Files", description = "Api for working with files")
@RestController
@RequestMapping
@SecurityRequirement(name = "bearerAuth")
public interface FilesApi {

  @Operation(operationId = "downloadFile", method = "GET", tags = "Files",
      description = "Returns site finded by merchant site id",
      summary = "Get file"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = Resource.class),
                  mediaType = APPLICATION_OCTET_STREAM_VALUE
              )
          },
              headers = {
                  @Header(name = HttpHeaders.CONTENT_DISPOSITION, description = "File name"),
                  @Header(name = HttpHeaders.CONTENT_LENGTH, description = "File size"),
                  @Header(name = HttpHeaders.CONTENT_TYPE, description = "application/octet-stream")
              }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Site is not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @GetMapping(path = "/api/v1/file/{ecmUuid}",
      produces = APPLICATION_OCTET_STREAM_VALUE
  )
  default ResponseEntity<Resource> downloadFile(@PathVariable("ecmUuid") UUID uuid) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "uploadFile", method = "POST", tags = "Files",
      description = "Upload file",
      summary = "Upload file to content storage system"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = FileMetaInfoDto.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      })
  }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PostMapping(path = "/api/v1/file",
      consumes = MULTIPART_FORM_DATA_VALUE,
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<FileMetaInfoDto> uploadFile(
      @RequestBody MultipartFile file) {
    return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).build();
  }

  @Operation(operationId = "deleteFile", method = "DELETE", tags = "Files",
      description = "Delete file",
      summary = "Delete file from content storage system"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK"),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      })
  }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @DeleteMapping(path = "/api/v1/file/{ecmUuid}")
  default ResponseEntity<Void> deleteFile(@PathVariable("ecmUuid") UUID uuid) {
    return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).build();
  }
}
