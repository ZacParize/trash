package ru.vtb.tsp.ia.epay.adminconsole.dto.ecm;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties
public class FileInfoDto {

  private String hashSum;
  private String name;
  private Integer size;
  private String type;
  private OffsetDateTime uploadDate;
  private OffsetDateTime expirationDate;
  private UUID uuid;

}
