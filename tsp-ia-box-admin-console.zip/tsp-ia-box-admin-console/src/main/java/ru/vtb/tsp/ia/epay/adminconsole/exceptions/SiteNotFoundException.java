package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 21.07.2022
 */
@Data
public class SiteNotFoundException extends IdentifiedException {

  private final Integer httpCode = 404;
  private final String id = "0120005031";
  private final String errorMessage = "Site is not found";
  private final String description = "Сайт не зарегистрирован за данным ТСП";

}
