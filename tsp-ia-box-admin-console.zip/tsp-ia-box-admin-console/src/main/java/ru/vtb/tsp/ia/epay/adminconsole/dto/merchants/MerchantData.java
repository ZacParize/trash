package ru.vtb.tsp.ia.epay.adminconsole.dto.merchants;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.06.2022
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantData {

  private Long mdmCode;
  private Long mdmOsnCode;
  private Long mdmPkbCode;
  private String name;

}
