package ru.vtb.tsp.ia.epay.adminconsole.dto.openapi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RequestDto {
  @JsonProperty("reason_create")
  String reasonCreate;

  @JsonProperty("information_system_name")
  String informationSystemName;

  @JsonProperty("client_type")
  String clientType;

  @JsonProperty("org_id")
  String orgId;

  @JsonProperty("org_code")
  String orgCode;

  @JsonProperty("external_application_name")
  String externalApplicationName;

  @JsonProperty("application_type")
  String applicationType;

  @JsonProperty("external_application_email")
  String[] externalApplicationEmail;
}
