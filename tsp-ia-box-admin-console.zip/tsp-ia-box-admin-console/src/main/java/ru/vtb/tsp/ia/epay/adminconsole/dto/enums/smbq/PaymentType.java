package ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum PaymentType {
  SBP(1, "СБП"),
  CARD(2, "Карта");

  private final int id;

  private final String description;
}
