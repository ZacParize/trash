package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

@Data
public class FileDeleteAuthErrorException extends IdentifiedException {

  private final Integer httpCode = 401;
  private final String id = "0120005043";
  private final String errorMessage = "auth_error";
  private final String description = "";

}
