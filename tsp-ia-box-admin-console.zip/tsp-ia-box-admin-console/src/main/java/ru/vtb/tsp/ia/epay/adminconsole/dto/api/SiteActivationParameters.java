package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 13.07.2022
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SiteActivationParameters {

  private String tessaTicketId;

}
