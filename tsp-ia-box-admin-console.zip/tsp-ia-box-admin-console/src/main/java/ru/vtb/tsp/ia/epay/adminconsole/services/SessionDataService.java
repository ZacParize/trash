package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.List;
import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;

public interface SessionDataService {

  List<Long> getMdmCodes(String jwt);

  Optional<Client> getClient(String jwt);

}
