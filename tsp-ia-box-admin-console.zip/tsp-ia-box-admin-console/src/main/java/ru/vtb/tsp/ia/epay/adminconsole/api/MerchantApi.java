package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantNameDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantShortDto;

@Validated
@Tag(name = "Merchant", description = "Api for working with merchant")
@SecurityRequirement(name = "bearerAuth")
public interface MerchantApi {

  @Operation(
      operationId = "getMerchant", method = "GET", tags = "Merchant",
      description = "Get merchant",
      summary = "Get merchant"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = MerchantShortDto.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      })
  })
  @GetMapping(path = "/api/v1/merchant", produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<MerchantShortDto> getMerchant() {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "postMerchant", method = "POST", tags = "Merchant",
      description = "Create new merchant",
      summary = "Create new merchant"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = MerchantShortDto.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @PostMapping(path = "/api/v1/merchant",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<MerchantShortDto> postMerchant() {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
  }

  @Operation(
      operationId = "getMerchantName", method = "GET", tags = "Merchant",
      description = "Get merchant name",
      summary = "Get merchant name"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = MerchantNameDto.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      })
  })
  @GetMapping(path = "/api/v1/merchant/name", produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<MerchantNameDto> getMerchantName() {
    return ResponseEntity.notFound().build();
  }

}