package ru.vtb.tsp.ia.epay.adminconsole.clients.epa.am;

import static ru.vtb.tsp.ia.epay.adminconsole.config.CacheConfig.FIVE_MINUTES_EPA_AM_CACHE;

import java.time.LocalDateTime;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.epa.EpaAccessToken;

@Conditional(OnlyDevOrLocal.class)
@Component
@Qualifier("epaAmClient")
public class EpaAmMockClient implements EpaClient {

  @Override
  @Cacheable(FIVE_MINUTES_EPA_AM_CACHE)
  public Optional<EpaAccessToken> getToken() {
    return Optional.of(EpaAccessToken.builder()
        .accessToken("EpaAmAccessToken " + LocalDateTime.now())
        .tokenType("access")
        .expiresIn(System.currentTimeMillis() + 15000)
        .build());
  }

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("EpaAmMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
