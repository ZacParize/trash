package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.dto.db.AdditionalSiteParamsData;
import ru.vtb.tsp.ia.epay.adminconsole.entities.AdditionalSiteParams;
import ru.vtb.tsp.ia.epay.adminconsole.repositories.AdditionalSiteParamsRepository;
import ru.vtb.tsp.ia.epay.adminconsole.services.AdditionalSiteParamsService;

@Service
@RequiredArgsConstructor
public class AdditionalSiteParamsServiceImpl implements AdditionalSiteParamsService {

  private final AdditionalSiteParamsRepository repository;

  @Override
  public Map<String, AdditionalSiteParams> getByMdmCode(Long mdmCode) {
    return repository
        .findAll((root, criteriaQuery, criteriaBuilder)
            -> criteriaBuilder.equal(root.get("mdmCode"), mdmCode))
        .stream()
        .map(params -> Map.entry(params.getSiteId(), params))
        .collect(Collectors.toMap(Entry::getKey, Entry::getValue));
  }

  @Override
  public Optional<AdditionalSiteParams> getBySiteId(String siteId) {
    return repository
        .findOne((root, criteriaQuery, criteriaBuilder)
            -> criteriaBuilder.equal(root.get("siteId"), siteId));
  }

  @Override
  public Optional<AdditionalSiteParams> save(AdditionalSiteParams params) {
    return Optional.of(repository.save(params));
  }

  @Override
  public Optional<AdditionalSiteParams> updateOrSave(AdditionalSiteParams params) {
    getBySiteId(params.getSiteId()).ifPresent(siteParam -> {
      params.setId(siteParam.getId());
      fillParams(siteParam, params);
      fillDto(siteParam.getParams(), params.getParams());
    });
    return save(params);
  }

  private void fillParams(AdditionalSiteParams old, AdditionalSiteParams newParams) {
    newParams.setSiteId(Objects.nonNull(newParams.getSiteId())
        ? newParams.getSiteId()
        : old.getSiteId());
    newParams.setMdmCode(Objects.nonNull(newParams.getMdmCode())
        ? newParams.getMdmCode()
        : old.getMdmCode());
  }

  private void fillDto(AdditionalSiteParamsData old, AdditionalSiteParamsData newParams) {
    newParams.setEmail(Objects.nonNull(newParams.getEmail())
        ? newParams.getEmail()
        : old.getEmail());
    newParams.setPartnershipName(Objects.nonNull(newParams.getPartnershipName())
        ? newParams.getPartnershipName()
        : old.getPartnershipName());
    newParams.setPartnershipChannel(Objects.nonNull(newParams.getPartnershipChannel())
        ? newParams.getPartnershipChannel()
        : old.getPartnershipChannel());
    newParams.setPhone(Objects.nonNull(newParams.getPhone())
        ? newParams.getPhone()
        : old.getPhone());
  }
}
