package ru.vtb.tsp.ia.epay.adminconsole.clients.merchantapi;

import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;

public interface MerchantApiClient extends Checker {

}
