package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.clients.transactions.TransactionsClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.OrderService;

@Service
@RequiredArgsConstructor
public class OrderServiceImpl implements OrderService {

  private final TransactionsClient client;

  @Override
  public Page<OrderDto> getOrders(String orderTransactionCode, List<OrderStatus> status,
      List<UUID> merchantSite, Double amountMin, Double amountMax, int page, int size,
      ZonedDateTime fromDate, ZonedDateTime beforeDate, List<PaymentType> paymentType, String sort,
      SortOrder order, List<SourceSystemSearchFields> sourceSystem, String token) {

    return client.getOrders(orderTransactionCode, status, merchantSite, amountMin, amountMax,
        page, size, fromDate, beforeDate, paymentType, sort, order, sourceSystem, token);
  }

  @Override
  public FilterDictionariesDto getFilterDictionaries(String token) {
    return client.getFilterDictionaries(token);
  }
}
