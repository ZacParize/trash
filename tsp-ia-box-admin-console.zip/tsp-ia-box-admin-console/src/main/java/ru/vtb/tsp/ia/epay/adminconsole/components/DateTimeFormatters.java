package ru.vtb.tsp.ia.epay.adminconsole.components;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 27.06.2022
 */
public class DateTimeFormatters {

  public static final DateTimeFormatter DATE_TIME_WITH_SPACE =
      new DateTimeFormatterBuilder()
          .appendPattern("yyyy-MM-dd HH:mm:ss.SSS")
          .toFormatter();
}
