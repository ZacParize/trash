package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;
import ru.vtb.tsp.ia.epay.adminconsole.repositories.StatusFilesRepository;
import ru.vtb.tsp.ia.epay.adminconsole.services.StatusFileService;
import ru.vtb.tsp.ia.epay.adminconsole.specifications.StatusFileMetaDataSpecification;

@Service
@RequiredArgsConstructor
public class StatusFileServiceImpl implements StatusFileService {

  @Value("${status-files.unlinked-files.lifetime}")
  private Long lifeTime;
  private final StatusFilesRepository repository;

  @Override
  public List<StatusFileMetaData> findByCssUuids(List<UUID> uuids) {
    if (CollectionUtils.isEmpty(uuids)) {
      return Collections.emptyList();
    }
    return repository.findAll(StatusFileMetaDataSpecification.findByCssUuids(uuids));
  }

  @Override
  public List<StatusFileMetaData> findByCssUuid(UUID uuid) {
    return repository.findAll(StatusFileMetaDataSpecification.findByCssUuid(uuid));
  }

  @Override
  public List<StatusFileMetaData> findByStatusId(Long statusId) {
    return repository.findAll(StatusFileMetaDataSpecification.findByStatusId(statusId));
  }

  @Override
  public List<StatusFileMetaData> findExpiredUnlinkedFiles() {
    return repository.findExpiredUnlinkedFiles(lifeTime);
  }

  @Override
  public Optional<StatusFileMetaData> save(StatusFileMetaData file) {
    return Optional.of(repository.save(file));
  }

  @Override
  public List<UUID> saveAll(List<StatusFileMetaData> files) {
    return repository.saveAll(files)
        .stream()
        .map(StatusFileMetaData::getEcmId)
        .collect(Collectors.toList());
  }

  @Override
  public boolean deleteFiles(UUID... ecmUUIDs) {
    try {
      repository.deleteMetaByEcmIds(List.of(ecmUUIDs));
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  public List<FileMetaInfoDto> fromListToListDto(List<StatusFileMetaData> data) {
    if (CollectionUtils.isEmpty(data)) {
      return Collections.emptyList();
    }
    return data.stream()
        .map(this::mapToFileMetaInfoDto)
        .collect(Collectors.toList());
  }

  public FileMetaInfoDto mapToFileMetaInfoDto(StatusFileMetaData data) {
    return FileMetaInfoDto.builder()
        .fileSize(data.getFileSize())
        .ecmUuid(data.getEcmId())
        .fileName(data.getFileName())
        .build();
  }
}
