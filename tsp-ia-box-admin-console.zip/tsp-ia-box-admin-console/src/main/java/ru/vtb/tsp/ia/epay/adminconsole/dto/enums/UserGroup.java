package ru.vtb.tsp.ia.epay.adminconsole.dto.enums;

import static ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserRole.FRKK_ADMIN_SMBQ_PARTNERS;
import static ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserRole.FRKK_TECH_SUP_SMB;
import static ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserRole.SMBQ_ADMIN_SMBQ_PARTNERS;
import static ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserRole.SMBQ_TECH_SUP_SMB;

import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UserGroup {

  DEFAULT(List.of(
      FRKK_TECH_SUP_SMB,
      SMBQ_TECH_SUP_SMB,
      FRKK_ADMIN_SMBQ_PARTNERS,
      SMBQ_ADMIN_SMBQ_PARTNERS)
  ),

  NONE(Collections.emptyList());

  private final List<UserRole> roles;
}
