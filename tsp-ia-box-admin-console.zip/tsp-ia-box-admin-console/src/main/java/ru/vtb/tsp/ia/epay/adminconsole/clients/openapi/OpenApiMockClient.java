package ru.vtb.tsp.ia.epay.adminconsole.clients.openapi;

import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Optional;
import java.util.UUID;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.consts.AuditEvents;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.RequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.ResponseDto;

@Conditional(OnlyDevOrLocal.class)
@Component
public class OpenApiMockClient implements OpenApiClient {

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_POST_PORTAL_APPLICATION)
  public Optional<ResponseDto> postApplication(RequestDto requestDto) {
    return Optional.of(ResponseDto.builder()
        .application_Type(requestDto.getApplicationType())
        .clientId(UUID.randomUUID().toString())
        .clientName("ClientName")
        .clientSecret(Base64.getEncoder().encodeToString(UUID.randomUUID().toString().getBytes(
            StandardCharsets.UTF_8)))
        .clientType(requestDto.getClientType())
        .externalApplicationName(requestDto.getExternalApplicationName())
        .externalApplicationEmail(requestDto.getExternalApplicationEmail())
        .externalApplicationId(UUID.randomUUID().toString())
        .orgCode(requestDto.getOrgCode())
        .orgId(requestDto.getOrgId())
        .status("ACTIVE")
        .reasonBlocked("---")
        .build());
  }

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("OpenApiMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
