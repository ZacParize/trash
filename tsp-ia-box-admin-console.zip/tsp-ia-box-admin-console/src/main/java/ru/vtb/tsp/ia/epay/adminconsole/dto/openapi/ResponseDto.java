package ru.vtb.tsp.ia.epay.adminconsole.dto.openapi;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ResponseDto {

  @JsonProperty("client_type")
  String clientType;

  @JsonProperty("org_id")
  String orgId;

  @JsonProperty("org_code")
  String orgCode;

  @JsonProperty("external_application_name")
  String externalApplicationName;

  @JsonProperty("application_type")
  String application_Type;

  @JsonProperty("external_application_email")
  String [] externalApplicationEmail;

  @JsonProperty("external_application_id")
  String externalApplicationId;

  @JsonProperty("client_id")
  String clientId;

  @JsonProperty("client_secret")
  String clientSecret;

  @JsonProperty("client_name")
  String clientName;

  @JsonProperty("status")
  String status;

  @JsonProperty("reason_blocked")
  String reasonBlocked;

}
