package ru.vtb.tsp.ia.epay.adminconsole.config.properties;

import java.util.EnumMap;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Data
@Component
@Configuration
@ConfigurationProperties(prefix = "integrations")
public class Integrations {

  private EnumMap<RestClient, RestConnection> rests;

  public RestConnection getConnection(RestClient client) {
    return rests.getOrDefault(client, null);
  }
}
