package ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata;

import java.util.HashMap;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 30.06.2022
 */
public class Response extends HashMap<String, SessionData> {

}
