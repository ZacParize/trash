package ru.vtb.tsp.ia.epay.adminconsole.repositories;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;

@Repository
public interface StatusFilesRepository extends JpaRepository<StatusFileMetaData, Long>,
    JpaSpecificationExecutor<StatusFileMetaData> {

  @Query(value = "delete from status_files f where f.ecm_id in (:ecmId)", nativeQuery = true)
  void deleteMetaByEcmIds(Collection<UUID> ecmId);

  @Query(value = "select * from status_files f where f.status_id is null "
      + "and f.created < current_timestamp(0) - (:lifetime * INTERVAL '1 seconds')",
      nativeQuery = true)
  List<StatusFileMetaData> findExpiredUnlinkedFiles(Long lifetime);
}
