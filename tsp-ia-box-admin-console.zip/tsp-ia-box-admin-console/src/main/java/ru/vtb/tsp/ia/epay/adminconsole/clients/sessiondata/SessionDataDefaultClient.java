package ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Response;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.ObjectNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JsonUtils;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@Conditional(OnlyNotDevAndLocal.class)
@RequiredArgsConstructor
@Component
@Slf4j
public class SessionDataDefaultClient implements SessionDataClient {

  private static final String INTEGRATION_NAME = "session-data";
  private static final String SESSION_ID = "sessionId";
  private static final String ENDPOINT = "/session/{" + SESSION_ID + "}";

  @Qualifier("epaIgClient")
  private final EpaClient epaClient;
  @Qualifier("sessionDataClient")
  private final RestTemplate restTemplate;
  private final Integrations integrations;

  @Override
  public Optional<SessionData> getSessionData(String token) {
    return epaClient.getToken().map(epaAccessToken -> {
      final var httpHeaders = new HttpHeaders();
      httpHeaders.setBearerAuth(epaAccessToken.getAccessToken());
      final var entity = new HttpEntity<>(null, httpHeaders);
      final var sessionId = JwtTokenUtils.extractCtxi(token);
      log.info("Call session data [{}: {}]", SESSION_ID, sessionId);
      final String url = integrations.getConnection(RestClient.SESSION_DATA).getHost() + ENDPOINT;
      final var response = restTemplate.exchange(url, HttpMethod.GET, entity, Response.class,
          sessionId);
      if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
        return extractSessionData(response.getBody()).orElse(null);
      }
      return null;
    });
  }

  private Optional<SessionData> extractSessionData(Response response) {
    return response.values()
        .stream()
        .findFirst()
        .map(s -> {
          if (Objects.isNull(s.getRawClient())) {
            throw new ObjectNotFoundException();
          }
          try {
            final var client = JsonUtils.mapper().readValue(s.getRawClient(), Client.class);
            s.setClient(client);
            return s;
          } catch (JsonProcessingException e) {
            log.error("SessionData extraction error", e);
            return null;
          }
        });
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    try {
      final var httpHeaders = new HttpHeaders();
      final var entity = new HttpEntity<>(null, httpHeaders);
      final String url = integrations.getConnection(RestClient.SESSION_DATA).getHost() + ENDPOINT;

      restTemplate.exchange(url, HttpMethod.GET, entity, Response.class, "sessionId");
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }
}
