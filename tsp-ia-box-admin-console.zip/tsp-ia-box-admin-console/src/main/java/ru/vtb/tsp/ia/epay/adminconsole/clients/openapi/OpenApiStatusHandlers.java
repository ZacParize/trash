package ru.vtb.tsp.ia.epay.adminconsole.clients.openapi;

import java.util.Optional;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.clients.StatusHandler;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.OpenApiEpaInternalErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.OpenApiForbiddenException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.OpenApiKeyAuthErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.OpenApiOrgCodeIsNotUniqueException;

public class OpenApiStatusHandlers {

  public static <T> StatusHandler<Optional<T>> handler(ResponseEntity<T> response) {
    return () -> {
      switch (response.getStatusCode()) {
        case BAD_REQUEST: throw new OpenApiOrgCodeIsNotUniqueException();
        case NOT_FOUND: throw new OpenApiKeyAuthErrorException();
        case FORBIDDEN: throw new OpenApiForbiddenException();
        case INTERNAL_SERVER_ERROR: throw new OpenApiEpaInternalErrorException();
        default: {
          if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
            return Optional.of(response.getBody());
          }
          throw new IdentifiedException();
        }
      }
    };
  }

  public static <T> StatusHandler<Optional<T>> exceptionHandler (
      HttpClientErrorException exception, Class<T> cls) {
    return () -> {
      switch (exception.getStatusCode()) {
        case BAD_REQUEST: throw new OpenApiOrgCodeIsNotUniqueException();
        case NOT_FOUND: throw new OpenApiKeyAuthErrorException();
        case FORBIDDEN: throw new OpenApiForbiddenException();
        case INTERNAL_SERVER_ERROR: throw new OpenApiEpaInternalErrorException();
        default: {
          throw new IdentifiedException();
        }
      }
    };
  }

}
