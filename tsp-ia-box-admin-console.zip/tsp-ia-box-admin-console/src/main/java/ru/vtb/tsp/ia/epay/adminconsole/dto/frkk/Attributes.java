package ru.vtb.tsp.ia.epay.adminconsole.dto.frkk;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Attributes {
    @JsonProperty("trm_code")
    public String trmCode;
    @JsonProperty("short_trm_name")
    public String shortTrmName;
    @JsonProperty("full_trm_name")
    public String fullTrmName;
    @JsonProperty("last_name")
    public String lastName;
    @JsonProperty("generation_qualifier")
    public String generationQualifier;
    @JsonProperty("tp_code")
    public String tpCode;
    public String title;
    @JsonProperty("middle_name")
    public String middleName;
    public String login;
    @JsonProperty("employee_type")
    public String employeeType;
    public String domain;
    public String name;
    @JsonProperty("employee_number")
    public String employeeNumber;
    public String company;
    public String region;
    public String department;
    @JsonProperty("first_name")
    public String firstName;
    public String userPrincipalName;
    public String email;
    public String info;
    @JsonProperty("role_info")
    public List<RoleInfo> roleInfo;
}
