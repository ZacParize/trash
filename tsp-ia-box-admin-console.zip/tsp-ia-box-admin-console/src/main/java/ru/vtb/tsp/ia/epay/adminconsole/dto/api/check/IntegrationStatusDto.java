package ru.vtb.tsp.ia.epay.adminconsole.dto.api.check;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IntegrationStatusDto {

  private final String integrationName;
  private final IntegrationStatus status;
  private final String errors;
}
