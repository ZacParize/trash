package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class NewSiteDto {

  @NotNull(message = "'url'. Value required")
  @NotEmpty(message = "'url'. Value required")
  @Size(max = 255, message = "'url'. Length more 255 chars")
  @Pattern(regexp = "(http(s)?:\\/\\/)[\\wа-яёА-ЯЁ\\.\\-]+(?:\\.[\\wа-яёА-ЯЁ\\.\\-]+)+[\\wа-яёА-ЯЁ\\-\\._~:/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+", message = "'url'. Incorrect value")
  private String url;

  @NotNull(message = "'name'. Value required")
  @NotEmpty(message = "'name'. Value required")
  @Size(max = 255, message = "'name'. Incorrect value")
  @Pattern(regexp = "([a-zA-Zа-яёА-ЯЁ\\-\\d\\. ])+", message = "'name'. Incorrect value")
  private String name;
  @NotNull(message = "'login'. Value required")
  @NotEmpty(message = "'login'. Value required")
  private String login;

  @Size(max = 255, message = "'externalApplicationId'. Length more 255 chars")
  private String externalApplicationId;

  @Valid
  private SiteParamsDto params;
  private String phone;
  private String email;
  @NotNull(message = "'partnershipChannel'. Value required")
  private Boolean partnershipChannel;
  private String partnershipName;
  private String tessaTicketId;

}
