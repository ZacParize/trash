package ru.vtb.tsp.ia.epay.adminconsole.components;

import java.net.URI;
import java.util.Map;
import org.springframework.web.util.DefaultUriBuilderFactory;

public class TykUriBuilderFactory extends DefaultUriBuilderFactory {

  @Override
  public URI expand(String uriTemplate, Map<String, ?> uriVars) {
    final var url = uriTemplate.replace("/api/v1", "");
    return super.expand(url, uriVars);
  }

  @Override
  public URI expand(String uriTemplate, Object... uriVars) {
    final var url = uriTemplate.replace("/api/v1", "");
    return super.expand(url, uriVars);
  }
}
