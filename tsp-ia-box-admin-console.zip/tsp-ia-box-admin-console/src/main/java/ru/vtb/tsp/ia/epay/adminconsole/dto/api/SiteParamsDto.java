package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SiteParamsDto {

  @NotNull(message = "'mcc'. Value required")
  @Pattern(regexp = "^\\d{4}$", message = "'mcc'. Incorrect value")
  private String mcc;

  @Pattern(regexp = "((http(s)?:\\/\\/)[\\wа-яёА-ЯЁ\\.\\-]+(?:\\.[\\wа-яёА-ЯЁ\\.\\-]+)+[\\wа-яёА-ЯЁ\\-\\._~:/?#\\[\\]@!\\$&'\\(\\)\\*\\+,;=.]+){0,}", message = "'callbackUrl'. Incorrect value")
  private String callbackUrl;
  @Valid
  private SbpParamsDto sbpParams;
  @Valid
  private CardParamsDto cardParams;

}