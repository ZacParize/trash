package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.HttpHeaders.AUTHORIZATION;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsRequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.LegalEntityDto;

@Validated
@Tag(name = "OpenApi", description = "Api for working with OpenApi portal")
@SecurityRequirement(name = "bearerAuth")
public interface OpenApiApi {

  @Operation(
      operationId = "getLegalEntity", method = "GET", tags = "OpenApi",
      description = "Get organization name and generated identifier",
      summary = "Get organization name and generated identifier"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = LegalEntityDto.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      })
  })
  @GetMapping(path = "/api/v1/legalEntity", produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<LegalEntityDto> getLegalEntity() {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "postCredentials", method = "POST", tags = "OpenApi",
      description = "Send request for credentials",
      summary = "Send request for credentials"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = CredentialsResponseDto.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @PostMapping(path = "/api/v1/credentials",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<CredentialsResponseDto> postCredentials(
      @RequestBody @Validated CredentialsRequestDto requestDto) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
  }

}