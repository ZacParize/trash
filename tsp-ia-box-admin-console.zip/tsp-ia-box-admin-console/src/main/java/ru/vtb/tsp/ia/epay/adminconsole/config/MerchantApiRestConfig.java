package ru.vtb.tsp.ia.epay.adminconsole.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.RestTemplateFactory;
import ru.vtb.tsp.ia.epay.adminconsole.components.TykUriBuilderFactory;
import ru.vtb.tsp.ia.epay.adminconsole.components.interceptors.TykInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClient;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClientImpl;
import ru.vtb.tsp.ia.epay.merchant.MerchantControllerApi;
import ru.vtb.tsp.ia.epay.merchant.implementations.MerchantClientImpl;

@Configuration
@RequiredArgsConstructor
public class MerchantApiRestConfig {

  public static final String MERCHANT_API = "merchantApi";
  private final Integrations integrations;
  @Qualifier("epaAmClient")
  private final EpaClient epaAmClient;

  @Bean(MERCHANT_API)
  RestTemplate merchantApiClient(RestTemplateFactory restTemplateFactory) {
    final var restTemplate = restTemplateFactory.restTemplate(RestClient.MERCHANT_API);
    final var connection = integrations.getConnection(RestClient.MERCHANT_API);
    if (Boolean.TRUE.equals(connection.getTykEnabled())) {
      final var tykInterceptor = new TykInterceptor(epaAmClient, connection);
      final var tykUriBuilderFactory = new TykUriBuilderFactory();
      restTemplate.getInterceptors().add(tykInterceptor);
      restTemplate.setUriTemplateHandler(tykUriBuilderFactory);
    }
    return restTemplate;
  }

  @Bean
  public MerchantApiClient merchantApiClient(
      @Qualifier(MERCHANT_API) RestTemplate restTemplate,
      ObjectMapper objectMapper,
      @Value("${integrations.rests.merchant-api.host}") String host) {
    return new MerchantApiClientImpl(restTemplate, restTemplate, objectMapper, host);
  }

  @Bean
  public MerchantControllerApi merchantControllerApi(
      @Qualifier(MERCHANT_API) RestTemplate restTemplate,
      @Value("${integrations.rests.merchant-api.host}") String host
  ) {
    return new MerchantClientImpl(restTemplate, host);
  }
}