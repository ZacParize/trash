package ru.vtb.tsp.ia.epay.adminconsole.components.conditions;

import java.util.Arrays;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.06.2022
 */
public class OnlyNotDevAndLocal implements Condition {

  @Override
  public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
    return Arrays.stream(context.getEnvironment().getActiveProfiles())
        .anyMatch(s -> !"dev".equalsIgnoreCase(s) && !"local".equalsIgnoreCase(s));
  }
}
