package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantPayments {

  private boolean cardPayment;
  private boolean sbpPayment;
  private boolean cardFlowThreeDS;
  private boolean cardFlowThreeDSOnMerchantSide;
  private boolean googlePayment;
  private boolean applePayment;
  private boolean paymentCheckboxesVisible;

}