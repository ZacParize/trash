package ru.vtb.tsp.ia.epay.adminconsole.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import ru.vtb.tsp.ia.epay.adminconsole.components.interceptors.EpaInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.components.interceptors.FrkkInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.components.interceptors.RequestInterceptor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.06.2022
 */
@Configuration
@RequiredArgsConstructor
public class WebConfig implements WebMvcConfigurer {

  private static final String PATH_PATTERN = "/api/v1/**";
  private static final String PATH_PATTERN_EXCLUDE = "/api/v1/check";

  private final EpaInterceptor epaInterceptor;
  private final RequestInterceptor requestInterceptor;
  private final FrkkInterceptor frkkInterceptor;

  @Override
  public void addInterceptors(InterceptorRegistry registry) {
    registry.addInterceptor(requestInterceptor).addPathPatterns(PATH_PATTERN);
    registry.addInterceptor(epaInterceptor).addPathPatterns(PATH_PATTERN)
        .excludePathPatterns(PATH_PATTERN_EXCLUDE);
    registry.addInterceptor(frkkInterceptor).addPathPatterns(PATH_PATTERN)
        .excludePathPatterns(PATH_PATTERN_EXCLUDE);
    WebMvcConfigurer.super.addInterceptors(registry);
  }
}
