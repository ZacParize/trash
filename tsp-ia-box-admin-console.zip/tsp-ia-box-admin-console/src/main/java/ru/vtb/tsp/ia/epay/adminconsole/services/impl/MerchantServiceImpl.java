package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import java.util.Set;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata.SessionDataClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantNameDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.consts.AuditEvents;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.MerchantNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.services.MerchantService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SessionDataService;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClient;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;

@Service
@RequiredArgsConstructor
public class MerchantServiceImpl implements MerchantService {

  private final MerchantApiClient client;
  private final SessionDataClient sessionDataClient;
  private final SessionDataService service;

  @Override
  public Optional<MerchantShortDto> findMerchantConverted(String jwt) {
    return find(jwt).flatMap(this::mapMerchantApiMerchantDtoToMerchantShortDto);
  }

  @Override
  public Optional<MerchantDto> findMerchant(String jwt) {
    return find(jwt);
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_CREATE_MERCHANT)
  public Optional<MerchantShortDto> createMerchant(String jwt) {
    final var merchData = sessionDataClient.extractCodes(jwt);
    if (merchData.isEmpty()) {
      return Optional.empty();
    }
    final var dto = createMerchantDto(merchData.get().getName(),
        merchData.get().getMdmCode());

    final var response = client.createMerchant(dto);
    return response.flatMap(this::mapMerchantApiMerchantDtoToMerchantShortDto);
  }

  private Optional<MerchantDto> find(String jwt) {
    final var merchantData = service.getMdmCodes(jwt);
    if (CollectionUtils.isEmpty(merchantData)) {
      throw new MerchantNotFoundException();
    }

    final var filter = MerchantFilter.builder()
        .mdmCode(Set.of(merchantData.iterator().next()))
        .build();
    return Optional.ofNullable(client.getMerchants(filter, null).stream().findFirst()
        .orElseThrow(MerchantNotFoundException::new));
  }

  private MerchantDto createMerchantDto(String name, Long mdmCode) {
    return MerchantDto.builder()
        .name(name)
        .mdmCode(mdmCode)
        .build();
  }

  private Optional<MerchantShortDto> mapMerchantApiMerchantDtoToMerchantShortDto(MerchantDto src) {
    return Optional.ofNullable(
        MerchantShortDto.builder()
            .id(src.getId())
            .mdmCode(src.getMdmCode())
            .created(src.getCreated().atOffset(ZoneOffset.UTC))
            .modified(src.getModified().atOffset(ZoneOffset.UTC))
            .name(src.getName())
            .state(src.getState().name())
            .build()
    );
  }

  @Override
  public Optional<MerchantNameDto> getMerchantName(String jwt) {
    return sessionDataClient.getSessionData(jwt)
        .map(SessionData::getClient)
        .map(Client::getOrganization)
        .map(org -> MerchantNameDto.builder()
            .fullName(org.getFullName())
            .shortName(org.getShortName())
            .build());
  }
}
