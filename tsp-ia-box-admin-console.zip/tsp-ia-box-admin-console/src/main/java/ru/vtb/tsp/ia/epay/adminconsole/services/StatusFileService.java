package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;

public interface StatusFileService {

  List<StatusFileMetaData> findByCssUuids(List<UUID> uuids);

  List<StatusFileMetaData> findByCssUuid(UUID uuid);

  List<StatusFileMetaData> findByStatusId(Long statusId);

  List<StatusFileMetaData> findExpiredUnlinkedFiles();

  Optional<StatusFileMetaData> save(StatusFileMetaData file);

  List<UUID> saveAll(List<StatusFileMetaData> files);

  boolean deleteFiles(UUID ... ecmUUIDs);

  List<FileMetaInfoDto> fromListToListDto(List<StatusFileMetaData> data);

  FileMetaInfoDto mapToFileMetaInfoDto(StatusFileMetaData data);

}
