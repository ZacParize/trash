package ru.vtb.tsp.ia.epay.adminconsole.clients.transactions;

import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.CustomPageImpl;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.consts.AuditEvents;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.MerchantSiteState;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;

@Conditional(OnlyNotDevAndLocal.class)
@Component
@Slf4j
@RequiredArgsConstructor
public class TransactionsDefaultClient implements TransactionsClient {

  private static final String INTEGRATION_NAME = "smbq-ia-transaction";
  private static final String ORDER_TRANSACTION_CODE = "orderTransactionCode";
  private static final String STATUS = "status";
  private static final String MERCHANT_SITE = "merchantSite";
  private static final String AMOUNT_MIN = "amountMin";
  private static final String AMOUNT_MAX = "amountMax";
  private static final String PAGE = "page";
  private static final String SIZE = "size";
  private static final String FROM_DATE = "fromDate";
  private static final String BEFORE_DATE = "beforeDate";
  private static final String PAYMENT_TYPE = "paymentType";
  private static final String SORT = "sort";
  private static final String ORDER = "order";
  private static final String SOURCE_SYSTEM = "sourceSystem";
  private static final String ENDPOINT = "/v1/frkk/orders";
  private static final String SITES = "/sites";

  @Qualifier("transactionsRestClient")
  private final RestTemplate restTemplate;
  private final Integrations integrations;

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_GET_ORDERS)
  public Page<OrderDto> getOrders(String orderTransactionCode, List<OrderStatus> status,
      List<UUID> merchantSite, Double amountMin, Double amountMax, int page, int size,
      ZonedDateTime fromDate, ZonedDateTime beforeDate, List<PaymentType> paymentType, String sort,
      SortOrder order, List<SourceSystemSearchFields> sourceSystem, String token) {
    final HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", token);
    final HttpEntity<String> request = new HttpEntity<>(null, headers);

    final String statuses = CollectionUtils.isEmpty(status) ? null
        : status.stream().map(Enum::name).collect(Collectors.joining(","));
    final String merchantSites = CollectionUtils.isEmpty(merchantSite) ? null
        : merchantSite.stream().map(UUID::toString).collect(Collectors.joining(","));
    final String paymentTypes = CollectionUtils.isEmpty(paymentType) ? null
        : paymentType.stream().map(Enum::name).collect(Collectors.joining(","));
    final String sourceSystems = CollectionUtils.isEmpty(sourceSystem) ? null
        : sourceSystem.stream().map(Enum::name).collect(Collectors.joining(","));

    final Map<String, String> uriVariables = new HashMap<>();

    final String host = integrations.getConnection(RestClient.TRANSACTIONS).getHost();
    final StringBuilder url = new StringBuilder(host).append(ENDPOINT).append("?");

    if (StringUtils.hasLength(orderTransactionCode)) {
      fillUrlAndVariables(url, uriVariables, ORDER_TRANSACTION_CODE, orderTransactionCode);
      url.append("&");
    }
    if (StringUtils.hasLength(statuses)) {
      fillUrlAndVariables(url, uriVariables, STATUS, statuses);
      url.append("&");
    }
    if (StringUtils.hasLength(merchantSites)) {
      fillUrlAndVariables(url, uriVariables, MERCHANT_SITE, merchantSites);
      url.append("&");
    }
    if (Objects.nonNull(amountMin)) {
      fillUrlAndVariables(url, uriVariables, AMOUNT_MIN, String.valueOf(amountMin));
      url.append("&");
    }
    if (Objects.nonNull(amountMax)) {
      fillUrlAndVariables(url, uriVariables, AMOUNT_MAX, String.valueOf(amountMax));
      url.append("&");
    }
    fillUrlAndVariables(url, uriVariables, PAGE, String.valueOf(page));
    url.append("&");
    fillUrlAndVariables(url, uriVariables, SIZE, String.valueOf(size));
    url.append("&");
    if (Objects.nonNull(fromDate)) {
      fillUrlAndVariables(url, uriVariables, FROM_DATE, fromDate.toString());
      url.append("&");
    }
    if (Objects.nonNull(beforeDate)) {
      fillUrlAndVariables(url, uriVariables, BEFORE_DATE, beforeDate.toString());
      url.append("&");
    }
    if (StringUtils.hasLength(paymentTypes)) {
      fillUrlAndVariables(url, uriVariables, PAYMENT_TYPE, paymentTypes);
      url.append("&");
    }
    fillUrlAndVariables(url, uriVariables, SORT, sort);
    url.append("&");
    fillUrlAndVariables(url, uriVariables, ORDER, order.name());
    url.append("&");
    fillUrlAndVariables(url, uriVariables, SOURCE_SYSTEM, sourceSystems);

    log.info("url: {}", url);

    final var result = restTemplate.exchange(url.toString(), HttpMethod.GET, request,
        new ParameterizedTypeReference<CustomPageImpl<OrderDto>>() {
        },
        uriVariables);

    if (Objects.nonNull(result.getBody())) {
      return result.getBody();
    } else {
      return Page.empty();
    }
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_GET_SITES)
  public FilterDictionariesDto getFilterDictionaries(String token) {
    final String host = integrations.getConnection(RestClient.TRANSACTIONS).getHost();

    return FilterDictionariesDto.builder()
        .orderSites(getOrderSite(host, token))
        .merchantSiteStates(getMerchantSiteState())
        .paymentTypes(getPaymentType())
        .sourceSystemSearchFields(getSourceSystemSearchFields())
        .build();
  }

  private List<OrderSiteDto> getOrderSite(String host, String token) {
    final String url = host + ENDPOINT + SITES;
    log.info("url: {}", url);
    final HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", token);
    final HttpEntity<String> request = new HttpEntity<>(null, headers);
    return restTemplate.exchange(url, HttpMethod.GET, request,
        new ParameterizedTypeReference<List<OrderSiteDto>>() {
        }).getBody();
  }

  private List<MerchantSiteState> getMerchantSiteState() {
    return List.of(MerchantSiteState.values());
  }

  private List<PaymentType> getPaymentType() {
    return List.of(PaymentType.values());
  }

  private List<SourceSystemSearchFields> getSourceSystemSearchFields() {
    return List.of(SourceSystemSearchFields.values());
  }

  private void fillUrlAndVariables(StringBuilder url, Map<String, String> uriVariables,
      String param, String value) {
    url.append(param).append("={").append(param).append("}");
    uriVariables.put(param, value);
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    try {
      final String url =
          integrations.getConnection(RestClient.TRANSACTIONS).getHost() + ENDPOINT + SITES;
      restTemplate.optionsForAllow(url);
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }
}
