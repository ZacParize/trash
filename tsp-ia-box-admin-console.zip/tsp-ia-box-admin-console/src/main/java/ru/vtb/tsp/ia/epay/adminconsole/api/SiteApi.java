package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.util.Collections;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.ChangeSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.NewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.PagedSitesHistoryDtos;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteActivationParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteHistoryRecordDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserGroup;

@Validated
@Tag(name = "Sites", description = "Api for working with sites")
@RestController
@RequestMapping
@SecurityRequirement(name = "bearerAuth")
public interface SiteApi {

  @Operation(operationId = "getSite", method = "GET", tags = "Sites",
      description = "Returns site finded by merchant site id",
      summary = "Get site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = SiteDto.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Site is not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @GetMapping(path = "/api/v1/sites/{mstId}",
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<SiteDto> getSite(@PathVariable("mstId") String mstId) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "getSites", method = "GET", tags = "Sites",
      description = "Returns sites",
      summary = "Get site list"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              array = @ArraySchema(
                  schema = @Schema(implementation = SiteShortDto.class
                  )
              )
          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      })
  }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @GetMapping(path = "/api/v1/sites",
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<List<SiteShortDto>> getSites() {
    return ResponseEntity.ok(Collections.emptyList());
  }

  @Operation(operationId = "postSite", method = "POST", tags = "Sites",
      description = "Create site",
      summary = "Create site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = SiteDto.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PostMapping(path = "/api/v1/sites",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<SiteDto> postSite(@RequestBody @Validated NewSiteDto body) {
    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
  }

  @Operation(operationId = "patchSite", method = "PATCH", tags = "Sites",
      description = "Change various parameters of site",
      summary = "Change various parameters of site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = SiteDto.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PatchMapping(path = "/api/v1/sites/{mstId}",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<SiteDto> patchSite(
      @PathVariable("mstId") String mstId,
      @RequestBody @Validated ChangeSiteDto body) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "activeSite", method = "POST", tags = "Sites",
      description = "Activate site",
      summary = "Activate site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK"),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PostMapping(path = "/api/v1/sites/{mstId}/activation")
  default ResponseEntity<?> activateSite(
      @PathVariable("mstId") String mstId,
      @RequestBody SiteActivationParameters parameters
  ) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "blockSite", method = "POST", tags = "Sites",
      description = "Block site",
      summary = "Block site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = SiteDto.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PostMapping(path = "/api/v1/sites/{mstId}/block",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<SiteDto> blockSite(
      @PathVariable("mstId") String mstId,
      @RequestBody SiteBlockingParameters blockReason
  ) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "unblockSite", method = "POST", tags = "Sites",
      description = "Unblock site",
      summary = "Unblock site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = SiteDto.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @PostMapping(path = "/api/v1/sites/{mstId}/unblock",
      consumes = APPLICATION_JSON_VALUE,
      produces = APPLICATION_JSON_VALUE)
  default ResponseEntity<SiteDto> unblockSite(
      @PathVariable("mstId") String mstId,
      @RequestBody SiteUnblockingParameters params
  ) {
    return ResponseEntity.notFound().build();
  }

  @Operation(operationId = "deleteSite", method = "DELETE", tags = "Sites",
      description = "Delete site",
      summary = "Delete site"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK"),
          @ApiResponse(responseCode = "403", description = "Permission denied", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "404", description = "Not found", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @DeleteMapping(path = "/api/v1/sites/{mstId}")
  default ResponseEntity<?> deleteSite(@PathVariable("mstId") String mstId) {
    return ResponseEntity.ok().build();
  }

  @Operation(operationId = "getHistory", method = "GET", tags = "Sites",
      description = "Returns sites history",
      summary = "Get sites status changing history"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              array = @ArraySchema(
                  schema = @Schema(implementation = PagedSitesHistoryDtos.class
                  )
              )
          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE

          )
      }),
      @ApiResponse(responseCode = "404", description = "Merchant is not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      })
  }
  )
  @FrkkRoles(UserGroup.DEFAULT)
  @GetMapping(path = "/api/v1/sites/{mstId}/history",
      produces = APPLICATION_JSON_VALUE
  )
  default ResponseEntity<Page<SiteHistoryRecordDto>> getHistory(
      @PathVariable(name = "mstId") String mstId,
      @RequestParam(name = "page", required = false) Integer page,
      @RequestParam(name = "pageSize", required = false) Integer pageSize,
      @RequestParam(name = "sort", required = false) String sortBy,
      @RequestParam(name = "desc", required = false) Boolean desc) {
    return ResponseEntity.ok(Page.empty());
  }
}
