package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Getter;

@Getter
public class LegalEntityNotFoundException extends IdentifiedException {

  private final Integer httpCode = 404;
  private final String id = "0120005040";
  private final String errorMessage = "legalEntity_not_found";
  private final String description = "";

}
