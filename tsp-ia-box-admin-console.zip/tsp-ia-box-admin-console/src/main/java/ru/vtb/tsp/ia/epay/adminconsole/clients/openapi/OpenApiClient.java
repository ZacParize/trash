package ru.vtb.tsp.ia.epay.adminconsole.clients.openapi;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.RequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.ResponseDto;

public interface OpenApiClient extends Checker {

  Optional<ResponseDto> postApplication(RequestDto requestDto);

}
