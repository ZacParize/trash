package ru.vtb.tsp.ia.epay.adminconsole.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.components.RestTemplateFactory;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;

@Configuration
@RequiredArgsConstructor
public class EpaRestConfig {
  private final RestTemplateFactory restTemplateFactory;

  @Bean("epaIgRestClient")
  RestTemplate epaIgRestClient() {
    return restTemplateFactory.restTemplate(RestClient.EPA);
  }

  @Bean("epaAmRestClient")
  RestTemplate epaAmRestClient() {
    return restTemplateFactory.restTemplate(RestClient.EPA_AM);
  }
}
