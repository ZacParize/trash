package ru.vtb.tsp.ia.epay.adminconsole.clients.merchantapi;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;

@Slf4j
@Component
@RequiredArgsConstructor
@Conditional(OnlyDevOrLocal.class)
public class MerchantApiMockClient implements MerchantApiClient {

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("MerchantApiMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
