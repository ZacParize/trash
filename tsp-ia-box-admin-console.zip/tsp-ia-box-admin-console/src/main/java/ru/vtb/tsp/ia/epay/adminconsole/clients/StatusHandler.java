package ru.vtb.tsp.ia.epay.adminconsole.clients;


@FunctionalInterface
public interface StatusHandler<T> {

  T handle();

}
