package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.api.OpenApiApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsRequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.LegalEntityDto;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;
import ru.vtb.tsp.ia.epay.adminconsole.services.OpenApiService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@RestController
@RequiredArgsConstructor
@RequestMapping
public class OpenApiApiController implements OpenApiApi {

  private final OpenApiService openApiService;

  @Override
  public ResponseEntity<LegalEntityDto> getLegalEntity() {
    return openApiService.createLegalEntity(JwtTokenUtils.getJwtToken())
        .map(ResponseEntity::ok)
        .orElseThrow(IdentifiedException::new);
  }

  @Override
  public ResponseEntity<CredentialsResponseDto> postCredentials(CredentialsRequestDto requestDto) {
    return openApiService.createCredentials(JwtTokenUtils.getJwtToken(), requestDto)
        .map(ResponseEntity::ok)
        .orElseThrow(IdentifiedException::new);
  }
}
