package ru.vtb.tsp.ia.epay.adminconsole.clients.frkk;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.UserInfo;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@Slf4j
@Component
@Conditional(OnlyNotDevAndLocal.class)
@Order(1)
@RequiredArgsConstructor
public class FrkkDefaultClient implements FrkkClient {

  private static final String INTEGRATION_NAME = "ms-smbq-user-info";
  private static final String ENDPOINT = "/api/ms-smbq-user-info/auth-payload";
  private static final String USER_PRINCIPAL_NAME = "userPrincipalName";
  private static final String ENDPOINT_PARAMS =
      "?" + USER_PRINCIPAL_NAME + "={" + USER_PRINCIPAL_NAME + "}";

  @Qualifier("frkkRestClient")
  private final RestTemplate restTemplate;
  private final Integrations integrations;

  @Override
  public Optional<UserInfo> getUserInfo(String token) {
    final var sub = JwtTokenUtils.extractSub(token);
    final String host = integrations.getConnection(RestClient.FRKK).getHost();
    final String url = host + ENDPOINT + ENDPOINT_PARAMS;

    final HttpHeaders requestHeaders = new HttpHeaders();
    requestHeaders.setBearerAuth(token.replaceAll("Bearer ", ""));
    final HttpEntity<String> request = new HttpEntity<>(null, requestHeaders);

    final ResponseEntity<UserInfo> response = restTemplate.exchange(url,
        HttpMethod.POST,
        request,
        UserInfo.class,
        sub);

    if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
      final var body = response.getBody();
      return Optional.ofNullable(body);
    }
    return Optional.empty();
  }

  @Override
  public Optional<UserInfo> getUserInfo() {
    return getUserInfo(JwtTokenUtils.getJwtToken());
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    try {
      final String host = integrations.getConnection(RestClient.FRKK).getHost();
      final String url = host + ENDPOINT + ENDPOINT_PARAMS;

      final HttpHeaders requestHeaders = new HttpHeaders();
      final HttpEntity<String> request = new HttpEntity<>(null, requestHeaders);
      restTemplate.exchange(url, HttpMethod.POST, request, UserInfo.class, "sub");

      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }
}
