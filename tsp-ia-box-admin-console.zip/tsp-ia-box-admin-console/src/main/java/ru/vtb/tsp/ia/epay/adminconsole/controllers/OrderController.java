package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.api.OrderApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.PageOrderDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.OrderService;

@Slf4j
@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
public class OrderController implements OrderApi {

  private final OrderService orderService;

  @Override
  @GetMapping(produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<PageOrderDto> getOrders(
      @RequestParam(required = false) String orderTransactionCode,
      @RequestParam(required = false) List<OrderStatus> status,
      @RequestParam(required = false) List<UUID> merchantSite,
      @RequestParam(required = false) Double amountMin,
      @RequestParam(required = false) Double amountMax,
      @RequestParam(required = false, defaultValue = "0") int page,
      @RequestParam(required = false, defaultValue = "20") int size,
      @RequestParam(required = false) @DateTimeFormat(iso = ISO.DATE_TIME) ZonedDateTime fromDate,
      @RequestParam(required = false) @DateTimeFormat(iso = ISO.DATE_TIME) ZonedDateTime beforeDate,
      @RequestParam(required = false) List<PaymentType> paymentType,
      @RequestParam(required = false, defaultValue = "createdDate") String sort,
      @RequestParam(required = false, defaultValue = "descend") SortOrder order,
      @RequestParam(required = false, defaultValue = "ALL") List<SourceSystemSearchFields> sourceSystem,
      @RequestHeader(name = "Authorization") String token) {
    final PageOrderDto result = PageOrderDto.builder()
        .page(
            (PageImpl<OrderDto>) orderService.getOrders(orderTransactionCode, status, merchantSite,
                amountMin, amountMax, page, size, fromDate, beforeDate, paymentType, sort, order,
                sourceSystem, token))
        .build();
    return ResponseEntity.ok(result);
  }

  @Override
  @GetMapping(path = "/filter-dictionaries", produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<FilterDictionariesDto> getFilterDictionaries(
      @RequestHeader(name = "Authorization") String token) {
    return ResponseEntity.ok(orderService.getFilterDictionaries(token));
  }
}
