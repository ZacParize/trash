package ru.vtb.tsp.ia.epay.adminconsole.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;
import org.hibernate.annotations.Type;
import ru.vtb.tsp.ia.epay.adminconsole.dto.db.AdditionalSiteParamsData;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@EqualsAndHashCode
@Builder
@With
@Table(name = "additional_site_params")
@Entity
public class AdditionalSiteParams implements Serializable {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "id")
  private Long id;
  @Column(name = "mdmCode")
  private Long mdmCode;
  @Column(name = "site_id")
  private String siteId;
  @Column(name = "params")
  @Type(type = "com.vladmihalcea.hibernate.type.json.JsonBinaryType")
  private AdditionalSiteParamsData params;

}
