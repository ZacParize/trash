package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata.SessionDataClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;
import ru.vtb.tsp.ia.epay.adminconsole.services.SessionDataService;

@Service
@RequiredArgsConstructor
public class SessionDataServiceImpl implements SessionDataService {

  private final SessionDataClient client;

  @Override
  public List<Long> getMdmCodes(String jwt) {
    return client.extractCodes(jwt)
        .stream()
        .map(code -> {
          if (Objects.nonNull(code.getMdmCode())) {
            return code.getMdmCode();
          }
          if (Objects.nonNull(code.getMdmOsnCode())) {
            return code.getMdmOsnCode();
          }
          return code.getMdmPkbCode();
        })
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  @Override
  public Optional<Client> getClient(String jwt) {
    return client.getSessionData(jwt).map(SessionData::getClient);
  }
}
