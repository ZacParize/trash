package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;
import ru.vtb.tsp.ia.epay.adminconsole.services.EcmService;
import ru.vtb.tsp.ia.epay.adminconsole.services.FrkkService;
import ru.vtb.tsp.ia.epay.adminconsole.services.StatusFileService;

@Service
@RequiredArgsConstructor
public class EcmServiceImpl implements EcmService {

  private final EcmClient ecmClient;
  private final StatusFileService fileService;
  private final FrkkService frkkService;

  @Override
  public Optional<FileMetaInfoDto> uploadFile(MultipartFile file) {

    return ecmClient.uploadFile(file)
        .map(uuid -> {
          final var statusFile = StatusFileMetaData.builder()
              .created(OffsetDateTime.now())
              .ecmId(uuid)
              .fileName(file.getOriginalFilename())
              .fileSize(file.getSize())
              .user(frkkService.getLogin())
              .build();
          return fileService.save(statusFile).map(fileService::mapToFileMetaInfoDto)
              .orElse(FileMetaInfoDto.builder().build());
        });
  }

  @Override
  public Optional<Resource> downloadFile(UUID uuid) {
    return ecmClient.downloadFile(uuid);
  }

  @Override
  public boolean deleteFiles(UUID... ecmUuids) {
    if (ecmClient.deleteFiles(ecmUuids)) {
      return fileService.deleteFiles(ecmUuids);
    }
    return false;
  }
}
