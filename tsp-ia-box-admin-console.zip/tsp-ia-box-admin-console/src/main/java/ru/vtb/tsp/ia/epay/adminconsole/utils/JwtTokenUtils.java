package ru.vtb.tsp.ia.epay.adminconsole.utils;

import io.jsonwebtoken.Jwts;
import java.io.Serializable;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import ru.vtb.tsp.ia.epay.adminconsole.dto.JwtDto;

/**
 * Методы для работы с Jwt.
 *
 * @since 12.10.2020
 */

@Slf4j
@UtilityClass
public class JwtTokenUtils implements Serializable {

  public static String getJwtToken() {
    return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
            .getRequest().getHeader(HttpHeaders.AUTHORIZATION);
  }

  public static String extractCtxi(String token) {
    return extractJwtInfo(token)
        .map(JwtDto::getCtxi)
        .orElse("");
  }

  public static String extractChannel(String token) {
    return extractJwtInfo(token).map(JwtDto::getChannel).orElse("");
  }

  public static String extractSub(String token) {
    return extractJwtInfo(token).map(JwtDto::getSub).orElse("");
  }


  public static Optional<JwtDto> extractJwtInfo(String token) {
    final var src = removeBearer(token);
    final var untrusted = Jwts.parser().parseClaimsJwt(tokenWithoutSignature(src));
    return Optional.ofNullable(JsonUtils
        .mapper()
        .convertValue(untrusted.getBody(), JwtDto.class));
  }

  private String removeBearer(String token) {
    return token.toLowerCase().startsWith("bearer")
        ? token.substring(7)
        : token;
  }

  private String tokenWithoutSignature(String token) {
    final var index = token.lastIndexOf('.');
    return token.substring(0, index + 1);
  }
}
