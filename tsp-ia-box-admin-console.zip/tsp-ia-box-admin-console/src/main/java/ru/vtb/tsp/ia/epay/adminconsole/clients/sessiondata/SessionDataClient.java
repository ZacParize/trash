package ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;
import ru.vtb.tsp.ia.epay.adminconsole.dto.merchants.MerchantData;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 29.06.2022
 */
public interface SessionDataClient extends Checker {

  Optional<SessionData> getSessionData(String token);

  default Optional<MerchantData> extractCodes(String token) {
    final var data = getSessionData(token);
    return data.map(SessionData::getClient)
        .map(Client::getOrganization)
        .map(organization -> MerchantData.builder()
            .mdmCode(Optional.ofNullable(organization.getMdmCode())
                .map(Long::valueOf)
                .orElse(null))
            .mdmPkbCode(Optional.ofNullable(organization.getMdmPkbClient())
                .map(Long::valueOf)
                .orElse(null))
            .name(organization.getShortName())
            .build());
  }

}
