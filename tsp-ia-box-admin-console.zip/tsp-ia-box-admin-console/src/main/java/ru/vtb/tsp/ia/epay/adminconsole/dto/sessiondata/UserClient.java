package ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 29.06.2022
 */
@Data
@JsonIgnoreProperties
public class UserClient implements Serializable {

  private String mdmOsnClient;

  private String mdmCode;

  private String mdmPkbClient;

  private Boolean isolated;

  private OrgInfo orgInfo;
}
