package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.PagingParams;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteHistoryRecordDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortParams;
import ru.vtb.tsp.ia.epay.adminconsole.entities.SiteStatusHistoryRecord;

public interface SiteStatusHistoryService {

  List<SiteHistoryRecordDto> find(String mstId);
  Optional<SiteHistoryRecordDto> findLast(String mstId);
  List<SiteHistoryRecordDto> find(String mstId, SortParams sortParams);
  Page<SiteHistoryRecordDto> find(String mstId, PagingParams pagingParams);
  Page<SiteHistoryRecordDto> find(String mstId, PagingParams pagingParams, SortParams sortParams);
  Optional<SiteStatusHistoryRecord> save(SiteStatusHistoryRecord record);
  Optional<SiteHistoryRecordDto> newSite(String mstId);
  Optional<SiteHistoryRecordDto> blockSite(String mstId, SiteBlockingParameters params);
  Optional<SiteHistoryRecordDto> unblockSite(String mstId, SiteUnblockingParameters params);

}
