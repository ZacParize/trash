package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

@Data
public class FileDeleteInternalErrorException extends IdentifiedException {

  private final Integer httpCode = 500;
  private final String id = "0120005045";
  private final String errorMessage = "del_internal error";
  private final String description = "";

}
