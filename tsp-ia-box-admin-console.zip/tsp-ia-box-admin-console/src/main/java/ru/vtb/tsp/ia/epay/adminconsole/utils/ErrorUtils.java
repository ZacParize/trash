package ru.vtb.tsp.ia.epay.adminconsole.utils;

import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;
import javax.servlet.http.HttpServletResponse;
import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.ServletRequestBindingException;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.ValidationException;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.07.2022
 */
@UtilityClass
@Slf4j
public class ErrorUtils {

  private static final String MISSING_BODY = "Required request body is missing";
  private static final String MISSING_HEADER = "Missing request header '%s'";

  public static Error exceptionToError(Throwable throwable) {
    IdentifiedException exception = new IdentifiedException();
    final var traceId = UUID.randomUUID().toString();
    if (throwable instanceof IdentifiedException) {
      exception = (IdentifiedException) throwable;
    }
    return buildError(exception, throwable);
  }

  @SneakyThrows
  public static void exceptionToServletResponse(Throwable throwable,
      HttpServletResponse response) {
    final var error = exceptionToError(throwable);
    response.setStatus(error.getHttpCode());
    response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    response.setCharacterEncoding(StandardCharsets.UTF_8.displayName());
    response.getWriter().write(JsonUtils.mapper().writeValueAsString(error));
  }

  public static Error validationExceptionToError(MethodArgumentNotValidException ex) {
    final var description = Optional.ofNullable(ex.getFieldError())
        .map(FieldError::getDefaultMessage)
        .orElse(null);
    final var exception = new ValidationException(
        description,
        ex.getFieldError().getField());
    return buildError(exception, ex);
  }

  public static Error messageNotReadableExceptionToError(HttpMessageNotReadableException ex) {
    if (StringUtils.isNotEmpty(ex.getMessage()) && ex.getMessage().startsWith(MISSING_BODY)) {
      return buildError(new ValidationException(MISSING_BODY, "body"), ex);
    }
    return exceptionToError(ex);
  }

  public static Error servletRequestBindingExceptionToError(ServletRequestBindingException ex) {
    if (ex instanceof MissingRequestHeaderException) {
      final var headerException = (MissingRequestHeaderException) ex;
      final var exception = new ValidationException(String.format(MISSING_HEADER,
          headerException.getHeaderName()),
          headerException.getHeaderName());
      return buildError(exception, ex);
    }
    return exceptionToError(ex);
  }

  public static Error mediaTypeNotSupportedExceptionToError(HttpMediaTypeNotSupportedException ex) {
    return buildError(new ValidationException(ex.getMessage(), HttpHeaders.CONTENT_TYPE), ex);
  }

  private static Error buildError(IdentifiedException exception, Throwable originalException) {
    final var traceId = UUID.randomUUID().toString();
    final var error = Error.builder()
        .id(exception.getId())
        .httpCode(exception.getHttpCode())
        .code(null)
        .message(exception.getErrorMessage())
        .description(exception.getDescription())
        .traceId(traceId)
        .build();
    log.error("{}: {} [traceId: {}, status: {}]: ",
        error.getId(),
        error.getMessage(),
        error.getTraceId(),
        error.getHttpCode(),
        originalException
    );
    return error;
  }

}
