package ru.vtb.tsp.ia.epay.adminconsole.components.audit;

import freemarker.template.Configuration;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import ru.vtb.omni.audit.lib.api.enums.AudLibEventClass;
import ru.vtb.omni.audit.lib.resolver.FreeMarkerTemplateResolver;
import ru.vtb.tsp.ia.epay.adminconsole.clients.frkk.FrkkClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata.SessionDataClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.JwtDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.Attributes;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.UserInfo;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Organization;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.SessionData;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@Component
@ConditionalOnProperty(name = "audit.enabled", havingValue = "true")
@Primary
public class CustomFreeMarkerTemplateResolver extends FreeMarkerTemplateResolver {

  private final FrkkClient frkkClient;
  private final SessionDataClient sessionDataClient;

  public CustomFreeMarkerTemplateResolver(
      @Qualifier("auditFreeMarkerConfiguration") Configuration configuration,
      List<FrkkClient> frkkClients,
      List<SessionDataClient> sessionDataClients) {
    super(configuration);
    this.sessionDataClient = sessionDataClients.get(0);
    this.frkkClient = frkkClients.get(0);
  }

  @Override
  protected String toMessage(String eventCode, AudLibEventClass eventClass, String messageTemplate,
      Map<String, Object> model) {
    HttpServletRequest request =
        ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
            .getRequest();
    final var jwt = request.getHeader(HttpHeaders.AUTHORIZATION);
    final var userInfo = frkkClient.getUserInfo(jwt).orElse(UserInfo.builder().build());
    final var org = Optional.ofNullable(sessionDataClient.getSessionData(jwt))
        .map(Optional::get)
        .map(SessionData::getClient)
        .map(Client::getOrganization)
        .orElse(Organization.builder().build());
    fixReturnValue(model);
    model.put("org", org);
    model.put("uinf", userInfo);
    model.put("jwt", JwtTokenUtils.extractJwtInfo(jwt).orElse(JwtDto.builder().build()));
    model.put("additionalData", additionalDataForMessage(userInfo, jwt));
    return super.toMessage(eventCode, eventClass, messageTemplate, model);
  }

  private String additionalDataForMessage(UserInfo userInfo, String token) {
    Attributes attributes = Attributes.builder().build();
    if (Objects.nonNull(userInfo)) {
      attributes = userInfo.getAttributes();
    }
    return "employeeNumber: " + attributes.getEmployeeNumber()
        + " login: " + attributes.getLogin()
        + " sessionId: " + JwtTokenUtils.extractCtxi(token);
  }

  private void fixReturnValue(Map<String, Object> model) {
    if (!model.containsKey("retVal")) {
      return;
    }
    final var retVal = model.get("retVal");
    if (retVal instanceof Optional && ((Optional<?>) retVal).isPresent()) {
      model.put("retVal", ((Optional<?>) retVal).get());
    }
    if (retVal instanceof ResponseEntity && ((ResponseEntity<?>) retVal).hasBody()) {
      model.put("retVal", ((ResponseEntity<?>) retVal).getBody());
    }
  }
}
