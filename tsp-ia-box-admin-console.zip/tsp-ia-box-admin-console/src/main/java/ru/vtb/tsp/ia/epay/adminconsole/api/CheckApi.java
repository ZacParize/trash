package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.CheckResponseDto;

@Tag(name = "Check", description = "Api for checking integration services")
@Validated
public interface CheckApi {

  @Operation(
      operationId = "check", method = "GET", tags = "CheckApi",
      description = "Checking integration services",
      summary = "Checking integration services"
  )
  @ApiResponses(
      value = {
          @ApiResponse(responseCode = "200", description = "OK", content = {
              @Content(
                  schema = @Schema(implementation = CredentialsResponseDto.class),
                  mediaType = APPLICATION_JSON_VALUE

              )
          }),
          @ApiResponse(responseCode = "500", description = "Technical error", content = {
              @Content(
                  schema = @Schema(implementation = Error.class),
                  mediaType = APPLICATION_JSON_VALUE
              )
          })
      }
  )
  @GetMapping
  ResponseEntity<CheckResponseDto> check();
}
