package ru.vtb.tsp.ia.epay.adminconsole.components;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.net.ssl.SSLContext;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.actuate.metrics.web.client.MetricsRestTemplateCustomizer;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ResourceUtils;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.RestConnection;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;

@RequiredArgsConstructor
@Slf4j
@Component
public class RestTemplateFactory {

  private final RestTemplateBuilder builder;
  private final Integrations properties;
  private final MetricsRestTemplateCustomizer metricCustomizer;
  @Value("${logging.showOutboundRequests}")
  private Boolean showOutboundRequests;
  @Value("${logging.showBodies}")
  private Boolean showBodies;

  public RestTemplate restTemplate(RestClient client) {
    if (Objects.isNull(client)) {
      return null;
    }
    final var connection = properties.getConnection(client);
    log.info("Connection: [name: {}, host: {}, ssl.enabled: {}]",
        client.name(),
        connection.getHost(),
        connection.getSslEnabled());
    if (!connection.getSslEnabled() || Objects.isNull(connection.getSsl())) {
      HttpComponentsClientHttpRequestFactory requestFactory =
          new HttpComponentsClientHttpRequestFactory();
      final var httpClient = HttpClients.custom().build();
      requestFactory.setHttpClient(httpClient);
      return builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
          .additionalInterceptors(new RestClientInterceptor())
          .customizers(metricCustomizer)
          .build();
    }
    if (connection.getSsl().getCertValidation()) {
      return restTemplate(builder, connection);
    } else {
      return restTemplateWithoutValidation(connection);
    }
  }

  public RestTemplate restTemplate(RestTemplateBuilder builder, RestConnection props) {
    if (Objects.nonNull(props) && Objects.requireNonNullElse(props.getSslEnabled(), false)) {
      final var socketFactory = new SSLConnectionSocketFactory(
          Objects.requireNonNull(getSSLContext(props)), NoopHostnameVerifier.INSTANCE);
      final CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory)
          .build();
      final var requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
      builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
          .customizers(metricCustomizer);
    }
    return builder.additionalInterceptors(new RestClientInterceptor()).build();
  }

  @SneakyThrows
  private RestTemplate restTemplateWithoutValidation(RestConnection connection) {

    SSLContext sslContext = getSSLContext(connection);

    SSLConnectionSocketFactory csf = connection.getSsl().getTlsVerification()
        ? new SSLConnectionSocketFactory(sslContext)
        : new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);
    CloseableHttpClient httpClient = HttpClients.custom()
        .setSSLSocketFactory(csf)
        .build();

    HttpComponentsClientHttpRequestFactory requestFactory =
        new HttpComponentsClientHttpRequestFactory();

    requestFactory.setHttpClient(httpClient);
    return builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
        .additionalInterceptors(new RestClientInterceptor())
        .customizers(metricCustomizer)
        .build();
  }

  private static @Nullable
  String getKeyAlias(@Nullable RestConnection props,
      @Nullable KeyStore keyStore) {
    if (Objects.isNull(props) || !Objects.requireNonNullElse(props.getSslEnabled(), false)
        || Objects.isNull(keyStore)) {
      return null;
    }

    try {
      final var aliases = keyStore.aliases();
      for (var alias : Collections.list(aliases)) {
        log.info("Keystore aliases {}", alias);
        if (keyStore.isKeyEntry(alias)) {
          log.info("Keystore found alias {}", alias);
          return alias;
        }
      }
    } catch (KeyStoreException ex) {
      log.error("Error occurred during keystore loading alias", ex);
      throw new RestClientException("Error occurred during keystore loading alias", ex);
    }

    return null;
  }

  private static @Nullable KeyStore getKeystore(@Nullable RestConnection props) {
    if (Objects.isNull(props) || !Objects.requireNonNullElse(props.getSslEnabled(), false)) {
      return null;
    }

    try (var keyStoreInputStream = new FileInputStream(
        ResourceUtils.getFile(props.getSsl().getKeystorePath()))) {
      final var keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(keyStoreInputStream, props.getSsl().getKeystorePass().toCharArray());
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException ex) {
      log.error("Error occurred during keystore loading", ex);
      throw new RestClientException("Error occurred during keystore loading", ex);
    }
  }

  private static @Nullable SSLContext getSSLContext(@Nullable RestConnection props) {
    if (Objects.isNull(props) || !Objects.requireNonNullElse(props.getSslEnabled(), false)) {
      return null;
    }
    final var builder = new SSLContextBuilder();
    try {
      if (Objects.requireNonNullElse(props.getSsl().getClientAuth(), false)) {
        final var keyStore = getKeystore(props);
        final var keyAlias = getKeyAlias(props, keyStore);
        builder.loadKeyMaterial(keyStore, props.getSsl().getKeyPass().toCharArray(),
            ((aliases, socket) -> keyAlias));
      }
      if (Objects.requireNonNullElse(props.getSsl().getCertValidation(), false)) {
        builder.loadTrustMaterial(ResourceUtils.getFile(props.getSsl().getTruststorePath()),
            props.getSsl().getTruststorePass().toCharArray());
      } else {
        builder.loadTrustMaterial(null, (X509Certificate[] chain, String authType) -> true);
      }
      return builder.build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException
        | KeyManagementException | UnrecoverableKeyException e) {
      log.error("Error occurred during SSL context creation", e);
      throw new RestClientException("Error occurred during SSL context creation", e);
    }
  }

  private class RestClientInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
      if (showOutboundRequests) {
        log.info("Request url: {}", request.getURI());
        log.info("Request method: {}", request.getMethodValue());
        log.info("Request headers: {}", request.getHeaders()
            .entrySet()
            .stream()
            .map(stringListEntry -> new StringBuilder(stringListEntry.getKey())
                .append(": ")
                .append(listToDelimitedString(stringListEntry.getValue()))
                .toString()).collect(Collectors.joining("\r\n")));
        if (showBodies) {
          log.info("Request body: {}", body.length > 0 ? new String(body) : "empty");
        }
      }
      final var response = execution.execute(request, body);
      if (showOutboundRequests) {
        log.info("Response status: {}", response.getRawStatusCode());
        log.info("Response headers: {}", response.getHeaders().entrySet()
            .stream()
            .map(stringListEntry -> new StringBuilder(stringListEntry.getKey())
                .append(": ")
                .append(listToDelimitedString(stringListEntry.getValue()))
                .toString()).collect(Collectors.joining("\r\n")));
        final var respBody = response.getBody().readAllBytes();
        if (showBodies) {
          log.info("Response body: {}", respBody.length > 0 ? new String(respBody) : "empty");
        }
      }
      return response;
    }

    private String listToDelimitedString(List<String> lst) {
      if (CollectionUtils.isEmpty(lst)) {
        return "";
      }
      return String.join(", ", lst);
    }
  }
}
