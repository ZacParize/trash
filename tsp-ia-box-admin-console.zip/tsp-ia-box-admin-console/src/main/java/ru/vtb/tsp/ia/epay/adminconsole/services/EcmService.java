package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.Optional;
import java.util.UUID;
import org.springframework.core.io.Resource;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.FileMetaInfoDto;

public interface EcmService {

  Optional<FileMetaInfoDto> uploadFile(MultipartFile file);
  Optional<Resource> downloadFile(UUID uuid);
  boolean deleteFiles(UUID ... ecmUuids);

}
