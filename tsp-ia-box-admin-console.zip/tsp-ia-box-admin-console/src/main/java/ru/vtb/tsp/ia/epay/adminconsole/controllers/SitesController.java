package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import java.util.List;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.api.SiteApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.ChangeSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.NewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.PagingParams;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteActivationParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteHistoryRecordDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortField;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortParams;
import ru.vtb.tsp.ia.epay.adminconsole.services.SiteStatusHistoryService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SitesService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@RestController
@RequiredArgsConstructor
@RequestMapping
public class SitesController implements SiteApi {

  private final SitesService sitesService;
  private final SiteStatusHistoryService historyService;

  @Override
  public ResponseEntity<SiteDto> getSite(String mstId) {
    return sitesService.getSiteByMstId(JwtTokenUtils.getJwtToken(), mstId)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<List<SiteShortDto>> getSites() {
    return ResponseEntity.ok(sitesService.getSitesByMerchant(JwtTokenUtils.getJwtToken()));
  }

  @Override
  public ResponseEntity<SiteDto> postSite(NewSiteDto body) {
    return sitesService.create(JwtTokenUtils.getJwtToken(), body).map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<SiteDto> patchSite(String mstId, ChangeSiteDto body) {
    return sitesService.patch(JwtTokenUtils.getJwtToken(), mstId, body)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<?> activateSite(String mstId, SiteActivationParameters params) {
    return sitesService.activateSite(JwtTokenUtils.getJwtToken(), mstId, params)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<SiteDto> blockSite(String mstId,
      SiteBlockingParameters params) {
    return sitesService.blockSite(JwtTokenUtils.getJwtToken(), mstId, params)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<SiteDto> unblockSite(String mstId,
      SiteUnblockingParameters params) {
    return sitesService.unblockSite(JwtTokenUtils.getJwtToken(), mstId, params)
        .map(ResponseEntity::ok)
        .orElseGet(() -> ResponseEntity.badRequest().build());
  }

  @Override
  public ResponseEntity<Page<SiteHistoryRecordDto>> getHistory(String mstId,
      Integer page,
      Integer pageSize,
      String sortBy,
      Boolean desc) {
    PagingParams paging = null;
    SortParams sort = null;
    if (Objects.nonNull(pageSize)) {
      paging = PagingParams.builder()
          .size(pageSize)
          .page(Objects.requireNonNullElse(page, 0))
          .build();
    }
    if (Objects.nonNull(sortBy)) {
      sort = SortParams.builder()
          .fields(List.of(SortField.builder().field(sortBy)
              .desc(Objects.nonNull(desc) && desc)
              .build()))
          .build();
    }

    final var result = historyService.find(mstId,paging, sort);
    return ResponseEntity.ok(result);
  }

  @Override
  public ResponseEntity<?> deleteSite(String mstId) {
    return SiteApi.super.deleteSite(mstId);
  }
}