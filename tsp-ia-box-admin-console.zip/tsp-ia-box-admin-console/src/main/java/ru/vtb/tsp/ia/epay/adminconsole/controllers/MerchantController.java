package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.api.MerchantApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantNameDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.MerchantService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@RestController
@RequiredArgsConstructor
@RequestMapping
public class MerchantController implements MerchantApi {

  private final MerchantService service;

  @Override
  public ResponseEntity<MerchantShortDto> getMerchant() {
      return service.findMerchantConverted(JwtTokenUtils.getJwtToken()).map(ResponseEntity::ok)
          .get();
  }

  @Override
  public ResponseEntity<MerchantShortDto> postMerchant() {
      return service.createMerchant(JwtTokenUtils.getJwtToken())
          .map(ResponseEntity::ok)
          .orElse(ResponseEntity.status(400).build());
  }

  @Override
  public ResponseEntity<MerchantNameDto> getMerchantName() {
    return service.getMerchantName(JwtTokenUtils.getJwtToken()).map(ResponseEntity::ok).get();
  }
}