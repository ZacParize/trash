package ru.vtb.tsp.ia.epay.adminconsole.scheduler;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;
import ru.vtb.tsp.ia.epay.adminconsole.services.EcmService;
import ru.vtb.tsp.ia.epay.adminconsole.services.StatusFileService;

@Slf4j
@Component
@RequiredArgsConstructor
public class UnlinkedFilesRemovingScheduler {

  private final EcmService ecmService;
  private final StatusFileService statusFileService;

  @Scheduled(cron = "${status-files.unlinked-files.removing-cron}")
  public void removeUnlinkedFiles() {
    log.info("Removing unlinked files");
    final var uuids = statusFileService.findExpiredUnlinkedFiles()
        .stream()
        .map(StatusFileMetaData::getEcmId)
        .toArray(UUID[]::new);
    log.info("Found {} files", uuids.length);
    if (uuids.length == 0) {
      return;
    }
    ecmService.deleteFiles(uuids);
  }

}
