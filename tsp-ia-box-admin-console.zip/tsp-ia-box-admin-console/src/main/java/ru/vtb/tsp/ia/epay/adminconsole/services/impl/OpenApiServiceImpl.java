package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.clients.openapi.OpenApiClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsRequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CredentialsResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.LegalEntityDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.RequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.ResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Client;
import ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata.Organization;
import ru.vtb.tsp.ia.epay.adminconsole.entities.OpenApiCode;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.LegalEntityNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.MerchantNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.repositories.OpenApiCodesRepository;
import ru.vtb.tsp.ia.epay.adminconsole.services.MerchantService;
import ru.vtb.tsp.ia.epay.adminconsole.services.OpenApiService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SessionDataService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.OpenApiUtils;
import tech.inno.apimanager.mnemoniccode.generator.MnemonicCodeGenerator;

@Service
@RequiredArgsConstructor
public class OpenApiServiceImpl implements OpenApiService {

  @Value("${integrations.rests.openapi.appType}")
  private String appType;
  @Value("${integrations.rests.openapi.clientType}")
  private String clientType;
  @Value("${integrations.rests.openapi.infoSystemCode}")
  private String infoSystemCode;

  private final SessionDataService sessionDataService;
  private final MerchantService merchantService;
  private final OpenApiClient openApiClient;
  private final MnemonicCodeGenerator mnemonicCodeGenerator;
  private final OpenApiCodesRepository repository;

  @Override
  public Optional<LegalEntityDto> createLegalEntity(String jwt) {
    return Optional.of(
        sessionDataService.getClient(jwt)
            .map(this::mapToLegalEntityDto)
            .orElseThrow(MerchantNotFoundException::new)
    );
  }

  @Override
  public Optional<CredentialsResponseDto> createCredentials(String jwt,
      CredentialsRequestDto requestDto) {
    final var mdmCode = sessionDataService.getClient(jwt)
        .map(Client::getOrganization)
        .map(Organization::getMdmCode)
        .map(s -> Long.parseLong(s.trim()))
        .orElseThrow(MerchantNotFoundException::new);
    final var request = mapToRequestDto(requestDto);
    return openApiClient.postApplication(request)
        .map(responseDto -> {
          saveMnemocode(
              mdmCode,
              request.getOrgCode(),
              responseDto.getExternalApplicationId());
          return responseDto;
        })
        .map(this::mapToCredentialsResponseDto);

  }

  private RequestDto mapToRequestDto(CredentialsRequestDto requestDto) {
    final var name = OpenApiUtils
        .removeUnsupportedAndReplaceNumsChars(requestDto.getLegalEntityName());
    return RequestDto.builder()
        .applicationType(appType)
        .clientType(clientType)
        .externalApplicationEmail(requestDto.getExternalApplicationEmail().toArray(new String[0]))
        .reasonCreate(requestDto.getReasonCreate())
        .informationSystemName(name)
        .orgCode(mnemonicCodeGenerator.generate(infoSystemCode, name, getAllMnemocodes()))
        .orgId(UUID.randomUUID().toString())
        .externalApplicationName(requestDto.getExternalApplicationName())
        .build();
  }

  private Set<String> getAllMnemocodes() {
    return repository.findAll().stream().map(OpenApiCode::getOrgCode)
        .collect(Collectors.toSet());
  }

  private void saveMnemocode(Long mdmCode, String orgCode, String extAppId) {
    repository.save(OpenApiCode.builder()
        .mdmCode(mdmCode)
        .orgCode(orgCode)
        .externalApplicationId(extAppId)
        .build()
    );
  }

  private CredentialsResponseDto mapToCredentialsResponseDto(ResponseDto responseDto) {
    return CredentialsResponseDto.builder()
        .clientId(responseDto.getClientId().toLowerCase())
        .externalApplicationId(responseDto.getExternalApplicationId())
        .build();
  }

  private LegalEntityDto mapToLegalEntityDto(Client client) {
    return LegalEntityDto
        .builder()
        .externalApplicationName(OpenApiUtils
            .openapiUuid())
        .legalEntityName(Optional.ofNullable(client.getOrganization())
            .map(Organization::getShortName)
            .orElseThrow(LegalEntityNotFoundException::new))
        .build();
  }
}
