package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.data.domain.Page;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderDto;

public interface OrderService {

  Page<OrderDto> getOrders(String orderTransactionCode, List<OrderStatus> status,
      List<UUID> merchantSite, Double amountMin, Double amountMax, int page, int size,
      ZonedDateTime fromDate, ZonedDateTime beforeDate, List<PaymentType> paymentType, String sort,
      SortOrder order, List<SourceSystemSearchFields> sourceSystem, String token);

  FilterDictionariesDto getFilterDictionaries(String token);
}
