package ru.vtb.tsp.ia.epay.adminconsole.dto.consts;

public class AuditEvents {
  public static final String TSPACQ_SMBQ_CREATE_RESOURCE = "TSPACQ_SMBQ_CREATE_RESOURCE";
  public static final String TSPACQ_SMBQ_CHANGE_PARAMS_RESOURCE = "TSPACQ_SMBQ_CHANGE_PARAMS_RESOURCE";
  public static final String TSPACQ_SMBQ_UNLOCKING_RESOURCE = "TSPACQ_SMBQ_UNLOCKING_RESOURCE";
  public static final String TSPACQ_SMBQ_BLOCKING_RESOURCE = "TSPACQ_SMBQ_BLOCKING_RESOURCE";
  public static final String TSPACQ_SMBQ_POST_PORTAL_APPLICATION = "TSPACQ_SMBQ_POST_PORTAL_APPLICATION";
  public static final String TSPACQ_SMBQ_CREATE_MERCHANT = "TSPACQ_SMBQ_CREATE_MERCHANT";
  public static final String TSPACQ_SMBQ_GET_ORDERS = "TSPACQ_SMBQ_GET_ORDERS";
  public static final String TSPACQ_SMBQ_GET_SITES = "TSPACQ_SMBQ_GET_SITES";
}
