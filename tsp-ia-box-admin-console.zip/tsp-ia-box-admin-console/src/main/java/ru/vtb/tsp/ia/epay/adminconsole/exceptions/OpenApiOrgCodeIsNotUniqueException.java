package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Getter;

@Getter
public class OpenApiOrgCodeIsNotUniqueException extends IdentifiedException {

  private final Integer httpCode = 400;
  private final String id = "0120005036";
  private final String errorMessage = "org_code is not unique";
  private final String description = "";

}
