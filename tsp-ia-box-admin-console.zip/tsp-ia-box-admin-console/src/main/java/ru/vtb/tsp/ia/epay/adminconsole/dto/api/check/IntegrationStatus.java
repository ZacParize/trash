package ru.vtb.tsp.ia.epay.adminconsole.dto.api.check;

public enum IntegrationStatus {
  SUCCESS,
  CONFIG_ERROR,
  OTHER_ERROR
}
