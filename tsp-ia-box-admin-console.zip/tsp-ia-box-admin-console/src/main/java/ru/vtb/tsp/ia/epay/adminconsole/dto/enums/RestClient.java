package ru.vtb.tsp.ia.epay.adminconsole.dto.enums;

public enum RestClient {
  MERCHANT_API,
  EPA,
  EPA_AM,
  SESSION_DATA,
  FRKK,
  OPENAPI,
  ECM,
  TRANSACTIONS
}
