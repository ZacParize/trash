package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import static ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus.CONFIG_ERROR;
import static ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus.OTHER_ERROR;
import static ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus.SUCCESS;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.frkk.FrkkClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.merchantapi.MerchantApiClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.openapi.OpenApiClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata.SessionDataClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.transactions.TransactionsClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.CheckResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.CheckService;

@Slf4j
@Service
@RequiredArgsConstructor
public class CheckServiceImpl implements CheckService {

  @Qualifier("epaAmClient")
  private final EpaClient epaAmClient;
  @Qualifier("epaIgClient")
  private final EpaClient epaIgClient;
  private final EcmClient ecmClient;
  private final FrkkClient frkkClient;
  private final MerchantApiClient merchantApiClient;
  private final OpenApiClient openApiClient;
  private final SessionDataClient sessionDataClient;
  private final TransactionsClient transactionsClient;

  @Override
  public CheckResponseDto check() {
    log.info("Call check integrations");
    final var startTime = Instant.now();
    final var result = Stream.of(
        epaAmClient.check(),
        epaIgClient.check(),
        ecmClient.check(),
        frkkClient.check(),
        merchantApiClient.check(),
        openApiClient.check(),
        sessionDataClient.check(),
        transactionsClient.check()
    ).collect(Collectors.toList());

    final var checkStatuses = result.stream()
        .map(IntegrationStatusDto::getStatus)
        .distinct()
        .collect(Collectors.toList());

    log.info("Finish check integrations");
    return CheckResponseDto.builder()
        .checkTime(startTime)
        .commonCheckStatus(getCheckStatus(checkStatuses))
        .integrationStates(result)
        .build();
  }

  private IntegrationStatus getCheckStatus(List<IntegrationStatus> checkStatuses) {
    if (checkStatuses.contains(OTHER_ERROR)) {
      return OTHER_ERROR;
    } else if (checkStatuses.contains(CONFIG_ERROR)) {
      return CONFIG_ERROR;
    } else {
      return SUCCESS;
    }
  }
}
