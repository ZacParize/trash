package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.PagingParams;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteHistoryRecordDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortField;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortParams;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.enums.SiteState;
import ru.vtb.tsp.ia.epay.adminconsole.entities.SiteStatusHistoryRecord;
import ru.vtb.tsp.ia.epay.adminconsole.repositories.SiteStatusHistoryRepository;
import ru.vtb.tsp.ia.epay.adminconsole.services.FrkkService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SiteStatusHistoryService;
import ru.vtb.tsp.ia.epay.adminconsole.services.StatusFileService;
import ru.vtb.tsp.ia.epay.adminconsole.specifications.SiteStatusHistorySpecification;

@Service
@RequiredArgsConstructor
public class SiteStatusHistoryServiceImpl implements SiteStatusHistoryService {

  private final static SortParams defaultSort = SortParams.builder()
      .fields(List.of(SortField.builder().field("created").desc(true).build()))
      .build();

  private final SiteStatusHistoryRepository repository;
  private final StatusFileService statusFileService;
  private final FrkkService frkkService;

  @Override
  public List<SiteHistoryRecordDto> find(String mstId) {
    return repository.findAll(SiteStatusHistorySpecification.findSorted(mstId, defaultSort))
        .stream()
        .map(this::mapToDto)
        .collect(Collectors.toList());
  }

  @Override
  public Optional<SiteHistoryRecordDto> findLast(String mstId) {
    return repository
        .findAll(SiteStatusHistorySpecification.findLastRecord(mstId))
        .stream()
        .findFirst()
        .map(this::mapToDto);
  }

  @Override
  public List<SiteHistoryRecordDto> find(String mstId, SortParams sortParams) {
    if (Objects.isNull(sortParams)) {
      return find(mstId);
    }
    return repository
        .findAll(SiteStatusHistorySpecification.findSorted(mstId, sortParams))
        .stream()
        .map(this::mapToDto)
        .collect(Collectors.toList());
  }

  @Override
  public Page<SiteHistoryRecordDto> find(String mstId, PagingParams pagingParams) {
    return repository.
        findAll(SiteStatusHistorySpecification.findSorted(mstId, defaultSort), pageableFromDto(pagingParams))
        .map(this::mapToDto);
  }

  @Override
  public Page<SiteHistoryRecordDto> find(String mstId, PagingParams pagingParams,
      SortParams sortParams) {
    if (Objects.isNull(pagingParams)) {
      return fromList(find(mstId, sortParams));
    }
    if (Objects.isNull(sortParams)) {
      return find(mstId, pagingParams);
    }
    return repository.findAll(SiteStatusHistorySpecification.findSorted(mstId, sortParams),
            pageableFromDto(pagingParams))
        .map(this::mapToDto);
  }

  @Override
  public Optional<SiteStatusHistoryRecord> save(SiteStatusHistoryRecord record) {
    return Optional.of(repository.save(record));
  }

  public Optional<SiteHistoryRecordDto> newSite(String mstId) {
    return save(SiteStatusHistoryRecord.builder()
        .mstId(mstId)
        .created(OffsetDateTime.now())
        .state(SiteState.ACTIVE.name())
        .reason("")
        .user(frkkService.getLogin())
        .build()).map(this::mapToDto);
  }

  public Optional<SiteHistoryRecordDto> blockSite(String mstId, SiteBlockingParameters params) {
    final var files = statusFileService.findByCssUuids(params.getFiles());
    return save(SiteStatusHistoryRecord.builder()
        .mstId(mstId)
        .user(frkkService.getLogin())
        .state(SiteState.BLOCKED.name())
        .created(OffsetDateTime.now())
        .reason(params.getBlockReason())
        .files(files)
        .build()).map(record -> {
          files.forEach(statusFileMetaData -> {
            statusFileMetaData.setStatusId(record.getStatusId());
          });
          statusFileService.saveAll(files);
          return record;
        })
        .map(this::mapToDto);
  }

  public Optional<SiteHistoryRecordDto> unblockSite(String mstId,
      SiteUnblockingParameters params) {
    final var files = statusFileService.findByCssUuids(params.getFiles());
    return save(SiteStatusHistoryRecord.builder()
        .mstId(mstId)
        .user(frkkService.getLogin())
        .state(SiteState.ACTIVE.name())
        .created(OffsetDateTime.now())
        .reason(params.getUnblockReason())
        .files(files)
        .build()).map(record -> {
          files.forEach(statusFileMetaData -> {
            statusFileMetaData.setStatusId(record.getStatusId());
          });
          statusFileService.saveAll(files);
          return record;
        })
        .map(this::mapToDto);
  }

  private org.springframework.data.domain.Pageable pageableFromDto(PagingParams pagingParams) {
    return PageRequest.of(pagingParams.getPage(), pagingParams.getSize());
  }

  private SiteHistoryRecordDto mapToDto(SiteStatusHistoryRecord record) {
    return SiteHistoryRecordDto.builder()
        .created(record.getCreated())
        .state(record.getState())
        .reason(record.getReason())
        .files(statusFileService.fromListToListDto(record.getFiles()))
        .build();
  }

  private Page<SiteHistoryRecordDto> fromList(List<SiteHistoryRecordDto> records) {
    if (CollectionUtils.isEmpty(records)) {
      return Page.empty();
    }
    final var pageable = PageRequest.of(0, records.size());
    return new PageImpl<SiteHistoryRecordDto>(records, pageable, records.size());
  }
}
