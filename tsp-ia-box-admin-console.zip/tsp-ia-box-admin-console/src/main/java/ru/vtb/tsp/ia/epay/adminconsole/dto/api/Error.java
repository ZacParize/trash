package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.ResponseEntity;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.07.2022
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties
public class Error {

  private String id;
  private Integer code;
  private String message;
  private String description;
  private String traceId;
  @JsonIgnore
  private Integer httpCode;

  public ResponseEntity<Object> toResponse() {
    return ResponseEntity.status(httpCode).body(this);
  }
}
