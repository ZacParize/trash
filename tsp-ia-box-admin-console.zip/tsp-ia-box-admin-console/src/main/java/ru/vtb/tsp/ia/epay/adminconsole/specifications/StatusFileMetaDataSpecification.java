package ru.vtb.tsp.ia.epay.adminconsole.specifications;

import java.util.List;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import org.springframework.data.jpa.domain.Specification;
import ru.vtb.tsp.ia.epay.adminconsole.entities.StatusFileMetaData;

@UtilityClass
public class StatusFileMetaDataSpecification {

  private static final String STATUS_ID = "statusId";
  private static final String ECM_ID = "ecmId";

  public static Specification<StatusFileMetaData> findByCssUuids(List<UUID> uuids) {
    return (root, criteriaQuery, criteriaBuilder) ->
        root.get(ECM_ID).in(uuids);
  }

  public static Specification<StatusFileMetaData> findByCssUuid(UUID id) {
    return (root, criteriaQuery, criteriaBuilder)
        -> criteriaBuilder.equal(root.get(ECM_ID), id);
  }

  public static Specification<StatusFileMetaData> findByStatusId(Long id) {
    return (root, criteriaQuery, criteriaBuilder)
        -> criteriaBuilder.equal(root.get(STATUS_ID), id);
  }

}
