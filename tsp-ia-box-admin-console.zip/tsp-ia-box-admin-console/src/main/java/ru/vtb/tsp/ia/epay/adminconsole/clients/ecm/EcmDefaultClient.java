package ru.vtb.tsp.ia.epay.adminconsole.clients.ecm;

import static ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmStatusHandlers.deleteExceptionHandler;
import static ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmStatusHandlers.deleteStatusHandler;
import static ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmStatusHandlers.downloadStatusHandler;
import static ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmStatusHandlers.exceptionHandler;
import static ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmStatusHandlers.uploadStatusHandler;

import java.net.URI;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.ecm.FileInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;
import ru.vtb.tsp.ia.epay.adminconsole.utils.FileUtils;

@Conditional(OnlyNotDevAndLocal.class)
@Component
@RequiredArgsConstructor
@Slf4j
public class EcmDefaultClient implements EcmClient {

  private static final String INTEGRATION_NAME = "СХК";
  private static final String UUID = "uuid";
  private static final String UUIDS = "uuids";
  private static final String EXP_DATE = "expirationDate";
  private static final String UPLOAD = "/files?" + EXP_DATE + "={" + EXP_DATE + "}";
  private static final String DOWNLOAD = "/files/{" + UUID + "}";
  private static final String DELETE = "/files?" + UUIDS + "={" + UUIDS + "}";
  private static final String DATETIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";
  private static final String TRASH_CONFIG = "/trash-config";

  @Qualifier("epaIgClient")
  private final EpaClient epaClient;
  @Qualifier("ecmRestClient")
  private final RestTemplate restTemplate;
  private final Integrations integrations;

  @SneakyThrows
  @Override
  public Optional<UUID> uploadFile(MultipartFile resource) {
    log.info("Uploading file to ECM: {}", resource.getOriginalFilename());
    final var headers = headers(epaClient, MediaType.APPLICATION_OCTET_STREAM);

    FileUtils.createContentDisposition(resource.getOriginalFilename())
        .ifPresent(headers::setContentDisposition);

    final String url = integrations.getConnection(RestClient.ECM).getHost().concat(UPLOAD);
    final String date = OffsetDateTime.now(ZoneOffset.UTC)
        .plusYears(5)
        .format(DateTimeFormatter.ofPattern(DATETIME_PATTERN));

    final var entity = new HttpEntity<>(resource.getBytes(), headers);
    try {
      final var response = restTemplate
          .exchange(url, HttpMethod.POST, entity, FileInfoDto.class, date);
      return uploadStatusHandler(response, resource).handle();
    } catch (HttpClientErrorException e) {
      return exceptionHandler(e, UUID.class).handle();
    }
  }

  @Override
  public Optional<Resource> downloadFile(UUID fileUuid) {
    final var headers = headers(epaClient, MediaType.APPLICATION_OCTET_STREAM);
    final String url = integrations.getConnection(RestClient.ECM).getHost().concat(DOWNLOAD);
    final var entity = new HttpEntity<byte[]>(headers);

    try {
      final var response = restTemplate.exchange(url, HttpMethod.GET, entity,
          byte[].class, fileUuid);
      return downloadStatusHandler(response, fileUuid).handle();
    } catch (HttpClientErrorException e) {
      return exceptionHandler(e, Resource.class).handle();
    }
  }

  @Override
  public boolean deleteFiles(UUID... fileUUID) {
    final var headers = headers(epaClient, MediaType.APPLICATION_OCTET_STREAM);
    final String url = integrations.getConnection(RestClient.ECM).getHost().concat(DELETE);
    final var entity = new HttpEntity<byte[]>(headers);
    try {
      final var response = restTemplate.exchange(url, HttpMethod.DELETE, entity, void.class,
          fileUUID);
      return deleteStatusHandler(response, fileUUID).handle();
    } catch (HttpClientErrorException e) {
      return deleteExceptionHandler(e).handle();
    }
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    try {
      final URI uri = UriComponentsBuilder
          .fromHttpUrl(integrations.getConnection(RestClient.ECM).getHost().concat(TRASH_CONFIG))
          .build().toUri();
      restTemplate.optionsForAllow(uri);
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }
}
