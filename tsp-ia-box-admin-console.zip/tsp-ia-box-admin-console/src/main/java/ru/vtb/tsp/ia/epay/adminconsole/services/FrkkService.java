package ru.vtb.tsp.ia.epay.adminconsole.services;

import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;

public interface FrkkService {

  boolean checkRole(FrkkRoles role, String jwtToken);
  String getLogin();

}
