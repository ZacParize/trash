package ru.vtb.tsp.ia.epay.adminconsole.dto.transactions;

import java.util.List;
import lombok.Builder;
import lombok.Data;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.MerchantSiteState;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;

@Data
@Builder
public class FilterDictionariesDto {

  private List<OrderSiteDto> orderSites;
  private List<MerchantSiteState> merchantSiteStates;
  private List<PaymentType> paymentTypes;
  private List<SourceSystemSearchFields> sourceSystemSearchFields;
}
