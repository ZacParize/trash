package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 21.07.2022
 */
@Data
public class ObjectNotFoundException extends IdentifiedException {

  private final Integer httpCode = 404;
  private final String id = "0120005033";
  private final String errorMessage = "Object is not found";
  private final String description = "Для данного действия необходимо сначала выбрать ТСП";

}
