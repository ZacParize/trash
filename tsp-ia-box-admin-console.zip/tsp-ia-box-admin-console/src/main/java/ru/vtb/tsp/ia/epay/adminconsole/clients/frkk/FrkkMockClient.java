package ru.vtb.tsp.ia.epay.adminconsole.clients.frkk;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserGroup;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserRole;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.Attributes;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.RoleInfo;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.UserInfo;

@Component
@Conditional(OnlyDevOrLocal.class)
@Order(2)
@RequiredArgsConstructor
public class FrkkMockClient implements FrkkClient {

  @Override
  public Optional<UserInfo> getUserInfo(String token) {
    return Optional.of(UserInfo.builder()
        .roles(UserGroup.DEFAULT.getRoles().stream()
            .map(UserRole::getName)
            .collect(Collectors.toList()))
        .attributes(Attributes.builder()
            .company("")
            .department("Отдель поддержки дистанционного обслуживания")
            .domain("test.ru")
            .email("tech_sup_smb@test.ru")
            .info("")
            .employeeNumber("26112118")
            .employeeType("EMPLOYEE")
            .firstName("TECH_SUP ")
            .lastName("FRCORP")
            .generationQualifier("80006997")
            .login("tech_sup_smb")
            .middleName("SMB")
            .name("FRCORP  TECH_SUP  SMB")
            .roleInfo(List.of(RoleInfo.builder().roleFullName("Администратор поддержки СМБ")
                .roleShortName("Сотрудник тех поддержки СМБ").build()))
            .region("г. Москва")
            .title("Менеджер")
            .tpCode(" ")
            .trmCode(" ")
            .userPrincipalName("tech_sup_smb@test.ru")
            .build())
        .build());
  }

  @Override
  public Optional<UserInfo> getUserInfo() {
    return getUserInfo(" ");
  }

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("FrkkMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
