package ru.vtb.tsp.ia.epay.adminconsole.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@Configuration
@EnableJpaRepositories(basePackages = "ru.vtb.tsp.ia.epay.adminconsole.repositories")
public class DbConfig {

}
