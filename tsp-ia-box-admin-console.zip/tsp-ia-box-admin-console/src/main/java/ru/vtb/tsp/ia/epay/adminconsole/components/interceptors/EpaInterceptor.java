package ru.vtb.tsp.ia.epay.adminconsole.components.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;

@RequiredArgsConstructor
@Component
@Slf4j
public class EpaInterceptor implements HandlerInterceptor {

  @Qualifier("epaIgClient")
  private final EpaClient epaIgClient;
  @Qualifier("epaAmClient")
  private final EpaClient epaAmClient;

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    epaIgClient.getToken();
    epaAmClient.getToken();
    return HandlerInterceptor.super.preHandle(request, response, handler);
  }
}
