package ru.vtb.tsp.ia.epay.adminconsole.api;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.UUID;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.PageOrderDto;

@Tag(name = "Order", description = "Api for order services")
@SecurityRequirement(name = "bearerAuth")
public interface OrderApi {

  @Operation(operationId = "getOrders", method = "GET", tags = "Order",
      description = "Returns orders",
      summary = "Get orders",
      parameters = {
          @Parameter(name = "orderTransactionCode", in = ParameterIn.QUERY,
              description = "Код транзакции заказа",
              schema = @Schema(
                  type = "string", minLength = 1, maxLength = 255,
                  description = "Код транзакции заказа")),
          @Parameter(name = "status", in = ParameterIn.QUERY,
              description = "Список статусов заказа",
              array = @ArraySchema(arraySchema = @Schema(
                  type = "array", nullable = true),
                  schema = @Schema(implementation = OrderStatus.class),
                  minItems = 0, maxItems = 100)
          ),
          @Parameter(name = "merchantSite", in = ParameterIn.QUERY,
              description = "Список сайтов продавца",
              array = @ArraySchema(arraySchema = @Schema(
                  type = "array", nullable = true, description = "Список статусов заказа"),
                  schema = @Schema(
                      type = "string",
                      description = "Код",
                      pattern = "^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$",
                      example = "da38c357-64e7-438e-a1cb-bb9db8b286f0",
                      minLength = 36, maxLength = 36),
                  minItems = 0, maxItems = 100)
          ),
          @Parameter(name = "amountMin", in = ParameterIn.QUERY,
              description = "Сумма минимум",
              schema = @Schema(type = "number",
                  maximum = "1.7976931348623157e+308",
                  minimum = "2.2250738585072014E-308",
                  description = "Сумма минимум", nullable = true)
          ),
          @Parameter(name = "amountMax", in = ParameterIn.QUERY,
              description = "amountMax",
              schema = @Schema(type = "number",
                  description = "Сумма максимум", nullable = true,
                  maximum = "1.7976931348623157e+308",
                  minimum = "2.2250738585072014E-308")
          ),
          @Parameter(name = "page", in = ParameterIn.QUERY,
              description = "Номер страницы (пагинация)",
              schema = @Schema(type = "integer",
                  description = "Номер страницы (пагинация)", nullable = true,
                  minimum = "0", maximum = "2147483647", example = "0", defaultValue = "0")
          ),
          @Parameter(name = "size", in = ParameterIn.QUERY,
              description = "Количество элементов (пагинация)",
              schema = @Schema(type = "integer",
                  description = "Количество элементов (пагинация)", nullable = true,
                  minimum = "0", maximum = "2147483647", example = "20", defaultValue = "20")
          ),
          @Parameter(name = "fromDate", in = ParameterIn.QUERY,
              description = "Дата после которой искать",
              schema = @Schema(type = "string", format = "date-time",
                  pattern = "^[0-9]{4}-((0[1-9])|(1[0-2]))-[0-9]{2}(T[0-9]{2}:[0-9]{2}:[0-9]{2}(()|(.[0-9]{1,6})(Z|([+-](0[0-9]|1[0-2]):([0-5][0-9])))|(.[0-9]{1,6}))|)$",
                  description = "Дата после которой искать",
                  nullable = true,
                  example = "2029-02-11T00:05:01.001Z")
          ),
          @Parameter(name = "beforeDate", in = ParameterIn.QUERY,
              description = "Дата до которой искать",
              schema = @Schema(type = "string", format = "date-time",
                  pattern = "^[0-9]{4}-((0[1-9])|(1[0-2]))-[0-9]{2}(T[0-9]{2}:[0-9]{2}:[0-9]{2}(()|(.[0-9]{1,6})(Z|([+-](0[0-9]|1[0-2]):([0-5][0-9])))|(.[0-9]{1,6}))|)$",
                  description = "Дата до которой искать",
                  nullable = true,
                  example = "2029-02-11T00:05:01.001Z")
          ),
          @Parameter(name = "paymentType", in = ParameterIn.QUERY,
              description = "Список типов оплаты",
              array = @ArraySchema(arraySchema = @Schema(
                  type = "array", nullable = true, description = "Список способов оплаты"),
                  schema = @Schema(implementation = PaymentType.class),
                  minItems = 0, maxItems = 100)
          ),
          @Parameter(name = "sort", in = ParameterIn.QUERY,
              description = "Сортировка",
              schema = @Schema(
                  type = "string", minLength = 1, maxLength = 255, example = "createdDate", defaultValue = "createdDate",
                  description = "Сортировка")),
          @Parameter(name = "order", in = ParameterIn.QUERY,
              description = "Порядок сортировки",
              schema = @Schema(implementation = SortOrder.class, nullable = true)
          ),
          @Parameter(name = "sourceSystem", in = ParameterIn.QUERY,
              description = "Поля поиска исходной системы",
              array = @ArraySchema(arraySchema = @Schema(
                  type = "array", nullable = true, description = "Поля поиска исходной системы"),
                  schema = @Schema(implementation = SourceSystemSearchFields.class),
                  minItems = 0, maxItems = 100)
          )
      }
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = PageOrderDto.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "404", description = "Not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      })
  })
  ResponseEntity<PageOrderDto> getOrders(String orderTransactionCode, List<OrderStatus> status,
      List<UUID> merchantSite, Double amountMin, Double amountMax, int page, int size,
      ZonedDateTime fromDate, ZonedDateTime beforeDate, List<PaymentType> paymentType, String sort,
      SortOrder order, List<SourceSystemSearchFields> sourceSystem,
      @Parameter(hidden = true) String token);

  @Operation(operationId = "getFilters", method = "GET", tags = "Filter",
      description = "Returns data for filters",
      summary = "Get data for filters"
  )
  @ApiResponses({
      @ApiResponse(responseCode = "200", description = "OK", content = {
          @Content(
              schema = @Schema(implementation = FilterDictionariesDto.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "403", description = "Permission denied", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "404", description = "Not found", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      }),
      @ApiResponse(responseCode = "500", description = "Technical error", content = {
          @Content(
              schema = @Schema(implementation = Error.class),
              mediaType = MediaType.APPLICATION_JSON_VALUE
          )
      })
  })
  ResponseEntity<FilterDictionariesDto> getFilterDictionaries(
      @Parameter(hidden = true) String token);
}
