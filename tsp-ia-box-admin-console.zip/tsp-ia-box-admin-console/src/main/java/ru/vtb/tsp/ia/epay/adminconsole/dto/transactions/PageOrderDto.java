package ru.vtb.tsp.ia.epay.adminconsole.dto.transactions;

import lombok.Builder;
import lombok.Data;
import org.springframework.data.domain.PageImpl;

@Data
@Builder
public class PageOrderDto {

  private PageImpl<OrderDto> page;
}
