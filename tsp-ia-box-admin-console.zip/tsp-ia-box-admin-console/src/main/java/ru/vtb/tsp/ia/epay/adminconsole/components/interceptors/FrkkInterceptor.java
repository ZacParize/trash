package ru.vtb.tsp.ia.epay.adminconsole.components.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;
import ru.vtb.tsp.ia.epay.adminconsole.services.FrkkService;
import ru.vtb.tsp.ia.epay.adminconsole.utils.ErrorUtils;

@RequiredArgsConstructor
@Slf4j
@Component
public class FrkkInterceptor implements HandlerInterceptor {

  private final FrkkService frkkService;

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    final var method = (HandlerMethod) handler;
    final var token = request.getHeader(HttpHeaders.AUTHORIZATION);
    if (method.hasMethodAnnotation(FrkkRoles.class)) {
      try {
        frkkService.checkRole(method.getMethodAnnotation(FrkkRoles.class), token);
      } catch (Exception e) {
        ErrorUtils.exceptionToServletResponse(e, response);
        return false;
      }
    }
    return HandlerInterceptor.super.preHandle(request, response, handler);
  }
}
