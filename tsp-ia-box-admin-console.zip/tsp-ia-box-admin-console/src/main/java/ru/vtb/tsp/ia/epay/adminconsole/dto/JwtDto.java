package ru.vtb.tsp.ia.epay.adminconsole.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 28.06.2022
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class JwtDto {
  private String sub;
  private String[] scope;
  private String channel;
  private String iss;
  private String typ;
  private String ctxi;
  private String exp;
  private String iat;
  private String jti;
}
