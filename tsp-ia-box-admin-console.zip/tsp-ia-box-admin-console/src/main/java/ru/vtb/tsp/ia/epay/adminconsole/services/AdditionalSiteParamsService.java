package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.Map;
import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.entities.AdditionalSiteParams;

public interface AdditionalSiteParamsService {

  Map<String, AdditionalSiteParams> getByMdmCode(Long mdmCode);
  Optional<AdditionalSiteParams> getBySiteId(String siteId);
  Optional<AdditionalSiteParams> save(AdditionalSiteParams params);
  Optional<AdditionalSiteParams> updateOrSave(AdditionalSiteParams params);
}
