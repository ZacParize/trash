package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

@Data
public class FileDeleteException extends IdentifiedException {

  private final Integer httpCode = 400;
  private final String id = "0120005042";
  private final String errorMessage = "file_del_error";
  private final String description = "";

}
