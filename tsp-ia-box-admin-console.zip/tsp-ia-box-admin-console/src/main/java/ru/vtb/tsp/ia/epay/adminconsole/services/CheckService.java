package ru.vtb.tsp.ia.epay.adminconsole.services;

import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.CheckResponseDto;

public interface CheckService {

  CheckResponseDto check();
}
