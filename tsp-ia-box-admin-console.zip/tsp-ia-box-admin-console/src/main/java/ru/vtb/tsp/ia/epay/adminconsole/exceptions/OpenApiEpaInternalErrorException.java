package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Getter;

@Getter
public class OpenApiEpaInternalErrorException extends IdentifiedException {

  private final Integer httpCode = 500;
  private final String id = "0120005039";
  private final String errorMessage = "epa_internal_error";
  private final String description = "";

}
