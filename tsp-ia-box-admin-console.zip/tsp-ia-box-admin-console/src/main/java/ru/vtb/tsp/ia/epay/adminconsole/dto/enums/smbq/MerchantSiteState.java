package ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq;

public enum MerchantSiteState {
  CREATED,
  PAID,
  REFUNDED,
  PARTIALLY_REFUNDED,
  EXPIRED,
  CANCELED,
  REFUND_REQUEST
}
