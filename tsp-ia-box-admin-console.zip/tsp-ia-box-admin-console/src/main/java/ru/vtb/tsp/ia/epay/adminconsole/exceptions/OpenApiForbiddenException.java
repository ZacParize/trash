package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Getter;

@Getter
public class OpenApiForbiddenException extends IdentifiedException {

  private final Integer httpCode = 403;
  private final String id = "0120005038";
  private final String errorMessage = "forbidden";
  private final String description = "";

}
