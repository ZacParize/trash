package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.07.2022
 */
@Data
public class IdentifiedException extends RuntimeException {

  private final Integer httpCode = 500;
  private final String id = "0120005032";
  private final String errorMessage = "Technical error";
  private final String description = "Что-то пошло не так, попробуйте позднее";

}
