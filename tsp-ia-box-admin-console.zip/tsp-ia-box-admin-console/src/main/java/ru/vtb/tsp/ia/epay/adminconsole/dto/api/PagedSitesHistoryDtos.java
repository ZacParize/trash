package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

@Schema
@JsonIgnoreProperties
public class PagedSitesHistoryDtos extends PageImpl<SiteHistoryRecordDto> {

  public PagedSitesHistoryDtos(
      List<SiteHistoryRecordDto> content, Pageable pageable,
      long total) {
    super(content, pageable, total);
  }

  public PagedSitesHistoryDtos(
      List<SiteHistoryRecordDto> content) {
    super(content);
  }
}
