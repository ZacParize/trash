package ru.vtb.tsp.ia.epay.adminconsole.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.util.Objects;
import lombok.experimental.UtilityClass;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 04.07.2022
 */
@UtilityClass
public class JsonUtils {

  private static volatile ObjectMapper objectMapper;

  public static ObjectMapper mapper() {
    var mapper = objectMapper;
    if (Objects.isNull(mapper)) {
      synchronized (ObjectMapper.class) {
        mapper = objectMapper;
        if (Objects.isNull(mapper)) {
          mapper = new ObjectMapper()
              .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
              .configure(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT, true)
              .configure(DeserializationFeature.ACCEPT_EMPTY_ARRAY_AS_NULL_OBJECT, true)
              .configure(DeserializationFeature.ACCEPT_FLOAT_AS_INT, true)
              .configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true)
              .configure(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE, true);
          mapper.registerModule(new JavaTimeModule());
          objectMapper = mapper;
        }
      }
    }
    return mapper;
  }

}
