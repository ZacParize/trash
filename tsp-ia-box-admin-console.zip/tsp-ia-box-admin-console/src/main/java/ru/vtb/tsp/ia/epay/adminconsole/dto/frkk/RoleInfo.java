package ru.vtb.tsp.ia.epay.adminconsole.dto.frkk;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoleInfo {
    @JsonProperty("role_short_name")
    public String roleShortName;
    @JsonProperty("role_full_name")
    public String roleFullName;
}
