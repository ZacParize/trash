package ru.vtb.tsp.ia.epay.adminconsole.clients.transactions;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Conditional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.MerchantSiteState;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SortOrder;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.SourceSystemSearchFields;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.FilterDictionariesDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.transactions.OrderSiteDto;

@Conditional(OnlyDevOrLocal.class)
@Component
@Slf4j
public class TransactionsMockClient implements TransactionsClient {

  final ObjectMapper objectMapper = new ObjectMapper();

  @Override
  public Page<OrderDto> getOrders(String orderTransactionCode, List<OrderStatus> status,
      List<UUID> merchantSite, Double amountMin, Double amountMax, int page, int size,
      ZonedDateTime fromDate, ZonedDateTime beforeDate, List<PaymentType> paymentType, String sort,
      SortOrder order, List<SourceSystemSearchFields> sourceSystem, String token) {

    List<OrderDto> result;
    try (InputStream is = TransactionsMockClient.class.getResourceAsStream(
        "/integrations/orders.json")) {
      result = objectMapper.readValue(is, new TypeReference<>() {
      });
    } catch (IOException e) {
      log.error("Resource file error!");
      throw new RuntimeException(e);
    }

    if (StringUtils.isNotEmpty(orderTransactionCode)) {
      return new PageImpl<>(
          result.stream().filter(it -> orderTransactionCode.equals(it.getOrderCode()))
              .collect(Collectors.toList()));
    }

    if (!CollectionUtils.isEmpty(status)) {
      return new PageImpl<>(result.stream().filter(it -> status.contains(it.getStatus()))
          .collect(Collectors.toList()));
    }

    if (!CollectionUtils.isEmpty(merchantSite)) {
      return new PageImpl<>(result.stream()
          .filter(it -> merchantSite.contains(UUID.fromString(it.getOrderMerchantId())))
          .collect(Collectors.toList()));
    }

    if (Objects.nonNull(amountMin) || Objects.nonNull(amountMax)) {
      if (Objects.isNull(amountMin)) {
        return new PageImpl<>(result.stream().filter(it -> it.getAmount().getValue() <= amountMax)
            .collect(Collectors.toList()));
      } else if (Objects.isNull(amountMax)) {
        return new PageImpl<>(result.stream().filter(it -> it.getAmount().getValue() >= amountMin)
            .collect(Collectors.toList()));
      } else {
        return new PageImpl<>(result.stream().filter(
                it -> it.getAmount().getValue() >= amountMin && it.getAmount().getValue() <= amountMax)
            .collect(Collectors.toList()));
      }
    }

    if (Objects.nonNull(fromDate) || Objects.nonNull(beforeDate)) {
      if (Objects.isNull(fromDate)) {
        return new PageImpl<>(result.stream()
            .filter(it -> ZonedDateTime.parse(it.getCreatedDate()).compareTo(beforeDate) <= 0)
            .collect(Collectors.toList()));
      } else if (Objects.isNull(beforeDate)) {
        return new PageImpl<>(result.stream()
            .filter(it -> ZonedDateTime.parse(it.getCreatedDate()).compareTo(fromDate) >= 0)
            .collect(Collectors.toList()));
      } else {
        return new PageImpl<>(result.stream()
            .filter(it -> ZonedDateTime.parse(it.getCreatedDate()).compareTo(fromDate) >= 0
                && ZonedDateTime.parse(it.getCreatedDate()).compareTo(beforeDate) <= 0)
            .collect(Collectors.toList()));
      }
    }

    if (!CollectionUtils.isEmpty(paymentType)) {
      return new PageImpl<>(result.stream()
          .filter(it -> paymentType.contains(it.getPaymentType()))
          .collect(Collectors.toList()));
    }

    if (!CollectionUtils.isEmpty(sourceSystem)) {
      return new PageImpl<>(result.stream().filter(
              it -> sourceSystem.contains(SourceSystemSearchFields.valueOf(it.getSourceSystem())))
          .collect(Collectors.toList()));
    }

    return new PageImpl<>(result);
  }

  @Override
  public FilterDictionariesDto getFilterDictionaries(String token) {
    final OrderSiteDto orderSite = OrderSiteDto.builder().id("id").url("url").build();
    return FilterDictionariesDto.builder()
        .orderSites(List.of(orderSite))
        .merchantSiteStates(List.of(MerchantSiteState.values()))
        .paymentTypes(List.of(PaymentType.values()))
        .sourceSystemSearchFields(List.of(SourceSystemSearchFields.values()))
        .build();
  }

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("TransactionsMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
