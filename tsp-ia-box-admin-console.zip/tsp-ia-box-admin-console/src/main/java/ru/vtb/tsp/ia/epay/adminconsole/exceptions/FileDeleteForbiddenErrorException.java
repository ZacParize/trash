package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

@Data
public class FileDeleteForbiddenErrorException extends IdentifiedException {

  private final Integer httpCode = 403;
  private final String id = "0120005044";
  private final String errorMessage = "del_forbidden";
  private final String description = "";

}
