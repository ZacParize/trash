package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.ZoneId;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.CardParamsDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.ChangeSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.NewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SbpParamsDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteActivationParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteHistoryRecordDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteParamsDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.StateDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.enums.SiteState;
import ru.vtb.tsp.ia.epay.adminconsole.dto.consts.AuditEvents;
import ru.vtb.tsp.ia.epay.adminconsole.dto.db.AdditionalSiteParamsData;
import ru.vtb.tsp.ia.epay.adminconsole.entities.AdditionalSiteParams;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IncorrectNewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.MerchantNotFoundException;
import ru.vtb.tsp.ia.epay.adminconsole.services.AdditionalSiteParamsService;
import ru.vtb.tsp.ia.epay.adminconsole.services.MerchantService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SessionDataService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SiteStatusHistoryService;
import ru.vtb.tsp.ia.epay.adminconsole.services.SitesService;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClient;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCardParamsDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteSbpParamsDto;

@Service
@RequiredArgsConstructor
public class SitesServiceImpl implements SitesService {

  private static final String ACTIVE = "Active";
  private static final String BLOCKED = "Blocked";

  private final SessionDataService service;
  private final SiteStatusHistoryService historyService;
  private final AdditionalSiteParamsService paramsService;
  private final MerchantService merchantService;
  private final MerchantApiClient client;
  private final @Qualifier("objectNonNullMapper")
  ObjectMapper objectNonNullMapper;

  @Value("${extAppIds.paykeeper}")
  private String paykeeperExtAppId;

  @Override
  public List<SiteShortDto> getSitesByMerchant(String jwt) {
    final var merchantData = service.getMdmCodes(jwt);
    if (CollectionUtils.isEmpty(merchantData)) {
      throw new MerchantNotFoundException();
    }
    final var filter = MerchantSiteFilter.builder()
        .mdmCode(merchantData.iterator().next())
        .state(Set.of(ACTIVE, BLOCKED))
        .build();

    return client.getMerchantSites(filter, null)
        .stream()
        .map(site -> mapMerchantApiSiteShortDto(site).orElse(null))
        .map(siteShortDto -> {
          historyService
              .findLast(siteShortDto.getId())
              .ifPresent(historyRecord -> {
                siteShortDto.setState(mapToStateDto(historyRecord));
              });
          return siteShortDto;
        })
        .collect(Collectors.toList());
  }

  @Override
  public Optional<SiteDto> getSiteByMstId(String jwt, String mstId) {
    merchantService.findMerchant(jwt);
    return client.getMerchantSite(mstId)
        .flatMap(this::mapMerchantApiSiteDto)
        .map(siteDto -> paramsService.getBySiteId(siteDto.getId())
            .map(AdditionalSiteParams::getParams)
            .map(paramsDto -> {
              siteDto.setPartnershipChannel(paramsDto.getPartnershipChannel());
              siteDto.setPartnershipName(paramsDto.getPartnershipName());
              siteDto.setEmail(paramsDto.getEmail());
              siteDto.setPhone(paramsDto.getPhone());
              return siteDto;
            })
            .map(siteDto1 -> {
              historyService
                  .findLast(siteDto1.getId())
                  .ifPresent(historyRecord -> {
                    siteDto1.setState(mapToStateDto(historyRecord));
                  });
              return siteDto1;
            })
            .orElse(siteDto));
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_CREATE_RESOURCE)
  public Optional<SiteDto> create(String jwt, NewSiteDto body) {
    Optional<MerchantDto> merchantDto = getMerchantDto(jwt);
    merchantDto.orElseThrow(MerchantNotFoundException::new);
    return merchantDto.flatMap(dto -> mapNewSiteDto(dto.getId(), body))
        .flatMap(this::validateMerchantSiteParams)
        .flatMap(client::createMerchantSite)
        .flatMap(this::mapMerchantApiSiteDto)
        .map(siteDto -> {
          final var paramsData = AdditionalSiteParamsData.builder()
              .email(body.getEmail())
              .partnershipChannel(body.getPartnershipChannel())
              .phone(body.getPhone())
              .partnershipName(body.getPartnershipName())
              .build();
          final var params = AdditionalSiteParams.builder()
              .siteId(siteDto.getId())
              .mdmCode(merchantDto.get().getMdmCode())
              .params(paramsData)
              .build();
          paramsService.save(params);
          siteDto.setPartnershipName(paramsData.getPartnershipName());
          siteDto.setPartnershipChannel(paramsData.getPartnershipChannel());
          siteDto.setPhone(paramsData.getPhone());
          siteDto.setEmail(paramsData.getEmail());
          return siteDto;
        })
        .map(siteDto1 -> {
          historyService
              .newSite(siteDto1.getId())
              .ifPresent(historyRecord -> {
                siteDto1.setState(mapToStateDto(historyRecord));
              });
          return siteDto1;
        });
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_CHANGE_PARAMS_RESOURCE)
  public Optional<SiteDto> patch(String jwt, String mstId, ChangeSiteDto body) {
    if (Objects.isNull(body)) {
      return Optional.empty();
    }
    final var merchant = merchantService.findMerchant(jwt).get();
    return client.getMerchantSite(mstId)
        .flatMap(merchantSite -> {
          if (!Objects.equals(merchant.getId(), merchantSite.getMerchantId())) {
            throw new IncorrectNewSiteDto();
          }
          final var params = paramsService.getBySiteId(mstId)
              .map(AdditionalSiteParams::getParams)
              .orElse(AdditionalSiteParamsData.builder().build());
          merchantSite.setState(null);
          merchantSite.setCreated(null);
          merchantSite.setModified(null);
          merchantSite.setExternalApplicationId(
              externalApplicationIdSelector(
                  Objects.requireNonNullElse(body.getPartnershipChannel(),
                      params.getPartnershipChannel()),
                  body.getExternalApplicationId()));
          merchantSite.setName(Objects.requireNonNullElse(body.getName(), merchantSite.getName()));
          merchantSite.setLogin(Objects.requireNonNullElse(body.getLogin(), merchantSite
              .getLogin()));
          merchantSite.setUrl(Objects.requireNonNullElse(body.getUrl(), merchantSite.getUrl()));
          // TODO: nothing to do with phone, email, partnershipChannel, partnershipName
          if (Objects.nonNull(body.getParams())) {
            final var newParams = body.getParams();
            final var oldParams = merchantSite.getParams();
            oldParams.setMcc(Objects.requireNonNullElse(newParams.getMcc(), oldParams.getMcc()));
            if (Objects.nonNull(newParams.getCallbackUrl())) {
              oldParams.setCallbackUrl(newParams.getCallbackUrl());
            }
            if (Objects.nonNull(newParams.getSbpParams())) {
              try {
                objectNonNullMapper.readerForUpdating(oldParams.getSbpParams()).readValue(
                    objectNonNullMapper.writeValueAsString(newParams.getSbpParams()));
              } catch (JsonProcessingException e) {
                throw new IncorrectNewSiteDto();
              }
            }
            if (Objects.nonNull(newParams.getCardParams())) {
              try {
                objectNonNullMapper.readerForUpdating(oldParams.getCardParams()).readValue(
                    objectNonNullMapper.writeValueAsString(newParams.getCardParams()));
              } catch (JsonProcessingException e) {
                throw new IncorrectNewSiteDto();
              }
            }
          }
          final var result = client.updateMerchantSite(merchantSite.getId(), merchantSite);
          final var updParams = AdditionalSiteParams.builder()
              .mdmCode(merchant.getMdmCode())
              .siteId(mstId)
              .params(AdditionalSiteParamsData.builder()
                  .email(body.getEmail())
                  .phone(body.getPhone())
                  .build())
              .build();
          paramsService.updateOrSave(updParams);
          return result;
        })
        .flatMap(this::mapMerchantApiSiteDto)
        .map(dto -> {
          historyService
              .findLast(dto.getId())
              .ifPresent(historyRecord -> {
                dto.setState(mapToStateDto(historyRecord));
              });
          return dto;
        });
  }

  @Override
  public Optional<SiteDto> activateSite(String jwt, String mstId, SiteActivationParameters params) {
    merchantService.findMerchant(jwt);
    return Optional.empty();
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_BLOCKING_RESOURCE)
  public Optional<SiteDto> blockSite(String jwt, String mstId, SiteBlockingParameters params) {
    merchantService.findMerchant(jwt);
    return client.block(mstId).flatMap(this::mapMerchantApiSiteDto)
        .map(siteDto -> {
          historyService.blockSite(mstId, params)
              .ifPresent(recordDto -> {
                siteDto.setState(mapToStateDto(recordDto));
              });
          return siteDto;
        });
  }

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_UNLOCKING_RESOURCE)
  public Optional<SiteDto> unblockSite(String jwt, String mstId, SiteUnblockingParameters params) {
    merchantService.findMerchant(jwt);
    return client.unblock(mstId)
        .flatMap(this::mapMerchantApiSiteDto)
        .map(siteDto -> {
          historyService.unblockSite(mstId, params)
              .ifPresent(recordDto -> {
                siteDto.setState(mapToStateDto(recordDto));
              });
          return siteDto;
        });
  }

  private Optional<MerchantSiteDto> validateMerchantSiteParams(MerchantSiteDto siteDto) {
    return Optional.of(siteDto)
        .map(MerchantSiteDto::getParams)
        .map(siteParamsDto -> {
          if (!(isCardParamsComplete(siteParamsDto.getCardParams())
              || isSbpParamsComplete(siteParamsDto.getSbpParams()))
          ) {
            throw new IncorrectNewSiteDto();
          }
          return siteDto;
        });
  }

  private Optional<MerchantSiteDto> mapNewSiteDto(String merchantId, NewSiteDto siteDto) {
    if (Objects.isNull(siteDto.getParams())
        || Objects.isNull(siteDto.getParams().getSbpParams())
        || Objects.isNull(siteDto.getParams().getCardParams())) {
      throw new IncorrectNewSiteDto();
    }
    //TODO: прикрутить mapStruct
    return Optional.of(
        MerchantSiteDto.builder()
            .id(UUID.randomUUID().toString())
            .login(siteDto.getLogin())
            .externalApplicationId(externalApplicationIdSelector(siteDto.getPartnershipChannel(),
                siteDto.getExternalApplicationId()))
            .name(siteDto.getName())
            .merchantId(merchantId)
            .url(siteDto.getUrl())
            .params(
                MerchantSiteParamsDto.builder()
                    .callbackUrl(siteDto.getParams().getCallbackUrl())
                    .mcc(siteDto.getParams().getMcc())
                    .cardParams(MerchantSiteCardParamsDto.builder()
                        .merchantId(siteDto.getParams().getCardParams().getMerchantId())
                        .merchantName(siteDto.getParams().getCardParams().getMerchantName())
                        .terminalId(siteDto.getParams().getCardParams().getTerminalId())
                        .enablePartialRefund(
                            Objects.requireNonNullElse(
                                siteDto.getParams().getCardParams().getEnablePartialRefund(),
                                false))
                        .enableCardPayment(
                            Objects.requireNonNullElse(
                                siteDto.getParams().getCardParams().getEnableCardPayment(), false))
                        .enableApplePayment(
                            Objects.requireNonNullElse(
                                siteDto.getParams().getCardParams().getEnableApplePayment(), false))
                        .enableGooglePayment(
                            Objects.requireNonNullElse(
                                siteDto.getParams().getCardParams().getEnableGooglePayment(),
                                false))
                        .enableCardFlowThreeDS(
                            Objects.requireNonNullElse(siteDto.getParams().getCardParams()
                                .getEnableCardFlowThreeDS(), false))
                        .enablePaymentCheckboxesVisible(siteDto.getParams().getCardParams()
                            .getEnablePaymentCheckboxesVisible())
                        .enableCardFlowThreeDSOnMerchantSide(
                            Objects.requireNonNullElse(siteDto.getParams().getCardParams()
                                .getEnableCardFlowThreeDSOnMerchantSide(), false))
                        .build())
                    .sbpParams(MerchantSiteSbpParamsDto.builder()
                        .enableSbpPayment(Objects.requireNonNullElse(
                            siteDto.getParams().getSbpParams().getEnableSbpPayment(), false))
                        .enablePartialRefund(
                            Objects.requireNonNullElse(
                                siteDto.getParams().getSbpParams().getEnablePartialRefund(), false))
                        .account(siteDto.getParams().getSbpParams().getAccount())
                        .legalId(siteDto.getParams().getSbpParams().getLegalId())
                        .merchantId(siteDto.getParams().getSbpParams().getMerchantId())
                        .paymentPurpose(siteDto.getParams().getSbpParams().getPaymentPurpose())
                        .qrcType(siteDto.getParams().getSbpParams().getQrcType())
                        .refundPurpose(siteDto.getParams().getSbpParams().getRefundPurpose())
                        .templateVersion(siteDto.getParams().getSbpParams().getTemplateVersion())
                        .build())
                    .build()
            ).build());
  }

  private Optional<SiteDto> mapMerchantApiSiteDto(MerchantSiteDto siteDto) {
    if (Objects.isNull(siteDto.getParams())) {
      throw new IncorrectNewSiteDto();
    }
    final var params = paramsService.getBySiteId(siteDto.getId())
        .map(AdditionalSiteParams::getParams)
        .orElse(AdditionalSiteParamsData.builder().build());

    final var siteParamsBuilder = SiteParamsDto.builder()
        .callbackUrl(siteDto.getParams().getCallbackUrl())
        .mcc(siteDto.getParams().getMcc());

    Optional.ofNullable(siteDto.getParams().getCardParams()).ifPresent(cardParams ->
        siteParamsBuilder.cardParams(CardParamsDto.builder()
            .merchantId(siteDto.getParams().getCardParams().getMerchantId())
            .merchantName(siteDto.getParams().getCardParams().getMerchantName())
            .terminalId(siteDto.getParams().getCardParams().getTerminalId())
            .enablePartialRefund(
                siteDto.getParams().getCardParams().isEnablePartialRefund())
            .enableCardPayment(
                siteDto.getParams().getCardParams().isEnableCardPayment())
            .enableApplePayment(
                siteDto.getParams().getCardParams().isEnableApplePayment())
            .enableGooglePayment(
                siteDto.getParams().getCardParams().isEnableGooglePayment())
            .enableCardFlowThreeDS(siteDto.getParams().getCardParams()
                .isEnableCardFlowThreeDS())
            .enablePaymentCheckboxesVisible(siteDto.getParams().getCardParams()
                .isEnablePaymentCheckboxesVisible())
            .enableCardFlowThreeDSOnMerchantSide(siteDto.getParams().getCardParams()
                .isEnableCardFlowThreeDSOnMerchantSide())
            .build())
    );

    Optional.ofNullable(siteDto.getParams().getSbpParams()).ifPresent(sbpParams ->
        siteParamsBuilder.sbpParams(SbpParamsDto.builder()
            .enableSbpPayment(siteDto.getParams().getSbpParams().isEnableSbpPayment())
            .enablePartialRefund(
                siteDto.getParams().getSbpParams().isEnablePartialRefund())
            .account(siteDto.getParams().getSbpParams().getAccount())
            .legalId(siteDto.getParams().getSbpParams().getLegalId())
            .merchantId(siteDto.getParams().getSbpParams().getMerchantId())
            .paymentPurpose(siteDto.getParams().getSbpParams().getPaymentPurpose())
            .qrcType(siteDto.getParams().getSbpParams().getQrcType())
            .refundPurpose(siteDto.getParams().getSbpParams().getRefundPurpose())
            .templateVersion(siteDto.getParams().getSbpParams().getTemplateVersion())
            .build())
    );

    final var siteDtoBuilder = SiteDto.builder()
        .id(siteDto.getId())
        .created(siteDto.getCreated().atZone(ZoneId.systemDefault()).toOffsetDateTime())
        .modified(siteDto.getModified().atZone(ZoneId.systemDefault()).toOffsetDateTime())
        .login(siteDto.getLogin().toLowerCase())
        .externalApplicationId(siteDto.getExternalApplicationId())
        .name(siteDto.getName())
        .url(siteDto.getUrl())
        .state(StateDto.builder()
            .stateCode(SiteState.findByName(siteDto.getState().name()))
            .build())
        .partnershipChannel(params.getPartnershipChannel())
        .partnershipName(params.getPartnershipName())
        .email(params.getEmail())
        .phone(params.getPhone())
        .params(siteParamsBuilder.build());

    siteDtoBuilder.params(siteParamsBuilder.build());

    return Optional.of(siteDtoBuilder.build());
  }

  private Optional<SiteShortDto> mapMerchantApiSiteShortDto(MerchantSiteDto siteDto) {
    return Optional.of(SiteShortDto.builder()
        .id(siteDto.getId())
        .name(siteDto.getName())
        .state(StateDto.builder()
            .stateCode(SiteState.findByName(siteDto.getState().name()))
            .build())
        .url(siteDto.getUrl())
        .build());
  }

  private boolean isSbpParamsComplete(MerchantSiteSbpParamsDto sbpParams) {
    return Optional.of(StringUtils.isNotEmpty(sbpParams.getMerchantId()) &&
        StringUtils.isNotEmpty(sbpParams.getLegalId()) &&
        StringUtils.isNotEmpty(sbpParams.getAccount()) &&
        StringUtils.isNotEmpty(sbpParams.getTemplateVersion()) &&
        StringUtils.isNotEmpty(sbpParams.getQrcType()) &&
        StringUtils.isNotEmpty(sbpParams.getPaymentPurpose()) &&
        StringUtils.isNotEmpty(sbpParams.getRefundPurpose())).orElse(false);

  }

  private boolean isCardParamsComplete(MerchantSiteCardParamsDto cardParams) {
    return Optional.of(StringUtils.isNotEmpty(cardParams.getMerchantId()) &&
        StringUtils.isNotEmpty(cardParams.getTerminalId()) &&
        StringUtils.isNotEmpty(cardParams.getMerchantName())).orElse(false);

  }

  private Optional<MerchantDto> getMerchantDto(String jwt) {
    try {
      return merchantService.findMerchant(jwt);
    } catch (MerchantNotFoundException e) {
      return merchantService.createMerchant(jwt)
          .flatMap(merchantShortDto -> merchantService.findMerchant(jwt));
    }
  }

  private String externalApplicationIdSelector(Boolean partnershipChannel, String value) {
    if (Boolean.TRUE.equals(partnershipChannel)) {
      return paykeeperExtAppId;
    }
    return value;
  }

  private StateDto mapToStateDto(SiteHistoryRecordDto record) {
    return StateDto.builder()
        .stateModified(record.getCreated())
        .stateCode(SiteState.findByName(record.getState()))
        .stateReason(record.getReason())
        .build();
  }
}
