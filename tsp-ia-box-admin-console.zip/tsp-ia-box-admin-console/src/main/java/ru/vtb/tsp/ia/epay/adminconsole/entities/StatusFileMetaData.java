package ru.vtb.tsp.ia.epay.adminconsole.entities;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@EqualsAndHashCode
@Builder
@With
@Table(name = "status_files")
@Entity
public class StatusFileMetaData {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "file_id")
  private Long fileId;
  @Column(name = "status_id")
  private Long statusId;
  @Column(name = "\"user\"")
  private String user;
  @Column(name = "created")
  private OffsetDateTime created;
  @Column(name = "ecm_id")
  private UUID ecmId;
  @Column(name = "file_name")
  private String fileName;
  @Column(name = "file_size")
  private Long fileSize;
}
