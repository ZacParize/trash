package ru.vtb.tsp.ia.epay.adminconsole.components;

import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.Error;
import ru.vtb.tsp.ia.epay.adminconsole.utils.ErrorUtils;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 15.08.2022
 */
@ControllerAdvice
@Slf4j
public class ExceptionHandlers extends ResponseEntityExceptionHandler {

  @ExceptionHandler(Exception.class)
  ResponseEntity<Error> handleException(HttpServletRequest req, Throwable ex) {
    final var error = ErrorUtils.exceptionToError(ex);
    return ResponseEntity.status(error.getHttpCode()).body(error);
  }

  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
      HttpHeaders headers, HttpStatus status, WebRequest request) {
    final var error = ErrorUtils.validationExceptionToError(ex);
    return ResponseEntity.status(error.getHttpCode()).body(error);
  }

  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
      HttpHeaders headers, HttpStatus status, WebRequest request) {
    return ErrorUtils.messageNotReadableExceptionToError(ex).toResponse();
  }

  @Override
  protected ResponseEntity<Object> handleServletRequestBindingException(
      ServletRequestBindingException ex, HttpHeaders headers, HttpStatus status,
      WebRequest request) {
    return ErrorUtils.servletRequestBindingExceptionToError(ex).toResponse();
  }

  @Override
  protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
      HttpMediaTypeNotSupportedException ex, HttpHeaders headers, HttpStatus status,
      WebRequest request) {
    return ErrorUtils.mediaTypeNotSupportedExceptionToError(ex).toResponse();
  }
}
