package ru.vtb.tsp.ia.epay.adminconsole.clients.ecm;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.clients.StatusHandler;
import ru.vtb.tsp.ia.epay.adminconsole.dto.ecm.FileInfoDto;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.FileDeleteAuthErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.FileDeleteException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.FileDeleteForbiddenErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.FileDeleteInternalErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.FileUploadDownloadException;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;

@UtilityClass
@Slf4j
public class EcmStatusHandlers {

  public static StatusHandler<Optional<UUID>> uploadStatusHandler(
      ResponseEntity<FileInfoDto> response, MultipartFile resource) {
    return () -> {
      switch (response.getStatusCode()) {
        case BAD_REQUEST: throw new FileUploadDownloadException();
        case UNAUTHORIZED: throw new FileUploadDownloadException();
        case FORBIDDEN: throw new FileUploadDownloadException();
        case NOT_FOUND: throw new FileUploadDownloadException();
        case CONFLICT: throw new FileUploadDownloadException();
        case INTERNAL_SERVER_ERROR: throw new FileUploadDownloadException();
        case NO_CONTENT: throw new FileUploadDownloadException();
        default: {
          if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
            final var uuid = Objects.requireNonNull(response.getBody()).getUuid();
            log.info("File {} succesfull uploaded, ECM UUID: {}", resource.getOriginalFilename(), uuid);
            return Optional.of(uuid);
          }
          return Optional.empty();
        }
      }
    };
  }

  public static StatusHandler<Optional<Resource>> downloadStatusHandler(
      ResponseEntity<byte[]> response, UUID fileUuid) {
    return () -> {
      switch (response.getStatusCode()) {
        case BAD_REQUEST: throw new FileUploadDownloadException();
        case UNAUTHORIZED: throw new FileUploadDownloadException();
        case FORBIDDEN: throw new FileUploadDownloadException();
        case NOT_FOUND: throw new FileUploadDownloadException();
        case CONFLICT: throw new FileUploadDownloadException();
        case INTERNAL_SERVER_ERROR: throw new FileUploadDownloadException();
        case NO_CONTENT: throw new FileUploadDownloadException();
        default: {
          if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
            final var resource = new ByteArrayResource(Objects.requireNonNull(response.getBody())) {
              @Override
              public String getFilename() {
                return response.getHeaders().getContentDisposition().getFilename();
              }
            };
            log.info("File {} sucessfully downloaded", resource.getFilename());
            return Optional.of(resource);
          }
          return Optional.empty();
        }
      }
    };
  }

  public static <T> StatusHandler<Optional<T>> exceptionHandler(
      HttpClientErrorException exception, Class<T> cls) {
    return () -> {
      switch (exception.getStatusCode()) {
        case BAD_REQUEST: throw new FileUploadDownloadException();
        case UNAUTHORIZED: throw new FileUploadDownloadException();
        case FORBIDDEN: throw new FileUploadDownloadException();
        case NOT_FOUND: throw new FileUploadDownloadException();
        case CONFLICT: throw new FileUploadDownloadException();
        case INTERNAL_SERVER_ERROR: throw new FileUploadDownloadException();
        case NO_CONTENT: throw new FileUploadDownloadException();
        default: throw new IdentifiedException();
      }
    };
  }
  public static <T> StatusHandler<Boolean> deleteExceptionHandler(
      HttpClientErrorException exception, UUID ... resource) {
    return () -> {
      switch (exception.getStatusCode()) {
        case BAD_REQUEST: throw new FileDeleteException();
        case UNAUTHORIZED: throw new FileDeleteAuthErrorException();
        case FORBIDDEN: throw new FileDeleteForbiddenErrorException();
        case NOT_FOUND: {
          log.info("File succesfull deleted, ECM UUIDs: {}", resource);
          return Boolean.TRUE;
        }
        case INTERNAL_SERVER_ERROR: throw new FileDeleteInternalErrorException();
        default: throw new IdentifiedException();
      }
    };
  }

  public static StatusHandler<Boolean> deleteStatusHandler(
      ResponseEntity<Void> response, UUID ... resource) {
    return () -> {
      switch (response.getStatusCode()) {
        case BAD_REQUEST: throw new FileDeleteException();
        case UNAUTHORIZED: throw new FileDeleteAuthErrorException();
        case FORBIDDEN: throw new FileDeleteForbiddenErrorException();
        case NOT_FOUND: {
          log.info("File succesfull deleted, ECM UUIDs: {}", resource);
          return Boolean.TRUE;
        }
        case INTERNAL_SERVER_ERROR: throw new FileDeleteInternalErrorException();
        default: {
          if (response.getStatusCode().is2xxSuccessful()) {
            log.info("File succesfull deleted, ECM UUIDs: {}", resource);
            return Boolean.TRUE;
          }
          return Boolean.FALSE;
        }
      }
    };
  }

}
