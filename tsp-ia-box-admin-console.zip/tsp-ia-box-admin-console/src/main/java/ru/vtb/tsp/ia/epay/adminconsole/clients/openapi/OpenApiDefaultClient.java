package ru.vtb.tsp.ia.epay.adminconsole.clients.openapi;

import static ru.vtb.tsp.ia.epay.adminconsole.clients.openapi.OpenApiStatusHandlers.exceptionHandler;
import static ru.vtb.tsp.ia.epay.adminconsole.clients.openapi.OpenApiStatusHandlers.handler;

import java.util.List;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.OpenApiRestConfig;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.consts.AuditEvents;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.RequestDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.openapi.ResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;

@Conditional(OnlyNotDevAndLocal.class)
@RequiredArgsConstructor
@Component
@Slf4j
public class OpenApiDefaultClient implements OpenApiClient {

  private static final String INTEGRATION_NAME = "OpenAPI (МАПИ)";
  private static final String ENDPOINT = "/portal/applications";

  @Qualifier(OpenApiRestConfig.OPENAPI)
  private final RestTemplate restTemplate;
  private final Integrations integrations;

  @Override
  @Audit(AuditEvents.TSPACQ_SMBQ_POST_PORTAL_APPLICATION)
  public Optional<ResponseDto> postApplication(RequestDto requestDto) {
    final var response = getResponseDto(requestDto);
    try {
      return handler(response).handle();
    } catch (HttpClientErrorException e) {
      return exceptionHandler(e, ResponseDto.class).handle();
    }
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    final RequestDto requestDto = RequestDto.builder()
        .reasonCreate("reasonCreate")
        .informationSystemName("informationSystemName")
        .clientType("clientType")
        .orgId("orgId")
        .orgCode("orgCode")
        .externalApplicationName("externalApplicationName")
        .applicationType("appType")
        .externalApplicationEmail(new String[]{"example@mail.ru"})
        .build();
    try {
      getResponseDto(requestDto);
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }

  private ResponseEntity<ResponseDto> getResponseDto(RequestDto requestDto) {
    final var connection = integrations.getConnection(RestClient.OPENAPI);
    final var uri = UriComponentsBuilder
        .fromUriString(connection.getHost() + ENDPOINT).build().toUri();
    final var hdrs = new HttpHeaders();
    hdrs.setAccept(List.of(MediaType.APPLICATION_JSON));
    hdrs.setContentType(MediaType.APPLICATION_JSON);
    return restTemplate.exchange(uri, HttpMethod.POST, new HttpEntity<>(requestDto, hdrs),
        ResponseDto.class);
  }
}
