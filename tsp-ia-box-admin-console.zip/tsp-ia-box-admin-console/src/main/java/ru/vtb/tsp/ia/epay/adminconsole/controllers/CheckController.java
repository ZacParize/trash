package ru.vtb.tsp.ia.epay.adminconsole.controllers;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.adminconsole.api.CheckApi;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.CheckResponseDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.CheckService;

@RestController
@RequestMapping("/api/v1/check")
@RequiredArgsConstructor
public class CheckController implements CheckApi {

  private final CheckService checkService;

  @Override
  @GetMapping(produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<CheckResponseDto> check() {
    return ResponseEntity.ok(checkService.check());
  }
}
