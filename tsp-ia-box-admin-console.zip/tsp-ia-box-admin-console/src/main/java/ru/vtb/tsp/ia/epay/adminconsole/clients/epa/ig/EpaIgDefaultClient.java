package ru.vtb.tsp.ia.epay.adminconsole.clients.epa.ig;

import static ru.vtb.tsp.ia.epay.adminconsole.config.CacheConfig.FIVE_MINUTES_EPA_IG_CACHE;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.context.annotation.Conditional;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.epa.EpaAccessToken;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;

@Slf4j
@Conditional(OnlyNotDevAndLocal.class)
@Component
@RequiredArgsConstructor
@Qualifier("epaIgClient")
public class EpaIgDefaultClient implements EpaClient {

  private static final String INTEGRATION_NAME = "TyK (ЕПА IG)";
  private static final Integer TIME_FOR_EXPIRES = 3000;
  private static final String ENDPOINT = "/passport/tech/oauth2/token";
  private static final String GRANT_TYPE = "grant_type";
  private static final String GRANT_TYPE_VALUE = "client_credentials";
  private static final String CLIENT_ID = "client_id";
  private static final String CLIENT_SECRET = "client_secret";

  @Qualifier("epaIgRestClient")
  private final RestTemplate restTemplate;
  private final Integrations integrations;
  private EpaAccessToken token;
  @Value("${integrations.rests.epa.epaClientId}")
  private String clientId;
  @Value("${integrations.rests.epa.epaClientSecret}")
  private String clientSecret;

  @Override
  @Cacheable(FIVE_MINUTES_EPA_IG_CACHE)
  public Optional<EpaAccessToken> getToken() {
    if (StringUtils.isEmpty(clientId) || StringUtils.isEmpty(clientSecret)) {
      return Optional.empty();
    }
    if (tokenIsNotExpired()) {
      return Optional.ofNullable(token);
    }

    final String host = integrations.getConnection(RestClient.EPA).getHost();
    final String url = host + ENDPOINT;
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
    requestBody.add(GRANT_TYPE, GRANT_TYPE_VALUE);
    requestBody.add(CLIENT_ID, clientId);
    requestBody.add(CLIENT_SECRET, clientSecret);
    final var formEntity = new HttpEntity<>(requestBody, headers);

    final var response = restTemplate.exchange(url, HttpMethod.POST, formEntity,
        EpaAccessToken.class);

    if (response.getStatusCode().is2xxSuccessful() && response.hasBody()) {
      final var accessToken = response.getBody();
      Objects.requireNonNull(accessToken)
          .setExpiresIn(System.currentTimeMillis() + accessToken.getExpiresIn() * 1000);
      token = accessToken;
      return Optional.of(token);
    }
    return Optional.empty();
  }

  @Override
  public IntegrationStatusDto check() {
    log.info("Call check {}", INTEGRATION_NAME);
    final String host = integrations.getConnection(RestClient.EPA).getHost();
    final String url = host + ENDPOINT;
    try {
      restTemplate.optionsForAllow(url);
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }

  private boolean tokenIsNotExpired() {
    return Objects.nonNull(token)
        && System.currentTimeMillis() < token.getExpiresIn() - TIME_FOR_EXPIRES;
  }

}
