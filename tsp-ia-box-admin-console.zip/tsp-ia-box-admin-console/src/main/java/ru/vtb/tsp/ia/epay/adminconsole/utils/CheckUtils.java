package ru.vtb.tsp.ia.epay.adminconsole.utils;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;

@Slf4j
@UtilityClass
public class CheckUtils {

  public static IntegrationStatusDto processResponse(String integrationName) {
    return IntegrationStatusDto.builder()
        .integrationName(integrationName)
        .status(IntegrationStatus.SUCCESS)
        .build();
  }

  public static IntegrationStatusDto processException(Exception e, String integrationName) {
    if (e instanceof HttpClientErrorException) {
      if (HttpStatus.NOT_FOUND.equals(((HttpClientErrorException) e).getStatusCode())) {
        return IntegrationStatusDto.builder()
            .integrationName(integrationName)
            .status(IntegrationStatus.SUCCESS)
            .build();
      } else if (HttpStatus.UNAUTHORIZED.equals(((HttpClientErrorException) e).getStatusCode())) {
        return IntegrationStatusDto.builder()
            .integrationName(integrationName)
            .status(IntegrationStatus.SUCCESS)
            .build();
      } else {
        log.error("Check error: ", e);
        return IntegrationStatusDto.builder()
            .integrationName(integrationName)
            .status(IntegrationStatus.CONFIG_ERROR)
            .errors(e.getMessage())
            .build();
      }
    } else {
      log.error("Check error: ", e);
      return IntegrationStatusDto.builder()
          .integrationName(integrationName)
          .status(IntegrationStatus.OTHER_ERROR)
          .errors(e.getMessage())
          .build();
    }
  }
}
