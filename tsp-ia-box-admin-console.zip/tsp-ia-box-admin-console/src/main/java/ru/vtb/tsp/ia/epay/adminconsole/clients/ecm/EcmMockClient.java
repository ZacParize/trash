package ru.vtb.tsp.ia.epay.adminconsole.clients.ecm;

import java.nio.charset.StandardCharsets;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import org.springframework.context.annotation.Conditional;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyDevOrLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;

@Conditional(OnlyDevOrLocal.class)
@Component
public class EcmMockClient implements EcmClient {

  @Override
  public Optional<UUID> uploadFile(MultipartFile resource) {
    return Optional.of(UUID.randomUUID());
  }

  @Override
  public Optional<Resource> downloadFile(UUID fileUuid) {
    final var data = "test file content";
    return Optional.of(
        new ByteArrayResource(Objects.requireNonNull(data.getBytes(StandardCharsets.UTF_8))) {
          @Override
          public String getFilename() {
            return fileUuid.toString().concat(".txt");
          }
        }
    );
  }

  @Override
  public boolean deleteFiles(UUID... fileUUID) {
    return Boolean.TRUE;
  }

  @Override
  public IntegrationStatusDto check() {
    return IntegrationStatusDto.builder()
        .integrationName("EcmMockClient")
        .status(IntegrationStatus.SUCCESS)
        .build();
  }
}
