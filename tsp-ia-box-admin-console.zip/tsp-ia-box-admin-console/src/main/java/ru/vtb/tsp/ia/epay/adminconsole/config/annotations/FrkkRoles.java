package ru.vtb.tsp.ia.epay.adminconsole.config.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.UserGroup;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 02.08.2022
 */
@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface FrkkRoles {

  UserGroup value() default UserGroup.NONE;

}
