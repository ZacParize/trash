package ru.vtb.tsp.ia.epay.adminconsole.dto.api.check;

import java.time.Instant;
import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CheckResponseDto {

  private Instant checkTime;
  private IntegrationStatus commonCheckStatus;
  private List<IntegrationStatusDto> integrationStates;
}
