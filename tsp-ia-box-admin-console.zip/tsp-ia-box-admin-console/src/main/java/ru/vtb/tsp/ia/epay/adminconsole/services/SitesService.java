package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.List;
import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.ChangeSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.NewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteActivationParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteBlockingParameters;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteShortDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteUnblockingParameters;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.07.2022
 */
public interface SitesService {

  /**
   * Get sites of merchant.
   *
   * @param jwt - token for session
   * @return site list
   */
  List<SiteShortDto> getSitesByMerchant(String jwt);

  /**
   * Get full site info by merchantSiteId.
   *
   * @param jwt - JWT token
   * @param mstId - merchantSiteId
   * @return - Full site info or error
   */
  Optional<SiteDto> getSiteByMstId(String jwt, String mstId);

  /**
   * Save new site.
   *
   * @param jwt - JWT token
   * @param site - Full site info for save
   * @return - Saved full site info or error
   */
  Optional<SiteDto> create(String jwt, NewSiteDto site);


  /**
   * Patch site.
   *
   * @param jwt - JWT token
   * @param mstId - site Id
   * @param body - path data
   * @return - patch site data
   */
  Optional<SiteDto> patch(String jwt, String mstId, ChangeSiteDto body);

  /**
   * activate site.
   *
   * @param jwt - JWT token
   * @param mstId - site Id
   * @param params - siteActivationParameters data
   * @return - site data
   */
  Optional<SiteDto> activateSite(String jwt, String mstId, SiteActivationParameters params);

  /**
   * block site.
   *
   * @param jwt - JWT token
   * @param mstId - site Id
   * @param params - SiteBlockingParameters data
   * @return - site data
   */
  Optional<SiteDto> blockSite(String jwt, String mstId, SiteBlockingParameters params);

  /**
   * Unblock site.
   *
   * @param jwt - JWT token
   * @param mstId - merchant's site id
   * @return - site data
   */
  Optional<SiteDto> unblockSite(String jwt, String mstId, SiteUnblockingParameters params);

}
