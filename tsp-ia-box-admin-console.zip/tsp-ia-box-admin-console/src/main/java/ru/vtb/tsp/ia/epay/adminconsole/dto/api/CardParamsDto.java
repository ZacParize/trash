package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class CardParamsDto {

  private Boolean enableCardPayment;
  private Boolean enablePartialRefund;
  private Boolean enableCardFlowThreeDS;
  private Boolean enableCardFlowThreeDSOnMerchantSide;
  private Boolean enableGooglePayment;
  private Boolean enableApplePayment;
  private Boolean enablePaymentCheckboxesVisible;
  private String merchantId;
  private String terminalId;
  private String merchantName;

  public String toAudit() {
    return "enableCardPayment=" + enableCardPayment + ","
        + "enablePartialRefund=" + enablePartialRefund + ","
        + "enableCardFlowThreeDS=" + enableCardFlowThreeDS + ","
        + "merchantId=" + merchantId + ","
        + "terminalId=" + terminalId + ","
        + "merchantName=" + merchantName;

  }

}
