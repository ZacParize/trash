package ru.vtb.tsp.ia.epay.adminconsole.dto.transactions;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ActionsDto {

  private Boolean refund;
  private Boolean confirm;
  private Boolean cancel;
}
