package ru.vtb.tsp.ia.epay.adminconsole.clients.ecm;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.ia.epay.adminconsole.clients.Checker;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.IdentifiedException;

public interface EcmClient extends Checker {

  Optional<UUID> uploadFile(MultipartFile resource);

  Optional<Resource> downloadFile(UUID fileUuid);

  boolean deleteFiles(UUID... fileUUID);

  default HttpHeaders headers(EpaClient epaClient, MediaType contentType) {
    final var token = epaClient.getToken()
        .orElseThrow(IdentifiedException::new);
    final var headers = new HttpHeaders();
    if (Objects.nonNull(contentType)) {
      headers.setContentType(contentType);
    }
    headers.setBearerAuth(token.getAccessToken());
    return headers;
  }
}
