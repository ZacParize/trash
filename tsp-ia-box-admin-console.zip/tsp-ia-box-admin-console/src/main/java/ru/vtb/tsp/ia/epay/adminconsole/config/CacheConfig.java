package ru.vtb.tsp.ia.epay.adminconsole.config;

import com.google.common.cache.CacheBuilder;
import java.time.Duration;
import java.util.List;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCache;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableCaching
public class CacheConfig {

  public static final String FIVE_MINUTES_EPA_IG_CACHE = "fiveMinutesEpaIgCache";
  public static final String FIVE_MINUTES_EPA_AM_CACHE = "fiveMinutesEpaAmCache";

  @Bean
  public CacheManager cacheEpaIgManager() {
    final var manager = new ConcurrentMapCacheManager(FIVE_MINUTES_EPA_IG_CACHE) {
      @Override
      protected Cache createConcurrentMapCache(String name) {
        return new ConcurrentMapCache(name, CacheBuilder.newBuilder()
            .expireAfterWrite(Duration.ofSeconds(280)).build().asMap(), false);
      }
    };
    manager.setCacheNames(List.of(FIVE_MINUTES_EPA_IG_CACHE, FIVE_MINUTES_EPA_AM_CACHE));
    return manager;
  }

}
