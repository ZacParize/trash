package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.OffsetDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.enums.SiteState;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 11.07.2022
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties
public class StateDto {

  private SiteState stateCode;
  private String stateReason;
  private String stateFilePath;
  private OffsetDateTime stateModified;

}
