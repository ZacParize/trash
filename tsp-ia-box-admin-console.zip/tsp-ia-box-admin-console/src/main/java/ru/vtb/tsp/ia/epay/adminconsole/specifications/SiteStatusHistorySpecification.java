package ru.vtb.tsp.ia.epay.adminconsole.specifications;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Order;
import javax.persistence.criteria.Root;
import lombok.experimental.UtilityClass;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortParams;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SortField;
import ru.vtb.tsp.ia.epay.adminconsole.entities.SiteStatusHistoryRecord;

@UtilityClass
public class SiteStatusHistorySpecification {

  private static final String STATUS_ID = "statusId";
  private static final String MST_ID = "mstId";
  private static final String USER = "user";
  private static final String CREATED = "created";
  private static final String STATE = "state";
  private static final String REASON = "reason";


  public static Specification<SiteStatusHistoryRecord> find(String mstId) {
    return (root, criteriaQuery, criteriaBuilder) -> {
      return criteriaBuilder.equal(root.get(MST_ID), mstId);
    };
  }

  public static Specification<SiteStatusHistoryRecord> findLastRecord(String mstId) {
    return findSorted(mstId, listOfSortField(CREATED, true));
  }

  public static Specification<SiteStatusHistoryRecord> findSorted(String mstId, SortParams sortParams) {
    return (root, criteriaQuery, criteriaBuilder) -> {
      orderBy(root, criteriaQuery, criteriaBuilder, sortParams);
      return criteriaBuilder.equal(root.get(MST_ID), mstId);
    };
  }

  private static void orderBy(
      Root<SiteStatusHistoryRecord> root,
      CriteriaQuery query,
      CriteriaBuilder builder,
      SortParams sortParams) {
    if (Objects.isNull(sortParams)
        || CollectionUtils.isEmpty(sortParams.getFields())) {
      return;
    }
    final var orders = new ArrayList<Order>();
    sortParams.getFields().forEach(sortField -> {
      if (sortField.isDesc()) {
        orders.add(builder.desc(root.get(sortField.getField())));
      } else {
        orders.add(builder.asc(root.get(sortField.getField())));
      }
    });
    query.orderBy(orders.toArray(new Order[0]));
  }

  private SortParams listOfSortField(String field, boolean desc) {
    return SortParams.builder().fields(
        List.of(SortField.builder().field(field).desc(desc).build())
    ).build();
  }

}
