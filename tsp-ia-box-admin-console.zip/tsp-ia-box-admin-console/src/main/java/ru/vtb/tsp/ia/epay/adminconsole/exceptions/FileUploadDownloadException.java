package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

@Data
public class FileUploadDownloadException extends IdentifiedException {
  private final Integer httpCode = 400;
  private final String id = "0120005041";
  private final String errorMessage = "file_ul/dl_error";
  private final String description = "";
}
