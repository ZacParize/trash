package ru.vtb.tsp.ia.epay.adminconsole.services.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.adminconsole.clients.frkk.FrkkClient;
import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.Attributes;
import ru.vtb.tsp.ia.epay.adminconsole.dto.frkk.UserInfo;
import ru.vtb.tsp.ia.epay.adminconsole.exceptions.PermissionDeniedException;
import ru.vtb.tsp.ia.epay.adminconsole.services.FrkkService;

@RequiredArgsConstructor
@Slf4j
@Service
public class FrkkServiceImpl implements FrkkService {

  private final FrkkClient frkkClient;

  @Override
  public boolean checkRole(FrkkRoles roles, String jwtToken) {
    log.info("Checking FRKK roles: {}", roles.value());
    if (StringUtils.isEmpty(jwtToken)) {
      log.error("Authorization required! Token is empty");
      throw new PermissionDeniedException();
    }
    final var isExist = frkkClient.getUserInfo(jwtToken)
        .map(userInfo -> {
          log.debug("User roles: {}", userInfo.getRoles());
          return roles.value().getRoles().stream()
              .anyMatch(userRole -> userInfo.getRoles().contains(userRole.getName()));
        })
        .orElseThrow(PermissionDeniedException::new);
    log.info("Checking FRKK roles: OK!");
    return isExist;
  }

  @Override
  public String getLogin() {
    return frkkClient.getUserInfo()
        .map(UserInfo::getAttributes)
        .map(Attributes::getLogin)
        .orElse("-");
  }
}
