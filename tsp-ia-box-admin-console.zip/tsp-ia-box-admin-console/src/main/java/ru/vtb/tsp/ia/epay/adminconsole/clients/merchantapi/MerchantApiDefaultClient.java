package ru.vtb.tsp.ia.epay.adminconsole.clients.merchantapi;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.adminconsole.components.conditions.OnlyNotDevAndLocal;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;
import ru.vtb.tsp.ia.epay.merchant.MerchantControllerApi;

@Slf4j
@Component
@RequiredArgsConstructor
@Conditional(OnlyNotDevAndLocal.class)
public class MerchantApiDefaultClient implements MerchantApiClient {

  private static final String INTEGRATION_NAME = "Merchant Management API";
  private final MerchantControllerApi merchantController;

  @Override
  public IntegrationStatusDto check() {
    try {
      merchantController.get("merchant_id");
      return CheckUtils.processResponse(INTEGRATION_NAME);
    } catch (Exception e) {
      return CheckUtils.processException(e, INTEGRATION_NAME);
    }
  }
}
