package ru.vtb.tsp.ia.epay.adminconsole.entities;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.With;

@NoArgsConstructor
@AllArgsConstructor
@Data
@ToString
@EqualsAndHashCode
@Builder
@With
@Table(name = "sites_status_history")
@Entity
public class SiteStatusHistoryRecord {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "status_id")
  private Long statusId;
  @Column(name = "mst_id")
  private String mstId;
  @Column(name = "\"user\"")
  private String user;
  @Column(name = "created")
  private OffsetDateTime created;
  @Column(name = "state")
  private String state;
  @Column(name = "reason")
  private String reason;
  @OneToMany(targetEntity = StatusFileMetaData.class, mappedBy = "statusId")
  private List<StatusFileMetaData> files;

}
