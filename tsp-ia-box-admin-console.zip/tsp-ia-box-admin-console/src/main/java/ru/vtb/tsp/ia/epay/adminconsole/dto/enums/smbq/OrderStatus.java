package ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq;

public enum OrderStatus {
  CREATED,
  PAID,
  REFUNDED,
  PARTIALLY_REFUNDED,
  EXPIRED,
  CANCELED,
  REFUND_REQUEST,
  DECLINE,
  PENDING,
  CONFIRM_REQUEST,
  CANCEL_REQUEST,
  VOIDED
}
