package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.07.2022
 */
public class IncorrectNewSiteDto extends RuntimeException{

}
