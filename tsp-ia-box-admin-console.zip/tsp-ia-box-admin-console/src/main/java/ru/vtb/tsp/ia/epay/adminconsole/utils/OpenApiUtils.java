package ru.vtb.tsp.ia.epay.adminconsole.utils;

import java.util.UUID;
import lombok.experimental.UtilityClass;

@UtilityClass
public class OpenApiUtils {

  private static final String supportedChars = "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя";
  private static final String[] numWords = {
      "ноль", "один", "два", "три", "четыре", "пять", "шесть", "семь", "восемь", "девять"
  };
  private static final String[] forUuid = {
      "g", "h", "i", "j", "k", "l", "m", "n", "o", "p"
  };

  public static String removeUnsupportedAndReplaceNumsChars(String str) {
    final var bldr = new StringBuilder();
    for (char chr: str.toCharArray()) {
      final var index = supportedChars.indexOf(chr);
      if (index >= 0 && index <10) {
        bldr.append(numWords[index]);
        continue;
      }
      if (index >= 0) {
        bldr.append(chr);
      }
    }
    return bldr.toString();
  }

  public static String openapiUuid() {
    final var str = UUID.randomUUID().toString();
    final var bldr = new StringBuilder();
    for (char chr: str.toCharArray()) {
      final var index = supportedChars.indexOf(chr);
      if (index >= 0 && index <10) {
        bldr.append(forUuid[index]);
        continue;
      }
      if (index >= 0) {
        bldr.append(chr);
      }
    }
    return bldr.toString();
  }

}
