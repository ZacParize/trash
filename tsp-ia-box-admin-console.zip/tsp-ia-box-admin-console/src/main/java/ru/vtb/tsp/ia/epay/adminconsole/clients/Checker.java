package ru.vtb.tsp.ia.epay.adminconsole.clients;

import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;

public interface Checker {

  IntegrationStatusDto check();
}
