package ru.vtb.tsp.ia.epay.adminconsole.utils;

import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Optional;
import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ContentDisposition;

@UtilityClass
public class FileUtils {

  @SneakyThrows
  public static String fileSize(String path) {
    if (StringUtils.isEmpty(path)) {
      return "empty path";
    }
    final var filePath = (new File(path)).toPath();
    if (!Files.exists(filePath)) {
      return "not found";
    }
    final var sz = Files.size(filePath);
    return sz + " B";
  }

  public static Optional<ContentDisposition> createContentDisposition(String filename) {
    if (StringUtils.isEmpty(filename)) {
      return Optional.empty();
    }
    return Optional.of(ContentDisposition.builder("attachment")
        .filename(filename, StandardCharsets.UTF_8)
        .build());
  }

}
