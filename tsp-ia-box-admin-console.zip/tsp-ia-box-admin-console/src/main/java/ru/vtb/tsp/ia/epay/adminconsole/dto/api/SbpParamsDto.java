package ru.vtb.tsp.ia.epay.adminconsole.dto.api;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Schema
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class SbpParamsDto {

  private Boolean enableSbpPayment;
  private Boolean enablePartialRefund;
  //  @Pattern(regexp = "^[a-zA-Z0-9]{1,12}$")
  private String merchantId;
  //  @Pattern(regexp = "^[a-zA-Z0-9]{1,12}$")
  private String legalId;
  //  @Pattern(regexp = "^\\d{5}.[810].\\d{12}$")
  private String account;
  //  @Pattern(regexp = "^\\d{1,2}$")
  private String templateVersion;
  //  @Pattern(regexp = "^\\d{1,2}$")
  private String qrcType;
  //  @Size(max = 140)
  private String paymentPurpose;
  //  @Size(max = 140)
  private String refundPurpose;

  public String toAudit() {
    return "enableSbpPayment=" + enableSbpPayment + ","
        + "enablePartialRefund=" + enablePartialRefund + ","
        + "merchantId=" + merchantId + ","
        + "legalId=" + legalId + ","
        + "account=" + account + ","
        + "paymentPurpose=" + paymentPurpose + ","
        + "refundPurpose=" + refundPurpose;
  }

}