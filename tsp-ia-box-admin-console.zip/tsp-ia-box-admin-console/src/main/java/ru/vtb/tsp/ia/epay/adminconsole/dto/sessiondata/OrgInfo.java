package ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 29.06.2022
 */
@Data
@JsonIgnoreProperties
public class OrgInfo implements Serializable {
  
  private String officialName;
  
  private String orgType;
  
  private String okopf;
  
  private String kpp;
  
  private String kio;
  
  private String inn;
  
  private String ogrn;
  
  private String okpo;
  
  private String bik;
  
  private String swift;
  
  private String taxSystem;
  
  private String shortName;
}
