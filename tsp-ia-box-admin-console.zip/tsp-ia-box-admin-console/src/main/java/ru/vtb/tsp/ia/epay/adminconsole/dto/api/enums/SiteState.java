package ru.vtb.tsp.ia.epay.adminconsole.dto.api.enums;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 29.07.2022
 */
public enum SiteState {

  DRAFT,
  ACTIVE,
  NOT_ACTIVE,
  BLOCKED,
  DELETED;

  public static SiteState findByName(String name) {
      for (var val : SiteState.values()) {
          if (val.name().equals(name)) {
              return val;
          }
      }
      return null;
  }
}
