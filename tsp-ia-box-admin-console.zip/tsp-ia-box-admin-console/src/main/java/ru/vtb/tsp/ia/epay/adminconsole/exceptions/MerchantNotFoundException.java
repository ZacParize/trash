package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 21.07.2022
 */
@Data
public class MerchantNotFoundException extends IdentifiedException {

  private final Integer httpCode = 404;
  private final String id = "0120005030";
  private final String errorMessage = "Merchant is not found";
  private final String description = "Данное ТСП не зарегистрировано в ПЭК";

}
