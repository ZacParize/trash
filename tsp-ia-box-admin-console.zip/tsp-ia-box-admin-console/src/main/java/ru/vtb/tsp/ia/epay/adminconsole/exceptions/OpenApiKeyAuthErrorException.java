package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Getter;

@Getter
public class OpenApiKeyAuthErrorException extends IdentifiedException {

  private final Integer httpCode = 404;
  private final String id = "0120005037";
  private final String errorMessage = "key_auth_error";
  private final String description = "";

}
