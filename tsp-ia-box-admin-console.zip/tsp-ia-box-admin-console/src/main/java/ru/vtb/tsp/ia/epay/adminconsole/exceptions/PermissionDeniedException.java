package ru.vtb.tsp.ia.epay.adminconsole.exceptions;

import lombok.Data;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.07.2022
 */
@Data
public class PermissionDeniedException extends IdentifiedException {

  private final Integer httpCode = 403;
  private final String id = "0120005034";
  private final String errorMessage = "Permission denied";
  private final String description = "Не достаточно прав на выполнение данного действия";

}
