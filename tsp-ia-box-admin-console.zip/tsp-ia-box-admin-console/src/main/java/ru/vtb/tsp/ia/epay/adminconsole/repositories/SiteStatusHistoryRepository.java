package ru.vtb.tsp.ia.epay.adminconsole.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.adminconsole.entities.SiteStatusHistoryRecord;

@Repository
public interface SiteStatusHistoryRepository extends JpaRepository<SiteStatusHistoryRecord, Long>,
    JpaSpecificationExecutor<SiteStatusHistoryRecord> {

}
