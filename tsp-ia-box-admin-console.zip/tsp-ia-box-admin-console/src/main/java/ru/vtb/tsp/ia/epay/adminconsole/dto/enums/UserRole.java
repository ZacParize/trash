package ru.vtb.tsp.ia.epay.adminconsole.dto.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UserRole {

  //FRKK roles (deprecated)
  FRKK_TECH_SUP_SMB("FRCORP-TECH_SUP_SMB"),
  FRKK_ADMIN_SMBQ_PARTNERS("FRCORP-ADMIN_SMBQ_PARTNERS"),

  //SMBQ user-info roles
  SMBQ_TECH_SUP_SMB("SMBQ_TECH_SUP_SMB"),
  SMBQ_ADMIN_SMBQ_PARTNERS("ADMIN_SMBQ_PARTNERS");

  private final String name;

}
