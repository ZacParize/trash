package ru.vtb.tsp.ia.epay.adminconsole.dto.enums;

import java.util.Optional;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.ia.epay.adminconsole.config.annotations.FrkkRoles;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 02.08.2022
 */
@RequiredArgsConstructor
public enum Channel {

  FRKK_CHANNEL("internal", FrkkRoles.class);

  @Getter
  private final String channel;
  @Getter
  private final Class annotation;

  public static Optional<Channel> findByChannel(String channel) {
      for (var val : Channel.values()) {
          if (val.getChannel().equals(channel)) {
              return Optional.of(val);
          }
      }
      return Optional.empty();
  }

}
