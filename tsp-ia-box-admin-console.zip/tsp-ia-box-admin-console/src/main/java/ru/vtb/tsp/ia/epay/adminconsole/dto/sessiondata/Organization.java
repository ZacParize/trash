package ru.vtb.tsp.ia.epay.adminconsole.dto.sessiondata;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties
public class Organization implements Serializable {
  private String mdmCode;
  private String mdmPkbClient;
  private String slxId;
  private String fullName;
  private String shortName;
  private String inn;
  private String ogrn;
  private boolean isInBlackList;
  private String clientTypeCode;
  private String clientTypeName;
  private int clientSegmentId;
  private String clientSegmentName;
}
