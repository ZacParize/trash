package ru.vtb.tsp.ia.epay.adminconsole.config;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.components.RestTemplateFactory;
import ru.vtb.tsp.ia.epay.adminconsole.components.TykUriBuilderFactory;
import ru.vtb.tsp.ia.epay.adminconsole.components.interceptors.TykInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.Integrations;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;

@Configuration
@RequiredArgsConstructor
public class OpenApiRestConfig {

  public static final String OPENAPI = "openApi";
  private final Integrations integrations;
  @Qualifier("epaAmClient")
  private final EpaClient epaAmClient;

  @Bean(OPENAPI)
  RestTemplate openApiClient(RestTemplateFactory restTemplateFactory) {
    final var restTemplate = restTemplateFactory.restTemplate(RestClient.OPENAPI);
    final var connection = integrations.getConnection(RestClient.OPENAPI);
    if (Boolean.TRUE.equals(connection.getTykEnabled())) {
      final var tykInterceptor = new TykInterceptor(epaAmClient, connection);
      final var tykUriBuilderFactory = new TykUriBuilderFactory();
      restTemplate.getInterceptors().add(tykInterceptor);
      restTemplate.setUriTemplateHandler(tykUriBuilderFactory);
    }
    return restTemplate;
  }

}