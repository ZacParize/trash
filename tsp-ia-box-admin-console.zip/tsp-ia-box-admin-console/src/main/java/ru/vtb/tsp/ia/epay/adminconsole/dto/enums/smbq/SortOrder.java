package ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq;

public enum SortOrder {
  ascend,
  descend
}
