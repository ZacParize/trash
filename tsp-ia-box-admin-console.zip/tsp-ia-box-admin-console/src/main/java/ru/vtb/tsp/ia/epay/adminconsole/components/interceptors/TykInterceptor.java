package ru.vtb.tsp.ia.epay.adminconsole.components.interceptors;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.config.properties.RestConnection;
import ru.vtb.tsp.ia.epay.adminconsole.dto.epa.EpaAccessToken;

@RequiredArgsConstructor
public class TykInterceptor implements ClientHttpRequestInterceptor {

  private final EpaClient epaClient;
  private final RestConnection connection;

  @SneakyThrows
  @Override
  public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] bytes,
      ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
    if (Objects.nonNull(connection.getTykEnabled()) && connection.getTykEnabled()) {
      httpRequest.getHeaders().setBearerAuth(token());
      if (HttpMethod.POST.equals(httpRequest.getMethod()) && bytes.length == 0) {
        bytes = "{}".getBytes(StandardCharsets.UTF_8);
      }
    }
    return clientHttpRequestExecution.execute(httpRequest, bytes);
  }

  private String token() {
    return epaClient.getToken().map(EpaAccessToken::getAccessToken).orElse("");
  }
}
