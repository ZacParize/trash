package ru.vtb.tsp.ia.epay.adminconsole.services;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantNameDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.MerchantShortDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
public interface MerchantService {

  /**
   * Find merchant by active session.
   *
   * @param jwt - token with session_id
   * @return - Merchant or empty
   */
  Optional<MerchantShortDto> findMerchantConverted(String jwt);

  /**
   * Find merchant without convertation.
   *
   * @param jwt - token with session id
   * @return - EPay merchant dto
   */
  Optional<MerchantDto> findMerchant(String jwt);

  /**
   * Create merchant data.
   *
   * @param jwt - token with active session
   * @return updated merchant data
   */
  Optional<MerchantShortDto> createMerchant(String jwt);

  /**
   * Get merchant name from session data.
   *
   * @param jwt - token with active session
   * @return - short and full name
   */
  Optional<MerchantNameDto> getMerchantName(String jwt);

}
