package ru.vtb.tsp.ia.epay.adminconsole.config.properties;

import lombok.Data;
import ru.vtb.tsp.ia.epay.adminconsole.utils.FileUtils;

/**
 * Конфиг SSL.
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 16.08.2021
 */
@Data
public class Ssl {

  private String protocol;

  private String truststorePath;

  private String truststorePass;

  private String truststoreType;

  private String keystorePath;

  private String keystorePass;

  private String keystoreType;

  private String keyPass;

  private Boolean clientAuth;

  private Boolean certValidation;

  private Boolean tlsVerification;

  @Override
  public String toString() {
    return "Ssl{" +
        "protocol='" + protocol + '\'' +
        ", truststorePath='" + truststorePath + '\'' + " (" + FileUtils.fileSize(truststorePath) + ')' +
        ", truststorePass='" + truststorePass + '\'' +
        ", truststoreType='" + truststoreType + '\'' +
        ", keystorePath='" + keystorePath + '\'' + " (" + FileUtils.fileSize(keystorePath) + ')' +
        ", keystorePass='" + keystorePass + '\'' +
        ", keystoreType='" + keystoreType + '\'' +
        ", keyPass='" + keyPass + '\'' +
        ", clientAuth=" + clientAuth +
        ", certValidation=" + certValidation +
        ", tlsVerification=" + tlsVerification +
        '}';
  }
}