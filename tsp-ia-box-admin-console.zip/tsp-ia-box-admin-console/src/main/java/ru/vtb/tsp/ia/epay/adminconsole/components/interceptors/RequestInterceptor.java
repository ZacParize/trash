package ru.vtb.tsp.ia.epay.adminconsole.components.interceptors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import ru.vtb.tsp.ia.epay.adminconsole.utils.JwtTokenUtils;

@Component
@Slf4j
public class RequestInterceptor implements HandlerInterceptor {

  @Value("${logging.showJwtToken:false}")
  private Boolean showJwtToken;
  @Value("${logging.showInboundRequests:false}")
  private Boolean showRequest;

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
      throws Exception {
    if (showRequest) {
      log.debug("Endpoint: {}: {}", request.getMethod(), request.getRequestURL());
    }
    if (handler instanceof HandlerMethod) {
      final var handlerMethod = (HandlerMethod) handler;
      log.info("Method: {}.{}", handlerMethod.getMethod().getDeclaringClass().getSimpleName(),
          handlerMethod.getMethod().getName());
    }
    if (showJwtToken) {
      final var token = request.getHeader(HttpHeaders.AUTHORIZATION);
      log.debug("JWT: {}", token);
      if (StringUtils.isNotEmpty(token)) {
        log.debug("JwtDto: {}", JwtTokenUtils.extractJwtInfo(token).orElse(null));
      }
    }
    return HandlerInterceptor.super.preHandle(request, response, handler);
  }
}