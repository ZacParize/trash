package ru.vtb.tsp.ia.epay.adminconsole.config;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.adminconsole.components.RestTemplateFactory;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.RestClient;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 23.06.2022
 */
@Configuration
@RequiredArgsConstructor
public class SessionDataRestConfig {
  private final RestTemplateFactory restTemplateFactory;

  @Bean("sessionDataClient")
  RestTemplate sessionDataClient(RestTemplateFactory restTemplateFactory) {
    return restTemplateFactory.restTemplate(RestClient.SESSION_DATA);
  }

}
