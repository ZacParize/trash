package ru.vtb.tsp.ia.epay.adminconsole.dto.transactions;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.OrderStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.enums.smbq.PaymentType;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto {

  private String orderCode;
  private String orderMerchantId;
  private String createdDate;
  private AmountDto amount;
  private OrderStatus status;
  private MerchantSiteDto merchantSite;
  private List<TransactionDto> transactions;
  private PaymentType paymentType;
  private String sourceSystem;
  private ActionsDto actions;
}
