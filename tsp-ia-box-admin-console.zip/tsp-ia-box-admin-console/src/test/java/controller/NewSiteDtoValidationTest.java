package controller;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import org.junit.jupiter.api.Test;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.NewSiteDto;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.SiteParamsDto;

public class NewSiteDtoValidationTest {

  private final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
  private final Validator validator = factory.getValidator();

  @Test
  public void testNewSiteDtoValidation() {
    NewSiteDto newSiteDto = new NewSiteDto();
    newSiteDto.setUrl("http://www.vtb.ru");
    newSiteDto.setName("test");
    newSiteDto.setLogin("test");
    newSiteDto.setPartnershipChannel(true);

    SiteParamsDto params = new SiteParamsDto();
    params.setMcc("1234");

    newSiteDto.setParams(params);

    Set<ConstraintViolation<NewSiteDto>> violations = validator.validate(newSiteDto);

    assertTrue(violations.isEmpty());
  }

}
