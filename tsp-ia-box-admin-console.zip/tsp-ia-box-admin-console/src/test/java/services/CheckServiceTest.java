package services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import ru.vtb.tsp.ia.epay.adminconsole.clients.ecm.EcmClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.epa.EpaClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.frkk.FrkkClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.merchantapi.MerchantApiClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.openapi.OpenApiClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.sessiondata.SessionDataClient;
import ru.vtb.tsp.ia.epay.adminconsole.clients.transactions.TransactionsClient;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatusDto;
import ru.vtb.tsp.ia.epay.adminconsole.services.CheckService;
import ru.vtb.tsp.ia.epay.adminconsole.services.impl.CheckServiceImpl;

public class CheckServiceTest {

  private final EpaClient epaAmClient = Mockito.mock(EpaClient.class);
  private final EpaClient epaIgClient = Mockito.mock(EpaClient.class);
  private final EcmClient ecmClient = Mockito.mock(EcmClient.class);
  private final FrkkClient frkkClient = Mockito.mock(FrkkClient.class);
  private final MerchantApiClient merchantApiClient = Mockito.mock(MerchantApiClient.class);
  private final OpenApiClient openApiClient = Mockito.mock(OpenApiClient.class);
  private final SessionDataClient sessionDataClient = Mockito.mock(SessionDataClient.class);
  private final TransactionsClient transactionsClient = Mockito.mock(TransactionsClient.class);
  private CheckService checkService;

  @BeforeEach
  public void setup() {
    checkService = new CheckServiceImpl(epaAmClient, epaIgClient, ecmClient, frkkClient,
        merchantApiClient, openApiClient, sessionDataClient, transactionsClient);
  }

  @Test
  public void testCheck_ShouldBe_Ok() {
    final IntegrationStatusDto integrationStatus = IntegrationStatusDto.builder()
        .status(IntegrationStatus.SUCCESS)
        .build();

    doReturn(integrationStatus).when(epaAmClient).check();
    doReturn(integrationStatus).when(epaIgClient).check();
    doReturn(integrationStatus).when(ecmClient).check();
    doReturn(integrationStatus).when(frkkClient).check();
    doReturn(integrationStatus).when(merchantApiClient).check();
    doReturn(integrationStatus).when(openApiClient).check();
    doReturn(integrationStatus).when(sessionDataClient).check();
    doReturn(integrationStatus).when(transactionsClient).check();

    final var result = checkService.check();
    assertEquals(result.getCommonCheckStatus(), IntegrationStatus.SUCCESS);
    assertEquals(8, result.getIntegrationStates().size());
  }
}
