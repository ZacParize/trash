package utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import ru.vtb.tsp.ia.epay.adminconsole.dto.api.check.IntegrationStatus;
import ru.vtb.tsp.ia.epay.adminconsole.utils.CheckUtils;

public class CheckUtilsTest {

  @Test
  public void testProcessResponse_ShouldBe_Ok_When_Response200OK() {
    final var result = CheckUtils.processResponse("integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.SUCCESS);
    assertNull(result.getErrors());
    assertEquals("integrationName", result.getIntegrationName());
  }

  @Test
  public void testProcessException_ShouldBe_True_When_HttpStatusNotFound() {
    final var exception = new HttpClientErrorException(HttpStatus.NOT_FOUND);
    final var result = CheckUtils.processException(exception, "integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.SUCCESS);
    assertNull(result.getErrors());
    assertEquals("integrationName", result.getIntegrationName());
  }

  @Test
  public void testProcessException_ShouldBe_True_When_HttpStatusUnauthorized() {
    final var exception = new HttpClientErrorException(HttpStatus.UNAUTHORIZED);
    final var result = CheckUtils.processException(exception, "integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.SUCCESS);
    assertNull(result.getErrors());
    assertEquals("integrationName", result.getIntegrationName());
  }

  @Test
  public void testProcessException_ShouldBe_False_When_HttpStatusOther400() {
    final var exception = new HttpClientErrorException(HttpStatus.BAD_REQUEST);
    final var result = CheckUtils.processException(exception, "integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.CONFIG_ERROR);
    assertEquals("integrationName", result.getIntegrationName());
  }

  @Test
  public void testProcessException_ShouldBe_False_When_HttpServerErrorException() {
    final var exception = new HttpServerErrorException(HttpStatus.BAD_GATEWAY);
    final var result = CheckUtils.processException(exception, "integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.OTHER_ERROR);
    assertEquals("integrationName", result.getIntegrationName());
  }

  @Test
  public void testProcessException_ShouldBe_False_When_OtherException() {
    final var exception = new RuntimeException();
    final var result = CheckUtils.processException(exception, "integrationName");

    assertEquals(result.getStatus(), IntegrationStatus.OTHER_ERROR);
    assertEquals("integrationName", result.getIntegrationName());
  }
}
