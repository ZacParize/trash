package ru.vtb.tsp.ia.epay.fiscalization;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.support.Acknowledgment;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.core.domains.bundle.TaxParams;
import ru.vtb.tsp.ia.epay.core.domains.kafka.payloads.FiscalizationTask;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.EpaTokenResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptPrintResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.TokenResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.mappers.DocumentMapper;
import ru.vtb.tsp.ia.epay.fiscalization.mappers.ReceiptPrintRequestMapper;
import ru.vtb.tsp.ia.epay.fiscalization.service.ApiListenerService;
import ru.vtb.tsp.ia.epay.fiscalization.service.MerchantSiteServiceFacade;
import ru.vtb.tsp.ia.epay.fiscalization.service.ProcessorService;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFiscalParamsDto;

@ExtendWith(MockitoExtension.class)
public class ProcessorServiceTest {

  @Mock
  private FirstOfdClientImpl firstOfdClient;

  @Mock
  private MerchantSiteServiceFacade merchantApiService;

  @Mock
  private ApiListenerService apiListenerService;

  @Mock
  private ReceiptPrintRequestMapper requestMetaDataMapper;

  @Mock
  private DocumentMapper documentMapper;

  @InjectMocks
  private ProcessorService processorService;

  //@Test
  public void processTest() {

    List<BundleDto> bundleDtos = new ArrayList<>();
    BigDecimal ecashTotalSum = BigDecimal.ZERO;
    bundleDtos.add(
        BundleDto.builder()
            .taxParams(TaxParams.builder()
                .amount(ecashTotalSum).build())
            .build());
    MerchantSiteFiscalParamsDto fiscalParams = new MerchantSiteFiscalParamsDto();
    fiscalParams.setLogin("login");
    fiscalParams.setPassword("password");
    ResponseEntity<EpaTokenResponseDto> epaToken = new ResponseEntity<>(HttpStatus.OK);
    ResponseEntity<TokenResponseDto> tokenOFD = new ResponseEntity<>(HttpStatus.OK);
    DocumentDto documentDto = new DocumentDto();
    ResponseEntity<ReceiptPrintResponseDto> objectResponseEntity = new ResponseEntity<>(
        HttpStatus.OK);

    Mockito.when(apiListenerService.getByOrderId(Mockito.anyString())).thenReturn(bundleDtos);
    Mockito.when(merchantApiService.getFiscalParams(Mockito.anyString())).thenReturn(fiscalParams);
    Mockito.when(firstOfdClient.getEpaToken()).thenReturn(epaToken);
    Mockito.when(firstOfdClient.getOfdToken(Mockito.anyString(), Mockito.anyString()))
        .thenReturn(tokenOFD);
    Mockito.when(documentMapper.toDocumentDtoMapper(Mockito.any(), Mockito.any(), Mockito.any(),
        Mockito.any())).thenReturn(documentDto);
    Mockito.when(firstOfdClient.addReceiptToPrintQueue(Mockito.any(), Mockito.any(), Mockito.any()))
        .thenReturn(objectResponseEntity);
    final var record = new ConsumerRecord<>("topic", 1, 1, "key",
        FiscalizationTask.builder()
            .orderCode(UUID.randomUUID())
            .mstId("mstId")
            .build());
    final var acknowledgment = new Acknowledgment() {
      @Override
      public void acknowledge() {
      }

      @Override
      public void nack(long sleep) {
        Acknowledgment.super.nack(sleep);
      }

      @Override
      public void nack(int index, long sleep) {
        Acknowledgment.super.nack(index, sleep);
      }
    };
    processorService.process(record, acknowledgment);

    Mockito.verify(apiListenerService, Mockito.times(1)).getByOrderId(Mockito.anyString());
    Mockito.verify(merchantApiService, Mockito.times(1)).getFiscalParams(Mockito.anyString());
    Mockito.verify(firstOfdClient, Mockito.times(1)).getEpaToken();
    Mockito.verify(firstOfdClient, Mockito.times(1))
        .getOfdToken(Mockito.anyString(), Mockito.anyString());
    Mockito.verify(documentMapper, Mockito.times(1))
        .toDocumentDtoMapper(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
    Mockito.verify(firstOfdClient, Mockito.times(1))
        .addReceiptToPrintQueue(Mockito.any(), Mockito.any(), Mockito.any());
  }
}
