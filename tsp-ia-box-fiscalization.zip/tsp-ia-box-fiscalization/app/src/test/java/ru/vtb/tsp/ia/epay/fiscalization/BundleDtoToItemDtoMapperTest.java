package ru.vtb.tsp.ia.epay.fiscalization;


import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import org.apache.logging.log4j.core.util.FileUtils;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.core.domains.enums.TaxRate;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ItemDto;
import ru.vtb.tsp.ia.epay.fiscalization.mappers.ItemMapperImpl;

@ExtendWith(SpringExtension.class)
public class BundleDtoToItemDtoMapperTest {

  @InjectMocks
  private ItemMapperImpl bundleDtoToItemDtoMapper;


  //@Test
  public void toItemDtoTest() throws IOException {
    ObjectMapper objectMapper = new ObjectMapper();
    InputStream is = FileUtils.class.getResourceAsStream("/Bundle.json");
    BundleDto bundleDto = objectMapper.readValue(is, BundleDto.class);

    ItemDto itemDto = bundleDtoToItemDtoMapper.toItemDto(bundleDto);

    assertEquals(bundleDto.getName(), itemDto.getLabel());
    assertEquals(bundleDto.getPrice(), itemDto.getPrice());
    assertEquals(bundleDto.getQuantity(), itemDto.getQuantity());
    assertEquals(bundleDto.getTaxParams().getTaxType(),
        TaxRate.fromName(itemDto.getVatCode().name()));
    assertEquals(bundleDto.getTaxParams().getAmount(), itemDto.getAmount());
    assertEquals(bundleDto.getTaxParams().getTaxSum(), itemDto.getItemVatAmount());
    assertEquals(bundleDto.getTaxParams().getPaymentType(), itemDto.getPaymentType());
    assertEquals(bundleDto.getTaxParams().getPaymentSubject(), itemDto.getPaymentSubject());
    assertEquals(bundleDto.getMeasure(), itemDto.getMeasurementUnit());
    assertEquals(bundleDto.getTaxParams().getUserData(), itemDto.getAdditionalPositionInfo());
    assertEquals(bundleDto.getTaxParams().getPaymentSubject(), itemDto.getPaymentSubjectType());
  }
}
