package ru.vtb.tsp.ia.epay.fiscalization.configs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import ru.vtb.tsp.ia.epay.core.configurations.KafkaConfiguration;

@Slf4j
@Configuration
public class KafkaConsumerConfig {

  public static final int FETCH_TIMEOUT = 500;
  public static final int TIMEOUT = 5000;
  private static final int CONSUMER_CONCURRENCY = 3;
  private static final int MAX_POLL_RECORDS = 1;

  @Value("${spring.kafka.bootstrap-servers}")
  @NotEmpty
  private List<String> bootstrapServers;

  @Value("${app.kafka.consumer.topics}")
  @NotEmpty
  private List<String> consumerTopics;

  @Value("${app.kafka.partitions-count}")
  private int partitionsCount;

  @Value("${app.kafka.replicas-count}")
  private int replicasCount;

  @Value("${spring.kafka.consumer.group-id}")
  @NotBlank
  private String groupId;

  @Value("${spring.kafka.consumer.ssl.protocol:#{null}}")
  private String sslProtocol;

  @Value("${spring.kafka.consumer.ssl.trust-store-type:#{null}}")
  private String sslTrustStoreType;

  @Value("${spring.kafka.consumer.ssl.trust-store-location:#{null}}")
  private String sslTrustStoreLocation;

  @Value("${spring.kafka.consumer.ssl.trust-store-password:#{null}}")
  private String sslTrustStorePassword;

  @Value("${spring.kafka.consumer.ssl.key-store-type:#{null}}")
  private String sslKeyStoreType;

  @Value("${spring.kafka.consumer.ssl.key-store-location:#{null}}")
  private String sslKeyStoreLocation;

  @Value("${spring.kafka.consumer.ssl.key-store-password:#{null}}")
  private String sslKeyStorePassword;

  @Value("${spring.kafka.consumer.ssl.key-password:#{null}}")
  private String sslKeyPassword;

  public Map<String, Object> consumerConfig() {
    final var configuration = new HashMap<String, Object>();
    configuration.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
    configuration.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    configuration.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, JsonDeserializer.class);
    configuration.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
    configuration.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, MAX_POLL_RECORDS);
    configuration.put(ConsumerConfig.FETCH_MAX_WAIT_MS_CONFIG, FETCH_TIMEOUT);
    configuration.put(ConsumerConfig.ALLOW_AUTO_CREATE_TOPICS_CONFIG, true);
    configuration.put(ConsumerConfig.AUTO_COMMIT_INTERVAL_MS_CONFIG, TIMEOUT);
    configuration.put(ConsumerConfig.SESSION_TIMEOUT_MS_CONFIG, TIMEOUT * 2);
    configuration.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
    configuration.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
    configuration.put(ConsumerConfig.ISOLATION_LEVEL_CONFIG,
        KafkaProperties.IsolationLevel.READ_COMMITTED.toString().toLowerCase());
    configuration.put(JsonDeserializer.TRUSTED_PACKAGES, "*");
    configuration.put(JsonDeserializer.VALUE_DEFAULT_TYPE, Object.class.getCanonicalName());
    KafkaConfiguration.setSslProperties(configuration,
        sslProtocol,
        sslTrustStoreType,
        sslTrustStoreLocation,
        sslTrustStorePassword,
        sslKeyStoreType,
        sslKeyStoreLocation,
        sslKeyStorePassword,
        sslKeyPassword);
    KafkaConfiguration.createTopics(configuration, consumerTopics, partitionsCount, replicasCount);
    return configuration;
  }

  @Bean
  public ConsumerFactory<String, ?> kafkaConsumerFactory() {
    return new DefaultKafkaConsumerFactory<>(consumerConfig());
  }

  @Bean
  public ConcurrentKafkaListenerContainerFactory<String, ?> kafkaListenerContainerFactory(
      ConsumerFactory<String, Object> kafkaConsumerFactory) {
    //KafkaTransactionManager<String, ?> kafkaTransactionManager) {
    final var factory = new ConcurrentKafkaListenerContainerFactory<String, Object>();
    factory.setConsumerFactory(kafkaConsumerFactory);
    factory.setConcurrency(CONSUMER_CONCURRENCY);
    factory.setBatchListener(false);
    factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
    //factory.getContainerProperties().setTransactionManager(kafkaTransactionManager);
    return factory;
  }
}