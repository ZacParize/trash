package ru.vtb.tsp.ia.epay.fiscalization.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.validation.MapBindingResult;
import org.springframework.validation.Validator;
import ru.vtb.tsp.ia.epay.apilistener.impl.BundleClientImpl;
import ru.vtb.tsp.ia.epay.core.domains.kafka.payloads.FiscalizationTask;
import ru.vtb.tsp.ia.epay.fiscalization.FirstOfdClientImpl;
import ru.vtb.tsp.ia.epay.fiscalization.entity.Receipt;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptOperator;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptState;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptType;
import ru.vtb.tsp.ia.epay.fiscalization.mappers.DocumentMapper;
import ru.vtb.tsp.ia.epay.fiscalization.mappers.ReceiptPrintRequestMapper;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClientImpl;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class ProcessorService {

  private final Validator validator;
  private final ObjectMapper objectMapper;
  private final KafkaService kafkaService;
  private final BundleClientImpl bundleClient;
  private final ReceiptService receiptService;
  private final MerchantApiClientImpl merchantApiClient;
  private final FirstOfdClientImpl firstOfClient;
  private final ReceiptPrintRequestMapper requestMetaDataMapper;
  private final DocumentMapper documentMapper;

  public @NotNull Optional<FiscalizationTask> transform(@Nullable Object message) {
    try {
      return message == null ? Optional.empty() :
          (Optional.of(message instanceof FiscalizationTask ? (FiscalizationTask) message
              : objectMapper.convertValue(message, FiscalizationTask.class)));
    } catch (IllegalArgumentException ex) {
      kafkaService.sendToDlq(message);
      log.error("Fiscalization task transform exception", ex);
      return Optional.empty();
    }
  }

  //@Transactional(transactionManager = "kafkaTransactionManager")
  @KafkaListener(topics = "${app.kafka.consumer.topics}",
      containerFactory = "kafkaListenerContainerFactory")
  public void process(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      if (Objects.isNull(record.value())) {
        return;
      }
      transform(record.value())
          .filter(ft -> {
            final var errors = new MapBindingResult(new HashMap<String, String>(),
                Objects.requireNonNull(ft.getOrderCode().toString(),
                    "Fiscalization task order code can't be null"));
            validator.validate(ft, errors);
            final var errorCount = errors.getTargetMap().values().size();
            log.info("Fiscalization task order code {} has {} errors", ft.getOrderCode().toString(),
                errorCount == 0 ? "no" : String.valueOf(errorCount));
            return !errors.hasErrors();
          })
          .ifPresent(ft -> {
            final var bundleDtos = bundleClient.getByOrderCode(ft.getOrderCode().toString());

            final var fiscalParams = merchantApiClient.getMerchantSite(ft.getMstId())
                .map(MerchantSiteDto::getParams)
                .map(MerchantSiteParamsDto::getFiscalParams)
                .orElse(null);

            final var epaToken = firstOfClient.getEpaToken();

            final var tokenOFD = firstOfClient.getOfdToken(
                Objects.requireNonNull(fiscalParams).getLogin(), fiscalParams.getPassword());

            final var ecashTotalSum = bundleDtos.stream()
                .map(bundleDto -> bundleDto.getTaxParams().getAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);

            final var documentDto = documentMapper.toDocumentDtoMapper(fiscalParams, ft,
                ecashTotalSum, bundleDtos);

            final var responseEntity = firstOfClient
                .addReceiptToPrintQueue(tokenOFD.getBody(), epaToken.getBody(),
                    requestMetaDataMapper.mapToReceiptPrintRequestDto(fiscalParams, documentDto));

            final var dateTime = LocalDateTime.now(ZoneOffset.UTC);

            final var entity = receiptService.save(Receipt.builder()
                .operator(ReceiptOperator.OFD_1)
                .type(ReceiptType.INCOME)
                .documentId(Objects.requireNonNull(responseEntity.getBody()).getRequestId())
                .url(responseEntity.getBody().getPayload().getReceiptUrl())
                .state(ReceiptState.NEW)
                .externalId(UUID.randomUUID())
                .transactionCode(ft.getTransactionCode())
                .creationData(responseEntity.toString())
                .statusData(responseEntity.getBody().getStatus().toString())
                .createdAt(dateTime)
                .changedAt(dateTime)
                .version(1)
                .build()).block();

          });
    } catch (Exception ex) {
      log.error("Fiscalization task with key {} can't be processed", record.key(), ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}