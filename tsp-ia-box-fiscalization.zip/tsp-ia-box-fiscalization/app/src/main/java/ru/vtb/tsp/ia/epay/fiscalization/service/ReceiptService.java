package ru.vtb.tsp.ia.epay.fiscalization.service;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.fiscalization.entity.Receipt;
import ru.vtb.tsp.ia.epay.fiscalization.repository.ReceiptRepository;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReceiptService {

  private final ReceiptRepository receiptRepository;

  public Mono<Receipt> get(UUID id) {
    return receiptRepository.findById(id)
        .doOnSuccess(receipt -> log.info("Get receipt by id {}, result {}", id, receipt))
        .doOnError(ex -> log.error("Error while getting receipt by id {}, ex {}", id, ex));
  }

  @Transactional
  public Mono<Receipt> save(Receipt entity) {
    return receiptRepository.saveOrUpdate(entity)
        .doOnSuccess(receipt -> log.info("Save receipt, result {}", receipt))
        .doOnError(ex -> log.error("Error while trying to save receipt {}, ex {}", entity, ex));
  }

}