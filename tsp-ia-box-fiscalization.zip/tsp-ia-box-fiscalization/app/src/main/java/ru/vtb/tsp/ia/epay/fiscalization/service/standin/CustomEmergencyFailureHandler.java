package ru.vtb.tsp.ia.epay.fiscalization.service.standin;

import lombok.extern.slf4j.Slf4j;
import ru.vtb.smartreplication.client.producer.EnableReplicationResolver;
import ru.vtb.smartreplication.client.producer.handler.CustomReplicationPropertiesProvider;
import ru.vtb.smartreplication.client.producer.handler.DefaultEmergencyFailureHandler;
import ru.vtb.smartreplication.client.producer.handler.ReplicationFailureType;
import ru.vtb.smartreplication.core.exception.SmartReplicationException;

@Slf4j
public class CustomEmergencyFailureHandler extends DefaultEmergencyFailureHandler {

  public CustomEmergencyFailureHandler(
      EnableReplicationResolver enableReplicationResolver,
      CustomReplicationPropertiesProvider customReplicationPropertiesProvider,
      int maxReplicationErrors,
      int errorPeriodInSeconds) {
    super(enableReplicationResolver, customReplicationPropertiesProvider, maxReplicationErrors,
        errorPeriodInSeconds);
  }

  @Override
  public void handleException(ReplicationFailureType replicationFailureType,
      SmartReplicationException smartReplicationException) {
    log.error("Replication error occurred:", smartReplicationException);

    switch (replicationFailureType) {
      case KAFKA_ERROR -> super.handleKafkaError(smartReplicationException);
      case ETCD_INITIALIZATION_ERROR -> super.handleEtcdInitializationError(
          smartReplicationException);
      case ETCD_GET_CHANGE_SOURCE_ERROR -> handleEtcdGetChangeSourceError(
          smartReplicationException);
      default -> throw smartReplicationException;
    }
  }


  @Override
  public void handleEtcdGetChangeSourceError(SmartReplicationException smartReplicationException) {
    getCustomReplicationPropertiesProvider().setReplicationEnabled(false);
  }

}
