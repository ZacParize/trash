package ru.vtb.tsp.ia.epay.fiscalization.service.standin;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import ru.vtb.streaming.config.AdapterConfig;
import ru.vtb.streaming.jdbc.ColumnInfo;
import ru.vtb.streaming.jdbc.TableInfo;
import ru.vtb.streaming.parser.OperationType;
import ru.vtb.streaming.visitor.ChangeFormatFacade;
import ru.vtb.streaming.visitor.IReturningColumnStrategy;

@Slf4j
public class CustomReturningColumnStrategy implements IReturningColumnStrategy {

  @Override
  public List<ColumnInfo> calculateReturningColumns(TableInfo tableInfo,
      OperationType operationType, AdapterConfig config) {
    final var isApply =
        Objects.nonNull(tableInfo) && Objects.nonNull(tableInfo.getPrimaryKeyInfo());
    if (!isApply) {
      return Collections.emptyList();
    }
    var returningColumns = Collections.<ColumnInfo>emptyList();
    if (operationType != null) {
      switch (operationType) {
        case INSERT:
        case UPSERT:
          returningColumns = tableInfo.getColumns();
          break;
        case UPDATE:
          returningColumns = ChangeFormatFacade.get(config.getChangeFormatType())
              .getUpdateColumns(tableInfo);
          break;

        case DELETE:
          final Set<String> primaryColumns = new HashSet<>(
              tableInfo.getPrimaryKeyInfo().getColumns());
          returningColumns = tableInfo.getColumns().stream()
              .filter(c -> primaryColumns.contains(c.getColumn()))
              .collect(Collectors.toList());
          break;
        default:
          break;
      }

    }
    log.debug("returning columns {}", returningColumns);
    return returningColumns;
  }
}
