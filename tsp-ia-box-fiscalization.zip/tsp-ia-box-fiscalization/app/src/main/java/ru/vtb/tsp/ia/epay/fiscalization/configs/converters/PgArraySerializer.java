package ru.vtb.tsp.ia.epay.fiscalization.configs.converters;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import java.io.IOException;
import org.postgresql.jdbc.PgArray;

public class PgArraySerializer extends JsonSerializer<PgArray> implements ContextualSerializer {


  @Override
  public void serialize(PgArray value, JsonGenerator gen, SerializerProvider serializers)
      throws IOException {
    try {
      gen.writeObject(value.getArray());
    } catch (Exception e) {
      throw new IllegalArgumentException("Failed to serialize a PgArray", e);
    }
  }

  @Override
  public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property)
      throws JsonMappingException {
    return new PgArraySerializer();
  }
}
