package ru.vtb.tsp.ia.epay.fiscalization.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ReceiptPrintRequestDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFiscalParamsDto;

@Mapper(componentModel = "spring")
public interface ReceiptPrintRequestMapper {

  @Mapping(target = "requestMetadataDto.userGroup", source = "merchantSiteFiscalParamsDto.kktId")
  @Mapping(target = "requestMetadataDto.timestamp",
      expression = "java(java.time.LocalDateTime.now())")
  @Mapping(target = "requestMetadataDto.externalId",
      expression = "java(java.util.UUID.randomUUID().toString())")
  @Mapping(target = "cashboxParametersDto.userInn", source = "merchantSiteFiscalParamsDto.inn")
  @Mapping(target = "document", source = "documentDto")
  ReceiptPrintRequestDto mapToReceiptPrintRequestDto(
      MerchantSiteFiscalParamsDto merchantSiteFiscalParamsDto, DocumentDto documentDto);

}
