package ru.vtb.tsp.ia.epay.fiscalization.entity;

public enum ReceiptOperator {

  OFD_1

}