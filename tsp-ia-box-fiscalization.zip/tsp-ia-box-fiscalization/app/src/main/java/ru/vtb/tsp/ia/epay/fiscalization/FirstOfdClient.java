package ru.vtb.tsp.ia.epay.fiscalization;

import org.springframework.cloud.openfeign.FeignClient;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.FirstOfdApi;

@FeignClient(name = "firstOfdClient", url = "${epa.url}", decode404 = true)
public interface FirstOfdClient extends FirstOfdApi {

}