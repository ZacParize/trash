package ru.vtb.tsp.ia.epay.fiscalization.configs;

import static io.r2dbc.spi.ConnectionFactoryOptions.PASSWORD;
import static io.r2dbc.spi.ConnectionFactoryOptions.USER;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.etcd.jetcd.Client;
import io.grpc.netty.GrpcSslContexts;
import io.r2dbc.proxy.ProxyConnectionFactory;
import io.r2dbc.proxy.callback.ProxyConfig;
import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.r2dbc.R2dbcProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.dialect.PostgresDialect;
import org.springframework.r2dbc.connection.R2dbcTransactionManager;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import ru.vtb.smartreplication.client.producer.AbstractCachedResolver;
import ru.vtb.smartreplication.client.producer.DistributedChangeSourceResolver;
import ru.vtb.smartreplication.client.producer.WatcherChangeSourceResolver;
import ru.vtb.smartreplication.client.producer.handler.CustomReplicationPropertiesProvider;
import ru.vtb.smartreplication.client.producer.handler.EmergencyFailureHandler;
import ru.vtb.smartreplication.client.producer.handler.EmptyEmergencyFailureHandler;
import ru.vtb.smartreplication.client.producer.handler.ReplicationFailureType;
import ru.vtb.smartreplication.client.r2dbc.SmartReplicationConnectionFactory;
import ru.vtb.smartreplication.configuration.IConfigurationManagerPrivate;
import ru.vtb.smartreplication.configuration.etcd.AbstractEtcdConfigurationManager;
import ru.vtb.smartreplication.configuration.etcd.DefaultEtcdClientBuilderConfigurer;
import ru.vtb.smartreplication.configuration.etcd.EtcdClientBuilderConfigurerComposite;
import ru.vtb.smartreplication.configuration.etcd.EtcdClientBuilderConfigurerWrapper;
import ru.vtb.smartreplication.configuration.etcd.EtcdConfigurationManager;
import ru.vtb.smartreplication.configuration.etcd.EtcdMarker;
import ru.vtb.smartreplication.core.compress.ChangeCompressor;
import ru.vtb.smartreplication.core.compress.IChangeCompressor;
import ru.vtb.smartreplication.core.compress.JsonConverter;
import ru.vtb.smartreplication.core.exception.SmartReplicationException;
import ru.vtb.smartreplication.core.kafka.config.KafkaProducerConfig;
import ru.vtb.smartreplication.core.kafka.producer.OwnerKafkaProducerTopicResolver;
import ru.vtb.smartreplication.core.provider.ChangeFormatType;
import ru.vtb.smartreplication.core.ssl.KeyStoreSslContextBuilderConfigurer;
import ru.vtb.smartreplication.core.ssl.SslContextBuilderConfigurerComposite;
import ru.vtb.smartreplication.core.ssl.SslContextBuilderConfigurerWrapper;
import ru.vtb.smartreplication.model.Change;
import ru.vtb.smartreplication.model.ChangeSource;
import ru.vtb.smartreplication.model.CompressType;
import ru.vtb.smartreplication.model.ProviderType;
import ru.vtb.streaming.config.AdapterConfig;
import ru.vtb.streaming.config.SkipQueriesPredicate;
import ru.vtb.streaming.config.SkipTablePredicate;
import ru.vtb.streaming.handler.IEventHandler;
import ru.vtb.streaming.handler.StreamingHandler;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.streaming.mdc.MDCPropertiesSupplier;
import ru.vtb.streaming.producer.KafkaReactiveMessageSender;
import ru.vtb.streaming.r2dbc.core.IR2dbcDatabaseCrawler;
import ru.vtb.streaming.r2dbc.core.R2dbcDatabaseCrawler;
import ru.vtb.streaming.r2dbc.core.SyncR2dbcInterceptor;
import ru.vtb.streaming.r2dbc.core.factory.IInterceptFactory;
import ru.vtb.streaming.r2dbc.core.factory.InterceptFactory;
import ru.vtb.tsp.ia.epay.fiscalization.configs.converters.StandInObjectMapper;
import ru.vtb.tsp.ia.epay.fiscalization.configs.standin.StandInProperties;
import ru.vtb.tsp.ia.epay.fiscalization.service.standin.CustomEmergencyFailureHandler;
import ru.vtb.tsp.ia.epay.fiscalization.service.standin.CustomReplicationPropertiesProviderImpl;
import ru.vtb.tsp.ia.epay.fiscalization.service.standin.MockEtcdConfigurationManager;

@Configuration
@ConditionalOnProperty(prefix = "smart-replication", name = "enable", havingValue = "true")
@Slf4j
public class SmartReplicationConfig {

  private static final String DB_ALIAS = "TOKENIZATION";
  private static final String DB = "db";

  private StandInProperties standInProperties;
  private ObjectMapper objectMapper;

  public SmartReplicationConfig(
      StandInProperties standInProperties,
      ObjectMapper objectMapper) {
    this.standInProperties = standInProperties;
    this.objectMapper = objectMapper;
  }

  @Bean("mainR2dbcProperties")
  @ConfigurationProperties("spring.r2dbc.main")
  public R2dbcProperties mainR2dbcProperties() {
    return new R2dbcProperties();
  }

  @Bean("standInR2dbcProperties")
  @ConfigurationProperties("spring.r2dbc.standin")
  public R2dbcProperties standInR2dbcProperties() {
    return new R2dbcProperties();
  }

  @Bean("mainConnectionFactory")
  public ConnectionFactory mainConnectionFactory(
      @Qualifier("mainR2dbcProperties") R2dbcProperties mainR2dbcProperties) {
    return ConnectionFactories.get(ConnectionFactoryOptions.parse(mainR2dbcProperties.getUrl())
        .mutate()
        .option(USER, mainR2dbcProperties.getUsername())
        .option(PASSWORD, mainR2dbcProperties.getPassword())
        .build());
  }

  @Bean("standinConnectionFactory")
  public ConnectionFactory standinConnectionFactory(
      @Qualifier("standInR2dbcProperties") R2dbcProperties standInR2dbcProperties) {
    return ConnectionFactories.get(ConnectionFactoryOptions.parse(standInR2dbcProperties.getUrl())
        .mutate()
        .option(USER, standInR2dbcProperties.getUsername())
        .option(PASSWORD, standInR2dbcProperties.getPassword())
        .build());
  }

  @Bean
  public SmartReplicationConnectionFactory smartReplicationConnectionFactory(
      final AbstractCachedResolver changeSourceResolver,
      @Qualifier("mainConnectionFactory") ConnectionFactory mainConnectionFactory,
      @Qualifier("standinConnectionFactory") ConnectionFactory standinConnectionFactory

  ) {
    return new SmartReplicationConnectionFactory(mainConnectionFactory, standinConnectionFactory,
        changeSourceResolver, standInProperties.getOwner(), new EmptyEmergencyFailureHandler<>());
  }


  @Bean(initMethod = "start", destroyMethod = "stop")
  public AbstractEtcdConfigurationManager etcdConfigurationManager(
      final List<EtcdClientBuilderConfigurerWrapper<EtcdMarker>> etcdConfigurerWrappers) {
    if (standInProperties.getEtcd().isMock()) {
      log.info("Mocking etcdConfigurationManager");
      return new MockEtcdConfigurationManager(null, 0);
    } else {
      final var composite = new EtcdClientBuilderConfigurerComposite();
      composite.addConfigurers(etcdConfigurerWrappers);
      final var builder = Client.builder();
      composite.configure(builder);
      return new EtcdConfigurationManager(builder);
    }
  }

  @Bean
  @SneakyThrows
  public EtcdClientBuilderConfigurerWrapper<EtcdMarker> etcdSslConfigurer(
      final Optional<List<SslContextBuilderConfigurerWrapper<EtcdMarker>>>
          maybeSslConfigurerWrappers
  ) {
    final var sslConfigurerWrappers = maybeSslConfigurerWrappers.orElse(null);
    if (sslConfigurerWrappers == null) {
      log.warn("Found no beans of type {}<{}>",
          SslContextBuilderConfigurerWrapper.class.getSimpleName(),
          EtcdMarker.class.getSimpleName());
      return null;
    }
    log.info("Using SSL configurers to configure Etcd SslContext: {}", sslConfigurerWrappers);
    final var composite = new SslContextBuilderConfigurerComposite();
    composite.addConfigurers(sslConfigurerWrappers);
    final var sslContextBuilder = GrpcSslContexts.forClient();
    composite.configure(sslContextBuilder);
    final var context = sslContextBuilder.build();
    return new EtcdClientBuilderConfigurerWrapper<>(
        clientBuilder -> clientBuilder.sslContext(context));
  }

  @Bean
  public EtcdClientBuilderConfigurerWrapper<EtcdMarker> etcdConfigurer() {
    return new EtcdClientBuilderConfigurerWrapper<>(
        new DefaultEtcdClientBuilderConfigurer(standInProperties.getEtcd()));
  }

  @Bean
  public SslContextBuilderConfigurerWrapper<EtcdMarker> keyStoreConfigurer() {
    log.info("Initializing KeyStore SSL configurer");
    final var sslProps = standInProperties.getEtcd().getKeyStore();
    if (sslProps == null) {
      log.warn(
          "KeyStore SSL configurer initialization skipped because settings were not specified");
      return null;
    }
    return new SslContextBuilderConfigurerWrapper<>(
        new KeyStoreSslContextBuilderConfigurer(sslProps));
  }

  @Bean
  public AbstractCachedResolver changeSourceResolver(IConfigurationManagerPrivate configManager) {
    WatcherChangeSourceResolver watcherChangeSourceResolver = new WatcherChangeSourceResolver(
        new DistributedChangeSourceResolver(
            standInProperties.getOwner(),
            configManager));
    watcherChangeSourceResolver.init();
    return watcherChangeSourceResolver;
  }

  @Bean("emergencyFailureHandler")
  public EmergencyFailureHandler emergencyFailureHandler(
      AbstractCachedResolver changeSourceResolver,
      @Qualifier("customReplicationPropertiesProvider")
      CustomReplicationPropertiesProvider customReplicationPropertiesProvider) {
    return new CustomEmergencyFailureHandler(changeSourceResolver,
        customReplicationPropertiesProvider,
        standInProperties.getMaxReplicationErrors(),
        standInProperties.getErrorPeriodInSeconds());
  }

  @Bean("customReplicationPropertiesProvider")
  public CustomReplicationPropertiesProvider customReplicationPropertiesProvider(
      @Qualifier("emergencyReactiveTransactionManager")
      ReactiveTransactionManager reactiveTransactionManager,
      @Qualifier("emergencyDatabaseClient") DatabaseClient emergencyDatabaseClient) {
    return new CustomReplicationPropertiesProviderImpl(standInProperties,
        reactiveTransactionManager, emergencyDatabaseClient, objectMapper);
  }

  @Bean("smartReplicationKafka")
  public KafkaProducerConfig producerConfig() {
    final KafkaProducerConfig producerConfig = new KafkaProducerConfig(
        standInProperties.getKafka().getBootstrapServers());
    if (standInProperties.getKafka().getSecurity().isEnable()) {
      Map<String, String> map = producerConfig.getSslConfiguration();
      map.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStoreLocation());
      map.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStorePassword());
      map.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStoreType());
      map.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyStoreLocation());
      map.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyPassword());
      map.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyStoreType());
      map.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyPassword());
      map.put(SslConfigs.SSL_PROTOCOL_CONFIG, "TLSv1.3");
      map.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG,
          standInProperties.getKafka().getSecurity().getProtocol());
    }
    return new KafkaProducerConfig(producerConfig);
  }

  @Bean
  public KafkaReactiveMessageSender kafkaMessageSender(
      @Qualifier("smartReplicationKafka") KafkaProducerConfig producerConfig,
      @Qualifier("emergencyFailureHandler") final EmergencyFailureHandler emergencyFailureHandler) {
    final var resolver = new OwnerKafkaProducerTopicResolver();
    return new KafkaReactiveMessageSender(producerConfig,
        () -> standInProperties.getOwner(),
        //new ISO8601ObjectMapperFactory(),
        new StandInObjectMapper(),
        getChangeCompressor(),
        resolver,
        emergencyFailureHandler
    );
  }

  @Bean("proxyConnectionFactory")
  public ConnectionFactory proxyConnectionFactory(
      ConnectionFactory smartReplicationConnectionFactory,
      AbstractCachedResolver changeSourceResolver,
      IEventHandler eventHandler,
      EmergencyFailureHandler<Change> emergencyFailureHandler,
      AdapterConfig adapterConfig,
      ProxyConfig proxyConfig,
      IInterceptFactory interceptFactory) {
    try {
      changeSourceResolver.init();
    } catch (Exception e) {
      emergencyFailureHandler.handleException(ReplicationFailureType.ETCD_INITIALIZATION_ERROR,
          new SmartReplicationException(e.getLocalizedMessage(), e));
    }

    return ProxyConnectionFactory.builder(smartReplicationConnectionFactory, proxyConfig)
        .listener(new SyncR2dbcInterceptor(
            smartReplicationConnectionFactory,
            interceptFactory,
            eventHandler,
            adapterConfig,
            changeSourceResolver
        ))
        .build();
  }

  @Bean
  IInterceptFactory interceptFactory() {
    return new InterceptFactory();
  }

  @Bean
  public ProxyConfig proxyConfig(AdapterConfig adapterConfig,
      EmergencyFailureHandler<Change> emergencyFailureHandler,
      IInterceptFactory interceptFactory) {
    ProxyConfig proxyConfig = new ProxyConfig();
    proxyConfig.setProxyFactoryFactory(
        interceptFactory.createProxyFactoryFactory(adapterConfig, emergencyFailureHandler));
    return proxyConfig;
  }


  @Bean
  public IEventHandler<Change> eventHandler(KafkaReactiveMessageSender kafkaMessageSender) {
    return new StreamingHandler<>(kafkaMessageSender);
  }

  @Bean
  public IR2dbcDatabaseCrawler r2dbcDatabaseCrawler(
      ConnectionFactory smartReplicationConnectionFactory) {
    return new R2dbcDatabaseCrawler(smartReplicationConnectionFactory).metadata();
  }


  @Bean
  public AdapterConfig adapterConfig() {
    return new AdapterConfig(true)
        .subo(standInProperties::getOwner)
        .key(() -> Optional.ofNullable(MDC.get(MDCKeySupplier.UNIQUE_KEY)).orElse(null))
        .customProperties(new MDCPropertiesSupplier())
        .provider(ProviderType.SMART_REPLICATION)
        .changeFormatType(ChangeFormatType.ENTITY) // в ResultSet для потребителя передаются
        .skipQueryPredicate(new SkipQueriesPredicate())
        .customProperties(() -> Map.of(DB, DB_ALIAS))
        .skipTablePredicate(new SkipTablePredicate<>(Set.of(
            "standin_params",
            "databasechangeloglock",
            "databasechangelog",
            "flyway_schema_history")))
        .useContextConnection();
  }

  @Bean("databaseClient")
  @Primary
  public DatabaseClient databaseClient(
      @Qualifier("proxyConnectionFactory") ConnectionFactory proxyConnectionFactory) {
    return DatabaseClient.builder()
        .connectionFactory(proxyConnectionFactory)
        .namedParameters(true)
        .build();
  }

  @Bean("reactiveTransactionManager")
  @Primary
  public ReactiveTransactionManager reactiveTransactionManager(
      @Qualifier("proxyConnectionFactory") ConnectionFactory proxyConnectionFactory) {
    return new R2dbcTransactionManager(proxyConnectionFactory);
  }

  @Bean("transactionalOperator")
  public TransactionalOperator transactionalOperator(
      @Qualifier("reactiveTransactionManager")
      ReactiveTransactionManager reactiveTransactionManager) {
    return TransactionalOperator.create(reactiveTransactionManager);
  }

  @Bean
  public R2dbcEntityTemplate r2dbcEntityTemplate(DatabaseClient databaseClient) {
    return new R2dbcEntityTemplate(databaseClient, PostgresDialect.INSTANCE);
  }

  private ChangeSource getStandInDefaultChangeSource() {
    try {
      return ChangeSource.valueOf(standInProperties.getDefaultChangeSource());
    } catch (Exception e) {
      return ChangeSource.MAIN;
    }
  }

  private IChangeCompressor getChangeCompressor() {
    if ((Objects.nonNull(standInProperties.getCompressType()))
        && (Objects.nonNull(standInProperties.getMinBytesToCompress()))) {
      return new ChangeCompressor(CompressType.valueOf(standInProperties.getCompressType()),
          new JsonConverter(new StandInObjectMapper()), standInProperties.getMinBytesToCompress());
    } else {
      return new ChangeCompressor(new JsonConverter(new StandInObjectMapper()));
    }
  }

  @Bean("emergencyReactiveTransactionManager")
  public ReactiveTransactionManager emergencyReactiveTransactionManager(
      @Qualifier("mainConnectionFactory") ConnectionFactory mainConnectionFactory,
      @Qualifier("standinConnectionFactory") ConnectionFactory standinConnectionFactory) {
    final var changeSource = getStandInDefaultChangeSource();
    switch (changeSource) {
      case MAIN:
        return new R2dbcTransactionManager(mainConnectionFactory);
      case STAND_IN:
        return new R2dbcTransactionManager(standinConnectionFactory);
      default:
        throw new SmartReplicationException("Unsupported emergencyTransactionManager type");
    }
  }

  @Bean("emergencyDatabaseClient")
  public DatabaseClient emergencyDatabaseClient(
      @Qualifier("mainConnectionFactory") ConnectionFactory mainConnectionFactory,
      @Qualifier("standinConnectionFactory") ConnectionFactory standinConnectionFactory) {

    final var changeSource = getStandInDefaultChangeSource();
    switch (changeSource) {
      case MAIN:
        return DatabaseClient.builder()
            .connectionFactory(mainConnectionFactory)
            .namedParameters(true)
            .build();
      case STAND_IN:
        return DatabaseClient.builder()
            .connectionFactory(standinConnectionFactory)
            .namedParameters(true)
            .build();
      default:
        throw new SmartReplicationException("Unsupported emergencyTransactionManager type");
    }

  }

}

