package ru.vtb.tsp.ia.epay.fiscalization.configs;

import static ru.vtb.tsp.ia.epay.merchant.MerchantApiClientImpl.MERCHANT_REST_TEMPLATE;
import static ru.vtb.tsp.ia.epay.merchant.MerchantApiClientImpl.MERCHANT_SITE_REST_TEMPLATE;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.flywaydb.core.Flyway;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;
import org.springframework.core.env.Environment;
import org.springframework.data.r2dbc.repository.config.EnableR2dbcRepositories;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.FirstOfdApi;

@Slf4j
@Configuration
@EnableFeignClients(basePackages = {
    "ru.vtb.tsp.ia.epay.fiscalization",
    "ru.vtb.tsp.ia.epay.apilistener" })
@EnableKafka
@EnableScheduling
@EnableCaching
@AllArgsConstructor
@EnableR2dbcRepositories
@EnableTransactionManagement
@ComponentScan(
    basePackages = {
        //"ru.vtb.tsp.ia.epay.core.configurations",
        "ru.vtb.tsp.ia.epay.merchant",
        "ru.vtb.tsp.ia.epay.apilistener.impl",
        "ru.vtb.tsp.ia.epay.fiscalization" },
    excludeFilters = {
        @ComponentScan.Filter(type = FilterType.REGEX,
            pattern = "ru.vtb.tsp.ia.epay.core.services"),
        @ComponentScan.Filter(type = FilterType.REGEX,
            pattern = "ru.vtb.tsp.ia.epay.core.repositories")
    })
public class AppConfig {

  public static final int TIMEOUT = 5000;
  private final Environment env;

  @Bean
  @Qualifier(MERCHANT_REST_TEMPLATE)
  public RestTemplate merchantRestTemplate() {
    final var factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(TIMEOUT);
    factory.setReadTimeout(TIMEOUT);
    return new RestTemplate(factory);
  }

  @Bean
  @Qualifier(MERCHANT_SITE_REST_TEMPLATE)
  public RestTemplate merchantSiteRestTemplate() {
    final var factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(TIMEOUT);
    factory.setReadTimeout(TIMEOUT);
    return new RestTemplate(factory);
  }

  @Bean(initMethod = "migrate")
  public Flyway flyway() {
    return new Flyway(Flyway.configure()
        .baselineOnMigrate(true)
        .dataSource(
            env.getRequiredProperty("spring.flyway.url"),
            env.getRequiredProperty("spring.flyway.user"),
            env.getRequiredProperty("spring.flyway.password"))
    );
  }

  @Bean
  public CacheManager cacheManager() {
    return new ConcurrentMapCacheManager(FirstOfdApi.OFD_TOKEN_CACHE_NAME);
  }

  @Bean
  public ObjectMapper objectMapper() {
    final var objectMapperBuilder = JsonMapper.builder();
    objectMapperBuilder.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapperBuilder.enable(SerializationFeature.INDENT_OUTPUT);
    objectMapperBuilder.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
    objectMapperBuilder.enable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    objectMapperBuilder.enable(JsonParser.Feature.ALLOW_COMMENTS);
    objectMapperBuilder.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapperBuilder.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    objectMapperBuilder.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    final var objectMapper = objectMapperBuilder.build();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper;
  }

  @Bean
  public ObjectMapper merchantClientMapper() {
    final var objectMapperBuilder = JsonMapper.builder();
    objectMapperBuilder.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapperBuilder.enable(SerializationFeature.INDENT_OUTPUT);
    objectMapperBuilder.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
    objectMapperBuilder.enable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    objectMapperBuilder.enable(JsonParser.Feature.ALLOW_COMMENTS);
    objectMapperBuilder.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapperBuilder.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    objectMapperBuilder.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    final var objectMapper = objectMapperBuilder.build();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper;
  }

}