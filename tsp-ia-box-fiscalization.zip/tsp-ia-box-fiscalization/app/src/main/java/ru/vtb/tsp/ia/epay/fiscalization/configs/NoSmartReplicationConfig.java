package ru.vtb.tsp.ia.epay.fiscalization.configs;

import static io.r2dbc.spi.ConnectionFactoryOptions.PASSWORD;
import static io.r2dbc.spi.ConnectionFactoryOptions.USER;

import io.r2dbc.spi.ConnectionFactories;
import io.r2dbc.spi.ConnectionFactory;
import io.r2dbc.spi.ConnectionFactoryOptions;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.r2dbc.R2dbcProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.r2dbc.core.R2dbcEntityTemplate;
import org.springframework.data.r2dbc.dialect.PostgresDialect;
import org.springframework.r2dbc.connection.R2dbcTransactionManager;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;


@Configuration
@ConditionalOnProperty(prefix = "smart-replication", name = "enable", havingValue = "false")
@Slf4j
@RequiredArgsConstructor
public class NoSmartReplicationConfig {

  @Bean("mainR2dbcProperties")
  @ConfigurationProperties("spring.r2dbc.main")
  public R2dbcProperties mainR2dbcProperties() {
    return new R2dbcProperties();
  }

  @Bean("mainConnectionFactory")
  public ConnectionFactory mainConnectionFactory(
      @Qualifier("mainR2dbcProperties") R2dbcProperties mainR2dbcProperties) {
    return ConnectionFactories.get(ConnectionFactoryOptions.parse(mainR2dbcProperties.getUrl())
        .mutate()
        .option(USER, mainR2dbcProperties.getUsername())
        .option(PASSWORD, mainR2dbcProperties.getPassword())
        .build());
  }

  @Bean("databaseClient")
  public DatabaseClient databaseClient(
      @Qualifier("mainConnectionFactory") ConnectionFactory proxyConnectionFactory) {
    return DatabaseClient.builder()
        .connectionFactory(proxyConnectionFactory)
        .namedParameters(true)
        .build();
  }

  @Bean("reactiveTransactionManager")
  public ReactiveTransactionManager reactiveTransactionManager(
      @Qualifier("mainConnectionFactory") ConnectionFactory proxyConnectionFactory) {
    return new R2dbcTransactionManager(proxyConnectionFactory);
  }

  @Bean("transactionalOperator")
  public TransactionalOperator transactionalOperator(
      @Qualifier("reactiveTransactionManager")
      ReactiveTransactionManager reactiveTransactionManager) {
    return TransactionalOperator.create(reactiveTransactionManager);
  }

  @Bean
  public R2dbcEntityTemplate r2dbcEntityTemplate(
      @Qualifier("databaseClient") DatabaseClient databaseClient) {
    return new R2dbcEntityTemplate(databaseClient, PostgresDialect.INSTANCE);
  }

}
