package ru.vtb.tsp.ia.epay.fiscalization.mappers;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Named;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ItemDto;

@Mapper(componentModel = "spring", uses = ItemMapper.class)
public interface ListItemMapper {

  @Named("listItems")
  List<ItemDto> toItemDtoList(List<BundleDto> bundleDtoList);

}
