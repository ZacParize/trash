package ru.vtb.tsp.ia.epay.fiscalization.service;

import java.util.Optional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.merchant.implementations.MerchantSiteClientImpl;
import ru.vtb.tsp.ia.epay.merchant.sites.MerchantSiteControllerApi;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFiscalParamsDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

@Slf4j
@Service
public class MerchantSiteServiceFacade {

  private final MerchantSiteControllerApi merchantSiteClient;

  public MerchantSiteServiceFacade(
      @Value("${merchant-api.url}") String host,
      @Qualifier(value = "merchantSiteRestTemplate") RestTemplate merchantSiteRestTemplate) {
    this.merchantSiteClient = new MerchantSiteClientImpl(merchantSiteRestTemplate, host);
  }

  public MerchantSiteFiscalParamsDto getFiscalParams(String mstId) {
    log.info("Get fiscal params from Merchant Api service");
    return Optional.ofNullable(merchantSiteClient.get(mstId).getBody())
        .map(MerchantSiteDto::getParams)
        .map(MerchantSiteParamsDto::getFiscalParams)
        .orElse(null);
  }

}
