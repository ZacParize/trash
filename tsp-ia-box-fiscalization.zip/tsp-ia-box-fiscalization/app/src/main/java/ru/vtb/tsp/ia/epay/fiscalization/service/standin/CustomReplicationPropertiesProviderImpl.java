package ru.vtb.tsp.ia.epay.fiscalization.service.standin;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.r2dbc.core.DatabaseClient;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.transaction.ReactiveTransactionManager;
import org.springframework.transaction.reactive.TransactionalOperator;
import reactor.core.publisher.Mono;
import ru.vtb.smartreplication.client.producer.handler.CustomReplicationPropertiesProvider;
import ru.vtb.smartreplication.model.ChangeSource;
import ru.vtb.tsp.ia.epay.core.domains.enums.StandInVariables;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParamValue;
import ru.vtb.tsp.ia.epay.fiscalization.configs.standin.StandInProperties;


@Slf4j
public class CustomReplicationPropertiesProviderImpl implements
    CustomReplicationPropertiesProvider {

  private static final String QUERY_INSERT = "insert into standin_params (key, data, created_at, "
      + "modified_at) values "
      + "($1, to_jsonb($2::jsonb), "
      + "to_timestamp(cast($3 as text),'YYYY-MM-DD HH24:MI:SS'), "
      + "to_timestamp(cast($4 as text),'YYYY-MM-DD HH24:MI:SS')) "
      + "on conflict (key) do update "
      + "set data = to_jsonb($2::jsonb), "
      + "modified_at = to_timestamp(cast($4 as text),'YYYY-MM-DD HH24:MI:SS')";
  private static final String QUERY_SELECT = "select * from standin_params where key=$1";
  private static final Map<String, Boolean> cache = new ConcurrentHashMap<>();
  private static final String KEY = "REPLICATION_ENABLED";
  private final ReactiveTransactionManager reactiveTransactionManager;
  private final StandInProperties standInProperties;

  private final DatabaseClient databaseClient;
  private final ObjectMapper objectMapper;

  public CustomReplicationPropertiesProviderImpl(
      StandInProperties standInProperties,
      ReactiveTransactionManager reactiveTransactionManager,
      DatabaseClient databaseClient,
      ObjectMapper objectMapper) {
    this.standInProperties = standInProperties;
    this.reactiveTransactionManager = reactiveTransactionManager;
    this.databaseClient = databaseClient;
    this.objectMapper = objectMapper;
  }


  @Override
  @PostConstruct
  public boolean isReplicationEnabled() {
    if (!cache.containsKey(KEY)) {
      getEmergencyFlag();
    }
    return cache.get(KEY);
  }

  @Override
  public void setReplicationEnabled(boolean isReplicationEnabled) {
    log.info("Setting replication enabled flag to {}", isReplicationEnabled);
    TransactionalOperator transactionalOperator =
        TransactionalOperator.create(reactiveTransactionManager);
    transactionalOperator.execute(status ->
        insert(isReplicationEnabled).then()).subscribe();
    cache.put(KEY, isReplicationEnabled);
  }

  private Mono<Void> insert(boolean isReplicationEnabled) {
    try {
      return databaseClient.sql(QUERY_INSERT)
          .bind("$1", StandInVariables.SMART_REPLICATION_ENABLED.name())
          .bind("$2", objectMapper.writeValueAsString(Map.of("value", isReplicationEnabled)))
          .bind("$3", LocalDateTime.now(ZoneOffset.UTC))
          .bind("$4", LocalDateTime.now(ZoneOffset.UTC)).fetch().rowsUpdated().then();
    } catch (JsonProcessingException e) {
      log.error("Failed to serialize standIn params", e);
      throw new RuntimeException(e);
    }
  }


  @Override
  public ChangeSource getDefaultChangeSource() {
    return getStandInDefaultChangeSource();
  }

  private ChangeSource getStandInDefaultChangeSource() {
    try {
      return ChangeSource.valueOf(standInProperties.getDefaultChangeSource());
    } catch (Exception e) {
      return ChangeSource.MAIN;
    }
  }

  private Mono<String> fetchById() {
    return databaseClient.sql(QUERY_SELECT)
        .bind("$1", StandInVariables.SMART_REPLICATION_ENABLED.name())
        .map(row -> row.get("data", String.class))
        .one();
  }

  @Scheduled(cron = "0/10 * * * * ?")
  public boolean getEmergencyFlag() {
    Boolean result = true;
    try {
      final var object = objectMapper.readValue(fetchById().block(), StandInParamValue.class);
      result = Optional.of(Boolean.parseBoolean(object.getValue().toString()))
          .orElse(true);
    } finally {
      cache.put(KEY, result);
      return result;
    }
  }
}
