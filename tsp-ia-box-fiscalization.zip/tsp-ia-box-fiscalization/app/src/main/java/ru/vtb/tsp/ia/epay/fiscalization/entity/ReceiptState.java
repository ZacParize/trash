package ru.vtb.tsp.ia.epay.fiscalization.entity;

public enum ReceiptState {

 NEW, REGISTERED, PRINTED, REGISTRATION_ERROR, PRINT_ERROR

}