package ru.vtb.tsp.ia.epay.fiscalization.entity;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDateTime;
import java.util.UUID;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;

@Data
@Builder
@AllArgsConstructor
@Table(Receipt.TABLE_NAME)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Receipt {

  public static final String TABLE_NAME = "receipts";

  @Id
  @Column("id")
  @JsonProperty("id")
  private UUID id;

  @NotNull
  @Column("operator")
  @JsonProperty("operator")
  private ReceiptOperator operator;

  @NotNull
  @Column("type")
  @JsonProperty("type")
  private ReceiptType type;

  @NotNull
  @Column("state")
  @JsonProperty("state")
  private ReceiptState state;

  @NotNull
  @Column("external_id")
  @JsonProperty("externalId")
  private UUID externalId;

  @NotNull
  @Column("document_id")
  @JsonProperty("documentId")
  private UUID documentId;

  @NotEmpty
  @Column("url")
  @JsonProperty("url")
  private String url;

  @NotNull
  @Column("transaction_code")
  @JsonProperty("transactionCode")
  private UUID transactionCode;

  @NotNull
  @Column("creation_data")
  @JsonProperty("creationData")
  private String creationData;

  @NotNull
  @Column("status_data")
  @JsonProperty("statusData")
  private String statusData;

  @NotNull
  @Column("created_at")
  @JsonProperty("createdAt")
  private LocalDateTime createdAt;

  @NotNull
  @Column("changed_at")
  @JsonProperty("changedAt")
  private LocalDateTime changedAt;

  @Version
  @Builder.Default
  private int version = 0;

}