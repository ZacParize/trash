package ru.vtb.tsp.ia.epay.fiscalization.configs.converters;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.postgresql.jdbc.PgArray;
import ru.vtb.smartreplication.core.kafka.IObjectMapperFactory;

public class StandInObjectMapper implements IObjectMapperFactory {

  @Override
  public ObjectMapper create() {
    final var objectMapperBuilder = JsonMapper.builder();
    objectMapperBuilder.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapperBuilder.enable(SerializationFeature.INDENT_OUTPUT);
    objectMapperBuilder.enable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    objectMapperBuilder.enable(JsonParser.Feature.ALLOW_COMMENTS);
    objectMapperBuilder.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapperBuilder.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    objectMapperBuilder.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    final var objectMapper = objectMapperBuilder.build();
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.registerModule(getSimpleModule(PgArray.class, new PgArraySerializer()));
    objectMapper.registerModule(
        getSimpleModule(java.sql.Timestamp.class, new PgTimeStampSerializer()));
    return objectMapper;
  }

  private SimpleModule getSimpleModule(Class z, JsonSerializer jsonSerializer) {
    final var module = new SimpleModule();
    module.addSerializer(z, jsonSerializer);
    return module;
  }
}
