package ru.vtb.tsp.ia.epay.fiscalization.entity;

public enum ReceiptType {

  INCOME, INCOME_RETURN

}