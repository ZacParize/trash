package ru.vtb.tsp.ia.epay.fiscalization.service;

import static ru.vtb.tsp.ia.epay.fiscalization.configs.KafkaProducerConfig.KAFKA_BOX_TEMPLATE;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Slf4j
@Service
public class KafkaService {

  private final KafkaTemplate<String, Object> kafkaBoxTemplate;
  private final List<String> dlqTopics;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForDlq;

  public KafkaService(@Qualifier(KAFKA_BOX_TEMPLATE) KafkaTemplate<String, Object> kafkaBoxTemplate,
      @Value("${app.kafka.dlq-topics}") @NotEmpty List<String> dlqTopics) {
    this.kafkaBoxTemplate = kafkaBoxTemplate;
    this.dlqTopics = Objects.requireNonNullElse(dlqTopics, Collections.emptyList());
    this.callbackFactoryForDlq = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Message {} is sent to dlq with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending message {} to portal {}", key, topic, ex);
      }
    };
  }

  public void sendToDlq(@Nullable Object message) {
    Optional.ofNullable(message)
        .ifPresent(tx -> send(dlqTopics, message, message.toString()));
  }

  private void send(@Nullable List<String> outputTopics,
      @Nullable Object payload,
      @Nullable String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final KafkaTemplate<String, Object> kafkaTemplate;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    topics = outputTopics;
    kafkaTemplate = kafkaBoxTemplate;
    callback = callbackFactoryForDlq;
    Objects.requireNonNull(topics).forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
          .addCallback(callback.apply(topic, key));
    });
  }

}