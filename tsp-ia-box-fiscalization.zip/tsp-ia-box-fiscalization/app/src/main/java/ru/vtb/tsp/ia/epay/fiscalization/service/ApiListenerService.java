package ru.vtb.tsp.ia.epay.fiscalization.service;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class ApiListenerService {

  //todo implement real bundle client
  public List<BundleDto> getByOrderId(String orderCode) {
    return null;
  }

}
