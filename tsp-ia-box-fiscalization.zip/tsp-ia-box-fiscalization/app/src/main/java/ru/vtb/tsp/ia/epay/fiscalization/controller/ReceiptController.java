package ru.vtb.tsp.ia.epay.fiscalization.controller;

import java.time.LocalDateTime;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.RequestMetadataDto;
import ru.vtb.tsp.ia.epay.fiscalization.entity.Receipt;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptOperator;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptState;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptType;
import ru.vtb.tsp.ia.epay.fiscalization.service.ReceiptService;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class ReceiptController {

  private final ReceiptService receiptService;

  @GetMapping("/test")
  public @NotNull Mono<ResponseEntity<Receipt>> getDocumentStatus(
      @Header("Authorization") String mstId,
      @RequestParam("requestId") String requestId) {
    return receiptService.save(Receipt.builder().id(UUID.fromString(requestId))
            .documentId(UUID.fromString(requestId))
            .operator(ReceiptOperator.OFD_1)
            .state(ReceiptState.NEW)
            .type(ReceiptType.INCOME)
            .externalId(UUID.fromString(requestId))
            .url("ajshdbsajhbd")
            .transactionCode(UUID.fromString(requestId))
            .createdAt(LocalDateTime.now())
            .changedAt(LocalDateTime.now())
            .build())
        .map(ResponseEntity::ok)
        .defaultIfEmpty(ResponseEntity.notFound().build());
  }

  @PostMapping()
  public @NotNull ResponseEntity<ResponseEntity<Receipt>> addReceiptToPrintQueue(
      @RequestBody @Valid RequestMetadataDto requestMetadataDto) {
    return null;
  }
}
