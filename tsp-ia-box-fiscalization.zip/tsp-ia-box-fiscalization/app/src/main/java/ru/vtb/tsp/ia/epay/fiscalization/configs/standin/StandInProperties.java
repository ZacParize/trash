package ru.vtb.tsp.ia.epay.fiscalization.configs.standin;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import ru.vtb.smartreplication.configuration.KafkaConfigurationProperties;

@Configuration
@ConfigurationProperties("smart-replication")
@Data
public class StandInProperties {

  private KafkaConfigurationProperties kafka;
  private String owner;
  private String defaultChangeSource;
  private int maxReplicationErrors;
  private int errorPeriodInSeconds;
  private EtcdProperties etcd;
  private String compressType;
  private Integer minBytesToCompress;
}
