package ru.vtb.tsp.ia.epay.fiscalization.mappers;

import java.math.BigDecimal;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.core.domains.kafka.payloads.FiscalizationTask;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFiscalParamsDto;

@Mapper(componentModel = "spring", uses = ListItemMapper.class)
public interface DocumentMapper {

  @Mapping(target = "operationType", source = "task.operationType")
  @Mapping(target = "taxationType",
      source = "merchantSiteFiscalParamsDto.defaultSettings.taxSystem")
  @Mapping(target = "items", source = "bundleDtoList", qualifiedByName = "listItems")
  @Mapping(target = "totalSum.ecashTotalSum", source = "ecashTotalSum")
  @Mapping(target = "retailAddress", source = "merchantSiteFiscalParamsDto.url")
  @Mapping(target = "sendCheckTo",
      expression = "java((task.getEmail() != null && !task.getEmail().isEmpty())"
          + " ? task.getEmail() : merchantSiteFiscalParamsDto.getEmail())")
  @Mapping(target = "cashier", ignore = true)
  @Mapping(target = "cashierInn", ignore = true)
  @Mapping(target = "retailPlace", ignore = true)
  @Mapping(target = "buyer", ignore = true)
  @Mapping(target = "industryProp", ignore = true)
  @Mapping(target = "operationalProp", ignore = true)
  @Mapping(target = "mode", ignore = true)
  @Mapping(target = "optionalReceiptProp", ignore = true)
  @Mapping(target = "customProperty", ignore = true)
  DocumentDto toDocumentDtoMapper(MerchantSiteFiscalParamsDto merchantSiteFiscalParamsDto,
      FiscalizationTask task, BigDecimal ecashTotalSum, List<BundleDto> bundleDtoList);

}
