package ru.vtb.tsp.ia.epay.fiscalization;

import feign.form.ContentType;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.concurrent.ConcurrentTaskScheduler;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.FirstOfdApi;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.DocumentStatus;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentStatusRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ReceiptPrintRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.TokenRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.EpaTokenResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptPrintResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.TokenResponseDto;

@Slf4j
@Component
public class FirstOfdClientImpl {

  private static final String X_PARTNER_AUTHORIZATION = "X-Partner-Authorization";

  private final FirstOfdClient firstOfdClient;
  private final CacheManager cacheManager;
  private final TaskScheduler taskScheduler;
  private final String clientId;
  private final String clientSecret;

  public FirstOfdClientImpl(FirstOfdClient firstOfdClient,
      CacheManager cacheManager,
      @Value("${epa.client-id}") String clientId,
      @Value("${epa.client-secret}") String clientSecret) {
    this.firstOfdClient = firstOfdClient;
    this.cacheManager = cacheManager;
    this.taskScheduler = new ConcurrentTaskScheduler();
    this.clientId = clientId;
    this.clientSecret = clientSecret;
  }

  private static String mask(String input, int maskSize) {
    if (input.length() <= maskSize) {
      return input;
    }
    final var buf = input.toCharArray();
    Arrays.fill(buf, 0, buf.length - maskSize, '*');
    return new String(buf);
  }

  @Cacheable(cacheNames = FirstOfdApi.OFD_TOKEN_CACHE_NAME, key = "{#login}")
  public ResponseEntity<TokenResponseDto> getOfdToken(String login, String password) {
    if (ObjectUtils.isEmpty(login) || ObjectUtils.isEmpty(password)) {
      return ResponseEntity.ok(null);
    }
    final var maskedPassword = mask(password, 4);
    log.info("Request to first ofd, getting token by login {}, password {}",
        login, maskedPassword);
    try {
      final var map = new LinkedMultiValueMap<String, String>();
      map.set(HttpHeaders.CONTENT_TYPE, "application/json");
      final var result = firstOfdClient
          .getOfdToken(HttpHeaders.readOnlyHttpHeaders(map),
              TokenRequestDto.builder().login(login).pass(password).build());
      log.info("Response from first ofd, getting token by login {}, password {}, response {}",
          login, maskedPassword, result);
      if (!result.getStatusCode().is2xxSuccessful()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result.getBody());
      }
      return result;
    } catch (Exception ex) {
      log.error("Error occurred during first ofd, getting token by login {}, password {}",
          login, maskedPassword, ex);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
    }
  }

  @Cacheable(cacheNames = FirstOfdApi.EPA_TOKEN_CACHE_NAME, key = "'constantKey'")
  public ResponseEntity<EpaTokenResponseDto> getEpaToken() {
    Cache cache = cacheManager.getCache(FirstOfdApi.EPA_TOKEN_CACHE_NAME);
    if (cache == null) {
      final var epaTokenHeaders = new LinkedMultiValueMap<String, String>();
      epaTokenHeaders.set(HttpHeaders.CONTENT_TYPE, ContentType.URLENCODED.name());
      @NotNull ResponseEntity<EpaTokenResponseDto> epaToken = firstOfdClient.getEpaToken(
          HttpHeaders.readOnlyHttpHeaders(epaTokenHeaders), clientId, clientSecret);
      long expired = System.currentTimeMillis()
          + Objects.requireNonNull(epaToken.getBody()).getExpiresIn();
      taskScheduler.schedule(this::epaTokensCache, Instant.ofEpochSecond(expired));
      return epaToken;
    } else {
      EpaTokenResponseDto epaTokenResponseDto = cache.get("'constantKey'",
          EpaTokenResponseDto.class);
      return ResponseEntity.ok(epaTokenResponseDto);
    }
  }

  public ResponseEntity<Void> getDocumentStatus(TokenResponseDto token,
      String requestId,
      LocalDateTime timestamp,
      DocumentStatus status,
      String transactionType,
      String details) {
    log.info("Request to first ofd, getting document status by requestId {}, timestamp {}, "
            + "status {}, transaction type {}, details {}",
        requestId, timestamp, status, transactionType, details);
    try {
      final var map = new LinkedMultiValueMap<String, String>();
      map.set(HttpHeaders.CONTENT_TYPE, "application/json");
      final var result = firstOfdClient.getDocumentStatus(
          HttpHeaders.readOnlyHttpHeaders(map),
          DocumentStatusRequestDto.builder()
              .requestId(requestId)
              .timestamp(timestamp)
              .status(status)
              .transactionType(transactionType)
              .details(details)
              .build());
      log.info("Response from first ofd, getting document status by requestId {}, timestamp {}, "
              + "status {}, transaction type {}, details {}, response {}",
          requestId, timestamp, status, transactionType, details, result);
      if (!result.getStatusCode().is2xxSuccessful()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
      }
      return result;
    } catch (Exception ex) {
      log.error("Error occurred during first ofd, getting document status by requestId {}, "
              + "timestamp {}, status {}, transaction type {}, details {}",
          requestId, timestamp, status, transactionType, details, ex);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
    }
  }

  public ResponseEntity<ReceiptPrintResponseDto> addReceiptToPrintQueue(TokenResponseDto token,
      EpaTokenResponseDto epaTokenResponseDto, ReceiptPrintRequestDto receiptPrintRequestDto) {
    log.info("Request to first ofd, add receipt to print queue, ofd token{}, epa token {}, "
        + "requestMetadataDto {}", token, epaTokenResponseDto, receiptPrintRequestDto);
    try {
      final var map = new LinkedMultiValueMap<String, String>();
      map.set(HttpHeaders.CONTENT_TYPE, "application/json");
      map.set(HttpHeaders.AUTHORIZATION, epaTokenResponseDto.getAccessToken());
      map.set(X_PARTNER_AUTHORIZATION, token.getToken());
      final var result = firstOfdClient.addReceiptToPrintQueue(
          HttpHeaders.readOnlyHttpHeaders(map), receiptPrintRequestDto);
      log.info("Request to first ofd, add receipt to print queue, ofd token{}, epa token {}, "
          + "requestMetadataDto {}", token, epaTokenResponseDto, receiptPrintRequestDto);
      if (!result.getStatusCode().is2xxSuccessful()) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
      }
      return result;
    } catch (Exception ex) {
      log.info("Request to first ofd, add receipt to print queue, ofd token{}, epa token {}, "
          + "requestMetadataDto {}", token, epaTokenResponseDto, receiptPrintRequestDto);
      return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
    }
  }

  @CacheEvict(value = FirstOfdApi.OFD_TOKEN_CACHE_NAME, allEntries = true)
  @Scheduled(fixedDelay = 60 * 60 * 24 * 1000)
  public void emptyTokensCache() {
    log.info("Emptying ofd tokens cache");
  }

  @CacheEvict(value = FirstOfdApi.EPA_TOKEN_CACHE_NAME, allEntries = true)
  public void epaTokensCache() {
    log.info("Emptying epa tokens cache");
  }
}