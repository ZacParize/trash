package ru.vtb.tsp.ia.epay.fiscalization;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.UUID;
import javax.validation.constraints.NotNull;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.FirstOfdApi;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.Status;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentStatusRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ReceiptPrintRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.TokenRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.EpaTokenResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.PayloadDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptPrintResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.TokenResponseDto;

@Component
@ConditionalOnProperty(name = "ofd.mock", havingValue = "true")
public class MockFirstOfdClient implements FirstOfdApi {

  private static final String TOKEN = "eyJhbGciOiJIUzUxMiJ9.eyJpZCI6IjM1IiwiaWF0IjoxNzAyNDY3NDE0L"
      + "CJleHAiOjE3MDI3MjY2MTR9.xw5NMqdFnQEX_gN6pOmAgnNH-6wov75d8a8NqG5RijyjkWPWIKx0wCnIkwSHXwvO"
      + "04HZNMFysmPGT0WMcNDF6A";

  @Override
  public @NotNull ResponseEntity<TokenResponseDto> getOfdToken(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody TokenRequestDto body) {
    return ResponseEntity.ok(TokenResponseDto.builder()
        .token(TOKEN)
        .timestamp(LocalDateTime.now(ZoneOffset.UTC))
        .build());
  }

  @Override
  public ResponseEntity<EpaTokenResponseDto> getEpaToken(HttpHeaders httpHeaders,
      String clientId, String clientSecret) {
    return ResponseEntity.ok(EpaTokenResponseDto.builder()
        .accessToken(TOKEN)
        .expiresIn(899)
        .tokenType("Bearer")
        .build());
  }

  @Override
  public @NotNull ResponseEntity<Void> getDocumentStatus(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody DocumentStatusRequestDto body) {
    return ResponseEntity.ok(null);
  }

  @Override
  public ResponseEntity<ReceiptPrintResponseDto> addReceiptToPrintQueue(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody ReceiptPrintRequestDto receiptPrintRequestDto) {
    return ResponseEntity.ok(ReceiptPrintResponseDto.builder()
        .details("details")
        .payload(PayloadDto.builder().build())
        .requestId(UUID.randomUUID())
        .status(Status.COMPLETED)
        .timestamp(LocalDateTime.now())
        .transactionType("payment")
        .build());
  }

}