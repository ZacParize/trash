package ru.vtb.tsp.ia.epay.fiscalization.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.vtb.tsp.ia.epay.core.domains.bundle.BundleDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ItemDto;

@Mapper(componentModel = "spring")
public interface ItemMapper {

  @Mapping(target = "label", source = "bundleDto.name")
  @Mapping(target = "price", source = "bundleDto.price")
  @Mapping(target = "quantity", source = "bundleDto.quantity")
  @Mapping(target = "vatCode", source = "bundleDto.taxParams.taxType")
  @Mapping(target = "amount", source = "bundleDto.taxParams.amount")
  @Mapping(target = "itemVatAmount", source = "bundleDto.taxParams.taxSum")
  @Mapping(target = "paymentType", source = "bundleDto.taxParams.paymentType")
  @Mapping(target = "paymentSubject", source = "bundleDto.taxParams.paymentSubject")
  @Mapping(target = "measurementUnit", source = "bundleDto.measure")
  @Mapping(target = "additionalPositionInfo", source = "bundleDto.taxParams.userData")
  @Mapping(target = "paymentSubjectType", source = "bundleDto.taxParams.paymentSubject")
  @Mapping(target = "industryProp", ignore = true)
  @Mapping(target = "excise", ignore = true)
  @Mapping(target = "originCountryCode", ignore = true)
  @Mapping(target = "customsDeclarationNumber", ignore = true)
  @Mapping(target = "agent", ignore = true)
  @Mapping(target = "provider", ignore = true)
  @Mapping(target = "markedItemCheck", ignore = true)
  ItemDto toItemDto(BundleDto bundleDto);

}
