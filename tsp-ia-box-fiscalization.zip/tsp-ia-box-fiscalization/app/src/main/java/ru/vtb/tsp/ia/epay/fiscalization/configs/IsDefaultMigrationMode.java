package ru.vtb.tsp.ia.epay.fiscalization.configs;

import java.util.Arrays;
import java.util.Optional;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class IsDefaultMigrationMode implements Condition {

  public static final String STANDIN = "standin";

  @Override
  public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
    return Optional.of(context.getEnvironment())
        .map(envs -> !Arrays.asList(envs.getActiveProfiles()).contains(STANDIN))
        .orElse(true);
  }
}
