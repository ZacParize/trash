package ru.vtb.tsp.ia.epay.fiscalization;

import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import ru.vtb.tsp.ia.epay.fiscalization.configs.IsDefaultMigrationMode;

@SpringBootApplication
@Slf4j
public class App implements CommandLineRunner {

  public static void main(String[] args) {
    SpringApplication.run(App.class, args);
  }

  @Autowired
  private ApplicationContext context;

  @Override
  public void run(String... args) {
    System.out.println(context);
    // TODO: print all settings
    if (Arrays.asList(context.getEnvironment().getActiveProfiles()).contains(
        IsDefaultMigrationMode.STANDIN)) {
      log.info("StandIn db service completed. Application shutting down");
      ((ConfigurableApplicationContext) context).close();
    }
  }

}