package ru.vtb.tsp.ia.epay.fiscalization.repository;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import org.slf4j.MDC;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import reactor.core.publisher.Mono;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.tsp.ia.epay.fiscalization.entity.Receipt;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptOperator;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptState;
import ru.vtb.tsp.ia.epay.fiscalization.entity.ReceiptType;

public interface ReceiptRepository extends ReactiveCrudRepository<Receipt, UUID> {

  String COMMON_SELECT =
      "select "
          + " r.id as id, "
          + " r.operator as operator, "
          + " r.type as type, "
          + " r.state as state, "
          + " r.external_id as external_id, "
          + " r.document_id as document_id, "
          + " r.url as url, "
          + " r.transaction_code as transaction_ref, "
          + " r.creation_data as creation_data, "
          + " r.status_data as status_data, "
          + " r.created_at as created_at, "
          + " r.changed_at as changed_at, "
          + " r.version as version "
          + "from " + Receipt.TABLE_NAME + " r ";

  @Override
  @Query(COMMON_SELECT + "where r.id = :id")
  Mono<Receipt> findById(@NotEmpty @Param("id") UUID id);

  @Query(COMMON_SELECT + "where r.external_id = :externalId")
  Mono<Receipt> findByExternalId(@NotEmpty @Param("externalId") UUID externalId);

  @Query("update " + Receipt.TABLE_NAME + " set "
      + "state = :state, "
      + "document_id = :documentId, "
      + "url = :url, "
      + "creation_data = :creationData, "
      + "status_data = :statusData, "
      + "changed_at = :changedAt, "
      + "version = (:version + 1) "
      + "where id = :id and receipts.version = :version RETURNING *")
  Mono<Receipt> update(@NotNull @Param("state") ReceiptState state,
      @Nullable @Param("documentId") UUID documentId,
      @NotBlank @Param("url") String url,
      @NotNull @Param("creationData") Object creationData,
      @NotNull @Param("statusData") Object statusData,
      @Nullable @Param("changedAt") LocalDateTime changedAt,
      @Param("version") int version);

  default Mono<Receipt> update(@Nullable Receipt receipt) {
    Objects.requireNonNull(receipt, "Receipt for update can't be null");
    Objects.requireNonNull(receipt.getState(), "Receipt state for update can't be null");
    Objects.requireNonNull(receipt.getDocumentId(),
        "Receipt document id for update can't be null");
    Objects.requireNonNull(receipt.getUrl(),
        "Receipt url for update can't be null");
    Objects.requireNonNull(receipt.getCreationData(),
        "Receipt creation data for update can't be null");
    Objects.requireNonNull(receipt.getStatusData(),
        "Receipt status data for update can't be null");
    MDC.put(MDCKeySupplier.UNIQUE_KEY, receipt.getId().toString());
    return update(receipt.getState(),
        receipt.getDocumentId(),
        receipt.getUrl(),
        receipt.getCreationData(),
        receipt.getStatusData(),
        LocalDateTime.now(ZoneOffset.UTC),
        receipt.getVersion());
  }

  @Query("insert into " + Receipt.TABLE_NAME
      + " (id, operator, type, state, external_id, document_id, url, transaction_code, "
      + "creation_data, status_data, created_at, changed_at, version) "
      + "values (:id, :operator, :type, :state, :externalId, :documentId, :url, "
      + ":transactionCode, cast(:creationData as jsonb), cast(:statusData as jsonb), "
      + ":createdAt, :changedAt, :version) "
      + "on conflict (id) do update set "
      + "type = :type, state = :state, changed_at = :changedAt, version = (:version + 1) "
      + "where " + Receipt.TABLE_NAME + ".id = :id")
  Mono<Receipt> saveOrUpdate(@NotNull @Param("id") UUID id,
      @NotNull @Param("operator") ReceiptOperator operator,
      @NotNull @Param("type") ReceiptType type,
      @NotNull @Param("state") ReceiptState state,
      @NotNull @Param("externalId") UUID externalId,
      @Nullable @Param("documentId") UUID documentId,
      @NotBlank @Param("url") String url,
      @NotNull @Param("transactionCode") UUID transactionCode,
      @Nullable @Param("creationData") String creationData,
      @Nullable @Param("statusData") String statusData,
      @Nullable @Param("createdAt") LocalDateTime createdAt,
      @Nullable @Param("changedAt") LocalDateTime changedAt,
      @Param("version") int version);

  default @NotNull Mono<Receipt> saveOrUpdate(@Nullable Receipt receipt) {
    Objects.requireNonNull(receipt, "Receipt can't be null");
    Objects.requireNonNull(receipt.getOperator(), "Receipt operator can't be null");
    Objects.requireNonNull(receipt.getType(), "Receipt type can't be null");
    Objects.requireNonNull(receipt.getState(), "Receipt state can't be null");
    Objects.requireNonNull(receipt.getExternalId(), "Receipt external id can't be null");
    Objects.requireNonNull(receipt.getUrl(), "Receipt url can't be null");
    Objects.requireNonNull(receipt.getTransactionCode(), "Receipt transaction code can't be null");

    final var id = Objects.requireNonNullElse(receipt.getId(), UUID.randomUUID());
    final var updatedAt = Objects.requireNonNullElse(receipt.getChangedAt(),
        LocalDateTime.now(ZoneOffset.UTC));
    MDC.put(MDCKeySupplier.UNIQUE_KEY, receipt.getId().toString());
    return saveOrUpdate(
        id,
        receipt.getOperator(),
        receipt.getType(),
        receipt.getState(),
        receipt.getExternalId(),
        receipt.getDocumentId(),
        receipt.getUrl(),
        receipt.getTransactionCode(),
        receipt.getCreationData(),
        receipt.getStatusData(),
        receipt.getCreatedAt(),
        updatedAt,
        receipt.getVersion());
  }


}