create table if not exists standin_params
(
    id          bigserial primary key,
    key         varchar(256) not null UNIQUE,
    data        jsonb        not null,
    created_at  timestamp    not null default now(),
    modified_at timestamp    not null default now()
);