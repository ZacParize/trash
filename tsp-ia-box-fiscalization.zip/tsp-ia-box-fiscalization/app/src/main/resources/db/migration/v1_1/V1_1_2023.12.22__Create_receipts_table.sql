CREATE TABLE IF NOT EXISTS receipts (
    id                  uuid primary key,
    operator            varchar(256) not null,
    type                varchar(256) not null,
    state               varchar(256) not null,
    external_id         uuid not null,
    document_id         uuid,
    url                 varchar(256),
    transaction_code    uuid not null,
    creation_data       jsonb,
    status_data         jsonb,
    created_at          timestamp not null default now(),
    changed_at          timestamp not null default now(),
    version             integer not null
);

CREATE INDEX IF NOT EXISTS receipts_transaction_code_idx ON receipts USING btree (transaction_code);
CREATE UNIQUE INDEX IF NOT EXISTS receipts_external_id_idx ON receipts USING btree (external_id);