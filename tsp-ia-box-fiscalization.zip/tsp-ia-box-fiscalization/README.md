Internet acquiring, box, receipt service

Installation instructions:

1) Clone environment project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-environment.git

2) Clone the project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-receipt.git

3) Launch environment:

   cd tsp-ia-box-environment/docker

   docker-compose stop && docker-compose up -d

4) Launch receipt service