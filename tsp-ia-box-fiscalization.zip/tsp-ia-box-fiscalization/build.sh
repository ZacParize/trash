#!/bin/bash
function ComponentBuild() {
  gradle clean -i build -xtest ${GRADLE_CLI_OPTIONS} -p "${1}"
}
"$@"