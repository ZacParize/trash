package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum PlannedStatus {

  ITEM_GOODS_SALE,

  MEASURED_GOODS_SALIN,

  ITEM_GOODS_BACK,

  PARTIAL_GOODS_BACK,

  UNCHANGED;

}
