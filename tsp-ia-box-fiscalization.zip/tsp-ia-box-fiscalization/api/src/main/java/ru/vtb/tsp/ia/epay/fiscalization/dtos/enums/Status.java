package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum Status {

  COMPLETED,

  ERROR;

}
