package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.enums.UnitsMeasure;
import ru.vtb.tsp.ia.epay.core.domains.enums.ProductType;
import ru.vtb.tsp.ia.epay.core.domains.enums.PaymentType;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.VatCode;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ItemDto {

  @Size(max = 255)
  private String label;

  private BigDecimal price;

  private BigDecimal quantity;

  private VatCode vatCode;

  private BigDecimal amount;

  private BigDecimal itemVatAmount;

  @Valid
  private IndustryPropDto industryProp;

  private PaymentType paymentType;

  private ProductType paymentSubject;

  private UnitsMeasure measurementUnit;

  private BigDecimal excise;

  @Size(max = 255)
  private String originCountryCode;

  @Size(max = 255)
  private String customsDeclarationNumber;

  @Valid
  private AgentDto agent;

  @Valid
  private ProviderDto provider;

  @Size(max = 255)
  private String additionalPositionInfo;

  @Valid
  private MarkedItemCheckDto markedItemCheck;

  private ProductType paymentSubjectType;

}
