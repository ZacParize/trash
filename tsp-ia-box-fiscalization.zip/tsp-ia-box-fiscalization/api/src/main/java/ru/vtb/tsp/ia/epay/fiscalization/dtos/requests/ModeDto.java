package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.DefaultReceiptPolicy;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ModeDto {

  private boolean bso;

  private boolean internet;

  private boolean encryption;

  private boolean pawshop;

  @JsonProperty("defaultCheckPolicy")
  private DefaultReceiptPolicy defaultReceiptPolicy;

}
