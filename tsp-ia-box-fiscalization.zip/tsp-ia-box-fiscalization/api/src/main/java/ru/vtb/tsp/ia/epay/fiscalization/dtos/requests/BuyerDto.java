package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.format.annotation.DateTimeFormat;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.IdentityDocumentType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class BuyerDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  @Size(max = 255)
  private String name;

  @Size(max = 255)
  private String address;

  @Size(max = 12)
  private String inn;

  private List<String> phones;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime dayOfBirth;

  @Size(max = 3)
  private String countryCode;

  private IdentityDocumentType identityDocumentType;

  @Size(max = 255)
  private String identityDocument;

  @Size(max = 255)
  private String email;
}
