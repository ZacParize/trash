package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum TaxationType {

  GENERAL,

  SIMPLE_INCOME,

  SIMPLE_INCOME_EXPENSE,

  IMPUTED_INCOME,

  AGRICULTURAL,

  PATENT;

}
