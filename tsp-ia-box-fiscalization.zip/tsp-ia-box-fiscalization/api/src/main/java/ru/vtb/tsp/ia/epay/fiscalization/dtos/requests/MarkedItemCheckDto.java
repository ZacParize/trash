package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.ReceiptPolicy;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.PlannedStatus;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarkedItemCheckDto {

  @Valid
  private FractionDto fraction;

  private PlannedStatus plannedStatus;

  @Size(max = 255)
  private String markCode;

  private ReceiptPolicy receiptPolicy;

}
