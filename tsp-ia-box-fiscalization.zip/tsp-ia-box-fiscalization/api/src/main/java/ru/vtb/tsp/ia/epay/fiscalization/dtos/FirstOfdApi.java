package ru.vtb.tsp.ia.epay.fiscalization.dtos;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.DocumentStatusRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.ReceiptPrintRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.RequestMetadataDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.requests.TokenRequestDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.EpaTokenResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.ReceiptPrintResponseDto;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.responses.TokenResponseDto;

public interface FirstOfdApi {

  String OFD_TOKEN_CACHE_NAME = "ofd.token";
  String EPA_TOKEN_CACHE_NAME = "epa.token";

  /**
   * Запрос на получение токена ОФД
   */
  @Operation(summary = "Get 1 OFD token", description = "Get 1OFD token")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = TokenRequestDto.class))
  })
  @PostMapping(path = "/extapi/pervyj-ofd/v2/getToken",
      produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<TokenResponseDto> getOfdToken(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody TokenRequestDto body);

  /**
   * Запрос на получение токена ЕПА
   */
  @Operation(summary = "Get EPA token", description = "Get EPA token")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE)
  })
  @PostMapping(path = "/passport/oauth2/token/client_credentials/{clientId}/{clientSecret}",
      produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<EpaTokenResponseDto> getEpaToken(
      @RequestHeader HttpHeaders httpHeaders,
      @PathVariable String clientId,
      @PathVariable String clientSecret);

  /**
   * Запрос на уведомление о статусах обработки на печать фискальных документов
   */
  @Operation(summary = "Get document status", description = "Get document status")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = DocumentStatusRequestDto.class))
  })
  @PostMapping(path = "/api/v1/ofd/callback/firstofddocumentstatus",
      produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<Void> getDocumentStatus(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody DocumentStatusRequestDto body);

  /**
   * Запрос на создание фискального документа в ОФД
   */
  @Operation(summary = "Add receipt to print queue", description = "Add receipt to print queue")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = RequestMetadataDto.class))
  })
  @PostMapping(path = "/extapi/pervyj-ofd/v2/api/external/queue/v1/transaction/receipt",
      produces = "application/json", consumes = "application/json")
  @NotNull ResponseEntity<ReceiptPrintResponseDto> addReceiptToPrintQueue(
      @RequestHeader HttpHeaders httpHeaders,
      @RequestBody @Valid ReceiptPrintRequestDto receiptPrintRequestDto);

}