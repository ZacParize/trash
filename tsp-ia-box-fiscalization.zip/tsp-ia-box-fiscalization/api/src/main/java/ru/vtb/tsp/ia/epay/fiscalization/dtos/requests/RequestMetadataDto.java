package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestMetadataDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  @Size(max = 255)
  private String userGroup;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime timestamp;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime timeZone;

  @Size(max = 255)
  private String externalId;

  @Size(max = 255)
  private String callbackUrl;
}
