package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum VatCode {

  VAT_GENERAL,

  VAT_PREFERENTIAL,

  VAT_GENERAL_CALC,

  VAT_PREFERENTIAL_CALC,

  VAT_ZERO,

  NONE;

}
