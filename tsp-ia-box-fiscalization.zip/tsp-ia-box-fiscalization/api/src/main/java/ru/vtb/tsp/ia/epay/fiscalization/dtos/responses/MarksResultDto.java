package ru.vtb.tsp.ia.epay.fiscalization.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.CheckResult;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MarksResultDto {

  private String position;

  private String markCode;

  private CheckResult checkResult;

}
