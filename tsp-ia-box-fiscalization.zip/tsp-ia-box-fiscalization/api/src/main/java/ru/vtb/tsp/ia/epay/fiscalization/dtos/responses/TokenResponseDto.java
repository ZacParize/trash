package ru.vtb.tsp.ia.epay.fiscalization.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TokenResponseDto implements Serializable {

  private String token;

  @DateTimeFormat(pattern = "dd.MM.yyyy'T'HH:mm:ss")
  private LocalDateTime timestamp;

}