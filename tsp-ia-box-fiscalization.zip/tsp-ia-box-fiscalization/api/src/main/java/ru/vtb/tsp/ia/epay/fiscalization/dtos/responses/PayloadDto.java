package ru.vtb.tsp.ia.epay.fiscalization.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PayloadDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  private Long receiptInShiftNumber;

  private Long shiftNumber;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime receiptDatetime;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime currentDateTime;

  @Size(max = 32)
  private String fnNumber;

  @Size(max = 32)
  private String kktRegId;

  private Long fiscalDocumentNumber;

  @Size(max = 255)
  private String fiscalSign;

  @Size(max = 255)
  private String fnsUrl;

  @Size(max = 255)
  private String receiptUrl;

  @Size(max = 12)
  private String ofdInn;

  @Valid
  private MarksResultDto marksResult;

  private String retailAddress;

  private String retailPlace;

  private BigDecimal totalSum;

}
