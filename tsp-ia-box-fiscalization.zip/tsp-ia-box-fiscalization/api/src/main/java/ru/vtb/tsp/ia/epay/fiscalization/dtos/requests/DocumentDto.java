package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.OperationType;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.TaxationType;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentDto {


  private OperationType operationType;

  @Size(max = 255)
  private String cashier;

  @Size(max = 255)
  private String cashierInn;

  private List<ItemDto> items;

  private TaxationType taxationType;

  @Valid
  private TotalSumDto totalSum;

  @Size(max = 255)
  private String retailAddress;

  @Size(max = 255)
  private String retailPlace;

  @Size(max = 255)
  private String sendCheckTo;

  @Valid
  private BuyerDto buyer;

  @Valid
  private IndustryPropDto industryProp;

  @Valid
  private OperationalPropDto operationalProp;

  @Valid
  private ModeDto mode;

  @Size(max = 255)
  private String optionalReceiptProp;

  @Valid
  private CustomPropertyDto customProperty;

}
