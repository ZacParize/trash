package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public enum CheckResult {

  NOT_CHECKED(0),

  CHECKED_POSITIVE(3),

  NOT_CHECKED_AUTONOMOUS(16),

  CHECKED_POSITIVE_AUTONOMOUS(19),

  CHECKED_NEGATIVE(1),

  CHECKED_NEGATIVE_AUTONOMOUS(17),

  CHECKED_NEGATIVE_INCORRECT_STATUS(5),

  CHECKED_POSITIVE_INCORRECT_STATUS(7),

  CHECKED_POSITIVE_CORRECT_STATUS(15);

  private final int checkResult;

}
