package ru.vtb.tsp.ia.epay.fiscalization.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.util.UUID;
import javax.validation.Valid;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.Status;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReceiptPrintResponseDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  @Size(max = 32)
  private UUID requestId;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime timestamp;

  private Status status;

  @Size(max = 32)
  private String transactionType;

  @Size(max = 255)
  private String details;

  @Valid
  private PayloadDto payload;

}
