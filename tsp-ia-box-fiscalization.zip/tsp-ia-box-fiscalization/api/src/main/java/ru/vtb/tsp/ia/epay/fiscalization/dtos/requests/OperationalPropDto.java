package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.validation.constraints.Max;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import org.springframework.format.annotation.DateTimeFormat;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OperationalPropDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  @Max(32)
  private Long id;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime date;

  @Size(max = 255)
  private String data;

}
