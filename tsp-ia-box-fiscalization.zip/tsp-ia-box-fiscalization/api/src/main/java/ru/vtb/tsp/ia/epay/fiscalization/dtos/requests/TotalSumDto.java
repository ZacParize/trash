package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TotalSumDto {

  private BigDecimal cashTotalSum;

  private BigDecimal ecashTotalSum;

  private BigDecimal prepaymentSum;

  private BigDecimal postpaymentSum;

  private BigDecimal counterSubmissionSum;

}
