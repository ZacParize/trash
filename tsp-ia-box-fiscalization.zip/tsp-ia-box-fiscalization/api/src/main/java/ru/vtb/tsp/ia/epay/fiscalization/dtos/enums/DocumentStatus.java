package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum DocumentStatus {

  COMPLETED, ERROR;

}