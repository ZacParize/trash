package ru.vtb.tsp.ia.epay.fiscalization.dtos.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.DocumentStatus;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentStatusRequestDto implements Serializable {

  private static final String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  private String requestId;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime timestamp;

  private DocumentStatus status;

  private String transactionType;

  private String details;

}