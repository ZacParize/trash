package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum ReceiptPolicy {

  FISCAL_OR_SERVICE,

  NO_ERROR,

  ONLY_SERVICE,

  CORRECT_STATUS;

}
