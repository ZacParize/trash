package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum PaymentType {

  FULL_PREPAYMENT,

  PARTIAL_PREPAYMENT,

  ADVANCE,

  FULL_PAYMENT,

  PARTIAL_PAYMENT,

  CREDIT,

  CREDIT_PAYMENT;

}
