package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum OperationType {

  INCOME,

  INCOME_RETURN,

  EXPENCE,

  EXPENCE_RETURN;

}
