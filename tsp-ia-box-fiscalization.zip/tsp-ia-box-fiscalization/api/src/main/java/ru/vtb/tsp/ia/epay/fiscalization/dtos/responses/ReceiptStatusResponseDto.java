package ru.vtb.tsp.ia.epay.fiscalization.dtos.responses;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import ru.vtb.tsp.ia.epay.fiscalization.dtos.enums.Status;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReceiptStatusResponseDto {

  private final static String DATE_FORMAT = "dd.MM.yyyy'T'HH:mm:ss";

  @Size(max = 64)
  private String requestId;

  @DateTimeFormat(pattern = DATE_FORMAT)
  private LocalDateTime timestamp;

  private Status status;

  @Size(max = 255)
  private String transactionType;

  @Size(max = 255)
  private String details;

}
