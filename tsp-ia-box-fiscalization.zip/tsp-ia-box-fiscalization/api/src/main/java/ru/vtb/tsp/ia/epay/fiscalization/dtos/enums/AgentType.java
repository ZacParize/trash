package ru.vtb.tsp.ia.epay.fiscalization.dtos.enums;

public enum AgentType {

  BANK_PAYMENT_AGENT,

  BANK_PAYMENT_SUBAGENT,

  PAYMENT_AGENT,

  PAYMENT_SUBAGENT,

  SOLICITOR,

  COMMISSIONER,

  AGENT;

}
