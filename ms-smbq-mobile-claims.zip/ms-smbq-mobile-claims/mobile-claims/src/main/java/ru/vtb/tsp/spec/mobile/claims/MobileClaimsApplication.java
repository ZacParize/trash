package ru.vtb.tsp.spec.mobile.claims;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.FilterType;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.retry.annotation.EnableRetry;
import ru.vtb.dev.corp.smbq.partnership.common.config.PartnershipAutoConfiguration;

import javax.annotation.PostConstruct;
import java.util.TimeZone;
import ru.vtb.dev.corp.smbq.partnership.integration.epa.core.config.EpaAMConfigurationPropertiesConfigDto;
import ru.vtb.dev.corp.smbq.partnership.integration.epa.core.config.EpaIGConfigurationPropertiesConfigDto;

@SpringBootApplication(scanBasePackages = {"ru.vtb.tsp", "ru.vtb.dev.corp.smbq.partnership"})
@ConfigurationPropertiesScan(basePackages = {"ru.vtb.tsp"})
@EnableAspectJAutoProxy(proxyTargetClass = true)
@EnableJpaRepositories
@EnableFeignClients(basePackages = {"ru.vtb.tsp.spec"})
@EnableJpaAuditing
@EnableRetry
@EnableConfigurationProperties({EpaAMConfigurationPropertiesConfigDto.class, EpaIGConfigurationPropertiesConfigDto.class})
@ComponentScan(basePackages = {"ru.vtb.tsp.spec", "ru.vtb.dev.corp.smbq.partnership"}, excludeFilters = {@ComponentScan.Filter(
        type = FilterType.ASSIGNABLE_TYPE, classes = {PartnershipAutoConfiguration.class})})
public class MobileClaimsApplication {

  private static ConfigurableApplicationContext context;

  public static void main(String[] args) {
    context = SpringApplication.run(MobileClaimsApplication.class, args);
  }

  @PostConstruct
  void started() {
    TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
  }

  public static void restart(String... args) {
    Thread thread = new Thread(() -> {
      context.close();
      context = SpringApplication.run(MobileClaimsApplication.class, args);
    });
    thread.setDaemon(false);
    thread.start();
  }
}
