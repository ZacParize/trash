package ru.vtb.tsp.spec.mobile.claims.config;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.AntPathMatcher;

@Configuration
public class AntPathConfig {

  @Bean
  @ConditionalOnMissingBean
  public AntPathMatcher unprotectedUrlAntPathMatcher() {
    return new AntPathMatcher();
  }

}