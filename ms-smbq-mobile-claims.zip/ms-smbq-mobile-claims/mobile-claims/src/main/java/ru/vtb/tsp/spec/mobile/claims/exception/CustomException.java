package ru.vtb.tsp.spec.mobile.claims.exception;

public class CustomException extends RuntimeException {

  public CustomException(String message, Throwable cause) {
    super(message, cause);
  }

}
