package ru.vtb.tsp.spec.mobile.claims.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.spec.mobile.claims.exception.CustomException;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TimeUtil {

  public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

  public static LocalDateTime toLocalDate(String date) {
    return getLocalDateTime(date, DATE_TIME_FORMAT);
  }

  private static LocalDateTime getLocalDateTime(String date, String dateTimeFormatWithTimeZone) {
    if (date == null) {
      return null;
    }
    var formatter = DateTimeFormatter.ofPattern(dateTimeFormatWithTimeZone);
    try {
      return LocalDateTime.parse(date, formatter);
    } catch (DateTimeParseException e) {
      throw new CustomException("Ошибка конвертирования времени: " + date, e);
    }
  }

  public static String getStringDateTimeFormat(LocalDateTime localDateTime) {
    var dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
    return localDateTime.format(dateTimeFormatter);
  }

  public static LocalDateTime nowFormatted() {
    var localDateTime = LocalDateTime.now();
    var dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
    return LocalDateTime.parse(localDateTime.format(dateTimeFormatter), dateTimeFormatter);
  }

  public static Instant now() {
    return Instant.now();
  }

  public static LocalDateTime nowFormattedMsk() {
    var localDateTime = LocalDateTime.now(ZoneId.of("Europe/Moscow"));
    var dateTimeFormatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
    return LocalDateTime.parse(localDateTime.format(dateTimeFormatter), dateTimeFormatter);
  }
}


