package ru.vtb.tsp.spec.mobile.claims.utils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.CollectionType;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.lang.reflect.ParameterizedType;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class JsonResourceService<T> {

  protected List<T> items;

  private final String resourceName;
  private final String jsonAttribute;
  private final ResourceLoader resourceLoader;
  private final ObjectMapper objectMapper;

  public JsonResourceService(final String resourceName, final String jsonAttribute,
      final ResourceLoader resourceLoader, final ObjectMapper objectMapper) {
    this.resourceName = resourceName;
    this.resourceLoader = resourceLoader;
    this.objectMapper = objectMapper;
    this.jsonAttribute = jsonAttribute;
  }

  @PostConstruct
  private void load() throws IOException {
    var resource = resourceLoader.getResource(resourceName);
    var jsonMap = objectMapper.readTree(resource.getInputStream());
    var arrayNode = jsonMap.get(jsonAttribute);
    var listType = objectMapper.getTypeFactory()
        .constructCollectionType(ArrayList.class, elementClass());
    items = Collections.unmodifiableList(objectMapper.convertValue(arrayNode, listType));
  }

  @SuppressWarnings("unchecked")
  protected Class<T> elementClass() {
    return (Class<T>) ((ParameterizedType) getClass().getGenericSuperclass()).getActualTypeArguments()[0];
  }

  public List<T> findAll() {
    return items;
  }
}
