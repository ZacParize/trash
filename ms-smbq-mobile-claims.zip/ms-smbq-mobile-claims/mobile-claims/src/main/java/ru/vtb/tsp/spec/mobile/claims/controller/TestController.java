package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.MobileClaimsApplication;

import java.util.Arrays;
import java.util.stream.Collectors;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocType;
import ru.vtb.tsp.spec.mobile.claims.dto.template.ApplicationForSbpDocumentDto;
import ru.vtb.tsp.spec.mobile.claims.dto.template.PosAndQrRegistrationDto;
import ru.vtb.tsp.spec.mobile.claims.service.FileStorageService;
import ru.vtb.tsp.spec.mobile.claims.service.TemplateService;

@Profile("test_controller")
@Api(value = "Test-controller", tags = "test-controller")
@RestController
@RequestMapping("${api-v1.root}/test")
@RequiredArgsConstructor
@Slf4j
public class TestController {

  @Value("${spring.profiles.active}")
  private String activeProfiles;

  private FileStorageService fileStorageService;

  private final String MASKING_DISABLED_PROFILE = "masking_disabled";

  private final TemplateService templateService;


  @GetMapping(path = "download/cxk", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public byte[] downloadCxkFile(UUID uuid) {
    return fileStorageService.download(uuid);
  }

  @PostMapping("/masking")
  public void disableMasking(@RequestParam(defaultValue = "true") boolean disableMasking) {
    var updatedActiveProfiles = Arrays.stream(activeProfiles.split(",")).collect(Collectors.toSet());
    var logFile = "classpath:log4j2.xml";

    if (disableMasking) {
      updatedActiveProfiles.add(MASKING_DISABLED_PROFILE);
      logFile = "classpath:log4j2-unmasked.xml";
    } else {
      updatedActiveProfiles.remove(MASKING_DISABLED_PROFILE);
    }
    var profiles = "--spring.profiles.active=" + String.join(",", updatedActiveProfiles);
    var loggingConfig = "--logging.config=" + String.join(",", logFile);

    MobileClaimsApplication.restart(profiles, loggingConfig);
  }
}
