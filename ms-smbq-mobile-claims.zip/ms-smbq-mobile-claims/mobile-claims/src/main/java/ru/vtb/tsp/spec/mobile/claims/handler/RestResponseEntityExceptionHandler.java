package ru.vtb.tsp.spec.mobile.claims.handler;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ErrorMsg;
import ru.vtb.tsp.spec.mobile.claims.common.exception.EntityNotFoundException;

import java.nio.file.AccessDeniedException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.exception.AccountNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ErrorCode;
import ru.vtb.tsp.spec.mobile.claims.exception.AddressNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.exception.AddressSearchUnknownException;
import ru.vtb.tsp.spec.mobile.claims.exception.AuthorizationFailedException;
import ru.vtb.tsp.spec.mobile.claims.exception.ClaimRegistrationException;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkDownloadFileException;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkUploadException;
import ru.vtb.tsp.spec.mobile.claims.exception.FailedToConfirmUploadSuccessException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferGetStatusException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferUploadException;
import ru.vtb.tsp.spec.mobile.claims.exception.GetDownloadLinkException;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;
import ru.vtb.tsp.spec.mobile.claims.exception.NotFoundDocumentSignProcessException;
import ru.vtb.tsp.spec.mobile.claims.exception.PdfGenerationException;
import ru.vtb.tsp.spec.mobile.claims.exception.SendCodeAttemptsExceededException;
import ru.vtb.tsp.spec.mobile.claims.exception.TariffNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.exception.TariffSearchFailedException;
import ru.vtb.tsp.spec.mobile.claims.exception.VerifyNotificationException;
import ru.vtb.tsp.spec.mobile.claims.session.exception.SessionDataNotFoundException;


@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(value
          = {AccountNotFoundException.class})
  protected ResponseEntity<Object> accountNotFound(
          RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.ACCOUNTS_NOT_FOUND),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {ClaimRegistrationException.class})
  protected ResponseEntity<Object> claimRegistrationException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.CLAIM_CREATION_ERROR),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value
      = {CxkDownloadFileException.class})
  protected ResponseEntity<Object> cxkDownloadFileFailed(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.GET_ECM_FILE_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {FileTransferUploadException.class})
  protected ResponseEntity<Object> fileTransferUploadException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.DOWNLOAD_FILE_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {FileTransferGetStatusException.class})
  protected ResponseEntity<Object> fileTransferGetStatusException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.GET_STATUS_CHECK_DLP_FILE_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {GetDownloadLinkException.class})
  protected ResponseEntity<Object> getDownloadLinkException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.SET_FILE_STATUS_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {AuthorizationFailedException.class})
  protected ResponseEntity<Object> authFailed(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.CHECK_PERMISSIONS_ERROR),
        new HttpHeaders(), HttpStatus.FORBIDDEN, request);
  }

  @ExceptionHandler(value
      = {AddressNotFoundException.class})
  protected ResponseEntity<Object> addressNotFound(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.ADDRESS_NOT_FOUND),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {AddressSearchUnknownException.class})
  protected ResponseEntity<Object> addressUnknownError(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.GET_DADATA_ADDRESS_ERROR),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value
      = {EntityNotFoundException.class})
  protected ResponseEntity<Object> entityNotFound(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.INVALID_EXTERNAL_SYSTEM_RESPONSE),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {InvalidExternalSystemResponseException.class})
  protected ResponseEntity<Object> invalidExternalSystemResponse(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.INVALID_EXTERNAL_SYSTEM_RESPONSE),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value
      = {SessionDataNotFoundException.class})
  protected ResponseEntity<Object> sessionDataNotFound(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.GET_SESSION_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {FailedToConfirmUploadSuccessException.class})
  protected ResponseEntity<Object> failedToConfirmUploadSuccessException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.SET_FILE_STATUS_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {VerifyNotificationException.class})
  protected ResponseEntity<Object> verifyNotificationException(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.VERIFICATION_CODE_NOT_MATCH),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {SendCodeAttemptsExceededException.class})
  protected ResponseEntity<Object> sendCodeAttemptsExceeded(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.ATTEMPTS_LIMIT_EXCEEDED),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {NotFoundDocumentSignProcessException.class})
  protected ResponseEntity<Object> notFoundDocumentSignProcess(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.INVALID_EXTERNAL_SYSTEM_RESPONSE),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {TariffNotFoundException.class})
  protected ResponseEntity<Object> tariffNotFound(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.TARIFF_NOT_FOUND),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {TariffSearchFailedException.class})
  protected ResponseEntity<Object> tariffSearchFailed(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.GET_TARIFF_ERROR),
        new HttpHeaders(), HttpStatus.NOT_FOUND, request);
  }

  @ExceptionHandler(value
      = {CxkUploadException.class})
  protected ResponseEntity<Object> cxkUploadFailed(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.ECM_FILE_DOWNLOAD_ERROR),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value
      = {PdfGenerationException.class})
  protected ResponseEntity<Object> pfdGenerationFailed(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, ErrorMsg.from(ErrorCode.FILE_CREATION_ERROR),
        new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR, request);
  }

  @ExceptionHandler(value
      = {AccessDeniedException.class, JwtIsNotValidException.class})
  protected ResponseEntity<Object> accessDenied(
      RuntimeException ex, WebRequest request) {
    return handleExceptionInternal(ex, createResponse(ex),
        new HttpHeaders(), HttpStatus.FORBIDDEN, request);
  }

  @ExceptionHandler(value
      = {HttpClientErrorException.class})
  protected ResponseEntity<Object> httpClientErrorException(
      RuntimeException ex, WebRequest request) {
    var httpClientErrorException = (HttpClientErrorException) ex;
    return handleExceptionInternal(ex, httpClientErrorException.getResponseBodyAsByteArray(),
        new HttpHeaders(), httpClientErrorException.getStatusCode(), request);
  }

  private Map<String, Object> createResponse(RuntimeException ex) {
    Map<String, Object> map = new HashMap<>();
    map.put("timestamp", LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
    map.put("message", ex.getMessage());
    return map;
  }
}