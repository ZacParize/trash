package ru.vtb.tsp.spec.mobile.claims.config;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.Meter.Id;
import io.micrometer.core.instrument.MeterRegistry;
import java.util.Arrays;
import java.util.regex.Pattern;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
public class MeterRegistryFixer {
  private final ApplicationContext applicationContext;

  @PostConstruct
  public void fixMeterRegistry() {
    final var meterRegistryPostProcessorSearchPattern =
        Pattern.compile(String.format(".*%s.*", MeterRegistry.class.getSimpleName()), Pattern.CASE_INSENSITIVE);
    try {
      Arrays.stream(applicationContext.getBeanNamesForType(BeanPostProcessor.class))
          .filter(beanPostProcessorName -> meterRegistryPostProcessorSearchPattern.matcher(beanPostProcessorName).matches())
          .forEach(beanPostProcessorName -> {
            final var meterRegistryPostProcessor = (BeanPostProcessor) applicationContext.getBean(beanPostProcessorName);
            for (String meterRegistryName : applicationContext.getBeanNamesForType(MeterRegistry.class)) {
              final var meterRegistry = (MeterRegistry) applicationContext.getBean(meterRegistryName);
              if (meterRegistry.getMeters().stream().map(Meter::getId).map(Id::getName).noneMatch(name -> name.startsWith("jvm."))) {
                meterRegistryPostProcessor.postProcessAfterInitialization(meterRegistry, meterRegistryName);
              }
            }
          });
    } catch (NoSuchBeanDefinitionException ignore) {
    }
  }
}