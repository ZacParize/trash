package ru.vtb.tsp.spec.mobile.claims.config;

import javax.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.AbstractRequestLoggingFilter;

@Configuration
@Slf4j
public class RequestLoggingFilterConfig extends AbstractRequestLoggingFilter {

    @Override
    protected void beforeRequest(HttpServletRequest request, String message) {
        log.debug("Request initiated, info. {}", message);
    }

    @Override
    protected void afterRequest(HttpServletRequest request, String message) {

    }
}