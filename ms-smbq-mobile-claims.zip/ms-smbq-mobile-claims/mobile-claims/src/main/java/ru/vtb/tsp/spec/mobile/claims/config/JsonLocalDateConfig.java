package ru.vtb.tsp.spec.mobile.claims.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.annotation.PostConstruct;

@Configuration
@RequiredArgsConstructor
public class JsonLocalDateConfig {

  private final ObjectMapper mapper;

  @PostConstruct
  void init() {
    mapper.registerModule(new JavaTimeModule());
  }

}
