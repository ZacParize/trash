package ru.vtb.tsp.spec.mobile.claims.config.v2;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import ru.vtb.tsp.spec.mobile.claims.TestApplication;

@ActiveProfiles(profiles = {"tests", "test", "sbp_stub", "qr_stub", "session_stub", "session_pp_stub"})
@SpringBootTest(classes = TestApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ExtendWith(SpringExtension.class)
@ComponentScan(basePackages = "ru.vtb.tsp", lazyInit = true)
public abstract class TestsConfigurationV2 {

}
