package ru.vtb.tsp.spec.mobile.claims.util.masking.credentials;

import static org.junit.jupiter.api.Assertions.assertFalse;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Removes ofd credentials from logs. Example: {"login":"Uzver567","password":"Uzverovich12323"}
 * Masked: Whitespace char
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckOfdCredentialsRemovedTest implements MaskingTest {

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String login = "Uzver567";
    String password = "Uzverovich12323";
    log.info("[Ofd1DataApi#login] {\"login\":\"{}\",\"password\":\"{}\"}", login, password);
    String out = output.getOut();
    assertFalse(out.contains(login));
    assertFalse(out.contains(password));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    // same as for quotes case
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    // not applicable
  }

}
