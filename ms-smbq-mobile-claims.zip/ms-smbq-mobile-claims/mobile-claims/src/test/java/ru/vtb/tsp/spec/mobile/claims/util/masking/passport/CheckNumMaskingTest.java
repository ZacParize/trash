package ru.vtb.tsp.spec.mobile.claims.util.masking.passport;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckNumMaskingTest implements MaskingTest {

  private static final String MOCK_NUM = "111111";
  private static final String MASKED_MOCK_NUM = "1****1";

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String num = String.format("\"num\":\"%s\",\",", MOCK_NUM);
    String expectedMasked = String.format("\"num\":\"%s\",\",", MASKED_MOCK_NUM);
    log.info("Secret information: [{}]", num);
    String out = output.getOut();
    assertFalse(out.contains(num));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    log.info("num: [{}]", MOCK_NUM);
    String out = output.getOut();
    assertFalse(out.contains(MOCK_NUM));
    assertTrue(out.contains(MASKED_MOCK_NUM));
  }

  @Test
  public void checkMasking_notResident8Digits_messageMasked(CapturedOutput output) {
    String num = "66666666";
    String maskedNum = "6*****66";
    log.info("num: [{}]", num);
    String out = output.getOut();
    assertFalse(out.contains(num));
    assertTrue(out.contains(maskedNum));
  }

  @Test
  public void checkMasking_notResidentEndingWithChars_messageMasked(CapturedOutput output) {
    String num = "QwerTY111abc";
    String maskedNum = "Qw********bc";
    log.info("num: [{}]", num);
    String out = output.getOut();
    assertFalse(out.contains(num));
    assertTrue(out.contains(maskedNum));
  }

  @Test
  public void checkMasking_notResidentUs_messageMasked(CapturedOutput output) {
    String num = "C12345678";
    String maskedNum = "C******78";
    log.info("num: [{}]", num);
    String out = output.getOut();
    assertFalse(out.contains(num));
    assertTrue(out.contains(maskedNum));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String numFirst = "11111111";
    String expectedMaskedFirst = "1*****11";
    String numSecond = "22222222";
    String expectedMaskedSecond = "2*****22";

    log.info("Secret information: num: [{}], num: [{}]",
        numFirst, numSecond);
    String out = output.getOut();
    assertFalse(out.contains(numFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(numSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
