package ru.vtb.tsp.spec.mobile.claims.util.masking.ogrn;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Ogrn has 13 digits. Example: 123456789098765 Masked: 12*********8765
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckOgrnMaskingTest implements MaskingTest {

  @Test
  void checkMaskingOgrnFoundEndOfLineTest(CapturedOutput output) {
    String ogrn = "1234567890123";
    String expectedMasked = "12********123";
    log.debug("OGRN found in organization: {}", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkNotMaskingMdmTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    String mdmOsnClient = "11111111111111";
    String mdmPkbClient = "6666666666666";
    log.debug("[{\"mdmCode\":\"{}\",\"mdmOsnClient\":" +
        "\"{}\",\"mdmPkbClient\":\"{}\",", mdmCode, mdmOsnClient, mdmPkbClient);

    String out = output.getOut();
    assertTrue(out.contains(mdmCode));
    assertTrue(out.contains(mdmOsnClient));
    assertTrue(out.contains(mdmPkbClient));
  }

  @Test
  public void checkNotMaskingMdmSecondTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    String mdmOsnClient = "11111111111111";
    String mdmPkbClient = "6666666666666";
    log.debug(
        "\\\"activeClient\\\":{\\\"mdmCode\\\":\\\"{}\\\",\\\"mdmOsnClient\\\":\\\"{}\\\",\\\"mdmPkbClient\\\":\\\"{}\\\"},\\\"lastName\\\"",
        mdmCode, mdmOsnClient, mdmPkbClient);

    String out = output.getOut();
    assertTrue(out.contains(mdmCode));
    assertTrue(out.contains(mdmOsnClient));
    assertTrue(out.contains(mdmPkbClient));
  }

  @Test
  public void checkNotMaskingMdmFindProcessTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    log.debug("Searching existing process for client with mdm code: [{}]", mdmCode);

    String out = output.getOut();
    assertTrue(out.contains(mdmCode));
  }

  @Test
  public void checkNotMaskingMdmSetMdmToProcessTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    log.debug("Set mdm code [{}] to process", mdmCode);

    String out = output.getOut();
    assertTrue(out.contains(mdmCode));
  }

  @Test
  public void checkNotMaskingMdmFoundInOrganizationTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    log.debug("MDM found in organization: {}", mdmCode);

    String out = output.getOut();
    assertTrue(out.contains(mdmCode));
  }

  @Test
  public void checkMaskingOrganizationInfoTest(CapturedOutput output) {
    String mdmCode = "1234567890123";
    String inn = "1111111111";
    String ogrn = "2222222222222";
    log.debug("OrganizationInfo : OrganizationInfo(mdmCode={}, inn={}, ogrn={})", mdmCode, inn,
        ogrn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    String expectedMaskedOgrn = "22********222";

    assertFalse(out.contains(inn));
    assertFalse(out.contains(ogrn));

    assertTrue(out.contains(mdmCode));

    assertTrue(out.contains(expectedMaskedInn));
    assertTrue(out.contains(expectedMaskedOgrn));
  }

  @Test
  public void checkMaskingActiveSessionTest(CapturedOutput output) {
    String inn = "1111111111";
    String ogrn = "2222222222222";
    log.debug("Active session: SessionInfo(mdmCode=111, orgInfo=OrgInfo(inn={}, ogrn={}))", inn,
        ogrn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    String expectedMaskedOgrn = "22********222";

    assertFalse(out.contains(inn));
    assertFalse(out.contains(ogrn));

    assertTrue(out.contains(expectedMaskedInn));
    assertTrue(out.contains(expectedMaskedOgrn));
  }

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String ogrn = "\":[{\"ogrn\":\"1234567890123\",\"";
    String expectedMasked = "\":[{\"ogrn\":\"12********123\",\"";
    log.info("Secret information: [{}]", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String ogrn = "1234567890123";
    String expectedMasked = "12********123";
    log.info("Secret information: [{}]", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String ogrnFirst = "1111111111111";
    String expectedMaskedFirst = "11********111";
    String ogrnSecond = "2222222222222";
    String expectedMaskedSecond = "22********222";
    log.info("Secret information: ogrnFirst: [{}], ogrnSecond: [{}]", ogrnFirst, ogrnSecond);

    String out = output.getOut();
    assertFalse(out.contains(ogrnFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(ogrnSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
