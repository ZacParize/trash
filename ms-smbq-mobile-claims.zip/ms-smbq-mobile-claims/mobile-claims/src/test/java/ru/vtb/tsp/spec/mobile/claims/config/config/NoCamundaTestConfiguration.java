package ru.vtb.tsp.spec.mobile.claims.config.config;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ActiveProfiles;
import ru.vtb.tsp.spec.mobile.claims.TestApplication;

@ActiveProfiles(profiles = {"tests", "test", "sbp_stub", "qr_stub", "session_stub", "local",
    "account_stub", "etalon_stub", "workflow_stub", "mbank_stub", "open_swagger",
    "mbank_to_cft_migration_test",
    "qrcode_stub", "mbank_test", "token_test", "ofd_delegate_stub", "dadata_stub",
    "frkk_tasks_stub",
    "qr_stub", "epa_off"
})
@SpringBootTest(classes = {TestApplication.class},
    webEnvironment = WebEnvironment.NONE
)
@ComponentScan(basePackages = "ru.vtb.tsp", lazyInit = true)
public abstract class NoCamundaTestConfiguration {

}
