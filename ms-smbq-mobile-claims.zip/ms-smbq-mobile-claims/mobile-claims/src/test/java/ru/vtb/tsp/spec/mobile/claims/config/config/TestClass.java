package ru.vtb.tsp.spec.mobile.claims.config.config;

public class TestClass {

}
