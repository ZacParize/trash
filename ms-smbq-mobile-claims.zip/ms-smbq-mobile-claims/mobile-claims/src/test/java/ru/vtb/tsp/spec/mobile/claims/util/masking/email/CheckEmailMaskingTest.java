package ru.vtb.tsp.spec.mobile.claims.util.masking.email;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckEmailMaskingTest implements MaskingTest {

  @Test
  void checkMaskingWorkflowPutOrganizationTest(CapturedOutput output) {
    String email = "boss@ya.ru";
    String expectedMasked = "bo******ru";
    log.debug("{\"lastNa*me\":\"Фамилия\",\"firstName\":\"Имя\",\"middleName\":\"Отчествогого*\",\"sex\":\"F\",\"birthday\":\"1962-01-20\",\"phone\":\"3333333333\",\"email\":\"{}\",\"nonResident\":false,\"ps\"", email);
    String out = output.getOut();
    assertFalse(out.contains(email));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String email = "boss@ya.ru";
    String expectedMasked = "bo******ru";
    log.debug("Ofd1DataApi#submitForm {\"email\":\"{}\"", email);
    String out = output.getOut();
    assertFalse(out.contains(email));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String email = "boss@ya.ru";
    String expectedMasked = "bo******ru";
    log.debug("email: {}", email);
    String out = output.getOut();
    assertFalse(out.contains(email));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String emailFirst = "chalishev@mail.ru";
    String expectedMaskedFirst = "cha***********.ru";
    String emailSecond = "zvancev@mail.ru";
    String expectedMaskedSecond = "zv*********l.ru";

    log.info("some text email: [{}], email: [{}]", emailFirst, emailSecond);
    String out = output.getOut();
    assertFalse(out.contains(emailFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(emailSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
