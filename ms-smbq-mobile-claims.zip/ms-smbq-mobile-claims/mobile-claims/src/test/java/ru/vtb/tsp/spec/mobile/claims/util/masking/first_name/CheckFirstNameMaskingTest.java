package ru.vtb.tsp.spec.mobile.claims.util.masking.first_name;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckFirstNameMaskingTest implements MaskingTest {

  @Test
  public void checkMaskingSessionDataTest(CapturedOutput output) {
    String firstName = "Анна";
    String expectedMasked = "А**";
    log.debug("\"firstName\\\":\\\"{}\\\"", firstName);
    String out = output.getOut();
    assertFalse(out.contains(firstName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingWorkflowPutOrganizationTest(CapturedOutput output) {
    String firstName = "Имя";
    String expectedMasked = "И**";
    log.debug("{\"lastName\":\"Фамилия\",\"firstName\":\"{}\",\"middleName\":\"Отчествогого\",\"sex\":\"F\",\"birthday\":\"1962-01-20\",\"phone\":\"3333333333\",\"email\":\"boss@ya.ru\",\"nonResident\":false,\"ps\"", firstName);
    String out = output.getOut();
    assertFalse(out.contains(firstName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String firstName = "Сергей";
    String expectedMasked = "С****й";
    log.debug("Ofd1DataApi#submitForm {\"firstName\":\"{}\"", firstName);
    String out = output.getOut();
    assertFalse(out.contains(firstName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String firstName = "Сергей";
    String expectedMasked = "С****й";
    log.debug("firstName: {}", firstName);
    String out = output.getOut();
    assertFalse(out.contains(firstName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String firstNameFirst = "Сергей";
    String expectedMaskedFirst = "С****й";
    String firstNameSecond = "Олег";
    String expectedMaskedSecond = "О***";

    log.info("some text firstName: [{}], firstName: [{}]", firstNameFirst, firstNameSecond);
    String out = output.getOut();
    assertFalse(out.contains(firstNameFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(firstNameSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
