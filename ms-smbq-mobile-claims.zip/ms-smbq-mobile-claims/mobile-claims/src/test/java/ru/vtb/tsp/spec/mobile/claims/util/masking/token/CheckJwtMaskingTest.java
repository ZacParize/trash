package ru.vtb.tsp.spec.mobile.claims.util.masking.token;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Alg ES256. Example: eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q
 * Masked: eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiO********************************************************************************************************************************************oNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckJwtMaskingTest implements MaskingTest {

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String jwt = "Authorization: Bearer \"eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8\"";
    log.info("Secret information: [{}]", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String jwt = "Authorization: Bearer eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q";
    log.info("Secret information: [{}]", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String jwt = "Authorization: Bearer eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q";
    String secondJwt = "Authorization: Bearer eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidGVybWluYXRvciIsImF1ZCI6IlQtODAwIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.8LBQsMDeM2s_z8BOlE6EEoeav1yzEOz2X4HwO4OAPBTvzmsEk-GFEsvPl_tI-b5MOYOQ-EjSgnvma6tw1Zk7tg";
    log.info("Secret information: firstToken: [{}], secondToken: [{}]", jwt, secondJwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("Secret information: firstToken: [Authorization: Bearer "));
  }

  @Test
  public void checkSbpStateTest(CapturedOutput output) {
    String jwt = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q";
    log.debug("2022-12-08 15:56:13[http-nio-8080-exec-8]INFO r.v.t.s.s.r.c.QrCodeControllerV2 - getSbpState: httpHeaders: [x-forwarded-for:\"10.222.39.64\", \"10.222.254.2\", accept:\"application/json\", x-forwarded-host:\"10.222.25.11\", \"spec.ss1-genr01-smbq-tspift.apps.ss1-genr01.test.vtb.ru\", authorization:\"Bearer {}\", user-agent:\"okhttp/4.10.0\", x-forwarded-port:\"443\", \"443\", end-time:\"null\", uber-trace-id:\"eb01c38ad34ec53f:eb01c38ad34ec53f:0:1\", x-tyk-api-key:\"sdsd\", x-forwarded-proto:\"https\", \"https\", x-real-ip:\"10.222.25.11\", accept-encoding:\"gzip\", host:\"spec.ss1-genr01-smbq-tspift.apps.ss1-genr01.test.vtb.ru\", x-forwarded-proto-version:\"h2\", forwarded:\"for=10.222.254.2;host=spec.ss1-genr01-smbq-tspift.apps.ss1-genr01.test.vtb.ru;proto=https\"]", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("authorization:\"Bearer ,"));
  }

  @Test
  public void checkJwtTokensUtilTest(CapturedOutput output) {
    String jwt = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q";
    log.debug("2022-12-08 15:56:13[http-nio-8080-exec-8]DEBUG r.v.tsp.spec.sbp.utils.JwtTokenUtils - Formatted token : {}", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("Formatted token : "));
  }

  @Test
  public void checkNotMaskingTraceIdTest(CapturedOutput output) {
    String msg = "[http-nio-8080-exec-5][traceId=eyJhbGciOiJFUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ0ZXN0Iiwic3ViIjoidXp2ZXJvdmljaCIsImF1ZCI6InV6dmVyIiwiaWF0Ijo2NjY2NjY2Njk5LCJleHAiOjY2NzA1NzQ1OTl9.6yoB5SbaSalHmGu7Gz8Nas1TfxC3C73ram6d3A6VoNQRRYem5ux1QR0sfpn0qsElR7RZIzLgz0_3bLu6HzU-8Q] DEBUG r.v.t.s.dadata.api.DadataAdapterApi - DadataAdapterApi#sucsSearch Content-Length: 160";
    log.debug(msg);
    String out = output.getOut();
    assertTrue(out.contains(msg));
  }

  @Test
  public void checkMaskingNotTechJwtEpaTest(CapturedOutput output) {
    String jwt = "AQQR5wM2LD4SfceYoyfrHIvWMUWGwqQJzzGypOuO9UxWJsg.*AAJTSQADMCIAAlNLABI3MTI1jMcwMjk5DMczATMxMzAAAlMxAAIwMQ..*";
    log.info("EpaSessionAuthServiceImpl : Login successful: EpaSessionTokenResponse(accessToken={}, expiresIn=179, tokenType=Bearer)", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("accessToken=, expiresIn=179, tokenType=Bearer)"));
  }

  @Test
  public void checkMaskingNotTechJwtEtalonTest(CapturedOutput output) {
    String jwt = "AQQR5wM2LD4SfceYoyfrHIvWMUWGwqQJzzGypOuO9UxWJsg.*AAJTSQADMCIAAlNLABI3MTI1jMcwMjk5DMczATMxMzAAAlMxAAIwMQ..*";
    log.info("2022-12-13 16:39:48[main][traceId=, spanId=] DEBUG r.v.tsp.spec.app.feign.EtalonDataApi - EtalonDataApi#etalonData Authorization: Bearer {}", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("Authorization: Bearer "));
  }

  @Test
  public void checkMaskingNotTechJwtEtalonSecondFormatTest(CapturedOutput output) {
    String jwt = "AQICasdjSdsasdczbgIany4UE6FHP0LhGtASSDSDSigox1gbPTs.*AAJTXZXZXZAWAlNLABQtODI2NjA1MDSDSWEWQ1ODg0MzSDSEWESDCUzEAAjAx*";
    log.info("[EtalonDataApi#etalonData] Authorization: Bearer {}", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("Authorization: Bearer "));
  }

  @Test
  public void checkMaskingNotTechJwtOfdTest(CapturedOutput output) {
    String jwt = "AQICasdjSdsasdczbgIany4UE6FHP0LhGtASSDSDSigox1gbPTs.*AAJTXZXZXZAWAlNLABQtODI2NjA1MDSDSWEWQ1ODg0MzSDSEWESDCUzEAAjAx*";
    log.info("r.vtb.tsp.spec.app.feign.Ofd1DataApi - [Ofd1DataApi#login] Authorization: Bearer {}", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("Authorization: Bearer"));
  }

  @Test
  public void checkMaskingNotTechJwtSessionTest(CapturedOutput output) {
    String jwt = "AQICasdjSdsasdczbgIany4UE6FHP0LhGtASSDSDSigox1gbPTs.*AAJTXZXZXZAWAlNLABQtODI2NjA1MDSDSWEWQ1ODg0MzSDSEWESDCUzEAAjAx*";
    log.info("EpaEtalonSessionApi - [EpaEtalonSessionApi#auth] {\"access_token\":\"{}\",\"expires_in\":327,\"token_type\":\"Bearer\"}", jwt);
    String out = output.getOut();
    assertFalse(out.contains(jwt));
    assertTrue(out.contains("access_token\"\":\"Bearer"));
  }

}
