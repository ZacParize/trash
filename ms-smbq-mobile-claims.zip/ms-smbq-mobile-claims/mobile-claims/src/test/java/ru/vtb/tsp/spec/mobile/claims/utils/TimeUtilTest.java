package ru.vtb.tsp.spec.mobile.claims.utils;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static ru.vtb.tsp.spec.mobile.claims.utils.TimeUtil.DATE_TIME_FORMAT;

class TimeUtilTest {

    @Test
    void toLocalDate_execute_isCorrectYear() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        Assertions.assertEquals(now.getDayOfYear(), TimeUtil.toLocalDate(now.format(formatter)).getDayOfYear());
    }

    @Test
    void getLocalDateTime_incorrectFormatPassed_exceptionThrown() {
        LocalDateTime now = LocalDateTime.now();
        assertThrows(Exception.class, () -> TimeUtil.toLocalDate(now.toString()));
    }
}