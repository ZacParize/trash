package ru.vtb.tsp.spec.mobile.claims.util.masking.last_name;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckLastNameMaskingTest implements MaskingTest {

  @Test
  public void checkMaskingSessionDataTest(CapturedOutput output) {
    String lastName = "Отчество";
    String expectedMasked = "О*****во";
    log.debug("\"lastName\\\":\\\"{}\\\"", lastName);
    String out = output.getOut();
    assertFalse(out.contains(lastName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingWorkflowPutOrganizationTest(CapturedOutput output) {
    String lastName = "Челищев";
    String expectedMasked = "Ч*****в";
    log.debug("{\"lastName\":\"{}\",\"firstName\":\"Имя\",\"middleName\":\"Отчествогого*\",\"sex\":\"F\",\"birthday\":\"1962-01-20\",\"phone\":\"3333333333\",\"email\":\"boss@ya.ru\",\"nonResident\":false,\"ps\"", lastName);
    String out = output.getOut();
    assertFalse(out.contains(lastName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String lastName = "Челищев";
    String expectedMasked = "Ч*****в";
    log.debug("Ofd1DataApi#submitForm {\"lastName\":\"{}\"", lastName);
    String out = output.getOut();
    assertFalse(out.contains(lastName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String lastName = "Челищев";
    String expectedMasked = "Ч*****в";
    log.debug("lastName: {}", lastName);
    String out = output.getOut();
    assertFalse(out.contains(lastName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String lastNameFirst = "Челищев";
    String expectedMaskedFirst = "Ч*****в";
    String lastNameSecond = "Званцев";
    String expectedMaskedSecond = "З*****в";

    log.info("some text lastName: [{}], lastName: [{}]", lastNameFirst, lastNameSecond);
    String out = output.getOut();
    assertFalse(out.contains(lastNameFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(lastNameSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
