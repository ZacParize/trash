package ru.vtb.tsp.spec.mobile.claims.util.masking.inn;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Legal entity inn has 10 digits. Example: 1111111111 Masked: 11******11
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckLegalEntityInnMaskingTest implements MaskingTest {

  @Test
  void checkMaskingInnFoundEndOfLineTest(CapturedOutput output) {
    String inn = "1111111111";
    log.debug("INN found in organization: {}", inn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    assertFalse(out.contains(inn));
    assertTrue(out.contains(expectedMaskedInn));
  }

  @Test
  void checkMaskingActiveSessionTest(CapturedOutput output) {
    String inn = "1111111111";
    String ogrn = "2222222222222";
    log.debug("Active session: SessionInfo(mdmCode=111, orgInfo=OrgInfo(inn={}, ogrn={}))", inn,
        ogrn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    String expectedMaskedOgrn = "22********222";

    assertFalse(out.contains(inn));
    assertFalse(out.contains(ogrn));

    assertTrue(out.contains(expectedMaskedInn));
    assertTrue(out.contains(expectedMaskedOgrn));
  }

  @Test
  public void checkMaskingSbpTest(CapturedOutput output) {
    String inn = "1111111111";
    log.debug("Для клиента (ИНН: {}) запрашивается информация из процессинга СБП", inn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    assertFalse(out.contains(inn));
    assertTrue(out.contains(expectedMaskedInn));
  }


  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String inn = "\":[{\"inn\":\"1234567890\",\"";
    String expectedMasked = "\":[{\"inn\":\"12******90\",\"";
    log.info("Secret information: [{}]", inn);
    String out = output.getOut();
    assertFalse(out.contains(inn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String inn = "1234567890";
    String expectedMasked = "12******90";
    log.info("Secret information: [{}]", inn);
    String out = output.getOut();
    assertFalse(out.contains(inn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String innFirst = "1111111111";
    String expectedMaskedFirst = "11******11";
    String innSecond = "2222222222";
    String expectedMaskedSecond = "22******22";

    log.info("Secret information: innFirst: [{}], innSecond: [{}]", innFirst, innSecond);
    String out = output.getOut();
    assertFalse(out.contains(innFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(innSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
