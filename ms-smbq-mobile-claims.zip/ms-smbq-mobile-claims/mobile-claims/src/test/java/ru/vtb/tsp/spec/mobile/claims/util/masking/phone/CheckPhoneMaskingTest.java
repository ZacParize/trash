package ru.vtb.tsp.spec.mobile.claims.util.masking.phone;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckPhoneMaskingTest implements MaskingTest {

  @Test
  public void checkMaskingInBracketsTest(CapturedOutput output) {
    String phone = "(333)333-33-33";
    String expectedMasked = "3*********-33";
    log.debug("phoneValue: {}", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  public void checkMaskingFullPhoneNumberTest(CapturedOutput output) {
    String phone = "967 4209012";
    String expectedMasked = "96*******12";
    log.debug("{\"fullPhoneNumber\":\"{}", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  public void checkMaskingInBracketsStartingWithPlusTest(CapturedOutput output) {
    String phone = "+3(333) 333-33-33";
    String expectedMasked = "+3(***********-33";
    log.debug("phone: {}", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingWorkflowPutOrganizationTest(CapturedOutput output) {
    String phone = "3333333333";
    String expectedMasked = "33******33";
    log.debug("{\"lastName\":\"Фамилия\",\"firstName\":\"Имя\",\"middleName\":\"Отчествогого*\",\"sex\":\"F\",\"birthday\":\"1962-01-20\",\"phone\":\"{}\",\"email\":\"boss@ya.ru\",\"nonResident\":false,\"ps\"", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String phone = "3333333333";
    String expectedMasked = "33******33";
    log.debug("Ofd1DataApi#submitForm {\"phone\":\"{}\"", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String phone = "3333333333";
    String expectedMasked = "33******33";
    log.debug("phone: {}", phone);
    String out = output.getOut();
    assertFalse(out.contains(phone));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String firstPhone = "+3333333333";
    String expectedMaskedFirst = "+33******33";
    String secondPhone = "6666666666";
    String expectedMaskedSecond = "66******66";

    log.info("some text phone: [{}], phone: [{}]", firstPhone, secondPhone);
    String out = output.getOut();
    assertFalse(out.contains(firstPhone));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(secondPhone));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
