package ru.vtb.tsp.spec.mobile.claims.util.masking.ogrn;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Legal entity ogrn(Ogrnip) has 15 digits. Example: 123456789098765 Masked: 12*********8765
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckOgrnIPMaskingTest implements MaskingTest {

  @Test
  void checkMaskingOgrnFoundEndOfLineTest(CapturedOutput output) {
    String ogrn = "123456789098765";
    String expectedMasked = "12*********8765";
    log.debug("OGRN found in organization: {}", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingActiveSessionTest(CapturedOutput output) {
    String inn = "1111111111";
    String ogrn = "123456789098765";
    log.debug("Active session: SessionInfo(mdmCode=111, orgInfo=OrgInfo(inn={}, ogrn={}))", inn,
        ogrn);

    String out = output.getOut();
    String expectedMaskedInn = "11******11";
    String expectedMaskedOgrn = "12*********8765";

    assertFalse(out.contains(inn));
    assertFalse(out.contains(ogrn));

    assertTrue(out.contains(expectedMaskedInn));
    assertTrue(out.contains(expectedMaskedOgrn));
  }

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String ogrn = "\":[{\"ogrn\":\"123456789098765\",\"";
    String expectedMasked = "\":[{\"ogrn\":\"12*********8765\",\"";
    log.info("Secret information: [{}]", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String ogrn = "123456789098765";
    String expectedMasked = "12*********8765";
    log.info("Secret information: [{}]", ogrn);
    String out = output.getOut();
    assertFalse(out.contains(ogrn));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String ogrnFirst = "111111111111111";
    String expectedMaskedFirst = "11*********1111";
    String ogrnSecond = "222222222222222";
    String expectedMaskedSecond = "22*********2222";
    log.info("Secret information: ogrnFirst: [{}], ogrnSecond: [{}]", ogrnFirst, ogrnSecond);

    String out = output.getOut();
    assertFalse(out.contains(ogrnFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(ogrnSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
