package ru.vtb.tsp.spec.mobile.claims.util.masking.account;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Account number has 20 digits. Example: 12345678901234567890 Masked: 1234************7890
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckAccountMaskingTest implements MaskingTest {

  @Test
  void checkMaskingAccountFilteredInResultMapEndOfLineTest(CapturedOutput output) {
    String accountNumber = "12345678901234567890";
    String expectedMasked = "1234************7890";
    log.debug("AccountServiceImpl : Filtered account in result map : {}", accountNumber);
    String out = output.getOut();
    assertFalse(out.contains(accountNumber));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingAccountFilteredEndOfLineTest(CapturedOutput output) {
    String accountNumber = "12345678901234567890";
    String expectedMasked = "1234************7890";
    log.debug("AccountServiceImpl : Filtered account : {}", accountNumber);
    String out = output.getOut();
    assertFalse(out.contains(accountNumber));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String accountNumber = "\":[{\"accountNumber\":\"12345678901234567890\",\"";
    String expectedMasked = "\":[{\"accountNumber\":\"1234************7890\",\"";
    log.info("Secret information: [{}]", accountNumber);
    String out = output.getOut();
    assertFalse(out.contains(accountNumber));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String accountNumber = "12345678901234567890";
    String expectedMasked = "1234************7890";
    log.info("Secret information: [{}]", accountNumber);
    String out = output.getOut();
    assertFalse(out.contains(accountNumber));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String accountNumberFirst = "00000000000000000000";
    String expectedMaskedFirst = "0000************0000";
    String accountNumberSecond = "12341111111111115678";
    String expectedMaskedSecond = "1234************5678";

    log.info("Secret information: accountNumberFirst: [{}], accountSecond: [{}]",
        accountNumberFirst, accountNumberSecond);
    String out = output.getOut();
    assertFalse(out.contains(accountNumberFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(accountNumberSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }

  @Test
  public void checkMaskingNotAppliedSizeIsSmallerTest(CapturedOutput output) {
    String accountNumber = "6666666666666666666";
    log.info("Secret information: accountNumber: [{}]", accountNumber);
    String out = output.getOut();
    assertTrue(out.contains(accountNumber));
  }

  @Test
  public void checkMaskingNotAppliedLastSymbolIsNotDigitTest(CapturedOutput output) {
    String accountNumber = "6666666666666666666B";
    log.info("Secret information: accountNumber: [{}]", accountNumber);
    String out = output.getOut();
    assertTrue(out.contains(accountNumber));
  }

  @Test
  public void checkNotMaskingOperationIdTest(CapturedOutput output) {
    String operationId = "A2073094700406010000055FDC58F4FF";
    log.debug("Changing status for payment operation : [{}] ", operationId);
    String out = output.getOut();
    assertTrue(out.contains(operationId));
  }

  @Test
  public void checkNotMaskingOperationIdInQuotesTest(CapturedOutput output) {
    String operationId = "\":[{\"accountNumber\":\"A2073094700406010000055FDC58F4FF\",\"";
    log.info("Secret information: [{}]", operationId);
    String out = output.getOut();
    assertTrue(out.contains(operationId));
  }

  @Test
  public void checksNotMaskIfHasCharLeftTest(CapturedOutput output) {
    String word = "A12345678901234567890";
    log.debug("Changing status for payment operation : [{}] ", word);
    String out = output.getOut();
    assertTrue(out.contains(word));
  }


  @Test
  public void checksNotMaskIfHasCharRightTest(CapturedOutput output) {
    String word = "12345678901234567890B";
    log.debug("Changing status for payment operation : [{}] ", word);
    String out = output.getOut();
    assertTrue(out.contains(word));
  }

  @Test
  public void checksNotMaskBetweenCharsTest(CapturedOutput output) {
    String word = "A12345678901234567890B";
    log.debug("Changing status for payment operation : [{}] ", word);
    String out = output.getOut();
    assertTrue(out.contains(word));
  }
}
