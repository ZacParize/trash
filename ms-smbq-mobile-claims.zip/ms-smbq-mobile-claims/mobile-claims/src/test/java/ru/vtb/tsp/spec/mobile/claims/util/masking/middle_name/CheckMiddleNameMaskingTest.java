package ru.vtb.tsp.spec.mobile.claims.util.masking.middle_name;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckMiddleNameMaskingTest implements MaskingTest {

  @Test
  public void checkMaskingSessionDataTest(CapturedOutput output) {
    String middleName = "Фамилия";
    String expectedMasked = "Ф*****я";
    log.debug("\"middleName\\\":\\\"{}\\\"", middleName);
    String out = output.getOut();
    assertFalse(out.contains(middleName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  void checkMaskingWorkflowPutOrganizationTest(CapturedOutput output) {
    String middleName = "Александрович";
    String expectedMasked = "Ал********вич";
    log.debug("{\"lastName\":\"Фамилия\",\"firstName\":\"Имя\",\"middleName\":\"{}\",\"sex\":\"F\",\"birthday\":\"1962-01-20\",\"phone\":\"3333333333\",\"email\":\"boss@ya.ru\",\"nonResident\":false,\"ps\"", middleName);
    String out = output.getOut();
    assertFalse(out.contains(middleName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String middleName = "Александрович";
    String expectedMasked = "Ал********вич";
    log.debug("Ofd1DataApi#submitForm {\"middleName\":\"{}\"", middleName);
    String out = output.getOut();
    assertFalse(out.contains(middleName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String middleName = "Александрович";
    String expectedMasked = "Ал********вич";
    log.debug("middleName: {}", middleName);
    String out = output.getOut();
    assertFalse(out.contains(middleName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String middleNameFirst = "Александрович";
    String expectedMaskedFirst = "Ал********вич";
    String middleNameSecond = "Андреевич";
    String expectedMaskedSecond = "А******ич";

    log.info("some text middleName: [{}], middleName: [{}]", middleNameFirst, middleNameSecond);
    String out = output.getOut();
    assertFalse(out.contains(middleNameFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(middleNameSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
