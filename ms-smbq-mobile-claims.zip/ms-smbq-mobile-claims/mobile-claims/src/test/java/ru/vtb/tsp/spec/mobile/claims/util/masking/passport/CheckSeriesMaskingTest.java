package ru.vtb.tsp.spec.mobile.claims.util.masking.passport;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckSeriesMaskingTest implements MaskingTest {

  private static final String MOCK_SERIES = "9999";
  private static final String MASKED_MOCK_NUM = "9***";

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String series = String.format("\"series\":\"%s\",\",", MOCK_SERIES);
    String expectedMasked = String.format("\"series\":\"%s\",\",", MASKED_MOCK_NUM);
    log.info("Secret information: [{}]", series);
    String out = output.getOut();
    assertFalse(out.contains(series));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    log.info("series: [{}]", MOCK_SERIES);
    String out = output.getOut();
    assertFalse(out.contains(MOCK_SERIES));
    assertTrue(out.contains(MASKED_MOCK_NUM));
  }

  @Test
  public void checkMasking_notResidentEndingWithChars_messageMasked(CapturedOutput output) {
    String series = "ABC666de";
    String maskedSeries = "A*****de";
    log.info("series: [{}]", series);
    String out = output.getOut();
    assertFalse(out.contains(series));
    assertTrue(out.contains(maskedSeries));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String seriesFirst = "1111";
    String expectedMaskedFirst = "1***";
    String seriesSecond = "2222";
    String expectedMaskedSecond = "2***";

    log.info("Secret information: series: [{}], series: [{}]",
        seriesFirst, seriesSecond);
    String out = output.getOut();
    assertFalse(out.contains(seriesFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(seriesSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
