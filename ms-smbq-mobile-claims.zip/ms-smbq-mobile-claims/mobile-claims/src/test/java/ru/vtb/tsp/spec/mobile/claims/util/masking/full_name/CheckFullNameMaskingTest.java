package ru.vtb.tsp.spec.mobile.claims.util.masking.full_name;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckFullNameMaskingTest implements MaskingTest {

  @Test
  public void checkMaskingSessionDataFirstNameAndMiddleNameTest(CapturedOutput output) {
    String fullName = "Имя Фамилия";
    String expectedMasked = "Им*******ия";
    log.debug("\"fullName\\\":\\\"{}\\\"", fullName);
    String out = output.getOut();
    assertFalse(out.contains(fullName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  public void checkMaskingSessionDataTest(CapturedOutput output) {
    String fullName = "Найдинов МЕНЯ Наденович";
    String expectedMasked = "Найд**************нович";
    log.debug("\"fullName\\\":\\\"{}\\\"", fullName);
    String out = output.getOut();
    assertFalse(out.contains(fullName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String fullName = "Найдинов МЕНЯ Наденович";
    String expectedMasked = "Найд**************нович";
    log.debug("\"fullName\":\"{}\",", fullName);
    String out = output.getOut();
    assertFalse(out.contains(fullName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String fullName = "Александров Александр Александрович";
    String expectedMasked = "Алексан*********************ндрович";
    log.debug("fullName: {}", fullName);
    String out = output.getOut();
    assertFalse(out.contains(fullName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String fullNameFirst = "Александров Александр Александрович";
    String expectedMaskedFirst = "Алексан*********************ндрович";
    String fullNameSecond = "Имя Фамилия Отчество";
    String expectedMaskedSecond = "Имя ************ство";

    log.info("some text fullName: [{}], fullName: [{}]", fullNameFirst, fullNameSecond);
    String out = output.getOut();
    assertFalse(out.contains(fullNameFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(fullNameSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
