package ru.vtb.tsp.spec.mobile.claims.util.masking;

import org.springframework.boot.test.system.CapturedOutput;

/**
 * The class you should implement for test, if you add a new maskingPattern in
 * application/src/main/resources/logback-spring.xml
 */
public interface MaskingTest {

  @SuppressWarnings("unused")
  void checkMasking_inQuotes_messageMasked(CapturedOutput output);

  @SuppressWarnings("unused")
  void checkMasking_oneMatch_messageMasked(CapturedOutput output);

  @SuppressWarnings("unused")
  void checkMasking_twoMatches_messageMasked(CapturedOutput output);

}
