package ru.vtb.tsp.spec.mobile.claims.util.masking.name;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckNameMaskingTest implements MaskingTest {

  @Test
  @Override
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String firstName = "Найдинов МЕНЯ Наденович";
    String expectedMasked = "Найд**************нович";
    log.debug("\"name\":\"{}\",", firstName);
    String out = output.getOut();
    assertFalse(out.contains(firstName));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String name = "Александров Александр Александрович";
    String expectedMasked = "Алексан*********************ндрович";
    log.debug("name: {}", name);
    String out = output.getOut();
    assertFalse(out.contains(name));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  @Override
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String nameFirst = "Александров Александр Александрович";
    String expectedMaskedFirst = "Алексан*********************ндрович";
    String nameSecond = "Имя Фамилия Отчество";
    String expectedMaskedSecond = "Имя ************ство";

    log.info("some text name: [{}], name: [{}]", nameFirst, nameSecond);
    String out = output.getOut();
    assertFalse(out.contains(nameFirst));
    assertTrue(out.contains(expectedMaskedFirst));
    assertFalse(out.contains(nameSecond));
    assertTrue(out.contains(expectedMaskedSecond));
  }
}
