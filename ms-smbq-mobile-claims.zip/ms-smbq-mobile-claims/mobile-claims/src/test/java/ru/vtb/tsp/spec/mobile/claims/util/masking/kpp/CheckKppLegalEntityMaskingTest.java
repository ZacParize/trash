package ru.vtb.tsp.spec.mobile.claims.util.masking.kpp;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.system.CapturedOutput;
import org.springframework.boot.test.system.OutputCaptureExtension;
import ru.vtb.tsp.spec.mobile.claims.config.config.TestClass;
import ru.vtb.tsp.spec.mobile.claims.util.masking.MaskingTest;

/**
 * Legal entity hpp has 9 digits. Example: 123456789 Masked: 1******89
 */
@Slf4j
@SpringBootTest(
    classes = {TestClass.class},
    webEnvironment = SpringBootTest.WebEnvironment.NONE
)
@ExtendWith(OutputCaptureExtension.class)
public class CheckKppLegalEntityMaskingTest implements MaskingTest {

  @Override
  @Test
  public void checkMasking_inQuotes_messageMasked(CapturedOutput output) {
    String kpp = "123456789";
    String expectedMasked = "1******89";
    log.info("\\\"kpp\\\":\\\"{}\\\"", kpp);
    String out = output.getOut();
    assertFalse(out.contains(kpp));
    assertTrue(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_oneMatch_messageMasked(CapturedOutput output) {
    String kpp = "123456789";
    String expectedMasked = "1******89";
    log.info("kpp : {}", kpp);
    String out = output.getOut();
    assertFalse(out.contains(kpp));
    assertTrue(out.contains(expectedMasked));
  }

  @Test
  public void checkMaskingNotMaskingPpSequenceTest(CapturedOutput output) {
    String kpp = "123456789";
    String expectedMasked = "1******89";
    log.info("pp: {}", kpp);
    String out = output.getOut();
    assertTrue(out.contains(kpp));
    assertFalse(out.contains(expectedMasked));
  }

  @Override
  @Test
  public void checkMasking_twoMatches_messageMasked(CapturedOutput output) {
    String kpp = "123456789";
    String expectedMasked = "1******89";
    log.info("kpp={}, KPP : {}", kpp, kpp);
    String out = output.getOut();
    assertFalse(out.contains(kpp));
    assertTrue(out.contains(expectedMasked));
  }
}
