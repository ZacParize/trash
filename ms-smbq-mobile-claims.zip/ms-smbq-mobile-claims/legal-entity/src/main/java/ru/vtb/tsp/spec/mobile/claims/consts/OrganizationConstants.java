package ru.vtb.tsp.spec.mobile.claims.consts;

public interface OrganizationConstants {

  String FACT_ADDRESS_TYPE_CODE = "fact";

  String PERMANENT_ADDRESS_TYPE_CODE = "permanent";

  String PHONE_PATTERN = "^(\\d{3})\\s(\\d{7})$";

  String MAIN_PHONE = "MainPhoneBO";

  String PHONE = "Phone";

  String MOBILE_PHONE = "PhoneMobile";

  String COUNTRY_CODE = "7";

  String PASSPORT_RUSSIA_SUBTYPE_CODE = "PassportRussia";

  String EMAIL = "Email";

  String EMAIL_PERSONAL = "EMAIL_PERSONAL";

  String ORGANIZATION_PHONE_TYPE = "Phone";

  String ORGANIZATION_EMAIL_NOTIFICATION_TYPE = "EMAIL_NOTIFICATION";

}
