package ru.vtb.tsp.spec.mobile.claims.mapper;

import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.COUNTRY_CODE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.EMAIL;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.EMAIL_PERSONAL;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.FACT_ADDRESS_TYPE_CODE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.MAIN_PHONE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.MOBILE_PHONE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.PASSPORT_RUSSIA_SUBTYPE_CODE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.PERMANENT_ADDRESS_TYPE_CODE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.PHONE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.PHONE_PATTERN;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.NullValuePropertyMappingStrategy;
import org.mapstruct.ReportingPolicy;
import org.springframework.util.CollectionUtils;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonCitizenRelationCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientAddressCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientContactCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientDocCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientPhoneCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.common.enums.Gender;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationDataHead;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrganizationHeadMapper {

//  @Mapping(target = "birthday", source = "relatedClient.birthDate", qualifiedByName = "birthDate")
  @Mapping(target = "gender", source = "relatedClient.sexCode", qualifiedByName = "gender")
  @Mapping(target = "series", source = "relatedClient.documents", qualifiedByName = "docSeries")
  @Mapping(target = "number", source = "relatedClient.documents", qualifiedByName = "docNumber")
  @Mapping(target = "passportIssueDate", source = "relatedClient.documents", qualifiedByName = "issueDate")
  @Mapping(target = "birthPlace", source = "relatedClient.birthPlace")
  @Mapping(target = "email", source = "relatedClient.contacts", qualifiedByName = "headEmail")
  @Mapping(target = "firstName", source = "relatedClient.firstName")
  @Mapping(target = "lastName", source = "relatedClient.lastName")
  @Mapping(target = "middleName", source = "relatedClient.middleName")
  @Mapping(target = "passportIssuer", source = "relatedClient.documents", qualifiedByName = "issuer")
  @Mapping(target = "passportIssuedId", source = "relatedClient.documents", qualifiedByName = "issuerCode")
  @Mapping(target = "phone", source = "relatedClient.phoneNumbers", qualifiedByName = "phoneNumbers")
  @Mapping(target = "position", source = "relatedClient.publicPersonInfo.publicPersonPosition")
  @Mapping(target = "registrationPlace", source = "relatedClient.addresses", qualifiedByName = "citizenAddressFull")
  @Mapping(target = "isResident", expression = "java(citizenRel.getRelatedClient().getIsResident())")
  @Mapping(target = "isEio", source = "relatedClient.isEIO")
  @Mapping(target = "country", ignore = true)
  OrganizationDataHead toResponse(EtalonCitizenRelationCsocResponseDto citizenRel);

  @Named("birthDate")
  default String birthDate(ZonedDateTime dateTime) {
    if (dateTime == null) {
      return null;
    }
    return dateTime.toLocalDate().toString();
  }

  @Named("gender")
  default Gender getGender(String sexCode) {
    if (sexCode != null && sexCode.equalsIgnoreCase(Gender.FEMALE.name())) {
      return Gender.FEMALE;
    } else {
      return Gender.MALE;
    }
  }

  @Named("docSeries")
  default String docSeries(List<EtalonClientDocCsocResponseDto> documents) {
    if (CollectionUtils.isEmpty(documents)) {
      return null;
    }
    var document = documents.stream()
        .filter(doc -> doc.getDocSubTypeCode() != null && doc.getDocSubTypeCode()
            .equalsIgnoreCase(PASSPORT_RUSSIA_SUBTYPE_CODE))
        .findFirst().orElse(null);
    if (document == null || document.getDocSeries() == null) {
      return null;
    }
    return document.getDocSeries().substring(0, 2) + document.getDocSeries().substring(3, 5);
  }

  @Named("docNumber")
  default String docNumber(List<EtalonClientDocCsocResponseDto> documents) {
    if (CollectionUtils.isEmpty(documents)) {
      return null;
    }
    var document = documents.stream()
        .filter(doc -> doc.getDocSubTypeCode() != null && doc.getDocSubTypeCode()
            .equalsIgnoreCase(PASSPORT_RUSSIA_SUBTYPE_CODE))
        .findFirst().orElse(null);
    if (document == null || document.getDocNumber() == null) {
      return null;
    }
    return document.getDocNumber();
  }

  @Named("issueDate")
  default String issueDate(List<EtalonClientDocCsocResponseDto> documents) {
    if (CollectionUtils.isEmpty(documents)) {
      return null;
    }
    var document = documents.stream()
        .filter(doc -> doc.getDocSubTypeCode() != null && doc.getDocSubTypeCode()
            .equalsIgnoreCase(PASSPORT_RUSSIA_SUBTYPE_CODE))
        .findFirst().orElse(null);
    if (document == null || document.getIssueDate() == null) {
      return null;
    }
    return document.getIssueDate().toLocalDate().toString();
  }

  @Named("headEmail")
  default String getHeadEmail(List<EtalonClientContactCsocResponseDto> contacts) {
    if (CollectionUtils.isEmpty(contacts)) {
      return null;
    }
    var contact = contacts.stream()
        .filter(
            c -> c.getContactTypeCode() != null && c.getContactTypeCode().equalsIgnoreCase(EMAIL))
        .findFirst().orElse(null);
    if (contact == null) {
      contact = contacts.stream()
          .filter(c -> c.getContactTypeCode() != null && c.getContactTypeCode()
              .equalsIgnoreCase(EMAIL_PERSONAL))
          .findFirst().orElse(null);
    }

    if (contact == null) {
      contact = contacts.stream()
          .filter(c -> c.getValue() != null && !c.getValue().isEmpty())
          .findFirst().orElse(null);
    }

    if (contact == null || contact.getValue() == null) {
      return null;
    }
    return contact.getValue().toLowerCase();
  }

  @Named("issuer")
  default String issuer(List<EtalonClientDocCsocResponseDto> documents) {
    if (CollectionUtils.isEmpty(documents)) {
      return null;
    }
    var document = documents.stream()
        .filter(doc -> doc.getDocSubTypeCode() != null && doc.getDocSubTypeCode()
            .equalsIgnoreCase(PASSPORT_RUSSIA_SUBTYPE_CODE))
        .findFirst().orElse(null);
    if (document == null || document.getIssuer() == null) {
      return null;
    }
    return document.getIssuer();
  }

  @Named("issuerCode")
  default String issuerCode(List<EtalonClientDocCsocResponseDto> documents) {
    if (CollectionUtils.isEmpty(documents)) {
      return null;
    }
    var document = documents.stream()
        .filter(doc -> doc.getDocSubTypeCode() != null && doc.getDocSubTypeCode()
            .equalsIgnoreCase(PASSPORT_RUSSIA_SUBTYPE_CODE))
        .findFirst().orElse(null);
    if (document == null || document.getIssuerCode() == null) {
      return null;
    }
    return document.getIssuerCode().substring(0, 3) + document.getIssuerCode().substring(4, 7);
  }

  @Named("phoneNumbers")
  default String getPhoneNumbers(List<EtalonClientPhoneCsocResponseDto> phones) {
    if (CollectionUtils.isEmpty(phones)) {
      return null;
    }
    var phone = phones.stream()
        .filter(
            p -> p.getPhoneTypeCode() != null && p.getPhoneTypeCode().equalsIgnoreCase(MAIN_PHONE))
        .findFirst().orElse(null);
    if (phone == null) {
      phone = phones.stream()
          .filter(p -> p.getPhoneTypeCode() != null && p.getPhoneTypeCode().equalsIgnoreCase(PHONE))
          .findFirst().orElse(null);
    }
    if (phone == null) {
      phone = phones.stream()
          .filter(p -> p.getPhoneTypeCode() != null && p.getPhoneTypeCode()
              .equalsIgnoreCase(MOBILE_PHONE))
          .findFirst().orElse(null);
    }
    if (phone == null || phone.getPhoneValue() == null) {
      return null;
    }
    Pattern pattern = Pattern.compile(PHONE_PATTERN);
    Matcher matcher = pattern.matcher(phone.getPhoneValue());
    if (!matcher.matches()) {
      return null;
    }

    return COUNTRY_CODE + phone.getPhoneValue().substring(0, 3) + phone.getPhoneValue()
        .substring(4, 11);
  }

  @Named("citizenAddressFull")
  default String citizenAddressFull(List<EtalonClientAddressCsocResponseDto> addresses) {
    if (CollectionUtils.isEmpty(addresses)) {
      return null;
    }
    var address = addresses.stream()
        .filter(a -> a.getAddressTypeCode() != null && a.getAddressTypeCode()
            .equalsIgnoreCase(PERMANENT_ADDRESS_TYPE_CODE))
        .findFirst().orElse(null);
    if (address == null) {
      address = addresses.stream()
          .filter(a -> a.getAddressTypeCode() != null && a.getAddressTypeCode()
              .equalsIgnoreCase(FACT_ADDRESS_TYPE_CODE))
          .findFirst().orElse(null);
    }
    if (address == null || address.getAddressFull() == null) {
      return null;
    }
    return !Objects.requireNonNull(address.getAddressFull()).isEmpty() ? address.getAddressFull()
        : "";
  }

}
