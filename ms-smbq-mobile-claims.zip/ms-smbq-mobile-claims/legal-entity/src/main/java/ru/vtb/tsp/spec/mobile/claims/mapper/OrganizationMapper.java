package ru.vtb.tsp.spec.mobile.claims.mapper;

import static java.util.Objects.isNull;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.ORGANIZATION_EMAIL_NOTIFICATION_TYPE;
import static ru.vtb.tsp.spec.mobile.claims.consts.OrganizationConstants.ORGANIZATION_PHONE_TYPE;

import java.util.Collection;
import java.util.Optional;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientAddressCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientContactCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientPhoneCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationData;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrganizationMapper {


  @Mapping(target = "factAddress", source = "legalEntity", qualifiedByName = "factAddress")
  @Mapping(target = "addressesMatch", source = "legalEntity", qualifiedByName = "addressesMatch")
  @Mapping(target = "fullTitle", source = "legalEntity.name")
  @Mapping(target = "inn", source = "legalEntity.tin")
  @Mapping(target = "kpp", source = "legalEntity.kpp")
  @Mapping(target = "legalAddress", source = "legalEntity", qualifiedByName = "organizationAddress")
  @Mapping(target = "ogrn", source = "legalEntity.registryNumber")
  @Mapping(target = "okato", source = "legalEntity.okato")
  @Mapping(target = "okpo", source = "legalEntity.okpo")
  @Mapping(target = "okved", source = "legalEntity.okved")
  @Mapping(target = "email", source = "legalEntity", qualifiedByName = "email")
  @Mapping(target = "phone", source = "legalEntity", qualifiedByName = "phone")
  @Mapping(target = "opf", source = "legalEntity.mdmOpfCode")
  OrganizationData toResponse(EtalonClientSnapshotCsocResponseDto legalEntity);


  @Named("factAddress")
  default String getFactOrganizationAddress(EtalonClientSnapshotCsocResponseDto legalEntity) {
    return Optional.ofNullable(legalEntity.getAddresses()).stream()
        .flatMap(Collection::stream)
        .filter(a -> a.getAddressTypeCode().equalsIgnoreCase("fact"))
        .findFirst()
        .map(EtalonClientAddressCsocResponseDto::getAddressFull)
        .orElse(null);
  }

  @Named("addressesMatch")
  default boolean isAddressesMatched(EtalonClientSnapshotCsocResponseDto legalEntity) {
    var actualAddress = getFactOrganizationAddress(legalEntity);
    var legalAddress = getOrganizationLegalAddress(legalEntity);
    if (isNull(actualAddress) || isNull(legalAddress)) {
      return false;
    }
    return actualAddress.equalsIgnoreCase(legalAddress);
  }

  @Named("organizationAddress")
  default String getOrganizationLegalAddress(EtalonClientSnapshotCsocResponseDto legalEntity) {
    return Optional.ofNullable(legalEntity.getAddresses()).stream()
        .flatMap(Collection::stream)
        .filter(a -> a.getAddressTypeCode().equalsIgnoreCase("post"))
        .findFirst()
        .map(EtalonClientAddressCsocResponseDto::getAddressFull)
        .orElse(null);
  }

  @Named("phone")
  default String phone(EtalonClientSnapshotCsocResponseDto legalEntity) {
    return legalEntity.getPhoneNumbers() == null ? "" : legalEntity.getPhoneNumbers().stream()
            .filter(p -> p.getPhoneTypeCode().equalsIgnoreCase(ORGANIZATION_PHONE_TYPE))
            .findFirst()
            .map(EtalonClientPhoneCsocResponseDto::getPhoneValue)
            .orElse("");
  }

  @Named("email")
  default String email(EtalonClientSnapshotCsocResponseDto legalEntity) {
    return legalEntity.getContacts() == null ? "" : legalEntity.getContacts().stream()
        .filter(c -> c.getContactTypeCode().equalsIgnoreCase(ORGANIZATION_EMAIL_NOTIFICATION_TYPE))
        .findFirst()
        .map(EtalonClientContactCsocResponseDto::getValue)
        .orElse("");
  }
}
