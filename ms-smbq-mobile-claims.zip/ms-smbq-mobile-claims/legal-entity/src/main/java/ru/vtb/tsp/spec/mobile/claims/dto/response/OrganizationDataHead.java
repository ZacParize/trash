package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType;
import ru.vtb.tsp.spec.mobile.claims.common.enums.Gender;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class OrganizationDataHead {

  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
  @Size(min = 10, max = 10)
  private String birthday;

  @NotNull
  private Gender gender;

  @Pattern(regexp = "^\\d{4}$", groups = ValidationType.Resident.class)
  @Pattern(regexp = "^[a-zA-Z0-9\\-\\s]{0,8}$", groups = ValidationType.NotResident.class)
  private String series;

  @Pattern(regexp = "^\\d{6}$", groups = ValidationType.Resident.class)
  @Pattern(regexp = "^[a-zA-Z0-9\\-]{4,16}$", groups = ValidationType.NotResident.class)
  private String number;

  @Pattern(regexp = "^[0-9]{4}-[0-9]{2}-[0-9]{2}$")
  private String passportIssueDate;

  @Pattern(regexp = "^[а-яёА-ЯЁ0-9]( ?([-а-яёА-ЯЁ0-9:_;.,+/?!()№\\\"\\\\\\\\]+ )*[-а-яёА-ЯЁ0-9:_;.,+/?!()№\\\"\\\\\\\\])*$")
  @Size(max = 255)
  private String birthPlace;

  @Pattern(regexp = "^(([^<>()\\[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$")
  private String email;

  @Pattern(regexp = "^[а-яёА-ЯЁ][-а-яёА-ЯЁ]+$")
  @Size(max = 54)
  private String firstName;

  @Pattern(regexp = "^([а-яёА-ЯЁ][-а-яёА-ЯЁ]+( [а-яёА-ЯЁ][-а-яёА-ЯЁ]+)?)$")
  @Size(max = 54)
  private String middleName;

  @Pattern(regexp = "^[а-яёА-ЯЁ][-а-яёА-ЯЁ]+$")
  @Size(max = 54)
  private String lastName;

  @Pattern(regexp = "^[а-яёА-ЯЁ0-9]( ?([-а-яёА-ЯЁ0-9:_;.,+/?!()№\\\"\\\\\\\\]+ )*[-а-яёА-ЯЁ0-9:_;.,+/?!()№\\\"\\\\\\\\])*$")
  @Size(max = 255)
  private String passportIssuer;

  @Pattern(regexp = "^(\\d{3}\\-\\d{3})|\\d{6}$")
  private String passportIssuedId;

  @Pattern(regexp = "^\\d{5,20}$")
  private String phone;

  private String position;

  @Size(min = 10, groups = ValidationType.NotResident.class)
  private String registrationPlace;

  private Boolean isResident;

  private Boolean isEio;

  @Pattern(regexp = "^[а-яёА-ЯЁ\\-\\s\\']{2,50}$", message = "Название страны указывается на кириллице, может содержать тире, пробелы")
  private String country;

}
