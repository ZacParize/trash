package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import javax.validation.constraints.Pattern;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class OrganizationData {

  private String factAddress;

  private Boolean addressesMatch;

  @Pattern(regexp = "^(([^<>()\\[\\]\\\\.,;:\\s@\\\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\\\"]+)*)|(\\\".+\\\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$")
  private String email;

  private String fullTitle;

  @Pattern(regexp = "^\\d{10}|\\d{12}$", message = "ИНН имеет некорректный формат")
  private String inn;

  @Pattern(regexp = "^\\d{9}$", message = "КПП имеет некорректный формат")
  private String kpp;

  private String legalAddress;

  @Pattern(regexp = "^\\d{13}$", message = "ОГРН имеет некорректный формат")
  private String ogrn;

  @Pattern(regexp = "^\\d{11}$")
  private String okato;

  @Pattern(regexp = "^(\\d{8}|\\d{10})$")
  private String okpo;

  @Pattern(regexp = "^\\d{2}(\\.\\d{1,2}){0,2}$")
  private String okved;

  private String opf;

  @Pattern(regexp = "^\\d{10}")
  private String phone;

}
