package ru.vtb.tsp.spec.mobile.claims.service;

import org.springframework.http.HttpHeaders;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ResponseWithValidationInfo;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationData;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationDataHead;

public interface OrganizationService {

  EtalonClientSnapshotCsocResponseDto getLegalEntity(Long mdmCode);

  ResponseWithValidationInfo<OrganizationData> getOrganizationData(HttpHeaders headers);

  ResponseWithValidationInfo<OrganizationDataHead> getOrganizationHead(HttpHeaders headers);

}
