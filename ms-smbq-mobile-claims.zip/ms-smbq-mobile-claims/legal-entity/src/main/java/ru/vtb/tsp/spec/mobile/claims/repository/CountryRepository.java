package ru.vtb.tsp.spec.mobile.claims.repository;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.spec.mobile.claims.entity.CountryEntity;

@Repository
public interface CountryRepository extends JpaRepository<CountryEntity, Long> {

  Optional<CountryEntity> findByIsoA2Code(String isoA2Code);

}