package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ResponseWithValidationInfo;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationData;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationDataHead;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.OrganizationService;

@Slf4j
@RestController
@RequestMapping("${api-v1.root}/organization")
@RequiredArgsConstructor
@Api(value = "Organization controller", tags = "organization-controller")
public class OrganizationController {

  private final OrganizationService csocService;

  @Logging
  @GetMapping
  @ApiOperation(value = "Получение данных организации")
  public ResponseWithValidationInfo<OrganizationData> organizationData(@RequestHeader HttpHeaders headers) {
    return csocService.getOrganizationData(headers);
  }

  @Logging
  @GetMapping("/head")
  @ApiOperation(value = "Получение данных руководителя организации")
  public ResponseWithValidationInfo<OrganizationDataHead> organizationHead(@RequestHeader HttpHeaders headers) {
    return csocService.getOrganizationHead(headers);
  }
}
