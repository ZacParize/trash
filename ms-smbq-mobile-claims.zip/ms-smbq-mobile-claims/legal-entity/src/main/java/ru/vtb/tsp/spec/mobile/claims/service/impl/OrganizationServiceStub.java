package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ResponseWithValidationInfo;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationData;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationDataHead;
import ru.vtb.tsp.spec.mobile.claims.service.OrganizationService;

@RequiredArgsConstructor
@Service
@Profile("etalon_stub")
public class OrganizationServiceStub implements OrganizationService {

  @Override
  public EtalonClientSnapshotCsocResponseDto getLegalEntity(Long mdmCode) {
    return EtalonClientSnapshotCsocResponseDto.builder()
        .mdmCode(mdmCode)
        .firstName("Уилсон")
        .build();
  }

  @Override
  public ResponseWithValidationInfo<OrganizationData> getOrganizationData(HttpHeaders headers) {
    var legalEntity = OrganizationData.builder()
//        .fullTitle("Уилсон")
        .build();
    return new ResponseWithValidationInfo<>(legalEntity);
  }

  @Override
  public ResponseWithValidationInfo<OrganizationDataHead> getOrganizationHead(HttpHeaders headers) {
    var legalHead = OrganizationDataHead.builder()
//        .firstName("Уилсон")
        .build();
    return new ResponseWithValidationInfo<>(legalHead);
  }
}
