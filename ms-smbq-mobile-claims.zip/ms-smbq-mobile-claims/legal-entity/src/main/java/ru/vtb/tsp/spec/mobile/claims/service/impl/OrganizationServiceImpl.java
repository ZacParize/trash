package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.constant.EtalonSearchDataBlockCsocRequestEnum;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.request.EtalonGetCsocRequestDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.service.CsocIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ResponseWithValidationInfo;
import ru.vtb.tsp.spec.mobile.claims.common.exception.EntityNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationData;
import ru.vtb.tsp.spec.mobile.claims.dto.response.OrganizationDataHead;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.mapper.OrganizationHeadMapper;
import ru.vtb.tsp.spec.mobile.claims.mapper.OrganizationMapper;
import ru.vtb.tsp.spec.mobile.claims.repository.CountryRepository;
import ru.vtb.tsp.spec.mobile.claims.service.OrganizationService;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;

import java.util.Set;

@RequiredArgsConstructor
@Service
@Profile("!etalon_stub")
@Slf4j
public class OrganizationServiceImpl implements OrganizationService, CheckIntegrationService {

  private final CsocIntegrationService csocIntegrationService;
  private final SessionService sessionService;
  private final OrganizationMapper organizationMapper;
  private final OrganizationHeadMapper organizationHeadMapper;
  private final CountryRepository countryRepository;

  private static final String HEAD_TYPE_CODE = "EIO";

  private static final String INTEGRATION_NAME = "Карточка ЮЛ";

  @Override
  public ResponseWithValidationInfo<OrganizationData> getOrganizationData(HttpHeaders headers) {
    var mdmCode = sessionService.getSessionData(headers).getMdmCode();
    try {
      var legalEntity = getLegalEntity(Long.valueOf(mdmCode));
      return new ResponseWithValidationInfo<>(organizationMapper.toResponse(legalEntity),
          getValidationType(legalEntity));
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  public ResponseWithValidationInfo<OrganizationDataHead> getOrganizationHead(HttpHeaders headers) {
    var mdmCode = sessionService.getSessionData(headers).getMdmCode();
    try {
      var legalEntity = getLegalEntity(Long.valueOf(mdmCode));
      var legalHead = legalEntity.getRelWithCitizen().stream()
              .filter(relation -> CollectionUtils.isNotEmpty(relation.getRelationTypes()))
              .filter(relation -> relation.getRelationTypes().stream()
                      .anyMatch(type -> type.getRelationTypeCode().equalsIgnoreCase(HEAD_TYPE_CODE)))
              .findFirst()
              .orElse(legalEntity.getRelWithCitizen().stream().findFirst().orElseThrow(() -> new EntityNotFoundException("Руководитель не найден")));
      var mappedHead = organizationHeadMapper.toResponse(legalHead);
      if (legalHead.getRelatedClient() != null) {
        log.debug("Searching for country in DB by code: {}",
            legalHead.getRelatedClient().getCountryCode());
        var countryEntity = countryRepository.findByIsoA2Code(
            legalHead.getRelatedClient().getCountryCode());
        countryEntity.ifPresent(c -> mappedHead.setCountry(c.getNameRu()));
      }
      return new ResponseWithValidationInfo<>(mappedHead, getValidationType(legalEntity));
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  public EtalonClientSnapshotCsocResponseDto getLegalEntity(Long mdmCode) {
    try {
      var etalonRequest = EtalonGetCsocRequestDto.builder().mdmCode(mdmCode).requiredDataBlocks(
          Set.of(EtalonSearchDataBlockCsocRequestEnum.MainInfo,
              EtalonSearchDataBlockCsocRequestEnum.Addresses,
              EtalonSearchDataBlockCsocRequestEnum.Contacts,
              EtalonSearchDataBlockCsocRequestEnum.RelatedEntities,
              EtalonSearchDataBlockCsocRequestEnum.OchLinearInfo)).build();
      return csocIntegrationService.getEtalon(etalonRequest).getPayload();
    } catch (Exception e) {
      throw new InvalidExternalSystemResponseException("ЮЛ не найдено, mdmCode: " + mdmCode);
    }
  }

  private Class<? extends ValidationType> getValidationType(EtalonClientSnapshotCsocResponseDto legalEntity) {
    var isResident = legalEntity.getRelWithCitizen().stream().findFirst().get().getRelatedClient()
        .getIsResident();
    return Boolean.TRUE.equals(isResident) ? ValidationType.Resident.class : ValidationType.NotResident.class;
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
      getLegalEntity(123456L);
    } catch (EntityNotFoundException | InvalidExternalSystemResponseException e) {
      return EndpointCheckDto.builder().status(HttpStatus.OK.name()).build();
    } catch (Exception ex) {
      log.error("check-integration organization error" + ExceptionUtils.getStackTrace(ex));
      throw ex;
    }
    return EndpointCheckDto.builder().status(HttpStatus.NOT_ACCEPTABLE.name()).build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
