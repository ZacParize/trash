package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;

import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolverContext;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolverFactory;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverConfig;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverFactory;

@Plugin(name = "JsonMaskingResolverFactory", category = TemplateResolverFactory.CATEGORY)
public final class JsonMaskingResolverFactory implements EventResolverFactory {

    private static final JsonMaskingResolverFactory INSTANCE =
        new JsonMaskingResolverFactory();

    private JsonMaskingResolverFactory() {}

    @PluginFactory
    public static JsonMaskingResolverFactory getInstance() {
        return INSTANCE;
    }

    @Override
    public String getName() {
        return JsonMaskingResolver.getName();
    }

    @Override
    public JsonMaskingResolver create(
        final EventResolverContext context,
        final TemplateResolverConfig config) {
        return new JsonMaskingResolver(config);
    }

}