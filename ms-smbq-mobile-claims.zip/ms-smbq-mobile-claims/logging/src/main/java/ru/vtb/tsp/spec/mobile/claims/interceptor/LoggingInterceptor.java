package ru.vtb.tsp.spec.mobile.claims.interceptor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.lang.reflect.Array;
import java.util.Arrays;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Aspect
@Component
@RequiredArgsConstructor
public class LoggingInterceptor {

  private final ObjectMapper objectMapper;

  @Value("${log.controller.requests:true}")
  private boolean logControllerRequests;

  private void log(final Logger logger, final Logging logging, final String method,
      final String message, final Object... args) {
    if (!logControllerRequests) {
      return;
    }

    var format = method + ": " + message;
    switch (logging.level()) {
      case TRACE -> logger.trace(format, wrapArgs(logging, args));
      case INFO -> logger.info(format, wrapArgs(logging, args));
      case DEBUG -> logger.debug(format, wrapArgs(logging, args));
      case WARN -> logger.warn(format, wrapArgs(logging, args));
      case ERROR, FATAL -> logger.error(format, wrapArgs(logging, args));
      default -> {
      }
    }
  }

  private Object[] wrapArgs(final Logging logging, final Object... args) {
    if (logging.printArrays()) {
      return args;
    }
    var result = new Object[args.length];
    for (int i = 0; i < args.length; i++) {
      if (args[i] != null && args[i].getClass().isArray()) {
        result[i] = String.format("array[(%s), (length %s)]", args[i].getClass(),
            Array.getLength(args[i]));
      } else {
        result[i] = args[i];
      }
    }
    return result;
  }

  @Pointcut("within(ru.vtb..*) && @annotation(Logging)")
  private void needLogging() {
  }

  @SneakyThrows
  @Before("needLogging() && @annotation(logging)")
  public void before(final JoinPoint joinPoint, final Logging logging) {
    var signature = (MethodSignature) joinPoint.getSignature();
    var logger = LoggerFactory.getLogger(signature.getDeclaringType());
    var argumentsTemplate = formatArgumentsTemplate(signature.getParameterNames());
    log(logger, logging, signature.getName(), argumentsTemplate, joinPoint.getArgs());
  }

  @SneakyThrows
  @AfterReturning(value = "needLogging() && @annotation(logging)", returning = "returnValue")
  public void success(final JoinPoint joinPoint, final Logging logging, final Object returnValue) {
    var signature = (MethodSignature) joinPoint.getSignature();
    var logger = LoggerFactory.getLogger(signature.getDeclaringType());
    if (logging.includeResultLogging()) {
      if (logging.resultAsJson()) {
        try {
          log(logger, logging, "returns: {}", objectMapper.writeValueAsString(returnValue));
        } catch (JsonProcessingException e) {
          log(logger, logging, signature.getName(), "returns: {}", returnValue);
        }
      } else {
        log(logger, logging, signature.getName(), "returns: {}", returnValue);
      }
    }
  }

  @SneakyThrows
  @AfterThrowing(value = "needLogging() && @annotation(logging)", throwing = "e")
  public void failure(final JoinPoint joinPoint, final Logging logging, final Exception e) {
    var signature = (MethodSignature) joinPoint.getSignature();
    var logger = LoggerFactory.getLogger(signature.getDeclaringType());
    var argumentsTemplate = formatArgumentsTemplate(signature.getParameterNames());
    logger.error(String.format("%s: %s", signature.getName(), argumentsTemplate),
        wrapArgs(logging, joinPoint.getArgs()), e);
  }

  private String formatArgumentsTemplate(final String... names) {
    return Arrays.stream(names)
        .reduce(new StringBuilder(),
            (r, v) -> r.append(v).append(": ").append("{} "),
            (r, v) -> r)
        .toString();
  }
}
