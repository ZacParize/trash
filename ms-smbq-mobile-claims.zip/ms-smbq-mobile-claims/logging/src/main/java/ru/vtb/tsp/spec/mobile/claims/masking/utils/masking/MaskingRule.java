package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MaskingRule {

  public static final String MASKING_SYMBOL = "*";

  private int maskAmount;

  private int indent;

}
