package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;


import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.apache.logging.log4j.core.pattern.PatternConverter;
import ru.vtb.tsp.spec.mobile.claims.masking.consts.MaskingConstants;

@Plugin(name = "logmasker", category = PatternConverter.CATEGORY)
@ConverterKeys({"msk", "mask"})
public class ConsoleMaskingConverter extends LogEventPatternConverter {

    protected ConsoleMaskingConverter(String name, String style) {
        super(name, style);
    }

    public static ConsoleMaskingConverter newInstance(String[] options) throws Exception {
        return new ConsoleMaskingConverter(ConsoleMaskingConverter.class.getSimpleName(), null);
    }

    @Override
    public void format(LogEvent event, StringBuilder toAppendTo) {
        String masked = SensitiveDataMaskingUtils.maskMessage(MaskingConstants.MULTILINE_PATTERN,
            event.getMessage().getFormattedMessage());
        toAppendTo.append(masked);
    }
}