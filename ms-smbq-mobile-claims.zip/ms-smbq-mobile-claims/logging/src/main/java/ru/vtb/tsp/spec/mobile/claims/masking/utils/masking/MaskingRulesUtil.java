package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class MaskingRulesUtil {

  private static final double MASKING_RATE = 0.6;

  public static MaskingRule getRule(String match) {
    MaskingRule maskingRule = new MaskingRule();
    if (match.length() == 1) {
      maskingRule.setMaskAmount(1);
      maskingRule.setIndent(0);
    } else if (match.length() == 2) {
      maskingRule.setMaskAmount(1);
      maskingRule.setIndent(1);
    } else if (match.length() == 3) {
      maskingRule.setMaskAmount(2);
      maskingRule.setIndent(1);
    } else if (match.length() == 4) {
      maskingRule.setMaskAmount(3);
      maskingRule.setIndent(1);
    } else if (match.length() >= 5 && match.length() <= 9) {
      int maskAmount = getMaskAmount(match);
      maskingRule.setMaskAmount(maskAmount);
      maskingRule.setIndent(1);
    } else if (match.length() >= 10 && match.length() <= 15) {
      int maskAmount = getMaskAmount(match);
      maskingRule.setMaskAmount(maskAmount);
      maskingRule.setIndent(2);
    } else if (match.length() >= 16) {
      int maskAmount = getMaskAmount(match);
      int indent = (match.length() - maskAmount) / 2;
      maskingRule.setMaskAmount(maskAmount);
      maskingRule.setIndent(indent);
    }

    return maskingRule;
  }

  private static int getMaskAmount(String match) {
    return new BigDecimal(match.length())
        .multiply(BigDecimal.valueOf(MASKING_RATE))
        .setScale(0, RoundingMode.UP).intValue();
  }


}
