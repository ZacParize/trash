package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;


import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

/**
 * <a href="https://wiki.corp.dev.vtb/pages/viewpage.action?pageId=1148535889">Masking rules</a>
 * The test should be placed in <application> module -> application/src/test/java/ru/vtb/tsp/spec/app/util/masking/account/CheckAccountMaskingTest.java
 */
public class SensitiveDataMaskingUtils {

  private static final String OFD_LOGIN_PASSWORD = ".\"login.*password.*}";

  private static final String JWT_TECH_PATTERN = "(?<!\\[traceId=)\\b[\\w-]*9\\.[\\w-]+\\.[\\w-]+(?=[\\s\\\"\\\\,)\\]]|$)";

  private static final String JWT_BEARER_PATTERN = "(?<=Bearer\\s)(?!,)([^*********].[^(,]*)";

  private static final String JWT_ACCESS_TOKEN_PATTERN = "(?<=accessToken=)(?!,)([^*********].[^,]*)";

  private static final String JWT_ACCESS_TOKEN_HYPHEN_PATTERN = "(?<=access_token\":\")(?!,)([^*********].[^\\\"]*)";

  private static final List<String> credentialsPatterns = List.of(OFD_LOGIN_PASSWORD, JWT_ACCESS_TOKEN_PATTERN,
      JWT_TECH_PATTERN, JWT_BEARER_PATTERN, JWT_ACCESS_TOKEN_PATTERN, JWT_ACCESS_TOKEN_HYPHEN_PATTERN);

  private static final Pattern credentialsMultilinePattern = Pattern.compile(
      String.join("|", credentialsPatterns), Pattern.MULTILINE
  );


  public static String maskMessage(Pattern multilinePattern, String message) {
    if (multilinePattern == null) {
      return message;
    }
    StringBuilder sb = new StringBuilder(message);
    Matcher credentialsMatcher = credentialsMultilinePattern.matcher(sb);
    while (credentialsMatcher.find()) {
      String match = credentialsMatcher.group();
      remove(sb, match);
      credentialsMatcher = credentialsMultilinePattern.matcher(sb);
    }

    Matcher maskingMatcher = multilinePattern.matcher(sb);
    while (maskingMatcher.find()) {
      String match = maskingMatcher.group();
      replaceWithMask(sb, match);
    }
    return sb.toString();
  }

  private static void remove(StringBuilder sb, String match) {
    int startIndex = sb.toString().indexOf(match);
    sb.replace(startIndex, startIndex + match.length(), "");
  }

  private static void replaceWithMask(StringBuilder sb, String match) {
    String maskedString = getMaskedString(match);
    int startIndex = sb.toString().indexOf(match);
    sb.replace(startIndex, startIndex + match.length(), maskedString);
  }

  private static String getMaskedString(String match) {
    MaskingRule rule = MaskingRulesUtil.getRule(match);
    int maskAmount = rule.getMaskAmount();
    int indent = rule.getIndent();
    return match.substring(0, indent) +
        IntStream.range(0, maskAmount)
            .mapToObj(i -> MaskingRule.MASKING_SYMBOL)
            .collect(Collectors.joining()) +
        match.substring(indent + maskAmount);
  }

}
