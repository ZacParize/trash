package ru.vtb.tsp.spec.mobile.claims.masking.utils.masking;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.layout.template.json.resolver.EventResolver;
import org.apache.logging.log4j.layout.template.json.resolver.TemplateResolverConfig;
import org.apache.logging.log4j.layout.template.json.util.JsonWriter;
import ru.vtb.tsp.spec.mobile.claims.masking.consts.MaskingConstants;

public final class JsonMaskingResolver implements EventResolver {

    private static final String RESOLVER_KEY = "maskJson";

    JsonMaskingResolver(final TemplateResolverConfig config) {
        // Additional configuration not required
    }

    static String getName() {
        return RESOLVER_KEY;
    }

    @Override
    public void resolve(
        final LogEvent value,
        final JsonWriter jsonWriter) {
        String masked = SensitiveDataMaskingUtils.maskMessage(MaskingConstants.MULTILINE_PATTERN,
            value.getMessage().getFormattedMessage());
        jsonWriter.writeString(String.valueOf(masked));
    }
}