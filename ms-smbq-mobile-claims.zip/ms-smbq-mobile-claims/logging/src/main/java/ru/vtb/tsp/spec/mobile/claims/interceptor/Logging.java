package ru.vtb.tsp.spec.mobile.claims.interceptor;

import org.springframework.boot.logging.LogLevel;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Logging {

  LogLevel level() default LogLevel.INFO;

  boolean includeResultLogging() default true;

  boolean resultAsJson() default false;

  boolean printArrays() default false;
}
