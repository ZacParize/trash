package ru.vtb.tsp.spec.mobile.claims.masking.consts;

import java.util.List;
import java.util.regex.Pattern;

public interface MaskingConstants {

  String ACCOUNT = "(?<=(?<!mdmCode)(?<!mdmCode\":)(?<!mdmCode....)(?<!mdmCode.....)(?<!mdm code.)(?<!mdm code..)(?<!mdm code...)(?<!MDM found in organization.)(?<!mdmPkbClient\":)(?<!mdmPkbClient....)[\\s\\\"\\[\\=\\:])\\d{20}(?=[\\s\\\"\\\\,\\)\\]]|$)"; // 20-digit Account masking
  String FL_INN = "(?<=(?<!mdmCode)(?<!mdmCode\":)(?<!mdmCode....)(?<!mdmCode.....)(?<!mdm code.)(?<!mdm code..)(?<!mdm code...)(?<!MDM found in organization.)(?<!mdmPkbClient\":)(?<!mdmPkbClient....)[\\s\\\"\\[\\=\\:])\\d{12}(?=[\\s\\\"\\\\,\\)\\]]|$)"; // 12-digit FL inn masking
  String LEGAL_ENTITY_INN = "(?<=(?<!mdmCode)(?<!mdmCode\":)(?<!mdmCode....)(?<!mdmCode.....)(?<!mdm code.)(?<!mdm code..)(?<!mdm code...)(?<!MDM found in organization.)(?<!mdmPkbClient\":)(?<!mdmPkbClient....)[\\s\\\"\\[\\=\\:])\\d{10}(?=[\\s\\\"\\\\,\\)\\]]|$)"; // 10-digit Legal entity inn masking
  String OGRN = "(?<=(?<!mdmCode)(?<!mdmCode\":)(?<!mdmCode....)(?<!mdmCode.....)(?<!mdm code.)(?<!mdm code..)(?<!mdm code...)(?<!MDM found in organization.)(?<!mdmPkbClient\":)(?<!mdmPkbClient....)[\\s\\\"\\[\\=\\:])\\d{13}(?=[\\s\\\"\\\\,\\)\\]]|$)"; // 13-digit ogrn masking

  String OGRNIP = "(?<=(?<!mdmCode)(?<!mdmCode\":)(?<!mdmCode....)(?<!mdmCode.....)(?<!mdm code.)(?<!mdm code..)(?<!mdm code...)(?<!MDM found in organization.)(?<!mdmPkbClient\":)(?<!mdmPkbClient....)[\\s\\\"\\[\\=\\:])\\d{15}(?=[\\s\\\"\\\\,\\)\\]]|$)"; // 15-digit ogrnip masking

  String JWT_TECH_TOKEN = "(?<!\\[traceId=)\\b[\\w-]*9\\.[\\w-]+\\.[\\w-]+(?=[\\s\\\"\\\\,)\\]]|$)"; // Jwt tech token masking

  String JWT = "(?<=Bearer\\s)(?!,)([^*********].[^(,]*)"; // Jwt

  String ACCESS_TOKEN = "(?<=accessToken=)(?!,)([^*********].[^,]*)"; // Access token

  String ACCESS_TOKEN_SECOND_FORMAT = "(?<=access_token\":\")(?!,)([^*********].[^\\\"]*)"; // Access token second format

  String KPP_ORGANIZATION = "(?<=(k|K)(p|P)(p|P)(....|...|..|.|\\s|)(\"|=|:\\s|:\\s))[0-9]{9}";

  String OFD_CREDENTIALS = ".\"login.*password.*}";

  String FULL_NAME = "(?<=((fullName)(......|.....|....|...|..|.|\\s|)))([А-ЯЁЕ][а-яеёМЕНЯ]+[\\-\\s]?){2,}";

  String NAME = "(?<=((name)(......|.....|....|...|..|.|\\s|)))([А-ЯЁЕ][а-яеёМЕНЯ]+[\\-\\s]?){3,}";

  String FIRST_NAME = "(?<=((firstName)(......|.....|....|...|..|.|\\s|)))(([а-яА-Я]*)(-?)([а-яА-Я]*))(?=[\\s\\\"\\\\,\\)\\]]|$)";

  String MIDDLE_NAME = "(?<=((middleName)(......|.....|....|...|..|.|\\s|)))(([а-яА-Я]*)(-?)([а-яА-Я]*))(?=[\\s\\\"\\\\,\\)\\]]|$)";

  String LAST_NAME = "(?<=((lastName)(......|.....|....|...|..|.|\\s|)))(([а-яА-Я]*)(-?)([а-яА-Я]*))(?=[\\s\\\"\\\\,\\)\\]]|$)";

  String PHONE_NUMBER_FIRST_FORMAT = "(?<=\\+)(( |-|\\.)\\d{1,2}( |-|\\.)?)?(\\(?\\d{3}\\)?|\\d{3})( |-|\\.)?(\\d{3}( |-|\\.)?\\d{4})";

  String PHONE_NUMBER_SECOND_FORMAT = "\\+[0-9]+\\([0-9]+\\)\\s[0-9]+-[0-9]+-[0-9]+";

  String PHONE_NUMBER_THIRD_FORMAT = "\\([0-9]+\\)[0-9]+-[0-9]+-[0-9]+";

  String PHONE_NUMBER_FORTH_FORMAT = "[0-9]+\\s[0-9]+";

  String EMAIL = "[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?";

  String PASSPORT_NUM = "(?<=((num)(.{1,6}|\\s|)))[a-zA-Z0-9]*([-][a-zA-Z0-9]+)*";

  String PASSPORT_SERIES = "(?<=((series)(.{1,6}|\\s|)))[a-zA-Z0-9]*([-][a-zA-Z0-9]+)*";

  List<String> maskingPatterns = List.of(ACCOUNT, FL_INN, LEGAL_ENTITY_INN, OGRN, OGRNIP,
      JWT_TECH_TOKEN, JWT, ACCESS_TOKEN, ACCESS_TOKEN_SECOND_FORMAT, KPP_ORGANIZATION,
      OFD_CREDENTIALS, FIRST_NAME, MIDDLE_NAME, LAST_NAME, EMAIL, NAME, FULL_NAME,
      PHONE_NUMBER_FIRST_FORMAT, PHONE_NUMBER_SECOND_FORMAT, PHONE_NUMBER_THIRD_FORMAT, PHONE_NUMBER_FORTH_FORMAT,
      PASSPORT_NUM, PASSPORT_SERIES
  );

  Pattern MULTILINE_PATTERN = Pattern.compile(String.join("|", maskingPatterns), Pattern.MULTILINE);

}
