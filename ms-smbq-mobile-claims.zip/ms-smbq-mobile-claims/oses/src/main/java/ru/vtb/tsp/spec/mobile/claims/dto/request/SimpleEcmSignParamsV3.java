package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SimpleEcmSignParamsV3 {

    @JsonProperty("file_ids")
    private List<String> fileIds;

    @JsonProperty("grant_access_rights")
    private Boolean grantAccessRights;

    private SimpleRequisitesV3OsesRequest requisites;

    private NotificationV3Request notification;

}
