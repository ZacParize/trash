package ru.vtb.tsp.spec.mobile.claims.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentOsesResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentSignProcessInfoV3Response;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SignatureMapper {


  DocumentOsesResponse toResponse(DocumentSignProcessInfoV3Response response);

}
