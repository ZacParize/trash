package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.List;
import java.util.UUID;
import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentOsesRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentOsesResponse;

public interface SignatureService {

    DocumentOsesResponse signSignature(HttpHeaders headers, DocumentOsesRequest documentOsesRequest,
        List<String> docUuidList, String claimId);

}
