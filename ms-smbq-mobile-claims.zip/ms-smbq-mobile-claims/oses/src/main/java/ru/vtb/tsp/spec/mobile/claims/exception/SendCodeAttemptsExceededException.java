package ru.vtb.tsp.spec.mobile.claims.exception;

public class SendCodeAttemptsExceededException extends RuntimeException {

  public SendCodeAttemptsExceededException(String errorMessage) {
    super(errorMessage);
  }

}
