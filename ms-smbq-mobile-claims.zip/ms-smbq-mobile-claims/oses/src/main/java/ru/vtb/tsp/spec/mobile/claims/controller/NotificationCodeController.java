package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.NotificationCodeService;

@Api(value = "Notification code controller", tags = "notification-code-controller")
@RestController
@RequestMapping("${api-v1.root}/code")
@RequiredArgsConstructor
public class NotificationCodeController {

  private final NotificationCodeService confirmationCodeService;

  @Logging
  @GetMapping
  @ApiOperation(value = "Запрос на получение кода")
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void code(@RequestParam String processId) {
    confirmationCodeService.sendNotificationCode(processId);
  }



}
