package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.request.*;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentOsesResponse;
import ru.vtb.tsp.spec.mobile.claims.feign.OsesApi;
import ru.vtb.tsp.spec.mobile.claims.mapper.SignatureMapper;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgServiceTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.FileStorageService;
import ru.vtb.tsp.spec.mobile.claims.service.SignatureService;
import ru.vtb.tsp.spec.mobile.claims.session.exception.SessionDataNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class SignatureServiceImpl implements SignatureService {

  public static final String ORGANIZATION_NOTIFICATION_PHONE_TYPE = "16";
  public static final String FL_CONTACT_PHONE_TYPE = "7";
  public static final String MSG_TEMPLATE = "Код подтверждения для электронного подписания документов:  {code}. Никому не сообщайте этот код.";
  private final OsesApi osesApi;
  private final EpaIgServiceTokenService epaIgServiceTokenService;
  private final SignatureMapper signatureMapper;
  private final SessionService sessionService;
  private final FileStorageService fileStorageService;

  private static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

  @Override
  @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_DOCS_SIGN, techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
  public DocumentOsesResponse signSignature(HttpHeaders headers,
      DocumentOsesRequest documentOsesRequest, List<String> docUuidList, String claimId) {
    var sessionData = sessionService.getSessionData(headers);
    try {
      documentOsesRequest.getDocumentList().getDocumentListItems()
              .forEach(doc -> fileStorageService.createPermission(UUID.fromString(doc.getDocUuid())));
      var notificationPhone = sessionData.getPhones().stream()
          .filter(p -> p.getPhoneType().equals(ORGANIZATION_NOTIFICATION_PHONE_TYPE))
          .findFirst().orElseThrow(() -> new SessionDataNotFoundException("notificationPhone not found"));
      log.debug("found notificationPhone: {} in sessionData", notificationPhone);
      var contactPhone = sessionData.getPhones().stream()
          .filter(p -> p.getPhoneType().equals(FL_CONTACT_PHONE_TYPE))
          .findFirst().orElseThrow(() -> new SessionDataNotFoundException("contactPhone not found"));
      log.debug("found contactPhone: {} in sessionData", contactPhone);
      var fileIds = documentOsesRequest.getDocumentList().getDocumentListItems().stream()
          .map(DocumentOsesItemRequest::getDocUuid)
          .toList();

      var formatter = DateTimeFormatter.ofPattern(DATE_FORMAT);
      var req = SimpleEcmSignParamsV3.builder()
          .grantAccessRights(true)
          .requisites(SimpleRequisitesV3OsesRequest.builder()
              .signDt(OffsetDateTime.parse(OffsetDateTime.now().format(formatter)).toString())
              .address(SimpleAddressV3Request.builder()
                  .mac(documentOsesRequest.getMac())
                  .ip(documentOsesRequest.getIp())
                  .build())
              .user(SimpleUserV3Request.builder()
                  .nameFirst(sessionData.getFirstName())
                  .nameMiddle(sessionData.getMiddleName())
                  .nameLast(sessionData.getLastName())
                  .phone(contactPhone.getFullPhoneNumber())
                  .login(sessionData.getLogin())
                  .build())
              .build())
          .fileIds(fileIds)
          .notification(NotificationV3Request.builder()
              .msgTemplate(MSG_TEMPLATE)
              .phone(notificationPhone.getFullPhoneNumber())
              .keepAliveFor(60)
              .maxVerifyCount(3)
              .maxNotifyCount(3)
              .build())
          .build();
      var techHeaders = new HttpHeaders();
      techHeaders.add(HttpHeaders.AUTHORIZATION, epaIgServiceTokenService.getToken());
      return signatureMapper.toResponse(osesApi.sign(req, techHeaders));
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }
}
