package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentOsesItemRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentOsesRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentOsesResponse;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.SignatureService;
import ru.vtb.tsp.spec.mobile.claims.session.utils.HeaderUtils;

@Api(value = "Signature controller", tags = "signature-controller")
@RestController
@RequestMapping("${api-v1.root}/signature")
@RequiredArgsConstructor
public class SignatureController {

  private final SignatureService signatureService;

  @Logging
  @PostMapping
  @ApiOperation(value = "Подписание документов")
  public DocumentOsesResponse signature(@RequestHeader HttpHeaders httpHeaders,
      @RequestBody DocumentOsesRequest documentOsesRequest) {
    return signatureService.signSignature(httpHeaders, documentOsesRequest,
        documentOsesRequest.getDocumentList().getDocumentListItems()
            .stream().map(DocumentOsesItemRequest::getDocUuid)
            .collect(Collectors.toList()), HeaderUtils.getClaimId(httpHeaders));
  }



}
