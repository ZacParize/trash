package ru.vtb.tsp.spec.mobile.claims.exception;

public class VerifyNotificationException extends RuntimeException {

  public VerifyNotificationException(String errorMessage) {
    super(errorMessage);
  }

}
