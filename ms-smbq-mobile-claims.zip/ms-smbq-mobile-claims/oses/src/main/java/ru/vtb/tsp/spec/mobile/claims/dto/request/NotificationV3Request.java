package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class NotificationV3Request {

    @JsonProperty("msg_template")
    private String msgTemplate;

    private String phone;

    @JsonProperty("keep_alive_for")
    private Integer keepAliveFor;

    @JsonProperty("max_verify_count")
    private Integer maxVerifyCount;

    @JsonProperty("max_notify_count")
    private Integer maxNotifyCount;

}
