package ru.vtb.tsp.spec.mobile.claims.exception;

public class NotFoundDocumentSignProcessException extends RuntimeException {

  public NotFoundDocumentSignProcessException(String errorMessage) {
    super(errorMessage);
  }

}
