package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.UUID;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.request.NotifyParamsV3Request;
import ru.vtb.tsp.spec.mobile.claims.dto.request.VerifyNotificationCodeRequest;
import ru.vtb.tsp.spec.mobile.claims.exception.NotFoundDocumentSignProcessException;
import ru.vtb.tsp.spec.mobile.claims.exception.SendCodeAttemptsExceededException;
import ru.vtb.tsp.spec.mobile.claims.exception.VerifyNotificationException;
import ru.vtb.tsp.spec.mobile.claims.feign.OsesApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgServiceTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.NotificationCodeService;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationCodeServiceImpl implements NotificationCodeService,
    CheckIntegrationService {

  private static final String INTEGRATION_NAME = "Сервис ПЭП";
  public static final String PROCESS_ID_NOT_FOUND = "processId not found or invalid";

  private final OsesApi osesApi;

  private final EpaIgServiceTokenService epaIgServiceTokenService;


  @Override
  public void sendNotificationCode(String processId) {
    try {
      var headers = new HttpHeaders();
      headers.add(HttpHeaders.AUTHORIZATION, epaIgServiceTokenService.getToken());
      var notificationResponse = osesApi.sendNotificationCode(NotifyParamsV3Request.builder()
          .processId(processId)
          .build(), headers);
      var httpStatus = notificationResponse.getStatusCode();
      switch (httpStatus) {
        case BAD_REQUEST -> throw new SendCodeAttemptsExceededException("");
        case NOT_FOUND -> throw new NotFoundDocumentSignProcessException("");
        case INTERNAL_SERVER_ERROR -> throw new InvalidExternalSystemResponseException("");
      }
    } catch (FeignException.BadRequest feignException) {
      log.error(ExceptionUtils.getStackTrace(feignException));
      throw new InvalidExternalSystemResponseException(PROCESS_ID_NOT_FOUND);
    }
    catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  public boolean verifyNotificationCode(String code, String processId) {
    try {
      var headers = new HttpHeaders();
      headers.add(HttpHeaders.AUTHORIZATION, epaIgServiceTokenService.getToken());
      var responseEntity = osesApi.verifyCode(VerifyNotificationCodeRequest.builder()
              .code(code)
              .processId(processId)
              .build(),
          headers);
      if (responseEntity.getStatusCode() == HttpStatus.OK) {
        return true;
      }

      throw new VerifyNotificationException("");
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new VerifyNotificationException("");
    }
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
      sendNotificationCode(UUID.randomUUID().toString());
    } catch (InvalidExternalSystemResponseException e) {
      if (e.getMessage().equalsIgnoreCase(PROCESS_ID_NOT_FOUND)) {
        return EndpointCheckDto.builder()
                .status(HttpStatus.OK.name())
                .build();
      }
    }

    return EndpointCheckDto.builder()
        .status(HttpStatus.BAD_REQUEST.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
