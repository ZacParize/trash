package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.NotifyParamsV3Request;
import ru.vtb.tsp.spec.mobile.claims.dto.request.SimpleEcmSignParamsV3;
import ru.vtb.tsp.spec.mobile.claims.dto.request.VerifyNotificationCodeRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentSignProcessInfoV3Response;
import ru.vtb.tsp.spec.mobile.claims.dto.response.NotifyResultV3;

@FeignClient(name = "osesApi", url = "${oses.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface OsesApi {

  @PostMapping(value = "/ecm/sign", produces = "application/json", consumes = "application/json")
  DocumentSignProcessInfoV3Response sign(@RequestBody SimpleEcmSignParamsV3 req, @RequestHeader HttpHeaders httpHeaders);

  @PostMapping(value = "/notify", produces = "application/json", consumes = "application/json")
  ResponseEntity<NotifyResultV3> sendNotificationCode(@RequestBody NotifyParamsV3Request request, @RequestHeader HttpHeaders httpHeaders);

  @PostMapping("/ecm/verify")
  ResponseEntity<Void> verifyCode(@RequestBody VerifyNotificationCodeRequest request, @RequestHeader HttpHeaders httpHeaders);

}