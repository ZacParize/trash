package ru.vtb.tsp.spec.mobile.claims.service;

public interface NotificationCodeService {

  void sendNotificationCode(String processId);

  boolean verifyNotificationCode(String code, String processId);

}
