package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
// Удалить в следующих версиях, это трэш TODO
public class DocumentOsesListDummyRequest {

    private List<DocumentOsesItemRequest> documentListItems;

}
