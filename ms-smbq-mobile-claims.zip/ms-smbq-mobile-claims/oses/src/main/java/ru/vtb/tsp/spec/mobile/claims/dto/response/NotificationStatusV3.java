package ru.vtb.tsp.spec.mobile.claims.dto.response;

public enum NotificationStatusV3 {

    OK,
    NO_ATTEMPTS

}
