package ru.vtb.tsp.spec.mobile.claims.session.service;

import org.springframework.http.HttpHeaders;

public interface HeaderService {

  HttpHeaders ofDadataHeaders();

  HttpHeaders ofPosHeaders();

}
