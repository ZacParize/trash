package ru.vtb.tsp.spec.mobile.claims.session.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.session.service.HeaderService;
import ru.vtb.tsp.spec.mobile.claims.session.utils.AuthContextHolder;

@Service
public class HeaderServiceImpl implements HeaderService {
  @Value("${adapter.token}")
  private String dadataToken;


  private static final String X_VTB_SMBQ_CHANNEL = "x-vtb-smbq-channel";

  private static final String MB_CHANNEL = "SMMB";

  @Override
  public HttpHeaders ofDadataHeaders() {
    var headers = new HttpHeaders();
    headers.add(HttpHeaders.AUTHORIZATION, dadataToken);
    return headers;
  }

  @Override
  public HttpHeaders ofPosHeaders() {
    var headers = new HttpHeaders();
    headers.add(HttpHeaders.AUTHORIZATION, AuthContextHolder.getBearerToken());
    headers.add(X_VTB_SMBQ_CHANNEL, MB_CHANNEL);
    headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    return headers;
  }
}
