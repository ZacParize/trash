package ru.vtb.tsp.spec.mobile.claims.session.security;

import com.fasterxml.jackson.annotation.JsonCreator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum EmployeeType {
    EMPLOYEE,
    LEADER,
    TECHNICAL,
    NOT_DEFINED;

    private static final Logger log = LoggerFactory.getLogger(EmployeeType.class);

    private EmployeeType() {
    }

    @JsonCreator
    public static EmployeeType getEmployeeType(Object inputEmployeeType) {
        String inputEmployeeTypeAsString = String.valueOf(inputEmployeeType);
        EmployeeType[] var2 = values();
        int var3 = var2.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            EmployeeType employeeType = var2[var4];
            if (employeeType.name().equalsIgnoreCase(inputEmployeeTypeAsString)) {
                return employeeType;
            }
        }

        try {
            int index = Integer.parseInt(inputEmployeeTypeAsString);
            EmployeeType[] values = values();
            if (index < values.length && index >= 0) {
                return values[index];
            } else {
                log.warn(String.format("Input employee type <%s> mismatched order in EmployeeType array.", inputEmployeeType));
                return NOT_DEFINED;
            }
        } catch (NumberFormatException var6) {
            log.warn(String.format("Input employee type <%s> is a wrong value.", inputEmployeeType));
            return NOT_DEFINED;
        }
    }
}