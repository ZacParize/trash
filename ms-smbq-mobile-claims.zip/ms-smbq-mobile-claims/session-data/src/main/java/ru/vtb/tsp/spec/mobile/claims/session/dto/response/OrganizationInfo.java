package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import com.sun.istack.NotNull;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class OrganizationInfo {

  @NotNull
  private String mdmCode;

  @NotNull
  private String inn;

  @NotNull
  private String ogrn;

  private List<PhoneSessionData> phones;

  private List<EmailSessionData> emails;

  private String firstName;

  private String middleName;

  private String lastName;

  private String login;

  private String citizenship;

  private String mdmOsn;
}
