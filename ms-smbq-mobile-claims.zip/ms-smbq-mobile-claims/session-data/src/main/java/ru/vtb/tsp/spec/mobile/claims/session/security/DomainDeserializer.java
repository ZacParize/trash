package ru.vtb.tsp.spec.mobile.claims.session.security;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

public class DomainDeserializer extends JsonDeserializer<String> {
    public DomainDeserializer() {
    }

    public String deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException {
        String domain = (String)jsonParser.readValueAs(String.class);
        if (StringUtils.isNotBlank(domain)) {
            String[] domainParts = domain.split("@");
            if (domainParts.length == 1) {
                return domainParts[0];
            }

            if (domainParts.length == 2) {
                return domainParts[1];
            }
        }

        return "";
    }
}