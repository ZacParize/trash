package ru.vtb.tsp.spec.mobile.claims.session.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.AntPathMatcher;

import java.util.Iterator;
import java.util.List;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class UrlUtils {
    public static boolean isUnprotectedUrl(String requestUrl, List<String> unprotectedUrlPatterns, AntPathMatcher anonymousUrlAntPathMatcher) {
        Iterator var3 = unprotectedUrlPatterns.iterator();

        String pattern;
        do {
            if (!var3.hasNext()) {
                return false;
            }

            pattern = (String)var3.next();
        } while(!StringUtils.isNotBlank(pattern) || !anonymousUrlAntPathMatcher.match(pattern, requestUrl));

        return true;
    }

}