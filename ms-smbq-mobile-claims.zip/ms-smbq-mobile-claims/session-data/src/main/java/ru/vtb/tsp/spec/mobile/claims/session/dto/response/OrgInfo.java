package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class OrgInfo {

  @NotNull
  private String inn;

  @NotNull
  private String ogrn;
}
