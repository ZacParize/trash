package ru.vtb.tsp.spec.mobile.claims.session.utils;

import static lombok.AccessLevel.PRIVATE;
import static ru.vtb.tsp.spec.mobile.claims.common.utils.StringUtil.removeFirst;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.EmployeeSessionData;
import ru.vtb.tsp.spec.mobile.claims.session.security.JwtAuthentication;
import ru.vtb.tsp.spec.mobile.claims.session.security.JwtToken;

@NoArgsConstructor(access = PRIVATE)
@Slf4j
public class AuthContextHolder {

  public static List<String> getRoles() {
    return getJwtToken(SecurityContextHolder.getContext())
        .map(JwtToken::getRoles)
        .orElse(Collections.emptyList());
  }

  public static String getSession() {
    return getJwtToken(SecurityContextHolder.getContext())
        .map(JwtToken::getCtxi)
        .orElse("");
  }


  public static String getBearerToken() {

    if (SecurityContextHolder.getContext()
        .getAuthentication() instanceof JwtAuthentication authentication) {
      String token = "Bearer " + authentication.getCredentials().toString();
      log.debug("auth token: {}", token);
      return token;
    }
    return "";
  }


  public static String getEmail() {
    return getJwtToken(SecurityContextHolder.getContext())
        .map(JwtToken::getSub)
        .orElse("");
  }

  public static String getName() {
    return getJwtToken(SecurityContextHolder.getContext())
        .map(JwtToken::getName)
        .orElse("");
  }

  public static EmployeeSessionData getEmployeeSessionData() {
    return getJwtToken(SecurityContextHolder.getContext())
        .map(jwtToken -> new EmployeeSessionData(
            jwtToken.getJwtTokenAttributes().getEmployeeNumber(),
            removeFirst(jwtToken.getJwtTokenAttributes().getTpCode(), "Z"),
            jwtToken.getJwtTokenAttributes().getLogin(),
            jwtToken.getName(),
            jwtToken.getEmail())
        ).orElse(null);
  }

  private static Optional<JwtToken> getJwtToken(SecurityContext securityContext) {
    return Optional.ofNullable(securityContext)
        .map(SecurityContext::getAuthentication)
        .map(authentication -> authentication instanceof JwtAuthentication jwtAuthentication
            ? jwtAuthentication : null)
        .map(JwtAuthentication::getPrincipal)
        .map(principal -> principal instanceof JwtToken jwtToken ? jwtToken : null);
  }
}
