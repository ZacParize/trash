package ru.vtb.tsp.spec.mobile.claims.session.security;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;
import ru.vtb.tsp.spec.mobile.claims.session.utils.JwtTokenUtils;
import ru.vtb.tsp.spec.mobile.claims.session.utils.UrlUtils;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(value = "mobile.claims.auth", matchIfMissing = true)
public class JwtTokenFilter extends OncePerRequestFilter {

  private final JwtTokenProvider jwtTokenProvider;

  private final AntPathMatcher anonymousUrlAntPathMatcher;

  @Value("#{'${service.security.unprotected:}'.split(',')}")
  private List<String> unprotectedUrlPatterns;


  @Override
  protected void doFilterInternal(HttpServletRequest httpServletRequest,
      HttpServletResponse httpServletResponse,
      FilterChain filterChain) throws IOException, ServletException {
    try {
      if (!UrlUtils.isUnprotectedUrl(httpServletRequest.getRequestURI(),
          this.unprotectedUrlPatterns, this.anonymousUrlAntPathMatcher)) {
        final var token = JwtTokenUtils.resolveToken(httpServletRequest);
        JwtTokenUtils.validateJwtToken(token);
        final var auth = jwtTokenProvider.getAuthentication(token);
        SecurityContextHolder.getContext().setAuthentication(auth);
      }
    } catch (Exception e) {
      throw new JwtIsNotValidException(e.getMessage());
    }
    filterChain.doFilter(httpServletRequest, httpServletResponse);
  }
}