package ru.vtb.tsp.spec.mobile.claims.session.security;

import java.util.List;
import java.util.Map;

public class UserInfo {
    private List<String> roles;
    private Map<String, Object> attributes;
    private List<String> permissions;

    public List<String> getRoles() {
        return this.roles;
    }

    public Map<String, Object> getAttributes() {
        return this.attributes;
    }

    public List<String> getPermissions() {
        return this.permissions;
    }

    public void setRoles(final List<String> roles) {
        this.roles = roles;
    }

    public void setAttributes(final Map<String, Object> attributes) {
        this.attributes = attributes;
    }

    public void setPermissions(final List<String> permissions) {
        this.permissions = permissions;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof UserInfo)) {
            return false;
        } else {
            UserInfo other = (UserInfo)o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label47: {
                    Object this$roles = this.getRoles();
                    Object other$roles = other.getRoles();
                    if (this$roles == null) {
                        if (other$roles == null) {
                            break label47;
                        }
                    } else if (this$roles.equals(other$roles)) {
                        break label47;
                    }

                    return false;
                }

                Object this$attributes = this.getAttributes();
                Object other$attributes = other.getAttributes();
                if (this$attributes == null) {
                    if (other$attributes != null) {
                        return false;
                    }
                } else if (!this$attributes.equals(other$attributes)) {
                    return false;
                }

                Object this$permissions = this.getPermissions();
                Object other$permissions = other.getPermissions();
                if (this$permissions == null) {
                    if (other$permissions != null) {
                        return false;
                    }
                } else if (!this$permissions.equals(other$permissions)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof UserInfo;
    }

    public int hashCode() {
        int result = 1;
        Object $roles = this.getRoles();
        result = result * 59 + ($roles == null ? 43 : $roles.hashCode());
        Object $attributes = this.getAttributes();
        result = result * 59 + ($attributes == null ? 43 : $attributes.hashCode());
        Object $permissions = this.getPermissions();
        result = result * 59 + ($permissions == null ? 43 : $permissions.hashCode());
        return result;
    }

    public String toString() {
        List var10000 = this.getRoles();
        return "UserInfo(roles=" + var10000 + ", attributes=" + this.getAttributes() + ", permissions=" + this.getPermissions() + ")";
    }

    public UserInfo() {
    }

    public UserInfo(final List<String> roles, final Map<String, Object> attributes, final List<String> permissions) {
        this.roles = roles;
        this.attributes = attributes;
        this.permissions = permissions;
    }
}