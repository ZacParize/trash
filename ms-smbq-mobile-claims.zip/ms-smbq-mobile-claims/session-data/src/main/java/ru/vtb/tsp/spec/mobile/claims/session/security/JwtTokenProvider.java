package ru.vtb.tsp.spec.mobile.claims.session.security;


import com.auth0.jwt.JWT;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;
import ru.vtb.tsp.spec.mobile.claims.session.utils.JwtTokenUtils;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Slf4j
@Component
@RequiredArgsConstructor
public class JwtTokenProvider {

  private final ObjectMapper jwtTokenObjectMapper = this.createObjectMapper();

  public Authentication getAuthentication(String token) {
    return new JwtAuthentication(JwtTokenUtils.extractValue(token, "sub"), getJwtToken(token),
        true);
  }

  private JwtToken getJwtToken(String accessTokenString) {
    try {
      return this.jwtTokenObjectMapper.readValue(this.getDecodeTokenPayload(accessTokenString),
          JwtToken.class);
    } catch (Exception e) {
      throw new JwtIsNotValidException();
    }
  }

  private ObjectMapper createObjectMapper() {
    var jwtTokenObjectMapper = new ObjectMapper();
    jwtTokenObjectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    jwtTokenObjectMapper.configure(DeserializationFeature.FAIL_ON_IGNORED_PROPERTIES, false);
    jwtTokenObjectMapper.configure(MapperFeature.DEFAULT_VIEW_INCLUSION, true);
    return jwtTokenObjectMapper;
  }

  private String getDecodeTokenPayload(String token) {
    var decodedJWT = JWT.decode(token);
    var bytes = Base64.getUrlDecoder().decode(decodedJWT.getPayload());
    return new String(bytes, StandardCharsets.UTF_8);
  }
}
