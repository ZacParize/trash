package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;

@Data
@AllArgsConstructor
public class EmployeeSessionData implements Serializable {

  private String number;
  private String tpCode;
  private String login;
  private String fullName;
  private String email;
}
