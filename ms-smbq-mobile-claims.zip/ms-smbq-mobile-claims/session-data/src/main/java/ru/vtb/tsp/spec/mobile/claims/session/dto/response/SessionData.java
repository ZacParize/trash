package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SessionData {

  private Organization organization;

  private Representative representative;

  private String requestId;

  private String serviceId;

  private String nextServiceId;

  private String productId;

  private String processName;

  private UrlAttributes urlAttributes;

}
