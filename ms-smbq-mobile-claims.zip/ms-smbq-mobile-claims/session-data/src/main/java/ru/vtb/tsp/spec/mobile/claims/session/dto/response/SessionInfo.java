package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SessionInfo {

  @NotNull
  private String mdmCode;

  @Valid
  private OrgInfo orgInfo;

  private List<PhoneSessionData> phones;

  private List<EmailSessionData> emails;

  private String firstName;

  private String middleName;

  private String lastName;

  private String login;

  private String citizenship;

  private String mdmOsn;
}
