package ru.vtb.tsp.spec.mobile.claims.session.security;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.google.common.base.Strings;
import org.apache.commons.lang3.StringUtils;
import ru.vtb.tsp.spec.mobile.claims.session.utils.DomainUtils;

import java.util.HashMap;
import java.util.Map;

public class JwtTokenAttributes {
    private String login;
    @JsonDeserialize(
        using = DomainDeserializer.class
    )
    @JsonTypeInfo(
        use = JsonTypeInfo.Id.NONE
    )
    private String domain;
    @JsonProperty("trm_code")
    private String trmCode;
    @JsonProperty("tp_code")
    private String tpCode;
    private String region;
    private String city;
    @JsonProperty("employee_number")
    private String employeeNumber;
    @JsonProperty("employee_type")
    private EmployeeType employeeType;
    private String title;
    private String company;
    private String department;
    private String info;
    private String shortTrmName;
    private String fullTrmName;
    @JsonProperty("region_code")
    private String regionCode;
    @JsonProperty("ou_ref")
    private String ouRef;

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap();
        DomainUtils.putIfNotNull("login", this.login, map);
        DomainUtils.putIfNotNull("domain", this.domain, map);
        DomainUtils.putIfNotNull("trm_code", this.trmCode, map);
        DomainUtils.putIfNotNull("tp_code", this.tpCode, map);
        DomainUtils.putIfNotNull("region", this.region, map);
        DomainUtils.putIfNotNull("city", this.city, map);
        DomainUtils.putIfNotNull("employee_number", this.employeeNumber, map);
        String name = this.employeeType == null ? null : this.employeeType.name();
        DomainUtils.putIfNotNull("employee_type", name, map);
        DomainUtils.putIfNotNull("title", this.title, map);
        DomainUtils.putIfNotNull("company", this.company, map);
        DomainUtils.putIfNotNull("department", this.department, map);
        DomainUtils.putIfNotNull("info", this.info, map);
        DomainUtils.putIfNotNull("short_trm_name", this.shortTrmName, map);
        DomainUtils.putIfNotNull("full_trm_name", this.fullTrmName, map);
        DomainUtils.putIfNotNull("region_code", this.regionCode, map);
        DomainUtils.putIfNotNull("ou_ref", this.ouRef, map);
        return map;
    }

    public void fillFromMap(Map<String, Object> attributes) {
        this.setLogin((String)attributes.get("login"));
        this.setEmployeeNumber(String.valueOf(attributes.get("employee_number")));
        this.setCompany((String)attributes.get("company"));
        this.setDepartment((String)attributes.get("department"));
        String incomingDomain = (String)attributes.get("domain");
        if (StringUtils.isNotBlank(incomingDomain)) {
            String[] domainParts = incomingDomain.split("@");
            if (domainParts.length == 1) {
                incomingDomain = domainParts[0];
            } else if (domainParts.length == 2) {
                incomingDomain = domainParts[1];
            } else {
                incomingDomain = "";
            }
        } else {
            incomingDomain = "";
        }

        this.setDomain(incomingDomain);
        String employeeTypeAsString = (String)attributes.get("employee_type");
        EmployeeType employeeTypeEnum;
        if (Strings.isNullOrEmpty(employeeTypeAsString)) {
            employeeTypeEnum = EmployeeType.NOT_DEFINED;
        } else {
            try {
                employeeTypeEnum = EmployeeType.valueOf(employeeTypeAsString);
            } catch (IllegalArgumentException var6) {
                employeeTypeEnum = EmployeeType.NOT_DEFINED;
            }
        }

        this.setEmployeeType(employeeTypeEnum);
        this.setInfo((String)attributes.get("info"));
        this.setRegion((String)attributes.get("region"));
        this.setCity((String)attributes.get("city"));
        this.setTitle((String)attributes.get("title"));
        this.setTpCode(String.valueOf(attributes.get("tp_code")));
        this.setTrmCode(String.valueOf(attributes.get("trm_code")));
        this.setShortTrmName(String.valueOf(attributes.get("short_trm_name")));
        this.setFullTrmName(String.valueOf(attributes.get("full_trm_name")));
        this.setRegionCode(String.valueOf(attributes.get("region_code")));
        this.setOuRef(String.valueOf(attributes.get("ou_ref")));
    }

    public String getLogin() {
        return this.login;
    }

    public String getDomain() {
        return this.domain;
    }

    public String getTrmCode() {
        return this.trmCode;
    }

    public String getTpCode() {
        return this.tpCode;
    }

    public String getRegion() {
        return this.region;
    }

    public String getCity() {
        return this.city;
    }

    public String getEmployeeNumber() {
        return this.employeeNumber;
    }

    public EmployeeType getEmployeeType() {
        return this.employeeType;
    }

    public String getTitle() {
        return this.title;
    }

    public String getCompany() {
        return this.company;
    }

    public String getDepartment() {
        return this.department;
    }

    public String getInfo() {
        return this.info;
    }

    public String getShortTrmName() {
        return this.shortTrmName;
    }

    public String getFullTrmName() {
        return this.fullTrmName;
    }

    public String getRegionCode() {
        return this.regionCode;
    }

    public String getOuRef() {
        return this.ouRef;
    }

    public JwtTokenAttributes setLogin(final String login) {
        this.login = login;
        return this;
    }

    public JwtTokenAttributes setDomain(final String domain) {
        this.domain = domain;
        return this;
    }

    @JsonProperty("trm_code")
    public JwtTokenAttributes setTrmCode(final String trmCode) {
        this.trmCode = trmCode;
        return this;
    }

    @JsonProperty("tp_code")
    public JwtTokenAttributes setTpCode(final String tpCode) {
        this.tpCode = tpCode;
        return this;
    }

    public JwtTokenAttributes setRegion(final String region) {
        this.region = region;
        return this;
    }

    public JwtTokenAttributes setCity(final String city) {
        this.city = city;
        return this;
    }

    @JsonProperty("employee_number")
    public JwtTokenAttributes setEmployeeNumber(final String employeeNumber) {
        this.employeeNumber = employeeNumber;
        return this;
    }

    @JsonProperty("employee_type")
    public JwtTokenAttributes setEmployeeType(final EmployeeType employeeType) {
        this.employeeType = employeeType;
        return this;
    }

    public JwtTokenAttributes setTitle(final String title) {
        this.title = title;
        return this;
    }

    public JwtTokenAttributes setCompany(final String company) {
        this.company = company;
        return this;
    }

    public JwtTokenAttributes setDepartment(final String department) {
        this.department = department;
        return this;
    }

    public JwtTokenAttributes setInfo(final String info) {
        this.info = info;
        return this;
    }

    public JwtTokenAttributes setShortTrmName(final String shortTrmName) {
        this.shortTrmName = shortTrmName;
        return this;
    }

    public JwtTokenAttributes setFullTrmName(final String fullTrmName) {
        this.fullTrmName = fullTrmName;
        return this;
    }

    @JsonProperty("region_code")
    public JwtTokenAttributes setRegionCode(final String regionCode) {
        this.regionCode = regionCode;
        return this;
    }

    @JsonProperty("ou_ref")
    public JwtTokenAttributes setOuRef(final String ouRef) {
        this.ouRef = ouRef;
        return this;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof JwtTokenAttributes)) {
            return false;
        } else {
            JwtTokenAttributes other = (JwtTokenAttributes)o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label203: {
                    Object this$login = this.getLogin();
                    Object other$login = other.getLogin();
                    if (this$login == null) {
                        if (other$login == null) {
                            break label203;
                        }
                    } else if (this$login.equals(other$login)) {
                        break label203;
                    }

                    return false;
                }

                Object this$domain = this.getDomain();
                Object other$domain = other.getDomain();
                if (this$domain == null) {
                    if (other$domain != null) {
                        return false;
                    }
                } else if (!this$domain.equals(other$domain)) {
                    return false;
                }

                Object this$trmCode = this.getTrmCode();
                Object other$trmCode = other.getTrmCode();
                if (this$trmCode == null) {
                    if (other$trmCode != null) {
                        return false;
                    }
                } else if (!this$trmCode.equals(other$trmCode)) {
                    return false;
                }

                label182: {
                    Object this$tpCode = this.getTpCode();
                    Object other$tpCode = other.getTpCode();
                    if (this$tpCode == null) {
                        if (other$tpCode == null) {
                            break label182;
                        }
                    } else if (this$tpCode.equals(other$tpCode)) {
                        break label182;
                    }

                    return false;
                }

                label175: {
                    Object this$region = this.getRegion();
                    Object other$region = other.getRegion();
                    if (this$region == null) {
                        if (other$region == null) {
                            break label175;
                        }
                    } else if (this$region.equals(other$region)) {
                        break label175;
                    }

                    return false;
                }

                label168: {
                    Object this$city = this.getCity();
                    Object other$city = other.getCity();
                    if (this$city == null) {
                        if (other$city == null) {
                            break label168;
                        }
                    } else if (this$city.equals(other$city)) {
                        break label168;
                    }

                    return false;
                }

                Object this$employeeNumber = this.getEmployeeNumber();
                Object other$employeeNumber = other.getEmployeeNumber();
                if (this$employeeNumber == null) {
                    if (other$employeeNumber != null) {
                        return false;
                    }
                } else if (!this$employeeNumber.equals(other$employeeNumber)) {
                    return false;
                }

                label154: {
                    Object this$employeeType = this.getEmployeeType();
                    Object other$employeeType = other.getEmployeeType();
                    if (this$employeeType == null) {
                        if (other$employeeType == null) {
                            break label154;
                        }
                    } else if (this$employeeType.equals(other$employeeType)) {
                        break label154;
                    }

                    return false;
                }

                Object this$title = this.getTitle();
                Object other$title = other.getTitle();
                if (this$title == null) {
                    if (other$title != null) {
                        return false;
                    }
                } else if (!this$title.equals(other$title)) {
                    return false;
                }

                label140: {
                    Object this$company = this.getCompany();
                    Object other$company = other.getCompany();
                    if (this$company == null) {
                        if (other$company == null) {
                            break label140;
                        }
                    } else if (this$company.equals(other$company)) {
                        break label140;
                    }

                    return false;
                }

                Object this$department = this.getDepartment();
                Object other$department = other.getDepartment();
                if (this$department == null) {
                    if (other$department != null) {
                        return false;
                    }
                } else if (!this$department.equals(other$department)) {
                    return false;
                }

                Object this$info = this.getInfo();
                Object other$info = other.getInfo();
                if (this$info == null) {
                    if (other$info != null) {
                        return false;
                    }
                } else if (!this$info.equals(other$info)) {
                    return false;
                }

                label119: {
                    Object this$shortTrmName = this.getShortTrmName();
                    Object other$shortTrmName = other.getShortTrmName();
                    if (this$shortTrmName == null) {
                        if (other$shortTrmName == null) {
                            break label119;
                        }
                    } else if (this$shortTrmName.equals(other$shortTrmName)) {
                        break label119;
                    }

                    return false;
                }

                label112: {
                    Object this$fullTrmName = this.getFullTrmName();
                    Object other$fullTrmName = other.getFullTrmName();
                    if (this$fullTrmName == null) {
                        if (other$fullTrmName == null) {
                            break label112;
                        }
                    } else if (this$fullTrmName.equals(other$fullTrmName)) {
                        break label112;
                    }

                    return false;
                }

                Object this$regionCode = this.getRegionCode();
                Object other$regionCode = other.getRegionCode();
                if (this$regionCode == null) {
                    if (other$regionCode != null) {
                        return false;
                    }
                } else if (!this$regionCode.equals(other$regionCode)) {
                    return false;
                }

                Object this$ouRef = this.getOuRef();
                Object other$ouRef = other.getOuRef();
                if (this$ouRef == null) {
                    if (other$ouRef != null) {
                        return false;
                    }
                } else if (!this$ouRef.equals(other$ouRef)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof JwtTokenAttributes;
    }

    public int hashCode() {
        int result = 1;
        Object $login = this.getLogin();
        result = result * 59 + ($login == null ? 43 : $login.hashCode());
        Object $domain = this.getDomain();
        result = result * 59 + ($domain == null ? 43 : $domain.hashCode());
        Object $trmCode = this.getTrmCode();
        result = result * 59 + ($trmCode == null ? 43 : $trmCode.hashCode());
        Object $tpCode = this.getTpCode();
        result = result * 59 + ($tpCode == null ? 43 : $tpCode.hashCode());
        Object $region = this.getRegion();
        result = result * 59 + ($region == null ? 43 : $region.hashCode());
        Object $city = this.getCity();
        result = result * 59 + ($city == null ? 43 : $city.hashCode());
        Object $employeeNumber = this.getEmployeeNumber();
        result = result * 59 + ($employeeNumber == null ? 43 : $employeeNumber.hashCode());
        Object $employeeType = this.getEmployeeType();
        result = result * 59 + ($employeeType == null ? 43 : $employeeType.hashCode());
        Object $title = this.getTitle();
        result = result * 59 + ($title == null ? 43 : $title.hashCode());
        Object $company = this.getCompany();
        result = result * 59 + ($company == null ? 43 : $company.hashCode());
        Object $department = this.getDepartment();
        result = result * 59 + ($department == null ? 43 : $department.hashCode());
        Object $info = this.getInfo();
        result = result * 59 + ($info == null ? 43 : $info.hashCode());
        Object $shortTrmName = this.getShortTrmName();
        result = result * 59 + ($shortTrmName == null ? 43 : $shortTrmName.hashCode());
        Object $fullTrmName = this.getFullTrmName();
        result = result * 59 + ($fullTrmName == null ? 43 : $fullTrmName.hashCode());
        Object $regionCode = this.getRegionCode();
        result = result * 59 + ($regionCode == null ? 43 : $regionCode.hashCode());
        Object $ouRef = this.getOuRef();
        result = result * 59 + ($ouRef == null ? 43 : $ouRef.hashCode());
        return result;
    }

    public String toString() {
        String var10000 = this.getLogin();
        return "JwtTokenAttributes(login=" + var10000 + ", domain=" + this.getDomain() + ", trmCode=" + this.getTrmCode() + ", tpCode=" + this.getTpCode() + ", region=" + this.getRegion() + ", city=" + this.getCity() + ", employeeNumber=" + this.getEmployeeNumber() + ", employeeType=" + this.getEmployeeType() + ", title=" + this.getTitle() + ", company=" + this.getCompany() + ", department=" + this.getDepartment() + ", info=" + this.getInfo() + ", shortTrmName=" + this.getShortTrmName() + ", fullTrmName=" + this.getFullTrmName() + ", regionCode=" + this.getRegionCode() + ", ouRef=" + this.getOuRef() + ")";
    }

    public JwtTokenAttributes() {
        this.employeeType = EmployeeType.NOT_DEFINED;
    }
}