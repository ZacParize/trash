package ru.vtb.tsp.spec.mobile.claims.session.exception;

public class SessionDataNotFoundException extends RuntimeException {

  public SessionDataNotFoundException(String errorMessage) {
    super(errorMessage);
  }

}