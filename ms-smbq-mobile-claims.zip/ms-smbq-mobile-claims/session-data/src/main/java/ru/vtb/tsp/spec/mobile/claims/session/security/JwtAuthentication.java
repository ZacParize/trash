package ru.vtb.tsp.spec.mobile.claims.session.security;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class JwtAuthentication extends AbstractAuthenticationToken {
    private static final String ROLE_PREFIX = "ROLE_";
    private String token;
    private JwtToken jwtToken;
    private boolean authenticated;
    private Collection<GrantedAuthority> authorities = super.getAuthorities();

    public JwtAuthentication(String token, JwtToken jwtToken, boolean authenticated) {
        super(Stream.concat(jwtToken.getPermissions().stream(), jwtToken.getRoles().stream().map((it) -> {
            return "ROLE_" + it;
        })).map(SimpleGrantedAuthority::new).collect(Collectors.toList()));
        this.token = token;
        this.jwtToken = jwtToken;
        this.authenticated = authenticated;
    }

    public Collection<GrantedAuthority> getAuthorities() {
        return this.authorities;
    }

    public Object getCredentials() {
        return this.token;
    }

    public Object getDetails() {
        return null;
    }

    public void setDetails(Object details) {
    }

    public Object getPrincipal() {
        return this.jwtToken;
    }

    public boolean isAuthenticated() {
        return this.authenticated;
    }

    public void setAuthenticated(boolean authenticated) {
        this.authenticated = authenticated;
    }

    public String getName() {
        return this.jwtToken.getName();
    }
}