package ru.vtb.tsp.spec.mobile.claims.session.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import feign.FeignException.NotFound;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.EmailSessionData;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.PhoneSessionData;
import ru.vtb.tsp.spec.mobile.claims.session.exception.SessionDataNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.session.feign.SessionApi;
import ru.vtb.tsp.spec.mobile.claims.session.dto.request.SessionRequest;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.OrganizationInfo;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.SessionInfo;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;
import ru.vtb.tsp.spec.mobile.claims.session.utils.JwtTokenUtils;

@Service
@Slf4j
@Profile("!session_stub")
@RequiredArgsConstructor
public class SessionServiceImpl implements SessionService, CheckIntegrationService {

  public static final String FIRST_NAME = "firstName";
  public static final String MIDDLE_NAME = "middleName";
  public static final String LAST_NAME = "lastName";
  public static final String CITIZENSHIP = "citizenship";
  public static final String IDS = "ids";
  public static final String LOGIN = "login";
  public static final String MDM_OSN = "mdmOsn";
  public static final String PHONES = "phones";
  public static final String FULL_PHONE_NUMBER = "fullPhoneNumber";
  public static final String PHONE_TYPE = "phoneType";
  public static final String EMAILS = "emails";
  public static final String EMAIL = "email";
  public static final String EMAIL_TYPE = "emailType";

  private static final String USER_CLIENTS = "userClients";
  private static final String USER = "user";
  private static final String ACTIVE_CLIENT = "activeClient";

  private static final String INTEGRATION_NAME = "Сессионные данные";

  private final EpaIgTechTokenService epaIgService;
  private final SessionApi sessionApi;
  private final ObjectMapper objectMapper;

  @Override
  public OrganizationInfo getSessionData(HttpHeaders httpHeaders) {
    try {
      var token = httpHeaders.getFirst(HttpHeaders.AUTHORIZATION);
      var ctxi = JwtTokenUtils.extractValue(token, "ctxi");
      var techToken = epaIgService.getTechToken();
      var organizationInfoCommon = getOrganizationInfo(
          SessionRequest.builder()
              .sessionId(ctxi)
              .authorization(techToken)
              .build());
      if (organizationInfoCommon.isPresent()) {
        return organizationInfoCommon.get();
      } else {
        throw new SessionDataNotFoundException(
            "Auth exception! Session not found! Login: [" + JwtTokenUtils.extractValue(token,
                "sub") + "]");
      }
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new SessionDataNotFoundException("");
    }
  }

  public Optional<OrganizationInfo> getOrganizationInfo(SessionRequest sessionRequest) {
    if (sessionRequest.getSessionId() != null && sessionRequest.getAuthorization() != null) {
      var json = sessionApi.sessionData(sessionRequest.getSessionId(),
          sessionRequest.getAuthorization());
      if (json != null && !json.isEmpty()) {
        var optionalSessionInfo = parseQrSessionJson(json);
        if (optionalSessionInfo.isPresent()) {
          var info = new OrganizationInfo();
          var sessionInfo = optionalSessionInfo.get();
          info.setMdmCode(sessionInfo.getMdmCode());
          info.setInn(sessionInfo.getOrgInfo().getInn());
          info.setOgrn(sessionInfo.getOrgInfo().getOgrn());
          info.setEmails(sessionInfo.getEmails());
          info.setPhones(sessionInfo.getPhones());
          info.setLogin(sessionInfo.getLogin());
          info.setMdmOsn(sessionInfo.getMdmOsn());
          info.setFirstName(sessionInfo.getFirstName());
          info.setMiddleName(sessionInfo.getMiddleName());
          info.setLastName(sessionInfo.getLastName());
          info.setCitizenship(sessionInfo.getCitizenship());

          log.debug("<<< OrganizationInfo : {}", info);
          return Optional.of(info);
        }
      }
    }
    return Optional.empty();
  }

  private Optional<SessionInfo> parseQrSessionJson(String json) {
    try {
      var jsonObject = objectMapper.readValue(json, JSONObject.class);
      var keys = jsonObject.keySet();
      for (var key : keys) {
        var root = (LinkedHashMap<?, ?>) jsonObject.get(key);
        var userClients = root.getOrDefault(USER_CLIENTS, null);
        var user = root.getOrDefault(USER, null);
        if (userClients != null && user != null) {
          var jsonArray = objectMapper.readValue(userClients.toString(), JSONArray.class);
          var userJson = objectMapper.readValue(user.toString(), JsonNode.class);
          if (!jsonArray.isEmpty()) {
            var activeSession = objectMapper.convertValue(userJson.findValue(ACTIVE_CLIENT),
                SessionInfo.class);
            for (Object jsonArrayNode : jsonArray) {
              var session = objectMapper.convertValue(jsonArrayNode, SessionInfo.class);
              if (activeSession.getMdmCode().equals(session.getMdmCode())) {
                activeSession.setOrgInfo(session.getOrgInfo());
                activeSession.setFirstName(userJson.findValue(FIRST_NAME).asText());
                activeSession.setMiddleName(userJson.findValue(MIDDLE_NAME).asText());
                activeSession.setLastName(userJson.findValue(LAST_NAME).asText());
                activeSession.setCitizenship(userJson.findValue(CITIZENSHIP).asText());
                var ids = userJson.findValue(IDS);
                if (ids != null) {
                  activeSession.setLogin(userJson.findValue(LOGIN).asText());
                  activeSession.setMdmOsn(userJson.findValue(MDM_OSN).asText());
                }

                try {
                  activeSession.setPhones(getPhones(userJson));
                  activeSession.setEmails(getClientEmails(userJson));
                } catch (Exception e) {
                  // ignore
                }
              }
            }
            log.debug("Active session: {}", activeSession);
            return Optional.of(activeSession);
          }
        }
      }
    } catch (JsonProcessingException e) {
      log.error(e.getMessage());
    }
    return Optional.empty();
  }

  private List<PhoneSessionData> getPhones(JsonNode userJson) throws JsonProcessingException {
    log.debug("Phone parsing, json: {}", userJson);
    try {
      var phonesArr = new ArrayList<PhoneSessionData>();
      var phones = objectMapper.readValue(userJson.findValue(PHONES).toString(),
          JSONArray.class);
      for (var phone : phones) {
        if (phone != null) {
          phonesArr.add(PhoneSessionData.builder()
              .fullPhoneNumber(((HashMap) phone).get(FULL_PHONE_NUMBER).toString())
              .phoneType(((HashMap) phone).get(PHONE_TYPE).toString())
              .build());
        }
      }
      return phonesArr;
    } catch (Exception e) {
      return new ArrayList<>();
    }
  }

  private List<EmailSessionData> getClientEmails(JsonNode userJson) throws JsonProcessingException {
    var emailsArr = new ArrayList<EmailSessionData>();
    JSONArray emails = objectMapper.readValue(userJson.findValue(EMAILS).toString(),
        JSONArray.class);
    for (var email : emails) {
      if (email != null) {
        emailsArr.add(EmailSessionData.builder()
            .email(((HashMap)email).get(EMAIL).toString())
            .emailType(((HashMap)email).get(EMAIL_TYPE).toString())
            .build());
      }
    }
    return emailsArr;
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
    getOrganizationInfo(SessionRequest.builder()
            .sessionId(UUID.randomUUID().toString())
            .authorization(epaIgService.getTechToken())
            .build());
    } catch (NotFound e) {
      return EndpointCheckDto.builder()
          .status(HttpStatus.OK.name())
          .build();
    }
    return EndpointCheckDto.builder()
        .status(HttpStatus.OK.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
