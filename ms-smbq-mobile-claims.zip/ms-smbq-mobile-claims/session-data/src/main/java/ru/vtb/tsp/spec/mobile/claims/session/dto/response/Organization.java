package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Organization {

  private String mdmCode;

  private String slxId;

  private String fullName;

  private String shortName;

  private String inn;

  private String ogrn;

  @JsonProperty("isInBlackList")
  private boolean inBlackList;

  private String clientTypeCode;

  private String clientTypeName;

  private int clientSegmentId;

  private String clientSegmentName;

}
