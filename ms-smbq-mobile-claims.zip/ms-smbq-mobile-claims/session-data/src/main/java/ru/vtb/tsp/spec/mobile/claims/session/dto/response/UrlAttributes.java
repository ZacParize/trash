package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UrlAttributes {

  private String key1;

  private String key2;
}
