package ru.vtb.tsp.spec.mobile.claims.session.utils;

import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import javax.xml.bind.DatatypeConverter;
import java.io.Serializable;
import java.sql.Date;
import java.time.Instant;
import java.util.Base64;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;

/**
 * Методы для работы с Jwt.
 *
 * @since 12.10.2020
 */

@Slf4j
@UtilityClass
public class JwtTokenUtils implements Serializable {

  private final String TOKEN_SEPARATOR = " ";

  private final int TOKEN_PAYLOAD_CHUNK_INDEX = 1;

  private final String TOKEN_CHUNKS_SEPARATOR = "\\.";

  private final String FORMATTED_TOKEN = "Formatted token : {}";

  public void validateJwtToken(String token) {
    validateJwtToken(token, null);
  }

  public void validateJwtToken(String token, String key) {
    final var i = token.lastIndexOf('.');
    try {
      if (key == null || key.isEmpty()) {
        final var withoutSignature = token.substring(0, i + 1);
        Jwts.parserBuilder().build().parseClaimsJwt(withoutSignature);
      } else {
        Jwts.parserBuilder().setSigningKey(DatatypeConverter.parseBase64Binary(key)).build()
            .parse(token);
      }
      log.info("JWT token is valid");
    } catch (JwtException e) {
      log.info("JWT token is invalid", e);
      throw new JwtIsNotValidException();
    }
  }

  public Optional<UUID> extractJti(String token) {
    final var claims = extractClaimsFromToken(token);
    if (claims.isEmpty()) {
      return Optional.empty();
    }
    final var uuid = claims.get().get("jti", UUID.class);
    if (Objects.isNull(uuid)) {
      return Optional.empty();
    }
    return Optional.of(uuid);
  }

  public String extractValue(String token, String valueName) {
    if (token == null) {
      throw new JwtIsNotValidException();
    }
    if (token.contains(TOKEN_SEPARATOR)) {
      int TOKEN_SEPARATOR_INDEX = token.indexOf(TOKEN_SEPARATOR);
      token = token.substring(TOKEN_SEPARATOR_INDEX);
    }
    log.debug(FORMATTED_TOKEN, token);
    var chunks = token.split(TOKEN_CHUNKS_SEPARATOR);
    Base64.Decoder decoder = Base64.getDecoder();
    if (chunks.length > TOKEN_PAYLOAD_CHUNK_INDEX) {
      try {
        var payload = new String(decoder.decode(chunks[TOKEN_PAYLOAD_CHUNK_INDEX]));
        var jsonObject = JsonParser.parseString(payload).getAsJsonObject();
        if (jsonObject.has(valueName)) {
          return jsonObject.get(valueName).getAsString();
        }
      } catch (IllegalArgumentException | JsonSyntaxException e) {
        log.error(e.getMessage());
      }
    }
    throw new JwtIsNotValidException();
  }

  public Boolean isExpired(String token) {
    final var claims = extractClaimsFromToken(token);
    if (claims.isEmpty()) {
      return true;
    }
    return claims.get().getExpiration().before(Date.from(Instant.now()));
  }

  public String resolveToken(HttpServletRequest req) {
    var bearerToken = req.getHeader("Authorization");
    return resolveToken(bearerToken);
  }

  public String resolveToken(String authHeader) {
    if (authHeader != null && authHeader.startsWith("Bearer ")) {
      return authHeader.substring(7);
    }
    return null;
  }

  private Optional<Claims> extractClaimsFromToken(String token) {
    final var claims = Jwts.parserBuilder().build().parseClaimsJws(token).getBody();
    if (Objects.nonNull(claims)) {
      return Optional.of(claims);
    }
    return Optional.empty();
  }
}
