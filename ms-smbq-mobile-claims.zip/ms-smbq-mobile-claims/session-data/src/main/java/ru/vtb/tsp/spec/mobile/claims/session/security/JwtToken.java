package ru.vtb.tsp.spec.mobile.claims.session.security;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import ru.vtb.tsp.spec.mobile.claims.session.utils.DomainUtils;

import java.util.*;

import static com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL;

@JsonInclude(NON_NULL)
public class JwtToken {
    private Long exp;
    private Long iat;
    private String jti;
    private String iss;
    private String ip;
    private Object aud;
    private String sub;
    private String typ;
    private String azp;
    @JsonProperty("session_state")
    private String sessionState;
    private String acr;
    @JsonProperty("allowed-origins")
    private List<String> allowedOrigins;
    @JsonFormat(
        with = {JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY}
    )
    private List<String> scope;
    @JsonProperty("email_verified")
    private Boolean emailVerified;
    private String ctxi;
    private List<String> roles = new ArrayList();
    private String name;
    @JsonProperty("first_name")
    private String firstName;
    @JsonProperty("last_name")
    private String lastName;
    @JsonProperty("middle_name")
    private String middleName;
    @JsonProperty("attributes")
    private JwtTokenAttributes jwtTokenAttributes;
    private String email;
    @JsonProperty("generation_qualifier")
    private String generationQualifier;
    private List<String> permissions = new ArrayList();
    private String channel;

    public Map<String, Object> toPayloadClaimsMap() {
        Map<String, Object> payloadClaims = new HashMap();
        DomainUtils.putIfNotNull("session_state", this.sessionState, payloadClaims);
        DomainUtils.putIfNotNull("roles", this.roles, payloadClaims);
        if (Objects.nonNull(this.jwtTokenAttributes)) {
            DomainUtils.putIfNotNull("attributes", this.jwtTokenAttributes.toMap(), payloadClaims);
        }

        DomainUtils.putIfNotNull("permissions", this.permissions, payloadClaims);
        DomainUtils.putIfNotNull("scope", this.scope, payloadClaims);
        DomainUtils.putIfNotNull("email", this.email, payloadClaims);
        DomainUtils.putIfNotNull("email_verified", this.emailVerified, payloadClaims);
        DomainUtils.putIfNotNull("name", this.name, payloadClaims);
        DomainUtils.putIfNotNull("first_name", this.firstName, payloadClaims);
        DomainUtils.putIfNotNull("last_name", this.lastName, payloadClaims);
        DomainUtils.putIfNotNull("middle_name", this.middleName, payloadClaims);
        DomainUtils.putIfNotNull("sub", this.sub, payloadClaims);
        DomainUtils.putIfNotNull("generation_qualifier", this.generationQualifier, payloadClaims);
        DomainUtils.putIfNotNull("channel", this.channel, payloadClaims);
        DomainUtils.putIfNotNull("ctxi", this.ctxi, payloadClaims);
        return payloadClaims;
    }

    public void fillFromUserInfo(UserInfo userInfo) {
        this.setRoles(userInfo.getRoles());
        this.setPermissions(userInfo.getPermissions());
        if (this.jwtTokenAttributes == null) {
            this.jwtTokenAttributes = new JwtTokenAttributes();
        }

        Map<String, Object> userInfoAttributes = userInfo.getAttributes();
        this.jwtTokenAttributes.fillFromMap(userInfoAttributes);
        this.setEmail((String)userInfoAttributes.get("email"));
        this.setName((String)userInfoAttributes.get("name"));
        this.setFirstName((String)userInfoAttributes.get("first_name"));
        this.setLastName((String)userInfoAttributes.get("last_name"));
        this.setMiddleName((String)userInfoAttributes.get("middle_name"));
        this.setGenerationQualifier((String)userInfoAttributes.get("generation_qualifier"));
    }

    public Long getExp() {
        return this.exp;
    }

    public Long getIat() {
        return this.iat;
    }

    public String getJti() {
        return this.jti;
    }

    public String getIss() {
        return this.iss;
    }

    public String getIp() {
        return this.ip;
    }

    public Object getAud() {
        return this.aud;
    }

    public String getSub() {
        return this.sub;
    }

    public String getTyp() {
        return this.typ;
    }

    public String getAzp() {
        return this.azp;
    }

    public String getSessionState() {
        return this.sessionState;
    }

    public String getAcr() {
        return this.acr;
    }

    public List<String> getAllowedOrigins() {
        return this.allowedOrigins;
    }

    public List<String> getScope() {
        return this.scope;
    }

    public Boolean getEmailVerified() {
        return this.emailVerified;
    }

    public String getCtxi() {
        return this.ctxi;
    }

    public List<String> getRoles() {
        return this.roles;
    }

    public String getName() {
        return this.name;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public String getMiddleName() {
        return this.middleName;
    }

    public JwtTokenAttributes getJwtTokenAttributes() {
        return this.jwtTokenAttributes;
    }

    public String getEmail() {
        return this.email;
    }

    public String getGenerationQualifier() {
        return this.generationQualifier;
    }

    public List<String> getPermissions() {
        return this.permissions;
    }

    public String getChannel() {
        return this.channel;
    }

    public JwtToken setExp(final Long exp) {
        this.exp = exp;
        return this;
    }

    public JwtToken setIat(final Long iat) {
        this.iat = iat;
        return this;
    }

    public JwtToken setJti(final String jti) {
        this.jti = jti;
        return this;
    }

    public JwtToken setIss(final String iss) {
        this.iss = iss;
        return this;
    }

    public JwtToken setIp(final String ip) {
        this.ip = ip;
        return this;
    }

    public JwtToken setAud(final Object aud) {
        this.aud = aud;
        return this;
    }

    public JwtToken setSub(final String sub) {
        this.sub = sub;
        return this;
    }

    public JwtToken setTyp(final String typ) {
        this.typ = typ;
        return this;
    }

    public JwtToken setAzp(final String azp) {
        this.azp = azp;
        return this;
    }

    @JsonProperty("session_state")
    public JwtToken setSessionState(final String sessionState) {
        this.sessionState = sessionState;
        return this;
    }

    public JwtToken setAcr(final String acr) {
        this.acr = acr;
        return this;
    }

    @JsonProperty("allowed-origins")
    public JwtToken setAllowedOrigins(final List<String> allowedOrigins) {
        this.allowedOrigins = allowedOrigins;
        return this;
    }

    public JwtToken setScope(final List<String> scope) {
        this.scope = scope;
        return this;
    }

    @JsonProperty("email_verified")
    public JwtToken setEmailVerified(final Boolean emailVerified) {
        this.emailVerified = emailVerified;
        return this;
    }

    public JwtToken setCtxi(final String ctxi) {
        this.ctxi = ctxi;
        return this;
    }

    public JwtToken setRoles(final List<String> roles) {
        this.roles = roles;
        return this;
    }

    public JwtToken setName(final String name) {
        this.name = name;
        return this;
    }

    @JsonProperty("first_name")
    public JwtToken setFirstName(final String firstName) {
        this.firstName = firstName;
        return this;
    }

    @JsonProperty("last_name")
    public JwtToken setLastName(final String lastName) {
        this.lastName = lastName;
        return this;
    }

    @JsonProperty("middle_name")
    public JwtToken setMiddleName(final String middleName) {
        this.middleName = middleName;
        return this;
    }

    @JsonProperty("attributes")
    public JwtToken setJwtTokenAttributes(final JwtTokenAttributes jwtTokenAttributes) {
        this.jwtTokenAttributes = jwtTokenAttributes;
        return this;
    }

    public JwtToken setEmail(final String email) {
        this.email = email;
        return this;
    }

    @JsonProperty("generation_qualifier")
    public JwtToken setGenerationQualifier(final String generationQualifier) {
        this.generationQualifier = generationQualifier;
        return this;
    }

    public JwtToken setPermissions(final List<String> permissions) {
        this.permissions = permissions;
        return this;
    }

    public JwtToken setChannel(final String channel) {
        this.channel = channel;
        return this;
    }

    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        } else if (!(o instanceof JwtToken)) {
            return false;
        } else {
            JwtToken other = (JwtToken)o;
            if (!other.canEqual(this)) {
                return false;
            } else {
                label311: {
                    Object this$exp = this.getExp();
                    Object other$exp = other.getExp();
                    if (this$exp == null) {
                        if (other$exp == null) {
                            break label311;
                        }
                    } else if (this$exp.equals(other$exp)) {
                        break label311;
                    }

                    return false;
                }

                Object this$iat = this.getIat();
                Object other$iat = other.getIat();
                if (this$iat == null) {
                    if (other$iat != null) {
                        return false;
                    }
                } else if (!this$iat.equals(other$iat)) {
                    return false;
                }

                label297: {
                    Object this$jti = this.getJti();
                    Object other$jti = other.getJti();
                    if (this$jti == null) {
                        if (other$jti == null) {
                            break label297;
                        }
                    } else if (this$jti.equals(other$jti)) {
                        break label297;
                    }

                    return false;
                }

                Object this$iss = this.getIss();
                Object other$iss = other.getIss();
                if (this$iss == null) {
                    if (other$iss != null) {
                        return false;
                    }
                } else if (!this$iss.equals(other$iss)) {
                    return false;
                }

                label283: {
                    Object this$ip = this.getIp();
                    Object other$ip = other.getIp();
                    if (this$ip == null) {
                        if (other$ip == null) {
                            break label283;
                        }
                    } else if (this$ip.equals(other$ip)) {
                        break label283;
                    }

                    return false;
                }

                Object this$aud = this.getAud();
                Object other$aud = other.getAud();
                if (this$aud == null) {
                    if (other$aud != null) {
                        return false;
                    }
                } else if (!this$aud.equals(other$aud)) {
                    return false;
                }

                label269: {
                    Object this$sub = this.getSub();
                    Object other$sub = other.getSub();
                    if (this$sub == null) {
                        if (other$sub == null) {
                            break label269;
                        }
                    } else if (this$sub.equals(other$sub)) {
                        break label269;
                    }

                    return false;
                }

                label262: {
                    Object this$typ = this.getTyp();
                    Object other$typ = other.getTyp();
                    if (this$typ == null) {
                        if (other$typ == null) {
                            break label262;
                        }
                    } else if (this$typ.equals(other$typ)) {
                        break label262;
                    }

                    return false;
                }

                Object this$azp = this.getAzp();
                Object other$azp = other.getAzp();
                if (this$azp == null) {
                    if (other$azp != null) {
                        return false;
                    }
                } else if (!this$azp.equals(other$azp)) {
                    return false;
                }

                label248: {
                    Object this$sessionState = this.getSessionState();
                    Object other$sessionState = other.getSessionState();
                    if (this$sessionState == null) {
                        if (other$sessionState == null) {
                            break label248;
                        }
                    } else if (this$sessionState.equals(other$sessionState)) {
                        break label248;
                    }

                    return false;
                }

                label241: {
                    Object this$acr = this.getAcr();
                    Object other$acr = other.getAcr();
                    if (this$acr == null) {
                        if (other$acr == null) {
                            break label241;
                        }
                    } else if (this$acr.equals(other$acr)) {
                        break label241;
                    }

                    return false;
                }

                Object this$allowedOrigins = this.getAllowedOrigins();
                Object other$allowedOrigins = other.getAllowedOrigins();
                if (this$allowedOrigins == null) {
                    if (other$allowedOrigins != null) {
                        return false;
                    }
                } else if (!this$allowedOrigins.equals(other$allowedOrigins)) {
                    return false;
                }

                Object this$scope = this.getScope();
                Object other$scope = other.getScope();
                if (this$scope == null) {
                    if (other$scope != null) {
                        return false;
                    }
                } else if (!this$scope.equals(other$scope)) {
                    return false;
                }

                label220: {
                    Object this$emailVerified = this.getEmailVerified();
                    Object other$emailVerified = other.getEmailVerified();
                    if (this$emailVerified == null) {
                        if (other$emailVerified == null) {
                            break label220;
                        }
                    } else if (this$emailVerified.equals(other$emailVerified)) {
                        break label220;
                    }

                    return false;
                }

                Object this$ctxi = this.getCtxi();
                Object other$ctxi = other.getCtxi();
                if (this$ctxi == null) {
                    if (other$ctxi != null) {
                        return false;
                    }
                } else if (!this$ctxi.equals(other$ctxi)) {
                    return false;
                }

                Object this$roles = this.getRoles();
                Object other$roles = other.getRoles();
                if (this$roles == null) {
                    if (other$roles != null) {
                        return false;
                    }
                } else if (!this$roles.equals(other$roles)) {
                    return false;
                }

                label199: {
                    Object this$name = this.getName();
                    Object other$name = other.getName();
                    if (this$name == null) {
                        if (other$name == null) {
                            break label199;
                        }
                    } else if (this$name.equals(other$name)) {
                        break label199;
                    }

                    return false;
                }

                Object this$firstName = this.getFirstName();
                Object other$firstName = other.getFirstName();
                if (this$firstName == null) {
                    if (other$firstName != null) {
                        return false;
                    }
                } else if (!this$firstName.equals(other$firstName)) {
                    return false;
                }

                label185: {
                    Object this$lastName = this.getLastName();
                    Object other$lastName = other.getLastName();
                    if (this$lastName == null) {
                        if (other$lastName == null) {
                            break label185;
                        }
                    } else if (this$lastName.equals(other$lastName)) {
                        break label185;
                    }

                    return false;
                }

                Object this$middleName = this.getMiddleName();
                Object other$middleName = other.getMiddleName();
                if (this$middleName == null) {
                    if (other$middleName != null) {
                        return false;
                    }
                } else if (!this$middleName.equals(other$middleName)) {
                    return false;
                }

                label171: {
                    Object this$jwtTokenAttributes = this.getJwtTokenAttributes();
                    Object other$jwtTokenAttributes = other.getJwtTokenAttributes();
                    if (this$jwtTokenAttributes == null) {
                        if (other$jwtTokenAttributes == null) {
                            break label171;
                        }
                    } else if (this$jwtTokenAttributes.equals(other$jwtTokenAttributes)) {
                        break label171;
                    }

                    return false;
                }

                Object this$email = this.getEmail();
                Object other$email = other.getEmail();
                if (this$email == null) {
                    if (other$email != null) {
                        return false;
                    }
                } else if (!this$email.equals(other$email)) {
                    return false;
                }

                label157: {
                    Object this$generationQualifier = this.getGenerationQualifier();
                    Object other$generationQualifier = other.getGenerationQualifier();
                    if (this$generationQualifier == null) {
                        if (other$generationQualifier == null) {
                            break label157;
                        }
                    } else if (this$generationQualifier.equals(other$generationQualifier)) {
                        break label157;
                    }

                    return false;
                }

                label150: {
                    Object this$permissions = this.getPermissions();
                    Object other$permissions = other.getPermissions();
                    if (this$permissions == null) {
                        if (other$permissions == null) {
                            break label150;
                        }
                    } else if (this$permissions.equals(other$permissions)) {
                        break label150;
                    }

                    return false;
                }

                Object this$channel = this.getChannel();
                Object other$channel = other.getChannel();
                if (this$channel == null) {
                    if (other$channel != null) {
                        return false;
                    }
                } else if (!this$channel.equals(other$channel)) {
                    return false;
                }

                return true;
            }
        }
    }

    protected boolean canEqual(final Object other) {
        return other instanceof JwtToken;
    }

    public int hashCode() {
        int result = 1;
        Object $exp = this.getExp();
        result = result * 59 + ($exp == null ? 43 : $exp.hashCode());
        Object $iat = this.getIat();
        result = result * 59 + ($iat == null ? 43 : $iat.hashCode());
        Object $jti = this.getJti();
        result = result * 59 + ($jti == null ? 43 : $jti.hashCode());
        Object $iss = this.getIss();
        result = result * 59 + ($iss == null ? 43 : $iss.hashCode());
        Object $ip = this.getIp();
        result = result * 59 + ($ip == null ? 43 : $ip.hashCode());
        Object $aud = this.getAud();
        result = result * 59 + ($aud == null ? 43 : $aud.hashCode());
        Object $sub = this.getSub();
        result = result * 59 + ($sub == null ? 43 : $sub.hashCode());
        Object $typ = this.getTyp();
        result = result * 59 + ($typ == null ? 43 : $typ.hashCode());
        Object $azp = this.getAzp();
        result = result * 59 + ($azp == null ? 43 : $azp.hashCode());
        Object $sessionState = this.getSessionState();
        result = result * 59 + ($sessionState == null ? 43 : $sessionState.hashCode());
        Object $acr = this.getAcr();
        result = result * 59 + ($acr == null ? 43 : $acr.hashCode());
        Object $allowedOrigins = this.getAllowedOrigins();
        result = result * 59 + ($allowedOrigins == null ? 43 : $allowedOrigins.hashCode());
        Object $scope = this.getScope();
        result = result * 59 + ($scope == null ? 43 : $scope.hashCode());
        Object $emailVerified = this.getEmailVerified();
        result = result * 59 + ($emailVerified == null ? 43 : $emailVerified.hashCode());
        Object $ctxi = this.getCtxi();
        result = result * 59 + ($ctxi == null ? 43 : $ctxi.hashCode());
        Object $roles = this.getRoles();
        result = result * 59 + ($roles == null ? 43 : $roles.hashCode());
        Object $name = this.getName();
        result = result * 59 + ($name == null ? 43 : $name.hashCode());
        Object $firstName = this.getFirstName();
        result = result * 59 + ($firstName == null ? 43 : $firstName.hashCode());
        Object $lastName = this.getLastName();
        result = result * 59 + ($lastName == null ? 43 : $lastName.hashCode());
        Object $middleName = this.getMiddleName();
        result = result * 59 + ($middleName == null ? 43 : $middleName.hashCode());
        Object $jwtTokenAttributes = this.getJwtTokenAttributes();
        result = result * 59 + ($jwtTokenAttributes == null ? 43 : $jwtTokenAttributes.hashCode());
        Object $email = this.getEmail();
        result = result * 59 + ($email == null ? 43 : $email.hashCode());
        Object $generationQualifier = this.getGenerationQualifier();
        result = result * 59 + ($generationQualifier == null ? 43 : $generationQualifier.hashCode());
        Object $permissions = this.getPermissions();
        result = result * 59 + ($permissions == null ? 43 : $permissions.hashCode());
        Object $channel = this.getChannel();
        result = result * 59 + ($channel == null ? 43 : $channel.hashCode());
        return result;
    }

    public String toString() {
        Long var10000 = this.getExp();
        return "JwtToken(exp=" + var10000 + ", iat=" + this.getIat() + ", jti=" + this.getJti() + ", iss=" + this.getIss() + ", ip=" + this.getIp() + ", aud=" + this.getAud() + ", sub=" + this.getSub() + ", typ=" + this.getTyp() + ", azp=" + this.getAzp() + ", sessionState=" + this.getSessionState() + ", acr=" + this.getAcr() + ", allowedOrigins=" + this.getAllowedOrigins() + ", scope=" + this.getScope() + ", emailVerified=" + this.getEmailVerified() + ", ctxi=" + this.getCtxi() + ", roles=" + this.getRoles() + ", name=" + this.getName() + ", firstName=" + this.getFirstName() + ", lastName=" + this.getLastName() + ", middleName=" + this.getMiddleName() + ", jwtTokenAttributes=" + this.getJwtTokenAttributes() + ", email=" + this.getEmail() + ", generationQualifier=" + this.getGenerationQualifier() + ", permissions=" + this.getPermissions() + ", channel=" + this.getChannel() + ")";
    }

    public JwtToken() {
    }
}