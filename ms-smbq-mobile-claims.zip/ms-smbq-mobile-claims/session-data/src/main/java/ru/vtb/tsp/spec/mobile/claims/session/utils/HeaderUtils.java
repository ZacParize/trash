package ru.vtb.tsp.spec.mobile.claims.session.utils;

import java.util.Optional;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.session.filter.ClaimIdMdcFilter;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class HeaderUtils {

  public static String getClaimId(HttpHeaders headers) {
    return Optional.ofNullable(headers.getFirst(ClaimIdMdcFilter.X_CLAIM_SESSION_ID)).orElse("");
  }

}
