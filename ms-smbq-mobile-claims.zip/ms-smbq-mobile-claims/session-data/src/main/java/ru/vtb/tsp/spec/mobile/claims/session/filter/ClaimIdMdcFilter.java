package ru.vtb.tsp.spec.mobile.claims.session.filter;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Component
public class ClaimIdMdcFilter extends OncePerRequestFilter {

    public static final String X_CLAIM_SESSION_ID = "X-CLAIM-SESSION-ID";
    public static final String CLAIM_SESSION_ID = "claimSessionId";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        var claimId = request.getHeader(X_CLAIM_SESSION_ID);
        MDC.put(CLAIM_SESSION_ID, claimId);
        try {
            filterChain.doFilter(request, response);
        } finally {
            MDC.remove(CLAIM_SESSION_ID);
        }
    }
}