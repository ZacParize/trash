package ru.vtb.tsp.spec.mobile.claims.session.utils;

import java.util.Map;
import java.util.Objects;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DomainUtils {
    public static void putIfNotNull(String key, Object value, Map<String, Object> map) {
        if (Objects.nonNull(value)) {
            map.put(key, value);
        }

    }

}