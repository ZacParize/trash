package ru.vtb.tsp.spec.mobile.claims.session.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;

@FeignClient(name = "sessionData", url = "${session.data.url}",
    configuration = {LogFeignConfiguration.class,
        SslFeignConfiguration.class})
public interface SessionApi {

  @GetMapping(value = "/session/{sessionId}", produces = "application/json")
  String sessionData(@PathVariable("sessionId") String sessionId,
                     @RequestHeader("Authorization") String token);
}