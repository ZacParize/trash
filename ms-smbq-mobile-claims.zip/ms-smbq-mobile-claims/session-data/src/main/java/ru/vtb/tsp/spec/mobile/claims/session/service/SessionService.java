package ru.vtb.tsp.spec.mobile.claims.session.service;

import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.OrganizationInfo;

/**
 * Сервис для получения информации из сервиса Сессионные данные
 */
public interface SessionService {

  OrganizationInfo getSessionData(HttpHeaders httpHeaders);

}
