package ru.vtb.tsp.spec.mobile.claims.session.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.OrganizationInfo;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;

@Service
@Slf4j
@Profile("session_stub")
@RequiredArgsConstructor
public class SessionServiceStub implements SessionService {

  @Override
  public OrganizationInfo getSessionData(HttpHeaders httpHeaders) {
    var orgInfo = new OrganizationInfo();
    orgInfo.setInn("9999");
    orgInfo.setOgrn("666");
    orgInfo.setMdmCode("555");
    orgInfo.setLogin("wilson");
    orgInfo.setFirstName("Уилсон");
    orgInfo.setMiddleName("что-то");
    orgInfo.setLastName("Иванович");
    return orgInfo;
  }
}
