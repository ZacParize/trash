package ru.vtb.tsp.spec.mobile.claims.session.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Representative {

  private long mdmOsn;

  private String lastName;

  private String firstName;

  private String middleName;

  @JsonProperty("isEIO")
  private boolean eio;

}
