package ru.vtb.tsp.spec.session.config;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import ru.vtb.tsp.spec.session.TestApplication;

@ActiveProfiles(profiles = {"tests", "session_stub"})
@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = TestApplication.class, webEnvironment = WebEnvironment.NONE)
public abstract class TestsConfiguration {

}
