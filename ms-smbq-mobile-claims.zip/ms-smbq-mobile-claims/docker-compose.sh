#!/bin/sh

. .env

LOGIN_SPEC_IMAGE= "docker login -u $USER -p $PASSWORD $BASE_URL"
PULL_SPEC_IMAGE="docker pull $SPEC_IMAGE"
START_SPEC_IMAGE="docker-compose up"

$LOGIN_SPEC_IMAGE
$PULL_SPEC_IMAGE
$START_SPEC_IMAGE

sleep 20