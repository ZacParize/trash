package ru.vtb.tsp.spec.mobile.claims.audit.consts;

public abstract class AuditConstant {

  public static final String SMBQ_MB_CLAIMS_PROCESS_INIT = "SMBQ_MB_CLAIMS_PROCESS_INIT";

  public static final String SMBQ_MB_CLAIMS_SEND_KAFKA = "SMBQ_MB_CLAIMS_SEND_KAFKA";

  public static final String SMBQ_MB_CLAIMS_DOCS_SIGN = "SMBQ_MB_CLAIMS_DOCS_SIGN";

  public static final String SMBQ_MB_CLAIMS_DOCS_GENERATE = "SMBQ_MB_CLAIMS_DOCS_GENERATE";

  public static final String SMBQ_MB_CLAIMS_DOCS_SAVE = "SMBQ_MB_CLAIMS_DOCS_SAVE";

  public static final String SMBQ_MB_CLAIMS_DOCS_DOWNLOAD = "SMBQ_MB_CLAIMS_DOCS_DOWNLOAD";

  private AuditConstant() {
  }
}