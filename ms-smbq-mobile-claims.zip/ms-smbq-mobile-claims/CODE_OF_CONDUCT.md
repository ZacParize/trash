### Название ветки.
Тип задачи:
- `feature` - Добавление новой функциональности или изменение старой. Создание от **develop**
- `bugfix` - Исправление бага. Создание от **develop**
- `hotfix` - Исправление бага с прода. Создание от **master**  
`Пример - feature/TSPSPEC-2309`
---
### Code Style:
Используем [code-style/google-style.xml](code-style/google-style.xml)  
Установка в IDEA: File > Settings > Editor > Code Style > Import Scheme
---

### Название тестов.

Согласно формату `methodName_stateUnderTest_expectedBehavior`  
Примеры:

    isAdult_ageLessThan18_false
    withdrawMoney_invalidAccount_exceptionThrown
    admitStudent_missingMandatoryFields_failToAdmit
---

### Название коммитов:
       Формат: (Номер задачи) описание.
       Пример: (TSPSPEC-2334) added ffdVersion to ofd

Коммит с апом версии должен иметь формат:

`up version VERSION_NUMBER`

---
### Формирование ПР:

* Если изменения в Bpmn схемах Camunda - Приложить к ПР скриншоты новых изменений.
Выделить их цветом.  
* Если ветку нельзя сливать. В заголовке ПР ставить метку `NO_MERGE`.  
`Пример: [NO_MERGE] feature/TSPSPEC-2247`  
Когда ветку можно слить, убрать `NO_MERGE` из заголовка.
* Исправлять замечания Sonar(code smell).
* После исправления замечания, добавить ответ "fixed"
* Если в ПР присутствуют регулярные выражения, добавить ссылку на расшифровку регулярного выражения на regex101.com 
* Отразить в какой ветке задача выполнялась в [таблице](https://sfera.inno.local/knowledge/pages?id=951758) Если конфиги отсутствуют - ставить `none`
* В стори, в рамках которой задача выполнялась, отразить название ветки бэка и конфигов.   
Формат:`бэк: feature/TSPSPEC-2247, конфиги: feature/TSPSPEC-2247`. Если конфиги отсутствуют - ставить `none`
---
### Название DTO:
При создании новых, делать разделение на 2 вида: Request и Response.  
`Пример: AccountRequest, AccountResponse`

---
### Изменение маскирования происходит в:
   [application/src/main/java/ru/vtb/tsp/spec/app/consts/MaskingConstants.java](application/src/main/java/ru/vtb/tsp/spec/app/consts/MaskingConstants.java)
   * Если новый паттерн - реализовать тест
   [application/src/test/java/ru/vtb/tsp/spec/app/util/masking/MaskingTest.java](application/src/test/java/ru/vtb/tsp/spec/app/util/masking/MaskingTest.java)
---
### Создание релиза:
* Отрезать от **develop** ветку `release/RM-XXX`,
повысить в ней 3 цифру  
`Пример:`  
`Текущая версия - <revision>1.8.7-SNAPSHOT</revision>`  
`Новая версия - <revision>1.8.8-SNAPSHOT</revision>`

* В ветке **develop** увеличить в revision [pom.xml](pom.xml) вторую цифру версии.  
`Пример:`  
`Текущая версия - <revision>1.8.7-SNAPSHOT</revision>`  
`Новая версия - <revision>1.9.0-SNAPSHOT</revision>`

* Проверить что джоба **dev** успешно выполнилась и проставился тэг  
https://teamcity-cicdl.corp.dev.vtb/buildConfiguration/SMBQ_Spec_Dev_BuildMsSmbqSpec#all-projects

* Собрать релизную версию  
https://teamcity-cicdl.corp.dev.vtb/buildConfiguration/SMBQ_Spec_Release_BuildMsSmbqSpec?mode=builds#all-projects
---
### Структура миграций:
* Миграции базы данных располагаются по адресу  
[application/src/main/resources/db/changelog](application/src/main/resources/db/changelog)
* Основная структура
    - Директория текущего `года`
    - Директория текущего `месяца`
    - Две директории `data` (для миграций) и `sql` (для sql скриптов).   
    В миграциях следует описывать изменение структуры базы данных,  
    в sql добавление/изменение данных  
   Плюс файл changelog-cumulative.xml для этих двух директории.
    - Файлы следует именовать следующим образом.  
   `число месяца-версия-тип действия-таблица`  
 Типы действий: 
      `create` (создание таблиц),  
      `update` (обновление),  
      `data` (добавление/изменение данных),  
      `system` (добавление/изменение данных в системных таблицах)
      
`Пример:`
```
`-- db
    `-- changelog
        `-- db.changelog-master.xml
        | -- 2023
             `-- changelog-cumulative.xml  
             |-- 01
                 `-- changelog-cumulative.xml
                 | -- data
                 |    ` -- 12-01-create-table-name.xml
                 |    ` -- 12-01-update-table-name.xml
                 |    ` -- 12-02-update-table-name.xml
                 |    ` -- 13-01-system-table-name.xml
                 | -- sql
                      ` -- 11-01-data-table-name.sql
           
           
           
           
```
      
