package ru.vtb.tsp.spec.mobile.claims.service.impl;

import feign.FeignException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.api.FileStorageServiceApi;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.Permission;
import ru.vtb.tsp.spec.mobile.claims.dto.request.PermissionSharingInputDTO;
import ru.vtb.tsp.spec.mobile.claims.dto.response.FileStoreResponse;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkDownloadFileException;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkUploadException;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.FileStorageService;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.UUID;

@Service
@Profile("!ecm_stub")
@Slf4j
@RequiredArgsConstructor
public class FileStorageServiceImpl implements FileStorageService, CheckIntegrationService {

  private final FileStorageServiceApi fileStorageServiceApi;
  private final EpaIgTechTokenService epaIgService;

  private static final String ATTACHMENT = "attachment";
  public final static String INTEGRATION_NAME = "СХК";

  @Value("${cxk.service-to.grant}")
  private String serviceToGrant;

  @Override
  public void createPermission(UUID uuid) {
    try {
      fileStorageServiceApi.createPermission(PermissionSharingInputDTO.builder()
              .permissions(List.of(Permission.GRANT, Permission.DOWNLOAD))
              .serviceTo(serviceToGrant)
              .fileUUID(uuid)
              .build(), tokenAuthorization());
    } catch (Exception e) {
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  public void deletePermission(UUID uuid) {
    try {
      fileStorageServiceApi.deletePermission(PermissionSharingInputDTO.builder()
              .permissions(List.of(Permission.GRANT, Permission.DOWNLOAD))
              .serviceTo(serviceToGrant)
              .fileUUID(uuid)
              .build(), tokenAuthorization());
    } catch (Exception e) {
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  public void acquireOwnership(List<UUID> uuids) {
    try {
      fileStorageServiceApi.acquireOwnership(false, uuids, tokenAuthorization());
    } catch (Exception e) {
      throw new InvalidExternalSystemResponseException("");
    }
  }

  @Override
  @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_DOCS_SAVE,
      techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
  public FileStoreResponse upload(String contentType, byte[] file,
                                                  String fileName, String claimId) {
    try {
      var headers = tokenAuthorization();
      headers.add(HttpHeaders.CONTENT_TYPE, contentType);

      var contentDisposition = ContentDisposition
          .builder(ATTACHMENT)
          .filename(fileName, StandardCharsets.UTF_8)
          .build().toString();
      headers.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition);
      return fileStorageServiceApi.upload(file, headers);
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new CxkUploadException("");
    }
  }

  @Override
  public byte[] download(UUID uuid) {
    try {
      HttpHeaders headers = tokenAuthorization();
      return fileStorageServiceApi.download(uuid, headers);
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new CxkDownloadFileException("");
    }
  }

  @Override
  public Boolean delete(UUID uuid) {
    HttpHeaders headers = tokenAuthorization();
    try {
      ResponseEntity<Object> response = fileStorageServiceApi.delete(uuid, headers);
      return response.getStatusCode().equals(HttpStatus.NO_CONTENT);
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      return false;
    }
  }

  private HttpHeaders tokenAuthorization() {
    HttpHeaders headers = new HttpHeaders();
    headers.add(HttpHeaders.AUTHORIZATION, epaIgService.getTechToken());
    return headers;
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    var headers = tokenAuthorization();
    var fileName = "тест";
    var contentDisposition = ContentDisposition
            .builder(ATTACHMENT)
            .filename(fileName, StandardCharsets.UTF_8)
            .build().toString();
    headers.add(HttpHeaders.CONTENT_DISPOSITION, contentDisposition);
    var upload = fileStorageServiceApi.upload(fileName.getBytes(StandardCharsets.UTF_8), headers);
    var delete = fileStorageServiceApi.delete(upload.getUuid(), headers);
    return EndpointCheckDto.builder()
        .status(delete.getStatusCode().name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
