package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.List;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.spec.mobile.claims.dto.response.FileStoreResponse;

import java.util.UUID;


public interface FileStorageService {

  FileStoreResponse upload(String contentType, byte[] file, String fileName, String claimId);

  byte[] download(UUID uuid);

  Boolean delete(UUID uuid);

  void createPermission(UUID uuid);

  void deletePermission(UUID uuid);

  void acquireOwnership(List<UUID> uuids);
}
