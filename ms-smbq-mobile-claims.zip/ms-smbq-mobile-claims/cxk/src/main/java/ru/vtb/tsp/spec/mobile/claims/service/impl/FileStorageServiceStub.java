package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.response.FileStoreResponse;
import ru.vtb.tsp.spec.mobile.claims.service.FileStorageService;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.UUID;

@Service
@Profile("ecm_stub")
@RequiredArgsConstructor
public class FileStorageServiceStub implements FileStorageService {

  @Value("ecm-integration/src/main/resources/stub/image-response.png")
  String resourceFile;

  @Override
  public FileStoreResponse upload(String contentType, byte[] file,
                                                  String fileName, String claimId) {
    FileStoreResponse fileStoreResponse = new FileStoreResponse();
    fileStoreResponse.setUuid(UUID.randomUUID());
    fileStoreResponse.setName("vtb-kassa-test.jpg");
    fileStoreResponse.setFolder("test-folder");
    fileStoreResponse.setSize(10L);
    fileStoreResponse.setType("vtbCashboxAgreement");
    fileStoreResponse.setHashSum("6534a018013a19e0b081ea03ac7a75f1");
    return fileStoreResponse;
  }

  @Override
  public byte[] download(UUID uuid) {
    try {
      File file = new File(resourceFile);
      byte[] bytes = new byte[(int) file.length()];
      BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(file));
      bufferedInputStream.read(bytes, 0, bytes.length);
      return bytes;
    } catch (Exception e) {
      return null;
    }
  }

  @Override
  public Boolean delete(UUID uuid) {
    return true;
  }

  @Override
  public void createPermission(UUID uuid) {

  }

  @Override
  public void deletePermission(UUID uuid) {

  }

  @Override
  public void acquireOwnership(List<UUID> uuids) {

  }
}
