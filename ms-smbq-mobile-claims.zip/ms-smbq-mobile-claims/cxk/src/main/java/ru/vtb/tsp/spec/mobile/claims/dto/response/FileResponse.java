package ru.vtb.tsp.spec.mobile.claims.dto.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FileResponse {

  private String byteArray;

  private String description;

  private String filename;

  private boolean open;

  private boolean readable;

  private String uri;

  private String url;
}
