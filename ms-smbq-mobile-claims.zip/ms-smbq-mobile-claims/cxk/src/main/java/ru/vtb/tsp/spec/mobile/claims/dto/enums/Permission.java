package ru.vtb.tsp.spec.mobile.claims.dto.enums;

public enum Permission {

    GRANT,
    DOWNLOAD,
    ATTACH,
    DELETE,
    ACQUIRE,
    ACQUIRE_QUOTA,
    UPLOAD,
    USE_QUOTA

}
