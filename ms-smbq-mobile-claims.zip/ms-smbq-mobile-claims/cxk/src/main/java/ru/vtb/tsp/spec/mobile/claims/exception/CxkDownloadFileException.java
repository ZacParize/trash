package ru.vtb.tsp.spec.mobile.claims.exception;

public class CxkDownloadFileException extends RuntimeException {

  public CxkDownloadFileException(String message) {
    super(message);
  }
}
