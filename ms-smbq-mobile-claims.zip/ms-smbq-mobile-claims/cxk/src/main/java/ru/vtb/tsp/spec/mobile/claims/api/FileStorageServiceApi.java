package ru.vtb.tsp.spec.mobile.claims.api;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.PermissionSharingInputDTO;
import ru.vtb.tsp.spec.mobile.claims.dto.response.FileStoreResponse;

import java.util.UUID;

@FeignClient(name = "ecmData", url = "${ecm.data.url}",
    configuration = {LogFeignConfiguration.class,
        SslFeignConfiguration.class})
public interface FileStorageServiceApi {

  @PostMapping(path = "/files")
  FileStoreResponse upload(@RequestBody byte[] file,
                                           @RequestHeader HttpHeaders headers);

  @GetMapping("/files/{uuid}")
  byte[] download(@PathVariable("uuid") UUID uuid,
      @RequestHeader HttpHeaders headers);

  @DeleteMapping("/files/{uuid}")
  ResponseEntity<Object> delete(@PathVariable("uuid") UUID uuid,
      @RequestHeader HttpHeaders headers);

  @PostMapping("/permission-sharings")
  ResponseEntity<Void> createPermission(@RequestBody PermissionSharingInputDTO dto,
      @RequestHeader HttpHeaders headers);

  @DeleteMapping("/permission-sharings")
  ResponseEntity<Void> deletePermission(@RequestBody PermissionSharingInputDTO dto,
      @RequestHeader HttpHeaders headers);

  @PostMapping("/permission-sharings/acquire")
  ResponseEntity<Void> acquireOwnership(@RequestParam Boolean keepExpiration,
      @RequestBody List<UUID> uuids, @RequestHeader HttpHeaders headers);

}
