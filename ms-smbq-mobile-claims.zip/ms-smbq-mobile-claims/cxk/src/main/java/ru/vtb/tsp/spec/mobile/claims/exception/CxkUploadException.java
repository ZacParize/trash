package ru.vtb.tsp.spec.mobile.claims.exception;

public class CxkUploadException extends RuntimeException {

  public CxkUploadException(String message) {
    super(message);
  }
}
