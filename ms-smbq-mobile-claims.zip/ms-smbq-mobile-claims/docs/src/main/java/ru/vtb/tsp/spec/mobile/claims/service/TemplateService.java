package ru.vtb.tsp.spec.mobile.claims.service;

/**
 * Сервис управления шаблонами
 */
public interface TemplateService {

  /**
   * Обновление/создание файла шаблона по указанному имени
   *
   * @param name     имя шаблона
   * @param template данные шаблона
   */
  void update(String name, byte[] template);

  /**
   * Генерация файла по шаблону
   *
   * @param template имя шаблона
   * @param model    данные для подстановки в шаблон
   */
  <T> byte[] documentGeneration(String template, T model, String claimId);
}
