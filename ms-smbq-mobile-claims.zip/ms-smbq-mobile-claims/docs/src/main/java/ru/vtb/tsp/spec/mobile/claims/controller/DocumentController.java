package ru.vtb.tsp.spec.mobile.claims.controller;

import static org.springframework.http.MediaType.APPLICATION_PDF;
import static org.springframework.http.MediaType.APPLICATION_PDF_VALUE;

import io.jaegertracing.internal.utils.Http;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.io.IOException;
import java.net.URL;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ConfirmUploadRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.QpsDocumentRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.ConfirmUploadSuccessResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocDownloadInfo;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentResponse;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.DocumentService;

import java.util.UUID;
import ru.vtb.tsp.spec.mobile.claims.session.utils.HeaderUtils;

@Api(value = "Documents controller", tags = "documents-controller")
@RestController
@RequestMapping("${api-v1.root}/docs")
@RequiredArgsConstructor
public class DocumentController {

    private final DocumentService documentService;

    @Logging
    @PostMapping
    @ApiOperation(value = "Получение списка идентификаторов документов")
    public DocumentResponse uploadDocuments(@RequestHeader HttpHeaders headers,
        @RequestBody QpsDocumentRequest documentRequest,
        String claimId) {
        return documentService.uploadDocuments(documentRequest, claimId);
    }

    @Logging
    @GetMapping("/docs/{docUuid}")
    @ApiOperation(value = "Загрузка документа")
    public DocDownloadInfo doc(@RequestHeader HttpHeaders headers, @PathVariable UUID docUuid) {
        return documentService.getDocument(docUuid, HeaderUtils.getClaimId(headers));
    }

    @Logging
    @PutMapping("/docs/download/status/{docUuid}")
    @ApiOperation(value = "Статус загрузки документа")
    @ResponseStatus(value = HttpStatus.NO_CONTENT)
    public ConfirmUploadSuccessResponse confirmUploadSuccess(@RequestHeader HttpHeaders headers,
        @PathVariable String docUuid,
        @RequestBody ConfirmUploadRequest request) {
        return documentService.confirmUploadSuccess(Integer.valueOf(request.getRequestId()));
    }

}
