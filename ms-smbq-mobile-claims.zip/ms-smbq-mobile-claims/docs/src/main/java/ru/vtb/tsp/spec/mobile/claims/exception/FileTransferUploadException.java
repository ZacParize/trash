package ru.vtb.tsp.spec.mobile.claims.exception;

public class FileTransferUploadException extends RuntimeException {

  public FileTransferUploadException(String message) {
    super(message);
  }
}
