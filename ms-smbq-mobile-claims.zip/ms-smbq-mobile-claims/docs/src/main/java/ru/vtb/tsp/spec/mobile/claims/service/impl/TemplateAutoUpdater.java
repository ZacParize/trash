package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.spec.mobile.claims.service.TemplateService;

/**
 * Класс, загружающий документы из src/main/resources/templates в pdf-сервис
 */
@Slf4j
@Component
@RequiredArgsConstructor
@Profile("!local")
public class TemplateAutoUpdater {

  private static final String SUFFIX = ".html";

  private static final String RESOURCE_TEMPLATE = "classpath:templates/*" + SUFFIX;

  private final TemplateService templateService;

  private final ResourceLoader resourceLoader;

  @Value("${pdf.service.upload.documents:true}")
  private Boolean uploadDocuments;

  @PostConstruct
  void init() {
    if (uploadDocuments) {
      log.debug("Uploading pdf documents");
      try {
        loadResources().forEach(resource -> {
          String templateName = Objects.requireNonNull(resource.getFilename()).replace(SUFFIX, "");
          try {
            templateService.update(templateName, resource.getInputStream().readAllBytes());
          } catch (IOException e) {
            log.error("Error while loading template resource with name: [{}]", templateName);
          }
          log.info("Template with name: [{}] updated", templateName);
        });
      } catch (IOException e) {
        log.error("Error while loading template resource from path: [{}]", RESOURCE_TEMPLATE);
      }
    } else {
      log.debug("Upload pdf documents is disabled");
    }
  }

  private List<Resource> loadResources() throws IOException {
    return Arrays.asList(ResourcePatternUtils.getResourcePatternResolver(resourceLoader)
        .getResources(RESOURCE_TEMPLATE));
  }
}
