package ru.vtb.tsp.spec.mobile.claims.exception;

public class FileTransferGetStatusException extends RuntimeException {

  public FileTransferGetStatusException(String message) {
    super(message);
  }
}
