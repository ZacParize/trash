package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.UUID;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocumentBusinessType;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class DocumentItem {

    private String docName;

    private UUID docUuid;

    private DocumentBusinessType businessType;

}
