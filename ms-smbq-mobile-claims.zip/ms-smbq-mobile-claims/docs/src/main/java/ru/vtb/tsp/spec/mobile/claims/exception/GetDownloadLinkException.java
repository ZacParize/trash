package ru.vtb.tsp.spec.mobile.claims.exception;

public class GetDownloadLinkException extends RuntimeException {

  public GetDownloadLinkException(String message) {
    super(message);
  }
}
