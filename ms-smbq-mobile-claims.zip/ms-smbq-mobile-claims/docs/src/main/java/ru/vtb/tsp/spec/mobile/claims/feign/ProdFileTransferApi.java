package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.FileTransferStatusRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.FileTransferStatusResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.GetDownloadLinkDlpResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.UploadDlpFileResponse;

@FeignClient(name = "prodFileTransferApi", url = "${prod-file-transfer.url}",
        configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface ProdFileTransferApi {

    @PostMapping(value = "/dlp/files/{subsystem}", consumes = "multipart/form-data", produces = "application/json")
    ResponseEntity<UploadDlpFileResponse> uploadFileForDlpValidation(@RequestBody MultipartFile file,
                                                                     @RequestHeader HttpHeaders headers,
                                                                     @PathVariable String subsystem);

    @GetMapping("/dlp/statuses/{subsystem}/{requestId}")
    ResponseEntity<FileTransferStatusResponse> getDlpUploadStatus(@PathVariable Integer requestId,
                                                                  @RequestHeader HttpHeaders headers,
                                                                  @PathVariable String subsystem);

    @GetMapping("/dlp/transfers/{subsystem}/{requestId}")
    ResponseEntity<GetDownloadLinkDlpResponse> getDownloadLink(@PathVariable Integer requestId,
                                                               @RequestHeader HttpHeaders headers,
                                                               @PathVariable String subsystem);

    @PutMapping("/dlp/transfers/{subsystem}/{requestId}")
    ResponseEntity<Void> confirmUploadFinished(@PathVariable Integer requestId,
                                               @RequestHeader HttpHeaders headers,
                                               @PathVariable String subsystem);

    @GetMapping("/test/integrations")
    ResponseEntity<Void> checkIntegrations();
}
