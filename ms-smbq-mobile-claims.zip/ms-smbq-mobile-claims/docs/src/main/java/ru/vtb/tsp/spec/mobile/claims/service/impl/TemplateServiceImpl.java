package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.dto.InMemoryMultipartFile;
import ru.vtb.tsp.spec.mobile.claims.exception.PdfGenerationException;
import ru.vtb.tsp.spec.mobile.claims.feign.DocumentGeneratorApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.TemplateService;

@Service
@Profile("!template_stub")
@RequiredArgsConstructor
public class TemplateServiceImpl implements TemplateService, CheckIntegrationService {

  public static final String DOCUMENT_TEMPLATE_MULTIPART_NAME = "file";
  public final static String INTEGRATION_NAME = "PDF сервис";

  private final DocumentGeneratorApi documentGeneratorApi;

  @Override
  public void update(String name, byte[] template) {
    documentGeneratorApi.template(InMemoryMultipartFile.builder()
        .name(DOCUMENT_TEMPLATE_MULTIPART_NAME)
        .originalFilename(name)
        .contentType(MediaType.TEXT_PLAIN_VALUE)
        .bytes(template)
        .build(), name);
  }

  @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_DOCS_GENERATE,
      techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
  @Override
  public <T> byte[] documentGeneration(String template, T model, String claimId) {
    try {
      return documentGeneratorApi.documentGeneration(template, model);
    } catch (Exception e) {
      throw new PdfGenerationException("");
    }
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    documentGeneratorApi.allTemplate();
    return EndpointCheckDto.builder()
        .status(HttpStatus.OK.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
