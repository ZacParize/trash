package ru.vtb.tsp.spec.mobile.claims.dto.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentDateRequest;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApplicationForSbpDocumentDto implements Serializable, GenericDocTemplate {

  private String organizationName;
  private String accountNumber;
  private String email;
  private String fio;
  private DocumentDateRequest currentDate;
  private String acceptDate;

}