package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class QpsAnketaRequest {

    private String organizationName;

    private String opf;

    private String inn;

    private String kpp;

    private String ogrn;

    private String legalAddress;

    private String mcc;

    private String fio;

    private String accountNumber;

    private List<OutletRequest> outlets;

}
