package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileTransferStatusRequest {

    private String fileName;
    private String status;
}
