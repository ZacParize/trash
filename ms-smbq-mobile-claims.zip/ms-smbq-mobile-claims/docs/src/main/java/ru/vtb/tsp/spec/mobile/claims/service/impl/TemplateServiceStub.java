package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.service.TemplateService;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

@Service
@Profile("template_stub")
@RequiredArgsConstructor
public class TemplateServiceStub implements TemplateService {

  @Value("mobile-claims/src/main/resources/templates/response.pdf")
  String resourceFile;

  @Override
  public void update(String name, byte[] template) {

  }

  @Override
  public <T> byte[] documentGeneration(String template, T model, String claimId) {
    try {
      File file = new File(resourceFile);
      byte[] bytes = new byte[(int) file.length()];
      try (BufferedInputStream bufferedInputStream = new BufferedInputStream(
          new FileInputStream(file))) {
        bufferedInputStream.read(bytes, 0, bytes.length);
      }
      return bytes;
    } catch (Exception e) {
      return new byte[0];
    }
  }
}
