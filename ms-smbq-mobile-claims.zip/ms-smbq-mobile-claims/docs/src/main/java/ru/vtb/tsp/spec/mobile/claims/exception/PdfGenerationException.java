package ru.vtb.tsp.spec.mobile.claims.exception;

public class PdfGenerationException extends RuntimeException {

  public PdfGenerationException(String message) {
    super(message);
  }
}
