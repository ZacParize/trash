package ru.vtb.tsp.spec.mobile.claims.dto.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PosAndQrRegistrationDto implements Serializable, GenericDocTemplate {

  private String organizationDataMainName;
  private String organizationDataMainOpf;
  private String organizationDataMainInn;
  private String organizationDataMainKpp;
  private String organizationDataMainOgrn;
  private String organizationDataAddressLegalLocation;
  private String organizationDataAddressLegalPostIndex;
  private String organizationDataAddressLegalFullAddress;
  private String organizationHeadFullName;
  private String agreementDate;
  private String countrySubDivisionCode;
  private String mcc;
  private List<Account> accounts;
  private List<Outlet> outlets;
  private final String documentGenerateDate = LocalDate.now()
      .format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));

  @Getter
  @Setter
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  @JsonIgnoreProperties(ignoreUnknown = true)
  public static class Account implements Serializable {

    private String accountNumber;
  }

  @Getter
  @Setter
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  @JsonIgnoreProperties(ignoreUnknown = true)
  public static class Outlet implements Serializable {

    private String name;
    private String addressLocation;
    private String addressPostIndex;
    private String addressFullAddress;
    private String contactPhone;
    private String mcc;
  }
}
