package ru.vtb.tsp.spec.mobile.claims.service;

import java.io.IOException;
import java.net.MalformedURLException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.spec.mobile.claims.dto.request.QpsDocumentRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.ConfirmUploadSuccessResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocDownloadInfo;
import ru.vtb.tsp.spec.mobile.claims.dto.response.DocumentResponse;

import java.util.UUID;

public interface DocumentService {

    DocumentResponse uploadDocuments(QpsDocumentRequest documentRequest, String claimId);

    DocDownloadInfo getDocument(UUID docUuid, String claimId);

    ConfirmUploadSuccessResponse confirmUploadSuccess(Integer requestId);
}
