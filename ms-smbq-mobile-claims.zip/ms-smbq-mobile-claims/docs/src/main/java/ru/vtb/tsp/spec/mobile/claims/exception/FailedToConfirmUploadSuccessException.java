package ru.vtb.tsp.spec.mobile.claims.exception;

public class FailedToConfirmUploadSuccessException extends RuntimeException {

  public FailedToConfirmUploadSuccessException(String message) {
    super(message);
  }
}
