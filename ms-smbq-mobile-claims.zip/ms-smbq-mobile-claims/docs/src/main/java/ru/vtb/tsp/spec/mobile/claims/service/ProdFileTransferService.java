package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.UUID;

public interface ProdFileTransferService {

    Integer uploadFile(byte[] file, UUID docUuid);

    boolean checkStatusIsOk(Integer requestId);

    String getDownloadLink(Integer requestId);

    void confirmUpload(Integer requestId);
}
