package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocType;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.InMemoryMultipartFile;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentDateRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.QpsDocumentRequest;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocumentBusinessType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.*;
import ru.vtb.tsp.spec.mobile.claims.dto.template.ApplicationForSbpDocumentDto;
import ru.vtb.tsp.spec.mobile.claims.dto.template.GenericDocTemplate;
import ru.vtb.tsp.spec.mobile.claims.dto.template.PosAndQrRegistrationDto;
import ru.vtb.tsp.spec.mobile.claims.dto.template.PosAndQrRegistrationDto.Account;
import ru.vtb.tsp.spec.mobile.claims.dto.template.PosAndQrRegistrationDto.Outlet;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkDownloadFileException;
import ru.vtb.tsp.spec.mobile.claims.exception.CxkUploadException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferGetStatusException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferUploadException;
import ru.vtb.tsp.spec.mobile.claims.exception.GetDownloadLinkException;
import ru.vtb.tsp.spec.mobile.claims.exception.PdfGenerationException;
import ru.vtb.tsp.spec.mobile.claims.feign.ProdFileTransferApi;
import ru.vtb.tsp.spec.mobile.claims.service.DocumentService;
import ru.vtb.tsp.spec.mobile.claims.service.FileStorageService;
import ru.vtb.tsp.spec.mobile.claims.service.ProdFileTransferService;
import ru.vtb.tsp.spec.mobile.claims.service.TemplateService;

@Service
@Slf4j
@RequiredArgsConstructor
public class DocumentServiceImpl implements DocumentService {

  private static final String CONTENT_TYPE_PDF = "application/pdf";
  private static final String PDF_EXTENSION = ".pdf";
  public static final String DOWNLOADED = "DOWNLOADED";

  private final TemplateService templateService;
  private final FileStorageService fileStorageService;
  private final ProdFileTransferService prodFileTransferService;

  @Override
  public DocumentResponse uploadDocuments(QpsDocumentRequest documentRequest, String claimId) {
    var documents = new ArrayList<DocumentItem>();
    saveDeclarationToCxkAndAddToResult(documentRequest, documents, claimId);
    saveAnketaToCxkAndAddToResult(documentRequest, documents, claimId);

    return DocumentResponse.builder()
        .documentListItems(documents)
        .build();
  }

  @Override
  @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_DOCS_DOWNLOAD, techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
  public DocDownloadInfo getDocument(UUID docUuid, String claimId) {
    try {
      var file = fileStorageService.download(docUuid);
      var requestId = prodFileTransferService.uploadFile(file, docUuid);
      if (prodFileTransferService.checkStatusIsOk(requestId)) {
        return DocDownloadInfo.builder()
            .downloadLink(prodFileTransferService.getDownloadLink(requestId))
            .requestId(String.valueOf(requestId))
            .build();
      }

      throw new GetDownloadLinkException("");
    } catch (CxkDownloadFileException | FileTransferUploadException |
             FileTransferGetStatusException ex) {
      throw ex;
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new GetDownloadLinkException("");
    }
  }

  @Override
  public ConfirmUploadSuccessResponse confirmUploadSuccess(Integer requestId) {
    try {
      prodFileTransferService.confirmUpload(requestId);
      return ConfirmUploadSuccessResponse.builder()
          .requestId(String.valueOf(requestId))
          .status(DOWNLOADED)
          .build();
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

  private void saveDeclarationToCxkAndAddToResult(QpsDocumentRequest documentRequest,
      List<DocumentItem> documents, String claimId) {
    if (documentRequest.getDeclarationQps() != null) {
      documents.add(saveToPdfAndCxk(DocType.declaration_sbp,
          ApplicationForSbpDocumentDto.builder()
              .organizationName(documentRequest.getDeclarationQps().getOrganizationName())
              .accountNumber(documentRequest.getDeclarationQps().getAccountNumber())
              .email(documentRequest.getDeclarationQps().getEmail())
              .fio(documentRequest.getDeclarationQps().getFio())
              .currentDate(DocumentDateRequest.builder()
                  .day(LocalDate.now().getDayOfMonth())
                  .month(LocalDate.now().getMonth().getValue())
                  .year(LocalDate.now().getYear())
                  .build())
              .acceptDate(LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy")))
              .build(), claimId));
    }
  }

  private void saveAnketaToCxkAndAddToResult(QpsDocumentRequest documentRequest,
      List<DocumentItem> documents, String claimId) {
    var anketaQps = documentRequest.getAnketaQps();
    if (anketaQps != null) {
      var outlets = anketaQps.getOutlets().stream().map(o -> Outlet.builder()
          .name(o.getName())
          .addressLocation("")
          .addressPostIndex("")
          .addressFullAddress(o.getFactAddress())
          .contactPhone("")
          .build()).collect(Collectors.toList());

      documents.add(saveToPdfAndCxk(DocType.anketa_sbp,
          PosAndQrRegistrationDto.builder()
              .organizationDataMainName(anketaQps.getOrganizationName())
              .organizationDataMainOpf(anketaQps.getOpf())
              .organizationDataMainInn(anketaQps.getInn())
              .organizationDataMainKpp(anketaQps.getKpp())
              .organizationDataMainOgrn(anketaQps.getOgrn())
              .countrySubDivisionCode("")
              .organizationDataAddressLegalLocation("")
              .organizationDataAddressLegalPostIndex("")
              .organizationDataAddressLegalFullAddress(anketaQps.getLegalAddress())
              .accounts(List.of(Account.builder()
                  .accountNumber(anketaQps.getAccountNumber())
                  .build()))
              .outlets(outlets)
              .mcc(anketaQps.getMcc())
              .build(), claimId));
    }
  }

  private DocumentItem saveToPdfAndCxk(DocType docType, GenericDocTemplate dto, String claimId) {
    var bytes = templateService.documentGeneration(
        docType.getPdfServiceName(), dto, claimId);
    var responseCxk = fileStorageService.upload(CONTENT_TYPE_PDF, bytes,
        docType + PDF_EXTENSION, claimId);
    return DocumentItem.builder()
        .docUuid(responseCxk.getUuid())
        .docName(docType.getPdfServiceName())
        .businessType(DocumentBusinessType.from(docType))
        .build();
  }
}
