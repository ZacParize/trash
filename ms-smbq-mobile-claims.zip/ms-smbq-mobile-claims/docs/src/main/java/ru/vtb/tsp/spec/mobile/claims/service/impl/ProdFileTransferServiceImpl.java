package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.InMemoryMultipartFile;
import ru.vtb.tsp.spec.mobile.claims.dto.request.FileTransferStatusRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.GetDownloadLinkDlpResponse;
import ru.vtb.tsp.spec.mobile.claims.exception.FailedToConfirmUploadSuccessException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferGetStatusException;
import ru.vtb.tsp.spec.mobile.claims.exception.FileTransferUploadException;
import ru.vtb.tsp.spec.mobile.claims.exception.GetDownloadLinkException;
import ru.vtb.tsp.spec.mobile.claims.feign.ProdFileTransferApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.ProdFileTransferService;

@RequiredArgsConstructor
@Service
@Slf4j
public class ProdFileTransferServiceImpl implements ProdFileTransferService,
    CheckIntegrationService {

    public final static String INTEGRATION_NAME = "Prod-file-transfer";

    public static final String SUCCESS_STATUS = "success";
    private final ProdFileTransferApi prodFileTransferApi;
    private final EpaIgTechTokenService epaIgService;

    private static final String DOCUMENT_TEMPLATE_MULTIPART_NAME = "file";

    @Value("${file-transfer.subsystem:POS}")
    private String subsystem;

    @Value("${file-transfer.retry.times:9}")
    private Integer retryTimes;

    @Value("${file-transfer.retry.sleep:9}")
    private Integer retrySleep;

    @Override
    public Integer uploadFile(byte[] file, UUID docUuid) {
        try {
            var multipartFile = InMemoryMultipartFile.builder()
                .name(DOCUMENT_TEMPLATE_MULTIPART_NAME)
                .originalFilename(docUuid + ".pdf")
                .contentType(MediaType.TEXT_PLAIN_VALUE)
                .bytes(file)
                .build();
            var responseEntity = prodFileTransferApi.uploadFileForDlpValidation(multipartFile,
                tokenAuthorization(), subsystem);
            if (responseEntity.getStatusCode().value() != HttpStatus.OK.value()
                || responseEntity.getBody() == null) {
                throw new FileTransferUploadException("");
            }
            return responseEntity.getBody().getRequestId();
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            throw new FileTransferUploadException("");
        }
    }

    @Override
    public boolean checkStatusIsOk(Integer requestId) {
        try {
            for (var i = 0; i <= retryTimes; i++) {
                var responseEntity = prodFileTransferApi.getDlpUploadStatus(requestId,
                    tokenAuthorization(), subsystem);
                log.debug("prod-file-transfer checkStatus statusCode is [{}], requestId: {}", responseEntity.getStatusCode(), requestId);
                if (responseEntity.getStatusCode().value() == HttpStatus.OK.value()) {
                    if (responseEntity.getBody() != null && responseEntity.getBody().getStatus().equals(SUCCESS_STATUS)) {
                        log.debug("Status file transfer is 'success'");
                        return true;
                    } else {
                        log.debug("prod-file-transfer response body is null or status is not successful: {}", responseEntity.getBody());
                    }
                }
                try {
                    Thread.sleep(retrySleep);
                } catch (InterruptedException e) {
                    // ignore
                }
            }

            log.error("Exceeded attempts status check for requestId: {}", requestId);
            throw new FileTransferGetStatusException("Exceeded attempts");
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            throw new FileTransferUploadException("");
        }

    }

    @Override
    public String getDownloadLink(Integer requestId) {
        try {
            var responseEntity = prodFileTransferApi.getDownloadLink(requestId,
                tokenAuthorization(), subsystem);
            if (responseEntity.getStatusCode().value() != HttpStatus.OK.value()
                || responseEntity.getBody() == null) {
                throw new GetDownloadLinkException("");
            }
            return responseEntity.getBody().getContentURL();
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            throw  new GetDownloadLinkException("");
        }
    }

    @Override
    public void confirmUpload(Integer requestId) {
        try {
            var responseEntity = prodFileTransferApi.confirmUploadFinished(requestId,
                tokenAuthorization(), subsystem);
            log.debug("prod-file-transfer confirmUpload statusCode is [{}], requestId: {}", responseEntity.getStatusCode(), requestId);
            if (responseEntity.getStatusCode().value() == HttpStatus.OK.value()
                || responseEntity.getStatusCode().value() == HttpStatus.CREATED.value()) {
                log.debug("prod-file-transfer confirmUpload status is valid, requestId: {}", requestId);
                return;
            }
            log.error("prod-file-transfer confirmUpload status is invalid, requestId: {}", requestId);
            throw new FailedToConfirmUploadSuccessException("");
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            throw new FailedToConfirmUploadSuccessException("");
        }
    }

    private HttpHeaders tokenAuthorization() {
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, epaIgService.getTechToken());
        return headers;
    }

    @Override
    public EndpointCheckDto checkEndpoint() {
        try {
            var checkIntegrations = prodFileTransferApi.checkIntegrations();
            if (checkIntegrations.getStatusCode() == HttpStatus.OK) {
                return EndpointCheckDto.builder()
                    .status(HttpStatus.OK.name())
                    .build();
            }
            return EndpointCheckDto.builder()
                .status(HttpStatus.NOT_ACCEPTABLE.name())
                .build();
        } catch (Exception e) {
            return EndpointCheckDto.builder()
                .status(HttpStatus.NOT_ACCEPTABLE.name())
                .errorMessage(e.getMessage())
                .build();
        }
    }

    @Override
    public String getIntegrationName() {
        return INTEGRATION_NAME;
    }
}
