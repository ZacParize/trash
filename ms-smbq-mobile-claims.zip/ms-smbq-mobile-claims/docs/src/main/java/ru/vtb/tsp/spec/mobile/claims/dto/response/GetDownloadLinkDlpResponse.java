package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class GetDownloadLinkDlpResponse {

    private String contentURL;
    private String error;
    private Integer expires;
    private Integer requestId;
    private String message;

}
