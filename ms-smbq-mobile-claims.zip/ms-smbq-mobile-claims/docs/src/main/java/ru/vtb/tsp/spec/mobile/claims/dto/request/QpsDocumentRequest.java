package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@ToString
public class QpsDocumentRequest {

    private ClaimType claimType;

    private QpsAnketaRequest anketaQps;

    private QpsDeclarationRequest declarationQps;

}
