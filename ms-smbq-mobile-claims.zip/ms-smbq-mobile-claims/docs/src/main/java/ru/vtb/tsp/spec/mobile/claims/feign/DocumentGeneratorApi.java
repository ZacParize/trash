package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.multipart.MultipartFile;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;

@FeignClient(name = "pdfGenerator", url = "${pdf.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface DocumentGeneratorApi {

  @PostMapping(value = "/v2/document?template={template}", produces = "application/pdf", consumes = "application/json")
  <T> byte[] documentGeneration(@PathVariable("template") String template, T model);

  @PutMapping(value = "/v1/template?name={name}", consumes = "multipart/form-data")
  void template(MultipartFile file, @PathVariable("name") String name);

  @GetMapping(value = "/v1/template", consumes = "application/json")
  String allTemplate();
}
