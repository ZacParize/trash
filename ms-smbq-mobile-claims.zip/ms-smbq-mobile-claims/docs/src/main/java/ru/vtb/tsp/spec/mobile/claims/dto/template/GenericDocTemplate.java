package ru.vtb.tsp.spec.mobile.claims.dto.template;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.vtb.tsp.spec.mobile.claims.dto.request.DocumentDateRequest;

public interface GenericDocTemplate {

}