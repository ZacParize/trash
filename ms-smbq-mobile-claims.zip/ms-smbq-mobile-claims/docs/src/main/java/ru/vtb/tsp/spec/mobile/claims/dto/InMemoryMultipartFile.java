package ru.vtb.tsp.spec.mobile.claims.dto;

import lombok.Builder;
import lombok.Getter;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

@Getter
@Builder
public class InMemoryMultipartFile implements MultipartFile {

  private final String name;

  private final String originalFilename;

  private final String contentType;

  private final byte[] bytes;

  @Override
  public boolean isEmpty() {
    return bytes == null || bytes.length == 0;
  }

  @Override
  public long getSize() {
    return bytes == null ? 0 : bytes.length;
  }

  @Override
  public InputStream getInputStream() throws IOException {
    return new ByteArrayInputStream(bytes);
  }

  @Override
  public void transferTo(File dest) throws IllegalStateException {
    throw new UnsupportedOperationException("transferTo is unsupported yet");
  }
}
