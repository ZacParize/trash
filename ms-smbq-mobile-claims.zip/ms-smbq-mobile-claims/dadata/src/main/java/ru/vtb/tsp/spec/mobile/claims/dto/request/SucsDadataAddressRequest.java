package ru.vtb.tsp.spec.mobile.claims.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "ДТО запроса поиска адреса в произвольном формате")
public class SucsDadataAddressRequest {

  @Schema(maxLength = 255, description = "Строка для поиска", nullable = true)
  private String request;

  @Schema(maxLength = 255, description = "Ограничение по ФИАС-коду региона", nullable = true)
  private String regionFiasId;

  @Schema(maxLength = 255, description = "Ограничение по ФИАС-коду области", nullable = true)
  private String areaFiasId;

  @Schema(maxLength = 255, description = "Ограничение по ФИАС-коду города", nullable = true)
  private String cityFiasId;

  @Schema(maxLength = 255, description = "Ограничение по ФИАС-коду населенного пункта", nullable = true)
  private String settlementFiasId;

  @Schema(maxLength = 255, description = "Ограничение по ФИАС-коду улицы", nullable = true)
  private String streetFiasId;

  @Schema(description = "Тип объекта для поиска ОТ", nullable = true)
  private DadataOt fromBound;

  @Schema(description = "Тип объекта для поиска ОТ", nullable = true)
  private DadataOt toBound;

  @Schema(description = "Количество результатов")
  private int count;

}