package ru.vtb.tsp.spec.mobile.claims.mapper;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import ru.vtb.tsp.spec.mobile.claims.dto.response.AddressResponseItem;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataResponse;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface AddressMapper {


  List<AddressResponseItem> toList(List<SucsDadataAddressResponse> dadataAddresses);

  @Mapping(target = "address", source = "fullAddress")
  @Mapping(target = "isParsed", constant = "true")
  AddressResponseItem toDto(SucsDadataAddressResponse dadataAddress);

}