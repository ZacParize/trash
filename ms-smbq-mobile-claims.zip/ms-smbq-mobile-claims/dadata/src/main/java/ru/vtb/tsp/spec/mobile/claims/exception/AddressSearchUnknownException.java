package ru.vtb.tsp.spec.mobile.claims.exception;

public class AddressSearchUnknownException extends RuntimeException {

  public AddressSearchUnknownException(String errorMessage) {
    super(errorMessage);
  }

}