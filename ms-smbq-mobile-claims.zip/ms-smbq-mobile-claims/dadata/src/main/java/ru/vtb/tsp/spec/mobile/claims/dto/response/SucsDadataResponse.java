package ru.vtb.tsp.spec.mobile.claims.dto.response;

import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SucsDadataResponse {

  private List<SucsDadataAddressResponse> addresses;
}