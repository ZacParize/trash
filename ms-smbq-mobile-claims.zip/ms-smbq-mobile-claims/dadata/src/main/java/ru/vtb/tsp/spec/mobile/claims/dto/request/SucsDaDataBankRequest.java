package ru.vtb.tsp.spec.mobile.claims.dto.request;

import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SucsDaDataBankRequest {

    private String request;
}
