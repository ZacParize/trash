package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.deserializer.EmptyStringAsNullDeserializer;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SucsDadataAddressResponse {

  private SucsDadataAddressItemResponse region;
  private SucsDadataAddressItemResponse area;
  private SucsDadataAddressItemResponse city;
  private SucsDadataAddressItemResponse settlement;
  private SucsDadataAddressItemResponse street;
  private SucsDadataAddressItemResponse house;
  private SucsDadataAddressItemResponse blockType;
  private SucsDadataAddressItemResponse block;
  private SucsDadataAddressItemResponse flat;

  @Schema(maxLength = 255, description = "Почтовый индекс", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String postalCode;

  @Schema(maxLength = 255, description = "Адрес")
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String fullAddress;

  @Schema(description = "Код ФИАС", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String fiasId;

  @Schema(maxLength = 255, description = "Код ОКТМО", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String oktmo;

}