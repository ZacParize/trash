package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.deserializer.EmptyStringAsNullDeserializer;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SucsDadataAddressItemResponse {

  @Schema(maxLength = 1024, description = "Значение")
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String value;

  @Schema(description = "Признак обязательности")
  private Boolean required;

  @Schema(description = "Сокращенный тип", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String type;

  @Schema(description = "Значение с типом", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String valueWithType;

  @Schema(description = "Полный тип", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String typeFull;

  @Schema(description = "Код ФИАС", nullable = true)
  @JsonDeserialize(using = EmptyStringAsNullDeserializer.class)
  private String fiasId;

}