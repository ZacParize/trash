package ru.vtb.tsp.spec.mobile.claims.service;

import ru.vtb.tsp.spec.mobile.claims.dto.request.SucsDadataAddressRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.AddressResponseItem;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;

import java.util.List;

/**
 * Интерфейс для взаимодействия с тесса адаптером
 */
public interface AdapterService {


  List<AddressResponseItem> sucsSearch(String address, Integer count);

}