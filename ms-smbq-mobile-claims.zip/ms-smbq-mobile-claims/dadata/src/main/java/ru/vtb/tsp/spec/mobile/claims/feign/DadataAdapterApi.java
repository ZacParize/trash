package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.SucsDadataAddressRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataResponse;


@FeignClient(name = "dadataAdapterApi", url = "${dadata-adapter.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class}, decode404 = true)
@Service
public interface DadataAdapterApi {

  /**
   * Поиск адреса
   */
  @PostMapping("/sucsdadata/addresses/search")
  SucsDadataResponse sucsSearch(@RequestHeader HttpHeaders headers,
      SucsDadataAddressRequest request);

}
