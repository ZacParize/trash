package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.response.AddressResponseItem;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressItemResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;
import ru.vtb.tsp.spec.mobile.claims.service.AdapterService;

@Profile("dadata_stub")
@Service
public class AdapterServiceStub implements AdapterService {

  @Override
  public List<AddressResponseItem> sucsSearch(String address, Integer count) {
    return List.of(AddressResponseItem.builder()
        .address("432001, г. Москва, ул. Тверская, д.100")
        .isParsed(true)
        .build());
  }

}
