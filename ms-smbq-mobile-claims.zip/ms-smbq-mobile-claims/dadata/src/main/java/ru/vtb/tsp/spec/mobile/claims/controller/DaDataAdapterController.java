package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.dto.response.AddressResponseItem;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.request.SucsDadataAddressRequest;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.AdapterService;

import java.util.List;

@Api(value = "DaData controller", tags = "da-data-controller")
@RestController
@RequestMapping("${api-v1.root}/dadata")
@RequiredArgsConstructor
public class DaDataAdapterController {

  private final AdapterService adapterService;

  @ApiOperation(value = "Поиск адресов в произвольном формате")
  @GetMapping("/search")
  @Logging
  public List<AddressResponseItem> searchAddress(
      @ApiParam(value = "Адрес для поиска") @RequestParam(required = false) String address,
      @ApiParam(value = "Количество результатов") @RequestParam(required = false, defaultValue = "20") Integer count) {
    return adapterService.sucsSearch(address, count);
  }

}
