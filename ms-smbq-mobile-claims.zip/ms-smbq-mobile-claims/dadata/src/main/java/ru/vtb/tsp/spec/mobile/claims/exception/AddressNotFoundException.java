package ru.vtb.tsp.spec.mobile.claims.exception;

public class AddressNotFoundException extends RuntimeException {

  public AddressNotFoundException(String errorMessage) {
    super(errorMessage);
  }

}