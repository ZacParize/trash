package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class SucsDaDataBankDetails {

    private String name;

    private String bic;

    private String corrAcc;
}
