package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.request.SucsDadataAddressRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.AddressResponseItem;
import ru.vtb.tsp.spec.mobile.claims.exception.AddressNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.exception.AddressSearchUnknownException;
import ru.vtb.tsp.spec.mobile.claims.feign.DadataAdapterApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.mapper.AddressMapper;
import ru.vtb.tsp.spec.mobile.claims.service.AdapterService;
import ru.vtb.tsp.spec.mobile.claims.session.service.HeaderService;

@Slf4j
@Service
@RequiredArgsConstructor
@Profile("!dadata_stub")
public class AdapterServiceImpl implements AdapterService, CheckIntegrationService {

  private final DadataAdapterApi adapterApi;
  private final HeaderService headerService;
  private final AddressMapper addressMapper;

  public final static String INTEGRATION_NAME = "DaData";

  @Override
  public List<AddressResponseItem> sucsSearch(String address, Integer count) {
    try {
      var response = adapterApi.sucsSearch(headerService.ofDadataHeaders(),
          SucsDadataAddressRequest.builder()
              .request(address)
              .count(count)
              .build());
      if (response != null && CollectionUtils.isNotEmpty(response.getAddresses())) {
        return addressMapper.toList(response.getAddresses());
      } else {
        log.error("empty addresses response");
        throw new AddressNotFoundException("Not found address: " + address);
      }
    } catch (AddressNotFoundException notFoundException) {
      log.error(ExceptionUtils.getStackTrace(notFoundException));
      throw notFoundException;
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new AddressSearchUnknownException("Unknown exception while searching address: " + address);
    }
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
      adapterApi.sucsSearch(headerService.ofDadataHeaders(), SucsDadataAddressRequest.builder()
          .request("Москва")
          .build());
      return EndpointCheckDto.builder()
          .status(HttpStatus.OK.name())
          .build();
    } catch (Exception e) {
      log.error("dadata check-integration exception" + ExceptionUtils.getStackTrace(e));
      return EndpointCheckDto.builder()
          .status(HttpStatus.INTERNAL_SERVER_ERROR.name())
          .errorMessage(e.getMessage())
          .build();
    }
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}