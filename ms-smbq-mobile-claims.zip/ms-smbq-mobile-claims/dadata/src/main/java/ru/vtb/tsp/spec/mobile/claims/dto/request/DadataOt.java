package ru.vtb.tsp.spec.mobile.claims.dto.request;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "Тип объекта для поиска ОТ")
public enum DadataOt {

  REGION,
  AREA,
  CITY,
  SETTLEMENT,
  STREET,
  HOUSE

}
