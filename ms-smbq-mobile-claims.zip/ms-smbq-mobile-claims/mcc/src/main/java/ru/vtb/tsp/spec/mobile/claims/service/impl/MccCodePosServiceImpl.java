package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.consts.MccProvider;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccCodePagePos;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccCodePos;
import ru.vtb.tsp.spec.mobile.claims.enums.AcquiringType;
import ru.vtb.tsp.spec.mobile.claims.feign.WorkflowMccApi;
import ru.vtb.tsp.spec.mobile.claims.mapper.MccCodeMapper;
import ru.vtb.tsp.spec.mobile.claims.service.MccCodeService;
import ru.vtb.tsp.spec.mobile.claims.session.service.HeaderService;

@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "mcc.provider", havingValue = MccProvider.POS)
@Slf4j
public class MccCodePosServiceImpl implements MccCodeService {

  private final WorkflowMccApi mccApi;

  private final MccCodeMapper mccCodeMapper;

  private final HeaderService headerService;

  private static final int START_PAGE_INDEX = 0;

  private static final int PAGE_MAX_COUNT = 200;

  @Override
  public List<MccCode> getCodes(ClaimType claimType, String groupId) {
    var currentPageNumber = START_PAGE_INDEX;
    var codes = new ArrayList<MccCodePos>();
    boolean hasNextPage = true;
    var processWithAcquiringType = AcquiringType.fromClaimType(claimType).name();

    while (hasNextPage) {
      var headers = headerService.ofPosHeaders();
      var response = mccApi.getMccCodes(headers, null,
          null, null, processWithAcquiringType, currentPageNumber, PAGE_MAX_COUNT);
      if (CollectionUtils.isNotEmpty(response.getCodes())) {
        codes.addAll(response.getCodes());
        hasNextPage = hasNextPage(response.getPage(), currentPageNumber);
      } else {
        hasNextPage = false;
      }
    }
    return mccCodeMapper.toCodesResponsePos(codes);
  }

  private boolean hasNextPage(MccCodePagePos page, int currentPage) {
    return currentPage <= page.getTotalPages() - 1;
  }

}
