package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.List;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroup;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroupResponse;

public interface MccGroupService {

  List<MccGroup> getGroups(ClaimType claimType);

}
