package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BooleanFilterV1RequestDto {

  private Boolean isEqual;

  private Boolean notEquals;

}
