package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BankProductFilterV1RequestDto {

  private BankProductFilterV1RequestEnum isEqual;

  private List<BankProductFilterV1RequestEnum> in;

}
