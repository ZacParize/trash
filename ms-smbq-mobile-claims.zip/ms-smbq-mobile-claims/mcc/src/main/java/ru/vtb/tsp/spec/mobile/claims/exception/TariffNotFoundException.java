package ru.vtb.tsp.spec.mobile.claims.exception;

public class TariffNotFoundException extends RuntimeException {

  public TariffNotFoundException(String errorMessage) {
    super(errorMessage);
  }

}
