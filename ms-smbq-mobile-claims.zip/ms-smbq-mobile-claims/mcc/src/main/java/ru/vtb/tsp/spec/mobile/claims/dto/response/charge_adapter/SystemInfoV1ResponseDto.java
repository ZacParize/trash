package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SystemInfoV1ResponseDto {

  private String traceId;

  private ServiceInfoV1ResponseDto serviceInfo;

}
