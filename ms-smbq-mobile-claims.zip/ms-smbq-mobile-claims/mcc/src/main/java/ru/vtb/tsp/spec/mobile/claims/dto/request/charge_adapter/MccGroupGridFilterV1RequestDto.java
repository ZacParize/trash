package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MccGroupGridFilterV1RequestDto {

  private BooleanFilterV1RequestDto active;

  private BooleanFilterV1RequestDto mccCodeActive;

  private BankProductFilterV1RequestDto mccCodeBankProduct;

}
