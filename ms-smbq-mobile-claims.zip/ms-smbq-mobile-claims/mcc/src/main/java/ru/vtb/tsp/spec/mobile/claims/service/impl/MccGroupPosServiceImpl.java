package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.consts.MccProvider;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroup;
import ru.vtb.tsp.spec.mobile.claims.enums.AcquiringType;
import ru.vtb.tsp.spec.mobile.claims.feign.WorkflowMccApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.mapper.MccGroupMapper;
import ru.vtb.tsp.spec.mobile.claims.service.MccGroupService;
import ru.vtb.tsp.spec.mobile.claims.session.service.HeaderService;

@Service
@RequiredArgsConstructor
@ConditionalOnProperty(name = "mcc.provider", havingValue = MccProvider.POS)
public class MccGroupPosServiceImpl implements MccGroupService, CheckIntegrationService {

  private static final int START_PAGE_INDEX = 0;

  private static final int PAGE_MAX_COUNT = 200;

  private static final String INTEGRATION_NAME = "Сервис mcc-groups(POS)";

  private final WorkflowMccApi workflowMccApi;

  private final MccGroupMapper mccGroupMapper;

  private final HeaderService headerService;

  @Override
  public List<MccGroup> getGroups(ClaimType claimType) {
    var headers = headerService.ofPosHeaders();
    var mccCodesResponse = workflowMccApi.getMccGroups(headers, null,
        null, null, AcquiringType.fromClaimType(claimType).name(), START_PAGE_INDEX,
        PAGE_MAX_COUNT);
    return mccGroupMapper.toGroupsResponsePos(mccCodesResponse.getGroups());

  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    var groupResponse = getGroups(ClaimType.QPS_CONTRACT_CREATION);
    return EndpointCheckDto.builder()
        .status(groupResponse != null ? HttpStatus.OK.name() : HttpStatus.NOT_ACCEPTABLE.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
