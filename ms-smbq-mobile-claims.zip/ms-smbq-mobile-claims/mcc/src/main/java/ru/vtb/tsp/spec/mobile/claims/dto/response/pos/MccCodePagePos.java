package ru.vtb.tsp.spec.mobile.claims.dto.response.pos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccCodePagePos {

  private Integer size;

  private Integer totalElements;

  private Integer totalPages;

  private Integer number;
}