package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.*;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.MccCodeGridFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.MccGroupGridFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccCodeGridWrappedV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccGroupGridWrappedV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.TariffDetailWrappedV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.enums.AcquiringType;


@FeignClient(name = "chargeAdapterMccApi", url = "${charge-adapter.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class}, decode404 = true)
public interface ChargeAdapterMccApi {

  @PostMapping("/epa/mcc_code/v1/grids")
  MccCodeGridWrappedV1ResponseDto codes(@RequestParam Integer page,
      @RequestHeader HttpHeaders httpHeaders,
      @RequestParam Integer size, @RequestBody MccCodeGridFilterV1RequestDto mccGroupsRequest);

  @PostMapping("/epa/mcc_group/v1/grids")
  MccGroupGridWrappedV1ResponseDto groups(@RequestParam Integer page,
      @RequestHeader HttpHeaders httpHeaders,
      @RequestParam Integer size, @RequestBody MccGroupGridFilterV1RequestDto mccCodeRequest);

  @GetMapping("/epa/v1/tariff_detail/{mccCode}/{acquiringType}")
  TariffDetailWrappedV1ResponseDto tariff(@PathVariable String mccCode,
      @PathVariable AcquiringType acquiringType, @RequestHeader HttpHeaders httpHeaders);


}
