package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import ru.vtb.tsp.spec.mobile.claims.enums.PaymentSystemTypeV1Enum;

@Getter
@Setter
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class TariffRateV1RequestResponseDto {

  private PaymentSystemTypeV1Enum paymentSystem;

  private Double rateForVtbCardAndVtbAccount;

  private Double rateForVtbCardAndOtherBankAccount;

  private Double rateForOtherBankCardAndVtbAccount;

  private Double rateForOtherBankCardAndOtherBankAccount;

}

