package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

public enum TariffRateAcquiringTypeV1Enum {

  /**
   * ПОС эквайринг
   */
  POS_ACQUIRING,

  /**
   * Интернет эквайринг
   */
  INTERNET_ACQUIRING,

  /**
   * СБП
   */
  QR_ACQUIRING
}