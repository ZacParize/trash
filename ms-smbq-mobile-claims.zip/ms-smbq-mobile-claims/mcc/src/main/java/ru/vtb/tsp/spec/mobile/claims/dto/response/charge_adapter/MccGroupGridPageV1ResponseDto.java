package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccGroupGridPageV1ResponseDto {

  private PageInfoV1ResponseDto pageInfo;

  private List<MccGroupGridV1ResponseDto> content;

}
