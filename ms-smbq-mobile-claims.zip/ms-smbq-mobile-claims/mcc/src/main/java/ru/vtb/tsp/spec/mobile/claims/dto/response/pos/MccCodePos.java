package ru.vtb.tsp.spec.mobile.claims.dto.response.pos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.UUID;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccCodePos {

  private UUID uuid;

  private MccGroupPos group;

  private String name;

  private String code;

  private String nameLatin;

  private String description;

  private Boolean posAvailable;

  private Boolean eComAvailable;

  private Boolean posFastPaymentSystemAvailable;

  private Boolean eComFastPaymentSystemAvailable;

  private Boolean posLicense;

  private Boolean eComLicense;

  private Boolean posFastPaymentSystemLicense;

  private Boolean posHr;

  private Boolean eComHr;

  private Boolean posFastPaymentSystemHr;

  private Boolean posGeneralIrf;

  private Boolean eComGeneralIrf;

  private Boolean posFastPaymentSystemGeneralIrf;

  private Boolean posSecurity;

  private Boolean eComSecurity;

  private Boolean posFastPaymentSystemSecurity;

  private Integer order;
}