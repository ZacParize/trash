package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BankProductConditionV1ResponseDto {

  private String bankProduct;

  private Boolean isAvailable;

  private Boolean isNeedLicense;

  private Boolean isHighRisk;

  private Boolean isIrf;

  private Boolean isNeedSecurityDepartmentCheck;

}
