package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BankProductFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BankProductFilterV1RequestEnum;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BooleanFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.MccGroupGridFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroup;
import ru.vtb.tsp.spec.mobile.claims.consts.MccProvider;
import ru.vtb.tsp.spec.mobile.claims.feign.ChargeAdapterMccApi;
import ru.vtb.tsp.spec.mobile.claims.mapper.MccGroupMapper;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.MccGroupService;

@Service
@Slf4j
@RequiredArgsConstructor
@ConditionalOnProperty(name = "mcc.provider", havingValue = MccProvider.CHARGE_ADAPTER)
public class MccGroupChargeAdapterServiceImpl implements MccGroupService {

  private static final int START_PAGE_INDEX = 0;

  private static final int PAGE_MAX_COUNT = 200;

  private final ChargeAdapterMccApi mccApi;

  private final MccGroupMapper mccGroupMapper;

  private final EpaIgTechTokenService epaIgService;

  @Override
  public List<MccGroup> getGroups(ClaimType claimType) {
    try {
      BankProductFilterV1RequestEnum bankProduct = null;
      switch (claimType) {
        case QPS_CONTRACT_CREATION -> bankProduct = BankProductFilterV1RequestEnum.QPS;
      }

      var mccGroups = MccGroupGridFilterV1RequestDto.builder()
          .active(BooleanFilterV1RequestDto.builder()
              .isEqual(true)
              .build())
          .mccCodeActive(BooleanFilterV1RequestDto.builder()
              .isEqual(true)
              .build())
          .mccCodeBankProduct(BankProductFilterV1RequestDto.builder()
              .isEqual(bankProduct)
              .build())
          .build();
      var httpHeaders = new HttpHeaders();
      httpHeaders.add(HttpHeaders.AUTHORIZATION, epaIgService.getTechToken());
      var response = mccApi.groups(START_PAGE_INDEX, httpHeaders, PAGE_MAX_COUNT, mccGroups);
      return mccGroupMapper.toGroupsResponse(response.getPayload().getContent());
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

}
