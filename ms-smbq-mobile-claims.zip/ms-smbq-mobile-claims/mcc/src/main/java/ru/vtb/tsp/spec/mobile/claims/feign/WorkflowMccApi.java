package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccCodePosResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccGroupPosResponse;

@FeignClient(name = "workFlowMccApi", url = "${pos.workflow.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface WorkflowMccApi {

  /**
   * Получение справочника групп категорий деятельности
   */
  @GetMapping(path = "/v3/catalogs/mcc/groups")
  MccGroupPosResponse getMccGroups(@RequestHeader HttpHeaders headers,
      @RequestParam(required = false) String uuid,
      @RequestParam(required = false) String code,
      @RequestParam(required = false) Integer group,
      @RequestParam(required = false) String acquiringType,
      @RequestParam(required = false) Integer page,
      @RequestParam(required = false) Integer size);

  @GetMapping(path = "/v3/catalogs/mcc/codes")
  MccCodePosResponse getMccCodes(@RequestHeader HttpHeaders headers,
      @RequestParam(required = false) String uuid,
      @RequestParam(required = false) String code,
      @RequestParam(required = false) Integer group,
      @RequestParam(required = false) String acquiringType,
      @RequestParam(required = false) Integer page,
      @RequestParam(required = false) Integer size);



}
