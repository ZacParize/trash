package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.MccCodeService;

@Api(value = "Mcc codes controller", tags = "mcc-codes-controller")
@RestController
@RequestMapping("${api-v1.root}/mcc/codes")
@RequiredArgsConstructor
public class MccCodeController {

  private final MccCodeService mccCodeService;

  @GetMapping("/qps")
  @ApiOperation("Получение MCC-кодов для конкретной сферы деятельности")
  @Logging
  public List<MccCode> codes(@RequestParam String groupId, @RequestParam ClaimType claimType) {
    return mccCodeService.getCodes(claimType, groupId);
  }

}
