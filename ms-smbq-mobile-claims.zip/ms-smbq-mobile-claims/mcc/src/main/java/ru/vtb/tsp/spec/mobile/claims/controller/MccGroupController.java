package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import java.util.List;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroup;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroupResponse;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.MccGroupService;

@Api(value = "Mcc group controller", tags = "mcc-groups-controller")
@RestController
@RequestMapping("${api-v1.root}/mcc/groups")
@RequiredArgsConstructor
public class MccGroupController {

  private final MccGroupService mccGroupService;

  @GetMapping("/qps")
  @ApiOperation("Получение списка сфер деятельности")
  @Logging
  public List<MccGroup> groups() {
    return mccGroupService.getGroups(ClaimType.QPS_CONTRACT_CREATION);
  }

}
