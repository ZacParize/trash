package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccCodeResponse {

  private List<MccCode> codes;

}
