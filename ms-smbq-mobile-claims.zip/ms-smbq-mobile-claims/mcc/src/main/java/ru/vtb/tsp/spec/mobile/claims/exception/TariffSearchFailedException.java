package ru.vtb.tsp.spec.mobile.claims.exception;

public class TariffSearchFailedException extends RuntimeException {

  public TariffSearchFailedException(String errorMessage) {
    super(errorMessage);
  }

}
