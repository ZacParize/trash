package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccTariff;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.MccCodeService;
import ru.vtb.tsp.spec.mobile.claims.service.MccTariffService;

@Api(value = "Tariff controller", tags = "tariff-controller")
@RestController
@RequestMapping("${api-v1.root}/tariff")
@RequiredArgsConstructor
public class MccTariffController {

  private final MccTariffService mccTariffService;

  @GetMapping
  @Logging
  @ApiOperation("Запрос на получение тарифной ставки")
  public MccTariff tariff(@RequestParam ClaimType claimType, @RequestParam String mccCode) {
    return mccTariffService.getTariff(claimType, mccCode);
  }

}
