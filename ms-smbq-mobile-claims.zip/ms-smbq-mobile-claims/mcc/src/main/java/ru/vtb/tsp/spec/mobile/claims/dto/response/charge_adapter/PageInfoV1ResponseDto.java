package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageInfoV1ResponseDto {

  private Boolean empty;

  private Boolean first;

  private Boolean last;

  private Integer number;

  private Integer numberOfElements;

  private Integer totalElements;

  private Integer totalPages;

  private Integer size;

}
