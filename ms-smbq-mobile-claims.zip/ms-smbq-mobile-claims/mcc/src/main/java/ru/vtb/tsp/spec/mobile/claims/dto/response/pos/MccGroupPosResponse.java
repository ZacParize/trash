package ru.vtb.tsp.spec.mobile.claims.dto.response.pos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccGroupPosResponse {

  private MccCodePagePos page;

  private List<MccGroupPos> groups;
}