package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.List;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;

public interface MccCodeService {

  List<MccCode> getCodes(ClaimType claimType, String groupId);

}
