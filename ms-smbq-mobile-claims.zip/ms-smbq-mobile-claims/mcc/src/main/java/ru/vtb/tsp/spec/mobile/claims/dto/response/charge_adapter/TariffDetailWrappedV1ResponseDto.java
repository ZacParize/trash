package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TariffDetailWrappedV1ResponseDto {

  private SystemInfoV1ResponseDto systemInfo;

  private TariffDetailV1ResponseDto payload;
}