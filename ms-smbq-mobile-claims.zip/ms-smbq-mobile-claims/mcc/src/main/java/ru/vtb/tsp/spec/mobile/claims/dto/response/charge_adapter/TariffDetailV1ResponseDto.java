package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TariffDetailV1ResponseDto {

    private String name;

    private String fullNameWithRko;

    private String fullNameWithoutRko;

    private String code;

    private String startDate;

    private List<TariffConditionV1ResponseDto> tariffConditionCollection;

}
