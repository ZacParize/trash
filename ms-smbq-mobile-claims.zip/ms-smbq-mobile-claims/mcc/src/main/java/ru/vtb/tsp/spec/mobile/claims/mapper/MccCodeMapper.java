package ru.vtb.tsp.spec.mobile.claims.mapper;

import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccCodeGridV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccCodePos;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MccCodeMapper {

  default MccCodeResponse toResponse(List<MccCodeGridV1ResponseDto> codes) {
    var codeResponse = new MccCodeResponse();
    codeResponse.setCodes(toCodesResponse(codes));
    return codeResponse;
  }

  default MccCodeResponse toResponsePos(List<MccCodePos> codes) {
    var codeResponse = new MccCodeResponse();
    codeResponse.setCodes(toCodesResponsePos(codes));
    return codeResponse;
  }

  List<MccCode> toCodesResponse(List<MccCodeGridV1ResponseDto> codesDto);

  List<MccCode> toCodesResponsePos(List<MccCodePos> codesDto);

}
