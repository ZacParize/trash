package ru.vtb.tsp.spec.mobile.claims.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;

@Getter
@RequiredArgsConstructor
public enum AcquiringType {

  POS_ACQUIRING("ПОС"),
  INTERNET_ACQUIRING("ИЭ"),
  QR_ACQUIRING("СБП"),
  QPS_ACQUIRING("СБП"),
  VTB_KASSA("ВТБ-касса");

  private final String shortLabel;

  public static AcquiringType fromClaimType(ClaimType claimType) {
    return switch (claimType) {
      case QPS_CONTRACT_CREATION -> QR_ACQUIRING;
      default -> throw new UnsupportedOperationException("claimType is not supported");
    };
  }
}
