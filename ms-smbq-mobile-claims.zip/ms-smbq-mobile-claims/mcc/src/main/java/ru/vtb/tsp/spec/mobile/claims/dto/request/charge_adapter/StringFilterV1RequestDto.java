package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class StringFilterV1RequestDto {

  private String contains;

  private String doesNotContain;

  private String endsWith;

  private String startsWith;

  private String isEqual;

  private String notEquals;

  private boolean isSpecified;

  private List<String> in;

  private List<String> notIn;

}
