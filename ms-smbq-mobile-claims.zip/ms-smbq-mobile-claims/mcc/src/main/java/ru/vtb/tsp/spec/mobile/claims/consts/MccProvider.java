package ru.vtb.tsp.spec.mobile.claims.consts;

public interface MccProvider {
    String POS = "POS";
    String CHARGE_ADAPTER = "CHARGE_ADAPTER";
}
