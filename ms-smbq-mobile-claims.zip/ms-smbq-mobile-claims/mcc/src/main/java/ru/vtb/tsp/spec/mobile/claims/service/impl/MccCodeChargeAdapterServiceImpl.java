package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.consts.MccProvider;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.AcquiringTypeFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BankProductFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BankProductFilterV1RequestEnum;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.BooleanFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.MccCodeGridFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.StringFilterV1RequestDto;
import ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter.TariffRateAcquiringTypeV1Enum;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCode;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccCodeGridV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.PageInfoV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.feign.ChargeAdapterMccApi;
import ru.vtb.tsp.spec.mobile.claims.mapper.MccCodeMapper;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.MccCodeService;

@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "mcc.provider", havingValue = MccProvider.CHARGE_ADAPTER)
public class MccCodeChargeAdapterServiceImpl implements MccCodeService {

  private final ChargeAdapterMccApi mccApi;

  private final MccCodeMapper mccCodeMapper;

  private final EpaIgTechTokenService epaIgService;

  private static final int START_PAGE_INDEX = 0;

  private static final int PAGE_MAX_COUNT = 200;

  @Override
  public List<MccCode> getCodes(ClaimType claimType, String groupId) {
    try {
      BankProductFilterV1RequestEnum bankProduct = null;
      switch (claimType) {
        case QPS_CONTRACT_CREATION -> bankProduct = BankProductFilterV1RequestEnum.QPS;
      }

      var currentPageNumber = START_PAGE_INDEX;
      var codes = new ArrayList<MccCodeGridV1ResponseDto>();
      boolean hasNextPage = true;

      while (hasNextPage) {
        var mccCodesRequest = MccCodeGridFilterV1RequestDto.builder()
            .mccGroupCode(StringFilterV1RequestDto.builder()
                .isEqual(groupId)
                .build())
            .tariffGroupForAcquiringType(AcquiringTypeFilterV1RequestDto.builder()
                .isEqual(TariffRateAcquiringTypeV1Enum.QR_ACQUIRING)
                .build())
            .active(BooleanFilterV1RequestDto.builder()
                .isEqual(true)
                .build())
            .bankProducts(BankProductFilterV1RequestDto.builder()
                .isEqual(bankProduct)
                .build())
            .build();
        var httpHeaders = new HttpHeaders();
        httpHeaders.add(HttpHeaders.AUTHORIZATION, epaIgService.getTechToken());
        var response = mccApi.codes(currentPageNumber++, httpHeaders,
            PAGE_MAX_COUNT, mccCodesRequest);
        if (response != null && CollectionUtils.isNotEmpty(response.getContent())) {
          codes.addAll(response.getContent());
          hasNextPage = hasNextPage(response.getPageInfo(), currentPageNumber);
        } else {
          hasNextPage = false;
        }
      }
      return mccCodeMapper.toCodesResponse(codes);
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new InvalidExternalSystemResponseException("");
    }
  }

  private boolean hasNextPage(PageInfoV1ResponseDto page, int currentPage) {
    return currentPage <= page.getTotalPages() - 1;
  }
}
