package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

public enum TariffRateAcquiringTypeEnum {

  /**
   * ПОС эквайринг
   */
  POS_ACQUIRING,

  /**
   * Интернет эквайринг
   */
  INTERNET_ACQUIRING,

  /**
   * СБП
   */
  QR_ACQUIRING
}