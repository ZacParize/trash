package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import java.util.List;
import java.util.UUID;
import lombok.Data;

@Data
public class UUIDFilterV1RequestDto {

  private String isEqual;

  private String notEquals;

  private Boolean isSpecified;

  private List<UUID> in;

  private List<UUID> notIn;

}
