package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.UUID;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TariffGroupLightCoreDto {

  private UUID uuid;

  private TariffRateAcquiringTypeEnum acquiringType;

  private String code;

  private String name;

}