package ru.vtb.tsp.spec.mobile.claims.service;

import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccTariff;

public interface MccTariffService {

  MccTariff getTariff(ClaimType claimType, String mccCode);

}
