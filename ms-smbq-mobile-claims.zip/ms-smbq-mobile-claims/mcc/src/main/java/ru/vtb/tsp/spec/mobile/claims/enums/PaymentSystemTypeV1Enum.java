package ru.vtb.tsp.spec.mobile.claims.enums;

public enum PaymentSystemTypeV1Enum {

  MIR,
  VISA,
  MASTERCARD,
  AMERICAN_EXPRESS,
  UNION_PAY

}
