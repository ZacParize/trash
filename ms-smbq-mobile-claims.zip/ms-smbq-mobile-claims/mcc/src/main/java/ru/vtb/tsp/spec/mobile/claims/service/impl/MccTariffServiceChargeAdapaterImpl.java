package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.common.exception.InvalidExternalSystemResponseException;
import ru.vtb.tsp.spec.mobile.claims.consts.MccProvider;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccTariff;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.TariffConditionV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.TariffRateV1RequestResponseDto;
import ru.vtb.tsp.spec.mobile.claims.enums.AcquiringType;
import ru.vtb.tsp.spec.mobile.claims.enums.PaymentSystemTypeV1Enum;
import ru.vtb.tsp.spec.mobile.claims.exception.TariffNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.exception.TariffSearchFailedException;
import ru.vtb.tsp.spec.mobile.claims.feign.ChargeAdapterMccApi;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;
import ru.vtb.tsp.spec.mobile.claims.service.MccTariffService;

@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "mcc.provider", havingValue = MccProvider.CHARGE_ADAPTER)
public class MccTariffServiceChargeAdapaterImpl implements MccTariffService {

    private final ChargeAdapterMccApi chargeAdapterMccApi;
    private final EpaIgTechTokenService epaIgService;

    @Override
    public MccTariff getTariff(ClaimType claimType, String mccCode) {
        try {
            HttpHeaders headers = new HttpHeaders();
            headers.add(HttpHeaders.AUTHORIZATION, epaIgService.getTechToken());
            var tariffResponse = chargeAdapterMccApi.tariff(mccCode,
                AcquiringType.fromClaimType(claimType), headers);
            var rate = tariffResponse.getPayload().getTariffConditionCollection()
                .stream()
                    .map(TariffConditionV1ResponseDto::getTariffRateForSbp)
                .findFirst().orElseThrow(() -> new TariffNotFoundException(""));
            var tariff = new MccTariff();
            tariff.setTariffRate(String.valueOf(rate).replace(".", ","));
            tariff.setMccCode(mccCode);
            return tariff;
        } catch (TariffNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error(ExceptionUtils.getStackTrace(e));
            throw new TariffSearchFailedException("");
        }
    }
}
