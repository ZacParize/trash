package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class TariffConditionV1ResponseDto {

    private PaymentLoadV1ResponseDto paymentLoad;

    private Long monthlyTerminalRentalFee;

    private List<TariffRateV1RequestResponseDto> tariffRateForPaymentSystemCollection;

    private Double tariffRateForSbp;
}
