package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

public enum BankProductFilterV1RequestEnum {

  POS,
  ECOM,
  VTB_CASH,
  QPS

}
