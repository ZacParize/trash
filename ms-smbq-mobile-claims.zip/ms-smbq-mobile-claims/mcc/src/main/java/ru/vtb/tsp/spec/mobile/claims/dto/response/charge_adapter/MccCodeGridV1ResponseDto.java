package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.List;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccCodeGridV1ResponseDto {

  private String name;

  private String code;

  private Boolean active;

  private List<TariffGroupLightCoreDto> tariffGroupCollection;

  private MccCodeGridMccGroupV1ResponseDto mccGroup;

  private List<BankProductConditionV1ResponseDto> mccProductConditionCollection;

}
