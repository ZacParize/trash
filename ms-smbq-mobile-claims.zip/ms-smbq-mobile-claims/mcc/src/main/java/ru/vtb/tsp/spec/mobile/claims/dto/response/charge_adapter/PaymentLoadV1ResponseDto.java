package ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.UUID;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentLoadV1ResponseDto {

    private UUID uuid;

    private String code;

    private Long from;

    private Long to;

    private Long per;

    private String temporalUnit;

    private String name;

}
