package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MccCodeGridFilterV1RequestDto {

  private StringFilterV1RequestDto codeOrName;

  private StringFilterV1RequestDto mccGroupCode;

  private UUIDFilterV1RequestDto tariffGroup;

  private AcquiringTypeFilterV1RequestDto tariffGroupForAcquiringType;

  private BooleanFilterV1RequestDto active;

  private BankProductFilterV1RequestDto bankProducts;

}
