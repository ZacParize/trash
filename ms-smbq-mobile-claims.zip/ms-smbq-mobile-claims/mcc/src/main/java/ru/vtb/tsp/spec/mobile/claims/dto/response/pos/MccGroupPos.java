package ru.vtb.tsp.spec.mobile.claims.dto.response.pos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.UUID;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class MccGroupPos {

  private UUID uuid;

  private Integer code;

  private String name;
}