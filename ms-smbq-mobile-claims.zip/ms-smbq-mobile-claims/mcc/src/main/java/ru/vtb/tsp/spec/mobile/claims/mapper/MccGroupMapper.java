package ru.vtb.tsp.spec.mobile.claims.mapper;

import java.util.List;
import java.util.UUID;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroup;
import ru.vtb.tsp.spec.mobile.claims.dto.response.MccGroupResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccGroupGridV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.charge_adapter.MccGroupGridWrappedV1ResponseDto;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccGroupPos;
import ru.vtb.tsp.spec.mobile.claims.dto.response.pos.MccGroupPosResponse;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface MccGroupMapper {

  @Mapping(target = "groups", source = "payload.content")
  MccGroupResponse toResponsePos(MccGroupGridWrappedV1ResponseDto response);

  @Mapping(target = "groups", source = "groups")
  MccGroupResponse toResponsePos(MccGroupPosResponse posResponse);


  List<MccGroup> toGroupsResponse(List<MccGroupGridV1ResponseDto> groupsCa);

  @Mapping(target = "id", source = "groupCa.code")
  @Mapping(target = "name", source = "groupCa.name")
  @Mapping(target = "uuid", expression = "java(java.util.UUID.randomUUID())")
  MccGroup fromCaGroup(MccGroupGridV1ResponseDto groupCa);

  List<MccGroup> toGroupsResponsePos(List<MccGroupPos> groupsCa);

}
