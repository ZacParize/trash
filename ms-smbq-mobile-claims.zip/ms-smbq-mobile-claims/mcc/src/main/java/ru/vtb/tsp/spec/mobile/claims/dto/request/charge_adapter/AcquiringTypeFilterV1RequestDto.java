package ru.vtb.tsp.spec.mobile.claims.dto.request.charge_adapter;

import java.util.List;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AcquiringTypeFilterV1RequestDto {

  private TariffRateAcquiringTypeV1Enum isEqual;

  private List<TariffRateAcquiringTypeV1Enum> notEquals;

  private List<TariffRateAcquiringTypeV1Enum> in;

  private List<TariffRateAcquiringTypeV1Enum> notIn;

}
