#!/bin/sh

java ${JAVA_OPTS} -Dfile.encoding=UTF-8 -Dcom.sun.jndi.ldap.object.disableEndpointIdentification=true --add-opens=java.base/java.lang=ALL-UNNAMED -jar /opt/mobile-claims.jar