package ru.vtb.tsp.spec.mobile.claims.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.vtb.tsp.spec.mobile.claims.common.config.CoreFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.request.EpaAuthRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.EpaTokenResponse;

@FeignClient(name = "epaIgTokenApi", url = "${extr.epa.ig.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class},
    decode404 = true)
public interface EpaAuthApi {

  @PostMapping(path = "/passport/oauth2/token", consumes = "application/x-www-form-urlencoded")
  EpaTokenResponse getToken(@RequestBody EpaAuthRequest request);
}