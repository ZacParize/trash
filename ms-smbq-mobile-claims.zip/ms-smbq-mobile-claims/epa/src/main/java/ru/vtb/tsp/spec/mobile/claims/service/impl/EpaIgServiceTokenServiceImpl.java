package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.request.EpaAuthRequest;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;
import ru.vtb.tsp.spec.mobile.claims.feign.EpaAuthApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgServiceTokenService;

import static ru.vtb.tsp.spec.mobile.claims.consts.EpaConstants.BEARER;

@RequiredArgsConstructor
@Service
@Slf4j
public class EpaIgServiceTokenServiceImpl implements EpaIgServiceTokenService, CheckIntegrationService {

  private static final String INTEGRATION_NAME = "ЕПА токен";

  private final EpaAuthApi epaAuthApi;
  @Value("${epa.grant.type}")
  private String grantType;

  @Value("${epa.client.id}")
  private String clientId;

  @Value("${epa.client.secret}")
  private String clientSecret;

  @Override
  public String getToken() {
    try {
      var tokenResponse = epaAuthApi.getToken(EpaAuthRequest.builder()
          .client_secret(clientSecret)
          .client_id(clientId)
          .grant_type(grantType)
          .build());
      if (tokenResponse != null && tokenResponse.getAccessToken() != null) {
        return BEARER + tokenResponse.getAccessToken();
      }
      throw new JwtIsNotValidException(
          "Token response is invalid. Not able to receive epa-ig token");
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new JwtIsNotValidException(
          "Token response is invalid. Not able to receive epa-ig token");
    }
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
      getToken();
    } catch (JwtIsNotValidException e) {
      return EndpointCheckDto.builder()
          .status(HttpStatus.NOT_FOUND.name())
          .build();
    }
    return EndpointCheckDto.builder()
        .status(HttpStatus.OK.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
