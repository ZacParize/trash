package ru.vtb.tsp.spec.mobile.claims.service.impl;

import static ru.vtb.tsp.spec.mobile.claims.consts.EpaConstants.BEARER;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.dev.corp.smbq.partnership.integration.epa.core.dto.EpaTechUserRawRequestDto;
import ru.vtb.dev.corp.smbq.partnership.integration.epa.core.service.EpaIGIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.exception.JwtIsNotValidException;
import ru.vtb.tsp.spec.mobile.claims.feign.EpaAuthApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.EpaIgTechTokenService;

@RequiredArgsConstructor
@Service
@Slf4j
public class EpaIgTechTokenServiceImpl implements EpaIgTechTokenService, CheckIntegrationService {

  private static final String INTEGRATION_NAME = "ЕПА tech-токен";

  private final EpaIGIntegrationService epaIGIntegrationService;

  @Value("${epa.tech.client.id}")
  private String techClientId;
  @Value("${epa.tech.client.secret}")
  private String techClientSecret;
  @Value("${epa.grant.type}")
  private String grantType;

  @Override
  public String getTechToken() {
    try {
      var tokenResponse = epaIGIntegrationService.getToken(
          EpaTechUserRawRequestDto.builder()
              .grantType(grantType)
              .clientId(techClientId)
              .clientSecret(techClientSecret)
              .build());
      if (tokenResponse != null) {
        return BEARER + tokenResponse.getAccessToken();
      }
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new JwtIsNotValidException(
          "Token response is invalid. Not able to receive epa-ig tech token");
    }
    throw new JwtIsNotValidException(
        "Token response is invalid. Not able to receive epa-ig tech token");
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    try {
      getTechToken();
    } catch (JwtIsNotValidException e) {
      return EndpointCheckDto.builder()
          .status(HttpStatus.NOT_FOUND.name())
          .build();
    }
    return EndpointCheckDto.builder()
        .status(HttpStatus.OK.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
