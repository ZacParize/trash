package ru.vtb.tsp.spec.mobile.claims.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class JwtIsNotValidException extends RuntimeException {

    public JwtIsNotValidException(String message) {
        super(message);
    }
}
