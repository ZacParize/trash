package ru.vtb.tsp.spec.mobile.claims.dto.request;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EpaAuthRequest {

  private String grant_type;

  private String client_secret;

  private String client_id;

}