package ru.vtb.tsp.spec.mobile.claims.service;

public interface EpaIgServiceTokenService {

  String getToken();

}
