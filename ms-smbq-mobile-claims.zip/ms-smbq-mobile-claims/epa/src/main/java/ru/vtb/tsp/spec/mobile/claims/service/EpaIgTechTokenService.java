package ru.vtb.tsp.spec.mobile.claims.service;

public interface EpaIgTechTokenService {

  String getTechToken();

}
