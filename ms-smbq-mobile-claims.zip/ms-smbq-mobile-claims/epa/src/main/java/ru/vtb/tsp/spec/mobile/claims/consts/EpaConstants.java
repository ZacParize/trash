package ru.vtb.tsp.spec.mobile.claims.consts;

public interface EpaConstants {

  String BEARER = "Bearer ";

}
