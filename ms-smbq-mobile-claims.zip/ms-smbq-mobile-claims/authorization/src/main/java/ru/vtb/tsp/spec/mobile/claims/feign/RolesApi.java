package ru.vtb.tsp.spec.mobile.claims.feign;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.response.RoleItemResponse;

@FeignClient(name = "rolesApi", url = "${pos.workflow.url}",
        configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface RolesApi {

    @GetMapping("/v3/permissions/roles")
    ResponseEntity<List<RoleItemResponse>> getUserRoles(@RequestParam("clientId") String clientId,
                              @RequestParam("userId") String userId,
                              @RequestHeader HttpHeaders httpHeaders);

}
