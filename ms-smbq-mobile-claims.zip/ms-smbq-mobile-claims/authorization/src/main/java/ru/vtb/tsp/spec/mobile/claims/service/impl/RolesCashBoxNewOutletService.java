package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.config.ClaimRoles;
import ru.vtb.tsp.spec.mobile.claims.service.RolesService;

@Slf4j
@Service
@RequiredArgsConstructor
public class RolesCashBoxNewOutletService implements RolesService {

  private final ClaimRoles properties;

  @Override
  public List<String> getRoles() {
    return properties.getQpsContractCreation();
  }

  @Override
  public ClaimType getType() {
    return ClaimType.QPS_CONTRACT_CREATION;
  }
}