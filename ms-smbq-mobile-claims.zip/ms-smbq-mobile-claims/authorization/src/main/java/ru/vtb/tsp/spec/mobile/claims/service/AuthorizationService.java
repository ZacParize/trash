package ru.vtb.tsp.spec.mobile.claims.service;

import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;

public interface AuthorizationService {

  void authorize(HttpHeaders headers, ClaimType claimType);

}
