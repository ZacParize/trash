package ru.vtb.tsp.spec.mobile.claims.config;

import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@ConfigurationProperties(prefix = "mobile.auth.roles", ignoreUnknownFields = false)
@Component
@Setter
@Getter
public class ClaimRoles {

  List<String> qpsContractCreation;
}