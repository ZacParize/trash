package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.service.AuthorizationService;

@Service
@RequiredArgsConstructor
@Profile("authorization_stub")
public class AuthorizationServiceStub implements AuthorizationService {

  @Override
  public void authorize(HttpHeaders headers, ClaimType claimType) {
    // stub
  }
}
