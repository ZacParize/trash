package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RoleItemResponse {

    private String roleName;

    private Boolean superRole;

    private String sourceSystemId;

    private String sourceSystemName;

    private Integer roleCreated;

    private Integer roleChanged;

    private Integer roleStart;

    private Integer roleEnd;

    private String error;

}
