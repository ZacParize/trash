package ru.vtb.tsp.spec.mobile.claims.exception;

public class AuthorizationFailedException extends RuntimeException {

  public AuthorizationFailedException(String errorMessage) {
    super(errorMessage);
  }

}