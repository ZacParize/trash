package ru.vtb.tsp.spec.mobile.claims.service;

import java.util.List;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;

public interface RolesService {

  List<String> getRoles();

  ClaimType getType();

}