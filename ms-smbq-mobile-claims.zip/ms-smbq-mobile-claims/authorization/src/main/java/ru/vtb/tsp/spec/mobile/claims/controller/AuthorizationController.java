package ru.vtb.tsp.spec.mobile.claims.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.AuthorizationService;

@RestController
@RequestMapping("${api-v1.root}/mobile/claims/auth")
@RequiredArgsConstructor
public class AuthorizationController {

  private final AuthorizationService authorizationService;

  @GetMapping
  @Logging
  @ResponseStatus(value = HttpStatus.NO_CONTENT)
  public void authorize(@RequestHeader HttpHeaders headers, ClaimType claimType) {
    authorizationService.authorize(headers, claimType);
  }

}
