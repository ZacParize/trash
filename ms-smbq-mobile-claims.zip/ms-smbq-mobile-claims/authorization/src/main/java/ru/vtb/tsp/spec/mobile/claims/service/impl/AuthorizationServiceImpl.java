package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.omni.audit.lib.api.annotation.AuditParam;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ClaimType;
import ru.vtb.tsp.spec.mobile.claims.dto.response.RoleItemResponse;
import ru.vtb.tsp.spec.mobile.claims.exception.AuthorizationFailedException;
import ru.vtb.tsp.spec.mobile.claims.feign.RolesApi;
import ru.vtb.tsp.spec.mobile.claims.service.AuthorizationService;
import ru.vtb.tsp.spec.mobile.claims.service.RolesService;
import ru.vtb.tsp.spec.mobile.claims.session.dto.response.OrganizationInfo;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;
import ru.vtb.tsp.spec.mobile.claims.session.utils.HeaderUtils;

@Service
@Profile("!authorization_stub")
@Slf4j
@RequiredArgsConstructor
public class AuthorizationServiceImpl implements AuthorizationService {

  private final SessionService sessionService;

  private final AuthorizationAuditedServiceImpl authorizationProxyService;

  @Override
  public void authorize(HttpHeaders headers, ClaimType claimType) {
    var sessionData = sessionService.getSessionData(headers);
    authorizationProxyService.authorizeAudited(sessionData, headers, claimType,
            sessionData.getFirstName() + sessionData.getMiddleName() + sessionData.getLastName(),
            sessionData.getInn(), HeaderUtils.getClaimId(headers));
  }

  @Service
  static class AuthorizationAuditedServiceImpl {

    private final RolesApi rolesApi;
    private final Map<ClaimType, RolesService> rolesByClaimType;

    public AuthorizationAuditedServiceImpl(RolesApi rolesApi,
                                           List<RolesService> rolesServices) {
      this.rolesApi = rolesApi;
      this.rolesByClaimType = rolesServices.stream()
              .collect(Collectors.toMap(RolesService::getType, Function.identity()));
    }
    
    @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_PROCESS_INIT, techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
    public void authorizeAudited(OrganizationInfo sessionData, HttpHeaders headers,
                                 ClaimType claimType, @AuditParam(value = "fio", sendParam = true, isMasking = true) String fio,
                                 @AuditParam(value = "inn", sendParam = true, isMasking = true) String inn, String claimId) {
      try {
        var clientId = sessionData.getMdmCode();
        var userId = sessionData.getMdmOsn();
        log.debug("Searching user roles in POS-WORKFLOW, clientId: {}, userId: {}", clientId, userId);
        var userRolesResponse = rolesApi.getUserRoles(clientId, userId, headers);
        if (userRolesResponse.getStatusCode() == HttpStatus.OK
                && userRolesResponse.getBody() != null) {
          var rolesService = rolesByClaimType.get(claimType);
          var userRoles = userRolesResponse.getBody().stream()
                  .map(RoleItemResponse::getRoleName)
                  .toList();
          if (rolesService != null) {
            var claimRoles = rolesService.getRoles();
            log.debug("User roles: [{}], required roles: [{}]", userRoles, claimRoles);
            if (!Collections.disjoint(userRoles, claimRoles)) {
              log.debug("User has sufficient roles: {}", clientId);
              return;
            }
          }

          throw new AuthorizationFailedException("");
        }
      } catch (Exception e) {
        log.error(ExceptionUtils.getStackTrace(e));
        throw new AuthorizationFailedException("");
      }
    }
  }
}
