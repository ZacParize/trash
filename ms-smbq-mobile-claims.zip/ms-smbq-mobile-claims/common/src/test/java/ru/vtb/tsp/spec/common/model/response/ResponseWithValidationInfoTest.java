package ru.vtb.tsp.spec.common.model.response;

import static org.junit.jupiter.api.Assertions.*;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ResponseWithValidationInfo;

class ResponseWithValidationInfoTest {

  @AllArgsConstructor
  static class TestDto {

    @NotEmpty(message = "Имя не может быть пустым")
    private String name;

    @NotNull(message = "Возраст не может отсутствовать")
    private Integer age;

  }

  @Test
  void ResponseWithValidationInfo_validDto_noErrors() {
    var response = new ResponseWithValidationInfo<>(new TestDto("Имя", 100));
    assertTrue(CollectionUtils.isEmpty(response.getErrors()));
  }

  @Test
  void ResponseWithValidationInfo_ageNotValid_errorWithAge() {
    var response = new ResponseWithValidationInfo<>(new TestDto("Имя", null));
    assertFalse(CollectionUtils.isEmpty(response.getErrors()));
    assertTrue(response.getErrors().stream().anyMatch(e -> e.getKey().equals("age")));
  }

}