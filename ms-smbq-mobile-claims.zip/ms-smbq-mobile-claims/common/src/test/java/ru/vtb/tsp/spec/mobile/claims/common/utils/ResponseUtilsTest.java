package ru.vtb.tsp.spec.mobile.claims.common.utils;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.junit.jupiter.api.Test;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType.NotResident;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType.Resident;

class ResponseUtilsTest {

  @AllArgsConstructor
  @NoArgsConstructor
  @Getter
  @Setter
  @Builder
  @JsonIgnoreProperties(ignoreUnknown = true)
  public static class MockOrganizationData {

    @Pattern(regexp = "\\d{10}", groups = ValidationType.Resident.class)
    @Pattern(regexp = "\\d{12}", groups = ValidationType.NotResident.class)
    private String magicField;

    @Pattern(regexp = "\\d{9}")
    @NotEmpty
    private String kpp;

    @Size(max = 2)
    private String sizeColumn;

  }

  @Test
  void validate_isResidentViolatesPattern_foundErrors() {
    var legalEntity = MockOrganizationData.builder()
        .magicField("666")
        .kpp(getStringOfNum(8))
        .sizeColumn("333")
        .build();
    var errors = ResponseUtils.validate(legalEntity, Resident.class);
    assertFalse(CollectionUtils.isEmpty(errors));
    assertTrue(errors.containsKey("magicField"));
    assertTrue(errors.containsKey("kpp"));
    assertTrue(errors.containsKey("sizeColumn"));
  }

  @Test
  void validate_isResidentCorrect_isValid() {
    var legalEntity = MockOrganizationData.builder()
        .magicField(getStringOfNum(10))
        .kpp(getStringOfNum(9))
        .build();
    var errors = ResponseUtils.validate(legalEntity, Resident.class);
    assertTrue(CollectionUtils.isEmpty(errors));
  }

  @Test
  void validate_isNotResidentViolatesPattern_foundErrors() {
    var legalEntity = MockOrganizationData.builder()
        .magicField("666")
        .build();
    var errors = ResponseUtils.validate(legalEntity, NotResident.class);
    assertFalse(CollectionUtils.isEmpty(errors));
    assertTrue(errors.containsKey("magicField"));
    assertTrue(errors.containsKey("kpp"));
  }

  @Test
  void validate_isNotResidentCorrect_isValid() {
    var legalEntity = MockOrganizationData.builder()
        .magicField(getStringOfNum(12))
        .kpp(getStringOfNum(9))
        .build();
    var errors = ResponseUtils.validate(legalEntity, NotResident.class);
    assertTrue(CollectionUtils.isEmpty(errors));
  }

  private String getStringOfNum(int size) {
    return IntStream.range(0, size)
        .mapToObj((i) -> "1")
        .collect(Collectors.joining());
  }

}