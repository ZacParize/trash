package ru.vtb.tsp.spec.mobile.claims.common.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum ErrorCode {

    // internal service error
    ACCOUNTS_NOT_FOUND("100001", "Не найден счет для расчетов по СБП"),
    FILE_CREATION_ERROR("100002", "Ошибка генерации файлов"),
    CLAIM_CREATION_ERROR("100003", "Ошибка регистрации заявки"),
    DOWNLOAD_FILE_STATUS_ERROR("100004", "Ошибка обработки запроса на получение статуса"),
    INTERNAL_CHECK_ADDRESS_ERROR("100005", "Внутренняя ошибка обработки запроса адреса"),

    // 1725 errors
    ATTEMPTS_LIMIT_EXCEEDED("100010", "Превышено количество попыток проверки кода"),
    NO_PROCESS_FOUND("100011", "Не найден процесс подписания документов"),
    INVALID_EXTERNAL_SYSTEM_RESPONSE("100012", "Не удалось получить успешный ответ от внешней системы"),
    VERIFICATION_CODE_NOT_MATCH("100013", "Ошибочный код подтверждения"),

    // CXK errors
    FILE_ECM_NOT_FOUND("100020", "Ошибка создания файлов в СХК"),
    ECM_FILE_DOWNLOAD_ERROR("100021", "Ошибка загрузки файла в СХК"),
    GET_ECM_FILE_ERROR("100022", "Ошибка получения файла из СХК"),

    // SMBQ interaction error
    TARIFF_NOT_FOUND("100030", "Тариф не найден"),
    GET_TARIFF_ERROR("100031", "Ошибка получения тарифа"),
    GET_DADATA_ADDRESS_ERROR("100032", "Ошибка проверки адреса в справочнике"),
    DOWNLOAD_FILE_ERROR("100033", "Ошибка загрузки файла в хранилище S3"),
    GET_STATUS_CHECK_DLP_FILE_ERROR("100034", "Ошибка получения статуса проверки DLP файла в хранилище S3"),
    GET_FILE_LINK_ERROR("100035", "Ошибка получения ссылки для загрузки файла"),
    SET_FILE_STATUS_ERROR("100036", "Сбой подтверждения статуса загрузки файла"),
    CHECK_PERMISSIONS_ERROR("100037", "Ошибка проверки разрешений пользователя"),

    // dadata
    ADDRESS_NOT_FOUND("100040", "Адрес не найден в справочнике"),

    // session-data
    GET_SESSION_ERROR("100050", "Ошибка получения сессионных данных");


    private final String code;

    private final String description;

}
