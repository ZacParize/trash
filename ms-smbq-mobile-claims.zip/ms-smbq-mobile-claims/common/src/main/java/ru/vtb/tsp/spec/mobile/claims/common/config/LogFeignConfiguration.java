package ru.vtb.tsp.spec.mobile.claims.common.config;

import feign.Logger;
import feign.codec.Encoder;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.PageJacksonModule;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LogFeignConfiguration {

  private final String NONE = "NONE";
  private final String BASIC = "BASIC";
  private final String HEADERS = "HEADERS";
  private final String FULL = "FULL";
  @Value("${feign.log.level}")
  private String logLevel;
  @Autowired
  private ObjectFactory<HttpMessageConverters> messageConverters;

  @Bean
  Logger.Level feignCustomLoggerLevel() {
    var level = Logger.Level.NONE;
    switch (logLevel) {
      case (NONE):
        level = Logger.Level.NONE;
        break;
      case (BASIC):
        level = Logger.Level.BASIC;
        break;
      case (HEADERS):
        level = Logger.Level.HEADERS;
        break;
      case (FULL):
        level = Logger.Level.FULL;
        break;
      default:
        level = Logger.Level.NONE;
    }
    return level;
  }

  @Bean
  public Encoder feignCustomEncoder() {
    return new PageableQueryEncoder(new SpringEncoder(this.messageConverters));
  }

  @Bean
  public PageJacksonModule pageCustomJacksonModule() {
    return new PageJacksonModule();
  }

}
