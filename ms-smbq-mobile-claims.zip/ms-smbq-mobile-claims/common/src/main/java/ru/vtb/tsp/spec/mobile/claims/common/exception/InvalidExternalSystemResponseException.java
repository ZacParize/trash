package ru.vtb.tsp.spec.mobile.claims.common.exception;

public class InvalidExternalSystemResponseException extends RuntimeException {

  public InvalidExternalSystemResponseException(String errorMessage) {
    super(errorMessage);
  }

}
