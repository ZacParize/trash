package ru.vtb.tsp.spec.mobile.claims.common.enums;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@JsonFormat(shape = JsonFormat.Shape.STRING)
@Getter
@RequiredArgsConstructor
public enum DocType {

  declaration_sbp("spec_sbpDocument_mb"),
  anketa_sbp("spec_qr_registration");

  private final String pdfServiceName;
}
