package ru.vtb.tsp.spec.mobile.claims.common.deserializer;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;

public class EmptyStringAsNullDeserializer extends JsonDeserializer<String> {

  @Override
  public String deserialize(JsonParser jsonParser,
      DeserializationContext ctxt) throws IOException {
    String str = jsonParser.getText();
    return StringUtils.isBlank(str) ? null : str;
  }

}
