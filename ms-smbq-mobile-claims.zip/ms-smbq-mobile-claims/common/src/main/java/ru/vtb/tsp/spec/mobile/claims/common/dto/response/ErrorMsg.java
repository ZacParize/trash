package ru.vtb.tsp.spec.mobile.claims.common.dto.response;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import ru.vtb.tsp.spec.mobile.claims.common.enums.ErrorCode;

@Getter
@Setter
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ErrorMsg {

  private String error;
  private String message;
  private String code;

  public static ErrorMsg from(ErrorCode errorCode) {
    var errorMsg = new ErrorMsg();
    errorMsg.setError(errorCode.name());
    errorMsg.setMessage(errorCode.getDescription());
    errorMsg.setCode(errorCode.getCode());
    return errorMsg;
  }

}
