package ru.vtb.tsp.spec.mobile.claims.common.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Data;
import ru.vtb.tsp.spec.mobile.claims.common.dto.request.ValidationType;
import ru.vtb.tsp.spec.mobile.claims.common.utils.ResponseUtils;

@Data
public class ResponseWithValidationInfo<T> {

  T data;

  List<ValidationError> errors;

  public ResponseWithValidationInfo(T data, Class<? extends ValidationType> validationType) {
    this.data = data;
    this.errors = new ArrayList<>(ResponseUtils.validate(data, validationType).values());
  }

  public ResponseWithValidationInfo(T data) {
    this.data = data;
    this.errors = new ArrayList<>(ResponseUtils.validate(data).values());
  }

}
