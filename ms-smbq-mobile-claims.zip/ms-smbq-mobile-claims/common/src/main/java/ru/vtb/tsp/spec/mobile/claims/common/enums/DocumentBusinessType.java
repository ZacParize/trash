package ru.vtb.tsp.spec.mobile.claims.common.enums;


import lombok.ToString;

@ToString
public enum DocumentBusinessType {

  DECLARATION,
  DECLARATION_QPS,
  OFFER,
  OFFER_QPS,
  OTHER,
  CHANGE_DECLARATION;

  public static DocumentBusinessType from(DocType docType) {
    return switch (docType) {
      case declaration_sbp -> DECLARATION_QPS;
      case anketa_sbp -> OFFER_QPS;
      default -> throw new UnsupportedOperationException("claimType is not supported");
    };
  }

}
