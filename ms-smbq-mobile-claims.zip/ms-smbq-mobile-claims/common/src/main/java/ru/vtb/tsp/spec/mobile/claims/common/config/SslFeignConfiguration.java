package ru.vtb.tsp.spec.mobile.claims.common.config;

import feign.Client;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;

import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.GeneralSecurityException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

@Configuration
@Slf4j
@ConditionalOnProperty(value = "session.mtls.enabled", havingValue = "true")
public class SslFeignConfiguration {

  @Bean
  public Client feignClient(@Value("${smbq.truststore.password}") String trustStorePassword,
                            @Value("${smbq.truststore.path}") File trustStore,
                            @Value("${smbq.keystore.password}") String keyStorePassword,
                            @Value("${smbq.keystore.path}") String keyStorePath) throws Exception {
    File keyStore = ResourceUtils.getFile(keyStorePath);

    log.debug("Installing certificates for feign client");
    SSLContext sslcontext = SSLContexts.custom()
            .loadTrustMaterial(trustStore, trustStorePassword.toCharArray())
            .loadKeyMaterial(keyStore, keyStorePassword.toCharArray(), keyStorePassword.toCharArray())
            .build();
    return new Client.Default(sslcontext.getSocketFactory(), new DefaultHostnameVerifier());
  }
}
