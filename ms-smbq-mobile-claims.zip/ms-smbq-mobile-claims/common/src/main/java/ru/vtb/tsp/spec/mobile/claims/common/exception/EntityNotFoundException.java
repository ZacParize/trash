package ru.vtb.tsp.spec.mobile.claims.common.exception;

public class EntityNotFoundException extends RuntimeException {

  public EntityNotFoundException(String errorMessage) {
    super(errorMessage);
  }

}
