package ru.vtb.tsp.spec.mobile.claims.common.utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.groups.Default;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ValidationError;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ResponseUtils {

  private static final ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
  private static final Validator validator = factory.getValidator();

  public static Map<String, ValidationError> validate(Object instance) {
    return getViolations(instance, new Class[]{Default.class});
  }

  public static Map<String, ValidationError> validate(Object instance, Class<?> validationGroup) {
    return getViolations(instance, new Class[]{validationGroup, Default.class});
  }

  private static HashMap<String, ValidationError> getViolations(Object instance,
      Class<?>[] groupsWithDefault) {
    var errors = new HashMap<String, ValidationError>();
    var violations = validator.validate(instance, groupsWithDefault);
    if (violations.size() > 0) {
      for (var violation : violations) {
        if (violation.getConstraintDescriptor().getGroups().stream()
            .anyMatch(v -> List.of(groupsWithDefault).contains(v))) {
          var error = ValidationError.builder()
              .key(violation.getPropertyPath().toString())
              .value(violation.getInvalidValue() == null ? null : violation.getInvalidValue().toString())
              .reason(violation.getMessage())
              .build();
          errors.put(violation.getPropertyPath().toString(), error);
        }
      }
    }
    return errors;
  }


}
