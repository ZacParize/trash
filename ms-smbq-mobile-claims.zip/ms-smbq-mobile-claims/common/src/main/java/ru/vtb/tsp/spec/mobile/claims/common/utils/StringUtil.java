package ru.vtb.tsp.spec.mobile.claims.common.utils;

public class StringUtil {

  private StringUtil() {
  }

  public static String removeFirst(String value, String subString) {
    if (value != null && !value.isEmpty()) {
      int subStringLength = subString.length();
      if (value.length() >= subStringLength && value.substring(0, subStringLength)
          .equalsIgnoreCase(subString)) {
        value = value.substring(subStringLength);
      }
    }
    return value;
  }
}
