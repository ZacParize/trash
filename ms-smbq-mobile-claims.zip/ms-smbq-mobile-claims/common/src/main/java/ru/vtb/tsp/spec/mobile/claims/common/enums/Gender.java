package ru.vtb.tsp.spec.mobile.claims.common.enums;

public enum Gender {

  MALE,
  FEMALE

}
