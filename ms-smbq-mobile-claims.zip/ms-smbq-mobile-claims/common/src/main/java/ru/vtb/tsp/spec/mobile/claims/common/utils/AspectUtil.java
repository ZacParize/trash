package ru.vtb.tsp.spec.mobile.claims.common.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.reflect.MethodSignature;

import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class AspectUtil {

  public static Object getParameter(ProceedingJoinPoint joinPoint, String parameterName) {
    Object value = null;
    if (Objects.nonNull(joinPoint) && joinPoint.getSignature() instanceof MethodSignature
        && Objects.nonNull(parameterName)) {
      var methodSignature = (MethodSignature) joinPoint.getSignature();
      var parameterNames = methodSignature.getParameterNames();
      for (int i = 0; i < parameterNames.length; i++) {
        if (Objects.nonNull(parameterNames[i]) && parameterNames[i].equals(parameterName)) {
          var args = joinPoint.getArgs();
          value = args[i];
          break;
        }
      }
    }
    return value;
  }

}