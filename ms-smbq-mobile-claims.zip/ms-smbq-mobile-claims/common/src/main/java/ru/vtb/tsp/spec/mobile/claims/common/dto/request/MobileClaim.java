package ru.vtb.tsp.spec.mobile.claims.common.dto.request;

import lombok.Data;

import java.util.List;

@Data
public abstract class MobileClaim {

    private String id;

    private String claimNumber;

    private List<String> bankProductCollection;

    private String description;


}
