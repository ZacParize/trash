package ru.vtb.tsp.spec.mobile.claims.common.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@RequiredArgsConstructor
@Getter
@ToString
public enum ClaimType {

  QPS_CONTRACT_CREATION("СБП для новых клиентов");

  private final String claimName;
}
