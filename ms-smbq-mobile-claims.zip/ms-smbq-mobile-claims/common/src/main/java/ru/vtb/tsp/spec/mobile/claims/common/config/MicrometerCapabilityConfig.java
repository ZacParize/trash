package ru.vtb.tsp.spec.mobile.claims.common.config;

import feign.Feign;
import feign.micrometer.MicrometerCapability;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("feign_metrics")
public class MicrometerCapabilityConfig {

  @Bean
  public Feign.Builder feignBuilder(MeterRegistry meterRegistry) {
    return Feign.builder()
        .addCapability(new MicrometerCapability(meterRegistry));
  }

}