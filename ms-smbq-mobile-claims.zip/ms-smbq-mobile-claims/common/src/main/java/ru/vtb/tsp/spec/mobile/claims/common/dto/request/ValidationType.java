package ru.vtb.tsp.spec.mobile.claims.common.dto.request;

public interface ValidationType {

  interface Resident extends ValidationType {

  }

  interface NotResident extends ValidationType {

  }

}
