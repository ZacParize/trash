package ru.vtb.tsp.spec.mobile.claims.mapper;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.mapstruct.ReportingPolicy;
import ru.vtb.dev.corp.smbq.core.claims.orchestrator.infrastructure.kafka.api.dto.*;
import ru.vtb.dev.corp.smbq.partnership.connector.csoc.rest.dto.response.EtalonClientSnapshotCsocResponseDto;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocumentBusinessType;
import ru.vtb.tsp.spec.mobile.claims.common.enums.Gender;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.BankProduct;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.MdmLegalStatus;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimCreationRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimFileRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.MerchantRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.QpsContractDetailRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.TstRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;
import ru.vtb.tsp.spec.mobile.claims.entity.ClaimEntity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

@Mapper(componentModel = "spring",
    unmappedTargetPolicy = ReportingPolicy.IGNORE,
    builder = @Builder(disableBuilder = true))
public interface OrchestratorMapper {

  String API_SOURCE = "VTB_SBP";
  int MONTH_TURNOVER = 100000;
  int PERCENTAGE_FOREIGN_CARD = 1;
  String MS_SMBQ_SPEC_MOBILE_CLAIMS = "ms-smbq-mobile-claims";
  String DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";
  String BANK_ACCOUNT = "ФИЛИАЛ \"ЦЕНТРАЛЬНЫЙ\" БАНКА ВТБ (ПАО) г МОСКВА";
  String BANK_CORR_ACCOUNT = "30101810142250000411";
  String BANK_BIK = "044525411";
  String MERCHANT_LEGAL_ADDRESS = "LEGAL";
  String MERCHANT_FACT_ADDRESS = "FACT";
  String TST_ADDRESS = "TST_ADDRESS";
  String HEAD_REG_ADDRESS = "REG_ADDRESS";

  default ClaimPosNewContractRegistrationEventV1InKafkaDto toSbpNewClient(
      ClaimCreationRequest claim,
      EtalonClientSnapshotCsocResponseDto legalEntity,
      ClaimEntity claimEntity,
      Map<String, SucsDadataAddressResponse> dadataResponseByAddress) {
    var claimPosNewContractRegistrationEventV1InKafkaDto = new ClaimPosNewContractRegistrationEventV1InKafkaDto();
    var claimData = new ClaimPosNewContractV1InKafkaDto();
    claimData.setId(UUID.fromString(claimEntity.getClaimId()));
    claimData.setClaimNumber(claimEntity.getClaimNumber());
    claimData.setBankProductCollection(claim.getBankProductCollection().stream()
        .map(this::bankProduct)
        .toList());
    claimData.setMerchant(toMerchant(claim, legalEntity, dadataResponseByAddress));
    claimData.setFileCollection(claim.getClaimDetail().getFileCollection().stream()
            .map(this::fileRequest)
        .collect(Collectors.toList()));
    claimData.setAttractionDetail(attractionDetail());
    claimData.setQpsContractDetail(toQpsContractDetails(claim, claimEntity));
    claimData.setTstCollection(claim.getClaimDetail().getTstCollection().stream()
        .map((tstRequest -> tstRequest(tstRequest, dadataResponseByAddress)))
        .collect(Collectors.toList()));
    claimPosNewContractRegistrationEventV1InKafkaDto.setClaimData(claimData);
    return claimPosNewContractRegistrationEventV1InKafkaDto;
  }

  default QpsContractDetailV1InKafkaDto toQpsContractDetails(ClaimCreationRequest claim, ClaimEntity claimEntity) {
    var qpsContractDetails = new QpsContractDetailV1InKafkaDto();
    qpsContractDetails.setContractNumber(claimEntity.getClaimNumber());
    QpsContractDetailRequest qpsContractDetail = claim.getClaimDetail().getQpsContractDetail();
    qpsContractDetails.setContractDate(LocalDate.parse(qpsContractDetail.getContractDate()));
    qpsContractDetails.setAcquiringSegment(AcquiringSegmentV1KafkaEnum.SBP);
    qpsContractDetails.setApiSource(API_SOURCE);
    var bankDetail = new BankDetailV1InKafkaDto();
    bankDetail.setAccountType(AccountTypeV1KafkaEnum.QPS_ACQUIRING);
    bankDetail.setBik(BANK_BIK);
    bankDetail.setCorrAccount(BANK_CORR_ACCOUNT);
    bankDetail.setName(BANK_ACCOUNT);
    bankDetail.setAccount(claim.getClaimDetail().getQpsContractDetail().getBankAccount());
    qpsContractDetails.setBankDetailCollection(List.of(bankDetail));
    qpsContractDetails.setReportSendingCollection(qpsContractDetail.getReportSendingCollection().stream()
        .map(rep -> {
          var report = new ReportSendingDetailV1InKafkaDto();
          report.setEmail(report.getEmail());
          report.setFormat(report.getFormat());
          return report;
        }).collect(Collectors.toList()));
    return qpsContractDetails;
  }

  default MerchantV1InKafkaDto toMerchant(ClaimCreationRequest claim,
      EtalonClientSnapshotCsocResponseDto legalEntity, Map<String, SucsDadataAddressResponse> dadataResponseByAddress) {
    var merchant = new MerchantV1InKafkaDto();
    merchant.setMdmCode(legalEntity.getMdmCode().toString());
    MerchantRequest merchantRequest = claim.getClaimDetail().getMerchant();
    merchant.setNameRus(merchantRequest.getNameRus());
    merchant.setNameEng(legalEntity.getNameEn());
    merchant.setInn(merchantRequest.getInn());
    merchant.setKpp(merchantRequest.getKpp());
    merchant.setOkved(merchantRequest.getOkved());
    merchant.setOkpo(merchantRequest.getOkpo());
    merchant.setOgrn(merchantRequest.getOgrn());
    merchant.setBudget(false);
    merchant.setMdmLegalStatus(MdmLegalStatus.valueOf(legalEntity.getMdmLegalStatusCode()).name());
    merchant.setPhoneCollection(merchantRequest.getPhoneCollection());
    merchant.setEmailCollection(merchantRequest.getEmailCollection());

    merchant.setLegalAddress(mapAddress(merchantRequest.getLegalAddress(), dadataResponseByAddress.get(merchantRequest.getLegalAddress()),
        MERCHANT_LEGAL_ADDRESS));
    merchant.setFactAddress(mapAddress(merchantRequest.getFactAddress(), dadataResponseByAddress.get(merchantRequest.getFactAddress()),
        MERCHANT_FACT_ADDRESS));

    var headPersonDetail = new PersonDetailV1InKafkaDto();
    var headPersonReq = merchantRequest.getHeadPersonDetail();
    var names = Arrays.asList(headPersonReq.getFio().split(" "));
    headPersonDetail.setLastName(names.get(2));
    headPersonDetail.setFirstName(names.get(1));
    headPersonDetail.setMiddleName(names.get(0));
    headPersonDetail.setPosition(headPersonReq.getPosition());
    headPersonDetail.setSex(toSex(headPersonReq.getSex()));
    headPersonDetail.setBirthday(LocalDate.parse(headPersonReq.getBirthday()));
    headPersonDetail.setPhoneCollection(headPersonReq.getPhoneCollection());
    headPersonDetail.setEmailCollection(headPersonReq.getEmailCollection());
    headPersonDetail.setRegAddress(mapAddress(headPersonReq.getRegAddress(), dadataResponseByAddress.get(headPersonReq.getRegAddress()),
        HEAD_REG_ADDRESS));

    var passport = new PassportV1InKafkaDto();
    var passportReq = headPersonReq.getPassport();
    passport.setSeries(passportReq.getSeries());
    passport.setNumber(passportReq.getNumber());
    passport.setIssuedDate(LocalDate.parse(passportReq.getIssuedDate()));
    passport.setIssuedBy(passportReq.getIssuedBy());
    passport.setNonResident(!passportReq.getIsResident());
    passport.setCitizenship(passportReq.getCitizenship());
    headPersonDetail.setPassport(passport);

    merchant.setHeadPersonDetail(headPersonDetail);
    return merchant;
  }

  default SexV1KafkaEnum toSex(Gender gender) {
    return SexV1KafkaEnum.valueOf(gender.name());
  }

  private AddressV1KafkaDto mapAddress(String fullAddress, SucsDadataAddressResponse dadataAddress, String addressType) {
    try {
      var address = new AddressV1KafkaDto();
      address.setOktmo(dadataAddress.getOktmo());
      address.setPostalCode((String) getDadataFieldOrElseThrow(dadataAddress::getPostalCode));

      var regionInfo = new AddressRegionV1KafkaDto();
      regionInfo.setRegionWithType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getRegion().getValueWithType()));
      regionInfo.setRegion(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getRegion().getValue()));
      address.setRegionInfo(regionInfo);

      var areaInfo = new AddressAreaV1KafkaDto();
      areaInfo.setArea(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getArea().getValue()));
      areaInfo.setAreaWithType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getArea().getValueWithType()));
      address.setAreaInfo(areaInfo);

      var cityInfo = new AddressCityV1KafkaDto();
      cityInfo.setCity(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getCity().getValue()));
      cityInfo.setCityWithType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getCity().getValueWithType()));
      address.setCityInfo(cityInfo);

      var cityDistrictInfo = new AddressCityDistrictV1KafkaDto();
      address.setCityDistrictInfo(cityDistrictInfo);

      var settlementInfo = new AddressSettlementV1KafkaDto();
      settlementInfo.setSettlement(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getSettlement().getValue()));
      settlementInfo.setSettlementWithType((String) getDadataFieldOrElseThrow(
          () -> dadataAddress.getSettlement().getValueWithType()));
      address.setSettlementInfo(settlementInfo);

      var streetInfo = new AddressStreetV1KafkaDto();
      streetInfo.setStreet(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getStreet().getValue()));
      streetInfo.setStreetWithType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getStreet().getValueWithType()));
      address.setStreetInfo(streetInfo);

      var houseInfo = new AddressHouseV1KafkaDto();
      houseInfo.setHouse(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getHouse().getValue()));
      houseInfo.setHouseType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getHouse().getValueWithType()));
      address.setHouseInfo(houseInfo);

      var blockInfo = new AddressBlockV1KafkaDto();
      blockInfo.setBlock(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getBlock().getValue()));
      blockInfo.setBlockType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getBlock().getValueWithType()));
      address.setBlockInfo(blockInfo);

      var flatInfo = new AddressFlatV1KafkaDto();
      flatInfo.setFlat(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getFlat().getValue()));
      flatInfo.setFlatType(
          (String) getDadataFieldOrElseThrow(() -> dadataAddress.getFlat().getType()));
      address.setFlatInfo(flatInfo);

      address.setFullAddress(fullAddress);
      return address;
    } catch (Exception e) {
      throw new RuntimeException("Exception while parsing dadataAddress, addressType: " + addressType, e.getCause());
    }
  }

  private Object getDadataFieldOrElseThrow(Supplier<Object> function) {
    try {
      return function.get();
    } catch (Exception e) {
      return null;
    }
  }

  default TstDetailV1InKafkaDto tstRequest(TstRequest tstRequest, Map<String, SucsDadataAddressResponse> dadataResponseByAddress) {
    var tstDetail = new TstDetailV1InKafkaDto();
    tstDetail.setId(UUID.randomUUID());
    tstDetail.setMcc(tstRequest.getMcc());
    tstDetail.setTradeName(tstRequest.getTradeName());
    tstDetail.nameEng(tstRequest.getNameEng());
    tstDetail.setActivityInfo(tstRequest.getActivityInfo());
    tstDetail.setAssortment(tstRequest.getAssortment());
    tstDetail.setMonthTurnover(BigDecimal.valueOf(MONTH_TURNOVER));
    tstDetail.setPercentageForeignCard(BigDecimal.valueOf(PERCENTAGE_FOREIGN_CARD));
    tstDetail.setFactAddress(mapAddress(tstRequest.getTstAddress(), dadataResponseByAddress.get(tstRequest.getTstAddress()),
        TST_ADDRESS));
    var claimPersonDetail = new ShortPersonDetailV1InKafkaDto();
    claimPersonDetail.setPhoneCollection(tstRequest.getContactPersonDetail().getPhoneCollection());
    claimPersonDetail.setFullName(tstRequest.getContactPersonDetail().getFullName());
    tstDetail.setContactPersonDetail(claimPersonDetail);
    return tstDetail;
  }

  default BankProductV1KafkaEnum bankProduct(BankProduct bankProduct) {
    return BankProductV1KafkaEnum.fromValue(bankProduct.name());
  }

  @Named("attractionDetail")
  default AttractionDetailV1InKafkaDto attractionDetail() {
    var attractionDetail = new AttractionDetailV1InKafkaDto();
    attractionDetail.setChannel(OmniChannelV1KafkaEnum.MOBILE);
    attractionDetail.setMicroservice(MS_SMBQ_SPEC_MOBILE_CLAIMS);
    attractionDetail.setVerificationRequired(false);
    var formatter = DateTimeFormatter.ofPattern(DATE_PATTERN);
    var date = OffsetDateTime.parse(OffsetDateTime.now().format(formatter));
    attractionDetail.setCreateTime(date);
    attractionDetail.setModifyTime(date);
    return attractionDetail;
  }

  @Mapping(target = "id", source = "request.id")
  @Mapping(target = "businessType", source = "request.businessType")
  @Mapping(target = "name", source = "request.name")
  @Mapping(target = "hashSum", source = "request.hashSum")
  FileInformationV1InKafkaDto fileRequest(ClaimFileRequest request);

  default ClaimFileBusinessTypeV1KafkaEnum businessType(DocumentBusinessType businessType) {
    return ClaimFileBusinessTypeV1KafkaEnum.fromValue(businessType.name());
  }

}
