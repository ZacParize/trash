package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.BankProduct;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class TstRequest {

    private String mcc;

    private String tradeName;

    private String nameEng;

    private String activityInfo;

    private String assortment;

    private String tstAddress;

    private ContactPersonDetailRequest contactPersonDetail;

}