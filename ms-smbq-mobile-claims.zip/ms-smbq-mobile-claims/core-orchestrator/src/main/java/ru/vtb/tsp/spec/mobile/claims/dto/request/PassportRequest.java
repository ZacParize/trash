package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.ClaimChannel;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PassportRequest {

    private String series;

    private String number;

    private String birthPlace;

    private String issuedDate;

    private String issuedBy;

    private String issuerCode;

    private Boolean isResident;

    private String citizenship;

}