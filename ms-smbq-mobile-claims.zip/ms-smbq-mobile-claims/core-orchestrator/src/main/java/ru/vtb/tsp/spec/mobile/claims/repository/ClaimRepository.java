package ru.vtb.tsp.spec.mobile.claims.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ru.vtb.tsp.spec.mobile.claims.entity.ClaimEntity;
import ru.vtb.tsp.spec.mobile.claims.entity.CountryEntity;

import java.util.Optional;

@Repository
public interface ClaimRepository extends JpaRepository<ClaimEntity, Long> {


}