package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.Gender;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.ClaimChannel;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class PersonDetailRequest {

    private String fio;

    private String position;

    private Gender sex;

    private String birthday;

    private List<String> phoneCollection;

    private List<String> emailCollection;

    private String regAddress;

    private PassportRequest passport;

}