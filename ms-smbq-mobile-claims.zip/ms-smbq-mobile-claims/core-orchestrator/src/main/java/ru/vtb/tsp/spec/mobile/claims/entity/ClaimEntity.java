package ru.vtb.tsp.spec.mobile.claims.entity;

import lombok.*;
import org.hibernate.annotations.ColumnTransformer;
import ru.vtb.tsp.spec.mobile.claims.util.HashMapConverter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.UUID;

@Entity
@Setter
@Getter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "claim")
public class ClaimEntity {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  private String mdm;

  private UUID uuid;

  @PrePersist
  public void prePersist() {
    if (this.uuid == null) {
      this.uuid = UUID.randomUUID();
    }
  }

  @Convert(converter = HashMapConverter.class)
  @ColumnTransformer(write = "?::jsonb")
  private Map<String, Object> claimDump;

  private String claimNumber;

  private String claimId;

  private String channel;

  private String status;

  private LocalDateTime sendDate;

  private String error;

}
