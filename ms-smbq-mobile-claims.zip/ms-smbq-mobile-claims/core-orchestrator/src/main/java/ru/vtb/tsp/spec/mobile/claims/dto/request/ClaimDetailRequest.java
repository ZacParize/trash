package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.BankProduct;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimDetailRequest {

    private MerchantRequest merchant;
    private QpsContractDetailRequest qpsContractDetail;
    private List<TstRequest> tstCollection;
    private List<ClaimFileRequest> fileCollection;
    private AttractionDetailRequest attractionDetail;

}