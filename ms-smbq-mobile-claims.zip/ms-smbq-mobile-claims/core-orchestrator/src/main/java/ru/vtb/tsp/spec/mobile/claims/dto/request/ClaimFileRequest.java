package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import ru.vtb.tsp.spec.mobile.claims.common.enums.DocumentBusinessType;
import ru.vtb.tsp.spec.mobile.claims.dto.enums.ClaimChannel;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ClaimFileRequest {

    private String id;

    private DocumentBusinessType businessType;

    private String name;

    private String hashSum;

}