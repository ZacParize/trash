package ru.vtb.tsp.spec.mobile.claims.dto.enums;

public enum BankProduct {
    QPS
}
