package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.dev.corp.smbq.core.claims.orchestrator.infrastructure.kafka.api.process.newcontract.producer.v1.ClaimRegistrationProcessV1InKafkaProducer;
import ru.vtb.omni.audit.lib.api.annotation.Audit;
import ru.vtb.tsp.spec.mobile.claims.audit.consts.AuditConstant;
import ru.vtb.tsp.spec.mobile.claims.common.dto.response.ValidationError;
import ru.vtb.tsp.spec.mobile.claims.common.utils.ResponseUtils;
import ru.vtb.tsp.spec.mobile.claims.controller.DaDataAdapterController;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimCreationRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimFileRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.request.SucsDadataAddressRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.ClaimCreationResponse;
import ru.vtb.tsp.spec.mobile.claims.dto.response.SucsDadataAddressResponse;
import ru.vtb.tsp.spec.mobile.claims.entity.ClaimEntity;
import ru.vtb.tsp.spec.mobile.claims.exception.ClaimRegistrationException;
import ru.vtb.tsp.spec.mobile.claims.feign.DadataAdapterApi;
import ru.vtb.tsp.spec.mobile.claims.mapper.OrchestratorMapper;
import ru.vtb.tsp.spec.mobile.claims.repository.ClaimRepository;
import ru.vtb.tsp.spec.mobile.claims.service.*;
import ru.vtb.tsp.spec.mobile.claims.session.filter.ClaimIdMdcFilter;
import ru.vtb.tsp.spec.mobile.claims.session.service.HeaderService;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;

import java.util.UUID;
import ru.vtb.tsp.spec.mobile.claims.session.utils.HeaderUtils;

@Service
@RequiredArgsConstructor
@Slf4j
public class ClaimServiceImpl implements ClaimService {

  public static final String CLAIM_TYPE = "-СБП02-МБ";
  private final ClaimRepository claimRepository;
  private final ClaimProxyService claimProxyService;

  @Override
  public ClaimCreationResponse create(HttpHeaders headers, ClaimCreationRequest request) {
    try {
      var claimId = HeaderUtils.getClaimId(headers);
      if (StringUtils.isBlank(claimId)) {
        throw new ClaimRegistrationException("claimId from front is null");
      }
      var claimEntity = new ClaimEntity();
      claimEntity.setClaimId(claimId);
      claimEntity.setSendDate(LocalDateTime.now());
      claimEntity = claimRepository.saveAndFlush(claimEntity);
      claimEntity.setClaimNumber(claimEntity.getId() + CLAIM_TYPE);
      log.debug("Setting id for claim: {}", claimEntity.getClaimId());
      return claimProxyService.create(headers, request, claimEntity);
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new ClaimRegistrationException("");
    }
  }

  @Service
  @Slf4j
  @RequiredArgsConstructor
  static class ClaimProxyService {

    private final DadataAdapterApi adapterApi;
    private final HeaderService headerService;
    private final ClaimRegistrationProcessV1InKafkaProducer producer;
    private final OrganizationService organizationService;
    private final OrchestratorMapper orchestratorMapper;
    private final SessionService sessionService;
    private final NotificationCodeService notificationCodeService;
    private final FileStorageService fileStorageService;
    private final ClaimRepository claimRepository;

    @Value("${kafka-send-claim.retry.times:5}")
    private Integer retryTimes;

    @Value("${kafka-send-claim.retry.sleep:1000}")
    private Integer retrySleep;

    @Value("${extended_debug_info:false}")
    private Boolean extendedDebugInfo;

    @Audit(value = AuditConstant.SMBQ_MB_CLAIMS_SEND_KAFKA, techSectionCodes = {"fin_oper", "fin_keep", "fin_gen"})
    public ClaimCreationResponse create(HttpHeaders headers, ClaimCreationRequest request,
        ClaimEntity claimEntity) {
      notificationCodeService.verifyNotificationCode(request.getSmsVerificationCode(),
          request.getSignatureProcessId());

      var uuids = request.getClaimDetail().getFileCollection()
          .stream().map(doc -> UUID.fromString(doc.getId()))
          .toList();
      fileStorageService.acquireOwnership(uuids);

      var dadataResponseByAddress = new HashMap<String, SucsDadataAddressResponse>();
      fillAddressMap(request.getClaimDetail().getMerchant().getFactAddress(),
          dadataResponseByAddress);
      fillAddressMap(request.getClaimDetail().getMerchant().getLegalAddress(),
          dadataResponseByAddress);
      fillAddressMap(
          request.getClaimDetail().getMerchant().getHeadPersonDetail().getRegAddress(),
          dadataResponseByAddress);
      request.getClaimDetail().getTstCollection()
          .forEach(tst -> {
            fillAddressMap(tst.getTstAddress(), dadataResponseByAddress);
          });

      var mdmCode = Long.valueOf(sessionService.getSessionData(headers).getMdmCode());
      claimEntity.setMdm(String.valueOf(mdmCode));
      var kafkaClaim = orchestratorMapper.toSbpNewClient(
          request,
          organizationService.getLegalEntity(mdmCode),
          claimEntity,
          dadataResponseByAddress
      );
      if (extendedDebugInfo) {
        log.debug("Kafka claim info: {}", kafkaClaim);
      }
      var validationErrors = ResponseUtils.validate(kafkaClaim);
      var dump = Optional.ofNullable(claimEntity.getClaimDump()).orElse(new HashMap<>());
      dump.put("errorMsg", validationErrors);
      claimEntity.setClaimDump(dump);
      claimRepository.save(claimEntity);

      var claimResponse = new ClaimCreationResponse();
      claimResponse.setClaimUuid(claimEntity.getClaimId());
      for (var i = 0; i < retryTimes; i++) {
        try {
          var uuid = producer.sendEvent(kafkaClaim);
          if (uuid != null) {
            log.debug("Send claim success, uuid from orchestrator: {}", uuid);
            break;
          }
        } catch (Exception e) {
          log.error("Send claim failed, attempt: {}, out of: {}", i, retryTimes);
          log.error(ExceptionUtils.getStackTrace(e));
          try {
            Thread.sleep(retrySleep);
          } catch (InterruptedException ex) {
            // ignore
          }
        }
      }

      request.getClaimDetail().getFileCollection()
          .forEach(doc -> fileStorageService.deletePermission(UUID.fromString(doc.getId())));
      claimResponse.setClaimNumber(claimEntity.getClaimNumber());
      claimResponse.setMessage("OK");
      return claimResponse;
    }

    private void fillAddressMap(String fullAddress,
        Map<String, SucsDadataAddressResponse> dadataResponseByAddress) {
      adapterApi.sucsSearch(headerService.ofDadataHeaders(),
              SucsDadataAddressRequest.builder()
                  .request(fullAddress)
                  .count(1)
                  .build()).getAddresses()
          .forEach(address -> {
            dadataResponseByAddress.put(fullAddress, address);
          });
    }
  }
}
