package ru.vtb.tsp.spec.mobile.claims.dto.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum MdmLegalStatus {

  Undefined(0),
  Citizen(1),
  Businessman(2),
  Enterprise(3),
  Finance(4),
  Lawyer(5),
  Notary(6),
  Farmer(7),
  Holding(8);


  private final Integer code;
}
