package ru.vtb.tsp.spec.mobile.claims.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;

import javax.persistence.AttributeConverter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class HashMapConverter implements AttributeConverter<Map<String, Object>, String> {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    static {{
        objectMapper.registerModule(new JavaTimeModule());
    }}

    @Override
    public String convertToDatabaseColumn(Map<String, Object> properties) {
        String json = null;
        try {

            json = objectMapper.writeValueAsString(properties);
        } catch (final JsonProcessingException e) {
            log.error("JSON writing error", e);
        }

        return json;
    }

    @Override
    public Map<String, Object> convertToEntityAttribute(String json) {
        Map<String, Object> properties = null;
        if (json != null) {
            try {
                properties = objectMapper.readValue(json,
                    new TypeReference<HashMap<String, Object>>() {
                    });
            } catch (final IOException e) {
                log.error("JSON reading error", e);
            }
        }

        return properties;
    }
}