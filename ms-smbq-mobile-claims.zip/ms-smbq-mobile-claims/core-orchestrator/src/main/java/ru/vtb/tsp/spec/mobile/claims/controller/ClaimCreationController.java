package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimCreationRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.ClaimCreationResponse;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;
import ru.vtb.tsp.spec.mobile.claims.service.ClaimService;

@Api(value = "Claim creation controller", tags = "claim-creation-controller")
@RestController
@RequestMapping("${api-v1.root}/mobile/claims")
@RequiredArgsConstructor
public class ClaimCreationController {

    private final ClaimService claimService;

    @PostMapping
    @Logging
    @ApiOperation("Отправка и создание заявки")
    @ResponseStatus(value = HttpStatus.CREATED)
    public ClaimCreationResponse create(@RequestHeader HttpHeaders headers,
                                        @RequestBody ClaimCreationRequest request) {
        return claimService.create(headers, request);
    }

}
