package ru.vtb.tsp.spec.mobile.claims.dto.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

import java.util.List;

@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantRequest {

    private String mdmCode;

    private String nameRus;

    private String inn;

    private String kpp;

    private String ogrn;

    private String okved;

    private String okpo;

    private String okato;

    private String opf;

    private List<String> phoneCollection;

    private List<String> emailCollection;

    private String legalAddress;

    private String factAddress;

    private Boolean isFactAndLegalEqual;

    private PersonDetailRequest headPersonDetail;

}