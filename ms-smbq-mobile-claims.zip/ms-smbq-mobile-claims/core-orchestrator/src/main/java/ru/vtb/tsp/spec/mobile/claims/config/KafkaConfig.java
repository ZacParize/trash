package ru.vtb.tsp.spec.mobile.claims.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.vtb.dev.corp.smbq.core.claims.orchestrator.infrastructure.kafka.api.dto.*;
import ru.vtb.dev.corp.smbq.core.claims.orchestrator.infrastructure.kafka.api.process.newcontract.producer.v1.ClaimRegistrationProcessV1InKafkaProducer;

import javax.annotation.Nonnull;
import java.util.UUID;

import static ru.vtb.dev.corp.smbq.core.claims.orchestrator.infrastructure.kafka.connector.process.newcontract.producer.v1.ClaimRegistrationProcessV1InKafkaProducerImpl.PRODUCER_ENABLED_EXPRESSION;

@Slf4j
@Configuration
public class KafkaConfig {

  @Bean
  @ConditionalOnExpression("!(" + PRODUCER_ENABLED_EXPRESSION + ")")
  public ClaimRegistrationProcessV1InKafkaProducer claimRegistrationProcessV1InKafkaProducerStub() {
    return new ClaimRegistrationProcessV1InKafkaProducerStub();
  }

  public static class ClaimRegistrationProcessV1InKafkaProducerStub implements
      ClaimRegistrationProcessV1InKafkaProducer {

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewContractRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimEcomNewContractRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewContractReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimEcomNewContractReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewTstRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewTstReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewEquipmentRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosNewEquipmentReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimAttachEquipmentToQpsContractRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimAttachEquipmentToQpsContractReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosChangeBankDetailsRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimPosChangeBankDetailsReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimEcomChangeBankDetailsRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimEcomChangeBankDetailsReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimPosChangeFinancialConditionsRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimPosChangeFinancialConditionsReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimEcomChangeFinancialConditionsRegistrationEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimEcomChangeFinancialConditionsReworkCompletedEventV1InKafkaDto event) {
      log.debug("BAD EVENT");
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosChangeTstRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosChangeTstReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimEcomChangeTstRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimEcomChangeTstReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimCanceledEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosChangeEquipmentRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimPosChangeEquipmentReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimBlockEquipmentEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimUnblockEquipmentEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimDirectDebitAgreementRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimDirectDebitAgreementReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimChangeMerchantNamesRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimChangeMerchantNamesReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimChangeMerchantCabinetRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimChangeMerchantCabinetReworkCompletedEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(@Nonnull ClaimAttachTstToQpsContractRegistrationEventV1InKafkaDto event) {
      return null;
    }

    @Override
    public UUID sendEvent(
        @Nonnull ClaimAttachTstToQpsContractReworkCompletedEventV1InKafkaDto event) {
      return null;
    }
  }

}
