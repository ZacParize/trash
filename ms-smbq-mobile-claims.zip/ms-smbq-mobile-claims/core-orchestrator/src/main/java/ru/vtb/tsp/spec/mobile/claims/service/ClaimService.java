package ru.vtb.tsp.spec.mobile.claims.service;

import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.dto.request.ClaimCreationRequest;
import ru.vtb.tsp.spec.mobile.claims.dto.response.ClaimCreationResponse;

public interface ClaimService {

    ClaimCreationResponse create(HttpHeaders headers, ClaimCreationRequest request);

}
