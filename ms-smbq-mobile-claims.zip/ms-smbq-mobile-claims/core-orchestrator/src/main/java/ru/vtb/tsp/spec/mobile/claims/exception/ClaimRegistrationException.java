package ru.vtb.tsp.spec.mobile.claims.exception;

public class ClaimRegistrationException extends RuntimeException {

  public ClaimRegistrationException(String errorMessage) {
    super(errorMessage);
  }

}