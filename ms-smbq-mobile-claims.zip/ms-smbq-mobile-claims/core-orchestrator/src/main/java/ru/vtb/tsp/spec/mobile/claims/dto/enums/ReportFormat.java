package ru.vtb.tsp.spec.mobile.claims.dto.enums;

public enum ReportFormat {

    CSV, TXT, XLSX

}
