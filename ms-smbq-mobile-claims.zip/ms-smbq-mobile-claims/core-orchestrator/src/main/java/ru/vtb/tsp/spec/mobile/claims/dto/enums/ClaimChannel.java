package ru.vtb.tsp.spec.mobile.claims.dto.enums;

public enum ClaimChannel {

    KAP,
    OPEN_API,
    IB,
    MB,
    FRKK

}
