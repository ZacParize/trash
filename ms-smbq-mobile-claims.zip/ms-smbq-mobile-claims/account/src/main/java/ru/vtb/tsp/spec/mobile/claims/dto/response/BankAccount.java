package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BankAccount implements Serializable {

  @JsonProperty("accountNumber")
  private String accountNumber;

  @JsonProperty("status")
  private String status;

  @JsonProperty("isActive")
  private String isActive;

  @JsonProperty("currency")
  private String currency;

  @JsonProperty("departmentName")
  private String departmentName;

  private String departmentBic;

  @JsonProperty("correspondentNumber")
  private String correspondentNumber;

  private SourceSystem sourceSystem;
}