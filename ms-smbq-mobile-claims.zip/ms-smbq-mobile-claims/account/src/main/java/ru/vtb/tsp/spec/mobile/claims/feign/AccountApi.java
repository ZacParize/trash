package ru.vtb.tsp.spec.mobile.claims.feign;

import java.util.List;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.vtb.tsp.spec.mobile.claims.common.config.LogFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.common.config.SslFeignConfiguration;
import ru.vtb.tsp.spec.mobile.claims.dto.response.Account;

@FeignClient(name = "ppAccounts", url = "${pp-account.url}",
    configuration = {LogFeignConfiguration.class, SslFeignConfiguration.class})
public interface AccountApi {

  @GetMapping(value = "/accounts", produces = "application/json", consumes = "application/json")
  List<Account> account(@RequestParam String mdmCode, @RequestParam int status,
                        @RequestParam boolean isActive);

}
