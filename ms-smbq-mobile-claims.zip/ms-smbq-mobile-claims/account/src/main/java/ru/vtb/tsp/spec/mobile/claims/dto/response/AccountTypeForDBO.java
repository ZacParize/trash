package ru.vtb.tsp.spec.mobile.claims.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AccountTypeForDBO {

  private String accountTypeCode;

  private String accountTypeName;
}
