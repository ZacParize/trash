package ru.vtb.tsp.spec.mobile.claims.service.impl;

import java.util.List;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.spec.mobile.claims.dto.response.BankAccountResponse;
import ru.vtb.tsp.spec.mobile.claims.service.AccountService;


@Service
@Profile("account_stub")
public class AccountServiceStub implements AccountService {

  @Override
  public BankAccountResponse getAccounts(HttpHeaders httpHeaders) {
    return BankAccountResponse.builder()
        .accounts(List.of("40523810500285271296"))
        .build();
  }
}
