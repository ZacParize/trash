package ru.vtb.tsp.spec.mobile.claims.service;

import org.springframework.http.HttpHeaders;
import ru.vtb.tsp.spec.mobile.claims.dto.response.BankAccountResponse;

/**
 * Сервис для получения информации о счетах клиента
 */
public interface AccountService {

  BankAccountResponse getAccounts(HttpHeaders httpHeaders) ;

}
