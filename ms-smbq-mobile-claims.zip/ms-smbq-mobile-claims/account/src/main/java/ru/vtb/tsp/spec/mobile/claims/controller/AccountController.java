package ru.vtb.tsp.spec.mobile.claims.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.dto.response.BankAccountResponse;
import ru.vtb.tsp.spec.mobile.claims.service.AccountService;
import ru.vtb.tsp.spec.mobile.claims.interceptor.Logging;

@RestController
@RequestMapping("${api-v1.root}/accounts")
@RequiredArgsConstructor
@Api(value = "Account controller", tags = "account-controller")
public class AccountController {

    private final AccountService accountService;

    @GetMapping
    @ApiOperation(value = "Получение списка расчетных счетов клиента")
    @Logging
    public BankAccountResponse accounts(@RequestHeader HttpHeaders httpHeaders) {
        return accountService.getAccounts(httpHeaders);
    }

}
