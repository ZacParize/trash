package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Branch {

  private String departmentIKSID;

  private String departmentRefCode;

  private String departmentName;

  private String departmentBIC;

  private String correspondentNumber;

}
