package ru.vtb.tsp.spec.mobile.claims.dto.response;

public enum SourceSystemCode {

  CFT,
  MBANK
}
