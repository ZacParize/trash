package ru.vtb.tsp.spec.mobile.claims.exception;

public class AccountNotFoundException extends RuntimeException {

  public AccountNotFoundException(String errorMessage) {
    super(errorMessage);
  }

}