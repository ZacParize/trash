package ru.vtb.tsp.spec.mobile.claims.dto.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class Account {

  private String accountNumber;

  private String accountBalanceNum;

  private String accountId;

  private SourceSystem sourceSystem;

  private String mdmCode;

  private String fullName;

  private String opened;

  private String closed;

  private String status;

  private Department department;

  private Branch branch;

  private String lastMoveDate;

  private String isActive;

  private String currency;

  private AccountTypeForDBO accountTypeForDBO;

}
