package ru.vtb.tsp.spec.mobile.claims.service.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.tsp.spec.mobile.claims.dto.response.Account;
import ru.vtb.tsp.spec.mobile.claims.dto.response.BankAccountResponse;
import ru.vtb.tsp.spec.mobile.claims.exception.AccountNotFoundException;
import ru.vtb.tsp.spec.mobile.claims.feign.AccountApi;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationService;
import ru.vtb.tsp.spec.mobile.claims.service.AccountService;
import ru.vtb.tsp.spec.mobile.claims.session.service.SessionService;

import javax.persistence.EntityNotFoundException;
import java.util.stream.Collectors;

@Profile("!account_stub")
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountServiceImpl implements AccountService, CheckIntegrationService {

  private static final int ACTIVE_STATUS = 1;
  private static final String INTEGRATION_NAME = "Сервис счетов";
  private static final int VALID_ACCOUNT_SIZE = 20;

  private final AccountApi accountApi;

  private final SessionService sessionService;

  @Override
  public BankAccountResponse getAccounts(HttpHeaders httpHeaders) {
    String mdmCode = sessionService.getSessionData(httpHeaders).getMdmCode();
    log.debug("Searching accounts for mdm: {}", mdmCode);
    try {
      var accounts = accountApi.account(mdmCode, ACTIVE_STATUS, false)
          .stream()
          .map(Account::getAccountNumber)
          .filter(accountNumber -> accountNumber.length() == VALID_ACCOUNT_SIZE)
          .collect(Collectors.toList());
      if (CollectionUtils.isEmpty(accounts)) {
        throw new AccountNotFoundException("Account not found for mdm: " + mdmCode);
      }

      return BankAccountResponse.builder()
          .accounts(accounts)
          .build();
    } catch (Exception e) {
      log.error(ExceptionUtils.getStackTrace(e));
      throw new AccountNotFoundException("Account not found for mdm: " + mdmCode);
    }
  }

  @Override
  public EndpointCheckDto checkEndpoint() {
    accountApi.account("123456", ACTIVE_STATUS, false);
    return EndpointCheckDto.builder()
        .status(HttpStatus.OK.name())
        .build();
  }

  @Override
  public String getIntegrationName() {
    return INTEGRATION_NAME;
  }
}
