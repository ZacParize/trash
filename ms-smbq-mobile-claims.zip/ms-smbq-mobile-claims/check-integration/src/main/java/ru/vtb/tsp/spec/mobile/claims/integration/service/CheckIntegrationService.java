package ru.vtb.tsp.spec.mobile.claims.integration.service;


import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;

public interface CheckIntegrationService {

  default boolean isCheckAvailable() {
    return true;
  }

  EndpointCheckDto checkEndpoint();

  String getIntegrationName();
  // TODO rewrite
}