package ru.vtb.tsp.spec.mobile.claims.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckIntegrationMainResultDto {

    private String checkTime;

    private CheckIntegrationStatus commonCheckStatus;

    private List<CheckIntegrationInfoDto> integrationStates;

}
