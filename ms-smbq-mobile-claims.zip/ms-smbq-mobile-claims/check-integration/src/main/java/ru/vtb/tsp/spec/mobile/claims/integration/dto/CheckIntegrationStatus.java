package ru.vtb.tsp.spec.mobile.claims.integration.dto;

public enum CheckIntegrationStatus {

  SUCCESS,
  ERROR;
}
