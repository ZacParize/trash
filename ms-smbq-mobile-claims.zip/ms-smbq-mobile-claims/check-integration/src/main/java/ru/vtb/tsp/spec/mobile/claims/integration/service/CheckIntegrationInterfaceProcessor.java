package ru.vtb.tsp.spec.mobile.claims.integration.service;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.aop.framework.AopProxyUtils;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Field;
import java.util.HashMap;

/**
 * Процессор для обработки интерфейса проверки интеграций
 */
@Component
@AllArgsConstructor
@Slf4j
public class CheckIntegrationInterfaceProcessor implements BeanPostProcessor {

  private final ConfigurableListableBeanFactory configurableBeanFactory;

  @Override
  public Object postProcessBeforeInitialization(Object bean, String beanName)
      throws BeansException {
    return bean;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
    scanInterfaces(bean, beanName);
    return bean;
  }

  protected void scanInterfaces(Object bean, String beanName) {
    this.configureFieldInjection(bean, beanName);
  }

  private void configureFieldInjection(Object bean, String beanName) {
    Class<?> unwrappedBeanClass =
        AopUtils.isAopProxy(bean) ? AopProxyUtils.ultimateTargetClass(bean)
            //на случай, если у бина есть прокси
            : bean.getClass();
    if (!CheckIntegrationService.class.isAssignableFrom(unwrappedBeanClass)) {
      return;
    }

    CheckIntegrationService integration = (CheckIntegrationService) bean;

    // найти checkIntegrationProcessor
    CheckIntegrationProcessor checkIntegrationProcessor = configurableBeanFactory.getBean(
        CheckIntegrationProcessor.class);
    if (AopUtils.isAopProxy(checkIntegrationProcessor)) {
      checkIntegrationProcessor = (CheckIntegrationProcessor) AopProxyUtils.getSingletonTarget(
          checkIntegrationProcessor);
    }
    assert checkIntegrationProcessor != null;
    // найти поле "integrations" в checkIntegrationProcessor
    Field commandsField = ReflectionUtils.findField(checkIntegrationProcessor.getClass(),
        "integrations");
    if (commandsField == null) {
      throw new IllegalStateException(
          String.format("unable to find 'integrations' field in the bean %s",
              checkIntegrationProcessor));
    }
    ReflectionUtils.makeAccessible(commandsField);
    HashMap<String, CheckIntegrationService> integrationsMap;
    try {
      integrationsMap = (HashMap<String, CheckIntegrationService>) commandsField.get(
          checkIntegrationProcessor);
    } catch (IllegalAccessException e) {
      throw new IllegalStateException(e);
    }

    // добавить в поле "validators"
    integrationsMap.put(beanName, integration);
    log.debug("CheckIntegrationService bean '{}' added to checkIntegrationProcessor {}", beanName,
        checkIntegrationProcessor);
  }
}
