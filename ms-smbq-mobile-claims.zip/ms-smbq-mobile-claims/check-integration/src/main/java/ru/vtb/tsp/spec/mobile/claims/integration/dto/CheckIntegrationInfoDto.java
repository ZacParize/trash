package ru.vtb.tsp.spec.mobile.claims.integration.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CheckIntegrationInfoDto {

  private String integrationName;

  private CheckIntegrationStatus status;

  private String errors;
}
