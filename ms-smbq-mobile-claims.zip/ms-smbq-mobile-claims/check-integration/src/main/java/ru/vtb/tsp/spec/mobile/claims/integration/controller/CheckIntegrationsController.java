package ru.vtb.tsp.spec.mobile.claims.integration.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckIntegrationMainResultDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationProcessor;

/**
 * Контроллер для проверок интеграции
 */

@RestController
@RequestMapping("${api-v1.root}/integrations")
@RequiredArgsConstructor
@Api(value = "Check integrations controller", tags = "check-integrations-controller")
public class CheckIntegrationsController {

  private final CheckIntegrationProcessor processor;

  @ApiOperation(value = "Получить результаты проверок на доступность сервисов для интеграции")
  @GetMapping
  public CheckIntegrationMainResultDto getIntegrationCheckStatuses() {
    return processor.checkEndpoints();
  }
}
