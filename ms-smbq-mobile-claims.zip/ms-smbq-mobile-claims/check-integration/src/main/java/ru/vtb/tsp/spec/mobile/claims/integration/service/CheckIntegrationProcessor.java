package ru.vtb.tsp.spec.mobile.claims.integration.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.ResourceAccessException;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckCodeResponse;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckIntegrationInfoDto;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckIntegrationMainResultDto;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckIntegrationStatus;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.EndpointCheckDto;

import javax.net.ssl.SSLException;
import java.net.ConnectException;
import java.security.SignatureException;
import java.security.cert.CertPathValidatorException;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckCodeResponse.CONNECTION_REFUSED;
import static ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckCodeResponse.NO_CONNECT;
import static ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckCodeResponse.PKIX;
import static ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckCodeResponse.UNDEFINED;

@Service
@Slf4j
public class CheckIntegrationProcessor {

  private final Map<String, CheckIntegrationService> integrations = new HashMap<>();

  public CheckIntegrationMainResultDto checkEndpoints() {

    List<CheckIntegrationInfoDto> integrationStates = new ArrayList<>();
    if (CollectionUtils.isEmpty(integrations)) {
      return new CheckIntegrationMainResultDto();
    }

    CheckIntegrationStatus commonCheckStatus = CheckIntegrationStatus.SUCCESS;
    for (Map.Entry<String, CheckIntegrationService> integration : integrations.entrySet()) {
      if (!integration.getValue().isCheckAvailable()) {
        continue;
      }
      EndpointCheckDto endpointCheckDto;
      try {
        endpointCheckDto = integration.getValue().checkEndpoint();
      } catch (Exception e) {
        endpointCheckDto = constructEndpointCheckDto(e);
      }
      var status = isSuccessApiCheck(endpointCheckDto) ?
          CheckIntegrationStatus.SUCCESS : CheckIntegrationStatus.ERROR;
      if (CheckIntegrationStatus.ERROR == status) {
        commonCheckStatus = status;
      }
      integrationStates.add(new CheckIntegrationInfoDto(integration.getKey(), status,
          endpointCheckDto.getErrorMessage()));
    }

    return new CheckIntegrationMainResultDto(LocalDateTime.now().toString(), commonCheckStatus, integrationStates);
  }

  private EndpointCheckDto constructEndpointCheckDto(Exception ex) {
    if (ex instanceof HttpClientErrorException) {
      return EndpointCheckDto.builder()
          .status(((HttpClientErrorException) ex).getStatusCode().name())
          .errorMessage(((HttpClientErrorException) ex).getMessage())
          .build();
    }

    var cause = ex.getCause();
    if (cause instanceof SSLException || cause instanceof CertPathValidatorException
        || cause instanceof CertificateException || cause instanceof SignatureException) {
      return constructEndpointCheckDto(PKIX, ex);
    }
    if (cause instanceof ConnectException) {
      return constructEndpointCheckDto(CONNECTION_REFUSED, ex);
    }
    if (cause instanceof ResourceAccessException) {
      return constructEndpointCheckDto(NO_CONNECT, ex);
    }

    return constructEndpointCheckDto(UNDEFINED, ex);
  }

  private EndpointCheckDto constructEndpointCheckDto(CheckCodeResponse codeResponse, Exception ex) {
    return EndpointCheckDto.builder()
        .status(codeResponse.name())
        .errorMessage(ex.getMessage())
        .build();
  }

  private boolean isSuccessApiCheck(EndpointCheckDto apiCheckResult) {
    return Optional.ofNullable(apiCheckResult)
        .map(EndpointCheckDto::getStatus)
        .stream()
        .anyMatch(httpStatus ->
            httpStatus.equals(HttpStatus.OK.name())
                || httpStatus.equals(HttpStatus.ACCEPTED.name())
                || httpStatus.equals(HttpStatus.NO_CONTENT.name())
                || httpStatus.equals(HttpStatus.METHOD_NOT_ALLOWED.name())
                || httpStatus.equals(HttpStatus.UNSUPPORTED_MEDIA_TYPE.name())
                || httpStatus.equals(HttpStatus.UNAUTHORIZED.name())
        );
  }
}
