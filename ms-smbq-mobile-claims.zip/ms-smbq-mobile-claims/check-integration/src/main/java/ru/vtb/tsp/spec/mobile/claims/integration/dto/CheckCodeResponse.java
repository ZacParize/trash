package ru.vtb.tsp.spec.mobile.claims.integration.dto;

public enum CheckCodeResponse {
  CONNECTION_REFUSED,
  NO_CONNECT,
  PKIX,
  UNDEFINED
}