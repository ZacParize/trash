package ru.vtb.tsp.spec.mobile.claims.integration.dto;

import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
public class EndpointCheckDto {

  String status;
  String errorMessage;
}