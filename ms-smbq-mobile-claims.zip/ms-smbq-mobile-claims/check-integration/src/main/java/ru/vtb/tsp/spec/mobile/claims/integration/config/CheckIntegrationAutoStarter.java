package ru.vtb.tsp.spec.mobile.claims.integration.config;

import java.util.List;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.spec.mobile.claims.integration.dto.CheckIntegrationInfoDto;
import ru.vtb.tsp.spec.mobile.claims.integration.service.CheckIntegrationProcessor;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "integration.check.enabled", havingValue = "true")
public class CheckIntegrationAutoStarter {

  private final CheckIntegrationProcessor processor;

  @EventListener(ApplicationReadyEvent.class)
  public void check() {
    List<CheckIntegrationInfoDto> statuses = processor.checkEndpoints().getIntegrationStates();
    log.info("Check integrations starting....");
    statuses.forEach(
        infoDto -> log.info(" {} - {}", infoDto.getIntegrationName(), infoDto.getStatus()));
    log.info("Check integrations finished.");
  }
}