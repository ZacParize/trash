# TSPSPEC microservice.

# Back

Условия для сборки

```
Установить:
Maven 3.8.4
Java 17.
Добавить в Path Variables JAVA_HOME, MAVEN_HOME. 
```

---

### Code of conduct

[CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md)

---

### Настройки nexus

Скопировать [settings.xml](m2-settings/settings.xml)
и [settings-security.xml](m2-settings/settings-security.xml) в `C:\Users\ИМЯ_ПОЛЬЗОВАТЕЛЯ\.m2 `   
В скопированном `settings.xml` заменить `VTB_ID` и `VTB_PASSWORD`,  
в `settings-security.xml` заменить `KEY`.

---

### Добавление сертификатов в trustStore

Предварительно разместить сертификаты в `D:\certs`

```
keytool -import -file "D:\certs\MSK-CA-inter.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias msk-ca-inter
keytool -import -file "D:\certs\MSK-CA-root.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias msk-ca-root
keytool -import -file "D:\certs\VTB Group CA 1.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-ca-1
keytool -import -file "D:\certs\VTB Group CA 2.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-ca-2
keytool -import -file "D:\certs\VTB Group CA 3.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-ca-3
keytool -import -file "D:\certs\VTB Group CA 5.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-ca-5
keytool -import -file "D:\certs\VTB Group DSO CA 7 base64.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-dso-ca-7
keytool -import -file "D:\certs\VTB Group Root CA.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-root-ca
keytool -import -file "D:\certs\VTB Group VTB24 CA 8.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-group-vtb24-ca-8
keytool -import -file "D:\certs\VTB Root CA.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-root-ca
keytool -import -file "D:\certs\VTB Subordinate CA 1.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-subordinate-ca-1
keytool -import -file "D:\certs\VTB Subordinate CA 2.cer" -trustcacerts -cacerts -noprompt  -storepass "changeit" -alias vtb-subordinate-ca-2
```

---

### Сборка:

```
В IDE добавить VM option: 
--add-opens=java.base/java.lang=ALL-UNNAMED
(Application-> Edit Configurations -> Modify Options -> Add VM Options -> VM options)

Выполнить
- mvn clean install -U --fail-at-end -DskipTests
```

---	

### Изменение активного виджета

Для того чтобы бэк поменял виджет, изменить строку
в [SessionServiceStub](session-data-integration/src/main/java/ru/vtb/tsp/spec/session/service/impl/SessionServiceStub.java):

    frkkProcessInfo.setFrkkSessionName();

допустимые значения находятся справа от этой строки.

---

### Troubleshooting

Не запускается проект:

1) Выполнить команду mvn clean install -U --fail-at-end -DskipTests
2) Shift + Shift -> Reload all maven projects
3) File -> Invalidate Caches -> Invalidate all caches and restart
4) Build -> Rebuild project

=====================================================

# Front

Условия для сборки

```
npm 6.14.12
nodejs v14.16.1
```

---

В .env.dev добавить строки

```
buildTarget = http://localhost:9000/
PUBLIC_URL = http://localhost:8081/api/smbq/spec
```

---

### Troubleshooting

Если ошибка при сборке проекта в npm c C++ -
https://stackoverflow.com/a/59882818/14308420

=====================================================  
P.C

http://localhost:8081/api/smbq/spec/swagger-ui/index.html - Сваггер бэка локально

http://localhost:8081/api/smbq/spec/camunda/app/admin/default/#/ - Camunda UI

http://localhost:8081/api/smbq/spec/engine-rest Camunda REST API

http://localhost:8083/api/smbq-pdf/swagger-ui.html - Swagger PDF(если запущен)

=====

### Запуск локально сборки из Teamcity в Docker

------

- В Teamcity выбрать нужную сборку и перейти по `ссылке` в `столбце Build number`.
- Во вкладке `Docker Info` скопировать команду на загрузку образа в столбце `Docker pull`
- Команда будет следующего вида `docker pull smbq-docker-snapshot.nexus-ci.corp.dev.vtb/ms-smbq-spec@sha256:51bc91b454ba813fe6e91879f121f7e57500ac8cf6fcb916ce282df6bba6c720`  
Из нее копируем `ms-smbq-spec@sha256:51bc91b454ba813fe6e91879f121f7e57500ac8cf6fcb916ce282df6bba6c720`  
  и сохраняем в переменную `SPEC_IMAGE` файла `.env`  
 Если базовый `URL` отличен от `smbq-docker-snapshot.nexus-ci.corp.dev.vtb` прописываем его в `BASE_URL`      
- Так же в `.env` прописываем USER, PASSWORD для доступа в `nexus`  
- В `PROCESS_NAME` прописываем `frkkName` нужного процесса
- Из терминала в корне проекта запускаем `./docker-compose.sh` 

------