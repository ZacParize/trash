package sprint8

private fun readStr() = readln()

private fun main() {
    var s = readStr()
    val n = s.length
    val pi = IntArray(n) { 0 }
    for (i in 1..n) {
        // i — длина подстроки-префикса.
        val substring = s.substring(0, i)
        // Проверяем, перекрывается ли подстрока substring с собой по k символам.
        for (k in i - 1 downTo 1) {
            // Для этого сравним префикс и суффикс соответствующих длин.
            val prefix = substring.substring(0, k)
            val suffix = substring.substring(i - k, i)
            if (prefix == suffix) {
                pi[i - 1] = k
                break
            }
        }
    }
    println(pi.joinToString(separator = " "))
}