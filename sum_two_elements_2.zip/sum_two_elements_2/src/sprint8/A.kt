package sprint8

private fun readStr() = readln()

private fun main() {
    val str = readStr()
    val strings = str.split(" ")
    val inLength = str.length
    val newStr = StringBuffer(inLength)
    for (idx in strings.size - 1 downTo 0) {
        for (char in strings[idx]) {
            newStr.append(char)
        }
        if (newStr.length != inLength) {
            newStr.append(' ')
        }
    }
    println(newStr)
}