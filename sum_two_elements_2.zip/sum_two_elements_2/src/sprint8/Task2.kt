// https://contest.yandex.ru/contest/26133/run-report/111107274/
// Реализация префиксного дерева
// TN - длина текста, K - кол-во слов длины N
// Получаем, что при заполнение дерева каждым словом происходит за O(N), причем таких слов K
// Далее, мы линейно проходим по тексту и проверяем в префиксном дереве наличие слов
// Таким образом, временная сложность будет O(N * K + TN)
// Так как мы храним только само префиксное дерево, пространственная сложность O(N * K)

package sprint8

private typealias PrefixMap = HashMap<Char, Node>

private data class Node(var isEnding: Boolean) {
    val tree = PrefixMap()
}

private const val SUCCESS = "YES"
private const val FAIL = "NO"

private fun find(nodes: MutableList<Node>, char: Char): Pair<MutableList<Node>, Boolean> {
    val result = mutableListOf<Node>()
    var isEnding = false
    for (node in nodes) {
        if (!isEnding && node.isEnding) {
            isEnding = true
        }
        if (node.tree.containsKey(char)) {
            result.add(node.tree[char]!!)
        }
    }
    return Pair(result, isEnding)
}

private fun add(root: Node, word: String) {
    var currentNode = root
    for (char in word) {
        currentNode = currentNode.tree.getOrPut(char) { Node(false) }
    }
    currentNode.isEnding = true
}

private fun check(text: String, rootNode: Node): Boolean {
    var previousNodes = mutableListOf(rootNode.tree.getOrDefault(text[0], Node(false)))
    for (idx in 1 until text.length) {
        val char = text[idx]
        val (nodes, isEnding) = find(previousNodes, char)
        previousNodes = nodes
        if (isEnding && rootNode.tree.containsKey(char)) {
            previousNodes += rootNode.tree[char]!!
        }
    }
    // Илья, про динамический подход и булево значения понимаю
    // Но ведь мы двигаемся по дереву в поиске очередного значения и нам нужны ноды, чтобы сохранять текущее положение
    // Не понимаю, как без нод... Извиняюсь
    return previousNodes.any { it.isEnding }
}

fun main() {
    val text = readln()
    val wordCount = readln().toInt()
    val rootNode = Node(false)
    repeat(wordCount) {
        val word = readln()
        add(rootNode, word)
    }
    println(if (check(text, rootNode)) SUCCESS else FAIL)
}