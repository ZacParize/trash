// https://contest.yandex.ru/contest/26133/run-report/111107042/
// Пусть дано К строк
// Алгоритм работает след образом: пробегаем по каждой строке во время декомпрессии за O(N), где N - длина i - ой строки
// Далее на каждой из K строк длины N ищем префикс за O(N)
// Таким образом, получаем, что декомпрессия каждой строки O(N) и поиск префикса тоже линейный O(N)
// Всего строк K
// Получаем, что временная сложность O(N * N * K)
// Пространственная сложность O(N), так как мы распаковываем строку и сразу ищем префикс,
// то есть в момент времени T мы работаем только с 1 строкой

package sprint8

import java.util.Stack
import kotlin.math.min

private fun Char.isDigit(): Boolean {
    return this in '0'..'9'
}

private fun Char.isLetter(): Boolean {
    return this in 'a'..'z'
}

// про строку и ее длину понял
// но тогда надо переделывать весь метод под 0
private fun decompress(string: String): String {
    val stack = Stack<String>()
    var idx = 0
    var char: Char
    val currentSequence = StringBuilder()
    while (idx < string.length) {
        char = string[idx]
        if (char.isDigit()) {
            stack.push(char.toString())
            idx++
        } else {
            when (char) {
                '[' -> {
                    idx++
                }
                ']' -> {
                    var lettersForRepeat = ""
                    var tempLetters = stack.pop()
                    while (tempLetters[0].isLetter()) {
                        lettersForRepeat = tempLetters + lettersForRepeat
                        tempLetters = stack.pop()
                    }
                    currentSequence.clear()
                    val repeatCount = tempLetters.toInt()
                    repeat(repeatCount) {
                        currentSequence.append(lettersForRepeat)
                    }
                    stack.push(currentSequence.toString())
                    idx++
                }
                else -> {
                    currentSequence.clear()
                    while (idx < string.length && string[idx].isLetter()) {
                        currentSequence.append(string[idx].toString())
                        idx++
                    }
                    stack.push(currentSequence.toString())
                }
            }
        }
    }
    return stack.joinToString(separator = "")
}

fun main() {
    val wordCount = readln().toInt()
    var prefix = ""
    repeat(wordCount) {
        val inputString = readln()
        if (prefix == "") {
            prefix = decompress(inputString)
        } else {
            val word = decompress(inputString)
            // проверка нужна, тест 34
            // Сейчас цикл без этой проверки отработает корректно
            // Все дело в том, что в случае, когда префикс == слову,
            // то проверка префикса потребует O(n) вместо O(1) с этой проверкой
            if (prefix != word) {
                val minPrefixLength = min(prefix.length, word.length)
                var idx = 0
                while (idx < minPrefixLength && prefix[idx] == word[idx]) {
                    idx++
                }
                if (prefix.length > idx) {
                    prefix = word.substring(0, idx)
                }
            }
        }
    }
    println(prefix)
}