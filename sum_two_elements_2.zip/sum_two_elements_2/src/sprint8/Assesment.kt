
import java.net.Socket
import java.util.Date

/*interface Vehicle {

    fun model(): String

    fun color(): String

    fun manufacturedAt(): Date

    fun speedLimitKmPH(): Int

    fun powerKW(): Int

    companion object {

        data class DiagnosticError(val code: Int, val description: String)
    }

    fun getRemoteControl(): VehicleRemoteControlCommand

    fun getRemoteInputStreams(): Set<CarCommandInputStream<T>>

}

interface VehicleRemoteControlCommand {

    fun getIgnitionOnCommand(): ByteArray

    fun getIgnitionOffCommand(): ByteArray

    fun getSelfCheckCommand(): ByteArray

}

interface VehicleRemoteControl {

    fun ignitionOn(): Boolean

    fun ignitionOff(): Boolean

    fun selfCheck(): Set<Vehicle.Companion.DiagnosticError>
}

interface CarCommandInputStream<T> {

    fun send(command: T): Boolean

}

class CANVehicleRemoteControl(private val vehicle: Vehicle) : VehicleRemoteControl {

    override fun ignitionOn(): Boolean {
        vehicle.getRemoteInputStreams().vehicle.getRemoteControl().getIgnitionOnCommand())
    }

    override fun ignitionOff(): Boolean {
        stream.write(vehicle.getRemoteControl().getIgnitionOffCommand())
    }

    override fun selfCheck(): Set<Vehicle.Companion.DiagnosticError> {
        stream.write(vehicle.getRemoteControl().getSelfCheckCommand())
    }
}*/