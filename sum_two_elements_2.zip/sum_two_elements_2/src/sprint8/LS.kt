package sprint8

private fun readStr() = readln()

private fun main() {
    var s = readStr()
    val n = s.length
    val pi = IntArray(n)
    pi[0] = 0
    for (i in 1 until n) {
        var k = pi[i - 1]
        if (k > 0 && s[k] != s[i]) {
            k = pi[k - 1]
        }
        if (s[k] == s[i]) {
            k++
        }
        pi[i] = k
    }
    println(pi.joinToString(separator = " "))
}