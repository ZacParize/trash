package sprint8

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    readInt()
    val list = readInts()
    readInt()
    val pattern = readInts()
    if (list.size < pattern.size) {
        return
    }
    val result = ArrayList<Int>()
    for (pos in 0..list.size - pattern.size) {
        var match = true
        for (offset in 0 ..pattern.size - 2) {
            if (list[pos + offset + 1] - list[pos + offset] != pattern[offset + 1] - pattern[offset]) {
                match = false
                break
            }
        }
        if (match) {
            result.add(pos + 1)
        }
    }
    println(result.joinToString(separator = " "))
}