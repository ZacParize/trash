package sprint8

import java.util.TreeMap

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()

private fun main() {
    val word = readStr()
    var totalLength = word.length
    val countOfWord = readInt()
    val map = TreeMap<Int, String>(compareBy { it })
    for (idx in 0 until countOfWord) {
        val (value, key) = readStrings()
        map[key.toInt()] = value
        totalLength += value.length
    }
    val result = StringBuffer(totalLength)
    var cursor = 0
    for (entry in map) {
        result.append(word.substring(cursor, entry.key) + entry.value)
        cursor = entry.key
        if (entry == map.lastEntry() && cursor != word.length) {
            result.append(word.substring(cursor, word.length))
        }
    }
    println(result.toString())
}