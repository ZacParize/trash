package sprint8

import kotlin.math.abs

private fun readStr() = readln()

private const val SUCCESS_VALUE = "OK"
private const val FAIL_VALUE = "FAIL"

private fun main() {
    var wordA = StringBuffer(readStr())
    var wordB = StringBuffer(readStr())
    if (abs(wordA.length - wordB.length) > 1) {
        println(FAIL_VALUE)
        return
    }
    if (wordA.length < wordB.length) {
        val temp = wordA
        wordA = wordB
        wordB = temp
    }
    var posA = 0
    var posB = 0
    var diffCount = 0
    while (posA < wordA.length && posB < wordB.length) {
        if (wordA[posA] != wordB[posB]) {
            diffCount++
            if (diffCount > 1) {
                println(FAIL_VALUE)
                return
            }
            if (posA + 1 < wordA.length && wordA[posA + 1] == wordB[posB]) {
                posA++
            } else if (posB + 1 < wordB.length && wordA[posA] == wordB[posB + 1]) {
                posB++
            } else if (posA + 1 < wordA.length && posB + 1 < wordB.length && wordA[posA + 1] == wordB[posB + 1]) {
                posA++
                posB++
            }
        }
        posA++
        posB++
    }
    if (posA <= wordA.length - 1 || posB <= wordB.length - 1) {
        diffCount++
    }
    println(if (diffCount > 1) FAIL_VALUE else SUCCESS_VALUE)
}