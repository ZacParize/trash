package sprint8

private fun readStr() = readln()

private fun main() {
    var wordA = readStr()
    var wordB = readStr()
    var newWordA = StringBuffer(wordA.length / 2 + 1)
    var newWordB = StringBuffer(wordB.length / 2 + 1)
    for (c in wordA) {
        if (c.code % 2 == 0) {
            newWordA.append(c)
        }
    }
    for (c in wordB) {
        if (c.code % 2 == 0) {
            newWordB.append(c)
        }
    }
    if (newWordA > newWordB) {
        println("1")
    } else if (newWordA < newWordB) {
        println("-1")
    } else {
        println("0")
    }
}