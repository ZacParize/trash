package sprint4

import kotlin.random.Random

private fun hashCode(string: String, a: Int, m: Int): Long {
    var hash: Long = 0
    var multipliedA: Long = 1
    for (idx in string.indices) {
        hash = (hash + string[string.length - 1 - idx].code * multipliedA) % m
        multipliedA = (multipliedA * a) % m
    }
    return hash
}

private fun randomString(length: Int): String = (1..length)
    .map { Random.nextInt('a'.code, 'z'.code).let { it.toChar() } }
    .joinToString("")

fun main() {
    val a = 1000
    val m = 123_987_123
    val map: HashMap<Long, String> = HashMap(1000)
    while (true) {
        val example = randomString(23)
        val hash = hashCode(example, a, m)
        if (map.contains(hash)) {
            println(example)
            println(map[hash])
            return
        } else {
            map[hash] = example
        }
    }
}