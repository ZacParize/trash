package sprint4

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private data class Sum(val a1: Int, val a2: Int, val a3: Int, val a4: Int) {
    override fun toString(): String {
        return "$a1 $a2 $a3 $a4"
    }
}

fun main() {
    val arraySize = readInt()
    val target = readInt().toLong()
    if (arraySize < 4) {
        println("0")
        return
    }
    var array = readInts()
    array = array.sorted()
    val result = LinkedHashSet<Sum>()
    for (i in 0 until array.size - 3) {
        if (i > 0 && array[i] == array[i - 1]) {
            continue
        }
        for (j in i + 1 until array.size - 2) {
            if (j > i + 1 && array[j] == array[j - 1]) {
                continue
            }
            var k = j + 1
            var l = array.size - 1
            while (k < l) {
                val sum: Long = array[i].toLong() + array[j] + array[k] + array[l]
                if (sum == target) {
                    result.add(Sum(array[i], array[j], array[k], array[l]))
                    k++
                    l--
                    while (k < l && array[k] == array[k - 1]) {
                        k++
                    }
                    while (k < l && array[l] == array[l + 1]) {
                        l--
                    }
                } else if (sum < target) {
                    k++
                } else {
                    l--
                }
            }
        }
    }

    println(result.size.toString())
    println(result.joinToString("\n"))
}