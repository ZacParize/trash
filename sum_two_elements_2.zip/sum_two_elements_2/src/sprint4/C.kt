package sprint4

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private fun warmHashes(string: String, a: Int, m: Int): LongArray {
    val hashes = LongArray(string.length)
    var hash = 0L
    for (idx in string.indices) {
        hash = (hash * a + string[idx].code) % m
        hashes[idx] = hash
    }
    return hashes
}

private fun warmDegrees(string: String, a: Int, m: Int): LongArray {
    val degrees = LongArray(string.length)
    for (idx in string.indices) {
        if (idx == 0) {
            degrees[idx] = 1
        } else {
            degrees[idx] = (degrees[idx - 1] * a) % m
        }
    }
    return degrees
}

fun main() {
    val a = readInt()
    val m = readInt()
    val inputString = readStr()
    val repeats = readInt()
    val hashes = warmHashes(inputString, a, m)
    val degrees = warmDegrees(inputString, a, m)
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    repeat(repeats) {
        val array = readInts()
        val aI = array[0]
        val bI = array[1]
        if (aI - 1 == 0) {
            outputWriter.write(hashes[bI - 1].toString() + "\n")
        } else {

            var res = hashes[bI - 1] - hashes[aI - 2] * degrees[bI - aI + 1]
            if (res < 0) {
                res %= m
                res += m
                res %= m
            }
            outputWriter.write(res.toString() + "\n")
        }
    }
    outputWriter.flush()
}