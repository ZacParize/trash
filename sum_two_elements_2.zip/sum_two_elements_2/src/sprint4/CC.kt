package sprint4


private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main() {
    var a: Int
    var m: Int
    var t: Int
    var s: String
    var arr: MutableList<String> = mutableListOf()

    a = readInt()
    m = readInt()
    s = readStr()
    t = readInt()

    for (i in 0 until t) {
        arr.add(readStr())
    }

    val res = solution(a, m, t, s, arr)
    for (i in res.indices) {
        println(res[i])
    }
}

fun solution(a: Int, m: Int, t: Int, s: String, q: List<String>): List<Int> {
    if (s.isEmpty()) {
        return listOf(0)
    }
    val degree = degreeByModule(a, m, s.length)
    val pref = prefixHash(s, a, m)
    val result = mutableListOf<Int>()
    for (i in 0 until t) {
        val arrStr = q[i].split(" ")
        val aI = arrStr[0].toInt()
        val bI = arrStr[1].toInt()
        if (aI - 1 == 0) {
            result.add(pref[bI])
        } else {
            var v = pref[bI] - pref[aI - 1] * degree[bI - aI + 1]
            if (v < 0) {
                v %= m
                v += m
                v %= m
            }
            result.add(v)
        }
    }
    return result
}

fun degreeByModule(a: Int, mod: Int, n: Int): List<Int> {
    val degrees = mutableListOf<Int>()
    degrees.add(1)
    for (i in 1..n) {
        val res = degrees[i - 1] * a
                degrees.add(res % mod)
    }
    return degrees
}

fun prefixHash(s: String, a: Int, m: Int): List<Int> {
    val pref = mutableListOf<Int>()
    pref.add(0)
    for (i in 1..s.length) {
        val res = (pref[i - 1] * a + s[i - 1].code) % m
        pref.add(res)
    }
    return pref
}