package sprint4

private fun readStr() = readln()

private fun hashCode(number: Int): Int {
    return number - 'a'.code
}

fun main() {
    val string1 = readStr()
    val string2 = readStr()

    if (string1.length != string2.length) {
        println("NO")
        return
    }

    val length = string1.length
    val dictionaryFromS1ToS2 = CharArray('z'.code - 'a'.code + 1) { ' ' }
    val dictionaryFromS2ToS1 = CharArray('z'.code - 'a'.code + 1) { ' ' }
    for (idx in 0 until length) {
        var hash = hashCode(string1[idx].code)
        if (dictionaryFromS1ToS2[hash] != ' ' && dictionaryFromS1ToS2[hash].code != string2[idx].code) {
            println("NO")
            return
        } else {
            dictionaryFromS1ToS2[hash] = string2[idx]
        }
        hash = hashCode(string2[idx].code)
        if (dictionaryFromS2ToS1[hash] != ' ' && dictionaryFromS2ToS1[hash].code != string1[idx].code) {
            println("NO")
            return
        } else {
            dictionaryFromS2ToS1[hash] = string1[idx]
        }
    }
    println("YES")
}