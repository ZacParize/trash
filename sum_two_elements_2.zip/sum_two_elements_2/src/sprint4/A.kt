package sprint4

private fun readStr() = readln()
private fun readLong() = readStr().toLong()

fun main() {
    val a = readLong()
    val m = readLong()
    val inputString = readStr()
    var hash: Long = 0
    var multipliedA: Long = 1
    for (idx in inputString.indices) {
        hash = (hash + inputString[inputString.length - 1 - idx].code * multipliedA) % m
        multipliedA = (multipliedA * a) % m
    }
    println(hash)
}