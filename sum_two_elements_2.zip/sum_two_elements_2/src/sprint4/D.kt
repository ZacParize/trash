package sprint4

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

fun main() {
    val repeatCount = readInt()
    val set = LinkedHashSet<String>()
    repeat(repeatCount) {
        set.add(readStr())
    }
    set.forEach { println( it ) }
}