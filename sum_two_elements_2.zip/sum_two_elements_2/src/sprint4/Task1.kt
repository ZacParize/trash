// https://contest.yandex.ru/contest/24414/run-report/104634072/
// Реализация поисковой системы
// Пространственная сложность O(n), где n - общее кол-во слов в поисковой системе
// Временная сложность O(kn) -> O(n) (так как n стремится к бесконечности),
// где k - общее кол-во слов в поисковом запросе (k фиксированное << n)
package sprint4

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readInt() = readString().toInt()
private fun readString() = readln()
private fun readStrings() = readString().split(" ")

private const val DEFAULT_MAX_SEARCH_LIMIT = 5

private data class SearchResult(val documentId: Int, val count: Int)

private class SearchSystem {
    private val comparator = compareByDescending<MutableMap.MutableEntry<Int, Int>> { it.value }
        .thenBy { it.key }
    private val documentIndex = mutableMapOf<String, MutableMap<Int, Int>>()

    fun add(words: List<String>, id: Int) {
        for (word in words) {
            documentIndex.getOrPut(word) { mutableMapOf() }
                .merge(id, 1) { new, old -> new + old }
        }
    }

    fun search(words: List<String>, maxSearchLimit: Int = DEFAULT_MAX_SEARCH_LIMIT): List<SearchResult> {
        val searchIndex = mutableMapOf<Int, Int>()
        val uniqueWords: MutableSet<String> = mutableSetOf()
        for (word in words) {
            if (uniqueWords.contains(word)) {
                continue
            }
            documentIndex[word]?.forEach { (key, value) ->
                searchIndex.merge(key, value) { new, old -> new + old }
            }
            uniqueWords.add(word)
        }
        val result = searchIndex.entries
        // Хороший комментарий
        // Здесь мы используем MutableSet -> будет использоваться dual pivot quick sort (стабильная)
        // Следовательно, сложность in place сортировки в среднем O(n log n), в худшем случае O(n^2)
        // Мы же можем за O(n) найти k наименьших элементов (очевидно, что k << n и при этом пространственная сложность будет k)
        // Таким образом можно еще оптимизировать алгоритм поиска
            .sortedWith(comparator)
            .map { SearchResult(it.key, it.value) }
            .toList()
        return result.take(maxSearchLimit)
    }
}

fun main() {
    val documentsCount = readInt()
    val searchSystem = SearchSystem()
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))

    for (idx in 1..documentsCount) {
        val document = readStrings()
        searchSystem.add(document, idx)
    }

    val queriesCount = readInt()

    repeat(queriesCount) {
        val words = readStrings()
        outputWriter.write(searchSystem.search(words)
            .joinToString(separator = " ",
                transform = { it.documentId.toString() },
                postfix = "\n"))
    }

    outputWriter.flush()
}