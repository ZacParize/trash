package sprint4

private fun readStr() = readln()

fun main() {
    val input = readStr()
    var maxLen = 0
    for (i in input.indices) {
        val chars = mutableSetOf<Char>()
        var j = 0
        while (j < input.length - i) {
            if (chars.contains(input[j + i])) {
                if (j > maxLen) {
                    maxLen = j
                }
                break
            }
            chars.add(input[j + i])
            j++
        }
        if (j > maxLen) {
            maxLen = j
        }
    }
    println(maxLen)
}