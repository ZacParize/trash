package sprint4

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

private fun hashCode(number: Int, mod: Int): Int {
    return (number + mod) % mod
}

fun main() {
    val repeatCount = readInt()
    if (repeatCount == 0) {
        println("0")
        return
    }
    val points = readStrings()
    val arrayOfPoints = IntArray(repeatCount + 1) { -2 }
    var currentSum = 0
    var maxSeriesLength = 0
    arrayOfPoints[hashCode(currentSum, repeatCount + 1)] = -1

    for (idx in points.indices) {

        if (points[idx] == "1") {
            currentSum += 1
        } else {
            currentSum -= 1
        }

        val hash = hashCode(currentSum, repeatCount + 1)

        if (arrayOfPoints[hash] == -2) {
            arrayOfPoints[hash] = idx
        } else {
            val temp = idx - arrayOfPoints[hash]
            if (maxSeriesLength < temp) {
                maxSeriesLength = temp
            }
        }
    }

    println(maxSeriesLength)
}