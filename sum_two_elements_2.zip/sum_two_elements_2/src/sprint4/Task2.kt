// https://contest.yandex.ru/contest/24414/run-report/104764375/
// Реализация хэш-таблицы фиксированного размера
// Сложность (худшая) поиска O(1 + N/M), где N — количество элементов, добавленных в таблицу,
// M — количество корзин в таблице
package sprint4

import java.io.OutputStreamWriter
import java.io.PrintWriter
import kotlin.math.abs

private fun readInt() = readString().toInt()
private fun readString() = readln()
private fun readStrings() = readString().split(" ")

const val NONE_MESSAGE = "None"

class FixedSizeHashTable(private val size: Int) {

    private data class Node(val key: Int, var value: Int) {
        var next: Node? = null
    }

    private data class Chain(var first: Node?,
                             var prevNode: Node?,
                             var node: Node?,
                             var last: Node?)

    private val table: Array<Node?> = arrayOfNulls(size)

    private fun hash(key: Int): Int {
        return abs(key.hashCode()) % size
    }

    fun add(key: Int, value: Int) {
        val chain = getChain(key)
        if (chain.node == null) {
            val node = Node(key, value)
            if (chain.first == null) {
                table[hash(key)] = node
            } else {
                chain.last?.next = node
            }
        } else {
            chain.node?.value = value
        }
    }

    fun delete(key: Int): Int? {
        val chain = getChain(key)
        if (chain.node == null) {
            return null
        }
        if (chain.prevNode == null) {
            table[hash(key)] = chain.node?.next
        } else {
            chain.prevNode?.next = chain.node?.next
        }
        return chain.node?.value
    }

    fun get(key: Int): Int? {
        val chain = getChain(key)
        return chain.node?.value
    }

    private fun getChain(key: Int): Chain {
        val hash = hash(key)
        if (table[hash] == null) {
            return Chain(null, null, null, null)
        }
        var node = table[hash]!!
        val result = Chain(node, null, null, null)
        var previousNode: Node? = null
        while (node.next != null && node.key != key) {
            previousNode = node
            node = node.next!!
        }
        result.prevNode = previousNode
        if (node.key == key) {
            result.node = node
        } else {
            result.last = node
        }
        return result
    }
}

fun main() {
    val commandCount = readInt()
    val outputWriter = PrintWriter(OutputStreamWriter(System.out), false)
    val table = FixedSizeHashTable(commandCount)
    repeat(commandCount) {
        val command = readStrings()
        when (command[0]) {
            "get" -> outputWriter.println(
                table.get(command[1].toInt())?.toString()?: NONE_MESSAGE)
            "delete" -> outputWriter.println(
                table.delete(command[1].toInt())?.toString()?: NONE_MESSAGE)
            else -> table.add(command[1].toInt(), command[2].toInt())
        }
    }
    outputWriter.flush()
}