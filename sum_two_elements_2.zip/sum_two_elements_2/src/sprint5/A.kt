package sprint5

class Node {
    var value: Int
    var left: Node?
    var right: Node?

    constructor(value: Int) {
        this.value = value
        right = null
        left = null
    }

    constructor(value: Int, left: Node?, right: Node?) {
        this.value = value
        this.left = left
        this.right = right
    }
}

private fun solution(head: Node?): Int {
    var result = 0

    if (head == null) {
        return result
    }

    if (head.value > result) {
        result = head.value
    }

    if (head.left != null) {
        val temp = solution(head.left)
        if (temp > result) {
            result = temp
        }
    }

    if (head.right != null) {
        val temp = solution(head.right)
        if (temp > result) {
            result = temp
        }
    }

    return result
}

private fun main() {
    val node1 = Node(1)
    val node2 = Node(-5)
    val node3 = Node(3)
    node3?.left = node1
    node3?.right = node2
    val node4 = Node(2)
    node4?.left = node3
    println(solution(node4))
    assert(solution(node4) == 3)
}