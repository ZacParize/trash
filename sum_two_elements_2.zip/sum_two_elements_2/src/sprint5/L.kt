package sprint5

private fun siftDown(heap: IntArray, idx: Int): Int {
    val left = 2 * idx
    val right = 2 * idx + 1

    // Нет дочерних узлов
    if (heap.size - 1 < left) {
        return idx
    }

    // right < heap.size проверяет, что есть оба дочерних узла
    val indexLargest = if (right < heap.size && heap[left] < heap[right]) right else left

    return if (heap[idx] < heap[indexLargest]) {
        val temp = heap[idx]
        heap[idx] = heap[indexLargest]
        heap[indexLargest] = temp
        siftDown(heap, indexLargest)
    } else {
        idx
    }
}


private fun main() {
    val sample = intArrayOf(-1, 12, 1, 8, 3, 4, 7)
    //assert(siftDown(sample, 2) == 5)
    val result = siftDown(sample, 2)
    println(result)
}