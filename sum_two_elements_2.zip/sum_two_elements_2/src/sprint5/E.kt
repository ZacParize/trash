package sprint5

private fun treeSolutionE(head: Node?): Boolean {
    return isSearchTree(head, head!!.value + 1)
}

private fun isSearchTree(node: Node?, headValue: Int): Boolean {
    node?: return true
    if (node.left == null && node.right == null) {
        return true
    }
    if (node.left == null) {
        return node.value < node.right!!.value && headValue < node.right!!.value
    }
    if (node.right == null) {
        return node.value < node.left!!.value && headValue > node.left!!.value
    }
    if (node.left!!.value >= node.value || node.right!!.value <= node.value || node.left!!.value >= node.right!!.value) {
        return false
    }
    return headValue > node.left!!.value && headValue < node.right!!.value
            && isSearchTree(node.left, node.value) && isSearchTree(node.right, node.value)
}

private fun main() {

    /*

    0 5 1 2
    1 4 3 4
    2 6 5 6
    3 2 None None
    4 6 None None
    5 4 None None
    6 8 None None

          5
      4       6
    2   6   4   8


     */
    val node1 = Node(1, null, null)
    val node2 = Node(4, null, null)
    val node3 = Node(6, null, null)
    val node4 = Node(8, null, null)
    val node6 = Node(3, node1, node2)
    val node7 = Node(8, node3, node4)
    val node5 = Node(5, node6, node7)
    println(treeSolutionE(node5))
}