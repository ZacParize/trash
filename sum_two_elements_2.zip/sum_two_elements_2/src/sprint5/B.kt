package sprint5

private fun solution(head: Node?): Boolean {
    return checkBalance(head).second
}

private fun checkBalance(head: Node?, level: Int = 0): Pair<Int, Boolean> {
    head?: return Pair(level, true)
    val (left, leftStatus) = checkBalance(head.left, level + 1)
    val (right, rightStatus) = checkBalance(head.right, level + 1)
    if (!leftStatus || !rightStatus) {
        return Pair(level, false)
    }
    if (left - right != 0) {
        return Pair(level, false)
    }
    return Pair(left, true)
}

private fun main() {
    val node1 = Node(1)
    val node2 = Node(-5)
    val node3 = Node(3)
    node3?.left = node1
    node3?.right = node2
    val node4 = Node(10)
    val node5 = Node(2)
    node5?.left = node3
    node4?.left = node5
    node4?.right = Node(1)
    //node5?.right = node4
    println(solution(node4))
    assert(solution(node4))
}