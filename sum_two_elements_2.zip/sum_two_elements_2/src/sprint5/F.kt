package sprint5

private fun treeSolution(head: Node?): Int {
    head?: return 0
    return maxOf(treeSolution(head.left) + 1, treeSolution(head.right) + 1)
}

private fun main() {
    val node1 = Node(1, null, null)
    val node2 = Node(4, null, null)
    val node3 = Node(6, null, null)
    val node4 = Node(8, null, null)
    val node6 = Node(3, node1, node2)
    val node7 = Node(8, node3, node4)
    val node5 = Node(5, node6, node7)
    println(treeSolution(node5))
}