package sprint5

private fun solution(head: Node?): Boolean {
    return if (head?.left == head?.right) {
        true
    } else if (head?.left == null || head.right == null) {
        false
    } else {
        checkLeft(head.left) == checkRight(head.right)
    }
}

fun checkLeft(node: Node?): String {
    if (node == null) {
        return ""
    }
    return checkLeft(node.left) + '|' + node.value.toString() + '|' + checkLeft(node.right)
}

fun checkRight(node: Node?): String {
    node?: return ""
    return checkRight(node.right) + '|' + node.value.toString() + '|' + checkRight(node.left)
}

private fun main() {
    val node1 = Node(3, null, null)
    val node2 = Node(4, null, null)
    val node3 = Node(4, null, null)
    val node4 = Node(3, null, null)
    val node5 = Node(2, node1, node2)
    val node6 = Node(2, node3, node4)
    val node7 = Node(1, node5, node6)
    assert(solution(node7))
}