package sprint5

private fun siftUp(heap: IntArray, idx: Int): Int {
    if (idx == 1) {
        return idx
    }

    val parentIndex = idx / 2
    return if (heap[parentIndex] < heap[idx]) {
        val temp = heap[parentIndex]
        heap[parentIndex] = heap[idx]
        heap[idx] = temp
        siftUp(heap, parentIndex)
    } else {
        idx
    }
}

fun main() {
    val sample = intArrayOf(-1, 12, 6, 8, 3, 15, 7)
    //assert(siftUp(sample, 5) == 1)
    val result = siftUp(sample, 5)
    println(result)
}