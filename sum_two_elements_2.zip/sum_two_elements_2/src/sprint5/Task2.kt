// https://contest.yandex.ru/contest/24810/run-report/106843604/
// Удаление вершины с заданным ключом из бинарного дерева
// Временная сложность O(h), где h - высота дерева (n <= h <= log(n))

package sprint5

//private class Node(var left: Node?, var right: Node?, var value: Int)

fun remove(node: Node?, key: Int): Node? {
    if (node == null) {
        return null
    }
    var current = node
    var parent: Node = current

    while (current != null) {
        if (current.value == key) {
            if (current.left == null || current.right == null) {
                val newNode = current.left ?: current.right
                if (parent == current) {
                    return newNode
                }
                if (current == parent.left) {
                    parent.left = newNode
                } else {
                    parent.right = newNode
                }
            } else {
                var tmp = current.right
                while (tmp?.left != null) {
                    parent = tmp
                    tmp = tmp.left
                }
                if (tmp != current.right) {
                    parent.left = tmp?.right
                } else {
                    current.right = tmp?.right
                }
                current.value = tmp?.value ?: current.value
            }
            break
        }
        parent = current
        current = if (current.value < key) {
            current.right
        } else {
            current.left
        }
    }

    return node
}

/*fun main() {
    val node1 = Node(null, null, 2)
    val node2 = Node(node1, null, 3)
    val node3 = Node(null, node2, 1)
    val node4 = Node(null, null, 6)
    val node5 = Node(node4, null, 8)
    val node6 = Node(node5, null, 10)
    val node7 = Node(node3, node6, 5)
    val newHead = remove(node7, 10)
    assert(newHead!!.value == 5)
    assert(newHead.right == node5)
    assert(newHead.right!!.value == 8)
}*/