// https://contest.yandex.ru/contest/24810/run-report/106606834/
// Реализация пиромидальной сортировки
// Пространственная сложность O(n) (0 элемент в массиве при n -> бесконечности не в счет)
// Временная сложность O(n log(n))

package sprint5

/*import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readInt() = readString().toInt()
private fun readString() = readln()

data class Participant(val tasks: Int, val penalties: Int, val name: String)

fun<T> MutableList<T>.swap(firstIndex:Int,
                           secondIndex:Int) {
    val temp = this[firstIndex]
    this[firstIndex] = this[secondIndex]
    this[secondIndex] = temp
}

class Heap(private val comparator: Comparator<Participant>) {
    private val array = mutableListOf(Participant(-1, -1, ""))

    fun add(participant: Participant) {
        val index = array.size
        array.add(participant)
        siftUp(index)
    }

    fun pop(): Participant {
        val lastIndex = array.size - 1
        val result = array[1]
        array[1] = array[lastIndex]
        array.removeAt(lastIndex)
        siftDown(1)
        return result
    }

    private fun siftUp(idx: Int) {
        if (idx == 1) {
            return
        }
        val parentIndex = idx / 2
        if (comparator.compare(array[parentIndex], array[idx]) > 0) {
            array.swap(parentIndex, idx)
            siftUp(parentIndex)
        }
    }

    private fun siftDown(idx: Int) {
        val left = 2 * idx
        val right = 2 * idx + 1
        // Нет дочерних узлов
        if (array.size - 1 < left) {
            return
        }
        // right < heap.size проверяет, что есть оба дочерних узла
        val indexLargest = if (right < array.size
            && comparator.compare(array[left], array[right]) > 0) right else left

        if (comparator.compare(array[idx], array[indexLargest]) > 0) {
            array.swap(idx, indexLargest)
            siftDown(indexLargest)
        }
    }

}

fun parseParticipant(string: String): Participant {
    val (name, tasks, penalties) = string.split(" ")
    return Participant(tasks.toInt(), penalties.toInt(), name)
}

fun main() {
    val participantCount = readInt()
    val comparator = compareByDescending<Participant> { it.tasks }
        .thenBy { it.penalties }
        .thenBy { it.name }
    val heap = Heap(comparator)
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    repeat(participantCount) {
        val inputString = readString()
        val participant = parseParticipant(inputString)
        heap.add(participant)
    }
    repeat(participantCount) {
        outputWriter.write(heap.pop().name + "\n")
    }
    outputWriter.flush()
}*/