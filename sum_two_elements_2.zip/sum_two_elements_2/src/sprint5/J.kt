package sprint5

fun insert(root: Node, key: Int): Node {
    if (root.value <= key) {
        root.right = if (root.right == null) Node(key) else insert(root.right!!, key)
    } else {
        root.left = if (root.left == null) Node(key) else insert(root.left!!, key)
    }
    return root
}

private fun main() {
    val node1 = Node(7, null, null)
    val node2 = Node(8, node1, null)
    val node3 = Node(7, node2, null)
    val newHead = insert(node3, 6)
    assert(newHead == node3)
    assert(newHead?.left!!.value == 6)
}