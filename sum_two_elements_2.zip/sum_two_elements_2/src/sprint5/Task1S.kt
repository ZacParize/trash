// https://contest.yandex.ru/contest/24810/run-report/106866482/
// Полностью переделал реализацию пиромидальной сортировки
// Теперь сортировка делается с помощью метода in-place в массиве
// Пространственная сложность O(n)
// Временная сложность O(n log(n))

package sprint5

private fun readInt() = readString().toInt()
private fun readString() = readln()

data class Participant(val tasks: Int, val penalties: Int, val name: String) {
    companion object {
        fun valueOf(string: String): Participant {
            val (name, tasks, penalties) = string.split(" ")
            return Participant(tasks.toInt(), penalties.toInt(), name)
        }
    }
}

private fun <T> MutableList<T>.swap(firstIndex: Int, secondIndex: Int) {
    val temp = this[firstIndex]
    this[firstIndex] = this[secondIndex]
    this[secondIndex] = temp
}

private fun <T> siftDown(array: MutableList<T>, idx: Int, lastIdx: Int, comparator: Comparator<T>) {
    if (lastIdx < 0 || lastIdx > array.size) {
        throw IndexOutOfBoundsException()
    }
    val left = 2 * idx + 1
    val right = 2 * idx + 2
    var largest = idx

    if (left < lastIdx && comparator.compare(array[left], array[largest]) > 0) largest = left
    if (right < lastIdx && comparator.compare(array[right], array[largest]) > 0) largest = right

    if (largest != idx) {
        array.swap(idx, largest)
        siftDown(array, largest, lastIdx, comparator)
    }
}

private fun <T> siftUp(array: MutableList<T>, lastIdx: Int, comparator: Comparator<T>): T {
    if (lastIdx < 0 || lastIdx > array.size) {
        throw IndexOutOfBoundsException()
    }
    val top = array[0]
    array[0] = array[lastIdx - 1]
    siftDown(array, 0, lastIdx - 1, comparator)
    return top
}

fun <T> heapSort(array: MutableList<T>, comparator: Comparator<T>) {
    var lastIdx = array.size

    var i = (lastIdx - 2) / 2
    while (i >= 0) {
        siftDown(array, i--, lastIdx, comparator)
    }

    while (lastIdx > 0) {
        array[lastIdx - 1] = siftUp(array, lastIdx, comparator)
        lastIdx--
    }
}


fun main() {
    val participantCount = readInt()
    val comparator = compareByDescending<Participant> { it.tasks }
        .thenBy { it.penalties }
        .thenBy { it.name }
    val array = ArrayList<Participant>(participantCount)
    repeat(participantCount) {
        val inputString = readString()
        array.add(Participant.valueOf(inputString))
    }
    heapSort(array, comparator)
    println(array.joinToString(transform = { it.name }, separator = "\n"))
}