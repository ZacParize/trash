package sprint5

private fun solution(head1: Node?, head2: Node?): Boolean {
    return if (head1 == head2) {
        true
    } else {
        valueOf(head1) == valueOf(head2)
    }
}

private fun valueOf(node: Node?): String {
    node?: return ""
    return valueOf(node.left) + '|' + node.value.toString() + '|' + valueOf(node.right)
}

private fun main() {
    val node1 = Node(1, null, null)
    val node2 = Node(2, null, null)
    val node3 = Node(3, node1, node2)
    val node4 = Node(1, null, null)
    val node5 = Node(2, null, null)
    val node6 = Node(3, node4, node5)
    assert(solution(node3, node6))
}