import java.util.stream.Collectors

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main(args: Array<String>) {
    val size = readInt()
    var numberOne: List<Char> = readStrings().stream().flatMap { it.toList().stream() }
        .collect(Collectors.toList()).reversed()
    var numberTwo: List<Char> = readStr().toList().reversed()
    val result = StringBuffer()
    if (numberOne.size < numberTwo.size) {
        var temp = numberOne
        numberOne = numberTwo
        numberTwo = temp
    }
    var temp: Int
    var carry = 0
    for (idx in numberOne.indices) {
        temp = numberOne[idx] - '0'
        if (idx < numberTwo.size) {
            temp += numberTwo[idx] - '0'
        }
        temp += carry
        carry = temp / 10
        temp %= 10
        if (result.isNotEmpty()) {
            result.append(" ")
        }
        result.append(temp)
    }
    if (carry > 0) {
        result.append(" $carry")
    }
    print(result.reverse())
}