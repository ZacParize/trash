package com.company;

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val size = readInt()
    val list = readInts()
    val set = list.toSet()
    val sum = readInt()
    var tempSum: Int
    for (idx in 0 until size) {
        tempSum = sum - list[idx]
        if (set.contains(tempSum) && (tempSum != list[idx]
                    || (tempSum == list[idx] && idx + 1 < size && list[idx] == list[idx + 1]))) {
            val builder = StringBuilder()
            builder.append(list[idx])
                .append(" ")
                .append(tempSum);
            print(builder.toString())
            return
        }
    }
    print("None")
}