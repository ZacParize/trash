//https://contest.yandex.ru/contest/22450/run-report/101704080/

private fun readString() = readln()
private fun readInt() = readString().toInt()
const val PLAYERS_COUNT = 2

fun main() {
    val keys = readInt()
    val keysCount = keys * PLAYERS_COUNT
    val rowCount = 4
    val symbolsCount = HashMap<Char, Int>()

    // form dictionary
    for (idx in 0 until rowCount) {
        val inputString = readString()
        for (symbol in inputString) {
            symbolsCount.merge(symbol, 1) { new, old -> new + old }
        }
    }
    // count points
    print(symbolsCount.count{ it.key.isDigit() && it.value <= keysCount })
}