package com.company

import kotlin.math.sqrt


private fun readStr() = readln()
private fun readInt() = readStr().toInt()

fun getAllFactors(n: Int): Set<Int> {
    val factors: MutableSet<Int> = HashSet()
    val step = if (n % 2 == 0) 1 else 2
    var i = 1
    val sqrtOfN = sqrt(n.toDouble())
    while (i <= sqrtOfN) {
        if (n % i == 0) {
            factors.add(i)
            factors.add(n / i)
        }
        i += step
    }
    return factors
}

fun factor(set: Set<Int>, digit: Int): List<Int> {
    var currentValue = digit
    val result = ArrayList<Int>()
    val sortedFactors = set.sorted().toList()
    for (i in sortedFactors) {
        while (currentValue != 1 && i != 1 && currentValue % i == 0) {
            result += i
            currentValue /= i
        }
    }
    return result.sorted()
}

fun main(args: Array<String>) {
    val max = readInt()
    print(factor(getAllFactors(max), max).joinToString(" "))
}