//https://contest.yandex.ru/contest/22450/run-report/101702948/

import kotlin.math.min

private fun readString() = readln()
private fun readInt() = readString().toInt()
private fun readStrings() = readString().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

/** Process end of the array
 * @param list result list
 * @param shiftFromPreviousZero shift from previous zero
 */
fun processEnd(list: MutableList<Int>, shiftFromPreviousZero: Int) {
    // current digit 0
    if (shiftFromPreviousZero == 0) {
        val lastIndex = list.size - 1
        list[lastIndex] = 0
        return
    }
    val startPosition = list.size - shiftFromPreviousZero
    for (idx in startPosition until list.size) {
        list[idx] = idx - startPosition + 1
    }
}

/** Process middle of the array
 * @param list result list
 * @param position current zero position
 * @param shiftFromPreviousZero shift from previous zero
 */
fun processMiddle(list: MutableList<Int>, position: Int, shiftFromPreviousZero: Int) {
    // first digit 0
    if (shiftFromPreviousZero == 0) {
        list[position] = 0
        return
    }
    // position in the middle of the array
    val startPosition = position - shiftFromPreviousZero
    // there was previous 0
    if (startPosition != 0) {
        for (idx in startPosition..position) {
            list[idx] = min(idx - startPosition + 1, position - idx)
        }
    // there was no previous 0
    } else {
        for (idx in 0..position) {
            list[idx] = position - idx
        }
    }
}

fun main() {
    val size = readInt()
    val housesAndPlots = readInts()
    val result = MutableList(size) { -1 }
    var shiftFromPreviousZero = 0

    for (idx in 0 until size) {
        if (housesAndPlots[idx] == 0) {
            processMiddle(result, idx, shiftFromPreviousZero)
            shiftFromPreviousZero = 0
        } else {
            shiftFromPreviousZero++
        }
    }
    processEnd(result, shiftFromPreviousZero)
    print(result.joinToString(" "))
}