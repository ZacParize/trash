package com.company

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val dayCount = readInt()
    val listOfDays = readInts()
    if (dayCount == 1) {
        println("1")
        return
    }
    var chaosDays = 0
    for (idx in listOfDays.indices) {
        if ((idx == 0 && listOfDays[0] > listOfDays[1])
            || (idx + 1 == dayCount && listOfDays[idx - 1] < listOfDays[idx])
            || (idx - 1 >= 0 && idx + 1 < dayCount && listOfDays[idx - 1] < listOfDays[idx] && listOfDays[idx] > listOfDays[idx + 1])) {
            chaosDays += 1
        }
    }
    println(chaosDays)
}