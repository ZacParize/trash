package com.company

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

fun main(args: Array<String>) {
    val digit = readInt()
    if (digit == 0) {
        print("0")
        return
    }
    val result = StringBuffer()
    var currentDigit: Int = digit
    while (currentDigit != 0) {
        result.insert(0,currentDigit % 2)
        currentDigit /= 2
    }
    print(result.toString())
}