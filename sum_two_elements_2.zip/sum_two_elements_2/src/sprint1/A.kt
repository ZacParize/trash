package com.company;

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val list = readInts()
    print(list[0] * list[1] * list[1] + list[2] * list[1] + list[3]);
}