package com.company;

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val size = readInt()
    val list = readInts()
    val sum = readInt()
    var idx = 0
    var jdx:Int = size - 1
    while (idx < jdx) {
        if (list[idx] + list[jdx] == sum) {
            val builder = StringBuilder()
            builder.append(list[idx])
                .append(" ")
                .append(list[jdx]);
            print(builder.toString())
            return
        } else if (list[idx] + list[jdx] < sum) {
            idx++
        } else if (list[idx] + list[jdx] > sum) {
            jdx--
        }
    }
    print("None")
}