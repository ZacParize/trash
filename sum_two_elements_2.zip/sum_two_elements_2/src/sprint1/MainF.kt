package com.company

private fun readStr() = readln()

private fun getNextSymbol(str: String, pos: Int, delta: Int): Int {
    var idx = pos
    while (idx < str.length && !str[idx].isLetterOrDigit()) {
        idx += delta
    }
    return idx
}

fun main() {
    val phrase = readStr()
    var lIdx = 0
    var rIdx = phrase.length - 1
    while (lIdx <= rIdx) {
        lIdx = getNextSymbol(phrase, lIdx, 1)
        rIdx = getNextSymbol(phrase, rIdx, -1)
        if (phrase[lIdx].lowercase() != phrase[rIdx].lowercase()) {
            break
        }
        lIdx += 1
        rIdx -= 1
    }
    print(if (lIdx >= rIdx) "True" else "False")
}