package com.company

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

fun closestTo4Power(digit:Int) : Int {
    if (digit == 1) {
        return 1
    }
    var currentValue = 4
    while (currentValue < digit) {
        currentValue *= 4
    }
    return currentValue
}

fun main(args: Array<String>) {
    val digit = readInt()
    val closestDigit = closestTo4Power(digit)
    print(if (digit == closestDigit) "True" else "False")
}