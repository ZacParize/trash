private fun readStr() = readln()

fun main(args: Array<String>) {
    val standard = readStr()
    val comparable = readStr()
    val delta = 'A'
    val countedList = MutableList('z' - delta + 1) { 0 }
    for (symbol in standard) {
        countedList[symbol - delta] += 1
    }
    var temp: Int
    for (symbol in comparable) {
        temp = symbol - delta
        countedList[temp] -= 1
        if (countedList[temp] == -1) {
            print((temp + delta.code).toChar())
            break
        }
    }
    print("")
}