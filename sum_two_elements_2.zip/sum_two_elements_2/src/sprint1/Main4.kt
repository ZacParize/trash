package com.company;

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val rowCount = readInt()
    val columnCount = readInt()
    val matrix = Array(rowCount) { IntArray(columnCount) }
    var listOfInts : List<Int>
    for (idx in 0 until rowCount) {
        listOfInts = readInts()
        for (jdx in 0 until columnCount) {
            matrix[idx][jdx] = listOfInts[jdx]
        }
    }
    val y = readInt()
    val x = readInt()
    val numbers : MutableList<Int> = ArrayList()
    if (y - 1 >= 0) {
        numbers += matrix[y - 1][x]
    }
    if (y + 1 < rowCount) {
        numbers += matrix[y + 1][x]
    }
    if (x - 1 >= 0) {
        numbers += matrix[y][x - 1]
    }
    if (x + 1 < columnCount ) {
        numbers += matrix[y][x + 1]
    }
    numbers.sort()
    print(numbers.joinToString(" "))
}