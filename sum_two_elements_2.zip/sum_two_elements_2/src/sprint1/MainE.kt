package com.company

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main(args: Array<String>) {
    val wordCount = readInt()
    val listOfWords = readStrings()
    var length : Int = 0
    var idx : Int = 0
    for (jdx in listOfWords.indices) {
        if (listOfWords[jdx].length > length) {
            length = listOfWords[jdx].length
            idx = jdx
        }
    }
    println(listOfWords[idx])
    print(length)
}