package com.company;

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun checkParity(number : Int) : Boolean {
    return number % 2 == 0
}

fun main(args: Array<String>) {
    val list = readInts()
    if (checkParity(list[0]) && checkParity(list[1]) && checkParity(list[2])
        || !checkParity(list[0]) && !checkParity(list[1]) && !checkParity(list[2])) {
        print("WIN")
    } else {
        print("FAIL")
    }
}