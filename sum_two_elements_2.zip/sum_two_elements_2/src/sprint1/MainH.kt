package com.company

private fun readStr() = readln()

fun sumOfTwoBinaryStrings(digitA:String, digitB: String) : String {
    var firstLength: Int = digitA.length - 1
    var secondLength: Int = digitB.length - 1
    val result = StringBuilder()
    var carry = 0
    var sum: Int
    while (firstLength >= 0 || secondLength >= 0) {
        sum = carry
        if (firstLength >= 0) {
            sum += digitA[firstLength] - '0'
            firstLength--
        }
        if (secondLength >= 0) {
            sum += digitB[secondLength] - '0'
            secondLength--
        }
        carry = sum shr 1
        sum = sum and 1
        result.append(if (sum == 0) '0' else '1')
    }
    if (carry > 0) result.append('1')
    result.reverse()
    return result.toString()
}

fun main(args: Array<String>) {
    val digitA = readStr()
    val digitB = readStr()
    print(sumOfTwoBinaryStrings(digitA, digitB))
}