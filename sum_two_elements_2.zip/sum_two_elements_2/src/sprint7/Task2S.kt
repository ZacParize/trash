// https://contest.yandex.ru/contest/25597/run-report/109860371/
// Реализация проверки разделения исходного множества на 2 подмножества с одинаковой суммой элементов
// Временная сложность O(N/2 * N) -> O(N^2/2) -> O(N^2)
// Пространственная сложность O(N + N/2 + N/2) -> O(2N)

package sprint7

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private const val SUCCESS_VALUE = "True"
private const val FAIL_VALUE = "False"

private fun checkSum(listOfDigits: List<Int>): Boolean {
    val sum = listOfDigits.sum()
    if (sum % 2 != 0) {
        return false
    }
    val halfSum = sum / 2
    var dp = IntArray(halfSum + 1)
    val tempArray = IntArray(halfSum + 1)
    for (idx in 1..listOfDigits.size) {
        tempArray.fill(0)
        for (jdx in 1..halfSum) {
            tempArray[jdx] = dp[jdx]
            if (jdx == listOfDigits[idx - 1]) {
                tempArray[jdx]++
            } else if (jdx > listOfDigits[idx - 1] && dp[jdx - listOfDigits[idx - 1]] > 0) {
                tempArray[jdx]++
            }
        }
        tempArray.copyInto(dp)
    }
    return dp[halfSum] > 1
}

fun main() {
    readStr()
    val digits = readInts()
    println(if (checkSum(digits)) SUCCESS_VALUE else FAIL_VALUE)
}