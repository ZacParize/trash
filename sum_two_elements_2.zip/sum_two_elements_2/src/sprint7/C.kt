package sprint7

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    val bagSize = readInt()
    val heapCount = readInt()
    val listOfCostAndHeap = mutableListOf<Pair<Int, Int>>()
    repeat(heapCount) {
        val (cost, heap) = readInts()
        listOfCostAndHeap.add(Pair(cost, heap))
    }
    listOfCostAndHeap.sortByDescending { it.first }
    var result = 0L
    var restOfBag: Long = bagSize.toLong()
    for (entry in listOfCostAndHeap) {
        if (restOfBag == 0L) {
            break
        }
        val currentRestOfBag = minOf(restOfBag, entry.second.toLong())
        result += currentRestOfBag * entry.first.toLong()
        restOfBag -= currentRestOfBag
    }
    println(result)
}