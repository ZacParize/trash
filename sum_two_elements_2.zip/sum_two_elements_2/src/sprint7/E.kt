package sprint7

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private const val MAX_VALUE = 10001

private fun main() {
    val sum = readInt()
    readInt()
    val banknotes = readInts().sortedDescending()
    val dp = Array(sum + 1) { MAX_VALUE }
    dp[0] = 0
    for (tempSum in 1..sum) {
        for (banknote in banknotes) {
            if (tempSum >= banknote && dp[tempSum - banknote] + 1 < dp[tempSum]) {
                dp[tempSum] = dp[tempSum - banknote] + 1
            }
        }
    }
    println(if (dp[sum] == MAX_VALUE) -1 else dp[sum])
}