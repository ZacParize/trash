package sprint7

import java.lang.Integer.max

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private const val MIN_SIZE = 3
private const val MAX_VALUE = 1000000007

private fun main() {
    val (n, k) = readInts()
    val dp = Array(max(n, MIN_SIZE) + 1) { 0L }
    dp[0] = 0
    dp[1] = 1
    dp[2] = 1
    for (idx in 3..n) {
        for (jdx in 1..k) {
            if (idx - jdx >= 0) {
                dp[idx] = (dp[idx] + dp[idx - jdx]) % MAX_VALUE
            }
        }
    }
    println(dp[n])
}