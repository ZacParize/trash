package sprint7

import java.lang.Integer.max

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    val (n, m) = readInts()
    val matrix = Array(n) { IntArray(m) }
    for (idx in 0 until n) {
        val string = readStr()
        for (jdx in string.indices) {
            matrix[idx][jdx] = string[jdx].digitToInt()
        }
    }
    val dp = Array(n) { IntArray(m) }
    var a = 0
    var b = 0
    for (idx in n - 1 downTo  0) {
        for (jdx in 0 until m) {
            a = if (idx + 1 > n - 1) 0 else dp[idx + 1][jdx]
            b = if (jdx - 1 < 0) 0 else dp[idx][jdx - 1]
            dp[idx][jdx] = matrix[idx][jdx] + max(a, b)
        }
    }
    println(dp[0][m - 1])
}