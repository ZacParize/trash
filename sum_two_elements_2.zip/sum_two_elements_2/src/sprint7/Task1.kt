// https://contest.yandex.ru/contest/25597/run-report/109752751/
// Реализация алгоритма Левенштейна для поиска минимального расстояния между строками
// Временная сложность O(S * T)
// Пространственная сложность O(S + T + S)

package sprint7

import kotlin.math.min

private fun readStr() = readln()

fun getLevenshteinDimension(arrayS: ByteArray, arrayT: ByteArray):Int {
    // предыдущая строка матрицы
    val dp = IntArray(arrayS.size + 1) { it }
    var previous: Int
    var temp: Int

    for (idxOfArrayT in 1..arrayT.size) {
        previous = idxOfArrayT
        for (idxOfArrayS in 1..arrayS.size) {
            if (arrayT[idxOfArrayT - 1] != arrayS[idxOfArrayS - 1]) {
                dp[idxOfArrayS - 1] = min(dp[idxOfArrayS], min(dp[idxOfArrayS - 1], previous)) + 1
            }
            temp = dp[idxOfArrayS - 1]
            dp[idxOfArrayS - 1] = previous
            previous = temp
        }
        dp[arrayS.size] = previous
    }

    return dp[arrayS.size]
}

fun main() {
    val arrayS = readStr().toByteArray()
    val arrayT = readStr().toByteArray()
    println(getLevenshteinDimension(arrayS, arrayT))
}