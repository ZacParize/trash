// https://contest.yandex.ru/contest/25597/run-report/109860371/
// Реализация проверки разделения исходного множества на 2 подмножества с одинаковой суммой элементов
// Временная сложность O(N/2 * N) -> O(N^2/2) -> O(N^2)
// Пространственная сложность O(N + N/2 + N/2) -> O(2N)

package sprint7

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private const val SUCCESS_VALUE = "True"
private const val FAIL_VALUE = "False"

private fun checkSum(points: List<Int>): Boolean {
    val sum = points.sum()
    if (sum % 2 != 0) {
        return false
    }
    val target = sum / 2
    val results = BooleanArray(target + 1)
    results[0] = true
    for (point in points) {
        for (j in target downTo point) {
            results[j] = results[j] || results[j - point]
        }
    }
    return results[target]
}

fun main() {
    readStr()
    val digits = readInts()
    println(if (checkSum(digits)) SUCCESS_VALUE else FAIL_VALUE)
}