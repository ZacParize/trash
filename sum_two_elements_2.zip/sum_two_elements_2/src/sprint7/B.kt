package sprint7

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readDoubles() = readStrings().map { it.toDouble() }

const val EMPTY = -1.0

data class LessonSchedule(var lowRange: Double, var highRange: Double)

fun pretty(value: Double): Any {
    // check if the decimal places equal zero
    if (value % 1 > 0.0) {
        // if not, just print the number
        return value
    } else {
        // otherwise convert to Int and print
        return value.toInt()
    }
}

private fun main() {
    val rowSize = readInt()
    val matrix = MutableList(rowSize) { LessonSchedule(EMPTY, EMPTY) }
    for (idx in 0 until rowSize) {
        val list = readDoubles()
        matrix[idx].lowRange = list[0]
        if (list.size == 2) {
            matrix[idx].highRange = list[1]
        }
    }
    val comparator = compareBy<LessonSchedule> { it.highRange }
        .thenBy { it.lowRange }
    matrix.sortWith(comparator)
    val result = mutableListOf<LessonSchedule>()
    for (idx in 0 until rowSize - 1) {
        if (result.isEmpty() || result[result.lastIndex].highRange <= matrix[idx].lowRange) {
            result.add(matrix[idx])
        }
    }
    if (result.isEmpty() || result[result.lastIndex].highRange <= matrix[matrix.lastIndex].lowRange) {
        result.add(matrix[matrix.lastIndex])
    }
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    outputWriter.write(result.size.toString() + "\n")
    for (e in result) {
        outputWriter.write(pretty(e.lowRange).toString() + " " + pretty(e.highRange).toString() + "\n")
    }
    outputWriter.flush()
}