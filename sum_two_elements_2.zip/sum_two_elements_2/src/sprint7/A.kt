package sprint7

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    val arraySize = readInt()
    val list = readInts()
    var sum = 0
    for (idx in 0 until arraySize - 1) {
        if (list[idx] < list[idx + 1]) {
            sum += list[idx + 1] - list[idx]
        }
    }
    println(sum)
}