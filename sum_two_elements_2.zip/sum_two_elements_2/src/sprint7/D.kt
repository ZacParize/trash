package sprint7

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

const val MOD = 1000000007

fun main() {
    val n = readInt()
    var prev = 1
    var current = 1
    var result = 1
    for (i in 2..n) {
        result = (current + prev) % MOD
        prev = current
        current = result
    }
    println(result.toString())
}