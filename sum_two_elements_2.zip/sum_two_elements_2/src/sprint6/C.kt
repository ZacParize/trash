package sprint6

import java.util.Stack
import java.util.TreeSet

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun dfs(startVertex: Int, adjacencyList: HashMap<Int, TreeSet<Int>>, color: MutableList<Color>, travelOrder: LinkedHashSet<Int>) {
    val stack = Stack<Int>()
    stack.add(startVertex) // Добавляем стартовую вершину в стек.
    while (stack.isNotEmpty()) {  // Пока стек не пуст:
        // Получаем из стека очередную вершину.
        // Это может быть как новая вершина, так и уже посещённая однажды.
        val v = stack.pop()
        travelOrder.add(v)
        if (color[v] == Color.WHITE) {
            // Красим вершину в серый. И сразу кладём её обратно в стек:
            // это позволит алгоритму позднее вспомнить обратный путь по графу.
            color[v] = Color.GRAY
            stack.add(v)
            // Теперь добавляем в стек все непосещённые соседние вершины,
            // вместо вызова рекурсии
            for (w in adjacencyList.getOrDefault(v, TreeSet())) {
                // Для каждого исходящего ребра (v, w):
                if (color[w] == Color.WHITE) {
                    stack.add(w)
                }
            }
        } else if (color[v] == Color.GRAY) {
            // Серую вершину мы могли получить из стека только на обратном пути.
            // Следовательно, её следует перекрасить в чёрный.
            color[v] = Color.BLACK
        }
    }
}

private fun mainDFS(startVertex: Int, adjacencyList: HashMap<Int, TreeSet<Int>>, color: MutableList<Color>) {
    if (adjacencyList[startVertex] == null) {
        println((startVertex + 1).toString())
        return
    }
    val travelOrder = LinkedHashSet<Int>(adjacencyList.size)
    dfs(startVertex, adjacencyList, color, travelOrder)
    for (i in 0 until adjacencyList.size) {  // Для каждой вершины i от 0 до |V| - 1:
        // Перебираем варианты стартовых вершин, пока они существуют.
        if (color[i] == Color.WHITE) {
            dfs(i, adjacencyList, color, travelOrder)  // Запускаем обход, стартуя с i-й вершины.
        }
    }
    println(travelOrder.joinToString(separator = " ", transform = { (it + 1).toString() }))
}

private fun main() {
    val (v, e) = readInts()
    val adjacencyList = HashMap<Int, TreeSet<Int>>()
    repeat(e) {
        val (u, v) = readInts()
        adjacencyList.getOrPut(u - 1) { TreeSet<Int>(Comparator.reverseOrder()) }.add(v - 1)
        adjacencyList.getOrPut(v - 1) { TreeSet<Int>(Comparator.reverseOrder()) }.add(u - 1)
    }
    val startVertex = readInt() - 1
    val color = MutableList(v) { Color.WHITE }
    mainDFS(startVertex, adjacencyList, color)
}