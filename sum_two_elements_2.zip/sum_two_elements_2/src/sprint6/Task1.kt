// https://contest.yandex.ru/contest/25070/run-report/107819156/
// Реализация алгоритма Прима для поиска максимального остова
// Временная сложность O(V^2)
// Пространственная сложность O(V^2)

package sprint6

import java.util.PriorityQueue

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private const val OOPS_ERROR = "Oops! I did it again"
private const val INCORRECT_SKELETON_VALUE = -1L

data class Edge(val weight: Int, val vertex: Vertex)

class Vertex(val value: Int) {
    val edges = mutableListOf<Edge>()
}

fun getMaxSkeletonWeight(adjacencyList: MutableList<Vertex>): Long {
    val queue = PriorityQueue<Edge>(compareByDescending { it.weight })
    var totalWeight = 0L
    val visited = BooleanArray(adjacencyList.size)
    visited[0] = true
    queue.addAll(adjacencyList[0].edges)

    while (queue.isNotEmpty()) {
        val edge = queue.poll()
        val vertex = edge.vertex
        if (visited[vertex.value]) {
            continue
        }
        totalWeight += edge.weight
        visited[vertex.value] = true
        vertex.edges.forEach {
            if (!visited[it.vertex.value]) {
                queue.add(it)
            }
        }
    }

    return if (visited.all { it }) {
        totalWeight
    } else {
        INCORRECT_SKELETON_VALUE
    }
}

private fun main() {
    val (vertexCount, edgeCount) = readInts()

    if (vertexCount > 1 && edgeCount == 0) {
        println(OOPS_ERROR)
        return
    }

    val adjacencyList = MutableList(vertexCount) { Vertex(it) }

    repeat(edgeCount) {
        val (v, u, w) = readInts()
        val newV = v - 1
        val newU = u - 1
        adjacencyList[newV].edges.add(Edge(w, adjacencyList[newU]))
        adjacencyList[newU].edges.add(Edge(w, adjacencyList[newV]))
    }

    val totalWeight = getMaxSkeletonWeight(adjacencyList)
    // Отличный коммент, спасибо.
    if (totalWeight == INCORRECT_SKELETON_VALUE) {
        println(OOPS_ERROR)
    } else {
        println(totalWeight)
    }
}