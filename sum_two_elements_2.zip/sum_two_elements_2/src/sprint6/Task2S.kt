package sprint6

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.LinkedList

typealias Matrix = Array<MutableList<Int>>

enum class Peak {
    WHITE,
    GRAY,
    BLACK
}

const val RType = 'R'
const val YES = "YES"
const val NO = "NO"

fun solution(reader: BufferedReader, writer: StringBuilder) {
    val n = reader.readLine().trim().toInt()
    val matrix = Array(n + 1) { mutableListOf<Int>() }
    val visited = Array(n + 1) { Peak.WHITE }

    for (i in 1..n) {
        val railData = reader.readLine()

        visited[i] = Peak.WHITE
        for (j in railData.indices) {
            val target = i + j + 1

            if (railData[j] == RType) {
                matrix[i].add(target)
            } else {
                matrix[target].add(i)
            }
        }
    }
    if (matrix.checkOptimal(visited, n)) {
        writer.append(YES)
    } else {
        writer.append(NO)
    }
}

fun Matrix.checkOptimal(visited: Array<Peak>, n: Int): Boolean {
    for (i in 1..n) {
        if (visited[i] != Peak.WHITE) {
            continue
        }
        val stack = LinkedList<Int>()
        stack.push(i)
        while (stack.isNotEmpty()) {
            val current = stack.peek()
            if (visited[current] == Peak.WHITE) {
                visited[current] = Peak.GRAY
                for (target in this[current]) {
                    if (visited[target] == Peak.WHITE) {
                        stack.push(target)
                    } else if (visited[target] == Peak.GRAY) {
                        return false
                    }
                }
            } else {
                visited[current] = Peak.BLACK
                stack.pop()
            }
        }
    }
    return true
}

fun main() {
    val res = StringBuilder()
    solution(BufferedReader(InputStreamReader(System.`in`)), res)
    println(res.toString())
}