package sprint6

import java.util.LinkedList
import java.util.TreeSet

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun mainBFS(startVertex: Int, adjacencyList: HashMap<Int, TreeSet<Int>>, colors: MutableList<Color>) {
    // Создадим очередь вершин и положим туда стартовую вершину.
    val queue = LinkedList<Int>()
    val travelOrder = LinkedList<Int>()
    queue.add(startVertex)
    colors[startVertex] = Color.GRAY

    while (queue.isNotEmpty()) {
        val u = queue.poll()  // Возьмём вершину из очереди.
        travelOrder.add(u)

        for (v in adjacencyList.getOrDefault(u, TreeSet())) {
            if (colors[v] == Color.WHITE) {
                // Серые и чёрные вершины уже
                // либо в очереди, либо обработаны.
                colors[v] = Color.GRAY
                queue.add(v)  // Запланируем посещение вершины.
            }
        }
        colors[u] = Color.BLACK  // Теперь вершина считается обработанной.
    }
    println(travelOrder.joinToString(separator = " ", transform = { (it + 1).toString() }))
}

private fun main() {
    val (vc, e) = readInts()
    val adjacencyList = HashMap<Int, TreeSet<Int>>()
    repeat(e) {
        val (u, v) = readInts()
        adjacencyList.getOrPut(u - 1) { TreeSet<Int>(Comparator.naturalOrder()) }.add(v - 1)
        adjacencyList.getOrPut(v - 1) { TreeSet<Int>(Comparator.naturalOrder()) }.add(u - 1)
    }
    val startVertex = readInt() - 1
    val color = MutableList(vc) { Color.WHITE }
    mainBFS(startVertex, adjacencyList, color)
}