// https://contest.yandex.ru/contest/25070/run-report/107819778/
// Проверка ориентированного графа на наличие циклов.
// Идея алгортма состоит в том, чтобы взять граф всех дорог
// и с помощью обхода в глубину проверить возможность достижения
// столицы из любого города.
// Препятствием на пути достижения столицы может быть:
// 1) Отсутствие железной дороги с нужным направлением на участке пути
// 2) Наличие циклов на пути в столицу
// Собственно, dfs с проверкой циклов решает эти проблемы
// Сложность алгоритма O(V + E)
// Пространственная сложность O(V^2)

package sprint6

import java.util.Stack

enum class Color {
    WHITE, GRAY, BLACK
}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

const val RED_ROAD_MARK_VALUE = 'R'
const val YES_VALUE = "YES"
const val NO_VALUE = "NO"

private fun isNotCyclicGraph(matrix: Array<MutableList<Int>>): Boolean {
    val colors = Array(matrix.size) { Color.WHITE }
    val stack = Stack<Int>()

    for (idx in matrix.indices) {
        if (colors[idx] != Color.WHITE) {
            continue
        }
        stack.push(idx)
        while (stack.isNotEmpty()) {
            val v = stack.pop()
            if (colors[v] == Color.WHITE) {
                colors[v] = Color.GRAY
                stack.push(v)
                for (w in matrix[v]) {
                    if (colors[w] == Color.WHITE) {
                        stack.push(w)
                    } else if (colors[w] == Color.GRAY) {
                        return false
                    }
                }
            } else if (colors[v] == Color.GRAY) {
                colors[v] = Color.BLACK
            }
        }
    }
    return true
}

private fun main() {
    val cityCount = readInt()
    val matrix = Array(cityCount) { mutableListOf<Int>() }

    for (idx in 0 until cityCount - 1) {
        val railData = readln()
        for (jdx in railData.indices) {
            val destination = idx + jdx + 1
            if (railData[jdx] == RED_ROAD_MARK_VALUE) {
                matrix[idx].add(destination)
            } else {
                matrix[destination].add(idx)
            }
        }
    }

    if (isNotCyclicGraph(matrix)) {
        println(YES_VALUE)
    } else {
        println(NO_VALUE)
    }
}