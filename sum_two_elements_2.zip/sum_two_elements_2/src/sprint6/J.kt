package sprint6

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Stack

fun sort(startVertex: Int, adjacencyList: Array<MutableList<Int>>, colors: MutableList<Color>, stack: Stack<Int>) {
    colors[startVertex] = Color.GRAY
    for (node in adjacencyList[startVertex]) {
        if (colors[node] == Color.WHITE) {
            sort(node, adjacencyList, colors, stack)
        }
    }
    colors[startVertex] = Color.BLACK
    stack.push(startVertex)
}

fun main() {
    val reader = BufferedReader(InputStreamReader(System.`in`))
    val (v, e) = reader.readLine().split(" ").map { it.toInt() }
    val list = Array<MutableList<Int>>(v) { mutableListOf() }
    repeat(e) {
        val (from, to) = reader.readLine().split(" ").map { it.toInt() }
        list[from - 1].add(to - 1)
    }
    val colors = MutableList(v) { Color.WHITE }
    val stack = Stack<Int>()
    for (i in v - 1 downTo 0) {
        if (colors[i] == Color.WHITE) {
            sort(i, list, colors, stack)
        }
    }
    println(stack.reversed().joinToString(separator = " ") { (it + 1).toString() })
}