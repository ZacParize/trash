package sprint6

import java.util.TreeSet

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    val (v, e) = readInts()
    val adjacencyList = HashMap<Int, TreeSet<Int>>()
    repeat(e) {
        val (u, v) = readInts()
        adjacencyList.getOrPut(u) { TreeSet<Int>(Comparator.naturalOrder()) }.add(v)
    }
    for (idx in 1..v) {
        if (adjacencyList.containsKey(idx)) {
            val list = adjacencyList[idx]!!
            println(list.size.toString() + " " + list.joinToString(" "))
        } else {
            println("0")
        }
    }
}