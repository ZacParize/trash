package sprint6

import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.util.Stack
import java.util.TreeSet

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }
var time = 0

private fun dfs(startVertex: Int,
                adjacencyList: Array<TreeSet<Int>>,
                colors: MutableList<Color>,
                entry: MutableList<Int>,
                leave: MutableList<Int>) {
    val stack = Stack<Int>()
    stack.add(startVertex) // Добавляем стартовую вершину в стек.
    while (!stack.isEmpty()) {  // Пока стек не пуст:D
        // Получаем из стека очередную вершину.
        // Это может быть как новая вершина, так и уже посещённая однажды.
        val v = stack.pop()
        if (entry[v] == -1) {
            entry[v] = time++
        }
        if (colors[v] == Color.WHITE) {
            // Красим вершину в серый. И сразу кладём её обратно в стек:
            // это позволит алгоритму позднее вспомнить обратный путь по графу.
            colors[v] = Color.GRAY
            stack.add(v)
            // Теперь добавляем в стек все непосещённые соседние вершины,
            // вместо вызова рекурсии
            val vertexList = adjacencyList[v]
            if (vertexList.size != 0) {
                for (w in vertexList) {
                    // Для каждого исходящего ребра (v, w):
                    if (colors[w] == Color.WHITE) {
                        stack.add(w)
                    }
                }
            }
        } else if (colors[v] == Color.GRAY) {
            // Серую вершину мы могли получить из стека только на обратном пути.
            // Следовательно, её следует перекрасить в чёрный.
            if (leave[v] == -1) {
                leave[v] = time++
            }
            colors[v] = Color.BLACK
        }
    }
}

private fun mainDFS(startVertex: Int,
                    adjacencyList: Array<TreeSet<Int>>,
                    colors: MutableList<Color>) {
    if (adjacencyList[startVertex].size == 0) {
        println("0 1")
        return
    }
    val entry = MutableList(colors.size) { -1 }
    val leave = MutableList(colors.size) { -1 }
    dfs(startVertex, adjacencyList, colors, entry, leave)
    for (i in adjacencyList.indices) {  // Для каждой вершины i от 0 до |V| - 1:
        // Перебираем варианты стартовых вершин, пока они существуют.
        if (colors[i] == Color.WHITE) {
            dfs(i, adjacencyList, colors, entry, leave)  // Запускаем обход, стартуя с i-й вершины.
        }
    }
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    for (idx in 0 until colors.size) {
        outputWriter.write(entry[idx].toString() + ' ' + leave[idx].toString() + "\n")
    }
    outputWriter.flush()
}

private fun main() {
    val (v, e) = readInts()
    //val adjacencyList = HashMap<Int, TreeSet<Int>>()
    val adjacencyList = Array(v) { TreeSet<Int>(Comparator.reverseOrder()) }
    repeat(e) {
        val (u, v) = readInts()
        //adjacencyList.getOrPut(u - 1) { TreeSet<Int>(Comparator.reverseOrder()) }.add(v - 1)
        adjacencyList[u - 1].add(v - 1)
    }
    val colors = MutableList(v) { Color.WHITE }
    mainDFS(0, adjacencyList, colors)
}