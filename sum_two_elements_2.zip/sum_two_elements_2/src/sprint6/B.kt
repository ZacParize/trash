package sprint6

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private fun main() {
    val (v, e) = readInts()
    val adjacencyMatrix = Array(v) { IntArray(v) }
    repeat(e) {
        val (u, v) = readInts()
        adjacencyMatrix[u - 1][v -1] = 1
    }
    for (idx in 0 until v) {
        println(adjacencyMatrix[idx].joinToString(" "))
    }
}