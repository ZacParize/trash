package sprint6

import java.util.LinkedList
import java.util.TreeSet

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInt() = readStr().toInt()
private fun readInts() = readStrings().map { it.toInt() }

private fun mainBFS(startVertex: Int, adjacencyList: HashMap<Int, TreeSet<Int>>, colors: MutableList<Color>, travelOrder: LinkedHashSet<Int>) {
    // Создадим очередь вершин и положим туда стартовую вершину.
    val planned = LinkedList<Int>()
    planned.add(startVertex)
    colors[startVertex] = Color.GRAY
    //distance[startVertex] = 0

    while (planned.isNotEmpty()) {
        val u = planned.poll()  // Возьмём вершину из очереди.
        travelOrder.add(u)

        for (v in adjacencyList.getOrDefault(u, TreeSet())) {
            if (colors[v] == Color.WHITE) {
                // Серые и чёрные вершины уже
                // либо в очереди, либо обработаны.
                //distance[v] = distance[u] + 1
                //previous[v] = u
                colors[v] = Color.GRAY
                planned.add(v)  // Запланируем посещение вершины.
            }
        }
        colors[u] = Color.BLACK  // Теперь вершина считается обработанной.
    }
    println(travelOrder.joinToString(separator = " ", transform = { (it + 1).toString() }))
}

private fun shortestPath(v: Int, previous: MutableList<Int>): List<Int> {
    // Класть вершины будем в стек, тогда
    // стартовая вершина окажется наверху стека
    // и порядок следования от s до v будет соответствовать
    // порядку извлечения вершин из стека.
    val path = mutableListOf<Int>()
    var currentVertex = v

    while (currentVertex != -1) {
        // Предшественник вершины s равен -1.
        path.add(currentVertex)
        currentVertex = previous[currentVertex]
    }

    return path.reversed()
}

private fun main() {
    val (v, e) = readInts()
    val adjacencyList = HashMap<Int, TreeSet<Int>>()
    repeat(e) {
        val (u, v) = readInts()
        adjacencyList.getOrPut(u - 1) { TreeSet<Int>(Comparator.naturalOrder()) }.add(v - 1)
        adjacencyList.getOrPut(v - 1) { TreeSet<Int>(Comparator.naturalOrder()) }.add(u - 1)
    }
    val startVertex = readInt() - 1
    val color = MutableList(v) { Color.WHITE }
    val previous = MutableList(v) { 0 }
    val distance = MutableList(v) { 0 }
    val travelOrder =  LinkedHashSet<Int>()
    mainBFS(startVertex, adjacencyList, color, travelOrder)
}