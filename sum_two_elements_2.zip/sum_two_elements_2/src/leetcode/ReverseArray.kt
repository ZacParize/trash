package leetcode

private fun reverseArray(array: IntArray) {
    if (array.isEmpty()) {
        return
    }
    var leftPointer = 0
    var rightPointer = array.size - 1
    while (leftPointer < rightPointer) {
        array[leftPointer] += array[rightPointer]
        array[rightPointer] = array[leftPointer] - array[rightPointer]
        array[leftPointer] = array[leftPointer] - array[rightPointer]
        leftPointer++
        rightPointer--
    }
}

fun main() {
    var tempArray = intArrayOf(1,2,3,4,5,6)
    reverseArray(tempArray)
    println(tempArray.joinToString(separator = ","))
    tempArray = intArrayOf(1,2,3,4,5)
    reverseArray(tempArray)
    println(tempArray.joinToString(separator = ","))
}