package leetcode

import kotlin.math.abs

private fun intersect(nums1: IntArray, nums2: IntArray): IntArray {
    if (nums1.isEmpty() || nums2.isEmpty()) {
        return intArrayOf()
    }
    var map = mutableMapOf<Int, Int>()
    for (element in nums1) {
        map.putIfAbsent(abs(element), 0)
    }
    for (element in nums2) {
        map.computeIfPresent(element) { _, old -> old + 1 }
    }
    return map.filter { it.value > 0 }.map { it.key }.toIntArray()
}

fun main() {
    val nums1 = intArrayOf(1, 2, 3, 4, 5, 6, 7)
    val nums2 = intArrayOf(1, 3, 4, 5)
    intersect(nums1, nums2)
    println(intersect(nums1, nums2).joinToString(prefix = "[", separator = ",", postfix = "]"))
}