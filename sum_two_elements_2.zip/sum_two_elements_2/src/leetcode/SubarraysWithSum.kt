package leetcode

private fun getSubarraysWithSum1(array: IntArray, k: Int): IntArray {
    if (array.isEmpty()) {
        return IntArray(0)
    }
    var leftPointer = 0
    var rightPointer = 0
    var sumOfSubarray = 0
    while (rightPointer < array.size) {
        sumOfSubarray += array[rightPointer]
        while (sumOfSubarray > k && leftPointer <= rightPointer) {
            sumOfSubarray -= array[leftPointer];
            leftPointer++;
        }
        if (sumOfSubarray == k) {
            println("Найден подмассив: [ $leftPointer, $rightPointer ], $k");
            return IntArray(0)
        }
        rightPointer++;
    }
    return IntArray(0)
}

private fun getSubarraysWithSum2(array: IntArray, k: Int): IntArray {
    if (array.isEmpty()) {
        return IntArray(0)
    }
    var leftPointer = 0
    var rightPointer = 0
    var sumOfSubarray = array[0]
    while (leftPointer < array.size && rightPointer < array.size) {
        if (sumOfSubarray == k) {
            println("Найден подмассив: [ $leftPointer, $rightPointer ], $k");
            sumOfSubarray -= array[leftPointer]
            leftPointer++
        } else if (sumOfSubarray < k) {
            rightPointer++
            if (rightPointer < array.size) {
                sumOfSubarray += array[rightPointer]
            }
        } else {
            sumOfSubarray -= array[leftPointer]
            leftPointer++
        }
    }
    return IntArray(0)
}

fun main() {
    //val nums1 = intArrayOf(1, 2, 3, 4, 5, 6, 7)
    getSubarraysWithSum1(intArrayOf(2, 3, 6, 7, 9, 11), 16)
    getSubarraysWithSum2(intArrayOf(1, 2, 3, 4, 5, 6, 7), 6)
}