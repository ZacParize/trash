package leetcode

private fun check(str: String): Boolean {
    if (str.isBlank()) {
        return true
    }
    val validString = ArrayList<Char>()
    for (element in str.toCharArray()) {
        if (!element.isLetter()) {
            continue
        }
        validString.add(element.lowercaseChar())
    }
    val count = validString.size / 2 - 1
    for (idx in 0..count) {
        if (validString[idx] != validString[validString.size - idx - 1]) {
            return false
        }
    }
    return true
}

fun main() {
    val palindrome1 = "A man, a plan, a canal: Panama"
    val palindrome2 = "race a car"
    val palindrome3 = "a n n a"
    val palindrome4 = "a n rna"
    println(check(palindrome1))
    println(check(palindrome2))
    println(check(palindrome3))
    println(check(palindrome4))
}