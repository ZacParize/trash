package leetcode

import kotlin.math.abs

private fun solve(array1: IntArray, array2: IntArray, distance: Int): Int {
    if (array1.isEmpty() || array2.isEmpty()) {
        return 0
    }
    var result = array1.size
    for (outerElement in array1) {
        for (innerElement in array2) {
            if (abs(outerElement - innerElement) <= distance) {
                result--
                break
            }
        }
    }
    return result
}

fun main() {
    val array11 = intArrayOf(4,5,8)
    val array12 = intArrayOf(10,9,1,8   )
    val distance1 = 2
    val array21 = intArrayOf(1,4,2,3)
    val array22 = intArrayOf(-4,-3,6,10,20,30)
    val distance2 = 3
    val array31 = intArrayOf(2,1,100,3)
    val array32 = intArrayOf(-5,-2,10,-3,7)
    val distance3 = 6
    println(solve(array11, array12, distance1))
    println(solve(array21, array22, distance2))
    println(solve(array31, array32, distance3))
}