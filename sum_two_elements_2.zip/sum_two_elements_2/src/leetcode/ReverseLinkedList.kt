package leetcode

/**
 * Example:
 * var li = ListNode(5)
 * var v = li.`val`
 * Definition for singly-linked list.
 * class ListNode(var `val`: Int) {
 *     var next: ListNode? = null
 * }
 */

class ListNode (var value: Int, var next: ListNode?)

private fun reverseList(head: ListNode?): ListNode? {
    if (head?.next == null) {
        return head
    }
    val newHead = reverseList(head.next)
    head.next?.next = head
    head.next = null
    return newHead
}

fun main() {
    val node3 = ListNode(3, null)
    val node2 = ListNode(2, node3)
    val node1 = ListNode(1, node2)
    val node0 = ListNode(0, node1)
    reverseList(node0)
    println(node0)
}