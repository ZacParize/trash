package leetcode

private fun solve(str1: String, str2: String): Boolean {
    if (str1.isBlank() && str2.isBlank()) {
        return true
    }
    if (str1.isBlank() || str2.isBlank()) {
        return false
    }
    val dictionary1 = HashMap<Char,Int>(26)
    val dictionary2 = HashMap<Char,Int>(26)
    str1.forEach { dictionary1[it] = dictionary1.getOrDefault(it, 0) + 1 }
    str2.forEach { dictionary2[it] = dictionary2.getOrDefault(it, 0) + 1 }
    return dictionary1.all { it.value == dictionary2[it.key] }
            && dictionary2.all { it.value == dictionary1[it.key] }
}

fun main() {
    println(solve("anagram", "nagaram"))
    println(solve("rat", "car"))
}