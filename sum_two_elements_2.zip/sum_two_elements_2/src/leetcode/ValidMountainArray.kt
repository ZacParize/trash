package leetcode

private fun check(nums: IntArray): Boolean {
    if (nums.isEmpty() || nums.size <= 2) {
        return false
    }
    var positiveTrend = true
    var trendChangeCount = 0
    var previousNumber = nums[0]
    for (idx in 1 until nums.size) {
        val currentNumber = nums[idx]
        if (previousNumber == currentNumber) {
            return false
        }
        if (previousNumber > currentNumber && positiveTrend) {
            positiveTrend = false
            trendChangeCount++
        }
        if (previousNumber < currentNumber && !positiveTrend) {
            positiveTrend = true
        }
        previousNumber = currentNumber
    }
    return trendChangeCount == 1
}

fun main() {
    val nums1 = intArrayOf(2,1)
    val nums2 = intArrayOf(3,5,5)
    val nums3 = intArrayOf(0,3,2,1)
    println(check(nums1))
    println(check(nums2))
    println(check(nums3))
}