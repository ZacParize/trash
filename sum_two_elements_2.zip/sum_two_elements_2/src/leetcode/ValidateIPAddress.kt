package leetcode

const val ERROR_MESSAGE = "Neither"

private fun solve(ip: String): String {
    if (ip.isBlank() || !(ip.contains('.') || ip.contains(':'))) {
        return ERROR_MESSAGE
    }
    if (ip.contains('.')) {
        val ipArray = ip.split(".")
        if (ipArray.isEmpty() || ipArray.size > 4) {
            return ERROR_MESSAGE
        }
        for (ipPart in ipArray) {
            if (ipPart.startsWith('0')) {
                return ERROR_MESSAGE
            }
            for (ipElement in ipPart) {
                if (!ipElement.isDigit()) {
                    return ERROR_MESSAGE
                }
            }
            val ipPartInt = ipPart.toInt()
            if (0 > ipPartInt || ipPartInt > 255) {
                return ERROR_MESSAGE
            }
        }
        return "IPv4"
    } else {
        val ipArray = ip.split(":")
        if (ipArray.isEmpty() || ipArray.size > 8) {
            return ERROR_MESSAGE
        }
        for (ipPart in ipArray) {
            if (ipPart.isEmpty() || ipPart.length > 4) {
                return ERROR_MESSAGE
            }
            for (ipElement in ipPart) {
                if (!ipElement.isLetterOrDigit()) {
                    return ERROR_MESSAGE
                }
            }
        }
        return "IPv6"
    }
}

fun main() {
    println(solve("172.16.254.1"))
    println(solve("2001:0db8:85a3:0:0:8A2E:0370:7334"))
    println(solve("256.256.256.256"))
}