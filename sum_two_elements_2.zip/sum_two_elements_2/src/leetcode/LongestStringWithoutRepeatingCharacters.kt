package leetcode

import kotlin.math.max

private fun find(str: String): Int {
    if (str.isBlank()) {
        return 0
    }
    var idx = 0
    var maxLength = 0
    var setOfCharacters = HashSet<Char>()
    while (idx < str.length) {
        while (idx < str.length - 1 && str[idx] == str[idx + 1]) {
            idx++
        }
        setOfCharacters.clear()
        while (idx < str.length && !setOfCharacters.contains(str[idx])) {
            setOfCharacters.add(str[idx])
            idx++
        }
        maxLength = max(maxLength, setOfCharacters.size)
        idx++
    }
    return maxLength
}

fun main() {
    val string1 = "abcabcbb"
    val string2 = "bbbbb"

    println(find(string1))
    println(find(string2))
}