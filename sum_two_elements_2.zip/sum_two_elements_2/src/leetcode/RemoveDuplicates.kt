package leetcode

private fun removeDuplicates(nums: IntArray): Int {
    if (nums.isEmpty()) {
        return 0
    }
    var numIdx = 0
    var resultIdx = 0
    while (numIdx < nums.size) {
        nums[resultIdx++] = nums[numIdx]
        val currentValue = nums[numIdx]
        while (numIdx < nums.size && currentValue == nums[numIdx]) {
            numIdx++
        }
    }
    val count = resultIdx
    val arrayToString = nums.joinToString(prefix = "[", separator = ",", postfix = "]")
    println("$count, nums = $arrayToString")
    return count
}

fun main() {
    val nums = intArrayOf(1, 1, 2, 3, 4, 4, 4)
    removeDuplicates(nums)
}