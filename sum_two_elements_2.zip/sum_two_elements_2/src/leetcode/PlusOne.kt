package leetcode

private fun solve(nums: IntArray): CharArray {
    if (nums.isEmpty()) {
        return CharArray(0)
    }
    var degree = 1
    var number = 0
    for (idx in nums.size - 1 downTo 0) {
        number += degree * nums[idx]
        degree *= 10
    }
    number++
    return number.toString().toCharArray()
}

fun main() {
    val nums1 = intArrayOf(1,2,3)
    val nums2 = intArrayOf(4,3,2,1)
    val nums3 = intArrayOf(9)
    println(solve(nums1))
    println(solve(nums2))
    println(solve(nums3))
}