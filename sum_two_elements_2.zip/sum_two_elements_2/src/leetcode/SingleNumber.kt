package leetcode

private fun singleNumber(nums: IntArray): Int {
    if (nums.isEmpty()) {
        return 0
    }
    var result = 0
    for (idx in nums.indices) {
        result = result xor nums[idx]
    }
    return result
}

fun main() {
    val nums = intArrayOf(1, 1, 2, 2, 3, 3, 4, 4)

    println(singleNumber(nums))
}