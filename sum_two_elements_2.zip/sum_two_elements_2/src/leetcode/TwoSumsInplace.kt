package leetcode

private fun solve(array: IntArray, sum: Int): Boolean {
    if (array.isEmpty()) {
        return true
    }
    val sortedArray = array.sorted()
    var left = 0
    var right = sortedArray.size - 1
    var tempSum = 0
    while (left <= right) {
        tempSum = sortedArray[left] + sortedArray[right]
        if (tempSum == sum) {
            println(sortedArray[left].toString() + " + " + sortedArray[right] + " = " + sum)
            return true
        } else if (tempSum < sum) {
            left++
        } else {
            right--
        }
    }
    return false
}

fun main() {
    println(solve(intArrayOf(1, 3, -1, 13, 4, 2), 5))
}