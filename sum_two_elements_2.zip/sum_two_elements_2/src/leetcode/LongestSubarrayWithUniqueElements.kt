package leetcode

import kotlin.math.max

private fun solve(array: IntArray): IntArray {
    if (array.isEmpty()) {
        return IntArray(0)
    }
    var resultArray = IntArray(0)
    var leftPointer = 0
    val mapOfPositions = HashMap<Int,Int>()
    for (idx in array.indices) {
        if (mapOfPositions.contains(array[idx])) {
            if (idx - leftPointer > resultArray.size) {
                resultArray = array.copyOfRange(leftPointer, idx)
            }
            leftPointer = idx
        }
        if (idx == array.lastIndex) {
            if (idx - leftPointer > resultArray.size || resultArray.isEmpty()) {
                resultArray = array.copyOfRange(leftPointer, idx + 1)
            }
        }
        mapOfPositions[array[idx]] = idx
    }
    return resultArray
}

private fun solveLength(array: IntArray): Int {
    if (array.isEmpty()) {
        return 0
    }
    var maxLength = 0
    var leftPointer = 0
    val mapOfPositions = HashMap<Int,Int>()
    for (idx in array.indices) {
        maxLength = max(idx - leftPointer, maxLength)
        if (mapOfPositions.contains(array[idx])) {
            leftPointer = idx
        } else if (idx == array.lastIndex) {
            maxLength = max(idx - leftPointer + 1, maxLength)
        }
        mapOfPositions[array[idx]] = idx
    }
    return maxLength
}

fun main() {
    val array0 = intArrayOf(1)
    val array1 = intArrayOf(1, 2, 3, 4, 5)
    val array2 = intArrayOf(1, 2, 3, 1, 5)
    val array3 = intArrayOf(1, 2, 3, 3, 5, 6, 9, 0)
    val array4 = intArrayOf(1, 2, 3, 5, 7, 8, 2, 5, 6)
    val array5 = intArrayOf(1, 1, 5, 5, 5)


    println(solveLength(array0))
    println(solve(array0).joinToString(separator = ","))
    println(solveLength(array1))
    println(solve(array1).joinToString(separator = ","))
    println(solveLength(array2))
    println(solve(array2).joinToString(separator = ","))
    println(solveLength(array3))
    println(solve(array3).joinToString(separator = ","))
    println(solveLength(array4))
    println(solve(array4).joinToString(separator = ","))
    println(solveLength(array5))
    println(solve(array5).joinToString(separator = ","))
}