package leetcode

import kotlin.math.max
import kotlin.math.min

private fun solve(intervals: List<List<Int>>): List<List<Int>> {
    if (intervals.isEmpty() || !intervals.all { it.size == 2 }) {
        return emptyList()
    }
    val result = ArrayList<List<Int>>()
    for (idx in intervals.indices) {
        if (result.isEmpty()) {
            result.add(intervals[idx])
        } else {
            val jdx = result.size - 1
            if (result[jdx][1] >= intervals[idx][0]) {
                result[jdx] = listOf(min(result[jdx][0], intervals[idx][0]), max(result[jdx][1], intervals[idx][1]))
            } else {
                result.add(listOf(intervals[idx][0], intervals[idx][1]))
            }
        }
    }
    return result
}

fun main() {
    println(solve(listOf(listOf(1,3), listOf(2,6), listOf(8,10), listOf(15,18))))
    println(solve(listOf(listOf(1,4), listOf(4,5))))
}