package leetcode

private fun solve(pattern: String, string: String): Boolean {
    if (pattern.isBlank() && string.isBlank()) {
        return true
    }
    if (pattern.isBlank() || string.isBlank()) {
        return false
    }
    val splittedString = string.split(" ")
    if (pattern.length != splittedString.size) {
        return false
    }
    val dictionary = HashMap<Char, String>()
    for (idx in pattern.indices) {
        if (!dictionary.containsKey(pattern[idx])) {
            dictionary[pattern[idx]] = splittedString[idx]
        }
    }
    return pattern.map { dictionary[it] }.joinToString(separator = " ") == string
}

fun main() {
    println(solve("abba", "dog cat cat dog"))
    println(solve("abba", "dog cat cat fish"))
    println(solve("aaaa", "dog cat cat dog"))
    println(solve("aaaa", "dog dog dog"))
    println(solve("aaaa", "dog dog dog dog"))
}