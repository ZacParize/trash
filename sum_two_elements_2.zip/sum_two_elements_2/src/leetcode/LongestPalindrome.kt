package leetcode

private fun solve(string: String): String {
    if (string.isBlank()) {
        return ""
    }
    var idx = 0
    var result = ""
    while (idx < string.length) {
        var center = idx
        var shift = 1
        var tempResult = "" + string[center]
        while (center - shift >= 0 && center + shift < string.length) {
            if (string[center - shift] == string[center + shift]) {
                tempResult = string[center - shift] + tempResult + string[center + shift]
            } else {
                if ((string[center - shift] == tempResult[0] || string[center + shift] == tempResult[0])
                    && tempResult.length == 1) {
                    tempResult += tempResult
                }
                break
            }
            shift++
        }
        if (tempResult.length > result.length) {
            result = tempResult
        }
        idx++
    }
    return result
}

fun main() {
    println(solve("babad"))
    println(solve("cbbd"))
    println(solve("abcdefedcbaghi"))
}