package leetcode

private fun compress(str: String): List<Pair<Char,CharArray>> {
    if (str.isBlank()) {
        return emptyList()
    }
    var idx = 0
    var repeatCount: Int
    val result = ArrayList<Pair<Char,CharArray>>()
    var currentSymbol: Char
    while (idx < str.length) {
        repeatCount = 0
        currentSymbol = str[idx]
        while (idx < str.length && currentSymbol == str[idx]) {
            repeatCount++
            idx++
        }
        result.add(Pair(currentSymbol, repeatCount.toString().toCharArray()))
    }
    return result
}

fun main() {
    val chars = "aabbcccccccccccccc"
    println(compress(chars).joinToString(separator = "") {
        String.format("%c%s", it.first, it.second.joinToString(separator = ""))
    })
}