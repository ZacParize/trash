package leetcode

private fun rotate(nums: IntArray, k: Int) {
    if (k >= nums.size || nums.isEmpty()) {
        return
    }
    for (idx in 1..k) {
        var previousValue = nums[nums.lastIndex]
        for (jdx in 0..nums.lastIndex) {
            val currentValue = nums[jdx]
            nums[jdx] = previousValue
            previousValue = currentValue
        }
    }
}

fun main() {
    val nums = intArrayOf(1, 2, 3, 4, 5, 6, 7)
    rotate(nums, 3)
    println(nums.joinToString(prefix = "[", separator = ",", postfix = "]"))
}