package leetcode

import kotlin.math.max
import kotlin.math.min

private fun solve(array1: List<List<Int>>, array2: List<List<Int>>): List<List<Int>> {
    if (array1.isEmpty() || array2.isEmpty()) {
        return emptyList()
    }
    var idx = 0
    var jdx = 0
    val result = ArrayList<List<Int>>()
    while (idx < array1.size && jdx < array2.size) {
        while (jdx < array2.size && array1[idx][0] <= array2[jdx][0] && array1[idx][1] >= array2[jdx][0]) {
            result.add(listOf(max(array1[idx][0], array2[jdx][0]), min(array1[idx][1], array2[jdx][1])))
            jdx++
        }
        while (idx < array1.size && jdx < array2.size && array1[idx][0] >= array2[jdx][0]
            && array1[idx][0] <= array2[jdx][1]) {
            result.add(listOf(max(array1[idx][0], array2[jdx][0]), min(array1[idx][1], array2[jdx][1])))
            idx++
        }
        if (idx >= array1.size || jdx >= array2.size) {
            break
        }
        if (array1[idx][0] <= array2[jdx][0]) {
            idx++
        } else {
            jdx++
        }
    }
    return result
}

fun main() {
    // [[1,8] [9,11], [13, 17]]
    // [[2,3] [10,12], [16,20]
    println(solve(listOf(listOf(1,8), listOf(9,11), listOf(13,17)),
        listOf(listOf(2,3), listOf(4,5), listOf(10,12), listOf(16, 20))))
    println(solve(listOf(listOf(1,8), listOf(9,11), listOf(13,17)),
        listOf(listOf(18, 20))))
    println(solve(listOf(listOf(18,20)), listOf(listOf(18, 20))))
}