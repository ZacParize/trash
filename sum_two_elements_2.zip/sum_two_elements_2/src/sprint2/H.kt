import java.util.*

//package sprint2
private fun readStr() = readln()
val BRACKETS = mapOf(')' to '(', '}' to '{', ']' to '[')

private fun check(sequence: String?): String {
    if (sequence == null || sequence.isEmpty()) {
        return "True"
    }
    val stack = ArrayDeque<Char>(sequence.length)
    for (char in sequence) {
        if (BRACKETS.containsValue(char)) {
            stack.push(char)
        }
        if (BRACKETS.containsKey(char)) {
            if (stack.isEmpty()) {
                return "False"
            }
            if (stack.pop() != BRACKETS.getValue(char)) {
                return "False"
            }
        }
    }
    return if (stack.isEmpty()) { "True" } else { "False" }
}

fun main() {
    val inputString = readStr()
    print(check(inputString))
}