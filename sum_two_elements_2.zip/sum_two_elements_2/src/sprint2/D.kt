package sprint2

class Node<V>(
    var value: V,
    var next: Node<V>? = null,
)

fun solution(head: Node<String>?, item: String): Int {
    var position = -1
    var idx = 0
    var cursor = head
    while (cursor != null) {
        if (item == cursor.value) {
            position = idx
            break
        }
        cursor = cursor.next
        idx++
    }
    return position
}

fun main() {
    val node3 = Node("node3", null)
    val node2 = Node("node2", node3)
    val node1 = Node("node1", node2)
    val node0 = Node("node0", node1)
    val idx: Int = solution(node0, "node2")
    assert(idx == 2)
}