// https://contest.yandex.ru/contest/22781/run-report/102959055/

package sprint2

import java.lang.Math.floorDiv
import java.util.Stack

private fun readString() = readln()
private fun readStrings() = readString().split(" ")

interface Command {
    fun execute(a: Int, b: Int): Int
}

object Plus : Command {
    override fun execute(a: Int, b: Int) = a + b
}

object Minus : Command {
    override fun execute(a: Int, b: Int) = a - b
}

object Multiply : Command {
    override fun execute(a: Int, b: Int) = a * b
}

object Divide : Command {
    override fun execute(a: Int, b: Int) = floorDiv(a, b)
}

class Calculator(private val tokens: List<String>) {

    companion object {
        private val executors: Map<String, Command> =
            mapOf("+" to Plus, "-" to Minus, "/" to Divide, "*" to Multiply)
    }

    private val stack: Stack<Int> = Stack<Int>()

    fun calculate(): Int {
        for (symbol in tokens) {
            val token = executors[symbol]
            if (token != null) {
                val a = stack.pop()
                val b = stack.pop()
                stack.push(token.execute(b, a))
            } else {
                stack.push(symbol.toInt())
            }
        }
        return stack.pop()
    }
}

fun main() {
    val task = readStrings()
    println(Calculator(task).calculate())
}