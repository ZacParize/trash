package sprint2

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main() {
    val rowCount = readInt()
    val columnCount = readInt()
    val outMatrix = Array(columnCount) { IntArray(rowCount) }

    for (idx in 0 until rowCount) {
        val listOfInts = readInts()
        for (jdx in 0 until columnCount) {
            outMatrix[jdx][idx] = listOfInts[jdx]
        }
    }

    outMatrix.forEach { println(it.joinToString(" ")) }
}