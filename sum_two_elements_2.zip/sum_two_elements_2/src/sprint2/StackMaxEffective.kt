package sprint2

class StackMaxEffective {

    class Node<T>(var item: T, var nextStack: Node<T>?, var nextDesc: Node<T>?)

    private val errorMessage: String = "error"
    private var size: Int = 0
    private var headStack: StackMaxEffective.Node<Int>? = null
    private var headDesc: StackMaxEffective.Node<Int>? = null

    fun getMax() {
        println(headDesc?.item?: "None")
    }

    fun getSize(): Int {
        return size
    }

    fun isEmpty(): Boolean {
        return headDesc == null
    }

    fun push(item: Int) {
        size++
        val newNode = StackMaxEffective.Node(item, null, null)
        newNode.nextStack = headStack
        headStack = newNode
        if (headDesc == null) {
            headDesc = newNode
            return
        }
        var prev: StackMaxEffective.Node<Int>? = null
        var cursor = headDesc
        while (cursor != null && cursor.item > newNode.item) {
            prev = cursor
            cursor = cursor.nextDesc
        }
        prev?.nextDesc = newNode
        newNode.nextDesc = cursor
        if (prev == null) {
            headDesc = newNode
        }
    }

    fun pop() {
        if (headStack == null)  {
            println(errorMessage)
            return
        }

        val deletedItem = headStack
        headStack = headStack?.nextStack

        if (headDesc == deletedItem) {
            headDesc = deletedItem?.nextDesc
        } else {
            var cursor = headDesc
            while (cursor != null) {
                if (cursor.nextDesc == deletedItem) {
                    cursor.nextDesc = deletedItem?.nextDesc
                    break
                }
                cursor = cursor.nextDesc
            }
        }
        size--
    }

}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main() {
    val commandCount = readInt()
    val stack = StackMaxEffective()
    for (idx in 1 .. commandCount) {
        val command = readStrings()
        if (command[0] == "get_max") {
            stack.getMax()
        } else if (command[0] == "pop") {
            stack.pop()
        } else if (command[0] == "push") {
            stack.push(command[1].toInt())
        }
    }
}