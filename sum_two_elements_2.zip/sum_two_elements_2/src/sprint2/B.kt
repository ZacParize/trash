package sprint2

fun solution(head: Node<String>?) {
    var cursor = head
    while (cursor != null) {
        println(cursor.value)
        cursor = cursor.next
    }
}

fun test() {
    val node3 = Node("node3")
    val node2 = Node("node2", node3)
    val node1 = Node("node1", node2)
    val node0 = Node("node0", node1)
    solution(node0)
}