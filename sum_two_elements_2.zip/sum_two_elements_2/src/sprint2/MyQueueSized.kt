package sprint2

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private val OUTPUT_WRITER: BufferedWriter = BufferedWriter(OutputStreamWriter(System.out))

class MyQueueSized(private val capacity: Int) {

    companion object {
        private val errorMessage: String = "error"
        private val noneMessage: String = "None"
    }

    class Node(val value: String, var prev: Node?, var next: Node?)

    private var first: Node? = null
    private var last: Node? = null
    private var size: Int = 0

    fun getCapacity(): Int {
        return capacity
    }

    fun getSize(): Int {
        return size
    }

    fun isFull(): Boolean {
        return size == capacity
    }

    fun isEmpty(): Boolean {
        return size == 0
    }

    fun push(item: String) {
        if (isFull()) {
            OUTPUT_WRITER.write(errorMessage + "\n")
            return
        }
        if (isEmpty()) {
            val newNode = MyQueueSized.Node(item, null, null)
            first = newNode
            last = newNode
        } else {
            val newNode = MyQueueSized.Node(item, last, null)
            last?.next = newNode
            last = newNode
        }
        size++
    }

    fun pop(): String {
        if (isEmpty()) {
            return noneMessage
        }
        val removedNode = first
        first?.next?.prev = null
        first = first?.next
        if (first == null) {
            last = null
        }
        size--
        return removedNode?.value!!
    }

    fun peek(): String {
        if (isEmpty()) {
            return noneMessage
        }
        return first?.value!!
    }

}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main() {
    val commandCount = readInt()
    val queueSize = readInt()
    val queue = MyQueueSized(queueSize)
    for (idx in 1..commandCount) {
        val command = readStrings()
        if (command[0] == "peek") {
            OUTPUT_WRITER.write(queue.peek() + "\n")
        } else if (command[0] == "pop") {
            OUTPUT_WRITER.write(queue.pop() + "\n")
        } else if (command[0] == "size") {
            OUTPUT_WRITER.write(queue.getSize().toString() + "\n")
        } else if (command[0] == "push") {
            queue.push(command[1])
        }
    }
    OUTPUT_WRITER.flush()
}