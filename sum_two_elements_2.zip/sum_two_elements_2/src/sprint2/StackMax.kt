package sprint2

class StackMax {

    class Node<T>(var item: T, var next: Node<T>?)

    private val errorMessage: String = "error"
    private var max: Int? = null
    private var size: Int = 0
    private var head: StackMax.Node<Int>? = null

    fun getMax() {
        println(max?: "None")
    }

    fun getSize(): Int {
        return size
    }

    fun isEmpty(): Boolean {
        return head == null
    }

    fun push(item: Int) {
        head = StackMax.Node(item, head)
        size++
        if (max == null || item > max!!) {
            max = item
        }
    }

    fun pop() {
        if (head == null)  {
            println(errorMessage)
            return
        }
        head = head?.next
        size--

        var cursor = head
        max = null
        while (cursor != null) {
            if (max == null || cursor.item > max!!) {
                max = cursor.item
            }
            cursor = cursor.next
        }
    }

}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main() {
    val commandCount = readInt()
    val stack = StackMax()
    for (idx in 1 .. commandCount) {
        val command = readStrings()
        if (command[0] == "get_max") {
            stack.getMax()
        } else if (command[0] == "pop") {
            stack.pop()
        } else if (command[0] == "push") {
            stack.push(command[1].toInt())
        }
    }
}