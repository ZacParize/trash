package sprint2

import java.io.BufferedWriter
import java.io.OutputStreamWriter

class MyQueue {

    companion object {
        private val errorMessage: String = "error"
    }

    class Node(val value: String, var prev: Node?, var next: Node?)

    private var first: Node? = null
    private var last: Node? = null
    private var size: Int = 0

    fun getSize(): Int {
        return size
    }

    fun isEmpty(): Boolean {
        return size == 0
    }

    fun put(item: String) {
        if (isEmpty()) {
            val newNode = MyQueue.Node(item, null, null)
            first = newNode
            last = newNode
        } else {
            val newNode = MyQueue.Node(item, last, null)
            last?.next = newNode
            last = newNode
        }
        size++
    }

    fun get(): String {
        if (isEmpty()) {
            return errorMessage
        }
        val removedNode = first
        first?.next?.prev = null
        first = first?.next
        if (first == null) {
            last = null
        }
        size--
        return removedNode?.value!!
    }

}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun main() {
    val commandCount = readInt()
    val queue = MyQueue()
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    for (idx in 1..commandCount) {
        val command = readStrings()
        if (command[0] == "get") {
            outputWriter.write(queue.get() + "\n")
        } else if (command[0] == "size") {
            outputWriter.write(queue.getSize().toString() + "\n")
        } else if (command[0] == "put") {
            queue.put(command[1])
        }
    }
    outputWriter.flush()
}