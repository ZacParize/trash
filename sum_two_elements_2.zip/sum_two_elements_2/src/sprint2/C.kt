package sprint2

/*class Node<V>(
    var value: V,
    var next: Node<V>? = null,
)*/

fun solution(head: Node<String>?, pos: Int): Node<String>? {
    var cursor = head
    if (pos == 0) {
        cursor = head?.next
        return cursor
    }
    var idx = 0
    while (cursor != null && idx < pos) {
        if (idx == pos - 1) {
            cursor.next = cursor.next?.next
            break
        }
        cursor = cursor.next
        idx++
    }
    return head
}

fun main() {
    val node3 = Node("node3", null)
    val node2 = Node("node2", node3)
    val node1 = Node("node1", node2)
    val node0 = Node("node0", node1)
    val newHead = solution(node0, 1)
    assert(newHead === node0)
    assert(newHead?.next === node2)
    assert(newHead?.next?.next === node3)
    assert(newHead?.next?.next?.next == null)
    // result is : node0 -> node2 -> node3
}