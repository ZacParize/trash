// https://contest.yandex.ru/contest/22781/run-report/102962739/

package sprint2

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readString() = readln()
private fun readInt() = readString().toInt()
private fun readStrings() = readString().split(" ")
const val ERROR_MESSAGE = "error"

class Deque(private var maxSize: Int) {

    private val elements = arrayOfNulls<Int>(maxSize)
    private var size = 0
    private var head = maxSize - 1
    private var tail = 0

    fun isEmpty() = size == 0

    fun isFull() = size == maxSize

    fun pushBack(value: Int): Int? {
        if (isFull()) {
            return null
        }
        elements[tail] = value
        tail = (tail + 1) % maxSize
        size++
        return value
    }

    fun pushFront(value: Int): Int? {
        if (isFull()) {
            return null
        }
        elements[head] = value
        head = (head + maxSize - 1) % maxSize
        size++
        return value
    }

    fun popBack(): Int? {
        if (isEmpty()) {
            return null
        }
        size--
        tail = (tail + maxSize - 1) % maxSize
        return elements[tail]
    }

    fun popFront(): Int? {
        if (isEmpty()) {
            return null
        }
        size--
        head = (head + 1) % maxSize
        return elements[head]
    }

}

fun main() {
    val commandCount = readInt()
    val maxSize = readInt()
    val outputWriter = BufferedWriter(OutputStreamWriter(System.out))
    val deque = Deque(maxSize)
    repeat(commandCount) {
        val command = readStrings()
        if (command[0] == "push_back" && deque.pushBack(command[1].toInt()) == null) {
            outputWriter.write(ERROR_MESSAGE + "\n")
        } else if (command[0] == "push_front" && deque.pushFront(command[1].toInt()) == null) {
            outputWriter.write(ERROR_MESSAGE + "\n")
        } else if (command[0] == "pop_front") {
            outputWriter.write((deque.popFront()?.toString()?: ERROR_MESSAGE) + "\n")
        } else if (command[0] == "pop_back") {
            outputWriter.write((deque.popBack()?.toString()?: ERROR_MESSAGE) + "\n")
        }
    }
    outputWriter.flush()
}