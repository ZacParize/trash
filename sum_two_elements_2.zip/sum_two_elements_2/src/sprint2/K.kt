package sprint2

private fun fibonacciUsingRecursion(num: Int): Int {
    return if (num <= 1) {
        1
    } else {
        fibonacciUsingRecursion(num - 1) + fibonacciUsingRecursion(num - 2)
    }
}

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

fun main() {
    val count = readInt()
    println(fibonacciUsingRecursion(count))
}