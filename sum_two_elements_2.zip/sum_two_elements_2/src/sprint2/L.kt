package sprint2

import java.math.BigInteger

private fun fibonacciIteration(num: Int): BigInteger {
    if (num <= 1) {
        return BigInteger.ONE
    }
    var a = BigInteger.ONE
    var b = BigInteger.ONE
    var tmp: BigInteger = b
    for (idx in 2..num) {
        tmp = a.add(b)
        a = b
        b = tmp
    }
    return tmp
}

private fun fibonacciIterationModule(num: Int, pow: Int): Int {
    if (num <= 1) {
        return 1
    }
    var tenPow = 10
    for (idx in 1..pow) {
        if (idx != 1) {
            tenPow *= 10
        }
    }
    var a = 1
    var b = 1
    var tmp: Int = b
    for (idx in 2..num) {
        tmp = (a + b) % tenPow
        a = b
        b = tmp
    }
    return tmp
}

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main() {
    val listOfNumbers = readInts()
    println(fibonacciIterationModule(listOfNumbers[0], listOfNumbers[1]))
}