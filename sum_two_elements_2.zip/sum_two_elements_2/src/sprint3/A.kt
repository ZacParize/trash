package sprint3

private fun readStr() = readln()
private fun readInt() = readStr().toInt()

private fun genBinary(n: Int, prefix: String) {
    if (n == 0) {
        println(prefix)
    } else {
        genBinary(n - 1, prefix + "0")
        genBinary(n - 1, prefix + "1")
    }
}

private fun check(text: String): Boolean {
    var left = 0
    var right = 0
    for (symbol in text) {
        if (symbol == '(') {
            left++
        }
        if (symbol == ')') {
            right++
        }
        if (right > left) {
            return false
        }
    }
    return left == right
}

private fun genBrackets(n:Int, prefix: String) {
    if (n == 0) {
        if (check(prefix)) {
            println(prefix)
        }
    } else {
        genBrackets(n - 1, "$prefix(")
        genBrackets(n - 1, "$prefix)")
    }
}

private fun genBrackets(n: Int, left: Int, right: Int, prefix: String) {
    if (left == n && right == n) {
        println(prefix)
    }
    if (left < n) {
        genBrackets(n, left + 1, right, "$prefix(")
    }
    if (right < n && left > right) {
        genBrackets(n, left, right + 1, "$prefix)")
    }
}

fun main() {
    val n = readInt()
    val prefix = String()
    //genBrackets(n, prefix)
    genBrackets(n, 0, 0, prefix)
    //genBrackets(n * 2, result)

}