package sprint3

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }.toIntArray()

private fun bubble(array: IntArray) {
    val count = array.size
    var isPrinted = false
    for (idx in 0 until count - 1) {
        var isNeedSort = false
        for (jdx in 0 until count - idx - 1) {
            if (array[jdx] > array[jdx + 1]) {
                array[jdx + 1] = array[jdx] + array[jdx + 1]
                array[jdx] = array[jdx + 1] - array[jdx]
                array[jdx + 1] = array[jdx + 1] - array[jdx]
                isNeedSort = true
            }
        }
        if (!isNeedSort) {
            if (!isPrinted) {
                println(array.joinToString(" "))
            }
            break
        }
        isPrinted = true
        println(array.joinToString(" "))
    }
}

fun main() {
    val arrayCount = readInt()
    val unsortedArray = readInts()
    bubble(unsortedArray)
}