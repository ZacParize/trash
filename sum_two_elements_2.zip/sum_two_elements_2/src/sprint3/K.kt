package sprint3

private fun readStr() = readln()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun merge(arr: IntArray, left: Int, mid: Int, right: Int): IntArray {
    // заводим массив для результата сортировки
    val result = IntArray(right - left)

    // сливаем результаты
    var l = left
    var r = mid
    var k = 0
    while (l < mid && r < right) {
        // выбираем, из какого массива забрать минимальный элемент
        if (arr[l] <= arr[r]) {
            result[k] = arr[l]
            l += 1
        } else {
            result[k] = arr[r]
            r += 1
        }
        k += 1
    }

    // Если один массив закончился раньше, чем второй, то
    // переносим оставшиеся элементы второго массива в результирующий
    while (l < mid) {
        result[k] = arr[l]
        l += 1
        k += 1
    }
    while (r < right) {
        result[k] = arr[r]
        r += 1
        k += 1
    }

    return result
}

fun merge_sort(arr: IntArray, left: Int, right: Int) {
    if (right - left <= 1) {  // базовый случай рекурсии
        return
    }
    var delta = (right - left) / 2
    // запускаем сортировку рекурсивно на левой половине
    merge_sort(arr, left, left + delta)
    // запускаем сортировку рекурсивно на правой половине
    merge_sort(arr, left + delta, right)
    // мерджим
    val sortedArr = merge(arr, left, left + delta, right)
    System.arraycopy(sortedArr, 0, arr, left, sortedArr.size)
}

fun test() {
    val a = intArrayOf(1, 4, 9, 2, 10, 11)
    val b: IntArray = merge(a, 0, 3, 6)
    val expected = intArrayOf(1, 2, 4, 9, 10, 11)
    assert(b.contentEquals(expected))
    val c = intArrayOf(1, 4, 2, 10, 1, 2)
    merge_sort(c, 0, 6)
    val expected2 = intArrayOf(1, 1, 2, 2, 4, 10)
    assert(c.contentEquals(expected2))
}

fun main() {
    val array = readInts().toIntArray()
    merge_sort(array, 0, array.size)
    println(array.joinToString(" "))
}