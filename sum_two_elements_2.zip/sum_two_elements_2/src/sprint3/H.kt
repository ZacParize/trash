package sprint3

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")

fun compare(a: String, b: String): Boolean {
    return a + b > b + a
}

// воспользуемся уже знакомой сортировкой вставками
fun insertionSortByComparator(array: ArrayList<String>, function: (String, String) -> Boolean) {
    for (i in 1 until array.size) {
        val itemToInsert = array[i]
        var j = i
        while (j > 0 && function(itemToInsert, array[j - 1])) {
            array[j] = array[j - 1]
            j--
        }
        array[j] = itemToInsert
    }
    println(array.joinToString(""))
}

fun main() {
    val arrayCount = readInt()
    val array = readStrings()
    insertionSortByComparator(ArrayList(array), ::compare)
}