// https://contest.yandex.ru/contest/23815/run-report/104294622/
// Описание алгоритма: старый-добрый бинарный поиск с той лишь разницей, что мы долджны
// контролировать положение смещение кольцевого буфера
// Сложность алгоритма: O(log n)
package sprint3

import sprint3.Solution.brokenSearch

object Solution {

    fun brokenSearch(arr: IntArray, k: Int): Int {
        var startIndex = 0
        var lastIndex = arr.lastIndex
        while (startIndex <= lastIndex) {
            val middleIndex = (startIndex + lastIndex) / 2
            val left = arr[startIndex]
            val middle = arr[middleIndex]
            val right = arr[lastIndex]
            if (middle == k) {
                return middleIndex
            } else if (left <= middle) {
                if (k in left until middle) {
                    lastIndex = middleIndex - 1
                } else {
                    startIndex = middleIndex + 1
                }
            } else {
                if (k in (middle + 1)..right) {
                    startIndex = middleIndex + 1
                } else {
                    lastIndex = middleIndex - 1
                }
            }
        }
        return -1;
    }

}

fun main() {
    val arr = intArrayOf(15, 17, 90, 91, 2, 3, 5, 7, 13)
    val target = brokenSearch(arr, 5)
    println(target)
}