// https://contest.yandex.ru/contest/23815/run-report/104300059/
// Описание алгоритма: старая-добрая быстрая сортировка стой лишь разницей,
// что в данном варианте пространственная сложность будет O(n) (и в среднем, и в худшем)
// (отсутствуют издержки памяти на хранение отсортированных относительно опорного элемента левого и правого подмассива)
// Сложность алгоритма: худшая O(n^2), средняя O(n log n)
package sprint3

private fun readString() = readln()
private fun readInt() = readString().toInt()

data class Participant(val tasks: Int, val penalties: Int, val name: String)

fun<T> MutableList<T>.swap(firstIndex:Int,
                           secondIndex:Int) {
    val temp = this[firstIndex]
    this[firstIndex] = this[secondIndex]
    this[secondIndex] = temp
}

fun<T> partition(list: MutableList<T>,
                 comparator: Comparator<T>,
                 left: Int,
                 right: Int): Int {
    val pivot = list[left]
    var i = left + 1
    var j = right - 1
    while (i <= j) {
        while (i <= j && comparator.compare(list[i], pivot) < 0) {
            i++
        }
        while (i <= j && comparator.compare(list[j], pivot) > 0) {
            j--
        }
        if (i <= j) {
            list.swap(i, j)
        }
    }
    if (left != j) {
        list.swap(left, j)
    }
    return j
}

fun <T> quickSort(list: MutableList<T>,
                  comparator: Comparator<T>,
                  left: Int = 0,
                  right: Int = list.size) {
    if (left < right) {
        val pivot = partition(list, comparator, left, right)
        quickSort(list, comparator, left, pivot)
        quickSort(list, comparator, pivot + 1, right)
    }
}

private fun convert(string: String): Participant {
    val (name, tasks, penalties) = string.split(" ")
    return Participant(tasks.toInt(), penalties.toInt(), name)
}

fun main() {
    val repeatCount = readInt()
    val competitors = mutableListOf<Participant>()
    val comparator = compareByDescending<Participant> { it.tasks }
        .thenBy { it.penalties }
        .thenBy { it.name }
    repeat(repeatCount) {
        val inputString = readString()
        val participant = convert(inputString)
        competitors.add(participant)
    }
    quickSort(competitors, comparator)
    println(competitors.joinToString("\n") { it.name })
}