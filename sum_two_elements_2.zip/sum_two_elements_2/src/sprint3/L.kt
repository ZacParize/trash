package sprint3

import java.io.BufferedReader
import java.io.InputStreamReader

fun binarySearch(list: List<Int>, number: Int, left: Int, right: Int): Int {
    if (right <= left) {
        return -1
    }
    val mid: Int = (left + right) / 2
    return if (list[mid] == number ) {
        mid
    } else if (list[mid] > number) {
        binarySearch(list, number, left, mid)
    } else {
        binarySearch(list, number, mid + 1, right)
    }
}

fun binarySearchMod(list: List<Int>, number: Int, left: Int, right: Int): Int {
    if (list[left] >= number) {
        return left + 1
    }
    if (right <= left) {
        return -1
    }
    val mid: Int = (left + right) / 2
    return if (list[mid] < number) {
        binarySearchMod(list, number, mid + 1, right)
    } else {
        binarySearchMod(list, number, left, mid)
    }
}



fun main() {
    val reader = BufferedReader(InputStreamReader(System.`in`))
    val size = reader.readLine().toInt()
    val list = reader.readLine().split(" ").map { it.toInt() }
    val number = reader.readLine().toInt()
    val a = binarySearchMod(list, number, 0, list.size -1)
    val b = binarySearchMod(list, number * 2, kotlin.math.max(a, 0), list.size -1)
    println("$a $b")
}