package sprint3

import java.util.TreeMap
import kotlin.math.max
import kotlin.math.min

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

private fun checkSwap(left: Int, right: Int, oldLeft: Int, oldRight: Int): Boolean {
    return (left in oldLeft..oldRight) || (right in oldLeft..oldRight)
            || (left <= oldLeft && right >= oldRight)
}

private fun swap(map: TreeMap<Int, Int>, left: Int, right: Int, oldLeft: Int, oldRight: Int): Int {
    val newLeft = min(oldLeft, left)
    val newRight = max(oldRight, right)
    map.remove(oldLeft)
    map.remove(left)
    map[newLeft] = newRight
    return newLeft
}

fun main() {
    val count = readInt()
    val inputMap = TreeMap<Int, Int> { o1: Int, o2: Int -> o1.compareTo(o2) }

    for (idx in 1..count) {
        val values = readInts()
        val left = values[0]
        val right = values[1]
        inputMap[left] = right
    }

    val outputMap = TreeMap<Int, Int> { o1: Int, o2: Int -> o1.compareTo(o2) }
    var oldLeft = inputMap.entries.iterator().next().key
    var oldRight = inputMap.entries.iterator().next().value
    outputMap[oldLeft] = oldRight
    //var idx: Int = map.entries.indices.first
    for (entry in inputMap.entries) {
        val left = entry.key
        val right = entry.value
        if (checkSwap(left, right, oldLeft, oldRight)) {
            oldLeft = swap(outputMap, left, right, oldLeft, oldRight)
            oldRight = outputMap[oldLeft]?:0
        } else {
            outputMap[left] = right
            oldLeft = left
            oldRight = right
        }
    }
    for (e in outputMap) {
        println(e.key.toString() + ' ' + e.value.toString())
    }
}