package sprint3

private fun readStr() = readln()

private fun check(s: String, t: String): String {
    var s1 = s
    var s2 = t
    if (s1.length > s2.length) {
        s1 = t
        s2 = s
    }
    var idx = 0
    for (symbol in s2) {
        if (symbol == s1[idx]) {
            idx++
            if (idx == s1.length) {
                return "True"
            }
        }
    }
    return "False"
}

fun main() {
    val string1 = readStr()
    val string2 = readStr()

    println(check(string1, string2))
}