package sprint3

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun main() {
    val count = readInt()
    if (count == 0) {
        //println("0 0 0")
        return
    }
    val inputArray = readInts()
    val outputArray = IntArray(3)
    for (e in inputArray) {
        outputArray[e]++
    }

    val result = StringBuffer()
    for (idx in outputArray.indices) {
        val value = outputArray[idx]
        for (jdx in 0 until value) {
            if (result.isNotEmpty()) {
                result.append(' ')
            }
            result.append(idx)
        }
    }

    println(result.toString())
}