package sprint3

private fun readStr() = readln()
private fun readInt() = readStr().toInt()
private fun readStrings() = readStr().split(" ")
private fun readInts() = readStrings().map { it.toInt() }

fun solution(nArr: List<Int>, mArr: List<Int>): Int {
    val sortedGreed = nArr.sorted()
    val sortedCookie = mArr.sorted()
    var greedIndex = 0
    var cookieIndex = 0
    var count = 0
    while (greedIndex < sortedGreed.size && cookieIndex < sortedCookie.size) {
        while (greedIndex < sortedGreed.size && cookieIndex < sortedCookie.size
            && sortedCookie[cookieIndex] >= sortedGreed[greedIndex]) {
            count++
            greedIndex++
            cookieIndex++
        }
        if (greedIndex == sortedGreed.size - 1 && sortedCookie[cookieIndex] > sortedGreed[greedIndex]) {
            break
        }
        cookieIndex++
    }
    return count
}

fun merge(s: List<Int>): List<Int> {
    if (s.size == 1) {
        return listOf(s[0])
    }
    val middle = s.size / 2
    val a = merge(s.subList(0, middle))
    val b = merge(s.subList(middle, s.size))
    var aIndex = 0
    var bIndex = 0
    val result = ArrayList<Int>(s.size)
    while (aIndex < a.size || bIndex < b.size) {
        if (aIndex == a.size) {
            result.add(b[bIndex])
            bIndex++
            continue
        }
        if (bIndex == b.size) {
            result.add(a[aIndex])
            aIndex++
            continue
        }
        if (a[aIndex] <= b[bIndex]) {
            result.add(a[aIndex])
            aIndex++
        } else {
            result.add(b[bIndex])
            bIndex++
        }
    }
    return result
}

fun main() {
    val kidsCount = readInt()
    val kids: List<Int> = readInts()
    val cookiesCount = readInt()
    val cookies: List<Int>  = readInts()
    println(solution(kids, cookies))
}