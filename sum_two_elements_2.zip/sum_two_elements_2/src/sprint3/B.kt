package sprint3

import java.io.BufferedWriter
import java.io.OutputStreamWriter

private fun readStr() = readln()
val KEYS = mapOf(2 to "abc", 3 to "def", 4 to "ghi", 5 to "jkl", 6 to "mno", 7 to "pqrs", 8 to "tuv", 9 to "wxyz")
val OUTPUT_WRITER = BufferedWriter(OutputStreamWriter(System.out))
var IS_EMPTY_WRITER = true

private fun fill(text: String): List<String> {
    val result = ArrayList<String>(text.length)
    text.forEach { symbol ->
        val value = KEYS[symbol.digitToInt()]
        if (value != null) {
            result.add(value)
        }
    }
    return result
}

private fun generate(list: List<String>, cursor: Int, buffer: String) {
    if (buffer.length == list.size) {
        if (!IS_EMPTY_WRITER) {
            OUTPUT_WRITER.write(" ")
        }
        OUTPUT_WRITER.write(buffer)
        if (IS_EMPTY_WRITER) {
            IS_EMPTY_WRITER = false
        }
        return
    }
    if (cursor > list.size - 1) {
        return
    }
    for (symbol in list[cursor]) {
        generate(list, cursor + 1, buffer + symbol)
    }
}

fun main() {
    val input = readStr()
    val list = fill(input)
    generate(list, 0, "")
    OUTPUT_WRITER.flush()
}