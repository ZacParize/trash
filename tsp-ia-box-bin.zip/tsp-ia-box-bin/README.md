Internet acquiring, box, bin service

Installation instructions:

1) Clone environment project:

   git clone https://bitbucket.region.vtb.ru/scm/efcp/tsp-ia-box-environment.git

2) Clone the project:

   git clone https://bitbucket.region.vtb.ru/scm/efcp/tsp-ia-box-bin.git

3) Launch environment:

   cd tsp-ia-box-environment/docker

   docker-compose stop && docker-compose up -d

4) Launch bin service