plugins {
    idea
    base
    java
    application
    `maven-publish`
    //checkstyle
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")
apply(plugin = "io.spring.dependency-management")

val toolDir = "${project.buildDir}/tools"
val toolDependency by configurations.compileOnly
toolDependency.isCanBeResolved = true

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {

    // Core lib
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")

    //Apache components
    implementation("org.apache.commons:commons-pool2")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")

    // Spring components
    implementation("org.springframework.boot:spring-boot-starter-integration")
    implementation("org.springframework.boot:spring-boot-starter-data-redis")
    implementation("org.springframework.boot:spring-boot-starter-validation")
    implementation("org.springframework.boot:spring-boot-starter-webflux:2.6.4")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    //Reactive Feign Dependencies
    implementation("com.playtika.reactivefeign:feign-reactor-webclient:3.2.6")
    //implementation("com.playtika.reactivefeign:feign-reactor-cloud2:3.2.6")
    //implementation("com.playtika.reactivefeign:feign-reactor-spring-configuration:3.2.6")
    runtimeOnly("org.springframework.boot:spring-boot-starter-undertow")

    // Validation
    implementation("javax.validation:validation-api")

    // Tracing
    implementation("io.opentracing.contrib:opentracing-spring-jaeger-cloud-starter")

    // Logging
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("com.vlkan.log4j2:log4j2-logstash-layout")
    implementation("ru.vtb.infra.logging:log4j2-integration")

    // audit
    /*implementation("ru.vtb.omni:audit-lib-servlet-context")
    implementation("ru.vtb.omni:audit-lib-db-storage")
    implementation("ru.vtb.omni:audit-lib-kafka-sender")
    implementation("ru.vtb.omni:audit-lib-freemarker-template-resolver")*/

    //Monitoring
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    implementation("io.micrometer:micrometer-registry-prometheus")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testImplementation("org.junit.jupiter:junit-jupiter-params")
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:kafka")
    testImplementation("org.testcontainers:postgresql")
    testImplementation("org.testcontainers:junit-jupiter")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

var appMainClass = "ru.vtb.tsp.ia.epay.bin.App"

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set(appMainClass)
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            artifact("build/libs/${project.name}.jar")
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.jar {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
    manifest {
        attributes["Main-Class"] = appMainClass
    }
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
}

val extractToolsDependency by tasks.register<Copy>("extractToolsDependency") {
    dependsOn(toolDependency)
    from(toolDependency.map {
        zipTree(it)
    })
    include("config/**")
    into(toolDir)
    includeEmptyDirs = false
}

tasks.withType<Checkstyle>().configureEach {
    dependsOn(extractToolsDependency)
    reports {
        xml.required.set(false)
        html.required.set(true)
    }
}

/*checkstyle {
    maxWarnings = 0
    isShowViolations = true
    isIgnoreFailures = false
    toolVersion = "9.3"
    configFile = file("${toolDir}/config/checkstyle/checkstyle.xml")
}*/

idea {
    // Download javadoc and sources
    module {
        isDownloadSources = true
        isDownloadJavadoc = true
    }
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
        property("sonar.exclusions", "src/main/resources/**/*," +
                "ru/vtb/tsp/ia/epay/notificator/**/*Dto.java," +
                "ru/vtb/tsp/ia/epay/notificator/**/*Abstract*.java," +
                "ru/vtb/tsp/ia/epay/notificator/**/*Config.java," +
                "ru/vtb/tsp/ia/epay/notificator/configs/**/*.java" +
                "ru/vtb/tsp/ia/epay/notificator/domain/*.java" +
                "ru/vtb/tsp/ia/epay/notificator/exceptions/*.java" +
                "ru/vtb/tsp/ia/epay/notificator/App.java" +
                "**/*.yaml," +
                "**/*.yml," +
                "**/*.xml")
    }
}