package ru.vtb.tsp.ia.epay.merchant;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;
import ru.vtb.tsp.ia.epay.merchant.implementations.MerchantClientImpl;
import ru.vtb.tsp.ia.epay.merchant.implementations.MerchantSiteClientImpl;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;

@Slf4j
@Component
public class MerchantApiClientImpl implements MerchantApiClient {

  public static final String MERCHANT_REST_TEMPLATE = "merchantRestTemplate";
  public static final String MERCHANT_SITE_REST_TEMPLATE = "merchantSiteRestTemplate";
  public static final String MERCHANT_CLIENT_MAPPER = "merchantClientMapper";

  private final MerchantClientImpl merchantClient;
  private final MerchantSiteClientImpl merchantSiteClient;
  private final ObjectMapper objectMapper;

  public MerchantApiClientImpl(@Qualifier(MERCHANT_REST_TEMPLATE) RestTemplate merchantRestTemplate,
                               @Qualifier(MERCHANT_SITE_REST_TEMPLATE) RestTemplate merchantSiteRestTemplate,
                               @Qualifier(MERCHANT_CLIENT_MAPPER) ObjectMapper objectMapper,
                               @Value("${app.merchants.host}") @NotEmpty String host) {
    this.merchantClient = new MerchantClientImpl(merchantRestTemplate, host);
    this.merchantSiteClient = new MerchantSiteClientImpl(merchantSiteRestTemplate, host);
    this.objectMapper = objectMapper;
  }

  @Override
  public @NotEmpty Optional<MerchantDto> getMerchant(@Nullable String id) {
    final var response = merchantClient.get(id);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public @NotEmpty List<MerchantDto> getMerchants(@Nullable MerchantFilter filter,
      @Nullable Pageable pageable) {
    final var response = merchantClient.getAll(filter, pageable);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Collections.emptyList();
    }
    return response.getBody();
  }

  @Override
  public @NotNull Optional<MerchantDto> createMerchant(@Nullable MerchantDto data) {
    final var response = merchantClient.create(data);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public @NotEmpty Optional<MerchantSiteDto> getMerchantSite(@Nullable String mstId) {
    final var response = merchantSiteClient.get(mstId);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public Optional<ResponseEntity<MerchantSiteCheckHostDto>> getMerchantSiteLogin(@Nullable String mstId, @Nullable String mstUrl) {
    final var response = merchantSiteClient.getMerchantSiteCheckHost(mstId, mstUrl);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response);
  }

  @Override
  public @NotNull List<MerchantSiteDto> getMerchantSites(@Nullable MerchantSiteFilter filter,
      @Nullable Pageable pageable) {
    final var response = merchantSiteClient.getAll(filter, pageable);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Collections.emptyList();
    }
    return response.getBody();
  }

  @Override
  public @NotNull Optional<MerchantSiteDto> createMerchantSite(@Nullable MerchantSiteDto data) {
    final var response = merchantSiteClient.create(data);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public @NotNull Optional<MerchantSiteDto> updateMerchantSite(@Nullable String mstId,
      @Nullable MerchantSiteDto data) {
    final String source;
    try {
      source = objectMapper.writeValueAsString(data);
    } catch (JsonProcessingException ex) {
      log.error("Error occurred during update merchant site {}, {}", mstId, data, ex);
      return Optional.empty();
    }
    final var response = merchantSiteClient.update(mstId, source);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public Optional<MerchantSiteDto> block(@Nullable String mstId) {
    final var response = merchantSiteClient.block(mstId);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }

  @Override
  public Optional<MerchantSiteDto> unblock(@Nullable String mstId) {
    final var response = merchantSiteClient.unblock(mstId);
    if (!response.hasBody() || !response.getStatusCode().is2xxSuccessful()) {
      return Optional.empty();
    }
    return Optional.ofNullable(response.getBody());
  }
}