package ru.vtb.tsp.ia.epay.merchant;

import java.util.List;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;

public interface MerchantApiClient {

  @NotNull Optional<MerchantDto> getMerchant(@Nullable String id);

  @NotNull List<MerchantDto> getMerchants(@Nullable MerchantFilter filter,
      @Nullable Pageable pageable);

  @NotNull Optional<MerchantDto> createMerchant(@Nullable MerchantDto data);

  @NotNull Optional<MerchantSiteDto> getMerchantSite(@Nullable String mstId);

  @NotNull Optional<ResponseEntity<MerchantSiteCheckHostDto>> getMerchantSiteLogin(@Nullable String mstId, @Nullable String mstUrl);

  @NotNull List<MerchantSiteDto> getMerchantSites(@Nullable MerchantSiteFilter filter,
      @Nullable Pageable pageable);

  @NotNull Optional<MerchantSiteDto> createMerchantSite(@Nullable MerchantSiteDto data);

  @NotNull Optional<MerchantSiteDto> updateMerchantSite(@Nullable String mstId,
      @Nullable MerchantSiteDto data);

  @NotNull Optional<MerchantSiteDto> block(@Nullable String mstId);

  @NotNull Optional<MerchantSiteDto> unblock(@Nullable String mstId);

}