package ru.vtb.tsp.ia.epay.merchant.implementations;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.util.UriComponentsBuilder;
import ru.vtb.tsp.ia.epay.merchant.MerchantControllerApi;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;

@RequiredArgsConstructor
public class MerchantClientImpl implements MerchantControllerApi {

  private static final String ID = "id";
  private static final String NAME = "name";
  private static final String MDMCODE = "mdmCode";
  private static final String STATE = "state";
  private static final String SORT = "sort";
  private static final String OFFSET = "offset";
  private static final String PAGENUM = "pageNumber";
  private static final String PAGESIZE = "pageSize";
  private static final String MERCHANTS_PATH = "/api/v1/merchants";

  private final RestTemplate restTemplate;
  private final String host;

  @Override
  public @NotEmpty ResponseEntity<MerchantDto> get(@Nullable String id) {
    if (ObjectUtils.isEmpty(id)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANTS_PATH + "/" + id).build().toUriString(),
        HttpMethod.GET,
        entity,
        MerchantDto.class
    );
  }

  @Override
  public @NotEmpty ResponseEntity<List<MerchantDto>> getAll(@Nullable MerchantFilter filter,
      @Nullable Pageable pageable) {
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(headers);
    var builder = UriComponentsBuilder.fromHttpUrl(host + MERCHANTS_PATH);
    if (Objects.nonNull(filter)) {
      builder = builder.queryParam(NAME, filter.getName())
          .queryParam(ID, filter.getId())
          .queryParam(MDMCODE, filter.getMdmCode())
          .queryParam(STATE, filter.getState());
    }
    if (Objects.nonNull(pageable)) {
      builder = builder.queryParam(SORT, pageable.getSort().toString().replaceAll(":", ","))
          .queryParam(OFFSET, pageable.getOffset())
          .queryParam(PAGENUM, pageable.getPageNumber())
          .queryParam(PAGESIZE, pageable.getPageSize());
    }
    return ResponseEntity.ok(Arrays.asList(Objects.requireNonNull(restTemplate.exchange(
        builder.build().toUriString(),
        HttpMethod.GET,
        entity,
        MerchantDto[].class
    ).getBody())));
  }

  @Override
  public @NotNull ResponseEntity<MerchantDto> create(@Nullable MerchantDto data) {
    if (ObjectUtils.isEmpty(data)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(data, headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANTS_PATH).build().toUriString(),
        HttpMethod.POST,
        entity,
        MerchantDto.class
    );
  }

  @Override
  public ResponseEntity<MerchantDto> update(String merchantId, String source) {
    throw new MethodNotAllowedException("Method merchant api update is not implemented in client",
        Collections.emptySet());
  }

  @Override
  public ResponseEntity<MerchantDto> patch(String merchantId, String source) {
    throw new MethodNotAllowedException("Merchant api patch method is not implemented in client",
        Collections.emptySet());
  }

  @Override
  public void delete(String merchantId) {
    throw new MethodNotAllowedException("Merchant api delete method is not implemented in client",
        Collections.emptySet());
  }

  @Override
  public ResponseEntity<MerchantDto> block(String merchantId) {
    throw new MethodNotAllowedException("Merchant api block method is not implemented in client",
        Collections.emptySet());
  }

  @Override
  public ResponseEntity<MerchantDto> unblock(String merchantId) {
    throw new MethodNotAllowedException("Merchant api unblock method is not implemented in client",
        Collections.emptySet());
  }

}