package ru.vtb.tsp.ia.epay.merchant.implementations;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.util.UriComponentsBuilder;
import ru.vtb.tsp.ia.epay.merchant.sites.MerchantSiteControllerApi;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

@RequiredArgsConstructor
public class MerchantSiteClientImpl implements MerchantSiteControllerApi {

  private static final String MST_ID = "mstId";
  private static final String MERCHANT_ID = "merchantId";
  private static final String NAME = "name";
  private static final String MDMCODE = "mdmCode";
  private static final String LOGIN = "login";
  private static final String STATE = "state";
  private static final String SORT = "sort";
  private static final String OFFSET = "offset";
  private static final String PAGENUM = "pageNumber";
  private static final String PAGESIZE = "pageSize";
  private static final String MERCHANT_SITES_PATH = "/api/v1/sites";
  private static final String PATH_MST_CHECK_HOST = "/check-host";
  private static final String MST_URL_REQUEST_PARAM = "mstUrl";
  private static final String BLOCK = "/block";
  private static final String UNBLOCK = "/unblock";
  private static final String MERCHANT_SITE_PARAMS_PATH = "/params";

  private final RestTemplate restTemplate;
  private final String host;

  @Override
  public @NotEmpty ResponseEntity<MerchantSiteDto> get(@Nullable String mstId) {
    if (ObjectUtils.isEmpty(mstId)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH + "/" + mstId).build()
            .toUriString(),
        HttpMethod.GET,
        entity,
        MerchantSiteDto.class
    );
  }

  @Override
  public ResponseEntity<MerchantSiteCheckHostDto> getMerchantSiteCheckHost(@Nullable String mstId,
                                                                           @Nullable String mstUrl) {
    if (ObjectUtils.isEmpty(mstId)||ObjectUtils.isEmpty(mstUrl)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    headers.add("merchant_authorization", mstId);
    final var entity = new HttpEntity<>(headers);
    return restTemplate.exchange(
            UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH
                  + PATH_MST_CHECK_HOST).queryParam(MST_URL_REQUEST_PARAM, mstUrl).build()
                    .toUriString(),
            HttpMethod.GET,
            entity,
            MerchantSiteCheckHostDto.class
    );
  }

  @Override
  public @NotNull ResponseEntity<List<MerchantSiteDto>> getAll(@Nullable MerchantSiteFilter filter,
      @Nullable Pageable pageable) {
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(headers);
    var builder = UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH);
    if (Objects.nonNull(filter)) {
      builder = builder.queryParam(NAME, filter.getName())
          .queryParam(MST_ID, filter.getMstId())
          .queryParam(MERCHANT_ID, filter.getMerchantId())
          .queryParam(LOGIN, filter.getLogin())
          .queryParam(MDMCODE, filter.getMdmCode())
          .queryParam(STATE, filter.getState());
    }
    if (Objects.nonNull(pageable)) {
      builder = builder.queryParam(SORT, pageable.getSort().toString().replaceAll(":", ","))
          .queryParam(OFFSET, pageable.getOffset())
          .queryParam(PAGENUM, pageable.getPageNumber())
          .queryParam(PAGESIZE, pageable.getPageSize());
    }
    return ResponseEntity.ok(Arrays.asList(Objects.requireNonNull(restTemplate.exchange(
        builder.build().toUriString(),
        HttpMethod.GET,
        entity,
        MerchantSiteDto[].class
    ).getBody())));
  }

  @Override
  @Deprecated
  public @NotNull ResponseEntity<List<MerchantSiteDto>> getAllMock(@Nullable MerchantSiteFilter filter,
       @Nullable Pageable pageable) throws IOException {
    return getAll(filter, pageable);
  }

  @Override
  public @NotNull ResponseEntity<MerchantSiteDto> create(@Nullable MerchantSiteDto data) {
    if (ObjectUtils.isEmpty(data)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final var entity = new HttpEntity<>(data, headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH).build().toUriString(),
        HttpMethod.POST,
        entity,
        MerchantSiteDto.class
    );
  }

  @Override
  public @NotNull ResponseEntity<MerchantSiteDto> update(@Nullable String mstId,
      @Nullable String source) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(source)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final HttpEntity<String> entity = new HttpEntity<>(source, headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH + "/" + mstId).build()
            .toUriString(),
        HttpMethod.PATCH,
        entity,
        MerchantSiteDto.class
    );
  }

  @Override
  public ResponseEntity<MerchantSiteDto> patch(@Nullable String mstId, @Nullable String source) {
    return update(mstId, source);
  }

  @Override
  public void delete(String mstId) {
    throw new MethodNotAllowedException("Merchant site api delete method is not implemented in client",
        Collections.emptySet());
  }

  @Override
  public ResponseEntity<MerchantSiteDto> block(String mstId) {
    if (ObjectUtils.isEmpty(mstId)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final HttpEntity<String> entity = new HttpEntity<>(headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH + "/" + mstId + BLOCK).build()
            .toUriString(),
        HttpMethod.POST,
        entity,
        MerchantSiteDto.class
    );
  }

  @Override
  public ResponseEntity<MerchantSiteDto> unblock(String mstId) {
    if (ObjectUtils.isEmpty(mstId)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final HttpEntity<String> entity = new HttpEntity<>(headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH + "/" + mstId + UNBLOCK).build()
            .toUriString(),
        HttpMethod.POST,
        entity,
        MerchantSiteDto.class
    );
  }

  @Override
  public ResponseEntity<MerchantSiteParamsDto> updateParams(@Nullable String mstId,
      @Nullable String source) {
    if (ObjectUtils.isEmpty(mstId) || ObjectUtils.isEmpty(source)) {
      return ResponseEntity.badRequest().build();
    }
    final var headers = new HttpHeaders();
    headers.setContentType(MediaType.APPLICATION_JSON);
    headers.setAccept(List.of(MediaType.APPLICATION_JSON));
    final HttpEntity<String> entity = new HttpEntity<>(source, headers);
    return restTemplate.exchange(
        UriComponentsBuilder.fromHttpUrl(host + MERCHANT_SITES_PATH + "/"
                + mstId + MERCHANT_SITE_PARAMS_PATH).build()
            .toUriString(),
        HttpMethod.PATCH,
        entity,
        MerchantSiteParamsDto.class
    );
  }

}