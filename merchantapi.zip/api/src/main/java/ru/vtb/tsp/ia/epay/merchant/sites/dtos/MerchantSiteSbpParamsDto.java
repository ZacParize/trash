package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteSbpParamsDto implements Serializable {

  private boolean enableSbpPayment;
  private boolean enablePartialRefund;
  private String merchantId;
  private String legalId;
  private String account;
  private String templateVersion;
  private String qrcType;
  private String paymentPurpose;
  private String refundPurpose;

}