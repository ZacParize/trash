package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteParamsDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";

  private String mcc;
  private String callbackUrl;
  @JsonFormat(shape = Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime callbackUrlModified;
  private MerchantSiteSbpParamsDto sbpParams;
  private MerchantSiteCardParamsDto cardParams;
  private MerchantSiteTransferParamsDto transferParams;
  private MerchantSiteFiscalParamsDto fiscalParams;
  @JsonInclude
  private MerchantSiteApiConnectionParamsDto apiConnectionParams;
}