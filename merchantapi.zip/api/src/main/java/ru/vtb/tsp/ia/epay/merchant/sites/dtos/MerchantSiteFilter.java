package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteFilter implements Serializable {

  private Set<String> mstId;
  private Set<String> merchantId;
  private Set<String> login;
  private String name;
  private Long mdmCode;
  private Set<String> state;

}