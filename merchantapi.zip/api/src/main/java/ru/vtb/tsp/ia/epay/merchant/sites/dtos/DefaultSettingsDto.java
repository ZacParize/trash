package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import javax.annotation.Nullable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.merchant.enums.PaymentType;
import ru.vtb.tsp.ia.epay.merchant.enums.ProductType;
import ru.vtb.tsp.ia.epay.merchant.enums.TaxRate;
import ru.vtb.tsp.ia.epay.merchant.enums.TaxSystem;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DefaultSettingsDto {

  @Nullable
  private TaxSystem taxSystem;
  @Nullable
  private TaxRate taxRate;
  @Nullable
  private ProductType productType;
  @Nullable
  private PaymentType paymentType;
  @Nullable
  private String productName;

}