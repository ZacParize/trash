package ru.vtb.tsp.ia.epay.merchant.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ApiAccessState {
  INITIAL,
  CREATED_PROGRESS,
  CREATED,
  NOT_CREATED,
  SIGNED_PROGRESS,
  SIGNED,
  NOT_SIGNED
}
