package ru.vtb.tsp.ia.epay.merchant;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;

public interface MerchantControllerApi {

  int DEFAULT_PAGE_SIZE = 100;

  @Operation(summary = "Create merchant", description = "Create merchant from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantDto.class))
  })
  @NotNull ResponseEntity<MerchantDto> create(MerchantDto source);

  @Operation(summary = "Get merchant by ID", description = "Get merchant by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantDto.class))
  })
  @NotNull ResponseEntity<MerchantDto> get(String merchantId);

  @Operation(summary = "Get list of merchants", description = "Get list of merchants")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantDto.class))
  })
  @NotNull ResponseEntity<List<MerchantDto>> getAll(MerchantFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable);

  @Operation(summary = "Update merchant", description = "Update merchant from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantDto.class))
  })
  @NotNull ResponseEntity<MerchantDto> update(String merchantId, String source);

  @Operation(summary = "Update merchant", description = "Update merchant from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantDto.class))
  })
  @NotNull ResponseEntity<MerchantDto> patch(String merchantId, String source);

  @Operation(summary = "Delete merchant", description = "Delete merchant by ID")
  @ApiResponse(responseCode = "204", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  void delete(String merchantId);

  @Operation(summary = "Block merchant", description = "Block merchant by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  ResponseEntity<MerchantDto> block(String merchantId);

  @Operation(summary = "Unblock merchant", description = "Unblock merchant by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  ResponseEntity<MerchantDto> unblock(String merchantId);
}