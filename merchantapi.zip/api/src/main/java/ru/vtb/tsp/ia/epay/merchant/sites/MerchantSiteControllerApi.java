package ru.vtb.tsp.ia.epay.merchant.sites;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import java.io.IOException;
import java.util.List;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

public interface MerchantSiteControllerApi {

  int DEFAULT_PAGE_SIZE = 100;

  @Operation(summary = "Create merchant site", description = "Create merchant site from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteDto.class))
  })
  @NotNull ResponseEntity<MerchantSiteDto> create(MerchantSiteDto source);

  @Operation(summary = "Get merchant site by ID", description = "Get merchant site by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteDto.class))
  })
  @NotNull ResponseEntity<MerchantSiteDto> get(String mstId);

  @Operation(summary = "Get merchant site login by ID and host", description = "Get merchant site login by ID and host")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteCheckHostDto.class))
  })
  @NotNull ResponseEntity<MerchantSiteCheckHostDto> getMerchantSiteCheckHost(String mstId,
      String mstUrl);

  @Operation(summary = "Get list of merchant sites", description = "Get list of merchant sites")
  @NotNull ResponseEntity<List<MerchantSiteDto>> getAll(@NotNull MerchantSiteFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable);

  @Operation(summary = "Get list of merchant sites V2", description = "Get list of merchant sites V2")
  @Deprecated
  @NotNull ResponseEntity<List<MerchantSiteDto>> getAllMock(@NotNull MerchantSiteFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable) throws IOException;

  @Operation(summary = "Update merchant site", description = "Update merchant site from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteDto.class))
  })
  @NotNull ResponseEntity<MerchantSiteDto> update(String mstId, String source);

  @Operation(summary = "Update merchant site", description = "Update merchant site from JSON")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteDto.class))
  })
  @NotNull ResponseEntity<MerchantSiteDto> patch(String mstId, String source);

  @Operation(summary = "Delete merchant site", description = "Delete merchant site by ID")
  @ApiResponse(responseCode = "204", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  void delete(String mstId);

  @Operation(summary = "Block merchant site", description = "Block merchant site by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  ResponseEntity<MerchantSiteDto> block(String mstId);

  @Operation(summary = "Unblock merchant site", description = "Unblock merchant site by ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema())
  })
  ResponseEntity<MerchantSiteDto> unblock(String mstId);

  @Operation(summary = "Update params by merchant site ID", description = "Patch params by merchant site ID")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = MerchantSiteDto.class))
  })
  ResponseEntity<MerchantSiteParamsDto> updateParams(String mstId, String source);

}