package ru.vtb.tsp.ia.epay.merchant.enums;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum MerchantSiteStateDto {

  @JsonProperty("Draft")
  DRAFT,
  @JsonProperty("Not Active")
  NOT_ACTIVE,
  @JsonProperty("Active")
  ACTIVE,
  @JsonProperty("Deleted")
  DELETED,
  @JsonProperty("Blocked")
  BLOCKED

}