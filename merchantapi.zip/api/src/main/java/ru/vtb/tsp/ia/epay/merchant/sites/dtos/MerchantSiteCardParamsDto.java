package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteCardParamsDto implements Serializable {

  private boolean enableCardPayment;
  private boolean enableTwoStage;
  private boolean enablePartialRefund;
  private boolean enableCardFlowThreeDS;
  private boolean enableCardFlowThreeDSOnMerchantSide;
  private boolean enableGooglePayment;
  private boolean enableApplePayment;
  private boolean enablePaymentCheckboxesVisible;
  private String merchantId;
  private String terminalId;
  private String merchantName;

}