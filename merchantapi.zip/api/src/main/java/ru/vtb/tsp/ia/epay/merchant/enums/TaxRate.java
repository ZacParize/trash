package ru.vtb.tsp.ia.epay.merchant.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum TaxRate {

  VAT_GENERAL,
  VAT_PREFERENTIAL,
  VAT_GENERAL_CALC,
  VAT_PREFERENTIAL_CALC,
  VAT_ZERO,
  NONE;

}
