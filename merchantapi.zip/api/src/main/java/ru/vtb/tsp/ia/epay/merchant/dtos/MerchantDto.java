package ru.vtb.tsp.ia.epay.merchant.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.merchant.enums.MerchantStateDto;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

  private String id;
  private MerchantStateDto state;
  @JsonFormat(shape = Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime created;
  @JsonFormat(shape = Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime modified;
  private Long mdmCode;
  private String name;

}