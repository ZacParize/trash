package ru.vtb.tsp.ia.epay.merchant;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import javax.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.OfdPublicKeyDto;


public interface MerchantPublicKeyApi {


  @Operation(summary = "Get ofd public key", description = "Get ofd public key")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = OfdPublicKeyDto.class))
  })
  @NotNull ResponseEntity<OfdPublicKeyDto> getPublicKey();

}
