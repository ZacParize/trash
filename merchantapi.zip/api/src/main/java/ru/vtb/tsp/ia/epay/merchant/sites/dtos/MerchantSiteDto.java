package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.merchant.enums.MerchantSiteStateDto;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantSiteDto implements Serializable {

  private static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss.SSS";

  private String id;
  private MerchantSiteStateDto state;
  @JsonFormat(shape = Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime created;
  @JsonFormat(shape = Shape.STRING, pattern = DATE_TIME_FORMAT)
  private LocalDateTime modified;
  private String merchantId;
  private String url;
  private String name;
  private String type;
  private String login;
  private String externalApplicationId;
  private MerchantSiteParamsDto params;

}