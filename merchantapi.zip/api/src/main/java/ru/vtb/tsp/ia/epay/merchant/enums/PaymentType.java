package ru.vtb.tsp.ia.epay.merchant.enums;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum PaymentType {

  FULL_PREPAYMENT,
  PARTIAL_PREPAYMENT,
  ADVANCE,
  FULL_PAYMENT,
  PARTIAL_PAYMENT,
  CREDIT,
  CREDIT_PAYMENT;

}
