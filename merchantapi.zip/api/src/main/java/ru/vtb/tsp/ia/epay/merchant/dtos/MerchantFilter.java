package ru.vtb.tsp.ia.epay.merchant.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MerchantFilter {

  private Set<String> id;
  private Set<Long> mdmCode;
  private String name;
  private Set<String> state;

}