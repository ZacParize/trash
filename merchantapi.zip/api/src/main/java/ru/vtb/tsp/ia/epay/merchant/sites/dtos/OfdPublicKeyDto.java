package ru.vtb.tsp.ia.epay.merchant.sites.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class OfdPublicKeyDto {

  @JsonProperty("ofdPublicKey")
  @NotNull
  private String ofdPublicKey;

  @JsonProperty("version")
  @NotNull
  private Integer version;
}
