package ru.vtb.tsp.ia.epay.merchant.services.feigns.clients;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.merchant.services.feigns.MerchantPublicKeyApiClient;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.OfdPublicKeyDto;

@Slf4j
@Component
@RequiredArgsConstructor
@ConditionalOnProperty(name = "app.fiscalization-domain.mock", havingValue = "true")
public class FiscalizationPublicKeyApiClientMock implements MerchantPublicKeyApiClient {

  private static final String PUBLIC_KEY = """
      MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAm458nRmUzyerTUkKO62AVLEoezOqPqtlcl+CCpTxSOGZRP6
      CrdLuXs6fm9cM8+8EaP5O6GIy7a/2xUt2UjrGY42IsC/fj5rzxDVKNIJo2B0UKT+SkBG/zObZJfwzq6pxtLX/XwMdXC
      Kxg+soziaAKuhhWmZilLMqZ3DLq5hXEz3Um38EBAJ/YZw45Hg/bbMOcGtHVUBRzX6thE6ImjTf5QXueVdaDsISVF95l
      iz0zlo8GOvzygKUSSUABu560tfSmv2YYtI4jpEHLSC9EIpd+KGX7sKqNACGDEEQ4o9h2wGSOlyfQOXiwpnrJPA2t7dL
      oAeU9Smf5ZT2wtkzHImF3QIDAQAB
      """;

  public ResponseEntity<OfdPublicKeyDto> getPublicKey() {
    return ResponseEntity.ok(OfdPublicKeyDto.builder()
        .ofdPublicKey(PUBLIC_KEY)
        .version(1)
        .build());
  }

}
