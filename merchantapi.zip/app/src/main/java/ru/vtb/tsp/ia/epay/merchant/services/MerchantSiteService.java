package ru.vtb.tsp.ia.epay.merchant.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;

public interface MerchantSiteService {

  MerchantSiteHE getMerchantSite(String mstId);

  Page<MerchantSiteHE> getMerchantSites(MerchantSiteFilter filter,
      Pageable pageable);

  MerchantSite createMerchantSite(MerchantSite source);

  MerchantSite updateMerchantSite(String mstId, String source);

  void deleteMerchantSite(String mstId);

  MerchantSite blockMerchantSite(String mstId);

  MerchantSite unblockMerchantSite(String mstId);

  MerchantSiteCheckHostDto getCheckHostDto(String mstId, String mstUrl);

  MerchantSiteParams updateMerchantSiteParams(String mstId, String source);

}
