package ru.vtb.tsp.ia.epay.merchant.config;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "app.ssl")
public class SSLProperties {

  private boolean enabled;
  private String url;
  private String truststorePath;
  private String truststorePass;
  private String keystorePath;
  private String keystorePass;
  private boolean clientAuth;
  private boolean certValidation;

}