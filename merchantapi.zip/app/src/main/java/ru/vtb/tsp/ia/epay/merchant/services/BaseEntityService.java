package ru.vtb.tsp.ia.epay.merchant.services;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Validator;
import ru.vtb.tsp.ia.epay.core.domains.TransactionalObject;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantState;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;
import ru.vtb.tsp.ia.epay.merchant.data.repository.MerchantRepository;
import ru.vtb.tsp.ia.epay.merchant.data.repository.MerchantSiteRepository;
import ru.vtb.tsp.ia.epay.merchant.exception.InvalidDataException;
import ru.vtb.tsp.ia.epay.merchant.exception.MerchantDeletedException;
import ru.vtb.tsp.ia.epay.merchant.exception.MerchantSiteDeletedException;
import ru.vtb.tsp.ia.epay.merchant.exception.ObjectBlockedException;
import ru.vtb.tsp.ia.epay.merchant.exception.ObjectNotFoundException;


public abstract class BaseEntityService<T extends TransactionalObject> {

  public static final String MERCHANT_NOT_FOUND = "Merchant '%s' is not found";
  public static final String MERCHANT_SITE_NOT_FOUND = "MerchantSite '%s' is not found";
  public static final String MERCHANT_NOT_EXISTS = "Merchant '%s' does not exists";

  @Autowired
  protected Validator validator;

  @Autowired
  protected MerchantRepository merchantRepository;

  @Autowired
  protected @Qualifier(MerchantSiteRepository.BEAN_NAME)
  MerchantSiteRepository merchantSiteRepository;

  protected ObjectMapper updateObjectMapper;

  @Autowired
  public void setUpdateObjectMapper(ObjectMapper objectMapper) {
    this.updateObjectMapper = objectMapper.copy()
        .setSerializationInclusion(Include.ALWAYS)
        .disable(MapperFeature.DEFAULT_VIEW_INCLUSION)
        .setDefaultMergeable(true);
    this.updateObjectMapper.configOverride(List.class).setMergeable(false);
    this.updateObjectMapper.configOverride(Set.class).setMergeable(false);
  }

  protected MerchantHE getRequiredMerchantById(String merchantId) {
    return merchantRepository.findById(merchantId)
        .orElseThrow(
            () -> new ObjectNotFoundException(String.format(MERCHANT_NOT_FOUND, merchantId))
        );
  }

  protected MerchantSiteHE getRequiredMerchantSiteById(String mstId) {
    return merchantSiteRepository.findById(mstId)
        .orElseThrow(
            () -> new ObjectNotFoundException(String.format(MERCHANT_SITE_NOT_FOUND, mstId))
        );
  }

  protected MerchantHE getActualMerchantById(String merchantId) {
    MerchantHE he = getRequiredMerchantById(merchantId);
    if (MerchantState.BLOCKED.equals(he.getEntity().getState())) {
      throw new ObjectBlockedException();
    }
    if (MerchantState.DELETED.equals(he.getEntity().getState())) {
      throw new MerchantDeletedException();
    }
    return he;
  }

  protected MerchantSiteHE getActualMerchantSiteById(String mstId) {
    MerchantSiteHE he = getRequiredMerchantSiteById(mstId);
    if (MerchantSiteState.BLOCKED.equals(he.getEntity().getState())) {
      throw new ObjectBlockedException();
    }
    if (MerchantSiteState.DELETED.equals(he.getEntity().getState())) {
      throw new MerchantSiteDeletedException();
    }
    return he;
  }

  protected MerchantSiteHE getMerchantSiteByIdExceptDeleted(String mstId) {
    MerchantSiteHE he = getRequiredMerchantSiteById(mstId);
    if (MerchantSiteState.DELETED.equals(he.getEntity().getState())) {
      throw new MerchantSiteDeletedException();
    }
    return he;
  }

  protected void checkMerchantExistence(String merchantId) {
    if (!merchantRepository.existsById(merchantId)) {
      throw new ObjectNotFoundException(String.format(MERCHANT_NOT_EXISTS, merchantId));
    }
  }

  protected String createJson(T source) {
    try {
      return updateObjectMapper.writer()
          .withView(UpdatableJsonView.class)
          .writeValueAsString(source);
    } catch (JsonProcessingException ex) {
      throw new InvalidDataException(ex);
    }
  }

  protected void updateObject(T object, T source) {
    updateObjectFromJson(object, createJson(source));
  }

  protected void updateObjectFromJson(T object, String sourceJson) {
    try {
      updateObjectMapper.readerForUpdating(object)
          .withView(UpdatableJsonView.class)
          .readValue(sourceJson);
    } catch (JsonProcessingException ex) {
      throw new InvalidDataException(ex);
    }
    validateRequiredFields(object);
    validateState(object);
    fillCreatedAndModified(object);
  }

  protected void validateRequiredFields(T object) {
    BeanPropertyBindingResult bindingResult = new BeanPropertyBindingResult(object,
        object.getClass().getName());
    validator.validate(object, bindingResult);
    if (bindingResult.hasErrors()) {
      throw new InvalidDataException(bindingResult);
    }
  }

  protected void fillCreatedAndModified(@NotNull TransactionalObject entity) {
    LocalDateTime now = LocalDateTime.now();
    if (Objects.isNull(entity.getCreated())) {
      entity.setCreated(now);
    }
    entity.setModified(now);
  }

  protected abstract void validateState(T object);

  protected abstract void fillStateIfNull(T object);

}
