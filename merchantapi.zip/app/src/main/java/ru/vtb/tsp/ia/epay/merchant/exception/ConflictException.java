package ru.vtb.tsp.ia.epay.merchant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.CONFLICT)
public class ConflictException extends BusinessException {

  private static final String MESSAGE_DEFAULT = "Conflict";
  private Object conflictedObject;

  public ConflictException() {
    super(MESSAGE_DEFAULT);
  }

  public ConflictException(Object conflictedObject) {
    super(MESSAGE_DEFAULT);
    this.conflictedObject = conflictedObject;
  }

  public ConflictException(String message) {
    super(message);
  }

  public ConflictException(String message, Object conflictedObject) {
    super(message);
    this.conflictedObject = conflictedObject;
  }

  public ConflictException(String message, Throwable cause) {
    super(message, cause);
  }

  public ConflictException(Throwable cause) {
    super(cause);
  }

  public Object getConflictedObject() {
    return this.conflictedObject;
  }
}
