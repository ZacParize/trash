package ru.vtb.tsp.ia.epay.merchant.data.search;

import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.ID_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.LOGIN_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MDM_CODE_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MERCHANT_NAME_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MERCHANT_REF_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MERCHANT_SITES_RELATION;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.STATE_FIELD_NAME;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Set;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.persistence.criteria.Subquery;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;

@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Data
public class MerchantSiteSpecification implements Specification<MerchantSiteHE> {

  private static final Set<String> DEFAULT_STATES_SET = Set.of(MerchantSiteState.ACTIVE.getName(),
          MerchantSiteState.NOT_ACTIVE.getName(), MerchantSiteState.BLOCKED.getName());

  @Singular("mstId")
  private Set<String> id;

  @Singular("merchantId")
  private Set<String> merchantId;

  @Singular("login")
  private Set<String> login;

  private String name;

  private Long mdmCode;

  @Singular("state")
  private Set<String> state;

  @Override
  public Predicate toPredicate(Root<MerchantSiteHE> root,
                               CriteriaQuery<?> query,
                               CriteriaBuilder cb) {
    final var predicates = new ArrayList<Predicate>();

    if (CollectionUtils.isNotEmpty(id)) {
      predicates.add(root.get(ID_FIELD_NAME).in(id));
    }

    if (CollectionUtils.isNotEmpty(merchantId)) {
      predicates.add(root.get(MERCHANT_REF_FIELD_NAME).in(merchantId));
    }

    if (CollectionUtils.isNotEmpty(login)) {
      predicates.add(root.get(LOGIN_FIELD_NAME).in(login));
    }

    if (StringUtils.isNotBlank(name)) {
      predicates.add(cb.equal(root.get(MERCHANT_NAME_FIELD_NAME), name));
    }

    if (Objects.nonNull(mdmCode)) {
      Subquery<MerchantHE> subquery = query.subquery(MerchantHE.class);
      Root<MerchantHE> subroot = subquery.from(MerchantHE.class);
      subquery.select(subroot.join(MERCHANT_SITES_RELATION))
          .where(subroot.get(MDM_CODE_FIELD_NAME).in(mdmCode));
      predicates.add(root.get(ID_FIELD_NAME).in(subquery));
    }

    predicates.add(root.get(STATE_FIELD_NAME).in(getStateWithDefault()));

    return cb.and(predicates.toArray(new Predicate[0]));
  }

  private Set<String> getStateWithDefault() {
    return ObjectUtils.isEmpty(state) ? DEFAULT_STATES_SET : state;
  }
}
