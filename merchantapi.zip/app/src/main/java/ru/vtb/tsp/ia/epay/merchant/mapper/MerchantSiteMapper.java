package ru.vtb.tsp.ia.epay.merchant.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteFiscalParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.enums.MerchantSiteStateDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFiscalParamsDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

@Mapper(componentModel = "spring")
public interface MerchantSiteMapper {

  MerchantSiteStateDto mapMerchantSiteStateToDto(MerchantSiteState state);

  MerchantSiteState mapDtoToMerchantSiteState(MerchantSiteStateDto dto);

  MerchantSite mapDtoToMerchantSite(MerchantSiteDto dto);

  MerchantSiteDto mapMerchantSiteToDto(MerchantSite merchant);

  MerchantSiteParamsDto mapMerchantSiteParamsToDto(MerchantSiteParams params);

  @Mapping(target = "orderLifeTime", ignore = true)
  MerchantSiteParams mapDtoToMerchantSiteParams(MerchantSiteParamsDto dto);

  MerchantSiteFiscalParamsDto mapMerchantSiteFiscalParamsToDto(MerchantSiteFiscalParams params);

}