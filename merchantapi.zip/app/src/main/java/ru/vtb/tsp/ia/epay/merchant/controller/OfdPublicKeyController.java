package ru.vtb.tsp.ia.epay.merchant.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.vtb.tsp.ia.epay.merchant.App.VERSION_URL;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.merchant.MerchantPublicKeyApi;
import ru.vtb.tsp.ia.epay.merchant.services.feigns.MerchantPublicKeyApiClient;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.OfdPublicKeyDto;


@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping(value = VERSION_URL, produces = APPLICATION_JSON_VALUE)
public class OfdPublicKeyController implements MerchantPublicKeyApi {

  private static final String OFD_PUBLIC_KEY_URL = "/ofd-public-key";
  private final MerchantPublicKeyApiClient merchantPublicKeyApiClient;


  @Override
  @GetMapping(path = OFD_PUBLIC_KEY_URL, produces = MimeTypeUtils.APPLICATION_JSON_VALUE)
  public ResponseEntity<OfdPublicKeyDto> getPublicKey() {
    log.info("Get public key request");
    return merchantPublicKeyApiClient.getPublicKey();
  }
}
