package ru.vtb.tsp.ia.epay.merchant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.CONFLICT, reason = "Object was blocked")
public class ObjectBlockedException extends ConflictException {

  public ObjectBlockedException() {
  }

  public ObjectBlockedException(String message) {
    super(message);
  }

  public ObjectBlockedException(String message, Throwable cause) {
    super(message, cause);
  }

  public ObjectBlockedException(Throwable cause) {
    super(cause);
  }

}
