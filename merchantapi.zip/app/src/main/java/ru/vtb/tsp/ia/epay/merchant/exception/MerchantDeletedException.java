package ru.vtb.tsp.ia.epay.merchant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.GONE, reason = "Merchant was deleted")
public class MerchantDeletedException extends ObjectDeletedException {

  public MerchantDeletedException() {
  }

  public MerchantDeletedException(String message) {
    super(message);
  }

  public MerchantDeletedException(String message, Throwable cause) {
    super(message, cause);
  }

  public MerchantDeletedException(Throwable cause) {
    super(cause);
  }

  public MerchantDeletedException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
