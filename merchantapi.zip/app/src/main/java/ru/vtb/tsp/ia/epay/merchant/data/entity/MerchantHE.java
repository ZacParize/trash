package ru.vtb.tsp.ia.epay.merchant.data.entity;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantParams;
import ru.vtb.tsp.ia.epay.merchant.data.entity.support.MerchantPersistenceListener;

@Entity(name = "merchants")
@Table(name = "merchants")
@TypeDefs(@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class))
@EntityListeners(value = {MerchantPersistenceListener.class})
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class MerchantHE extends EntityHE<Merchant> {

  @Column(name = "state")
  private String state;

  @Column(name = "name")
  private String name;

  @Column(name = "mdm_code")
  private Long mdmCode;

  @Type(type = "jsonb")
  private MerchantParams params;

  @OneToMany(mappedBy = "merchRef", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
  private List<MerchantSiteHE> merchantSites = new ArrayList<>();

  public MerchantHE(Merchant entity) {
    super(entity, entity.getId());
  }

}