package ru.vtb.tsp.ia.epay.merchant.data.entity.support;

import java.util.Optional;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;


public class MerchantSitePersistenceListener {

  @PrePersist
  @PreUpdate
  public void handle(MerchantSiteHE entity) {
    MerchantSite mst = entity.getEntity();

    entity.setMerchRef(mst.getMerchantId());
    entity.setUrl(mst.getUrl());
    entity.setName(mst.getName());
    entity.setLogin(mst.getLogin());
    entity.setExternalApplicationId(mst.getExternalApplicationId());
    entity.setType(mst.getType());

    entity.setState(Optional.ofNullable(mst.getState())
        .map(MerchantSiteState::getName)
        .orElse(null));
    entity.setDeleted(MerchantSiteState.DELETED.equals(mst.getState())
        || MerchantSiteState.BLOCKED.equals(mst.getState()));
    entity.setParams(mst.getParams());

  }
}
