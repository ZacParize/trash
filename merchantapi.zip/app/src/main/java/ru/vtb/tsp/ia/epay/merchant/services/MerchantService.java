package ru.vtb.tsp.ia.epay.merchant.services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;
import ru.vtb.tsp.ia.epay.merchant.data.search.MerchantSpecification;

/**
 * .
 *
 * @author Rustam Valiev RValiev@inno.tech
 * @since 26.09.2022
 */
public interface MerchantService {

  @Transactional(readOnly = true)
  Merchant getMerchant(String merchantId);

  @Transactional(readOnly = true)
  Page<MerchantHE> getMerchants(MerchantSpecification filter, Pageable pageable);

  @Transactional
  Merchant createMerchant(Merchant source);

  @Transactional
  Merchant updateMerchant(String merchantId, String source);

  @Transactional
  void deleteMerchant(String merchantId);

  @Transactional
  Merchant blockMerchant(String merchantId);

  @Transactional
  Merchant unblockMerchant(String merchantId);
}
