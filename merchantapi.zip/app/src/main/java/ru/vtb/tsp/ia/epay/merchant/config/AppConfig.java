package ru.vtb.tsp.ia.epay.merchant.config;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

@Slf4j
@Configuration
@ComponentScan({"ru.vtb.tsp.ia.epay.merchant", "ru.vtb.tsp.ia.epay.core.utils"})
@EnableJdbcRepositories(basePackageClasses =
    ru.vtb.tsp.ia.epay.core.repositories.StandInParamsRepository.class)
public class AppConfig {

  public static final int TIMEOUT = 5000;

  @Bean
  public RestTemplate restTemplate() {
    final var factory = new SimpleClientHttpRequestFactory();
    factory.setConnectTimeout(TIMEOUT);
    factory.setReadTimeout(TIMEOUT);
    return new RestTemplate(factory);
  }

  @Bean
  public ObjectMapper objectMapper() {
    final var objectMapperBuilder = JsonMapper.builder();
    objectMapperBuilder.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    objectMapperBuilder.enable(SerializationFeature.INDENT_OUTPUT);
    objectMapperBuilder.enable(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES);
    objectMapperBuilder.enable(MapperFeature.DEFAULT_VIEW_INCLUSION);
    objectMapperBuilder.enable(JsonParser.Feature.ALLOW_COMMENTS);
    objectMapperBuilder.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapperBuilder.configure(SerializationFeature.WRAP_ROOT_VALUE, false);
    objectMapperBuilder.configure(DeserializationFeature.UNWRAP_ROOT_VALUE, false);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY);
    objectMapperBuilder.enable(DeserializationFeature.ACCEPT_EMPTY_STRING_AS_NULL_OBJECT);
    final var objectMapper = objectMapperBuilder.build();
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.setSerializationInclusion(Include.NON_NULL);
    return objectMapper;
  }

}