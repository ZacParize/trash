package ru.vtb.tsp.ia.epay.merchant.services.impl;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;
import ru.vtb.tsp.ia.epay.merchant.data.search.MerchantSpecification;
import ru.vtb.tsp.ia.epay.merchant.exception.InvalidDataException;
import ru.vtb.tsp.ia.epay.merchant.exception.MerchantConflictException;
import ru.vtb.tsp.ia.epay.merchant.services.BaseEntityService;
import ru.vtb.tsp.ia.epay.merchant.services.MerchantService;

@Slf4j
@Service
public class MerchantServiceImpl extends BaseEntityService<Merchant>
    implements MerchantService {

  @Override
  protected void validateState(Merchant object) {
    if (object.getState() != null && object.getState() != MerchantState.ACTIVE) {
      throw new InvalidDataException();
    }
  }

  @Override
  @Transactional(readOnly = true)
  public Merchant getMerchant(String merchantId) {
    return getRequiredMerchantById(merchantId).getEntity();
  }

  @Override
  @Transactional(readOnly = true)
  public Page<MerchantHE> getMerchants(MerchantSpecification filter, Pageable pageable) {
    return merchantRepository.findAll(filter, pageable);
  }

  @Override
  @Transactional
  public Merchant createMerchant(Merchant source) {
    Optional<Merchant> conflictMerchant = Optional.ofNullable(source.getId())
        .flatMap(merchantRepository::findById)
        .map(MerchantHE::getEntity);
    if (conflictMerchant.isPresent()) {
      throw new MerchantConflictException(conflictMerchant.get());
    }
    final var merchant = new Merchant(Objects
        .requireNonNullElse(source.getId(), UUID.randomUUID().toString()));
    updateObject(merchant, source);
    fillStateIfNull(merchant);

    return merchantRepository.save(new MerchantHE(merchant)).getEntity();
  }

  @Override
  @Transactional
  public Merchant updateMerchant(String merchantId, String source) {
    return updateMerchant(merchantId, merchant ->
        updateObjectFromJson(merchant, source));
  }

  private Merchant updateMerchant(String merchantId, Consumer<Merchant> updater) {
    MerchantHE merchantHE = getActualMerchantById(merchantId);
    Merchant merchant = merchantHE.getEntity();

    updater.accept(merchant);
    updateObject(merchant, merchant);
    fillStateIfNull(merchant);

    return merchantRepository.save(merchantHE).getEntity();
  }

  @Override
  @Transactional
  public void deleteMerchant(String merchantId) {
    MerchantHE merchant = getActualMerchantById(merchantId);
    Merchant entity = merchant.getEntity();
    entity.setState(MerchantState.DELETED);
    fillCreatedAndModified(entity);
    merchantRepository.save(merchant);
  }

  @Override
  @Transactional
  public Merchant blockMerchant(String merchantId) {
    MerchantHE merchant = getActualMerchantById(merchantId);
    Merchant entity = merchant.getEntity();
    entity.setState(MerchantState.BLOCKED);
    fillCreatedAndModified(entity);
    return merchantRepository.save(merchant).getEntity();
  }

  @Override
  @Transactional
  public Merchant unblockMerchant(String merchantId) {
    MerchantHE merchant = getRequiredMerchantById(merchantId);
    Merchant entity = merchant.getEntity();
    entity.setState(MerchantState.ACTIVE);
    fillCreatedAndModified(entity);
    return merchantRepository.save(merchant).getEntity();
  }

  @Override
  protected void fillStateIfNull(@NotNull Merchant object) {
    if (Objects.isNull(object.getState())) {
      object.setState(MerchantState.ACTIVE);
    }
  }

}