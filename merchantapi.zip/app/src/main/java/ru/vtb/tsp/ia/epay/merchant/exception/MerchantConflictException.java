package ru.vtb.tsp.ia.epay.merchant.exception;

import lombok.Getter;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;


public class MerchantConflictException extends ObjectConflictException {

  private static final String MESSAGE_DEFAULT = "Conflict of merchants";

  @Getter
  private final Merchant merchant;

  public MerchantConflictException() {
    super(MESSAGE_DEFAULT);
    this.merchant = null;
  }

  public MerchantConflictException(Merchant merchant) {
    this(MESSAGE_DEFAULT, merchant);
  }

  public MerchantConflictException(String message, Merchant merchant) {
    super(message);
    this.merchant = merchant;
  }

  public MerchantConflictException(String message, Throwable cause, Merchant merchant) {
    super(message, cause);
    this.merchant = merchant;
  }

  public MerchantConflictException(Throwable cause, Merchant merchant) {
    super(cause);
    this.merchant = merchant;
  }

  @Override
  public Object getConflictedObject() {
    return this.merchant;
  }
}
