package ru.vtb.tsp.ia.epay.merchant.data.entity;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import java.io.Serializable;
import java.time.LocalDateTime;
import javax.persistence.Column;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import javax.persistence.Version;
import javax.validation.constraints.NotNull;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import org.springframework.data.domain.Persistable;
import ru.vtb.tsp.ia.epay.core.domains.TransactionalObject;
import ru.vtb.tsp.ia.epay.merchant.data.entity.support.LastModifiedListener;

@TypeDefs(@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class))
@EqualsAndHashCode(of = "id")
@EntityListeners(value = {LastModifiedListener.class})
@MappedSuperclass
public abstract class EntityHE<T extends TransactionalObject> implements Serializable,
    Persistable<String> {

  @Id
  @Getter
  @NotNull
  private String id;

  @Type(type = "jsonb")
  @Getter
  private T entity;

  @Getter
  @Setter
  @Column(name = "deleted")
  private boolean deleted;

  @Getter
  @Setter
  @Column(name = "created")
  private LocalDateTime created;

  @Getter
  @Setter
  @Column(name = "modified")
  private LocalDateTime modified;

  @Version
  private long version;

  protected EntityHE() {}

  protected EntityHE(T entity, String id) {
    this.entity = entity;
    this.id = id;
  }

  @Override
  @Transient
  public boolean isNew() {
    return version == 0;
  }
}
