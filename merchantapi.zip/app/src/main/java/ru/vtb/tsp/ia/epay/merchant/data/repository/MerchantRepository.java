package ru.vtb.tsp.ia.epay.merchant.data.repository;

import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;

@Repository
public interface MerchantRepository extends BaseRepository<MerchantHE, String> {

}
