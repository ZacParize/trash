package ru.vtb.tsp.ia.epay.merchant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.GONE, reason = "Object was deleted")
public class ObjectDeletedException extends BusinessException {

  public ObjectDeletedException() {
  }

  public ObjectDeletedException(String message) {
    super(message);
  }

  public ObjectDeletedException(String message, Throwable cause) {
    super(message, cause);
  }

  public ObjectDeletedException(Throwable cause) {
    super(cause);
  }

  public ObjectDeletedException(String message, Throwable cause, boolean enableSuppression,
      boolean writableStackTrace) {
    super(message, cause, enableSuppression, writableStackTrace);
  }
}
