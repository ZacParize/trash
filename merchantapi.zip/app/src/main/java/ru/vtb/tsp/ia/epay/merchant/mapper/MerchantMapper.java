package ru.vtb.tsp.ia.epay.merchant.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingConstants;
import org.mapstruct.ValueMapping;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantState;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.enums.MerchantStateDto;

@Mapper(componentModel = "spring")
public interface MerchantMapper {

  MerchantStateDto mapMerchantStateToDto(MerchantState state);

  @ValueMapping(source = "DRAFT", target = MappingConstants.NULL)
  @ValueMapping(source = "NOT_ACTIVE", target = MappingConstants.NULL)
  MerchantState mapDtoToMerchantState(MerchantStateDto dto);

  @Mapping(target = "state", expression = "java(mapDtoToMerchantState(dto.getState()))")
  @Mapping(target = "params", ignore = true)
  Merchant mapDtoToMerchant(MerchantDto dto);

  @Mapping(target = "state", expression = "java(mapMerchantStateToDto(merchant.getState()))")
  MerchantDto mapMerchantToDto(Merchant merchant);

}