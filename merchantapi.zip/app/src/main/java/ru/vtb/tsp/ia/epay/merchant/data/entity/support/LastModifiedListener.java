package ru.vtb.tsp.ia.epay.merchant.data.entity.support;

import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import ru.vtb.tsp.ia.epay.core.domains.TransactionalObject;
import ru.vtb.tsp.ia.epay.merchant.data.entity.EntityHE;

public class LastModifiedListener {

  @PrePersist
  @PreUpdate
  public void applyCreatedAndModifiedDates(EntityHE entityHE) {
    TransactionalObject entity = entityHE.getEntity();
    entityHE.setCreated(entity.getCreated());
    entityHE.setModified(entity.getModified());
  }

}
