package ru.vtb.tsp.ia.epay.merchant.services.impl;


import com.fasterxml.jackson.core.JsonProcessingException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Consumer;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.UpdatableJsonView;
import ru.vtb.tsp.ia.epay.core.domains.enums.MerchantSiteType;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;
import ru.vtb.tsp.ia.epay.merchant.data.search.MerchantSiteSpecification;
import ru.vtb.tsp.ia.epay.merchant.exception.InvalidDataException;
import ru.vtb.tsp.ia.epay.merchant.exception.MerchantSiteConflictException;
import ru.vtb.tsp.ia.epay.merchant.services.BaseEntityService;
import ru.vtb.tsp.ia.epay.merchant.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;

@Slf4j
@Service
public class MerchantSiteServiceImpl extends BaseEntityService<MerchantSite>
    implements MerchantSiteService {

  private static final long ORDER_LIFE_TIME_MINUTES = 20L;

  @Override
  protected void validateState(MerchantSite object) {
    if (object.getState() != null
        && object.getState() != MerchantSiteState.ACTIVE
        && object.getState() != MerchantSiteState.BLOCKED
    ) {
      throw new InvalidDataException();
    }
  }

  @Override
  @Transactional(readOnly = true)
  public MerchantSiteHE getMerchantSite(String mstId) {
    return getRequiredMerchantSiteById(mstId);
  }

  @Override
  @Transactional(readOnly = true)
  public Page<MerchantSiteHE> getMerchantSites(MerchantSiteFilter filter,
      Pageable pageable) {
    final var builder = MerchantSiteSpecification.builder();
    if (!ObjectUtils.isEmpty(filter.getMstId())) {
      builder.id(filter.getMstId());
    }
    if (!ObjectUtils.isEmpty(filter.getMerchantId())) {
      builder.id(filter.getMerchantId());
    }
    if (!ObjectUtils.isEmpty(filter.getLogin())) {
      builder.login(filter.getLogin());
    }
    if (!ObjectUtils.isEmpty(filter.getMdmCode())) {
      builder.mdmCode(filter.getMdmCode());
    }
    if (!ObjectUtils.isEmpty(filter.getName())) {
      builder.name(filter.getName());
    }
    if (!ObjectUtils.isEmpty(filter.getState())) {
      builder.state(filter.getState());
    }
    return merchantSiteRepository.findAll(builder.build(), pageable);
  }

  @Override
  @Transactional
  public MerchantSite createMerchantSite(MerchantSite source) {
    checkMerchantExistence(source.getMerchantId());

    Optional<MerchantSite> conflictMerchantSite = Optional.ofNullable(source.getId())
        .flatMap(merchantSiteRepository::findById)
        .map(MerchantSiteHE::getEntity);
    if (conflictMerchantSite.isPresent()) {
      throw new MerchantSiteConflictException(conflictMerchantSite.get());
    }
    final var mst = new MerchantSite(Objects
        .requireNonNullElse(source.getId(), UUID.randomUUID().toString()));
    updateObject(mst, source);
    fillStateIfNull(mst);
    fillTypeIfNull(mst);
    checkOrderLifeTime(mst);

    return merchantSiteRepository.save(new MerchantSiteHE(mst)).getEntity();
  }

  @Override
  @Transactional
  public MerchantSite updateMerchantSite(String mstId, String source) {
    return updateMerchantSite(mstId, mst -> updateObjectFromJson(mst, source));
  }

  private MerchantSite updateMerchantSite(String mstId, Consumer<MerchantSite> updater) {
    MerchantSiteHE mstHE = getMerchantSiteByIdExceptDeleted(mstId);
    MerchantSite mst = mstHE.getEntity();
    final var callbackUrlBeforeUpdate = Objects.nonNull(mst.getParams())
        ? mst.getParams().getCallbackUrl() : null;
    updater.accept(mst);
    updateObject(mst, mst);
    fillStateIfNull(mst);
    fillTypeIfNull(mst);
    checkOrderLifeTime(mst);
    checkCallbackUrlModifyDate(mst, callbackUrlBeforeUpdate,
        Objects.nonNull(mst.getParams()) ? mst.getParams().getCallbackUrl() : null);
    return merchantSiteRepository.save(mstHE).getEntity();
  }

  @Override
  @Transactional
  public void deleteMerchantSite(String mstId) {
    MerchantSiteHE mstHE = getActualMerchantSiteById(mstId);
    MerchantSite entity = mstHE.getEntity();
    entity.setState(MerchantSiteState.DELETED);
    fillCreatedAndModified(entity);
    merchantSiteRepository.save(mstHE);
  }

  @Override
  @Transactional
  public MerchantSite blockMerchantSite(String mstId) {
    MerchantSiteHE mstHE = getActualMerchantSiteById(mstId);
    MerchantSite entity = mstHE.getEntity();
    entity.setState(MerchantSiteState.BLOCKED);
    disableCardPayment(entity.getParams());
    disableSbpPayment(entity.getParams());
    fillCreatedAndModified(entity);
    return merchantSiteRepository.save(mstHE).getEntity();
  }

  @Override
  @Transactional
  public MerchantSite unblockMerchantSite(String mstId) {
    MerchantSiteHE mstHE = getRequiredMerchantSiteById(mstId);
    MerchantSite entity = mstHE.getEntity();
    entity.setState(MerchantSiteState.ACTIVE);
    enableCardPayment(entity.getParams());
    enableSbpPayment(entity.getParams());
    fillCreatedAndModified(entity);
    return merchantSiteRepository.save(mstHE).getEntity();
  }

  @Override
  public MerchantSiteCheckHostDto getCheckHostDto(String mstId, String mstUrl) {
    if (ObjectUtils.isEmpty(mstId)) {
      return null;
    }
    final var merchantSite = getMerchantSite(mstId);
    MerchantSiteCheckHostDto merchantSiteCheckHostDto = new MerchantSiteCheckHostDto();
    if (mstUrl.equals(merchantSite.getUrl())) {
      merchantSiteCheckHostDto.setClientId(merchantSite.getLogin());
      merchantSiteCheckHostDto.setMerchantAuthorization(mstId);
      merchantSiteCheckHostDto.setCheckHost(true);
    } else {
      merchantSiteCheckHostDto.setMerchantAuthorization(mstId);
      merchantSiteCheckHostDto.setCheckHost(false);
    }

    return merchantSiteCheckHostDto;
  }

  @Override
  public MerchantSiteParams updateMerchantSiteParams(String mstId, String source) {
    if (ObjectUtils.isEmpty(mstId)) {
      return null;
    }
    final var mstEntity = getMerchantSiteByIdExceptDeleted(mstId).getEntity();
    try {
      final MerchantSiteParams mstParams = updateObjectMapper
          .readerForUpdating(mstEntity.getParams())
          .withView(UpdatableJsonView.class)
          .readValue(source);
      mstEntity.setParams(mstParams);
      return updateMerchantSite(mstId, updateObjectMapper.writeValueAsString(mstEntity))
          .getParams();
    } catch (JsonProcessingException ex) {
      throw new InvalidDataException(ex);
    }
  }

  @Override
  protected void fillStateIfNull(@NotNull MerchantSite object) {
    if (Objects.isNull(object.getState())) {
      object.setState(MerchantSiteState.ACTIVE);
    }
  }

  private void fillTypeIfNull(MerchantSite object) {
    if (Objects.isNull(object.getType())) {
      object.setType(MerchantSiteType.INTERNET_ACQUIRING);
    }
  }

  private void checkOrderLifeTime(MerchantSite mst) {
    if (Objects.isNull(mst.getParams().getOrderLifeTime())) {
      mst.getParams().setOrderLifeTime(Duration.ofMinutes(ORDER_LIFE_TIME_MINUTES));
    }
  }

  private void checkCallbackUrlModifyDate(MerchantSite mst, String callbackUrlBefore,
      String callbackUrlAfter) {
    if (!StringUtils.equals(callbackUrlBefore, callbackUrlAfter)
        && Objects.nonNull(mst.getParams())) {
      mst.getParams().setCallbackUrlModified(LocalDateTime.now(ZoneOffset.UTC));
    }
  }

  private void disableCardPayment(MerchantSiteParams params) {
    if (Objects.nonNull(params) && Objects.nonNull(params.getCardParams())) {
      params.getCardParams().setEnableCardPayment(false);
    }
  }

  private void enableCardPayment(MerchantSiteParams params) {
    if (checkCardPaymentRequirements(params)) {
      params.getCardParams().setEnableCardPayment(true);
    }
  }

  private void disableSbpPayment(MerchantSiteParams params) {
    if (Objects.nonNull(params) && Objects.nonNull(params.getSbpParams())) {
      params.getSbpParams().setEnableSbpPayment(false);
    }
  }

  private void enableSbpPayment(MerchantSiteParams params) {
    if (checkSbpPaymentRequirements(params)) {
      params.getSbpParams().setEnableSbpPayment(true);
    }
  }

  private boolean checkCardPaymentRequirements(MerchantSiteParams params) {
    return Objects.nonNull(params)
        && Objects.nonNull(params.getCardParams())
        && StringUtils.isNotEmpty(params.getCardParams().getMerchantId())
        && StringUtils.isNotEmpty(params.getCardParams().getTerminalId())
        && StringUtils.isNotEmpty(params.getCardParams().getMerchantName());
  }

  private boolean checkSbpPaymentRequirements(MerchantSiteParams params) {
    return Objects.nonNull(params)
        && Objects.nonNull(params.getSbpParams())
        && StringUtils.isNotEmpty(params.getSbpParams().getMerchantId())
        && StringUtils.isNotEmpty(params.getSbpParams().getLegalId())
        && StringUtils.isNotEmpty(params.getSbpParams().getAccount())
        && StringUtils.isNotEmpty(params.getSbpParams().getTemplateVersion())
        && StringUtils.isNotEmpty(params.getSbpParams().getQrcType())
        && StringUtils.isNotEmpty(params.getSbpParams().getPaymentPurpose())
        && StringUtils.isNotEmpty(params.getSbpParams().getRefundPurpose());
  }
}