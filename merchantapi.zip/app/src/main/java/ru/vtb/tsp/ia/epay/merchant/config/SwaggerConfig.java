package ru.vtb.tsp.ia.epay.merchant.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnExpression("${springdoc.swagger-ui.enabled:true}")
public class SwaggerConfig {

  @Bean
  public OpenAPI merchantApiOpenAPI() {
    return new OpenAPI()
        .info(new Info().title("Merchant API")
            .description("Merchant API")
            .version("v0.0.1")
        );
  }
}