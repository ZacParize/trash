package ru.vtb.tsp.ia.epay.merchant.data.entity;

import com.vladmihalcea.hibernate.type.json.JsonBinaryType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.TypeDefs;
import ru.vtb.tsp.ia.epay.core.domains.enums.MerchantSiteType;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.merchant.data.entity.support.MerchantSitePersistenceListener;

@Entity(name = "merchant_sites")
@Table(name = "merchant_sites")
@TypeDefs(@TypeDef(name = "jsonb", typeClass = JsonBinaryType.class))
@EntityListeners(value = {MerchantSitePersistenceListener.class})
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class MerchantSiteHE extends EntityHE<MerchantSite> {

  private String state;

  @NotNull
  @JoinColumn(name = "merch_ref")
  @Column(name = "merch_ref")
  private String merchRef;

  @Column(name = "url")
  private String url;

  @Column(name = "name")
  private String name;

  @Column(name = "login")
  private String login;

  @Column(name = "external_application_id")
  private String externalApplicationId;

  @Column(name = "type")
  @Enumerated(EnumType.STRING)
  private MerchantSiteType type;

  @Type(type = "jsonb")
  @Column(name = "params")
  private MerchantSiteParams params;

  public MerchantSiteHE(MerchantSite entity) {
    super(entity, entity.getId());
  }
}
