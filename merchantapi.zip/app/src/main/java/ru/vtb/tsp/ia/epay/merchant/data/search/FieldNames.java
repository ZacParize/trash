package ru.vtb.tsp.ia.epay.merchant.data.search;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class FieldNames {

  public static final String ID_FIELD_NAME = "id";
  public static final String MDM_CODE_FIELD_NAME = "mdmCode";
  public static final String STATE_FIELD_NAME = "state";
  public static final String LOGIN_FIELD_NAME = "login";
  public static final String MERCHANT_NAME_FIELD_NAME = "name";
  public static final String MERCHANT_REF_FIELD_NAME = "merchRef";
  public static final String MERCHANT_SITES_RELATION = "merchantSites";

}
