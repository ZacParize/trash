package ru.vtb.tsp.ia.epay.merchant.exception;

public class ObjectConflictException extends ConflictException {

  public ObjectConflictException() {
  }

  public ObjectConflictException(String message) {
    super(message);
  }

  public ObjectConflictException(String message, Throwable cause) {
    super(message, cause);
  }

  public ObjectConflictException(Throwable cause) {
    super(cause);
  }
}
