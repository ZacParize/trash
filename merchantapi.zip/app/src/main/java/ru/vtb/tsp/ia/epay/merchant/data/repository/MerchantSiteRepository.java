package ru.vtb.tsp.ia.epay.merchant.data.repository;

import static ru.vtb.tsp.ia.epay.merchant.data.repository.MerchantSiteRepository.BEAN_NAME;

import org.springframework.stereotype.Repository;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;

@Repository(BEAN_NAME)
public interface MerchantSiteRepository extends BaseRepository<MerchantSiteHE, String> {

  public static final String BEAN_NAME = "merchantSiteApiRepository";

}