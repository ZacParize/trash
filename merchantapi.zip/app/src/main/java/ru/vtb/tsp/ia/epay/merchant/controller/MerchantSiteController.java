package ru.vtb.tsp.ia.epay.merchant.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.vtb.tsp.ia.epay.merchant.App.VERSION_URL;

import java.io.IOException;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE;
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantSiteMapper;
import ru.vtb.tsp.ia.epay.merchant.services.MerchantSiteService;
import ru.vtb.tsp.ia.epay.merchant.sites.MerchantSiteControllerApi;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteCheckHostDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteParamsDto;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = VERSION_URL + MerchantSiteController.URL, produces = APPLICATION_JSON_VALUE)
public class MerchantSiteController implements MerchantSiteControllerApi {

  public static final String URL = "/sites";
  private static final String MST_ID = "mstId";
  private static final String PATH_MERCHANT_SITE_ID = "/{" + MST_ID + "}";
  private static final String PATH_MST_CHECK_HOST = "/check-host";
  private static final String PATH_V2_SITES = "/temp-sites";
  private static final String PATH_BLOCK = PATH_MERCHANT_SITE_ID + "/block";
  private static final String PATH_UNBLOCK = PATH_MERCHANT_SITE_ID + "/unblock";
  private static final String PATH_MERCHANT_SITE_ID_PARAMS = PATH_MERCHANT_SITE_ID + "/params";

  private final MerchantSiteService merchantSiteService;
  private final MerchantSiteMapper merchantSiteMapper;

  @Override
  @GetMapping(PATH_MERCHANT_SITE_ID)
  public ResponseEntity<MerchantSiteDto> get(@PathVariable(MST_ID) String mstId) {
    log.info("Get merchant site, request: mstId {}", mstId);
    final var merchantSite = merchantSiteMapper.mapMerchantSiteToDto(
        merchantSiteService.getMerchantSite(mstId).getEntity());
    log.info("Get merchant site, response: {}", merchantSite);
    return ResponseEntity.ok(merchantSite);
  }

  @Override
  @GetMapping(PATH_MST_CHECK_HOST)
  public ResponseEntity<MerchantSiteCheckHostDto> getMerchantSiteCheckHost(
      @RequestHeader(value = "merchant_authorization") String mstId,
      @RequestParam(value = "mstUrl") String mstUrl) {
    log.info("Get merchant site: mstId {}, with host control: mstUrl {}", mstId, mstUrl);
    return ResponseEntity.ok(merchantSiteService.getCheckHostDto(mstId, mstUrl));
  }

  @Override
  @GetMapping
  public ResponseEntity<List<MerchantSiteDto>> getAll(@NotNull MerchantSiteFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable) {
    log.info("Get merchant sites, request: filter {}, pagination {}", filter, pageable);
    final var items = merchantSiteService.getMerchantSites(filter, pageable)
        .stream()
        .map(MerchantSiteHE::getEntity)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
    log.info("Get merchant sites, response: {}", items);
    return ResponseEntity.ok(items.stream().map(merchantSiteMapper::mapMerchantSiteToDto).collect(
        Collectors.toList()));
  }

  @Override
  @GetMapping(PATH_V2_SITES)
  @Deprecated
  public ResponseEntity<List<MerchantSiteDto>> getAllMock(@NotNull MerchantSiteFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable) throws IOException {
    return getAll(filter, pageable);
  }

  @Override
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_CREATE_RESOURCE")
  public ResponseEntity<MerchantSiteDto> create(@RequestBody MerchantSiteDto source) {
    log.info("Create merchant site, request: body {}", source);
    final var mst = merchantSiteService
        .createMerchantSite(merchantSiteMapper.mapDtoToMerchantSite(source));
    log.info("Create merchant site, response: {}", mst);
    return ResponseEntity.ok(merchantSiteMapper.mapMerchantSiteToDto(mst));
  }

  @Override
  @PutMapping(path = PATH_MERCHANT_SITE_ID, consumes = MediaType.APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_CHANGE_PARAMS_RESOURCE")
  public ResponseEntity<MerchantSiteDto> update(@PathVariable(MST_ID) String mstId,
      @RequestBody String source) {
    log.info("Update merchant site, request: merchantId {}, body {}", mstId, source);
    final var merchantSite = merchantSiteMapper.mapMerchantSiteToDto(
        merchantSiteService.updateMerchantSite(mstId, source));
    log.info("Update merchant site, response: {}", merchantSite);
    return ResponseEntity.ok(merchantSite);
  }

  @Override
  @PatchMapping(path = PATH_MERCHANT_SITE_ID, consumes = MediaType.APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_CHANGE_PARAMS_RESOURCE")
  public ResponseEntity<MerchantSiteDto> patch(@PathVariable(MST_ID) String mstId,
      @RequestBody String source) {
    return update(mstId, source);
  }

  @Override
  @DeleteMapping(PATH_MERCHANT_SITE_ID)
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @AuditProcess("TSPACQ_BOX_DELETE_RESOURCE")
  public void delete(@PathVariable(MST_ID) String mstId) {
    log.info("Delete merchant site, request: mstId {}", mstId);
    merchantSiteService.deleteMerchantSite(mstId);
  }

  @Override
  @PostMapping(path = PATH_BLOCK)
  @AuditProcess("TSPACQ_BOX_BLOCKING_RESOURCE")
  public ResponseEntity<MerchantSiteDto> block(@PathVariable(MST_ID) String mstId) {
    log.info("Block merchant site, request: mstId {}", mstId);
    return ResponseEntity.ok(merchantSiteMapper
        .mapMerchantSiteToDto(merchantSiteService.blockMerchantSite(mstId)));
  }

  @Override
  @PostMapping(path = PATH_UNBLOCK)
  @AuditProcess("TSPACQ_BOX_UNLOCKING_RESOURCE")
  public ResponseEntity<MerchantSiteDto> unblock(@PathVariable(MST_ID) String mstId) {
    log.info("Unblock merchant site, request: mstId {}", mstId);
    return ResponseEntity.ok(merchantSiteMapper
        .mapMerchantSiteToDto(merchantSiteService.unblockMerchantSite(mstId)));
  }

  @Override
  @PutMapping(path = PATH_MERCHANT_SITE_ID_PARAMS, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MerchantSiteParamsDto> updateParams(@PathVariable(MST_ID) String mstId,
      @RequestBody String source) {
    log.info("Update merchant site params, request: mstId {}, params {}", mstId, source);

    final var merchantSiteParams = merchantSiteMapper.mapMerchantSiteParamsToDto(
        merchantSiteService.updateMerchantSiteParams(mstId, source));
    log.info("Update merchant site, response: {}", merchantSiteParams);
    return ResponseEntity.ok(merchantSiteParams);
  }

  @PatchMapping(path = PATH_MERCHANT_SITE_ID_PARAMS, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MerchantSiteParamsDto> patchParams(@PathVariable(MST_ID) String mstId,
      @RequestBody String source) {
    return updateParams(mstId, source);
  }

}