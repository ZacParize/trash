package ru.vtb.tsp.ia.epay.merchant.data.entity.support;

import java.util.Optional;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;

public class MerchantPersistenceListener {

  @PrePersist
  @PreUpdate
  public void handle(MerchantHE entity) {
    Merchant merchant = entity.getEntity();

    entity.setState(Optional.ofNullable(merchant.getState())
        .map(MerchantState::getName)
        .orElse(null));
    entity.setName(merchant.getName());
    entity.setMdmCode(merchant.getMdmCode());
    entity.setDeleted(MerchantState.DELETED.equals(merchant.getState())
        || MerchantState.BLOCKED.equals(merchant.getState()));
    entity.setParams(merchant.getParams());

  }
}
