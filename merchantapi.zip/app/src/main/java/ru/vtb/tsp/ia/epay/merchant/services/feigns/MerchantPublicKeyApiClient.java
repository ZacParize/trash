
package ru.vtb.tsp.ia.epay.merchant.services.feigns;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.bind.annotation.GetMapping;
import ru.vtb.tsp.ia.epay.merchant.App;
import ru.vtb.tsp.ia.epay.merchant.MerchantPublicKeyApi;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.OfdPublicKeyDto;

@FeignClient(name = "merchantFiscalizationPublicKeyApiClient",
    url = "${app.fiscalization-domain.url}", decode404 = true)
@ConditionalOnProperty(name = "app.fiscalization-domain.mock", havingValue = "false")
public interface MerchantPublicKeyApiClient extends MerchantPublicKeyApi {

  String OFD_PUBLIC_KEY_URL = App.VERSION_URL + "/ofd-public-key";

  @Override
  @GetMapping(path = OFD_PUBLIC_KEY_URL, produces = MimeTypeUtils.APPLICATION_JSON_VALUE)
  ResponseEntity<OfdPublicKeyDto> getPublicKey();
}