package ru.vtb.tsp.ia.epay.merchant.exception;

import lombok.Getter;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite;


public class MerchantSiteConflictException extends ObjectConflictException {

  private static final String MESSAGE_DEFAULT = "Conflict of merchant sites";

  @Getter
  private final MerchantSite mst;

  public MerchantSiteConflictException() {
    super(MESSAGE_DEFAULT);
    this.mst = null;
  }

  public MerchantSiteConflictException(MerchantSite mst) {
    this(MESSAGE_DEFAULT, mst);
  }

  public MerchantSiteConflictException(String message, MerchantSite mst) {
    super(message);
    this.mst = mst;
  }

  public MerchantSiteConflictException(String message, Throwable cause, MerchantSite mst) {
    super(message, cause);
    this.mst = mst;
  }

  public MerchantSiteConflictException(Throwable cause, MerchantSite mst) {
    super(cause);
    this.mst = mst;
  }

  @Override
  public Object getConflictedObject() {
    return this.mst;
  }
}
