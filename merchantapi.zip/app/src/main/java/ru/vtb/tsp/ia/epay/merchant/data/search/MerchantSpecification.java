package ru.vtb.tsp.ia.epay.merchant.data.search;

import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.ID_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MDM_CODE_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.MERCHANT_NAME_FIELD_NAME;
import static ru.vtb.tsp.ia.epay.merchant.data.search.FieldNames.STATE_FIELD_NAME;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Singular;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantState;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteState;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;


@Builder
@AllArgsConstructor
@NoArgsConstructor(access = AccessLevel.PROTECTED)
@Data
public class MerchantSpecification implements Specification<MerchantHE> {

  private static final Set<String> DEFAULT_STATES_SET = Set.of(MerchantState.ACTIVE.getName(),
          MerchantSiteState.BLOCKED.getName());

  @Singular("merchantId")
  private Set<String> id;

  @Singular("mdmCode")
  private Set<Long> mdmCode;

  private String name;

  @Singular("state")
  private Set<String> state;

  @Override
  public Predicate toPredicate(Root<MerchantHE> root, CriteriaQuery<?> q, CriteriaBuilder cb) {
    List<Predicate> predicates = new ArrayList<>();

    if (CollectionUtils.isNotEmpty(id)) {
      predicates.add(root.get(ID_FIELD_NAME).in(id));
    }
    if (CollectionUtils.isNotEmpty(mdmCode)) {
      predicates.add(root.get(MDM_CODE_FIELD_NAME).in(mdmCode));
    }
    if (StringUtils.isNotBlank(name)) {
      predicates.add(cb.equal(root.get(MERCHANT_NAME_FIELD_NAME), name));
    }
    predicates.add(root.get(STATE_FIELD_NAME).in(getStateWithDefault()));

    return cb.and(predicates.toArray(new Predicate[0]));
  }

  private Set<String> getStateWithDefault() {
    return ObjectUtils.isEmpty(state) ? DEFAULT_STATES_SET : state;
  }
}
