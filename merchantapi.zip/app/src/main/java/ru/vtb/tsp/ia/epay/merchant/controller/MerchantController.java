package ru.vtb.tsp.ia.epay.merchant.controller;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.vtb.tsp.ia.epay.merchant.App.VERSION_URL;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant;
import ru.vtb.tsp.ia.epay.merchant.MerchantControllerApi;
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE;
import ru.vtb.tsp.ia.epay.merchant.data.search.MerchantSpecification;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantDto;
import ru.vtb.tsp.ia.epay.merchant.dtos.MerchantFilter;
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantMapper;
import ru.vtb.tsp.ia.epay.merchant.services.MerchantService;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
@RequestMapping(value = VERSION_URL + MerchantController.URL, produces = APPLICATION_JSON_VALUE)
public class MerchantController implements MerchantControllerApi {

  public static final String URL = "/merchants";
  private static final String MERCHANT_ID = "merchantId";
  private static final String PATH_MERCHANT_ID = "/{" + MERCHANT_ID + "}";
  private static final String PATH_BLOCK = PATH_MERCHANT_ID + "/block";
  private static final String PATH_UNBLOCK = PATH_MERCHANT_ID + "/unblock";

  private final MerchantService merchantService;
  private final MerchantMapper merchantMapper;

  @Override
  @GetMapping(PATH_MERCHANT_ID)
  public ResponseEntity<MerchantDto> get(@PathVariable(MERCHANT_ID) String merchantId) {
    log.info("Get merchant, request: merchantId {}", merchantId);
    final Merchant merchant = merchantService.getMerchant(merchantId);
    log.info("Get merchant, response: {}", merchant);
    return ResponseEntity.ok(merchantMapper.mapMerchantToDto(merchant));
  }

  @Override
  @GetMapping
  public ResponseEntity<List<MerchantDto>> getAll(MerchantFilter filter,
      @PageableDefault(size = DEFAULT_PAGE_SIZE) @Valid Pageable pageable) {
    log.info("Get merchants, request: filter {}, pagination {}", filter, pageable);
    final var builder = MerchantSpecification.builder();
    if (!ObjectUtils.isEmpty(filter.getId())) {
      builder.id(filter.getId());
    }
    if (!ObjectUtils.isEmpty(filter.getMdmCode())) {
      builder.mdmCode(filter.getMdmCode());
    }
    if (!ObjectUtils.isEmpty(filter.getName())) {
      builder.name(filter.getName());
    }
    if (!ObjectUtils.isEmpty(filter.getState())) {
      builder.state(filter.getState());
    }
    final var items = merchantService.getMerchants(builder.build(), pageable)
        .stream()
        .map(MerchantHE::getEntity)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
    log.info("Get merchants, response: {}", items);
    return ResponseEntity.ok(items.stream().map(merchantMapper::mapMerchantToDto)
        .collect(Collectors.toList()));
  }

  @Override
  @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_CREATE_MERCHANT")
  public ResponseEntity<MerchantDto> create(@RequestBody MerchantDto source) {
    log.info("Create merchant, request: body {}", source);
    final var merchant = merchantService
        .createMerchant(merchantMapper.mapDtoToMerchant(source));
    log.info("Create merchant, response: {}", merchant);
    return ResponseEntity.ok(merchantMapper.mapMerchantToDto(merchant));
  }

  @Override
  @PutMapping(path = PATH_MERCHANT_ID, consumes = MediaType.APPLICATION_JSON_VALUE)
  @AuditProcess("TSPACQ_BOX_CHANGE_PARAMS_MERCHANT")
  public ResponseEntity<MerchantDto> update(@PathVariable(MERCHANT_ID) String merchantId,
      @RequestBody String source) {
    log.info("Update merchant, request: merchantId {}, body {}", merchantId, source);
    final var merchant = merchantService.updateMerchant(merchantId, source);
    log.info("Update merchant, response: {}", merchant);
    return ResponseEntity.ok(merchantMapper.mapMerchantToDto(merchant));
  }

  @Override
  @PatchMapping(path = PATH_MERCHANT_ID, consumes = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<MerchantDto> patch(@PathVariable(MERCHANT_ID) String merchantId,
      @RequestBody String source) {
    return update(merchantId, source);
  }

  @Override
  @DeleteMapping(PATH_MERCHANT_ID)
  @ResponseStatus(HttpStatus.NO_CONTENT)
  @AuditProcess("TSPACQ_BOX_DELETE_MERCHANT")
  public void delete(@PathVariable(MERCHANT_ID) String merchantId) {
    log.info("Delete merchant, request: merchantId {}", merchantId);
    merchantService.deleteMerchant(merchantId);
  }

  @Override
  @PostMapping(path = PATH_BLOCK)
  @AuditProcess("TSPACQ_BOX_BLOCKING_MERCHANT")
  public ResponseEntity<MerchantDto> block(@PathVariable(MERCHANT_ID) String merchantId) {
    log.info("Block merchant, request: merchantId {}", merchantId);
    return ResponseEntity.ok(merchantMapper
        .mapMerchantToDto(merchantService.blockMerchant(merchantId)));
  }

  @Override
  @PostMapping(path = PATH_UNBLOCK)
  @AuditProcess("TSPACQ_BOX_UNLOCKING_MERCHANT")
  public ResponseEntity<MerchantDto> unblock(@PathVariable(MERCHANT_ID) String merchantId) {
    log.info("Unblock merchant, request: merchantId {}", merchantId);
    return ResponseEntity.ok(merchantMapper
        .mapMerchantToDto(merchantService.unblockMerchant(merchantId)));
  }
}
