package ru.vtb.tsp.ia.epay.merchant.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class InvalidDataException extends BusinessException {

  private static final String MESSAGE_DEFAULT = "Invalid data";
  private static final String MESSAGE_VALIDATION_ERROR =
      "Validation failed for object='%s. Error count: %d";

  @JsonProperty("errors")
  private List<ObjectError> errors = null;

  public InvalidDataException() {
    super(MESSAGE_DEFAULT);
  }

  public InvalidDataException(String message) {
    super(message);
  }

  public InvalidDataException(String message, Throwable cause) {
    super(message, cause);
  }

  public InvalidDataException(Throwable cause) {
    super(cause);
  }

  public InvalidDataException(BindingResult bindingResult) {
    super(String.format(MESSAGE_VALIDATION_ERROR, bindingResult.getObjectName(),
        bindingResult.getErrorCount()));
    this.errors = bindingResult.getAllErrors();
  }

  public List<ObjectError> getErrors() {
    return this.errors;
  }
}
