package ru.vtb.tsp.ia.epay.merchant.controller

import com.fasterxml.jackson.databind.ObjectMapper
import groovy.json.JsonSlurper
import org.springframework.data.domain.PageImpl
import org.springframework.data.web.PageableHandlerMethodArgumentResolver
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.test.web.servlet.MockMvc
import ru.vtb.tsp.ia.epay.core.domains.merchant.Merchant
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantParams
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantHE
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantMapper
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantMapperImpl
import ru.vtb.tsp.ia.epay.merchant.services.impl.MerchantServiceImpl
import spock.lang.Specification

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup

class MerchantControllerTest extends Specification {

    ObjectMapper mapper = new ObjectMapper()

    MerchantServiceImpl merchantService = Mock()
    MerchantMapper merchantMapper = new MerchantMapperImpl()
    def controller = new MerchantController(merchantService, merchantMapper)
    MockMvc mvc = standaloneSetup(controller)
            .setMessageConverters(new MappingJackson2HttpMessageConverter(new ObjectMapper()))
            .setCustomArgumentResolvers(new PageableHandlerMethodArgumentResolver())
            .build()

    def "GetMerchant"() {
        given:
        def merchantId = '00000001'
        def merchant = createMerchant(merchantId)
        merchantService.getMerchant(merchantId) >> merchant

        when:
        def response = mvc.perform(get("/api/v1/merchants/" + merchantId)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                name == 'Test'
                id == merchantId
            }
        }
    }

    def "GetMerchants"() {
        given:
        def m1 = createMerchant("001")
        def mHE1 = new MerchantHE(m1)

        def pageImpl = new PageImpl<MerchantHE>([mHE1])
        merchantService.getMerchants(_, _) >> pageImpl

        when:
        def response = mvc.perform(get("/api/v1/merchants")
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.size() == 1
            it[0].name == 'Test'
            it[0].id == '001'
        }
    }

    def "CreateMerchant"() {
        given:
        def merchant = createMerchant("TESTMERCHID")
        merchantService.createMerchant(_) >> merchant

        when:
        def response = mvc.perform(post("/api/v1/merchants")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(merchant)))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == 'TESTMERCHID'
                name == 'Test'
            }
        }
    }

    def "UpdateMerchant"() {
        given:
        def merchantId = 'MERCHID01'
        def body = '"name":"merch"'
        def merchant = createMerchant(merchantId)
        merchantService.updateMerchant(merchantId, _ as String) >> merchant

        when:
        def response = mvc.perform(put("/api/v1/merchants/" + merchantId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == 'MERCHID01'
                name == 'Test'
            }
        }
    }

    def "PatchMerchant"() {
        given:
        def merchantId = 'MERCHID01'
        def body = '"name":"merch"'
        def merchant = createMerchant(merchantId)
        merchantService.updateMerchant(merchantId, _ as String) >> merchant

        when:
        def response = mvc.perform(patch("/api/v1/merchants/" + merchantId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == 'MERCHID01'
                name == 'Test'
            }
        }
    }

    def "DeleteMerchant"() {
        given:
        def merchantId = 'MERCHID01'
        when:
        def response = mvc.perform(delete("/api/v1/merchants/" + merchantId)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        response.status == HttpStatus.NO_CONTENT.value()

        and:
        1 * merchantService.deleteMerchant(merchantId)
    }

    def "BlockingMerchant"() {
        given:
        def merchantId = 'MERCHID01'

        when:
        def responce = mvc.perform(post("/api/v1/merchants/" + merchantId + "/block")
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        responce.status == HttpStatus.OK.value()
    }

    def "UnLockingMerchant"() {
        given:
        def merchantId = 'MERCHID01'

        when:
        def responce = mvc.perform(post("/api/v1/merchants/" + merchantId + "/unblock")
                .contentType(MediaType.APPLICATION_ATOM_XML))
                .andReturn().response

        then:
        responce.status == HttpStatus.OK.value()
    }

    private Merchant createMerchant(String id) {
        return new Merchant(id: id, name: "Test", params: new MerchantParams())
    }
}
