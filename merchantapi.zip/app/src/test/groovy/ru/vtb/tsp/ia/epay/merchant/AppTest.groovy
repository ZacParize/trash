package ru.vtb.tsp.ia.epay.merchant


import spock.lang.Specification

class AppTest extends Specification {

    def "no exception thrown"() {
        when:
        print("test")

        then:
        noExceptionThrown()
    }
}
