package ru.vtb.tsp.ia.epay.merchant.controller

import com.fasterxml.jackson.databind.ObjectMapper
import groovy.json.JsonSlurper
import org.springframework.data.domain.PageImpl
import org.springframework.data.web.PageableHandlerMethodArgumentResolver
import org.springframework.http.HttpStatus
import org.springframework.http.MediaType
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter
import org.springframework.test.web.servlet.MockMvc
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSite
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteCardParams
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams
import ru.vtb.tsp.ia.epay.merchant.data.entity.MerchantSiteHE
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantSiteMapper
import ru.vtb.tsp.ia.epay.merchant.mapper.MerchantSiteMapperImpl
import ru.vtb.tsp.ia.epay.merchant.services.impl.MerchantSiteServiceImpl
import spock.lang.Specification

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup

class MerchantSiteControllerTest extends Specification {

    ObjectMapper mapper = new ObjectMapper()

    MerchantSiteServiceImpl merchantSiteService = Mock()
    MerchantSiteMapper merchantSiteMapper = new MerchantSiteMapperImpl()
    def controller = new MerchantSiteController(merchantSiteService, merchantSiteMapper)
    MockMvc mvc = standaloneSetup(controller)
            .setMessageConverters(new MappingJackson2HttpMessageConverter(new ObjectMapper()))
            .setCustomArgumentResolvers(new PageableHandlerMethodArgumentResolver())
            .build()

    def "Get Merchant Site"() {
        given:
        def mstId = '00000001-001'
        def site = new MerchantSiteHE(createMst(mstId))
        merchantSiteService.getMerchantSite(mstId) >> site

        when:
        def response = mvc.perform(get("/api/v1/sites/" + mstId)
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                name == 'Test'
                id == mstId
                externalApplicationId == 'app-id'
            }
        }
    }

    def "Get Merchant Sites"() {
        given:
        def mstId = '00000001-001'
        def mstHE = new MerchantSiteHE(createMst(mstId))
        def pageImpl = new PageImpl<MerchantSiteHE>([mstHE])
        merchantSiteService.getMerchantSites(_, _) >> pageImpl

        when:
        def response = mvc.perform(get("/api/v1/sites")
                .contentType(MediaType.APPLICATION_JSON))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.size() == 1
            it[0].name == 'Test'
            it[0].id == mstId
            it[0].login == 'login'
            it[0].externalApplicationId == 'app-id'
        }
    }

    def "Create Merchant Site"() {
        given:
        def mstId = '00000001-001'
        def site = createMst(mstId)
        merchantSiteService.createMerchantSite(_ as MerchantSite) >> site

        when:
        def response = mvc.perform(post("/api/v1/sites")
                .contentType(MediaType.APPLICATION_JSON)
                .content(mapper.writeValueAsString(merchantSiteMapper.mapMerchantSiteToDto(site))))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == mstId
                name == 'Test'
                externalApplicationId == 'app-id'
            }
        }
    }

    def "Update Merchant Site"() {
        given:
        def mstId = '00000001-001'
        def site = createMst(mstId)
        def body = '"name":"merch"'
        merchantSiteService.updateMerchantSite(mstId, _ as String) >> site

        when:
        def response = mvc.perform(put("/api/v1/sites/" + mstId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == mstId
                name == 'Test'
                externalApplicationId == 'app-id'
            }
        }
    }

    def "PatchMerchant"() {
        given:
        def mstId = '00000001-001'
        def site = createMst(mstId)
        def body = '"name":"merch"'
        merchantSiteService.updateMerchantSite(mstId, _ as String) >> site

        when:
        def response = mvc.perform(patch("/api/v1/sites/" + mstId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(body))
                .andReturn().response

        then:
        response.status == HttpStatus.OK.value()
        response.contentType.contains('application/json')

        and:
        with(new JsonSlurper().parseText(response.contentAsString) as Map) {
            it.any {
                id == mstId
                name == 'Test'
                externalApplicationId == 'app-id'
            }
        }
    }

    private MerchantSite createMst(String id) {
        def siteParams = MerchantSiteParams.builder()
                .mcc("1234")
                .cardParams(MerchantSiteCardParams.builder()
                        .enableCardPayment(true)
                        .build())
                .build()
        return new MerchantSite(id: id, merchantId: "MERCHID001", name: "Test",
                url: "http://localhost", login: "login", externalApplicationId: "app-id",
                params: siteParams)
    }
}
