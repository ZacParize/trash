plugins {
    idea
    base
    java
    groovy
    application
    `maven-publish`
    checkstyle
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")

val toolDir = "${project.buildDir}/tools"
val toolDependency by configurations.compileOnly
toolDependency.isCanBeResolved = true

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
        exclude("io.springfox", "springfox-bean-validators")
        exclude("io.springfox", "springfox-boot-starter")
        exclude("io.springfox", "springfox-core")
        exclude("io.springfox", "springfox-data-rest")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    // Core api dependencies
    toolDependency("ru.vtb.dev.corp.ia.epay:epay-build-tools")
    implementation("io.jaegertracing:jaeger-proto:0.7.0")
    //implementation("ru.vtb.tsds:tsds-starter:4.2.3.12")

    //Spring
    implementation("org.springframework.boot:spring-boot")
    implementation("org.springframework.kafka:spring-kafka")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.core:jackson-databind")

    // Tracing
    implementation("io.opentracing.contrib:opentracing-spring-jaeger-cloud-starter")

    //Monitoring
    implementation("io.micrometer:micrometer-registry-prometheus")

    // Validation
    implementation("javax.validation:validation-api")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/groovy")
    }
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    enabled = true
}

tasks.bootJar {
    // Set bootJar file name
    enabled = false
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
    maxHeapSize = "1G"
}

val extractToolsDependency by tasks.register<Copy>("extractToolsDependency") {
    dependsOn(toolDependency)
    from(toolDependency.map {
        zipTree(it)
    })
    include("config/**")
    into(toolDir)
    includeEmptyDirs = false
}

tasks.withType<Checkstyle>().configureEach {
    dependsOn(extractToolsDependency)
    reports {
        xml.required.set(false)
        html.required.set(true)
    }
}

checkstyle {
    maxWarnings = 0
    isShowViolations = true
    isIgnoreFailures = false
    toolVersion = "9.3"
    configFile = file("${toolDir}/config/checkstyle/checkstyle.xml")
}

idea {
    // Download javadoc and sources
    module {
        isDownloadSources = true
        isDownloadJavadoc = true
    }
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
    }
}