package ru.vtb.tsp.ia.epay.tracing.configs.properties;

import java.util.Collections;
import java.util.List;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@Data
@ConfigurationProperties(
    TracingConfigurationKafkaProperties.TRACING_CONFIGURATION_KAFKA_PROPERTIES_PREFIX)
@EnableConfigurationProperties(TracingConfigurationKafkaSSLProperties.class)
public class TracingConfigurationKafkaProperties {

  public static final String TRACING_CONFIGURATION_KAFKA_PROPERTIES_PREFIX =
      TracingConfigurationProperties.TRACING_CONFIGURATION_PROPERTIES_PREFIX + ".kafka-sender";
  private static final int DEFAULT_PARTITIONS_COUNT = 10;
  private static final int DEFAULT_REPLICAS_COUNT = 10;

  private List<String> bootstrapServers = Collections.singletonList("localhost:9092");
  private List<String> topics = Collections.emptyList();
  private int partitionsCount = DEFAULT_PARTITIONS_COUNT;
  private int replicasCount = DEFAULT_REPLICAS_COUNT;
  @Autowired
  private TracingConfigurationKafkaSSLProperties ssl;

}