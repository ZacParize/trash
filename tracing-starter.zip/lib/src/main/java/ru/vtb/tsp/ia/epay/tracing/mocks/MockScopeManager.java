package ru.vtb.tsp.ia.epay.tracing.mocks;

import io.opentracing.Scope;
import io.opentracing.ScopeManager;
import io.opentracing.Span;

public class MockScopeManager implements ScopeManager {

  private final Scope scope = new MockScope();
  private final Span span = new MockSpan();

  @Override
  public Scope activate(Span span) {
    return scope;
  }

  @Override
  public Span activeSpan() {
    return span;
  }
}