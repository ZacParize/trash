package ru.vtb.tsp.ia.epay.tracing.mocks;

import io.opentracing.Scope;
import io.opentracing.ScopeManager;
import io.opentracing.Span;
import io.opentracing.SpanContext;
import io.opentracing.Tracer;
import io.opentracing.propagation.Format;

public class MockTracer implements Tracer {

  private final ScopeManager scopeManager = new MockScopeManager();
  private final Span span = new MockSpan();
  private final Scope scope = new MockScope();
  private final SpanBuilder spanBuilder = new MockSpanBuilder();

  @Override
  public ScopeManager scopeManager() {
    return scopeManager;
  }

  @Override
  public Span activeSpan() {
    return span;
  }

  @Override
  public Scope activateSpan(Span span) {
    return scope;
  }

  @Override
  public SpanBuilder buildSpan(String operationName) {
    return spanBuilder;
  }

  @Override
  public <C> void inject(SpanContext spanContext, Format<C> format, C carrier) {
  }

  @Override
  public <C> SpanContext extract(Format<C> format, C carrier) {
    return span.context();
  }

  @Override
  public void close() {
  }
}