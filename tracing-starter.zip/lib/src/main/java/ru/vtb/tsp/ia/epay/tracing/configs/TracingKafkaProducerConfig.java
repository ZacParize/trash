package ru.vtb.tsp.ia.epay.tracing.configs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.SneakyThrows;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationKafkaProperties;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationKafkaSSLProperties;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationProperties;

@Configuration
@EnableConfigurationProperties(TracingConfigurationProperties.class)
public class TracingKafkaProducerConfig {

  public static final String KAFKA_TRACING_TEMPLATE = "kafkaTracingTemplate";
  private static final String SSL_MODE = "SSL";
  private static final int TIMEOUT = 5000;

  @Autowired
  private TracingConfigurationKafkaProperties kafkaProperties;

  @Bean
  public ProducerFactory<String, ?> producerFactory() {
    final var configuration = producerConfig(kafkaProperties);
    createTopics(configuration, kafkaProperties.getTopics(), kafkaProperties.getPartitionsCount(),
        kafkaProperties.getReplicasCount());
    return new DefaultKafkaProducerFactory<>(configuration);
  }

  @Bean(KAFKA_TRACING_TEMPLATE)
  public KafkaTemplate<String, ?> kafkaPortalTemplate(
      ProducerFactory<String, ?> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

  @NotNull
  private static Map<String, Object> producerConfig(
      @Nullable TracingConfigurationKafkaProperties kafkaProperties) {
    if (Objects.isNull(kafkaProperties)) {
      return Collections.emptyMap();
    }
    HashMap<String, Object> configuration = new HashMap<>();
    configuration.put("bootstrap.servers", Objects.requireNonNull(kafkaProperties
        .getBootstrapServers(), "Tracing kafka bootstrap servers can't be null"));
    configuration.put("acks", "all");
    configuration.put("spring.json.add.type.headers", true);
    configuration.put("batch.size", 16384);
    configuration.put("buffer.memory", 33554432);
    configuration.put("key.serializer", StringSerializer.class);
    configuration.put("value.serializer", JsonSerializer.class);
    configuration.put("compression.type", "gzip");
    configuration.put("retries", 1);
    setSslProperties(configuration, kafkaProperties.getSsl());
    return configuration;
  }

  private static void setSslProperties(@Nullable Map<String, Object> configuration,
      @Nullable TracingConfigurationKafkaSSLProperties kafkaSSLProperties) {
    if (ObjectUtils.isEmpty(configuration) || ObjectUtils.isEmpty(kafkaSSLProperties)) {
      return;
    }
    configuration.put(SslConfigs.SSL_PROTOCOL_CONFIG, kafkaSSLProperties.getProtocol());
    configuration.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, SSL_MODE);
    configuration.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG,
        kafkaSSLProperties.getTrustStoreType());
    configuration.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
        kafkaSSLProperties.getTrustStoreLocation());
    configuration.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
        kafkaSSLProperties.getTrustStorePassword());
    configuration.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, kafkaSSLProperties.getKeyStoreType());
    configuration.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
        kafkaSSLProperties.getKeyStoreLocation());
    configuration.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,
        kafkaSSLProperties.getKeyStorePassword());
    configuration.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG, kafkaSSLProperties.getKeyPassword());
  }

  @SneakyThrows
  private static void createTopics(@NotEmpty Map<String, Object> configuration,
      @NotEmpty List<String> topics,
      int partitionsCount,
      int replicasCount) {
    if (ObjectUtils.isEmpty(configuration)) {
      return;
    }
    final var adminClient = AdminClient.create(configuration);
    final var names = adminClient.listTopics().names().get();
    final var newTopics = new ArrayList<NewTopic>();
    topics.forEach(topic -> {
      if (names.contains(topic) || newTopics.stream()
          .map(NewTopic::name).toList().contains(topic)) {
        return;
      }
      newTopics.add(TopicBuilder.name(topic)
          .partitions(partitionsCount)
          .replicas(replicasCount)
          .build());
    });

    if (newTopics.size() > 0) {
      try {
        adminClient.createTopics(newTopics).all().get(TIMEOUT, TimeUnit.MILLISECONDS);
      } catch (Exception ex) {
        // nothing to do, topics already exist
      }
    }
  }

}