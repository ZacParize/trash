package ru.vtb.tsp.ia.epay.tracing.headers;

import org.springframework.kafka.support.KafkaHeaders;

public abstract class TracingKafkaHeaders extends KafkaHeaders {

  public static final String TRACE_ID = "uber-trace-id";

}