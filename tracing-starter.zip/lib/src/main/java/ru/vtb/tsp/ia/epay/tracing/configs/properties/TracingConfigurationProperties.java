package ru.vtb.tsp.ia.epay.tracing.configs.properties;

import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@Data
@ConfigurationProperties(prefix =
    TracingConfigurationProperties.TRACING_CONFIGURATION_PROPERTIES_PREFIX)
@EnableConfigurationProperties(TracingConfigurationKafkaProperties.class)
public class TracingConfigurationProperties {

  public static final String TRACING_CONFIGURATION_PROPERTIES_PREFIX = "opentracing.jaeger";

  private boolean enabled = true;

  @Value("${opentracing.jaeger.service-name:${spring.application.name:unknown}}")
  private String serviceName;

  private boolean logSpans = true;

  @Autowired
  private TracingConfigurationKafkaProperties kafkaSender;

}
