package ru.vtb.tsp.ia.epay.tracing.configs.properties;


import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@Data
@ConfigurationProperties(
    TracingConfigurationKafkaProperties.TRACING_CONFIGURATION_KAFKA_PROPERTIES_PREFIX + ".ssl")
public class TracingConfigurationKafkaSSLProperties {

  private String protocol;
  private String trustStoreType;
  private String trustStoreLocation;
  private String trustStorePassword;
  private String keyStoreType;
  private String keyStoreLocation;
  private String keyStorePassword;
  private String keyPassword;

}