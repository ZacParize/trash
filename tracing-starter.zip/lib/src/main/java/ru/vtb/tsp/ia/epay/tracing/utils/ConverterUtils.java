package ru.vtb.tsp.ia.epay.tracing.utils;

import com.google.protobuf.ByteString;
import com.google.protobuf.util.Durations;
import com.google.protobuf.util.Timestamps;
import io.jaegertracing.api_v2.Model;
import io.jaegertracing.internal.JaegerSpan;
import io.jaegertracing.internal.LogData;
import io.jaegertracing.internal.Reference;
import io.opentracing.References;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ConverterUtils {

  public static Model.Span convertSpan(JaegerSpan jaegerSpan) {
    final var context = jaegerSpan.context();
    final var references = buildReferences(jaegerSpan.getReferences());
    return Model.Span.newBuilder()
        .setTraceId(ByteString.copyFrom(
            addArray(context.getTraceIdHigh() != 0L
                    ? BigInteger.valueOf(context.getTraceIdHigh()).toByteArray() : new byte[8],
                BigInteger.valueOf(context.getTraceIdLow()).toByteArray())))
        .setSpanId(ByteString.copyFrom(BigInteger.valueOf(context.getSpanId()).toByteArray()))
        .setOperationName(jaegerSpan.getOperationName())
        .setFlags(context.getFlags())
        .setStartTime(Timestamps.fromMicros(jaegerSpan.getStart()))
        .setDuration(Durations.fromMicros(jaegerSpan.getDuration()))
        .addAllReferences(references)
        .addAllTags(buildTags(jaegerSpan.getTags()))
        .addAllLogs(buildLogs(jaegerSpan.getLogs()))
        .setProcess(Model.Process.newBuilder()
            .setServiceName(jaegerSpan.getTracer().getServiceName())
            .addAllTags(buildTags(jaegerSpan.getTracer().tags()))
            .build())
        .build();
  }

  static List<Model.SpanRef> buildReferences(List<Reference> references) {
    final var protobufReferences = new ArrayList<Model.SpanRef>(references.size());
    for (Reference reference : references) {
      final var protobufRefType = References.CHILD_OF.equals(reference.getType())
          ? Model.SpanRefType.CHILD_OF
          : Model.SpanRefType.FOLLOWS_FROM;
      protobufReferences.add(Model.SpanRef.newBuilder()
          .setRefType(protobufRefType)
          .setTraceId(ByteString.copyFromUtf8(reference.getSpanContext().getTraceId()))
          .setSpanId(ByteString.copyFromUtf8(reference.getSpanContext().toSpanId()))
          .setTraceId(ByteString.copyFrom(
              addArray(reference.getSpanContext().getTraceIdHigh() != 0L
                      ? BigInteger.valueOf(reference.getSpanContext().getTraceIdHigh())
                        .toByteArray()
                      : new byte[8],
                  BigInteger.valueOf(reference.getSpanContext().getTraceIdLow()).toByteArray())))
          .setSpanId(ByteString.copyFrom(
              BigInteger.valueOf(reference.getSpanContext().getSpanId()).toByteArray()))
          .build());
    }
    return protobufReferences;
  }

  private static byte[] addArray(final byte[] array1, final byte[] array2) {
    final var joinedArray = Arrays.copyOf(array1, array1.length + array2.length);
    System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
    return joinedArray;
  }


  static List<Model.Log> buildLogs(List<LogData> logs) {
    final var protobufLogs = new ArrayList<Model.Log>();
    if (logs != null) {
      Model.Log.Builder protobufLogBuilder;
      List<Model.KeyValue> tags;
      for (LogData logData : logs) {
        protobufLogBuilder = Model.Log.newBuilder();
        protobufLogBuilder.setTimestamp(Timestamps.fromMicros(logData.getTime()));
        if (logData.getFields() != null) {
          protobufLogBuilder.addAllFields(buildTags(logData.getFields()));
        } else {
          tags = new ArrayList<>();
          if (logData.getMessage() != null) {
            tags.add(buildTag("event", logData.getMessage()));
          }
          protobufLogBuilder.addAllFields(tags);
        }
        protobufLogs.add(protobufLogBuilder.build());
      }
    }
    return protobufLogs;
  }

  public static List<Model.KeyValue> buildTags(Map<String, ?> tags) {
    final var protobufTags = new ArrayList<Model.KeyValue>();
    if (tags != null) {
      String tagKey;
      Object tagValue;
      for (Map.Entry<String, ?> entry : tags.entrySet()) {
        tagKey = entry.getKey();
        tagValue = entry.getValue();
        protobufTags.add(buildTag(tagKey, tagValue));
      }
    }
    return protobufTags;
  }

  static Model.KeyValue buildTag(String tagKey, Object tagValue) {
    final var tagBuilder = Model.KeyValue.newBuilder();
    tagBuilder.setKey(tagKey);
    if (tagValue instanceof Integer || tagValue instanceof Short || tagValue instanceof Long) {
      tagBuilder.setVType(Model.ValueType.INT64);
      tagBuilder.setVInt64(((Number) tagValue).longValue());
    } else if (tagValue instanceof Double || tagValue instanceof Float) {
      tagBuilder.setVType(Model.ValueType.FLOAT64);
      tagBuilder.setVFloat64(((Number) tagValue).doubleValue());
    } else if (tagValue instanceof Boolean) {
      tagBuilder.setVType(Model.ValueType.BOOL);
      tagBuilder.setVBool((Boolean) tagValue);
    } else {
      tagBuilder.setVType(Model.ValueType.STRING);
      tagBuilder.setVStr(String.valueOf(tagValue));
    }
    return tagBuilder.build();
  }

}