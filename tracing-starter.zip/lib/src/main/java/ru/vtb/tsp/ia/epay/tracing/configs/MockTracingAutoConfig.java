package ru.vtb.tsp.ia.epay.tracing.configs;

import io.jaegertracing.internal.JaegerTracer;
import io.opentracing.Tracer;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationProperties;
import ru.vtb.tsp.ia.epay.tracing.mocks.MockTracer;

@Configuration
@ConditionalOnClass(JaegerTracer.class)
@ConditionalOnMissingBean(Tracer.class)
@ConditionalOnProperty(
    value = TracingConfigurationProperties.TRACING_CONFIGURATION_PROPERTIES_PREFIX + ".enabled",
    havingValue = "false")
@AutoConfigureBefore(TracingAutoConfig.class)
public class MockTracingAutoConfig {

  @Bean
  public Tracer jaegerTracer() {
    return new MockTracer();

  }

}