package ru.vtb.tsp.ia.epay.tracing.mocks;

import io.opentracing.Scope;

public class MockScope implements Scope {

  @Override
  public void close() {
  }
}