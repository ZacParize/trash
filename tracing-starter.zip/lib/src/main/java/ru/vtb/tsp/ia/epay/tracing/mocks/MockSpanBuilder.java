package ru.vtb.tsp.ia.epay.tracing.mocks;

import io.opentracing.Span;
import io.opentracing.SpanContext;
import io.opentracing.Tracer.SpanBuilder;
import io.opentracing.tag.Tag;

public class MockSpanBuilder implements SpanBuilder {

  private final Span span = new MockSpan();

  @Override
  public SpanBuilder asChildOf(SpanContext parent) {
    return this;
  }

  @Override
  public SpanBuilder asChildOf(Span parent) {
    return this;
  }

  @Override
  public SpanBuilder addReference(String referenceType, SpanContext referencedContext) {
    return this;
  }

  @Override
  public SpanBuilder ignoreActiveSpan() {
    return this;
  }

  @Override
  public SpanBuilder withTag(String key, String value) {
    return this;
  }

  @Override
  public SpanBuilder withTag(String key, boolean value) {
    return this;
  }

  @Override
  public SpanBuilder withTag(String key, Number value) {
    return this;
  }

  @Override
  public <T> SpanBuilder withTag(Tag<T> tag, T value) {
    return this;
  }

  @Override
  public SpanBuilder withStartTimestamp(long microseconds) {
    return this;
  }

  @Override
  public Span start() {
    return span;
  }
}