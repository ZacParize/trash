package ru.vtb.tsp.ia.epay.tracing.configs;

import static ru.vtb.tsp.ia.epay.tracing.configs.TracingKafkaProducerConfig.KAFKA_TRACING_TEMPLATE;

import io.jaegertracing.internal.JaegerTracer;
import io.jaegertracing.internal.metrics.Metrics;
import io.jaegertracing.internal.metrics.NoopMetricsFactory;
import io.jaegertracing.internal.reporters.CompositeReporter;
import io.jaegertracing.internal.reporters.LoggingReporter;
import io.jaegertracing.internal.reporters.RemoteReporter;
import io.jaegertracing.internal.samplers.ConstSampler;
import io.jaegertracing.spi.MetricsFactory;
import io.jaegertracing.spi.Reporter;
import io.jaegertracing.spi.Sampler;
import io.opentracing.Tracer;
import io.opentracing.contrib.java.spring.jaeger.starter.JaegerAutoConfiguration;
import io.opentracing.contrib.java.spring.jaeger.starter.JaegerConfigurationProperties;
import io.opentracing.contrib.java.spring.jaeger.starter.ReporterAppender;
import io.opentracing.contrib.java.spring.jaeger.starter.TracerBuilderCustomizer;
import io.opentracing.contrib.spring.tracer.configuration.TracerAutoConfiguration;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationKafkaProperties;
import ru.vtb.tsp.ia.epay.tracing.configs.properties.TracingConfigurationProperties;
import ru.vtb.tsp.ia.epay.tracing.senders.KafkaProtobufSender;

@Slf4j
@Configuration
@ConditionalOnClass(JaegerTracer.class)
@ConditionalOnMissingBean(Tracer.class)
@ConditionalOnProperty(
    value = TracingConfigurationProperties.TRACING_CONFIGURATION_PROPERTIES_PREFIX + ".enabled",
    havingValue = "true", matchIfMissing = true)
@AutoConfigureBefore({JaegerAutoConfiguration.class, TracerAutoConfiguration.class})
@EnableConfigurationProperties({TracingConfigurationProperties.class,
    JaegerConfigurationProperties.class})
public class TracingAutoConfig {

  @Autowired(required = false)
  private List<TracerBuilderCustomizer> tracerCustomizers = Collections.emptyList();

  @Autowired
  private JaegerConfigurationProperties oldProperties;

  @Autowired
  private TracingConfigurationProperties newProperties;

  @Bean
  @ConditionalOnMissingBean
  public Tracer tracer(@NotNull Sampler sampler,
      @NotNull Reporter reporter,
      @NotNull Metrics metrics) {
    final JaegerTracer.Builder builder =
        new JaegerTracer.Builder(newProperties.getServiceName())
            .withReporter(reporter)
            .withSampler(sampler)
            .withTags(oldProperties.determineTags())
            .withMetrics(metrics);

    tracerCustomizers.forEach(c -> c.customize(builder));

    return builder.build();
  }

  @Bean
  @ConditionalOnMissingBean
  public Metrics metrics(MetricsFactory metricsFactory) {
    return new Metrics(metricsFactory);
  }

  @Bean
  @ConditionalOnMissingBean
  public MetricsFactory metricsFactory() {
    return new NoopMetricsFactory();
  }

  @Bean
  @ConditionalOnMissingBean
  public Sampler sampler() {
    // sampling every trace
    return new ConstSampler(true);
  }

  @Bean
  @ConditionalOnMissingBean
  public Reporter reporter(JaegerConfigurationProperties properties,
      @Qualifier(KAFKA_TRACING_TEMPLATE) KafkaTemplate<String, byte[]> kafkaTemplate,
      Metrics metrics,
      @Autowired(required = false) ReporterAppender reporterAppender) {

    final var reporters = new LinkedList<Reporter>();
    final var topics = Optional.ofNullable(newProperties.getKafkaSender())
            .map(TracingConfigurationKafkaProperties::getTopics)
                .orElse(Collections.emptyList());

    reporters.add(new RemoteReporter.Builder()
        .withSender(new KafkaProtobufSender(kafkaTemplate, topics))
        .withMetrics(metrics).build());

    if (properties.isLogSpans()) {
      reporters.add(new LoggingReporter());
    }

    if (reporterAppender != null) {
      reporterAppender.append(reporters);
    }

    return new CompositeReporter(reporters.toArray(new Reporter[reporters.size()]));
  }

  @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
  @Bean(KAFKA_TRACING_TEMPLATE)
  public KafkaTemplate<String, ?> kafkaBoxTemplate(ProducerFactory<String, ?> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }
}