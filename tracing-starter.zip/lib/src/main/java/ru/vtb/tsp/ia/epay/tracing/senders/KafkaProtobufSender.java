package ru.vtb.tsp.ia.epay.tracing.senders;

import io.jaegertracing.api_v2.Model;
import io.jaegertracing.internal.JaegerSpan;
import io.jaegertracing.internal.exceptions.SenderException;
import io.jaegertracing.spi.Sender;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.lang.Nullable;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.tracing.utils.ConverterUtils;

@Slf4j
public class KafkaProtobufSender implements Sender {

  private final KafkaTemplate<String, byte[]> kafkaTemplate;
  private final List<String> topics;
  private final ListenableFutureCallback<SendResult<String, byte[]>> callbackForResult;

  public KafkaProtobufSender(@Nullable KafkaTemplate<String, byte[]> kafkaTemplate,
                             @Nullable List<String> topics) {
    this(kafkaTemplate, topics,
        new ListenableFutureCallback<>() {
          @Override
          public void onSuccess(@NotNull SendResult<String, byte[]> result) {
            log.debug("Span with key {} and value {} is processed",
                result.getProducerRecord().key(), result.getProducerRecord().value());
          }

          @Override
          public void onFailure(@NotNull Throwable ex) {
            log.error("Span is processed with error", ex);
          }
        });
  }

  public KafkaProtobufSender(@Nullable KafkaTemplate<String, byte[]> kafkaTemplate,
      @Nullable List<String> topics,
      @Nullable ListenableFutureCallback<SendResult<String, byte[]>> callbackForResult) {
    this.kafkaTemplate = Objects.requireNonNull(kafkaTemplate,
        "Kafka template can't be null");
    this.topics = Objects.requireNonNull(topics,
        "Topics list can't be null");
    this.callbackForResult = Objects.requireNonNull(callbackForResult,
        "Trace result callback can't be null");
  }

  public void send(Model.Span span) throws SenderException {
    if (Objects.isNull(span)) {
      return;
    }
    try {
      topics.forEach(topic -> kafkaTemplate.send(topic,
              String.valueOf(span.getTraceId()), span.toByteArray())
            .addCallback(callbackForResult));
    } catch (Exception ex) {
      throw new SenderException("Could not send span", ex, 1);
    }
  }

  @Override
  public int append(JaegerSpan span) throws SenderException {
    send(ConverterUtils.convertSpan(span));
    return 1;
  }

  @Override
  public int flush() {
    return 0;
  }

  @Override
  public int close() {
    kafkaTemplate.destroy();
    return 0;
  }
}