package ru.vtb.tsp.ia.epay.tracing.mocks;

import io.opentracing.SpanContext;
import java.util.Collections;
import java.util.Map.Entry;
import java.util.UUID;

public class MockSpanContext implements SpanContext {

  private final String traceId = UUID.randomUUID().toString();
  private final String spanId = UUID.randomUUID().toString();

  @Override
  public String toTraceId() {
    return traceId;
  }

  @Override
  public String toSpanId() {
    return spanId;
  }

  @Override
  public Iterable<Entry<String, String>> baggageItems() {
    return Collections.emptyList();
  }
}