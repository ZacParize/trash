#!/bin/bash
function ComponentBuild() {
  gradle clean -i build ${GRADLE_CLI_OPTIONS} -p "${1}"
}
"$@"