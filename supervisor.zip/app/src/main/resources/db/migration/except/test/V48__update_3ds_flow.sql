INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (32,
        'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter") && transaction.getContext().containsKey("XID") && transaction.getContext().containsKey("CAVV") && transaction.getContext().containsKey("ECI")',
        '3DS Multicard operation', '3DS Multicard operation');
INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (33, 'transaction != null && "CARD_PAYMENT_TEST".equals(transaction.getType().name())',
        'Card test purchase flow check',
        'Card test purchase, checking whether transaction should go throughout purchase flow');

UPDATE flow_points
SET flow_command_ref = 33
WHERE flow_point_id = 0;

UPDATE flow_commands
SET command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")'
WHERE flow_command_id = 29;


UPDATE flow_points
SET flow_command_ref = 0,
    "rank"           = 0
WHERE flow_point_id = 36;

UPDATE flow_points
SET flow_command_ref = 1,
    "rank"           = 1
WHERE flow_point_id = 37;

UPDATE flow_points
SET flow_command_ref = 17,
    "rank"           = 2
WHERE flow_point_id = 38;

UPDATE flow_points
SET flow_command_ref = 28,
    "rank"           = 3
WHERE flow_point_id = 39;

UPDATE flow_points
SET flow_command_ref = 29,
    "rank"           = 5
WHERE flow_point_id = 40;

UPDATE flow_points
SET flow_command_ref = 3,
    "rank"           = 9
WHERE flow_point_id = 42;

UPDATE flow_points
SET flow_command_ref = 32,
    "rank"           = 8
WHERE flow_point_id = 41;