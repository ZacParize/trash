UPDATE merchant_sites mst
SET params = params || jsonb_build_object('mcc', '4722');

INSERT INTO merchants (merch_id, name, params)
VALUES('33685533', 'Test 3ds', NULL);

INSERT INTO merchant_sites (mst_id, merch_ref, url, name, params, login)
VALUES('TESTMST3DS', '33685533', 'http://testvtb.ru', 'Test 3ds', '{"mcc": "4722", "terminalId": "77054517", "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback", "orderLifeTime": "PT20m", "partialRefund": true, "merchantPayments": {"sbpPayment": true, "cardPayment": true, "cardFlowThreeDS": true, "cardFlowThreeDSOnMerchantSide": false}, "merchantTransfers": {"a2cTransferParams": {"FPTTI": "Payment Transaction", "SNAME": "Test LLC", "SFNAME": "OOO", "SLNAME": "Gde dengi", "BICCODE": "044525187", "FSOURCE": "08", "MRPPHONE": "+7001234567"}}}'::jsonb, 'test_efcp_epa@region.vtb.ru');

INSERT INTO rules (rule_id, name, group_id, mst_ref, chn_ref)
VALUES(67, '3DS_RULE#TEST', 'CARD_PURCHASE', 'TESTMST3DS', 3);

INSERT INTO rule_contents (rule_content_id, rule_ref, name, weight, value)
VALUES  (133, 67, '3DS_RULECONTENT#MAX_AMOUNT', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
        (134, 67, '3DS_RULECONTENT#CURRENCY', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());');
