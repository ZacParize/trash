update transactions
set state = 'SBP_PAYMENT_CREATED',
    data = jsonb_set(data, '{status}', to_jsonb('SBP_PAYMENT_CREATED'::text), true)
where type IN ('SBP_PAYMENT')
  and state = 'DECLINED'
  and data -> 'error' ->> 'id' = '10200005'
  and data -> 'error' ->> 'message' in ('SBP_BAD_GATEWAY', 'Technical error');

update transactions
set state = 'SBP_REFUND_CREATED',
    data = jsonb_set(data, '{status}', to_jsonb('SBP_REFUND_CREATED'::text), true)
where type IN ('PARTIAL_SBP_REFUND', 'SBP_REFUND')
  and state = 'DECLINED'
  and data -> 'error' ->> 'id' = '10200005'
  and data -> 'error' ->> 'message' in ('SBP_BAD_GATEWAY', 'Technical error');

update orders SET state = 'PAID' where order_id in ('61e3ae95-d985-4bf5-b10a-1135cda11119',
                                                    '248bf6d4-0c98-479f-a003-25dad2f2e7b0',
                                                    'c9a2e98f-10f8-4681-ba61-acc00b57af48');

update transactions
set state = 'RECONCILED',
    data = jsonb_set(data, '{status}', to_jsonb('RECONCILED'::text), true)
where transaction_id in ('2d9f504a-fd4d-43d9-b71b-71bbe3a5eaad-vpay',
                         'd5a32e30-9a8e-4328-a24a-0acedf4bf1d3-vpay',
                         'cb62f5d5-bc9e-4947-94e7-75df8d222914-vpay');

update transactions
set data = jsonb_set(data, '{orderInfo, orderState}', to_jsonb('PAID'::text), true)
where transaction_id in ('2d9f504a-fd4d-43d9-b71b-71bbe3a5eaad-vpay',
                         'd5a32e30-9a8e-4328-a24a-0acedf4bf1d3-vpay',
                         'cb62f5d5-bc9e-4947-94e7-75df8d222914-vpay');