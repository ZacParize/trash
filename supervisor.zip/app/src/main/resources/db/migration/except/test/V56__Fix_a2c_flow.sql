insert into flow_commands (flow_command_id, command, name, description)
values (34, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter") && !"DECLINED".equals(transaction.getStatus().getValue())', 'Account to card transfer, gateway adapter', 'Account to card transfer, gateway adapter')
ON CONFLICT DO NOTHING;

update flow_points set flow_command_ref=34
where flow_point_id = 45;
