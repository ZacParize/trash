UPDATE flow_commands
SET command='transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "AREQ".equals(transaction.getContext().get("TDS_NEXT_STEP"))'
WHERE flow_command_id = 29;

UPDATE flow_commands
SET command='transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-merchantplugin") && transaction.getContext().containsKey("epay-gatewayadapter")'
WHERE flow_command_id = 3;
