insert into flows (flow_id, name, mst_ref, description)
values (8, 'Merchant callback flow', null, 'Standard  merchant callback flow')
ON CONFLICT DO NOTHING;

insert into flow_commands (flow_command_id, command, name, description)
values (20, 'transaction != null && "RECONCILED".equals(transaction.getStatus().getValue()) && transaction.getContext().containsKey("notifyMerchant")', 'Merchant callback notification', 'Merchant callback notification after payment or refund'),
    (21, 'transaction != null && "RECONCILED".equals(transaction.getStatus().getValue()) && transaction.getContext().containsKey("notifyMerchant") && !transaction.getContext().containsKey("epay-router")', 'Merchant callback notification route flow', 'Merchant callback notification flow with condition'),
    (22, 'transaction != null && "RECONCILED".equals(transaction.getStatus().getValue()) && transaction.getContext().containsKey("notifyMerchant") && transaction.getContext().containsKey("epay-router")', 'Merchant callback adapter', 'Merchant notification')
ON CONFLICT DO NOTHING;

insert into flow_points (flow_point_id, flow_ref, flow_command_ref, point, rank, name, description)
values (21, 8, 20, 'epay.supervisor-topic', 0, 'Merchant callback flow info', 'Merchant callback apply command'),
    (22, 8, 21, 'epay.router-topic', 1, 'Merchant callback router info', 'Merchant callback apply router command'),
    (23, 8, 22, 'epay.merchantplugin-topic', 2, 'Merchant callback plugin info', 'Merchant callback apply merchant plugin info command')
ON CONFLICT DO NOTHING;