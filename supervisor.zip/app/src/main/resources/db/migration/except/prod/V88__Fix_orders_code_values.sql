DO
$$
    DECLARE
        textType text = 'text';
        columnType text;
        row text;
    BEGIN

        columnType = (SELECT DATA_TYPE
                      FROM INFORMATION_SCHEMA.columns
                      WHERE COLUMN_NAME = 'code'
                        and TABLE_NAME = 'orders'
                        and TABLE_SCHEMA = (select current_schema()));
        IF columnType = textType THEN
            FOR row IN (
                SELECT ordr.order_id
                FROM orders ordr
                WHERE code in ('f22424c2-1ae8-2d0b-9739-3e74f46c7c33',
                               'f22454c2-1ae8-2d0b-9739-3e74f46c7c10',
                               'f22924g2-1ae8-2d0b-9739-4e74f46c7c11',
                               'f22824f2-1ae8-2d0b-9739-5e74f46c7c12',
                               'f22724d2-1ae8-2d0b-9739-6e74f46c7c13',
                               'f22624q2-1ae8-2d0b-9739-7e74f46c7c14',
                               'f22524a2-1ae8-2d0b-9739-8e74f46c7c15',
                               'f22424s2-1ae8-2d0b-9739-9e74f46c7c16',
                               'f22324d2-1ae8-2d0b-9739-0e74f46c7c17',
                               'f22224f2-1ae8-2d0b-9739-3e73f46c7c18',
                               'f2232ёg2-1ae8-2d0b-9739-3e72f46c7c19')
            )
            LOOP
                BEGIN
                    SELECT row::uuid;
                EXCEPTION WHEN OTHERS THEN
                    DELETE FROM transaction_info
                    WHERE transaction_ref in (SELECT transaction_id
                        FROM transactions WHERE order_ref = row);
                    DELETE FROM transactions WHERE order_ref = row;
                    DELETE FROM orders WHERE order_id = row;
                END;
            END LOOP;
        END IF;

    END;
$$