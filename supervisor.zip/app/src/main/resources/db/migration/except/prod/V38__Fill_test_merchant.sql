INSERT INTO merchants(merch_id, name, params) VALUES ('00000000', 'ИП Солодков О.B', NULL) ON CONFLICT DO NOTHING;

INSERT INTO merchant_sites(mst_id, merch_ref, url, name, login ,params)
VALUES ('00000000-0001', '00000000', 'ipsolodkovov-site.ru', 'IP Solodkov O.V. merchant site', 'vtb', '{}')
ON CONFLICT DO NOTHING;

INSERT INTO orders(order_id, code, mst_ref, mst_order_id, name, amount, currency_ref, state, description)
VALUES ('f22424c2-1ae8-2d0b-9739-3e74f46c7c33', 'f22424c2-1ae8-2d0b-9739-3e74f46c7c33', '00000000-0001', 'ORDERID000001', 'Заказ №0 у ИП Солодков', 10.01, 'RUB', 'CREATED',  NULL),
       ('f22454c2-1ae8-2d0b-9739-3e74f46c7c10', 'f22454c2-1ae8-2d0b-9739-3e74f46c7c10', '00000000-0001', 'ORDERID000002', 'Заказ №1 у ИП Солодков', 10.01, 'RUB', 'CREATED',  NULL),
       ('f22924g2-1ae8-2d0b-9739-4e74f46c7c11', 'f22924g2-1ae8-2d0b-9739-4e74f46c7c11', '00000000-0001', 'ORDERID000003', 'Заказ №2 у ИП Солодков', 50.20, 'RUB', 'CREATED',  NULL),
       ('f22824f2-1ae8-2d0b-9739-5e74f46c7c12', 'f22824f2-1ae8-2d0b-9739-5e74f46c7c12', '00000000-0001', 'ORDERID000004', 'Заказ №3 у ИП Солодков', 60.55, 'RUB', 'CREATED',  NULL),
       ('f22724d2-1ae8-2d0b-9739-6e74f46c7c13', 'f22724d2-1ae8-2d0b-9739-6e74f46c7c13', '00000000-0001', 'ORDERID000005', 'Заказ №4 у ИП Солодков', 120.07, 'RUB', 'CREATED',  NULL),
       ('f22624q2-1ae8-2d0b-9739-7e74f46c7c14', 'f22624q2-1ae8-2d0b-9739-7e74f46c7c14', '00000000-0001', 'ORDERID000006', 'Заказ №5 у ИП Солодков', 700.00, 'RUB', 'CREATED',  NULL),
       ('f22524a2-1ae8-2d0b-9739-8e74f46c7c15', 'f22524a2-1ae8-2d0b-9739-8e74f46c7c15', '00000000-0001', 'ORDERID000007', 'Заказ №6 у ИП Солодков', 44.02, 'RUB', 'CREATED',  NULL),
       ('f22424s2-1ae8-2d0b-9739-9e74f46c7c16', 'f22424s2-1ae8-2d0b-9739-9e74f46c7c16', '00000000-0001', 'ORDERID000008', 'Заказ №7 у ИП Солодков', 90.70, 'RUB', 'CREATED',  NULL),
       ('f22324d2-1ae8-2d0b-9739-0e74f46c7c17', 'f22324d2-1ae8-2d0b-9739-0e74f46c7c17', '00000000-0001', 'ORDERID000009', 'Заказ №8 у ИП Солодков', 35.08, 'RUB', 'CREATED',  NULL),
       ('f22224f2-1ae8-2d0b-9739-3e73f46c7c18', 'f22224f2-1ae8-2d0b-9739-3e73f46c7c18', '00000000-0001', 'ORDERID000010', 'Заказ №9 у ИП Солодков', 67.20, 'RUB', 'CREATED',  NULL),
       ('f2232ёg2-1ae8-2d0b-9739-3e72f46c7c19', 'f2232ёg2-1ae8-2d0b-9739-3e72f46c7c19', '00000000-0001', 'ORDERID000011', 'Заказ №10 у ИП Солодков', 46.55, 'RUB', 'CREATED',  NULL)
ON CONFLICT DO NOTHING;

INSERT INTO gateways(gtw_id, adapter, description, params)
VALUES (1, 'epay-sbpadapter', 'Gateway for SBP operations', '{"sbpParams": null}')
ON CONFLICT DO NOTHING;

INSERT INTO channels(chn_id, gtw_ref, params)
VALUES (1, 1, '{
    "sbpParams": {
    "account": "40802810536000000263",
    "agentId": "A00000000010",
    "legalId": "LB0000024107",
    "qrcType": "02",
    "memberId": "100000000005",
    "merchantId": "MA0000255863",
    "refundPurpose": "Возврат платежа по заказу №",
    "paymentPurpose": "Платеж по заказу №",
    "templateVersion": "01" }}')
ON CONFLICT DO NOTHING;

INSERT INTO rules(rule_id, name, group_id, mst_ref, chn_ref)
VALUES (1, 'RULE1', 'SBP_PURCHASE', '00000000-0001', 1),
       (2, 'RULE2', 'SBP_REFUND', '00000000-0001', 1)
ON CONFLICT DO NOTHING;

INSERT INTO rule_contents(rule_content_id, rule_ref, name, weight, value)
VALUES (1, 1, 'IPSOLODKOVOVRULECONTENT#1', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 1000000'),
       (2, 1, 'IPSOLODKOVOVRULECONTENT#2', 0.8, 'var arr = ["RUB", "USD", "EUR"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (3, 2, 'IPSOLODKOVOVRULECONTENT#3', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 1000000'),
       (4, 2, 'IPSOLODKOVOVRULECONTENT#4', 0.8, 'var arr = ["RUB", "USD", "EUR"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());')
ON CONFLICT DO NOTHING;