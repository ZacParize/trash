insert into flows (flow_id, name, mst_ref, description)
values (9, 'Card purchase without 3ds flow', null, 'Standard card purchase without 3ds transaction flow')
ON CONFLICT DO NOTHING;

insert into flow_commands (flow_command_id, command, name, description)
values (23, 'transaction != null && "CARD_PAYMENT_WITHOUT_3DS".equals(transaction.getType().name()) && !"RECONCILED".equals(transaction.getStatus().getValue())', 'Card purchase flow check with no 3ds', 'Card purchase with no 3ds, checking whether transaction should go throughout purchase flow')
ON CONFLICT DO NOTHING;

insert into flow_points (flow_point_id, flow_ref, flow_command_ref, point, rank, name, description)
values (27, 9, 23, 'epay.supervisor-topic', 0, 'Card purchase without 3ds flow info', 'Card purchase without 3ds, apply card purchase flow command'),
       (28, 9, 1,  'epay.cardinfo-topic', 1, 'Card purchase without 3ds, card info', 'Card purchase without 3ds, apply card info command'),
       (29, 9, 4,  'epay.router-topic', 2, 'Card purchase without 3ds, router info', 'Card purchase without 3ds, apply router command'),
       (30, 9, 6,  'epay.gatewayadapter-topic', 3, 'Card purchase without 3ds, gateway info', 'Card purchase without 3ds, apply gateway adapter command'),
       (31, 9, 3,  'epay.merchantplugin-topic', 4, 'Card purchase without 3ds,merchant callback flow info', 'Card purchase, merchant callback apply command')
ON CONFLICT DO NOTHING;
