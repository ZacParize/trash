update flow_commands
set command = 'transaction != null && "C2A_TRANSFER".equals(transaction.getType().name())'
where flow_command_id = 37