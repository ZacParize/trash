update transactions
set state = 'SBP_PAYMENT_CREATED',
    data = jsonb_set(data, '{status}', to_jsonb('SBP_PAYMENT_CREATED'::text), true)
where type in ('SBP_PAYMENT')
  and state = 'PROCESSING'
  and created_at < now() - INTERVAL '5 DAYS';

update transactions
set state = 'SBP_REFUND_CREATED',
    data = jsonb_set(data, '{status}', to_jsonb('SBP_REFUND_CREATED'::text), true)
where type IN ('PARTIAL_SBP_REFUND', 'SBP_REFUND')
  and state = 'PROCESSING'
  and created_at < now() - INTERVAL '5 DAYS';