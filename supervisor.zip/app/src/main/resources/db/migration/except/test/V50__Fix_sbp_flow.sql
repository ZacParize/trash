update flow_commands set command = 'transaction != null && (!"NEW".equals(transaction.getStatus().getValue()) || transaction.getContext().containsKey("notifyMerchant"))'
where flow_command_id = 22;

