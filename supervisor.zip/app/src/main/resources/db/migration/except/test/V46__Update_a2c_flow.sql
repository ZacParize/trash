update flow_points set rank = 4 where flow_point_id = 46;
update flow_points set rank = 3 where flow_point_id = 45;

DELETE FROM flow_commands WHERE flow_command_id = 31;
DELETE FROM flow_points WHERE flow_point_id = 47;
INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (31, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")',
        'Account to card flow, route', 'Account to card flow, route');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (47, 10, 31, 2, 'epay.router-topic', 'Account to card flow, route',
        'Account to card flow, route');