update flow_commands set command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-sbpadapter") && Integer.parseInt(transaction.getContext().get("epay-sbpadapter").toString()) == 1 && !"DECLINED".equals(transaction.getState().getValue())'
where flow_command_id = 15;

