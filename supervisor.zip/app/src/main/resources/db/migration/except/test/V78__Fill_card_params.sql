update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantId}', '"33685533"'::jsonb, true)
where (params -> 'cardParams' ->> 'merchantId') is null;

update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantName}', '"Test 3ds"'::jsonb,true)
where (params -> 'cardParams' ->> 'merchantName') is null;