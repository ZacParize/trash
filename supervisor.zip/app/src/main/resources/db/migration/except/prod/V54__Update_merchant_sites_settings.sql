update merchant_sites
set params = '{ "terminalId": null,
                "callbackUrl": null,
                "orderLifeTime": "PT20m",
                "partialRefund": true,
                "merchantPayments": { "sbpPayment": true, "cardPayment": false, "cardFlowThreeDS": false, "cardFlowThreeDSOnMerchantSide": false },
                "merchantTransfers": { "a2cTransferParams": {} },
                "sbpParams": {
                 "account": "40802810536000000263",
                 "agentId": "A00000000010",
                 "legalId": "LB0000024107",
                 "qrcType": "02",
                 "memberId": "100000000005",
                 "merchantId": "MA0000255863",
                 "refundPurpose": "Возврат платежа по заказу №",
                 "paymentPurpose": "Платеж по заказу №",
                 "templateVersion": "01" } }'
where mst_id = '00000000-0001';