DELETE FROM flow_points WHERE flow_point_id in (43, 44, 45, 46);

DELETE FROM flow_commands WHERE flow_command_id in (30);

DELETE FROM rule_contents WHERE rule_content_id >= 111 and rule_content_id <= 132;

DELETE FROM rules WHERE rule_id >= 56 and rule_id <= 66;

DELETE FROM flows WHERE flow_id in (10);

INSERT INTO flows (flow_id, name, description)
VALUES (10, 'Account to card transfer flow', 'Standard account to card transfer flow');

INSERT INTO rules (rule_id, name, group_id, mst_ref, chn_ref)
VALUES (56, 'A2C_RULE', 'CARD_PURCHASE', 'TESTMSTID', 3),
       (57, 'A2C_RULE#1', 'CARD_PURCHASE', 'TESTMSTID1', 3),
       (58, 'A2C_RULE#2', 'CARD_PURCHASE', 'TESTMSTID2', 3),
       (59, 'A2C_RULE#3', 'CARD_PURCHASE', 'TESTMSTID3', 3),
       (60, 'A2C_RULE#4', 'CARD_PURCHASE', 'TESTMSTID4', 3),
       (61, 'A2C_RULE#5', 'CARD_PURCHASE', 'TESTMSTID5', 3),
       (62, 'A2C_RULE#6', 'CARD_PURCHASE', 'TESTMSTID6', 3),
       (63, 'A2C_RULE#7', 'CARD_PURCHASE', 'TESTMSTID7', 3),
       (64, 'A2C_RULE#8', 'CARD_PURCHASE', 'TESTMSTID8', 3),
       (65, 'A2C_RULE#9', 'CARD_PURCHASE', 'TESTMSTID9', 3),
       (66, 'A2C_RULE#10', 'CARD_PURCHASE', 'TESTMSTID10', 3);

INSERT INTO rule_contents (rule_content_id, rule_ref, name, weight, value)
VALUES (111, 56, 'A2C_RULECONTENT#1', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (112, 56, 'A2C_RULECONTENT#2', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (113, 57, 'A2C_RULECONTENT#3', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (114, 57, 'A2C_RULECONTENT#4', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (115, 58, 'A2C_RULECONTENT#5', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (116, 58, 'A2C_RULECONTENT#6', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (117, 59, 'A2C_RULECONTENT#7', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (118, 59, 'A2C_RULECONTENT#8', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (119, 60, 'A2C_RULECONTENT#9', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (120, 60, 'A2C_RULECONTENT#10', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (121, 61, 'A2C_RULECONTENT#11', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (122, 61, 'A2C_RULECONTENT#12', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (123, 62, 'A2C_RULECONTENT#13', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (124, 62, 'A2C_RULECONTENT#14', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (125, 63, 'A2C_RULECONTENT#15', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (126, 63, 'A2C_RULECONTENT#16', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (127, 64, 'A2C_RULECONTENT#17', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (128, 64, 'A2C_RULECONTENT#18', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (129, 65, 'A2C_RULECONTENT#19', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (130, 65, 'A2C_RULECONTENT#20', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (131, 66, 'A2C_RULECONTENT#21', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (132, 66, 'A2C_RULECONTENT#22', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());');

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (30, 'transaction != null && "A2C_TRANSFER".equals(transaction.getType().name()) && !"CONFIRMED".equals(transaction.getStatus().getValue())', 'Account to card transfer', 'Account to card transfer flow');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (43, 10, 30, 0, 'epay.supervisor-topic', 'Account to card flow info', 'Account to card flow command'),
       (44, 10, 1, 1, 'epay.cardinfo-topic', 'Account to card flow, card info', 'Account to card flow, card info command'),
       (45, 10, 6, 2, 'epay.gatewayadapter-topic', 'Account to card flow, gateway info', 'Account to card flow, gateway command'),
       (46, 10, 3, 3, 'epay.merchantplugin-topic', 'Account to card flow, merchant callback flow info', 'Account to card flow, merchant callback command');

update epay.merchant_sites  set params = params || '
{
  "merchantTransfers":{
    "a2cTransferParams":{
      "FPTTI":"Payment Transaction",
      "SNAME":"Romashka LLC",
      "SFNAME":"OAO",
      "SLNAME":"Gde dengi",
      "BICCODE":"044525187",
      "FSOURCE":"08",
      "MRPPHONE":"+7001234567"
    }
  }
}'::jsonb
WHERE mst_id LIKE 'TESTMSTID%';