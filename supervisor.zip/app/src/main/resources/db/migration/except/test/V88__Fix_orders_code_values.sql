DO
$$
    DECLARE
        textType text = 'text';
        columnType text;
        row text;
    BEGIN

        columnType = (SELECT DATA_TYPE
                      FROM INFORMATION_SCHEMA.columns
                      WHERE COLUMN_NAME = 'code'
                        and TABLE_NAME = 'orders'
                        and TABLE_SCHEMA = (select current_schema()));
        IF columnType = textType THEN
            FOR row IN (
                SELECT ordr.code
                FROM orders ordr
            )
            LOOP
                BEGIN
                    SELECT row::uuid;
                EXCEPTION WHEN OTHERS THEN
                    DELETE FROM transaction_info
                    WHERE transaction_ref IN (SELECT transaction_id
                        FROM transactions WHERE transactions.order_ref
                            IN (SELECT order_id from orders where orders.code = row));
                    DELETE FROM transactions WHERE order_ref
                            IN (SELECT order_id from orders where orders.code = row);
                    DELETE FROM orders WHERE code = row;
                END;
            END LOOP;
        END IF;

    END;
$$