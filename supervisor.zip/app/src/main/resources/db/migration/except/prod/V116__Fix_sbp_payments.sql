UPDATE transactions SET state = 'RECONCILED'
WHERE transaction_id in ('2d9f504a-fd4d-43d9-b71b-71bbe3a5eaad-vpay',
                         'd5a32e30-9a8e-4328-a24a-0acedf4bf1d3-vpay',
                         'cb62f5d5-bc9e-4947-94e7-75df8d222914-vpay');