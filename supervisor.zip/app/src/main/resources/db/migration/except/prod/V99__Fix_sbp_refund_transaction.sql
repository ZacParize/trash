UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('2e919358-d34d-4055-8694-8b9c8421ecfe-vpay',
                         'dffcbe27-0d2c-4688-9777-0f369bac8692-vpay',
                         'ac70ea2d-456e-4e14-a25e-3fc46415748e-vpay');