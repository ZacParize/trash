update epay.merchant_sites  set params = params || '
{
  "merchantTransfers":{
    "c2aTransferParams":{
      "SNAME":"SNAME",
      "SFNAME":"SFNAME",
      "SLNAME":"SLNAME",
      "RFNAME":"RFNAME",
      "RLNAME":"RLNAME",
      "FSOURCE":"02",
      "FPTTI":"С2А"
    }
  }
}'::jsonb
WHERE id LIKE 'TESTMSTID%';