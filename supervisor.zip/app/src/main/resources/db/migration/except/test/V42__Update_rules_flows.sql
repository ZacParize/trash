update flow_commands
set command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")'
where flow_command_id = 29;