INSERT INTO flows (flow_id, "name", description)
VALUES (12,'Card to account transfer flow','Standard  card to account transfer flow');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (37,
        'transaction != null && "CARD_TO_ACCOUNT".equals(transaction.getType().name())',
        'Card to account flow check',
        'Card to account, checking whether transaction should go throughout supervisor service');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (38, 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-cardinfo")',
        'Card to account flow check cardinfo',
        'Card to account, checking whether transaction should go throughout card info service');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (39, 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-router")',
        'Card to account router',
        'Card to account, checking whether transaction should go throughout router service');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (40, 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-3ds-adapter")',
        'Card to account ds-adapter OC',
        'Card to account, checking whether transaction should go throughout 3ds-adapter service');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (41, 'transaction != null && transaction.getContext() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "PARES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
        'Card to account 3DS V1.0 purchase, 3ds-adapter PARES operation',
        'Card to account, checking whether transaction should go throughout 3ds-adapter service with PARES operation');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (42, 'transaction != null && transaction.getContext() != null && transaction.getRoute() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "AREQ".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
        'Card to account 3ds-adapter AREQ',
        'Card to account, checking whether transaction should go throughout 3ds-adapter service with AREQ operation');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (43, 'transaction != null && transaction.getContext() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "CRES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
        'Card to account 3ds-adapter CRES',
        'Card to account, checking whether transaction should go throughout 3ds-adapter service with CRES operation');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (44, 'transaction != null && transaction.getContext() != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter") && transaction.getContext().containsKey("XID") && transaction.getContext().containsKey("CAVV") && transaction.getContext().containsKey("ECI")',
        'Card to account gateway',
        'Card to account, checking whether transaction should go throughout gateway addapter');

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (45, 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-merchantplugin")',
        'Card to account  merchant plugin',
        'Card to account, checking whether transaction should go throughout merchant plugin');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (50,12,37,0,'epay.supervisor-topic','Card to account info','Card to account info flow command');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (51,12,38,1,'epay.cardinfo-topic','Card to account card info stage','Card to account card info stage');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (52,12,39,2,'epay.router-topic','Card to account router stage','Card to account router stage');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (53,12,40,3,'epay.3ds-adapter-topic','Card to account 3ds adapter stage','Card to account 3ds adapter stage');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (54,12,41,4,'epay.3ds-adapter-topic','Card to account 3ds PARES','Card to account 3ds PARES');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (55,12,42,5,'epay.3ds-adapter-topic','Card to account 3ds AREQ','Card to account 3ds AREQ');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (56,12,43,6,'epay.3ds-adapter-topic','Card to account 3ds CRES','Card to account 3ds CRES');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (57,12,44,7,'epay.gatewayadapter-topic','Card to account gateway','Card to account gateway');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, "name", description)
VALUES (58,12,44,8,'epay.merchantplugin-topic','Card to account merchant plugin','Card to account merchant plugin');