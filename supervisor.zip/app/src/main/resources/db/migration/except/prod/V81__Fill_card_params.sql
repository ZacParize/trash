update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantId}', to_jsonb(id), true)
where (params -> 'cardParams' ->> 'merchantId') is null
  and (params -> 'cardParams' ->> 'enableCardPayment')::boolean = true;

update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantName}', to_jsonb(name), true)
where (params -> 'cardParams' ->> 'merchantName') is null
  and (params -> 'cardParams' ->> 'enableCardPayment')::boolean = true;