--Переводим ошибочно отклоненные транзакции из статуса "DECLINED" (транзакция отклонена) в статус "RECONCILED" (оплата прошла успешно), платежи по которым по факту успешно прошли на стороне Процессингого центра СБП ЮЛ (ИС 1708), но по которым ИС 1706 получила ошибку при запросе статуса операции:
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = 'e72f9ff7-1c95-4566-896e-9f2edc72c5b6-vpay';
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = '7ee4024b-8580-4ee9-a67b-7b2339580c68-vpay';
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = '1767c8f4-ae9d-4538-a12b-9cd89cc32cba-vpay';
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = 'f966f33e-5893-4b97-a6ed-f5cdf67b07b6-vpay';
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = 'c98fab90-b087-405f-af4b-b49a61d7b543-vpay';
UPDATE transactions SET state = 'RECONCILED' WHERE transaction_id = 'd96b1176-10c3-4c2f-aa1d-ac5edbbee640-vpay';

-- Переводим связапнные ордеры в статус "PAID" (успешно оплачен):
UPDATE orders SET state = 'PAID' where code = 'f2ad99d7-ca0d-4a35-9e7c-c5dba684c18e';
UPDATE orders SET state = 'PAID' where code = '52f64274-ff8e-428c-bc32-af2bd5d193eb';
UPDATE orders SET state = 'PAID' where code = '1def85be-b232-4f5e-a37e-b541b0fb68df';
UPDATE orders SET state = 'PAID' where code = 'aeb27ab7-6353-4529-9f66-148ab6615e19';
UPDATE orders SET state = 'PAID' where code = '1e92656e-1651-48ce-9451-bd3527009fe0';
UPDATE orders SET state = 'PAID' where code = '45fae041-fb6b-4cb1-80bb-78325f733b92';

-- Данное действие необходимо для возможности повторного создания мерчантом новой транзакции
-- на возврат по заказу (чтобы не получить ошибку "TRANSACTION_IN_PROCESS"):
UPDATE transactions SET state = 'DECLINED' where transaction_id = 'cd32d47e-6b41-4f38-a629-b78ca9c45c54-vpay';