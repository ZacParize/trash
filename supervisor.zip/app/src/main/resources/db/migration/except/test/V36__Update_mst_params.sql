UPDATE merchant_sites mst SET params = params || jsonb_build_object('terminalId', '88054516')
WHERE mst.mst_id ILIKE 'TESTMSTID%';

INSERT INTO merchant_sites (mst_id, merch_ref, url, name, params, login)
VALUES ('TESTMSTID21', 'TESTMERCHID', 'https://sample-url-0020.ru', 'TESTNAME21', '{
      "terminalId": "88054516",
      "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback",
      "orderLifeTime": "10m",
      "partialRefund": true
    }', 'test_efcp_epa@region.vtb.ru')
ON CONFLICT DO NOTHING;