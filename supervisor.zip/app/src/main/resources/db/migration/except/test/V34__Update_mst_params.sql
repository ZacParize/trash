UPDATE merchant_sites mst
SET params = '{"terminalId": "12345678", "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback", "partialRefund": true, "orderLifeTime" : "10m"}'
WHERE mst.mst_id ILIKE 'TESTMSTID%';