-- Update Challenge Flow
INSERT INTO flow_commands(flow_command_id, command, "name", description)
VALUES(35, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") '
    || '&& transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") '
    || '&& transaction.getContext().containsKey("TDS_NEXT_STEP") && "CRES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
       '3DS V2.0 purchase, 3ds-adapter CRES operation',
       '3DS V2.0 purchase, checking whether transaction should go throughout 3ds-adapter service with CRES operation');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES(48, 11, 35, 6, 'epay.3ds-adapter-topic', 'Card purchase 3DS V2.0 CRES', 'Card purchase 3DS V2.0 Challenge Flow, CRES operation');


-- Update 3DS V1.0 Flow
INSERT INTO flow_commands(flow_command_id, command, "name", description)
VALUES(36, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") '
    || '&& transaction.getContext().containsKey("TDS_NEXT_STEP") && "PARES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
       '3DS V1.0 purchase, 3ds-adapter PARES operation',
       '3DS V1.0 purchase, checking whether transaction should go throughout 3ds-adapter service with PARES operation');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES(49, 11, 36, 4, 'epay.3ds-adapter-topic', 'Card purchase 3DS V1.0 PARES', 'Card purchase 3DS V1.0, PARES operation');