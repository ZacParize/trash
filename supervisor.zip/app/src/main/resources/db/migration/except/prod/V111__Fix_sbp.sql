--Деклайним транзакции на возврат, которые зависли в статусе NEW и по которым не был успешно проведен возврат на стороне ИС 1708 "Процессинговый центр СБП:
UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('3bd97fa6-629b-4ee0-85e5-f95687c827f0-vpay',
                         '807c2831-04d9-4ecd-b910-d59e1b546952-vpay',
                         'dd378b8c-b70d-4caa-8a43-9de87bcabf97-vpay',
                         '151f81a9-fc59-44d8-97e8-e84e10f2078d-vpay',
                         'f842a5a0-0a84-4e09-9556-36f6de24c901-vpay',
                         '9c447e40-c60a-4542-8829-9a214662ebe3-vpay',
                         '31bbbf67-35f0-4f04-a914-dd1b1e9f463f-vpay',
                         '78090b46-40e9-43e4-b1ed-b97e453db0b6-vpay',
                         '6bef8c91-a696-492e-a89b-81ea2d603b4d-vpay',
                         '8e6ad9b5-cee2-4fa2-b809-ad09c09bae75-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('d1b9e5bd-d923-485c-b57c-2e42c3a01eb3-vpay',
                         '1f54b8b9-1a34-45ce-8198-cdc710de223c-vpay',
                         '9382854a-1ef4-4097-ac25-9e20c21a7d31-vpay',
                         '003b4fc6-4bb0-4476-bf97-b20ff84b8e63-vpay',
                         '34930728-6951-4340-a9c1-cb832e7171d0-vpay',
                         '3301223e-339b-4aca-9283-e4858d802bbb-vpay',
                         'd2d9574a-62b1-4bea-a976-3fd195ed2e4d-vpay',
                         '739a7cb0-f979-494e-9fbc-14bc6f06c367-vpay',
                         'e340000d-519d-4c95-95ea-0ae5da166f75-vpay',
                         '4f28b3c7-585e-490a-bf57-e3242f0245cc-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in('e30eafa9-7543-4dc0-96e7-fbe8a66415d8-vpay',
                        '8a075cf2-2858-45df-b5d5-05982cfaf980-vpay',
                        '10894908-090a-4790-add8-70700d1cf66b-vpay',
                        'bff38286-e1bf-4bf7-b28e-92370b6fef1d-vpay',
                        'bc9e3668-84b0-4444-8eba-befd6083d060-vpay',
                        '437fba03-c8ec-4f70-8254-17a48090f7e0-vpay',
                        '58647d1d-f2c2-4be4-800f-01f5db503708-vpay',
                        '1fbb0b3d-7743-425d-b3d3-afa9961297e6-vpay',
                        '8ebb50d7-8542-4911-a7d8-a022e7e17a4f-vpay',
                        '3773471d-763c-4dc8-9016-97933cdf940c-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('2ead9417-b27a-41be-803d-4f29e5184567-vpay',
                         'ae80983b-3c1b-4249-973e-02f8a972edc9-vpay',
                         '12adf8a1-972e-4cb2-aac5-6261fee0ff58-vpay',
                         'b505837f-cd5d-4f32-94f8-a86b6d1790cc-vpay',
                         'ffe007b0-7d62-4827-8490-ad9ace8e73fa-vpay',
                         '58cc8cfa-8438-43db-abb6-50a42689f33f-vpay',
                         'a5f56637-3d5d-4960-b7e2-29d7d1d21e4e-vpay',
                         '3e172749-8305-43be-99df-a0f7c503fae7-vpay',
                         '654592c7-da23-4883-adf4-c24d58b378ca-vpay',
                         '265eb789-db2a-42ab-982a-46232faf174c-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('2e7e9c8f-977a-458a-acc5-a54b05f28434-vpay',
                         '5b9e1a7b-0cd4-43e9-973f-9e32d793a4f9-vpay',
                         '287c82a8-be6c-4b7b-b68b-5cce5114e63b-vpay',
                         '6439e927-4cd2-47fb-afce-bde8acfbbc04-vpay',
                         'c3f6362b-b237-4f16-8473-a55c8b15e733-vpay',
                         '68d3f0ec-1c1a-4e75-a041-4f47fbed1b96-vpay',
                         '7d77173a-bed2-4537-8773-3b6a0e6cff93-vpay',
                         '97b5a8a5-029e-4b60-b0ff-edb0285eb855-vpay',
                         '6fb86be1-6231-4166-b40d-0ca61bf7f477-vpay',
                         'bb5b92a9-733e-477e-83d7-8c82d1632f37-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('4c6701dc-9a83-4592-a31c-4ef9ce51b1de-vpay',
                         '698a5d25-8f35-4902-9cc2-e5bc918dc836-vpay',
                         'b3915ffb-7b5e-40f9-b0be-4cddc6dda7d5-vpay',
                         '54412814-3a92-4618-964f-a89b63eab2be-vpay',
                         '7dde910d-7eb2-4021-ada3-b61ec551b58a-vpay',
                         '001343a4-91d0-45bb-8e59-d8166c179a0b-vpay',
                         '21aaeaa6-0772-4a26-ae7c-8ec206242bd9-vpay',
                         '35a54152-535b-4725-9691-86fb9897d865-vpay',
                         '939bda69-e580-41d7-8d57-963b361f61b1-vpay',
                         '1eb700d3-b1e4-491a-902d-78662dbb777a-vpay');

UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id in ('9e1e3e71-3143-4343-b8e6-8ce1bf7cd05a-vpay',
                         'c019bbbd-dc08-4d76-bb21-06f7424122a1-vpay',
                         '94557683-29f1-4d3b-9876-885adf7c6a6d-vpay',
                         '562d7d99-6847-4c7c-9016-46d688ddae34-vpay',
                         '4ce5a1c5-6f37-4255-b8fc-86f23f2c66e4-vpay');