update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantId}', '"700775020000000"'::jsonb, true)
where merch_ref in (select id from merchants where name = 'ИП Солодков О.B')
    and (params -> 'cardParams' ->> 'merchantId') is null;

update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantName}', '"TestVTBPAY"'::jsonb,true)
where merch_ref in (select id from merchants where name = 'ИП Солодков О.B')
    and (params -> 'cardParams' ->> 'merchantName') is null;