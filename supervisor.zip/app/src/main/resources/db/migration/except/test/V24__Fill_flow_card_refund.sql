INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (24, 'transaction != null && "CARD_REFUND".equals(transaction.getType().name()) && "NEW".equals(transaction.getStatus().getValue())', 'Card refund flow check', 'Card refund flow check'),
       (25, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', 'Card refund, router', 'Card refund, router'),
       (26, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter")', 'Card refund, gateway adapter', 'Card refund, gateway adapter'),
       (27, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-merchantplugin")', 'Card refund, merchplugin', 'Card refund, merchplugin')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES (32, 2, 24, 0, 'epay.supervisor-topic', 'Card refund flow info', 'Card refund, apply card refund flow command'),
       (33, 2, 25, 1, 'epay.router-topic', 'Card refund, router info', 'Card refund, apply router command'),
       (34, 2, 26, 2, 'epay.gatewayadapter-topic', 'Card refund, gateway adapter info', 'Card refund, apply gateway command'),
       (35, 2, 27, 3, 'epay.merchantplugin-topic', 'Card refund, merchantplugin info', 'Card refund, apply merchantplugin command')
ON CONFLICT DO NOTHING;
