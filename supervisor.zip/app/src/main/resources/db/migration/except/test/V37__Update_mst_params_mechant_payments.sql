UPDATE merchant_sites mst
SET params = '{"terminalId": "88054516", "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback", "partialRefund": true, "orderLifeTime": "10m", "merchantPayments":{"sbpPayment": false, "cardPayment": true}}'
WHERE mst.mst_id ILIKE 'TESTMSTID%';