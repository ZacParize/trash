update merchant_sites
set params = jsonb_set(params, '{merchantPayments, a2cTransfer}', 'true'::jsonb, true);

update merchant_sites
set params = jsonb_set(params, '{merchantPayments, c2aTransfer}', 'true'::jsonb, true);

update merchant_sites
set params = jsonb_set(params, '{merchantTransfers, a2cTransferParams}',
'{
	"FPTTI": "Payment Transaction",
	"SNAME": "Test LLC",
	"SFNAME": "OOO",
	"SLNAME": "Gde dengi",
	"BICCODE": "044525187",
	"FSOURCE": "08",
	"MRPPHONE": "+7001234567"
}'::jsonb,true);

update merchant_sites
set params = jsonb_set(params, '{merchantTransfers, c2aTransferParams}',
'{
    "SNAME": "SNAME",
    "SFNAME": "SFNAME",
    "SLNAME": "SLNAME",
    "RFNAME": "RFNAME",
    "RLNAME": "RLNAME",
    "FSOURCE": "02",
    "FPTTI": "С2А",
    "CONDITION": "5",
    "SACCNUMTYPE": "01",
    "RCOUNTRY": "RUS",
    "RACCNUMTYPE": "02"
}'::jsonb, true)
