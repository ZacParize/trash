update transactions
set state = 'RECONCILED',
    data = jsonb_set(data, '{status}', to_jsonb('RECONCILED'::text), true),
    version = 4
where transaction_id in ('2caa35b1-28dc-4cf7-9e9d-c3c08bde94e2-vpay');

update transactions
set data = jsonb_set(data, '{paymentData, status}', to_jsonb('OK'::text), true)
where transaction_id in ('2caa35b1-28dc-4cf7-9e9d-c3c08bde94e2-vpay');

update transactions
set data = jsonb_set(data, '{paymentData, operationId}', to_jsonb('A41101140045183B0000010011231101'::text), true)
where transaction_id in ('2caa35b1-28dc-4cf7-9e9d-c3c08bde94e2-vpay');

update notifications
set state = 'PROCESSED',
    sent_at = '2024-04-27 21:13:12.251671',
    created_at = '2024-04-27 21:13:12.251671',
    modified_at = '2024-04-27 21:13:12.251671',
    version = 1
where id in (240691);