UPDATE merchant_sites mst
SET params = params || jsonb_build_object('merchantPayments', params -> 'merchantPayments'
                                                              || jsonb_build_object('cardFlowThreeDS', false)
                                                              || jsonb_build_object('cardFlowThreeDSOnMerchantSide', false))
WHERE mst.mst_id ILIKE 'TESTMSTID%';