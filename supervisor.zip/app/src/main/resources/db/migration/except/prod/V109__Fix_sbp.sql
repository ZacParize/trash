-- Возвращаем к жизни протухшие ордера по проблемным оплатам и возвратам:
UPDATE orders SET state = 'CREATED' where code = 'f2ad99d7-ca0d-4a35-9e7c-c5dba684c18e';
UPDATE orders SET state = 'CREATED' where code = '52f64274-ff8e-428c-bc32-af2bd5d193eb';
UPDATE orders SET state = 'CREATED' where code = '1def85be-b232-4f5e-a37e-b541b0fb68df';
UPDATE orders SET state = 'CREATED' where code = 'aeb27ab7-6353-4529-9f66-148ab6615e19';
UPDATE orders SET state = 'CREATED' where code = '1e92656e-1651-48ce-9451-bd3527009fe0';
UPDATE orders SET state = 'CREATED' where code = '45fae041-fb6b-4cb1-80bb-78325f733b92';

-- Возвращаем к жизни задеклайненные транзакции по проблемным оплатам СБП, которые по факту прошли на стороне
-- процессинга СБП ЮЛ/НСПК:
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = 'e72f9ff7-1c95-4566-896e-9f2edc72c5b6-vpay';
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = '7ee4024b-8580-4ee9-a67b-7b2339580c68-vpay';
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = '1767c8f4-ae9d-4538-a12b-9cd89cc32cba-vpay';
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = 'f966f33e-5893-4b97-a6ed-f5cdf67b07b6-vpay';
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = 'c98fab90-b087-405f-af4b-b49a61d7b543-vpay';
UPDATE transactions SET state = 'SBP_PAYMENT_CREATED' WHERE transaction_id = 'd96b1176-10c3-4c2f-aa1d-ac5edbbee640-vpay';


-- Дропаем транзакции по возвратам СБП и информаци по ним, которые остались в начальном статусу NEW и не перешли в статусы
-- SBP_REFUND_CREATED; Это необходимо для возможности повторного создания мерчантом новой транзакции на возврат
-- по заказу (чтобы не получить ошибку TRANSACTION_IN_PROCESS):
DELETE FROM transaction_info where transaction_ref  = '40222184-a6de-47a8-abe5-91a285d1b9fc-vpay';
DELETE FROM transactions where transaction_id = '40222184-a6de-47a8-abe5-91a285d1b9fc-vpay';

DELETE FROM transaction_info where transaction_ref  = 'd336ef38-bd09-484c-b9b5-5ebab28982fe-vpay';
DELETE FROM transactions where transaction_id = 'd336ef38-bd09-484c-b9b5-5ebab28982fe-vpay';

DELETE FROM transaction_info where transaction_ref  = '34ea9b33-ff3b-441b-9fd7-4f1c92f8bdda-vpay';
DELETE FROM transactions where transaction_id = '34ea9b33-ff3b-441b-9fd7-4f1c92f8bdda-vpay';

DELETE FROM transaction_info where transaction_ref  = 'f2423a60-aeef-4ad5-af54-b48c0b3e8b2a-vpay';
DELETE FROM transactions where transaction_id = 'f2423a60-aeef-4ad5-af54-b48c0b3e8b2a-vpay';

DELETE FROM transaction_info where transaction_ref  = 'd6637207-726f-4305-a9ca-3154b8fa454e-vpay';
DELETE FROM transactions where transaction_id = 'd6637207-726f-4305-a9ca-3154b8fa454e-vpay';

DELETE FROM transaction_info where transaction_ref  = 'fdc08b0a-4b52-4bd3-8f45-64535af2fca9-vpay';
DELETE FROM transactions where transaction_id = 'fdc08b0a-4b52-4bd3-8f45-64535af2fca9-vpay';

DELETE FROM transaction_info where transaction_ref  = 'f73ea493-732f-46ea-bbbd-917982ed449f-vpay';
DELETE FROM transactions where transaction_id = 'f73ea493-732f-46ea-bbbd-917982ed449f-vpay';