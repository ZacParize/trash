insert into flow_points (flow_point_id, flow_ref, flow_command_ref, point, rank, name, description)
values (24, 4, 22, 'epay.merchantplugin-topic',3, 'Sbp purchase,merchant callback flow info', 'Sbp purchase, merchant callback apply command'),
       (25, 1, 22, 'epay.merchantplugin-topic',8, 'Card purchase, merchant callback flow info', 'Card purchase, merchant callback apply command'),
       (26, 5, 22, 'epay.merchantplugin-topic',5, 'Sbp refund, merchant callback flow info', 'Sbp refund, merchant callback apply command')
ON CONFLICT DO NOTHING;