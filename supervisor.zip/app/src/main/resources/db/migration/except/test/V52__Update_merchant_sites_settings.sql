update merchant_sites
set params = '{
                "terminalId": "88054516",
                "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback",
                "orderLifeTime": "PT20m",
                "partialRefund": true,
                "merchantPayments": {
                    "sbpPayment": true,
                    "cardPayment": true,
                    "cardFlowThreeDS": false,
                    "cardFlowThreeDSOnMerchantSide": false
                },
                "merchantTransfers": {
                    "a2cTransferParams": {
                        "FPTTI": "Payment Transaction",
                        "SNAME": "Romashka LLC",
                        "SFNAME": "OAO",
                        "SLNAME": "Gde dengi",
                        "BICCODE": "044525187",
                        "FSOURCE": "08",
                        "MRPPHONE": "+7001234567"
                    }
                },
                "sbpParams": {
                    "account": "40802810784000000472",
                    "agentId": "A00000000010",
                    "legalId": "LA0000010115",
                    "qrcType": "02",
                    "memberId": "100000000005",
                    "merchantId": "MA0000089979",
                    "refundPurpose": "Возврат платежа по заказу №",
                    "paymentPurpose": "Платеж по заказу №",
                    "templateVersion": "01"
                } }'
WHERE mst_id not in ('TESTMSTID10','TESTMSTID11');

update channels
set params = '{ "sbpParams": null }';
update epay.merchant_sites  set params = params || '
{ "terminalId":"24375695",
  "merchantTransfers":{
    "a2cTransferParams":{
      "FPTTI":"OCT",
      "SNAME":"Test A2C LLC",
      "SFNAME":"LLC",
      "SLNAME":"Test A2C",
      "BICCODE":"044525745",
      "FSOURCE":"08",
      "MRPPHONE":"+7001234567"
    }
  }
}'::jsonb
WHERE mst_id='TESTMSTID6';