INSERT into flows (flow_id, name, mst_ref, description)
values (9, 'Card purchase without 3ds flow', null, 'Standard card purchase without 3ds transaction flow')
ON CONFLICT DO NOTHING;

INSERT into flow_commands (flow_command_id, command, name, description)
values (23, 'transaction != null && "CARD_PAYMENT_WITHOUT_3DS".equals(transaction.getType().name()) && !"RECONCILED".equals(transaction.getStatus().getValue())', 'Card purchase flow check with no 3ds', 'Card purchase with no 3ds, checking whether transaction should go throughout purchase flow')
ON CONFLICT DO NOTHING;

INSERT into flow_points (flow_point_id, flow_ref, flow_command_ref, point, rank, name, description)
values (27, 9, 23, 'epay.supervisor-topic', 0, 'Card purchase without 3ds flow info', 'Card purchase without 3ds, apply card purchase flow command'),
       (28, 9, 1,  'epay.cardinfo-topic', 1, 'Card purchase without 3ds, card info', 'Card purchase without 3ds, apply card info command'),
       (29, 9, 4,  'epay.router-topic', 2, 'Card purchase without 3ds, router info', 'Card purchase without 3ds, apply router command'),
       (30, 9, 6,  'epay.gatewayadapter-topic', 3, 'Card purchase without 3ds, gateway info', 'Card purchase without 3ds, apply gateway adapter command'),
       (31, 9, 3,  'epay.merchantplugin-topic', 4, 'Card purchase without 3ds,merchant callback flow info', 'Card purchase, merchant callback apply command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (24, 'transaction != null && "CARD_REFUND".equals(transaction.getType().name()) && "NEW".equals(transaction.getStatus().getValue())', 'Card refund flow check', 'Card refund flow check'),
       (25, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', 'Card refund, router', 'Card refund, router'),
       (26, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter")', 'Card refund, gateway adapter', 'Card refund, gateway adapter'),
       (27, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-merchantplugin")', 'Card refund, merchplugin', 'Card refund, merchplugin')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES (32, 2, 24, 0, 'epay.supervisor-topic', 'Card refund flow info', 'Card refund, apply card refund flow command'),
       (33, 2, 25, 1, 'epay.router-topic', 'Card refund, router info', 'Card refund, apply router command'),
       (34, 2, 26, 2, 'epay.gatewayadapter-topic', 'Card refund, gateway adapter info', 'Card refund, apply gateway command'),
       (35, 2, 27, 3, 'epay.merchantplugin-topic', 'Card refund, merchantplugin info', 'Card refund, apply merchantplugin command')
ON CONFLICT DO NOTHING;

UPDATE flow_commands set command = 'transaction != null && (("PARTIAL_CARD_REFUND".equals(transaction.getType().name())) || ("CARD_REFUND".equals(transaction.getType().name()))) && "NEW".equals(transaction.getStatus().getValue())' where flow_command_id = 24;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (28, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds-adapter")',
        '3DS purchase, 3ds-adapter OC', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service'),
       (29, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && Integer.parseInt(transaction.getContext().get("epay-3ds-adapter").toString()) == 2',
        '3DS purchase, 3ds-adapter AREQ', '3DS purchase, 3ds-adapter AREQ')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (36, 1, 0, 9, 'epay.supervisor-topic', 'Card purchase flow 3DS info', 'Card purchase 3DS, apply card purchase flow command'),
       (37, 1, 1, 10, 'epay.cardinfo-topic', 'Card purchase 3DS, card info', 'Card purchase 3DS, apply card info command'),
       (38, 1, 17, 12, 'epay.router-topic', 'Card purchase 3DS, router info', 'Card purchase 3DS, apply router command'),
       (39, 1, 28, 13, 'epay.3ds-adapter-topic', 'Card purchase 3DS, 3ds adapter info', 'Card purchase 3DS, apply 3ds adapter command'),
       (40, 1, 3, 14, 'epay.merchantplugin-topic', 'Card purchase 3DS, merchant plugin info',
        'Card purchase 3DS, apply merchant plugin info command'),
       (41, 1, 29, 15, 'epay.3ds-adapter-topic', 'Card purchase 3DS second phase, 3ds adapter info', 'Card purchase 3DS second phase, apply 3ds adapter command'),
       (42, 1, 6, 16, 'epay.gatewayadapter-topic',
        'Card purchase 3DS second phase, gateway info', 'Card purchase 3DS second phase, apply gateway adapter command')
ON CONFLICT DO NOTHING;


UPDATE flow_commands
SET command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")'
WHERE flow_command_id = 29;

DELETE FROM flow_points WHERE flow_point_id in (43, 44, 45, 46);
DELETE FROM flow_commands WHERE flow_command_id in (30);
DELETE FROM flows WHERE flow_id in (10);

INSERT INTO flows (flow_id, name, description)
VALUES (10, 'Account to card transfer flow', 'Standard account to card transfer flow')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (30, 'transaction != null && "A2C_TRANSFER".equals(transaction.getType().name()) && !"CONFIRMED".equals(transaction.getStatus().getValue())', 'Account to card transfer', 'Account to card transfer flow')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (43, 10, 30, 0, 'epay.supervisor-topic', 'Account to card flow info', 'Account to card flow command'),
       (44, 10, 1, 1, 'epay.cardinfo-topic', 'Account to card flow, card info', 'Account to card flow, card info command'),
       (45, 10, 6, 2, 'epay.gatewayadapter-topic', 'Account to card flow, gateway info', 'Account to card flow, gateway command'),
       (46, 10, 3, 3, 'epay.merchantplugin-topic', 'Account to card flow, merchant callback flow info', 'Account to card flow, merchant callback command')
    ON CONFLICT DO NOTHING;

DELETE FROM flow_points WHERE flow_point_id in (36, 37, 38, 39, 40, 41, 42);
DELETE FROM flow_commands WHERE flow_command_id in (28, 29);
DELETE FROM flows WHERE flow_id in (11);

INSERT INTO flows (flow_id, mst_ref, name, description)
VALUES (11, null, 'Card purchase with 3ds flow', 'Standard card purchase with 3ds transaction flow')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (28, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds-adapter")',
        '3DS purchase, 3ds-adapter OC', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service'),
       (29, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")',
        '3DS purchase, 3ds-adapter AREQ', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (36, 11, 0, 0, 'epay.supervisor-topic', 'Card purchase 3DS info', 'Card purchase 3DS, apply card purchase flow command'),
       (37, 11, 1, 1, 'epay.cardinfo-topic', 'Card purchase 3DS first stage, card info', 'Card purchase 3DS first stage, apply card info command'),
       (38, 11, 17, 2, 'epay.router-topic', 'Card purchase 3DS first stage, router', 'Card purchase 3DS first stage, apply router command'),
       (39, 11, 28, 3, 'epay.3ds-adapter-topic', 'Card purchase 3DS first stage, 3ds adapter', 'Card purchase 3DS first stage, apply 3ds adapter command'),
       (40, 11, 29, 5, 'epay.3ds-adapter-topic', 'Card purchase 3DS second stage, 3ds adapter info', 'Card purchase 3DS second stage, apply 3ds adapter command'),
       (41, 11, 6, 8, 'epay.gatewayadapter-topic', 'Card purchase 3DS second stage, gateway info', 'Card purchase 3DS second stage, apply gateway adapter command'),
       (42, 11, 3, 9, 'epay.merchantplugin-topic', 'Card purchase 3DS first stage, merchant plugin info', 'Card purchase 3DS second stage, apply merchant plugin command')
ON CONFLICT DO NOTHING;

UPDATE flow_points set rank = 4 where flow_point_id = 46;
UPDATE flow_points set rank = 3 where flow_point_id = 45;

DELETE FROM flow_commands WHERE flow_command_id = 31;
DELETE FROM flow_points WHERE flow_point_id = 47;
INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (31, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")',
        'Account to card flow, route', 'Account to card flow, route')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (47, 10, 31, 2, 'epay.router-topic', 'Account to card flow, route',
        'Account to card flow, route')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (32,
        'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter") && transaction.getContext().containsKey("XID") && transaction.getContext().containsKey("CAVV") && transaction.getContext().containsKey("ECI")',
        '3DS Multicard operation', '3DS Multicard operation')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (33, 'transaction != null && "CARD_PAYMENT_TEST".equals(transaction.getType().name())',
        'Card test purchase flow check',
        'Card test purchase, checking whether transaction should go throughout purchase flow')
ON CONFLICT DO NOTHING;

UPDATE flow_points
SET flow_command_ref = 33
WHERE flow_point_id = 0;

UPDATE flow_commands
SET command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")'
WHERE flow_command_id = 29;

UPDATE flow_points
SET flow_command_ref = 0,
    "rank"           = 0
WHERE flow_point_id = 36;

UPDATE flow_points
SET flow_command_ref = 1,
    "rank"           = 1
WHERE flow_point_id = 37;

UPDATE flow_points
SET flow_command_ref = 17,
    "rank"           = 2
WHERE flow_point_id = 38;

UPDATE flow_points
SET flow_command_ref = 28,
    "rank"           = 3
WHERE flow_point_id = 39;

UPDATE flow_points
SET flow_command_ref = 29,
    "rank"           = 5
WHERE flow_point_id = 40;

UPDATE flow_points
SET flow_command_ref = 3,
    "rank"           = 9
WHERE flow_point_id = 42;

UPDATE flow_points
SET flow_command_ref = 32,
    "rank"           = 8
WHERE flow_point_id = 41;


UPDATE flow_commands
SET command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "AREQ".equals(transaction.getContext().get("TDS_NEXT_STEP"))'
WHERE flow_command_id = 29;

UPDATE flow_commands set command = 'transaction != null && (!"NEW".equals(transaction.getStatus().getValue()) || transaction.getContext().containsKey("notifyMerchant"))'
where flow_command_id = 22;

UPDATE flow_commands set command = 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-sbpadapter") && Integer.parseInt(transaction.getContext().get("epay-sbpadapter").toString()) == 1 && !"DECLINED".equals(transaction.getState().getValue())'
where flow_command_id = 15;

INSERT into flow_commands (flow_command_id, command, name, description)
values (34, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter") && !"DECLINED".equals(transaction.getStatus().getValue())', 'Account to card transfer, gateway adapter', 'Account to card transfer, gateway adapter')
ON CONFLICT DO NOTHING;
UPDATE flow_points set flow_command_ref=34 where flow_point_id = 45;


-- Update Challenge Flow
INSERT INTO flow_commands(flow_command_id, command, "name", description)
VALUES(35, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") '
    || '&& transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") '
    || '&& transaction.getContext().containsKey("TDS_NEXT_STEP") && "CRES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
       '3DS V2.0 purchase, 3ds-adapter CRES operation',
       '3DS V2.0 purchase, checking whether transaction should go throughout 3ds-adapter service with CRES operation')
    ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES(48, 11, 35, 6, 'epay.3ds-adapter-topic', 'Card purchase 3DS V2.0 CRES', 'Card purchase 3DS V2.0 Challenge Flow, CRES operation')
ON CONFLICT DO NOTHING;


-- Update 3DS V1.0 Flow
INSERT INTO flow_commands(flow_command_id, command, "name", description)
VALUES(36, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") '
    || '&& transaction.getContext().containsKey("TDS_NEXT_STEP") && "PARES".equals(transaction.getContext().get("TDS_NEXT_STEP"))',
       '3DS V1.0 purchase, 3ds-adapter PARES operation',
       '3DS V1.0 purchase, checking whether transaction should go throughout 3ds-adapter service with PARES operation')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name", description)
VALUES(49, 11, 36, 4, 'epay.3ds-adapter-topic', 'Card purchase 3DS V1.0 PARES', 'Card purchase 3DS V1.0, PARES operation')
ON CONFLICT DO NOTHING;

UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-merchantplugin") && transaction.getRoute().isVisitedService("epay-gatewayadapter")' where flow_command_id = 3;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && transaction.getRoute().getVisitedService("epay-sbpadapter") == 1 && !"DECLINED".equals(transaction.getState().getValue())' where flow_command_id = 15;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-router")' where flow_command_id = 25;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter")' where flow_command_id = 26;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-merchantplugin")' where flow_command_id = 27;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-3ds-adapter")' where flow_command_id = 28;
UPDATE flow_commands SET command = 'transaction != null && transaction.getContext() != null && transaction.getRoute() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "AREQ".equals(transaction.getContext().get("TDS_NEXT_STEP"))' where flow_command_id = 29;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-router")' where flow_command_id = 31;
UPDATE flow_commands SET command = 'transaction != null && transaction.getContext() != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter") && transaction.getContext().containsKey("XID") && transaction.getContext().containsKey("CAVV") && transaction.getContext().containsKey("ECI")' where flow_command_id = 32;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter") && !"DECLINED".equals(transaction.getStatus().getValue())' where flow_command_id = 34;
UPDATE flow_commands SET command = 'transaction != null && transaction.getContext() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "CRES".equals(transaction.getContext().get("TDS_NEXT_STEP"))' where flow_command_id = 35;
UPDATE flow_commands SET command = 'transaction != null && transaction.getContext() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "PARES".equals(transaction.getContext().get("TDS_NEXT_STEP"))' where flow_command_id = 36;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && "RECONCILED".equals(transaction.getStatus().getValue()) && !transaction.getRoute().isVisitedService("epay-merchantplugin")' where flow_command_id = 20;
UPDATE flow_commands SET command = 'transaction != null && transaction.getRoute() != null && "RECONCILED".equals(transaction.getStatus().getValue()) && !transaction.getRoute().isVisitedService("epay-merchantplugin")' where flow_command_id = 21;
UPDATE flow_commands SET command = 'transaction != null && (!"NEW".equals(transaction.getStatus().getValue()) || !transaction.getRoute().isVisitedService("epay-merchantplugin"))' where flow_command_id = 22;