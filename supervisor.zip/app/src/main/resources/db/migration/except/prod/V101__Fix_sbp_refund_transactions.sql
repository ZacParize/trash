UPDATE transactions SET state = 'RECONCILED'
WHERE transaction_id in ('7078dfe4-eb43-4335-a84d-a410d6d803f6-vpay',
                         '4d6ed43f-654c-4206-903f-dea3c0fec669-vpay',
                         '31fddc03-a989-4509-acd0-51bae87a5cc6-vpay',
                         '3f162620-e021-4503-a129-af751b0f4079-vpay',
                         '56a258e1-d206-4a85-9e98-ce7f0199cc10-vpay',
                         '70a6c3e5-7b89-4c6f-a21d-2dc12401c9ce-vpay');