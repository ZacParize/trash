DELETE FROM flow_points WHERE flow_point_id in (36, 37, 38, 39, 40, 41, 42);

DELETE FROM flow_commands WHERE flow_command_id in (28, 29);

DELETE FROM rule_contents WHERE rule_content_id >= 89 and rule_content_id <= 106;

DELETE FROM rules WHERE rule_id in (43, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55);

DELETE FROM flows WHERE flow_id in (11);

INSERT INTO flows (flow_id, mst_ref, name, description)
VALUES (11, null, 'Card purchase with 3ds flow', 'Standard card purchase with 3ds transaction flow');

INSERT INTO rules (rule_id, name, group_id, mst_ref, chn_ref)
VALUES (45, '3DS_RULE', 'CARD_PURCHASE', 'TESTMSTID', 3),
       (46, '3DS_RULE#1', 'CARD_PURCHASE', 'TESTMSTID1', 3),
       (47, '3DS_RULE#2', 'CARD_PURCHASE', 'TESTMSTID2', 3),
       (48, '3DS_RULE#3', 'CARD_PURCHASE', 'TESTMSTID3', 3),
       (49, '3DS_RULE#4', 'CARD_PURCHASE', 'TESTMSTID4', 3),
       (50, '3DS_RULE#5', 'CARD_PURCHASE', 'TESTMSTID5', 3),
       (51, '3DS_RULE#6', 'CARD_PURCHASE', 'TESTMSTID6', 3),
       (52, '3DS_RULE#7', 'CARD_PURCHASE', 'TESTMSTID7', 3),
       (53, '3DS_RULE#8', 'CARD_PURCHASE', 'TESTMSTID8', 3),
       (54, '3DS_RULE#9', 'CARD_PURCHASE', 'TESTMSTID9', 3),
       (55, '3DS_RULE#10', 'CARD_PURCHASE', 'TESTMSTID10', 3);

INSERT INTO rule_contents (rule_content_id, rule_ref, name, weight, value)
VALUES (89, 45, '3DS_RULECONTENT#1', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (90, 45, '3DS_RULECONTENT#2', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (91, 46, '3DS_RULECONTENT#3', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (92, 46, '3DS_RULECONTENT#4', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (93, 47, '3DS_RULECONTENT#5', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (94, 47, '3DS_RULECONTENT#6', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (95, 48, '3DS_RULECONTENT#7', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (96, 48, '3DS_RULECONTENT#8', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (97, 49, '3DS_RULECONTENT#9', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (98, 49, '3DS_RULECONTENT#10', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (99, 50, '3DS_RULECONTENT#11', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (100, 50, '3DS_RULECONTENT#12', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (101, 51, '3DS_RULECONTENT#13', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (102, 51, '3DS_RULECONTENT#14', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (103, 52, '3DS_RULECONTENT#15', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (104, 52, '3DS_RULECONTENT#16', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (105, 53, '3DS_RULECONTENT#17', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (106, 53, '3DS_RULECONTENT#18', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (107, 54, '3DS_RULECONTENT#19', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (108, 54, '3DS_RULECONTENT#20', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());'),
       (109, 55, '3DS_RULECONTENT#21', 1, 'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (110, 55, '3DS_RULECONTENT#22', 0.8, 'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());');

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (28, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds-adapter")',
        '3DS purchase, 3ds-adapter OC', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service'),
       (29, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND")',
        '3DS purchase, 3ds-adapter AREQ', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service');

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (36, 11, 0, 0, 'epay.supervisor-topic', 'Card purchase 3DS info', 'Card purchase 3DS, apply card purchase flow command'),
       (37, 11, 1, 1, 'epay.cardinfo-topic', 'Card purchase 3DS first stage, card info', 'Card purchase 3DS first stage, apply card info command'),
       (38, 11, 17, 2, 'epay.router-topic', 'Card purchase 3DS first stage, router', 'Card purchase 3DS first stage, apply router command'),
       (39, 11, 28, 3, 'epay.3ds-adapter-topic', 'Card purchase 3DS first stage, 3ds adapter', 'Card purchase 3DS first stage, apply 3ds adapter command'),
       (40, 11, 29, 5, 'epay.3ds-adapter-topic', 'Card purchase 3DS second stage, 3ds adapter info', 'Card purchase 3DS second stage, apply 3ds adapter command'),
       (41, 11, 6, 8, 'epay.gatewayadapter-topic', 'Card purchase 3DS second stage, gateway info', 'Card purchase 3DS second stage, apply gateway adapter command'),
       (42, 11, 3, 9, 'epay.merchantplugin-topic', 'Card purchase 3DS first stage, merchant plugin info', 'Card purchase 3DS second stage, apply merchant plugin command');