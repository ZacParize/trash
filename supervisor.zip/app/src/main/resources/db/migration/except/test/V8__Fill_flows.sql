insert into flows (flow_id, name, mst_ref, description)
values (1, 'Card purchase flow', null, 'Standard card purchase transaction flow'),
       (2, 'Card refund flow', null,  'Standard card refund transaction flow'),
       (3, 'Card payout flow', null,  'Standard card payout transaction flow'),
       (4, 'Sbp purchase flow', null,  'Standard sbp purchase transaction flow'),
       (5, 'Sbp refund flow', null, 'Standard sbp refund transaction flow'),
       (6, 'Confirm flow', null, 'Standard confirm transaction flow'),
       (7, 'Another card purchase flow', null, 'Standard card purchase transaction flow')
ON CONFLICT DO NOTHING;

insert into flow_commands (flow_command_id, command, name, description)
values (0, 'transaction != null && "CARD_PAYMENT".equals(transaction.getType().name())', 'Card purchase flow check', 'Card purchase, checking whether transaction should go throughout purchase flow'),
       (1, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-cardinfo")', 'Card purchase, card info check', 'Card purchase, checking whether transaction should go throughout card info service'),
       (2, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-comission")', 'Card purchase, commission check', 'Card purchase, checking whether transaction should go throughout commissions check service'),
       (3, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-merchantplugin")', 'Card purchase, merchant plugin', 'Card purchase, checking whether transaction should go throughout merchant plugin service'),
       (4, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', 'Card purchase router', 'Card purchase, checking whether transaction should go throughout router service'),
       (5, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds")', 'Card purchase 3DS', 'Card purchase, card purchase, checking whether transaction should go throughout 3DS service'),
       (6, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-gatewayadapter")', 'Card purchase, gateway adapter', 'Card purchase, checking whether transaction should go throughout gateway adapter service'),
       (7, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-tokenization")', 'Card purchase, tokenization', 'Card purchase, checking whether transaction should go throughout tokenization service'),
       (8, 'transaction != null && "SBP_PAYMENT".equals(transaction.getType().name())', 'Sbp purchase flow check', 'Sbp purchase, checking whether transaction should go throughout purchase flow'),
       (9, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', 'Sbp purchase, router', 'Sbp purchase, checking whether transaction should go throughout router service'),
       (10, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-sbpadapter")', 'Sbp purchase, sbp adapter', 'Sbp purchase, checking whether transaction should go throughout sbp adapter service'),
       (11, 'transaction != null && "SBP_REFUND".equals(transaction.getType().name())', 'Sbp refund flow check', 'Sbp refund, checking whether transaction should go throughout refund flow'),
       (12, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', 'Sbp refund, router init', 'Sbp refund, checking whether transaction should go throughout router service'),
       (13, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-sbpadapter")', 'Sbp refund, sbp adapter init', 'Sbp refund, checking whether transaction should go throughout sbp adapter service'),
       (14, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-router") && Integer.parseInt(transaction.getContext().get("epay-router").toString()) == 1', 'Sbp refund, router confirm', 'Sbp refund, checking whether transaction should go throughout router service'),
       (15, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-sbpadapter")', 'Sbp refund, sbp adapter confirm', 'Sbp refund, checking whether transaction should go throughout sbp adapter service'),
       (16, 'transaction != null && "CARD_PURCHASE".equals(transaction.getType().name())', 'Another card purchase flow check', 'Card purchase, checking whether transaction should go throughout purchase flow'),
       (17, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-router")', '3DS purchase, router', '3DS purchase, checking whether transaction should go throughout router service'),
       (18, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds-adapter")', '3DS purchase, 3ds-adapter', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service'),
       (19, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-multicard")', '3DS purchase, multicard', '3DS purchase, checking whether transaction should go throughout multicard service')
ON CONFLICT DO NOTHING;

insert into flow_points (flow_point_id, flow_ref, flow_command_ref, point, rank, name, description)
values (0, 1, 0, 'epay.supervisor-topic', 0, 'Card purchase flow info', 'Card purchase, apply card purchase flow command'),
       (1, 1, 1, 'epay.cardinfo-topic', 1, 'Card purchase, card info', 'Card purchase, apply card info command'),
       (2, 1, 2, 'epay.comission-topic', 2, 'Card purchase, commission info', 'Card purchase, apply commission info command'),
       (3, 1, 3, 'epay.merchantplugin-topic', 3, 'Card purchase, merchant plugin info', 'Card purchase, apply merchant plugin info command'),
       (4, 1, 4, 'epay.router-topic', 4, 'Card purchase, router info', 'Card purchase, apply router command'),
       (5, 1, 5, 'epay.3ds-topic', 5, 'Card purchase, 3DS info', 'Card purchase, apply 3DS command'),
       (6, 1, 6, 'epay.gatewayadapter-topic', 6, 'Card purchase, gateway info', 'Card purchase, apply gateway adapter command'),
       (7, 1, 7, 'epay.tokenization-topic', 7, 'Card purchase, tokenization info', 'Card purchase, apply tokenization command'),
       (8, 4, 8, 'epay.supervisor-topic', 0, 'Sbp purchase flow info', 'Sbp purchase, apply sbp purchase flow command'),
       (9, 4, 9, 'epay.router-topic', 1, 'Sbp purchase, router info', 'Sbp purchase, apply router command'),
       (10, 4, 10, 'epay.sbpadapter-topic', 2, 'Sbp purchase,sbp adapter info', 'Sbp purchase, apply sbp adapter command'),
       (11, 5, 11, 'epay.supervisor-topic', 0, 'Sbp refund flow info', 'Sbp refund, apply sbp refund flow command'),
       (12, 5, 12, 'epay.router-topic', 1, 'Sbp refund, router info init', 'Sbp refund, apply router command'),
       (13, 5, 13, 'epay.sbpadapter-topic', 2, 'Sbp refund, sbp adapter info', 'Sbp refund, apply sbp adapter command'),
       (14, 5, 14, 'epay.router-topic', 3, 'Sbp refund, router info confirm', 'Sbp refund, apply router command'),
       (15, 5, 15, 'epay.sbpadapter-topic', 4, 'Sbp refund, sbp adapter info confirm', 'Sbp refund, apply sbp adapter command'),
       (16, 7, 16, 'epay.supervisor-topic', 0, '3DS purchase flow info', '3DS purchase, apply 3ds purchase flow command'),
       (17, 7, 17, 'epay.router-topic', 1, '3DS purchase, router info', '3DS purchase, apply router command'),
       (18, 7, 18, 'epay.3ds-adapter-topic', 2, '3DS purchase, 3ds adapter info', '3DS purchase, apply 3DS adapter command'),
       (19, 7, 19, 'epay.multicard-topic', 3, '3DS purchase, multicard info', '3DS purchase, apply multicard command')
ON CONFLICT DO NOTHING;