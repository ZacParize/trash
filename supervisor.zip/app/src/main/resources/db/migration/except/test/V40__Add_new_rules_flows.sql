INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (28, 'transaction != null && transaction.getContext() != null && !transaction.getContext().containsKey("epay-3ds-adapter")',
        '3DS purchase, 3ds-adapter OC', '3DS purchase, checking whether transaction should go throughout 3ds-adapter service'),
       (29, 'transaction != null && transaction.getContext() != null && transaction.getContext().containsKey("epay-3ds-adapter") && Integer.parseInt(transaction.getContext().get("epay-3ds-adapter").toString()) == 2',
        '3DS purchase, 3ds-adapter AREQ', '3DS purchase, 3ds-adapter AREQ')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (36, 1, 0, 9, 'epay.supervisor-topic', 'Card purchase flow 3DS info', 'Card purchase 3DS, apply card purchase flow command'),
       (37, 1, 1, 10, 'epay.cardinfo-topic', 'Card purchase 3DS, card info', 'Card purchase 3DS, apply card info command'),
       (38, 1, 17, 12, 'epay.router-topic', 'Card purchase 3DS, router info', 'Card purchase 3DS, apply router command'),
       (39, 1, 28, 13, 'epay.3ds-adapter-topic', 'Card purchase 3DS, 3ds adapter info', 'Card purchase 3DS, apply 3ds adapter command'),
       (40, 1, 3, 14, 'epay.merchantplugin-topic', 'Card purchase 3DS, merchant plugin info',
        'Card purchase 3DS, apply merchant plugin info command'),
       (41, 1, 29, 15, 'epay.3ds-adapter-topic', 'Card purchase 3DS second phase, 3ds adapter info', 'Card purchase 3DS second phase, apply 3ds adapter command'),
       (42, 1, 6, 16, 'epay.gatewayadapter-topic',
        'Card purchase 3DS second phase, gateway info', 'Card purchase 3DS second phase, apply gateway adapter command')
ON CONFLICT DO NOTHING;

INSERT INTO rules (rule_id, name, group_id, mst_ref, chn_ref)
VALUES (45, '3DS_RULE', 'CARD_PURCHASE', 'TESTMSTID21', 3)
ON CONFLICT DO NOTHING;

INSERT INTO rule_contents (rule_content_id, rule_ref, name, weight, value)
VALUES (93, 45, '3DSRULECONTENT#1', 1,
        'transaction != null && transaction.getAmount() != null && transaction.getAmount().getValue() > 0 && transaction.getAmount().getValue() < 100000'),
       (94, 45, '3DSRULECONTENT#2', 0.8,
        'var arr = ["RUR", "RUB", "EUR", "USD"]; return transaction != null && transaction.getAmount() != null && arr.contains(transaction.getAmount().getCurrency());')
ON CONFLICT DO NOTHING;