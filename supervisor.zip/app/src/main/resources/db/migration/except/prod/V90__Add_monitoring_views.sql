CREATE OR REPLACE VIEW mon_transactions_view AS
SELECT o.code, o.changed_at , o.state as state_orders, tr.type, tr.state as state_transactions
FROM epay.epay.orders o
    INNER JOIN epay.epay.transactions tr on tr.order_ref = o.order_id;

CREATE OR REPLACE VIEW mon_orders_view AS
SELECT o.code,o.created_at, o.changed_at, o.expired_at, o.state
FROM epay.epay.orders o;