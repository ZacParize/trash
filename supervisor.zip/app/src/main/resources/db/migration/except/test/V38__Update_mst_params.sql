update merchant_sites
set params = '{ "terminalId": "88054516",
                "callbackUrl": "https://ms-tsp-ia-mock.ds1-genr01-efcp-box-tspdev.apps.ds1-genr01.corp.dev.vtb/merchcallback",
                "partialRefund": true,
                "orderLifeTime": "PT20m",
                "merchantPayments": { "sbpPayment": true, "cardPayment": true } }'
where mst_id ilike 'TESTMSTID%';