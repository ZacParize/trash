UPDATE transactions SET state = 'DECLINED'
WHERE transaction_id = '4ce5a1c5-6f37-4255-b8fc-86f23f2c66e4-vpay';