create table if not exists notifications (
    id bigserial primary key,
    code varchar(256) not null,
    type varchar(256) not null,
    state varchar(256) not null,
    sent_at timestamp not null default now(),
    payload bytea not null,
    destination varchar(256)[] not null,
    created_at timestamp not null default now(),
    modified_at timestamp not null default now(),
    version integer not null
);

CREATE SEQUENCE IF NOT EXISTS notifications_id_sequence START 1  INCREMENT 1;

CREATE INDEX IF NOT EXISTS notifications_code_idx ON notifications (code);
CREATE INDEX IF NOT EXISTS notifications_state_idx ON notifications (state);
CREATE INDEX IF NOT EXISTS notifications_type_idx ON notifications (type);
CREATE INDEX IF NOT EXISTS notifications_state_sent_at_idx ON notifications (state, sent_at);
CREATE INDEX IF NOT EXISTS notifications_state_destination_idx ON notifications (state, destination);
CREATE INDEX IF NOT EXISTS notifications_type_sent_at_idx ON notifications (type, sent_at);
CREATE INDEX IF NOT EXISTS notifications_type_destination_idx ON notifications (type, destination);
CREATE INDEX IF NOT EXISTS notifications_type_state_sent_at_idx ON notifications (type, state, sent_at);

GRANT USAGE ON SCHEMA epay TO epay_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA epay TO epay_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA epay TO epay_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA epay TO epay_user;