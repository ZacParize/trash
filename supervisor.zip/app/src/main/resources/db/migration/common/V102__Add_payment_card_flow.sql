INSERT INTO flows (flow_id, name, mst_ref, description)
VALUES (15, 'Common card payment flow', null, 'Common card payment flow')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, "name", description)
VALUES (64,
        'transaction != null && "GW_PAYMENT".equals(transaction.getType().name()) && !"RECONCILED".equals(transaction.getStatus().getValue())',
        'Check common card payment flow', 'Check common card payment flow'),
       (65,
        'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-cardinfo")',
        'Common card payment, card info check',
        'Common card payment, checking whether transaction should go throughout card info service'),
       (66,
        'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter")',
        'Common card payment, gateway adapter',
        'Common card payment, checking whether transaction should go throughout gateway adapter service'),
       (67,
        'transaction != null && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-merchantplugin") && transaction.getRoute().isVisitedService("epay-gatewayadapter")',
        'Common card payment, merchant plugin',
        'Common card payment, checking whether transaction should go throughout merchant plugin service')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, "rank", point, "name",
                         description)
VALUES (77, 15, 64, 0, 'epay.supervisor-topic', 'Common card payment flow',
        'Common card payment flow, apply card purchase flow command'),
       (78, 15, 65, 1, 'epay.cardinfo-topic', 'Common card payment flow, card info',
        'Common card payment flow, card info step'),
       (79, 15, 66, 3, 'epay.gatewayadapter-topic', 'Common card payment flow, gateway payment',
        'Common card payment flow, payment step'),
       (80, 15, 67, 5, 'epay.merchantplugin-topic', 'Common card payment flow, merchant callback',
        'Common card payment flow, merchant callback step')
ON CONFLICT DO NOTHING;
