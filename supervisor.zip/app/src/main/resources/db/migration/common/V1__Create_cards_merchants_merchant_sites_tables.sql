create table if not exists merchants (
    merch_id        text primary key,
    name            text not null,
    params          jsonb
);

CREATE INDEX IF NOT EXISTS merchants_name_idx ON merchants(name);

create table if not exists merchant_sites (
    mst_id          text primary key,
    merch_ref       text references merchants (merch_id) not null,
    url             text not null,
    name            text not null,
    params          jsonb
);

CREATE INDEX IF NOT EXISTS merchant_sites_merch_ref_idx ON merchant_sites(merch_ref);
CREATE UNIQUE INDEX IF NOT EXISTS merchant_sites_url_idx ON merchant_sites(url);
CREATE INDEX IF NOT EXISTS merchant_sites_name_idx ON merchant_sites(name);