ALTER TABLE IF EXISTS merchants
    ADD COLUMN IF NOT EXISTS mdm_code BIGINT;

CREATE UNIQUE INDEX merchants_mdm_code_idx ON merchants USING btree (mdm_code);

UPDATE merchants m
SET entity = entity || jsonb_build_object('mdmCode', null)
WHERE entity -> 'mdmCode' is null;