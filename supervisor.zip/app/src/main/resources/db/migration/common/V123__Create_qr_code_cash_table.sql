create table if not exists qr_code_cash
(
    id           bigserial primary key,
    qrc_id       varchar(100)            not null,
    payload      varchar(1000),
    redirect_url varchar(1024),
    status       varchar(100),
    account      varchar(50)             not null,
    created_at   timestamp default now() not null,
    merchant_id  varchar(256)            not null
);

create unique index if not exists qr_code_cash_qrc_id_idx on qr_code_cash (qrc_id);

create index if not exists qr_code_cash_merchant_id_idx on qr_code_cash (merchant_id);

create index if not exists qr_code_cash_merchant_id_status_idx on qr_code_cash (merchant_id, status);

grant select, update, usage on sequence qr_code_cash_id_seq to epay_user;

grant delete, insert, references, select, trigger, truncate, update on qr_code_cash to epay_user;