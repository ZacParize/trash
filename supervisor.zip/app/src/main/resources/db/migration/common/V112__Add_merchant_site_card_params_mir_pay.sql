-- добавление cardParams.enableMirPayment
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableMirPayment}', 'false'::jsonb, true);