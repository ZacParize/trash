UPDATE flow_commands
SET command ='transaction != null ' ||
             '&& transaction.getRoute()!=null ' ||
             '&& ("PAID".equals(transaction.getStatus().getValue()) ' ||
             '|| "DECLINED".equals(transaction.getStatus().getValue()) ' ||
             '|| "REJECTED".equals(transaction.getStatus().getValue())) ' ||
             '&& transaction.getRoute().getVisitedService("epay-absadapter")<2'
WHERE flow_command_id = 73



