ALTER TABLE IF EXISTS merchant_sites
    ADD COLUMN IF NOT EXISTS type varchar(64) NOT NULL DEFAULT 'INTERNET_ACQUIRING';

UPDATE merchant_sites ms
SET entity = entity || jsonb_build_object('type', 'INTERNET_ACQUIRING')
WHERE ms.entity -> 'type' IS NULL;

DROP INDEX merchant_sites_url_idx;
CREATE INDEX IF NOT EXISTS merchant_sites_url_idx ON merchant_sites (url);