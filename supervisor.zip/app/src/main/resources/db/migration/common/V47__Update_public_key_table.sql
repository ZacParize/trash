delete from public_key;
alter table public_key alter column value type JSONB USING value::JSONB;
alter table public_key alter column value set NOT NULL;
