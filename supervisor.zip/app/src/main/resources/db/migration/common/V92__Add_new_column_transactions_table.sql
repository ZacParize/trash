ALTER TABLE IF EXISTS transactions
    ADD COLUMN IF NOT EXISTS amount_hold numeric default 0;