UPDATE flow_commands set
command = 'transaction != null && transaction.getRoute() != null ' ||
          '&& "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) ' ||
          '&& !transaction.getRoute().isVisitedService("epay-merchantplugin") ' ||
          '&& transaction.getRoute().isVisitedService("epay-gatewayadapter") ' ||
          '&& ("AUTHORIZED".equals(transaction.getStatus().name()) || transaction.isCompleted())'
WHERE flow_command_id = 60;