create table if not exists flows (
    flow_id bigserial primary key,
    mst_ref text references merchant_sites(mst_id),
    name varchar(256) not null,
    description varchar(512) not null
);

CREATE UNIQUE INDEX IF NOT EXISTS flows_name_idx ON flows (name);
CREATE INDEX IF NOT EXISTS flows_mst_ref_idx ON flows (mst_ref);

create table if not exists flow_commands (
    flow_command_id bigserial primary key,
    command text not null,
    name varchar(256) not null,
    description varchar(512) not null
);

CREATE UNIQUE INDEX IF NOT EXISTS flow_commands_name_idx ON flow_commands (name);

create table if not exists flow_points (
    flow_point_id bigserial primary key,
    flow_ref bigint references flows(flow_id) not null,
    flow_command_ref bigint references flow_commands(flow_command_id) not null,
    rank bigint not null,
    point varchar(256) not null,
    name varchar(256) not null,
    description varchar(512) not null
);

CREATE UNIQUE INDEX IF NOT EXISTS flow_points_name_idx ON flow_points (name);
CREATE UNIQUE INDEX IF NOT EXISTS flow_points_flow_ref_rank_idx ON flow_points (flow_ref, rank);
CREATE INDEX IF NOT EXISTS flow_points_flow_ref_idx ON flow_points (flow_ref);
CREATE INDEX IF NOT EXISTS flow_points_flow_command_ref_idx ON flow_points (flow_command_ref);