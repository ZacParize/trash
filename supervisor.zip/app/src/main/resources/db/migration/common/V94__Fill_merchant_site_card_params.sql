DO
$$
    DECLARE
        row record;
    BEGIN

        ALTER TABLE IF EXISTS merchant_sites
            DROP COLUMN IF EXISTS params_old;

        UPDATE merchant_sites
        SET params = jsonb_set(params, '{cardParams,enableTwoStage}',
            coalesce(params #> '{merchantPayments,cardParams}', 'false'::jsonb), true)
        WHERE (params -> 'cardParams' ->> 'enableTwoStage') is null;

        FOR row IN (
            SELECT
                row_to_json(mst) as site
            FROM
                (
                    SELECT
                        ms.id,
                        ms.url,
                        ms.merch_ref as "merchantId",
                        ms.name,
                        ms.login,
                        ms.params,
                        to_char(ms.created, 'YYYY-MM-DD HH24:MI:SS.MS') as created,
                        to_char(ms.modified, 'YYYY-MM-DD HH24:MI:SS.MS') as modified,
                        ms.state
                    FROM
                        merchant_sites ms
                ) as mst
        ) LOOP

            UPDATE merchant_sites ms
            SET entity = (to_jsonb(row) ->> 'site') :: jsonb
            WHERE ms.id = to_jsonb(row) -> 'site' ->> 'id';

        END LOOP;

    END;
$$