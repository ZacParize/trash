ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS binding_type varchar(256);
ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS binding_category varchar(256);
ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS binding_code uuid;
ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS mst_customer_id varchar(256);