DO
$$
    DECLARE
        row record;
    BEGIN

        FOR row IN (
            select row_to_json(merchs) as merch
            from (
                     select m.id,
                            m.name,
                            m.state,
                            m.params,
                            m.mdm_code as "mdmCode",
                            to_char(m.created, 'YYYY-MM-DD HH24:MI:SS.MS') as created,
                            to_char(m.modified, 'YYYY-MM-DD HH24:MI:SS.MS') as modified
                     from merchants m
                 ) as merchs
        ) LOOP

            UPDATE merchants m
            SET entity = (to_jsonb(row) ->> 'merch')::jsonb
            WHERE m.id = to_jsonb(row) -> 'merch' ->> 'id';

        END LOOP;

    END
$$