create table if not exists currencies (
    code            text not null,
    numeric_code    integer not null,
    name            text not null
);

CREATE UNIQUE INDEX IF NOT EXISTS currencies_code_idx ON currencies(code);
CREATE UNIQUE INDEX IF NOT EXISTS currencies_numeric_code_idx ON currencies(numeric_code);

INSERT INTO currencies (code, numeric_code, name)
VALUES ('USD',	840, 'Доллар США'),
       ('EUR',	978, 'Евро'),
       ('GBP',	826, 'Фунт стерлингов Великобритании'),
       ('JPY',	392, 'Японская йена'),
       ('CHF',	756, 'Швейцарский франк'),
       ('CNY',	156, 'Китайский юань женьминьби'),
       ('RUB',	643, 'Российский рубль'),
       ('RUR',	810, 'Российский рубль (устарел)')
ON CONFLICT DO NOTHING;