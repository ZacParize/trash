CREATE TABLE IF NOT EXISTS bundle
(
    id          UUID                          NOT NULL PRIMARY KEY,
    order_ref   UUID REFERENCES orders (code) NOT NULL,
    fiscal_info JSONB,
    items       JSONB                         NOT NULL,
    created_at  TIMESTAMP                     NOT NULL DEFAULT now(),
    updated_at  TIMESTAMP                     NOT NULL DEFAULT now(),
    version     INTEGER                                DEFAULT 0
);

CREATE INDEX IF NOT EXISTS bundle_order_ref_idx ON bundle (order_ref);

COMMENT ON COLUMN bundle.id IS 'Идентификатор товарной корзины';
COMMENT ON COLUMN bundle.order_ref IS 'Идентификатор заказа товарной корзины';
COMMENT ON COLUMN bundle.fiscal_info IS 'Параметры фискализации для товарной корзины';
COMMENT ON COLUMN bundle.items IS 'Товарная корзина в виде JSON';
COMMENT ON COLUMN bundle.created_at IS 'Дата создания';
COMMENT ON COLUMN bundle.updated_at IS 'Дата изменения';