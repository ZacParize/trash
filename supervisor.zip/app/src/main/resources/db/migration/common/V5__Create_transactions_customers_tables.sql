create table if not exists transactions (
    transaction_id text primary key,
    order_ref text references orders(order_id) not null,
    flow_ref bigint references flows(flow_id),
    created_at timestamp not null default now(),
    amount numeric not null,
    currency_ref text references currencies(code) not null,
    token_ref text references tokens(token_id),
    mst_transaction_id text not null,
    type varchar(256) not null,
    state varchar(256) not null,
    data jsonb
);

CREATE UNIQUE INDEX IF NOT EXISTS transactions_transaction_id_state_idx ON transactions (transaction_id, state);
CREATE UNIQUE INDEX IF NOT EXISTS transactions_transaction_id_token_ref_idx ON transactions (transaction_id, token_ref);
CREATE INDEX IF NOT EXISTS transactions_order_idx ON transactions (order_ref);
CREATE INDEX IF NOT EXISTS transactions_currency_ref_idx ON transactions (currency_ref);
CREATE INDEX IF NOT EXISTS transactions_order_ref_type_idx ON transactions (order_ref, type);
CREATE INDEX IF NOT EXISTS transactions_mst_transaction_id_idx ON transactions (mst_transaction_id);

create table if not exists transaction_info (
    transaction_info_id bigserial primary key,
    transaction_ref     text references transactions (transaction_id) not null,
    key                 varchar(256) not null,
    value               text,
    created_at          timestamp not null default now()
);

CREATE INDEX IF NOT EXISTS transaction_info_transaction_ref_key_idx ON transaction_info(transaction_ref, key);
CREATE INDEX IF NOT EXISTS transaction_info_transaction_ref_created_at_idx ON transaction_info (transaction_ref, created_at);
CREATE INDEX IF NOT EXISTS transaction_info_key_value_created_at_idx ON transaction_info(key, value, created_at);

create table if not exists customers (
    customer_id text primary key,
    email       text not null,
    phone       text not null
);

CREATE UNIQUE INDEX IF NOT EXISTS customers_phone_email_idx ON customers(phone, email);
CREATE INDEX IF NOT EXISTS customers_email_idx ON customers(email);