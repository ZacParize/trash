-- добавление cardParams.enableMirPayment для entity
UPDATE merchant_sites ms
SET entity = jsonb_set(entity, '{params, cardParams, enableMirPayment}', 'false'::jsonb)
WHERE ms.entity -> 'params' IS NOT NULL
AND ms.entity -> 'params' -> 'cardParams' IS NOT NULL;