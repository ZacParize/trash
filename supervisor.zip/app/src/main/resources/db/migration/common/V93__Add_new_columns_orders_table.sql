ALTER TABLE IF EXISTS orders
    ADD COLUMN IF NOT EXISTS authorized_at timestamp;

ALTER TABLE IF EXISTS orders
    ADD COLUMN IF NOT EXISTS amount_hold numeric default 0;