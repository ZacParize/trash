create table if not exists public_key
(
    id serial PRIMARY KEY not null,
    value text not null,
    date_create timestamp not null default now(),
    date_update timestamp
);
COMMENT ON TABLE public_key IS 'Таблица для хранения публичных ключей для шифрования PAN/CVV';
COMMENT ON COLUMN public_key.id IS 'Первычиный ключ';
COMMENT ON COLUMN public_key.value IS 'Публичный ключ';
COMMENT ON COLUMN public_key.date_create IS 'Дата создания';
COMMENT ON COLUMN public_key.date_update IS 'Дата обновления';
