UPDATE flow_commands
SET command='transaction != null && "A2C_TRANSFER".equals(transaction.getType().name())' ||
            ' && "NEW".equals(transaction.getStatus().getValue())'
WHERE flow_command_id = 30;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (72, 'transaction != null ' ||
            '&& transaction.getRoute() != null' ||
            '&& "NEW".equals(transaction.getStatus().getValue())' ||
            '&& !transaction.getRoute().isVisitedService("epay-absadapter")',
            'A2C absadapter',
            'Account to card, holding step')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command,name, description)
VALUES (73, 'transaction != null ' ||
            '&& transaction.getRoute()!=null ' ||
            '&& ("PAID".equals(transaction.getStatus().getValue()) ' ||
            '|| "REJECTED".equals(transaction.getStatus().getValue())) ' ||
            '&& transaction.getRoute().getVisitedService("epay-absadapter")<2',
            'A2C absadapter finalization',
            'Account to card, final step')
ON CONFLICT DO NOTHING;

UPDATE flow_commands set command = 'transaction != null ' ||
                                   '&& transaction.getRoute() != null ' ||
                                   '&& !transaction.getRoute().isVisitedService("epay-gatewayadapter") ' ||
                                   '&& "HELD".equals(transaction.getStatus().getValue())'
                     WHERE flow_command_id=34;

DELETE FROM flow_points  WHERE flow_point_id=46;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (88, 10, 72, 2, 'epay.absadapter-topic',
        'Account to card flow, absadapter',
        'Account to card, holding step')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (89, 10, 73, 4, 'epay.absadapter-topic',
        'Account to card flow, absadapter finalization',
        'Account to card, final step');



