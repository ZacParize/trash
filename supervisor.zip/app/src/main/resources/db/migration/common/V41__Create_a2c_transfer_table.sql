ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS order_type varchar(256);
ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS changed_at timestamp null default now();