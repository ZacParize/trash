create table if not exists tokens (
    token_id text primary key,
    pan_hash text,
    valid_to timestamp,
    phone text,
    email text,
    account_id text,
    vtb_id text,
    cookie_id text,
    params jsonb
);

CREATE INDEX IF NOT EXISTS tokens_phone_idx ON tokens (phone);
CREATE INDEX IF NOT EXISTS tokens_email_idx ON tokens (email);
CREATE INDEX IF NOT EXISTS tokens_vtb_id_idx ON tokens (vtb_id);

create table if not exists orders
(
    order_id text primary key,
    mst_ref text references merchant_sites(mst_id) not null,
    mst_order_id text not null,
    name varchar(256) not null,
    amount numeric not null,
    currency_ref text references currencies(code) not null,
    state varchar(256) not null,
    created_at timestamp not null default now(),
    description text
);

CREATE INDEX IF NOT EXISTS orders_mst_id_idx ON orders (mst_ref);
CREATE INDEX IF NOT EXISTS orders_currency_ref_idx ON orders (currency_ref);
CREATE INDEX IF NOT EXISTS orders_amount_idx ON orders (amount);
CREATE UNIQUE INDEX IF NOT EXISTS orders_mst_order_id_mst_ref_idx ON orders (mst_order_id, mst_ref);