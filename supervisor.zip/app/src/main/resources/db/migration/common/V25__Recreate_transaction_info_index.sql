DROP INDEX IF EXISTS transaction_info_transaction_ref_key_idx;
CREATE UNIQUE INDEX IF NOT EXISTS transaction_info_transaction_ref_key_idx ON transaction_info(transaction_ref, key);