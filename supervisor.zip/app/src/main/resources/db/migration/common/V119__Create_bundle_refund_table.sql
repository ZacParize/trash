CREATE TABLE IF NOT EXISTS bundle_refund
(
    id              UUID                                NOT NULL PRIMARY KEY,
    order_ref       UUID REFERENCES orders (code)       NOT NULL,
    transaction_ref UUID REFERENCES transactions (code) NOT NULL,
    fiscal_info     JSONB,
    items           JSONB                               NOT NULL,
    created_at      TIMESTAMP                           NOT NULL DEFAULT now(),
    updated_at      TIMESTAMP                           NOT NULL DEFAULT now(),
    version         INTEGER                                      DEFAULT 0
);

CREATE INDEX IF NOT EXISTS bundle_order_ref_idx ON bundle_refund (order_ref);
CREATE UNIQUE INDEX IF NOT EXISTS bundle_transaction_ref_idx ON bundle_refund USING btree (transaction_ref);

COMMENT ON COLUMN bundle_refund.id IS 'Идентификатор товарной корзины';
COMMENT ON COLUMN bundle_refund.order_ref IS 'Идентификатор заказа товарной корзины';
COMMENT ON COLUMN bundle_refund.transaction_ref IS 'Идентификатор транзакции товарной корзины';
COMMENT ON COLUMN bundle_refund.fiscal_info IS 'Параметры фискализации для товарной корзины';
COMMENT ON COLUMN bundle_refund.items IS 'Товарная корзина в виде JSON';
COMMENT ON COLUMN bundle_refund.created_at IS 'Дата создания';
COMMENT ON COLUMN bundle_refund.updated_at IS 'Дата изменения';