create table if not exists gateways
(
    gtw_id bigserial primary key,
    adapter varchar(256) not null,
    description varchar(512),
    params jsonb
);

CREATE INDEX IF NOT EXISTS gateways_adapter_idx ON gateways(adapter);

create table if not exists channels
(
    chn_id bigserial primary key,
    gtw_ref bigint references gateways(gtw_id) not null,
    params jsonb
);

CREATE INDEX IF NOT EXISTS channels_gtw_ref_idx ON channels(gtw_ref);