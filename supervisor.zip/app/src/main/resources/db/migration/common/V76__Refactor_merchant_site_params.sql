ALTER TABLE IF EXISTS merchant_sites ADD COLUMN IF NOT EXISTS params_old jsonb;
update merchant_sites set params_old = params;


-- добавление cardParams, transferParams
update merchant_sites
set params = jsonb_set(params, '{cardParams}', '{}'::jsonb, true);
update merchant_sites
set params = jsonb_set(params, '{transferParams}', '{}'::jsonb, true);


-- добавление sbpParams.enableSbpPayment, cardParams.enableCardPayment
update merchant_sites
set params = jsonb_set(params, '{sbpParams,enableSbpPayment}',
    coalesce(params #> '{merchantPayments,sbpPayment}', 'false'::jsonb), true);
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableCardPayment}',
    coalesce(params #> '{merchantPayments,cardPayment}', 'false'::jsonb), true);


-- добавление sbpParams.enablePartialRefund, sbpParams.enablePartialRefund
update merchant_sites
set params = jsonb_set(params, '{sbpParams,enablePartialRefund}',
    coalesce(params -> 'partialRefund', 'false'::jsonb), true);
update merchant_sites
set params = jsonb_set(params, '{cardParams,enablePartialRefund}',
    coalesce(params -> 'partialRefund', 'false'::jsonb), true);

update merchant_sites set params = params #- '{partialRefund}';


-- удаление sbpParams.agentId, sbpParams.memberId
update merchant_sites set params = params #- '{sbpParams,agentId}';
update merchant_sites set params = params #- '{sbpParams,memberId}';


-- добавление cardParams.terminalId
update merchant_sites
set params = jsonb_set(params, '{cardParams,terminalId}',
    coalesce(params -> 'terminalId', 'null'::jsonb), true);
update merchant_sites set params = params #- '{terminalId}';


-- добавление cardParams.enableCardFlowThreeDS
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableCardFlowThreeDS}',
    coalesce(params #> '{merchantPayments,cardFlowThreeDS}', 'false'::jsonb), true);


-- добавление cardParams.enableCardFlowThreeDSOnMerchantSide
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableCardFlowThreeDSOnMerchantSide}',
    coalesce(params #> '{merchantPayments,cardFlowThreeDSOnMerchantSide}', 'false'::jsonb), true);


-- добавление cardParams.enableCardFlowThreeDSOnMerchantSide
update merchant_sites
set params = jsonb_set(params, '{cardParams,enablePaymentCheckboxesVisible}',
    coalesce(params #> '{merchantPayments,paymentCheckboxesVisible}', 'false'::jsonb), true);


-- добавление cardParams.enableGooglePayment
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableGooglePayment}', 'false'::jsonb, true);


-- добавление cardParams.enableApplePayment
update merchant_sites
set params = jsonb_set(params, '{cardParams,enableApplePayment}', 'false'::jsonb, true);


-- добавление cardParams.merchantId
update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantId}', 'null'::jsonb, true);


-- добавление cardParams.merchantName
update merchant_sites
set params = jsonb_set(params, '{cardParams,merchantName}', 'null'::jsonb, true);


-- добавление transferParams.enableA2cTransfer
update merchant_sites
set params = jsonb_set(params, '{transferParams, enableA2cTransfer}', 'false'::jsonb, true);


-- добавление transferParams.enableC2aTransfer
update merchant_sites
set params = jsonb_set(params, '{transferParams,enableC2aTransfer}', 'false'::jsonb, true);


-- добавление transferParams.a2cTransferParams
update merchant_sites
set params = jsonb_set(params, '{transferParams,a2cTransferParams}',
    coalesce(params #> '{merchantTransfers,a2cTransferParams}','{}'::jsonb), true);


-- добавление transferParams.c2aTransferParams
update merchant_sites
set params = jsonb_set(params, '{transferParams,c2aTransferParams}',
    coalesce(params #> '{merchantTransfers,c2aTransferParams}','{}'::jsonb), true);


-- удаление merchantPayments
update merchant_sites set params = params - 'merchantPayments';


-- удаление merchantTransfers
update merchant_sites set params = params - 'merchantTransfers';