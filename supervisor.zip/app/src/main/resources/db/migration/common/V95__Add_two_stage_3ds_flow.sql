INSERT INTO flows (flow_id, name, mst_ref, description)
VALUES (13, 'Card payment two-stage with 3DS', null, 'Card payment two-stage with 3DS')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (46, 'transaction != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name())', 'Two-stage with 3DS flow check', 'Two-stage with 3DS flow check'),
       (47, 'transaction != null && transaction.getRoute() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-cardinfo")', 'Two-stage with 3DS card-info step', 'Two-stage with 3DS card-info step'),
       (48, 'transaction != null && transaction.getRoute() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-3ds-adapter")', 'Two-stage with 3DS CREATE_ORDER_FIRST step', 'Two-stage with 3DS CREATE_ORDER_FIRST step'),
       (49, 'transaction != null && transaction.getContext() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "PARES".equals(transaction.getContext().get("TDS_NEXT_STEP"))', 'Two-stage with 3DS PAREQ step', 'Two-stage with 3DS PAREQ step'),
       (50, 'transaction != null && transaction.getContext() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute() != null && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "AREQ".equals(transaction.getContext().get("TDS_NEXT_STEP"))', 'Two-stage with 3DS AREQ step', 'Two-stage with 3DS AREQ step'),
       (51, 'transaction != null && transaction.getContext() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute().isVisitedService("epay-3ds-adapter") && transaction.getContext().containsKey("3DS_DECISION_COMPLETE") && transaction.getContext().containsKey("3DS_COMP_IND") && transaction.getContext().containsKey("TDS_NEXT_STEP") && "CRES".equals(transaction.getContext().get("TDS_NEXT_STEP"))', 'Two-stage with 3DS CREQ step', 'Two-stage with 3DS CREQ step'),
       (52, 'transaction != null && transaction.getContext() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter") && transaction.getContext().containsKey("XID") && transaction.getContext().containsKey("CAVV") && transaction.getContext().containsKey("ECI")', 'Two-stage with 3DS PREAUTH step', 'Two-stage with 3DS PREAUTH step'),
       (53, 'transaction != null && transaction.getRoute() != null && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-merchantplugin") && transaction.getRoute().isVisitedService("epay-gatewayadapter") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage with 3DS callback step', 'Two-stage with 3DS callback step'),
       (54, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute().getVisitedService("epay-cardinfo") < 2 && transaction.getRoute().isVisitedService("epay-merchantplugin") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage with 3DS COMPLETE card-info step', 'Two-stage with 3DS COMPLETE card-info step'),
       (55, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && transaction.getRoute().isVisitedService("epay-merchantplugin") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage with 3DS GW COMPLETE step', 'Two-stage with 3DS GW COMPLETE step'),
       (56, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE_3DS".equals(transaction.getType().name()) && ("CONFIRMED".equals(transaction.getStatus().name()) || "DECLINED".equals(transaction.getStatus().name()))', 'Two-stage with 3DS COMPLETE callback step', 'Two-stage with 3DS COMPLETE callback step')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (59, 13, 46, 0, 'epay.supervisor-topic', 'Two-stage with 3DS start flow', 'Two-stage with 3DS start flow'),
       (60, 13, 47, 1, 'epay.cardinfo-topic', 'Two-stage with 3DS initial card-info stage', 'Two-stage with 3DS card data decrypt stage'),
       (61, 13, 48, 3, 'epay.3ds-adapter-topic', 'Two-stage with 3DS CreateOrder_First requests', 'Two-stage with 3DS, start 3ds auth'),
       (62, 13, 49, 4, 'epay.3ds-adapter-topic', 'Two-stage with 3DS PARES', 'Two-stage with 3DS PARES'),
       (63, 13, 50, 5, 'epay.3ds-adapter-topic', 'Two-stage with 3DS AREQ', 'Two-stage with 3DS AREQ'),
       (64, 13, 51, 6, 'epay.3ds-adapter-topic', 'Two-stage with 3DS CRES', 'Two-stage with 3DS CRES'),
       (65, 13, 52, 7, 'epay.gatewayadapter-topic', 'Two-stage with 3DS PREAUTH command', 'Two-stage with 3DS PREAUTH command'),
       (66, 13, 53, 8, 'epay.merchantplugin-topic', 'Two-stage with 3DS PREAUTH callback', 'Two-stage with 3DS PREAUTH callback'),
       (67, 13, 54, 9, 'epay.cardinfo-topic', 'Two-stage with 3DS COMPLETE card-info stage', 'Two-stage with 3DS COMPLETE card-info stage'),
       (68, 13, 55, 10, 'epay.gatewayadapter-topic', 'Two-stage with 3DS COMPLETE command', 'Two-stage with 3DS COMPLETE command request'),
       (69, 13, 56, 11, 'epay.merchantplugin-topic', 'Two-stage with 3DS COMPLETE callback', 'Two-stage with 3DS COMPLETE callback')
ON CONFLICT DO NOTHING;
