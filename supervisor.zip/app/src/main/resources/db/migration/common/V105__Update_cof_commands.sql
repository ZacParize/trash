UPDATE flow_commands
set command=
            'transaction != null ' ||
            '&& transaction.getRoute() != null ' ||
            '&& !transaction.getRoute().isVisitedService("epay-tokenization") '
                '&& ("RECONCILED".equals(transaction.getStatus().getValue()) ' ||
            '|| "CONFIRMED".equals(transaction.getStatus().getValue()) )'
WHERE flow_command_id = 71;

UPDATE flow_commands
    set command=
        'transaction != null && transaction.getRoute() != null ' ||
        '&& "COF_PAYMENT".equals(transaction.getType().name()) ' ||
        '&& !transaction.getRoute().isVisitedService("epay-tokenization") ' ||
        '&& "NEW".equals(transaction.getStatus().getValue())'
WHERE flow_command_id = 69;

UPDATE flow_commands
    set command='transaction != null && transaction.getRoute() != null ' ||
                '&& transaction.getRoute().getVisitedService("epay-tokenization")<2 ' ||
                '&& ("RECONCILED".equals(transaction.getStatus().getValue()) || "CONFIRMED".equals(transaction.getStatus().getValue()))'
WHERE flow_command_id = 70;