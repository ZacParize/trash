ALTER TABLE IF EXISTS merchant_sites
    ADD COLUMN IF NOT EXISTS external_application_id varchar(255);

CREATE INDEX IF NOT EXISTS merchant_sites_external_application_id_idx ON merchant_sites (external_application_id);

UPDATE merchant_sites ms
   SET entity = entity || jsonb_build_object('externalApplicationId', ms.external_application_id)
 WHERE ms.entity -> 'externalApplicationId' IS NULL;