create table if not exists standin_params(
    id          bigserial primary key,
    key         varchar(256)   not null UNIQUE,
    data        jsonb          not null,
    created_at  timestamp     not null default now(),
    modified_at timestamp     not null default now()
);
GRANT USAGE ON SCHEMA epay TO epay_user;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA epay TO epay_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA epay TO epay_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA epay TO epay_user;
