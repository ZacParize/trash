INSERT INTO flows (flow_id, name, description)
VALUES (16, 'COF purchase flow', 'Standard COF purchase transaction flow without 3DS')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (68,
        'transaction != null ' ||
        '&& "COF_PAYMENT".equals(transaction.getType().name()) ' ||
        '&& "NEW".equals(transaction.getStatus().getValue())',
        'COF purchase flow check',
        'COF purchase, checking whether transaction should go throughout purchase flow')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (69,
        'transaction != null ' ||
        '&& transaction.getRoute() != null ' ||
        '&& "COF_PAYMENT".equals(transaction.getType().name()) '
            '&& transaction.getRoute().getVisitedService("epay-tokenization")<3 ' ||
        '&& "NEW".equals(transaction.getStatus().getValue())',
        'COF purchase tokenization check',
        'COF purchase, checking is binding exists')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (70,
        'transaction != null ' ||
        '&& transaction.getRoute() != null ' ||
        '&& transaction.getRoute().getVisitedService("epay-tokenization")<3 ' ||
        '&& ("RECONCILED".equals(transaction.getStatus().getValue())' ||
        '|| "CONFIRMED".equals(transaction.getStatus().getValue()) )',
        'COF purchase binding check',
        'COF purchase, binding creation')
ON CONFLICT DO NOTHING;


INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (81, 16, 68, 0, 'epay.supervisor-topic',
        'COF purchase first point',
        'COF Payload enrichment command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (82, 16, 69, 1, 'epay.tokenization-topic',
        'COF purchase tokenization info',
        'COF purchase tokenization command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (83, 16, 1, 2, 'epay.cardinfo-topic',
        'COF purchase card info',
        'COF purchase card info command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (84, 16, 6, 3, 'epay.gatewayadapter-topic',
        'COF purchase without 3ds, gateway info',
        'COF purchase apply gateway adapter command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (85, 16, 70, 4, 'epay.tokenization-topic',
        'COF purchase without 3ds, binding info',
        'COF purchase apply binding command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (86, 16, 3, 5, 'epay.merchantplugin-topic',
        'COF purchase merchant callback flow info',
        'COF purchase merchant callback apply command')
ON CONFLICT DO NOTHING;

UPDATE flow_points
SET rank= 10
WHERE flow_ref = 11
  AND flow_point_id = 42;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (71,
        'transaction != null ' ||
        '&& transaction.getRoute() != null ' ||
        '&& ("RECONCILED".equals(transaction.getStatus().getValue())' ||
        '|| "CONFIRMED".equals(transaction.getStatus().getValue()) )',
        'Card purchase 3DS, binding creation',
        'Card purchase 3DS, binding creation command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (87, 11, 71, 9, 'epay.tokenization-topic',
        'Card purchase 3DS binding check',
        'Card purchase 3DS apply binding creation command')
ON CONFLICT DO NOTHING;
