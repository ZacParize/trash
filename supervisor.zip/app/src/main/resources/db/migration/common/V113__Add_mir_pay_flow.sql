-- добавление flow для оплаты Mir Pay
INSERT INTO flows (flow_id, name, description)
VALUES (17, 'Mir Pay purchase flow', 'Standard Mir Pay purchase flow')
ON CONFLICT DO NOTHING;

-- добавление flow_commands для оплаты Mir Pay

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (74,
        'transaction != null && "MIR_PAYMENT_WEB_BASED".equals(transaction.getType().name()) && "MIR_PAY_PAYMENT_CREATED".equals(transaction.getStatus().getValue())',
        'Mir Pay purchase flow, start payment check',
        'Mir Pay purchase flow, checking whether transaction created for future payment')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (75,
        'transaction != null && "MIR_PAYMENT_WEB_BASED".equals(transaction.getType().name()) && "MIR_PAY_PAYMENT_CREATED".equals(transaction.getStatus().getValue())',
        'Mir Pay purchase flow, confirm payment check',
        'Mir Pay purchase flow, checking whether transaction should go throughout purchase flow')
ON CONFLICT DO NOTHING;

-- добавление flow_points для оплаты Mir Pay

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (90, 17, 74, 0, 'epay.supervisor-topic',
        'Mir Pay purchase flow',
        'Mir Pay purchase flow, apply start Mir Pay purchase flow command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (91, 17, 75, 1, 'epay.gatewayadapter-topic',
        'Mir Pay purchase flow, gateway adapter info',
        'Mir Pay purchase flow, apply gateway adapter command')
ON CONFLICT DO NOTHING;

-- добавление flow для отмены оплаты Mir Pay

INSERT INTO flows (flow_id, name, description)
VALUES (18, 'Mir Pay refund flow', 'Standard Mir Pay refund flow')
ON CONFLICT DO NOTHING;

-- добавление flow_commands для отмены оплаты Mir Pay

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (76,
        'transaction != null && "NEW".equals(transaction.getStatus().getValue()) && "MIR_PAYMENT_WEB_BASED_REFUND".equals(transaction.getType().name())',
        'Mir Pay refund flow, refund check',
        'Mir Pay refund flow, refund check')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (77,
        'transaction != null && transaction.getRoute() != null && "MIR_PAYMENT_WEB_BASED_REFUND".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-gatewayadapter")',
        'Mir Pay refund flow, refund gateway adapter',
        'Mir Pay refund flow, refund gateway adapter')
ON CONFLICT DO NOTHING;

-- добавление flow_points для отмены оплаты Mir Pay

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (92, 18, 76, 0, 'epay.supervisor-topic',
        'Mir Pay refund flow',
        'Mir Pay refund flow, apply Mir Pay refund flow command')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (93, 18, 77, 1, 'epay.gatewayadapter-topic',
        'Mir Pay refund flow, gateway adapter info',
        'Mir Pay refund flow, apply gateway adapter command')
ON CONFLICT DO NOTHING;