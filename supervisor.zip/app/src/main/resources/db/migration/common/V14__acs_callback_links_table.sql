create table if not exists acs_callback_links
(
    link_id text primary key,
    transaction_id text not null,
    active bool default true not null
);

CREATE INDEX IF NOT EXISTS acs_callback_links_transaction_id_idx ON acs_callback_links(transaction_id);