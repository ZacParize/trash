DO $$
    DECLARE
        r record;
    BEGIN
        ALTER TABLE IF EXISTS transactions
        ADD COLUMN IF NOT EXISTS mst_ref text references merchant_sites (mst_id);

        ALTER TABLE IF EXISTS transactions
        DROP CONSTRAINT IF EXISTS transactions_mst_ref_mst_transaction_id_uq;

        ALTER TABLE IF EXISTS transactions
        ADD CONSTRAINT transactions_mst_ref_mst_transaction_id_uq UNIQUE (mst_ref, mst_transaction_id);

        FOR r IN (SELECT t.transaction_id, o.mst_ref FROM orders o JOIN transactions t ON o.order_id = t.order_ref) LOOP
            UPDATE transactions SET mst_ref = r.mst_ref WHERE transaction_id = r.transaction_id;
        END LOOP;

        ALTER TABLE IF EXISTS transactions ALTER COLUMN mst_ref SET NOT NULL;
END $$

