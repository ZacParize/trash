DROP TRIGGER IF EXISTS merchantgenerator on merchants;
DROP TRIGGER IF EXISTS merchantsiteregex on merchant_sites;
DROP FUNCTION IF EXISTS merchant_id;
DROP FUNCTION IF EXISTS merchant_site_regex;