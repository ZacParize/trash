DROP TRIGGER IF EXISTS merchantgenerator ON merchants;

DROP TRIGGER IF EXISTS merchantsiteregex ON merchant_sites;

ALTER TABLE IF EXISTS merchant_sites DROP CONSTRAINT IF EXISTS merchant_sites_login_idx;

ALTER TABLE IF EXISTS merchant_sites ADD COLUMN IF NOT EXISTS login text;

UPDATE merchant_sites SET login = mst_id WHERE login is null;

ALTER TABLE IF EXISTS merchant_sites ALTER COLUMN login SET NOT NULL;

CREATE INDEX IF NOT EXISTS merchant_sites_login_idx on merchant_sites (login);