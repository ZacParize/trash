CREATE OR REPLACE FUNCTION epay.merchant_id()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
    merchid varchar(100);
    rs boolean;
begin
	if (TG_OP='UPDATE' or TG_OP='INSERT') and new.merch_id is null  then
		merchid=(SELECT array_to_string(ARRAY(SELECT chr((48 + round(random() * 9)) :: integer) FROM generate_series(1,8)), ''));
		while (exists(select merch_id from epay.merchants where epay.merchants.merch_id=merchid)) loop
            begin
		    	merchid	=(SELECT array_to_string(ARRAY(SELECT chr((48 + round(random() * 9)) :: integer) FROM generate_series(1,8)), ''));
            end;
        end loop;
		new.merch_id=merchid;
    else
        merchid=new.merch_id;
        rs=(select exists(SELECT REGEXP_MATCHES(merchid, '^[0-9]\d{7}$', '')));
        if rs=false then
            RAISE EXCEPTION 'Merch_id must contains 8 numbers. Example 12345678';
        end if;
    end if;
return new;
end;
$function$;

CREATE OR REPLACE FUNCTION epay.merchant_site_regex()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
DECLARE
    mercsiteid varchar(100);
    rs boolean;
begin
	if TG_OP='INSERT' or TG_OP='UPDATE'  then
		mercsiteid=new.mst_id;
		rs=(select exists(SELECT REGEXP_MATCHES(mercsiteid, '^[0-9]\d{7}-[0-9]\d{3}$', '')));
		if rs=false then
			RAISE EXCEPTION 'Merchant site id must have pattern XXXXXXXX-XXXX, merchant id with site number. Example 12345678-0001';
        end if;
    end if;
    return new;
end;
$function$;

DROP TRIGGER IF EXISTS merchantgenerator on epay.merchants;
create trigger merchantgenerator before insert OR UPDATE on epay.merchants for each row execute function epay.merchant_id();
DROP TRIGGER IF EXISTS merchantsiteregex on epay.merchant_sites;
create trigger merchantsiteregex before insert OR UPDATE  on epay.merchant_sites for each row execute function epay.merchant_site_regex()

