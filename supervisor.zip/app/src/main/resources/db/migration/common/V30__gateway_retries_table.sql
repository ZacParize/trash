create table if not exists gateway_retries (
    retry_id bigserial constraint gateway_retries_pk primary key,
    transaction_id text not null,
    retry_count integer default 0,
    retry_type varchar(10) default 'STATUS',
    retry_state varchar(10) default 'WAITING',
    execution_time timestamp not null
);

create index if not exists gateway_retries_retry_state_execution_time_index on gateway_retries (retry_state, execution_time);

comment on table gateway_retries is 'Table for transaction reprocessing in gateway-adapter';
comment on column gateway_retries.retry_id is 'Record identify';
comment on column gateway_retries.transaction_id is 'Transaction for retry';
comment on column gateway_retries.retry_count is 'Number of attempts';
comment on column gateway_retries.retry_type is 'Request type';
comment on column gateway_retries.retry_state is 'Reproccessing state';
comment on column gateway_retries.execution_time is 'Next execution time';