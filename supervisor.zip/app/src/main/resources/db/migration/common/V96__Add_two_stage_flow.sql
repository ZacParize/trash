INSERT INTO flows (flow_id, name, mst_ref, description)
VALUES (14, 'Card payment two-stage', null, 'Card payment two-stage')
ON CONFLICT DO NOTHING;

INSERT INTO flow_commands (flow_command_id, command, name, description)
VALUES (57, 'transaction != null && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name())', 'Two-stage flow check', 'Two-stage flow check'),
       (58, 'transaction != null && transaction.getRoute() != null && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-cardinfo")', 'Two-stage card-info step', 'Two-stage card-info step'),
       (59, 'transaction != null && transaction.getContext() != null && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && transaction.getRoute() != null && !transaction.getRoute().isVisitedService("epay-gatewayadapter")', 'Two-stage gateway PREAUTH step', 'Two-stage gateway PREAUTH step'),
       (60, 'transaction != null && transaction.getRoute() != null && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && !transaction.getRoute().isVisitedService("epay-merchantplugin") && transaction.getRoute().isVisitedService("epay-gatewayadapter") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage callback step', 'Two-stage callback step'),
       (61, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && transaction.getRoute().getVisitedService("epay-cardinfo") < 2 && transaction.getRoute().isVisitedService("epay-merchantplugin") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage COMPLETE card-info step', 'Two-stage COMPLETE card-info step'),
       (62, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && transaction.getRoute().isVisitedService("epay-merchantplugin") && "AUTHORIZED".equals(transaction.getStatus().name())', 'Two-stage GW COMPLETE step', 'Two-stage GW COMPLETE step'),
       (63, 'transaction != null && transaction.getRoute() != null && "CONFIRM".equals(transaction.getGatewayOperation().name()) && "CARD_PAYMENT_TWO_STAGE".equals(transaction.getType().name()) && ("CONFIRMED".equals(transaction.getStatus().name()) || "DECLINED".equals(transaction.getStatus().name()))', 'Two-stage COMPLETE callback step', 'Two-stage COMPLETE callback step')
ON CONFLICT DO NOTHING;

INSERT INTO flow_points (flow_point_id, flow_ref, flow_command_ref, rank, point, name, description)
VALUES (70, 14, 57, 0, 'epay.supervisor-topic', 'Two-stage start flow', 'Two-stage start flow'),
       (71, 14, 58, 1, 'epay.cardinfo-topic', 'Two-stage initial card-info stage', 'Two-stage card data decrypt stage'),
       (72, 14, 59, 2, 'epay.gatewayadapter-topic', 'Two-stage PREAUTH command', 'Two-stage PREAUTH command'),
       (73, 14, 60, 3, 'epay.merchantplugin-topic', 'Two-stage PREAUTH callback', 'Two-stage PREAUTH callback'),
       (74, 14, 61, 4, 'epay.cardinfo-topic', 'Two-stage COMPLETE card-info stage', 'Two-stage COMPLETE card-info stage'),
       (75, 14, 62, 5, 'epay.gatewayadapter-topic', 'Two-stage COMPLETE command', 'Two-stage COMPLETE command request'),
       (76, 14, 63, 6, 'epay.merchantplugin-topic', 'Two-stage COMPLETE callback', 'Two-stage COMPLETE callback')
ON CONFLICT DO NOTHING;
