create table if not exists rules
(
    rule_id bigserial primary key,
    name varchar(512) not null,
    group_id varchar(256) not null,
    mst_ref text references merchant_sites(mst_id) not null,
    chn_ref bigint references channels(chn_id) not null
);

CREATE UNIQUE INDEX IF NOT EXISTS rules_name_idx ON rules(name);
CREATE INDEX IF NOT EXISTS rules_group_id_idx ON rules(group_id);
CREATE INDEX IF NOT EXISTS rules_mst_ref_idx ON rules(mst_ref);
CREATE INDEX IF NOT EXISTS rules_chn_ref_idx ON rules(chn_ref);

create table if not exists rule_contents
(
    rule_content_id bigserial primary key,
    rule_ref bigint references rules(rule_id) not null,
    name varchar(512) not null,
    weight numeric not null,
    value text not null
);

CREATE UNIQUE INDEX IF NOT EXISTS rule_contents_name_idx ON rule_contents (name);
CREATE INDEX IF NOT EXISTS rule_contents_rule_ref_idx ON rule_contents (rule_ref);