ALTER TABLE IF EXISTS transactions DROP CONSTRAINT IF EXISTS transactions_code_idx;

ALTER TABLE IF EXISTS transactions ADD COLUMN IF NOT EXISTS code text;

UPDATE transactions SET code = mst_transaction_id WHERE code IS NULL;

ALTER TABLE IF EXISTS transactions ALTER COLUMN code SET NOT NULL;

DROP INDEX IF EXISTS transactions_code_idx;

ALTER TABLE IF EXISTS transactions ADD CONSTRAINT transactions_code_idx UNIQUE (code);