ALTER TABLE IF EXISTS orders DROP CONSTRAINT IF EXISTS orders_code_idx;

ALTER TABLE IF EXISTS orders add column if not exists code text;

UPDATE orders SET code = mst_order_id WHERE code IS NULL;

ALTER TABLE IF EXISTS orders ALTER column code SET NOT NULL;

ALTER TABLE IF EXISTS orders DROP CONSTRAINT IF EXISTS orders_code_idx;

ALTER TABLE IF EXISTS orders ADD CONSTRAINT orders_code_idx UNIQUE (code);