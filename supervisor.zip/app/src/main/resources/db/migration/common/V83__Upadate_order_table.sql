ALTER TABLE IF EXISTS orders ADD COLUMN IF NOT EXISTS source_system varchar (256) not null default('ECOM');
