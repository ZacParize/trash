CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE OR REPLACE FUNCTION isValidUUID(text) RETURNS boolean AS
$$
DECLARE
    val ALIAS FOR $1;
    t uuid;
BEGIN
    t := val::uuid;
    RETURN true;
EXCEPTION
    WHEN OTHERS THEN RETURN false;
END
$$ LANGUAGE plpgsql;

do
$$
    DECLARE
        colType text;
        uid     text;
        r       record;
    BEGIN
        colType = (SELECT DATA_TYPE
                   FROM INFORMATION_SCHEMA.columns
                   where COLUMN_NAME = 'code'
                     and TABLE_NAME = 'transactions'
                     and TABLE_SCHEMA = (select current_schema()));
        IF colType = 'text' THEN
            FOR r IN (select transaction_id, code from transactions)
            LOOP
                IF NOT isValidUUID(r.code) THEN
                    uid = (select gen_random_uuid());
                    UPDATE transactions SET code = uid WHERE transaction_id = r.transaction_id;
                END IF;
            END LOOP;
            ALTER TABLE transactions ALTER COLUMN code TYPE uuid USING code::uuid;
        END IF;
        DROP FUNCTION IF EXISTS isValidUUID;
    END
$$ LANGUAGE plpgsql;