DO
$$
    DECLARE
        r record;
    BEGIN

        ALTER TABLE IF EXISTS merchants RENAME COLUMN merch_id TO id;
        ALTER TABLE IF EXISTS merchants
            ADD COLUMN IF NOT EXISTS "version" int8 NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS deleted bool NOT NULL DEFAULT false,
            ADD COLUMN IF NOT EXISTS created timestamp NOT NULL DEFAULT now(),
            ADD COLUMN IF NOT EXISTS modified timestamp NOT NULL DEFAULT now(),
            ADD COLUMN IF NOT EXISTS state text NOT NULL DEFAULT 'Active',
            ADD COLUMN IF NOT EXISTS entity jsonb;

        FOR r IN (
            select row_to_json(merchs) as merch
            from (
                     select m.id,
                            m.name,
                            m.state,
                            m.params,
                            to_char(m.created, 'YYYY-MM-DD HH24:MI:SS.MS')  as created,
                            to_char(m.modified, 'YYYY-MM-DD HH24:MI:SS.MS') as modified
                     from merchants m
                 ) as merchs
        )
            LOOP
                UPDATE
                    merchants m
                SET entity = (to_jsonb(r) ->> 'merch')::jsonb
                WHERE m.id = to_jsonb(r) -> 'merch' ->> 'id'
                AND m.entity is NULL;

            END LOOP;


        ALTER TABLE IF EXISTS merchants ALTER COLUMN entity SET NOT NULL;
    END
$$
