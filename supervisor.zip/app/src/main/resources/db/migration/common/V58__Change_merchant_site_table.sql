DO
$$
    DECLARE
        r record;
    BEGIN

        ALTER TABLE IF EXISTS merchant_sites RENAME COLUMN mst_id TO id;
        ALTER TABLE IF EXISTS merchant_sites
            ADD COLUMN IF NOT EXISTS "version" int8 NOT NULL DEFAULT 0,
            ADD COLUMN IF NOT EXISTS deleted bool NOT NULL DEFAULT false,
            ADD COLUMN IF NOT EXISTS created timestamp NOT NULL DEFAULT now(),
            ADD COLUMN IF NOT EXISTS modified timestamp NOT NULL DEFAULT now(),
            ADD COLUMN IF NOT EXISTS state text NOT NULL DEFAULT 'Active',
            ADD COLUMN IF NOT EXISTS entity jsonb;

        FOR r IN (
            SELECT
                row_to_json(mst) as site
            FROM
                (
                    SELECT
                        ms.id,
                        ms.url,
                        ms.merch_ref as "merchantId",
                        ms.name,
                        ms.login,
                        ms.params,
                        to_char(ms.created, 'YYYY-MM-DD HH24:MI:SS.MS') as created,
                        to_char(ms.modified, 'YYYY-MM-DD HH24:MI:SS.MS') as modified,
                        ms.state
                    FROM
                        merchant_sites ms
                ) as mst
        ) LOOP
                UPDATE merchant_sites ms
                SET entity = (to_jsonb(r) ->> 'site') :: jsonb
                WHERE ms.id = to_jsonb(r) -> 'site' ->> 'id'
                AND ms.entity is null;

            END LOOP;


        ALTER TABLE IF EXISTS merchant_sites
            ALTER COLUMN entity SET NOT NULL;
    END
$$
