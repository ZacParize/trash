create table if not exists qr_code_static
(
    id          bigserial primary key,
    qrc_id      varchar(100)            not null,
    payload     varchar(1000),
    q_state     varchar(100),
    q_reason    varchar(500),
    q_code      varchar(100),
    request_id  varchar(100),
    legal_id    varchar(50)             not null,
    order_id    varchar(100),
    account     varchar(50)             not null,
    currency    varchar(100),
    purpose     varchar(140),
    created_at  timestamp default now() not null,
    merchant_id varchar(256)            not null,
    amount      numeric                 not null
);

create unique index if not exists qr_code_static_qrc_id_idx on qr_code_static (qrc_id);

create index if not exists qr_code_static_merchant_id_idx on qr_code_static (merchant_id);

grant select, update, usage on sequence qr_code_static_id_seq to epay_user;

grant delete, insert, references, select, trigger, truncate, update on qr_code_static to epay_user;