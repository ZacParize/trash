package ru.vtb.tsp.ia.epay.supervisor.exceptions;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = Shape.STRING)
public enum ApplicationException {

  INCORRECT_JEXL_PARAMETERS_EXCEPTION("10100001", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "INCORRECT_JEXL_PARAMETERS_EXCEPTION", "Внутренняя ошибка при обработке транзакции"),
  INCORRECT_JEXL_SCRIPT_EXCEPTION("10100002", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "INCORRECT_JEXL_SCRIPT_EXCEPTION", "Внутренняя ошибка при обработке транзакции"),
  ROUTE_LOOP_EXCEPTION("10100003", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "ROUTE_LOOP_EXCEPTION", "Внутренняя ошибка при обработке транзакции"),
  INCORRECT_ROUTE_EXCEPTION("10100004", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "INCORRECT_ROUTE_EXCEPTION", "Внутренняя ошибка при обработке транзакции"),
  EMPTY_ROUTE_EXCEPTION("10100005", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "EMPTY_ROUTE_EXCEPTION", "Внутренняя ошибка при обработке транзакции"),
  DATA_ACCESS_EXCEPTION("10100006", HttpStatus.INTERNAL_SERVER_ERROR.value(),
          "DATA_ACCESS_EXCEPTION", "Внутренняя ошибка при обработке транзакции");

  private final String id;
  private final Integer httpCode;
  private final String message;
  private final String description;

}