package ru.vtb.tsp.ia.epay.supervisor.configs;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.postgresql.util.PGobject;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.jdbc.core.convert.JdbcCustomConversions;
import org.springframework.data.jdbc.repository.config.AbstractJdbcConfiguration;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import ru.vtb.tsp.ia.epay.core.domains.JsonObject;
import ru.vtb.tsp.ia.epay.core.domains.merchant.MerchantParams;
import ru.vtb.tsp.ia.epay.core.domains.merchant.site.MerchantSiteParams;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.cardinfo.PublicKeyData;
import ru.vtb.tsp.ia.epay.core.entities.standin.StandInParamValue;


@Slf4j
@Configuration
@RequiredArgsConstructor
@EnableJdbcRepositories(basePackages = {"ru.vtb.tsp.ia.epay"})
public class PostgresConfig extends AbstractJdbcConfiguration {

  private final ObjectMapper objectMapper;

  @Bean
  @Override
  public JdbcCustomConversions jdbcCustomConversions() {
    return new JdbcCustomConversions(List.of(
        new PGobjectToStringConverter(),
        new PGobjectToTransactionPayloadConverter(objectMapper),
        new JsonObjectToStringConverter(objectMapper),
        new PGobjectToMerchantSiteParamsConverter(objectMapper),
        new PGobjectToMerchantParamsConverter(objectMapper),
        new PGobjectToTokenizationPublicKeyConverter(objectMapper),
        new PGobjectToStandInParamValueConverter(objectMapper)
    ));
  }

  @ReadingConverter
  static class PGobjectToStringConverter implements Converter<PGobject, String> {

    @Override
    public String convert(PGobject source) {
      return source.getValue();
    }
  }

  @ReadingConverter
  @RequiredArgsConstructor
  static class PGobjectToStandInParamValueConverter implements Converter<PGobject, StandInParamValue> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public StandInParamValue convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), StandInParamValue.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize stand in param value", e);
        return null;
      }
    }
  }

  @ReadingConverter
  @RequiredArgsConstructor
  static class PGobjectToTransactionPayloadConverter implements
      Converter<PGobject, TransactionPayload> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public TransactionPayload convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), TransactionPayload.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize transaction payload", e);
        return null;
      }
    }
  }

  @WritingConverter
  @RequiredArgsConstructor
  static class JsonObjectToStringConverter implements Converter<JsonObject, String> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public String convert(@NotNull JsonObject source) {
      try {
        return objectMapper.writeValueAsString(source);
      } catch (JsonProcessingException e) {
        log.error("Can not serialize instance of class {}", source.getClass().getSimpleName(), e);
        return null;
      }
    }
  }

  @RequiredArgsConstructor
  static class PGobjectToMerchantSiteParamsConverter implements
      Converter<PGobject, MerchantSiteParams> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public MerchantSiteParams convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), MerchantSiteParams.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize merchant site params {}", source.getValue(), e);
        return null;
      }
    }
  }

  @ReadingConverter
  @RequiredArgsConstructor
  static class PGobjectToMerchantParamsConverter implements Converter<PGobject, MerchantParams> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public MerchantParams convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), MerchantParams.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize merchant site params {}", source.getValue(), e);
        return null;
      }
    }
  }

  @ReadingConverter
  @RequiredArgsConstructor
  static class PGobjectToTokenizationPublicKeyConverter implements
      Converter<PGobject, PublicKeyData> {

    @NotNull
    private final ObjectMapper objectMapper;

    @Override
    public PublicKeyData convert(@NotNull PGobject source) {
      try {
        return objectMapper.readValue(source.getValue(), PublicKeyData.class);
      } catch (JsonProcessingException e) {
        log.error("Can not deserialize transaction payload", e);
        return null;
      }
    }
  }
}