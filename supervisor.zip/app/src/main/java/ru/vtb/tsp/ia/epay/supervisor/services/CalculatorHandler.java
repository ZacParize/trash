package ru.vtb.tsp.ia.epay.supervisor.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.jexl3.JexlBuilder;
import org.apache.commons.jexl3.JexlException;
import org.apache.commons.jexl3.MapContext;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.core.domains.transaction.Route;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowCommand;
import ru.vtb.tsp.ia.epay.core.entities.route.FlowPoint;
import ru.vtb.tsp.ia.epay.core.repositories.FlowCommandRepository;
import ru.vtb.tsp.ia.epay.core.repositories.FlowPointRepository;
import ru.vtb.tsp.ia.epay.core.repositories.FlowRepository;
import ru.vtb.tsp.ia.epay.supervisor.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.supervisor.exceptions.ServiceException;

@Slf4j
@Service
public class CalculatorHandler {

    private static final int CACHE_SIZE = 128;
    private final Map<Long, FlowCommand> flowCommandsByFlowId = new HashMap<>();
    private final Map<Long, List<FlowPoint>> flowPointsByFlowId = new HashMap<>();

    public CalculatorHandler(FlowCommandRepository flowCommandRepository,
                             FlowPointRepository flowPointRepository,
                             FlowRepository flowRepository) {
        flowRepository.findAll().forEach(flow -> {
            flowPointsByFlowId.put(flow.getFlowId(), flowPointRepository.findByFlow(flow.getFlowId()));
            flowCommandRepository.findFirstCommandsInEachFlow(flow.getFlowId())
                    .ifPresent(flowCommand -> flowCommandsByFlowId.put(flow.getFlowId(),
                            flowCommand));
        });
    }

    public @NotNull Optional<TransactionPayload> calculate(@Nullable TransactionPayload transactionPayload) {
        return Optional.ofNullable(transactionPayload)
                .map(tp -> {
                    // check transaction route completed
                    if (tp.isRouteCompleted()) {
                        return Optional.<TransactionPayload>empty();
                    }

                    // check transaction route loop
                    if (tp.isRouteLoopExists()) {
                        log.error("Transaction with id {} code {} route loop was detected",
                                tp.getTransactionId(), tp.getTransactionCode());
                        throw new ServiceException(ApplicationException.ROUTE_LOOP_EXCEPTION, tp);
                    }

                    // calculate route
                    log.info("Calculate next transaction id {}, code {} route point", tp.getTransactionId(),
                            tp.getTransactionCode());
                    if (Objects.isNull(tp.getRoute()) || ObjectUtils.isEmpty(tp.getRoute().getFlowPoints())) {
                        final var flowId = flowCommandsByFlowId.entrySet().stream()
                                .filter(entry -> execute(entry.getValue().getCommand(), tp))
                                .map(Entry::getKey)
                                .findFirst()
                                .orElse(null);

                        if (Objects.isNull(flowId)) {
                            log.error("Can't build transaction id {} route, couldn't find flow",
                                    tp.getTransactionId());
                            throw new ServiceException(ApplicationException.EMPTY_ROUTE_EXCEPTION, tp);
                        } else {
                            tp.setRoute(new Route(1, flowPointsByFlowId.get(flowId), new HashMap<>()));
                        }
                    }

                    // calculate next route point
                    int routesSize = tp.getRoute().getFlowPoints().size();
                    int currentPoint = tp.getRoute().getCurrentPoint();
                    FlowCommand currentFlowCommand;
                    boolean isMovedToNextPoint = false;
                    for (int idx = currentPoint; idx < routesSize; idx++) {
                        currentFlowCommand = tp.getRoute().getFlowPoints().get(idx).getFlowCommand();
                        if (Objects.nonNull(currentFlowCommand) && execute(currentFlowCommand.getCommand(),
                                tp)) {
                            tp.getRoute().setCurrentPoint(idx);
                            isMovedToNextPoint = true;
                            break;
                        }
                    }

                    // can't find next route point, hold on
                    if (!isMovedToNextPoint) {
                        log.info("Transaction id {} stopped along the route {}",
                            tp.getTransactionId(), tp.getRoute());
                        return Optional.<TransactionPayload>empty();
                    }

                    return Optional.of(tp);
                })
                .orElse(Optional.empty());
    }

    private boolean execute(@Nullable String command, @NotNull TransactionPayload payload) {
        return Optional.ofNullable(command)
                .map(cmnd -> {
                    final var jexlScript = new JexlBuilder().cache(CACHE_SIZE)
                            .strict(true).silent(false).create().createScript(cmnd);
                    try {
                        final var variables = jexlScript.getVariables().iterator().next();
                        if (variables.size() != 1) {
                            log.error("Incorrect JEXL script {}", jexlScript);
                            throw new ServiceException(ApplicationException.INCORRECT_JEXL_PARAMETERS_EXCEPTION, payload);
                        }
                        final var jexlContext = new MapContext();
                        jexlContext.set(variables.iterator().next(), payload);
                        return (boolean) jexlScript.execute(jexlContext);
                    } catch (JexlException ex) {
                        log.error("Can't calculate JEXL expression {}", jexlScript, ex);
                        throw new ServiceException(ApplicationException.INCORRECT_JEXL_SCRIPT_EXCEPTION, payload);
                    }
                })
                .orElse(false);
    }

}