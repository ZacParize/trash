package ru.vtb.tsp.ia.epay.supervisor.exceptions;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

@RequiredArgsConstructor
public class ServiceException extends RuntimeException {

  private final ApplicationException exception;
  private final TransactionPayload payload;

  public TransactionPayload getPayload() {
    return payload;
  }

  public String getId() {
    return Optional.ofNullable(exception).map(ApplicationException::getId).orElse(null);
  }

  public Integer getHttpCode() {
    return Optional.ofNullable(exception).map(ApplicationException::getHttpCode).orElse(null);
  }

  public String getMessage() {
    return Optional.ofNullable(exception).map(ApplicationException::getMessage).orElse(null);
  }

  public String getDescription() {
    return Optional.ofNullable(exception).map(ApplicationException::getDescription).orElse(null);
  }

}