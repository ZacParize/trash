package ru.vtb.tsp.ia.epay.supervisor;

import java.util.Arrays;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import ru.vtb.tsp.ia.epay.supervisor.configs.IsStandInMigration;

@SpringBootApplication
@Slf4j
public class App implements CommandLineRunner {

    @Autowired
    private ApplicationContext context;

    public static void main(String[] args) throws Exception {
        SpringApplication.run(App.class, args);
    }

    @Override
    public void run(String... args) {
        System.out.println(context);
        // TODO: print all settings
       if (Arrays.asList(context.getEnvironment().getActiveProfiles()).contains(
            IsStandInMigration.STANDIN)){
           log.info("StandIn db service completed. Application shutting down");
            ((ConfigurableApplicationContext) context).close();
        }
    }

}