package ru.vtb.tsp.ia.epay.supervisor.services;

import static ru.vtb.tsp.ia.epay.supervisor.configs.KafkaProducerConfig.KAFKA_BOX_TEMPLATE;
import static ru.vtb.tsp.ia.epay.supervisor.configs.KafkaProducerConfig.KAFKA_PORTAL_TEMPLATE;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Conditional;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.core.domains.kafka.payloads.FiscalizationTask;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.portal.domains.transaction.TransactionCallback;
import ru.vtb.tsp.ia.epay.supervisor.configs.IsStandInMigration;

@Slf4j
@Service
@Conditional(IsStandInMigration.class)
public class KafkaService {

  private final KafkaTemplate<String, Object> kafkaBoxTemplate;
  private final KafkaTemplate<String, Object> kafkaPortalTemplate;
  private final List<String> transactionTopics;
  private final List<String> fiscalTopics;
  private final List<String> dlqTopics;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForBox;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForPortalTransactions;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForDlq;

  public KafkaService(@Qualifier(KAFKA_BOX_TEMPLATE) KafkaTemplate<String, Object> kafkaBoxTemplate,
      @Qualifier(KAFKA_PORTAL_TEMPLATE) KafkaTemplate<String, Object> kafkaPortalTemplate,
      @Value("${app.kafka.callback.transaction-topics}") List<String> transactionTopics,
      @Value("${app.kafka.fiscal-topics}") List<String> fiscalTopics,
      @Value("${app.kafka.dlq-topics}") @NotEmpty List<String> dlqTopics) {
    this.kafkaBoxTemplate = kafkaBoxTemplate;
    this.kafkaPortalTemplate = kafkaPortalTemplate;
    this.transactionTopics = Objects.requireNonNullElse(transactionTopics, Collections.emptyList());
    this.fiscalTopics = Objects.requireNonNullElse(fiscalTopics, Collections.emptyList());
    this.dlqTopics = Objects.requireNonNullElse(dlqTopics, Collections.emptyList());
    this.callbackFactoryForBox = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is processed with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to next route point {}", key, topic, ex);
      }
    };
    this.callbackFactoryForPortalTransactions = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is sent to portal with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to portal {}", key, topic, ex);
      }
    };
    this.callbackFactoryForDlq = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Message {} is sent to dlq with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending message {} to portal {}", key, topic, ex);
      }
    };
  }

  public void sendFiscalTask(@Nullable FiscalizationTask task) {
    Optional.ofNullable(task)
        .ifPresent(payload -> send(null, payload, payload.getTransactionCode().toString()));
  }

  public void sendTransactionToPortal(@Nullable TransactionPayload transaction) {
    Optional.ofNullable(transaction)
        .ifPresent(tx -> send(null, TransactionCallback.map(tx).orElse(null),
            tx.getTransactionId()));
  }

  public void sendToBox(@Nullable List<String> topics,
      @Nullable TransactionPayload payload) {
    Optional.ofNullable(payload).ifPresent(tx -> send(topics, tx, tx.getTransactionId()));
  }

  public void sendToDlq(@Nullable Object message) {
    Optional.ofNullable(message)
        .ifPresent(tx -> send(dlqTopics, message, message.toString()));
  }

  private void send(@Nullable List<String> outputTopics,
      @Nullable Object payload,
      @Nullable String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final KafkaTemplate<String, Object> kafkaTemplate;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    if (payload instanceof TransactionPayload) {
      topics = Objects.requireNonNullElse(outputTopics, Collections.emptyList());
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForBox;
    } else if (payload instanceof TransactionCallback) {
      topics = transactionTopics;
      kafkaTemplate = kafkaPortalTemplate;
      callback = callbackFactoryForPortalTransactions;
    } else if (payload instanceof FiscalizationTask) {
      topics = fiscalTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForBox;
    } else {
      topics = outputTopics;
      kafkaTemplate = kafkaBoxTemplate;
      callback = callbackFactoryForDlq;
    }
    Objects.requireNonNull(topics).forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
          .addCallback(callback.apply(topic, key));
    });
  }

}