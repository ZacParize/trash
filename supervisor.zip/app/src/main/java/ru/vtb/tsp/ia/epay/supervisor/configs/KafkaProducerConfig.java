package ru.vtb.tsp.ia.epay.supervisor.configs;

import java.util.List;
import javax.validation.constraints.NotEmpty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.vtb.tsp.ia.epay.core.configurations.KafkaConfiguration;

@Slf4j
@Configuration
@Conditional(IsStandInMigration.class)
public class KafkaProducerConfig {

  public static final String KAFKA_BOX_TEMPLATE = "kafkaBoxTemplate";
  public static final String KAFKA_PORTAL_TEMPLATE = "kafkaPortalTemplate";

  @Value("${spring.kafka.bootstrap-servers}")
  @NotEmpty
  private List<String> bootstrapServers;

  @Value("${app.kafka.callback.transaction-topics}")
  @NotEmpty
  private List<String> transactionTopics;

  @Value("${app.kafka.partitions-count}")
  private int partitionsCount;

  @Value("${app.kafka.replicas-count}")
  private int replicasCount;

  @Value("${spring.kafka.producer.ssl.protocol:#{null}}")
  private String sslProtocol;

  @Value("${spring.kafka.producer.ssl.trust-store-type:#{null}}")
  private String sslTrustStoreType;

  @Value("${spring.kafka.producer.ssl.trust-store-location:#{null}}")
  private String sslTrustStoreLocation;

  @Value("${spring.kafka.producer.ssl.trust-store-password:#{null}}")
  private String sslTrustStorePassword;

  @Value("${spring.kafka.producer.ssl.key-store-type:#{null}}")
  private String sslKeyStoreType;

  @Value("${spring.kafka.producer.ssl.key-store-location:#{null}}")
  private String sslKeyStoreLocation;

  @Value("${spring.kafka.producer.ssl.key-store-password:#{null}}")
  private String sslKeyStorePassword;

  @Value("${spring.kafka.producer.ssl.key-password:#{null}}")
  private String sslKeyPassword;

  @Bean
  public ProducerFactory<String, ?> producerFactory() {
    final var configuration = KafkaConfiguration.producerConfig(bootstrapServers,
        sslProtocol,
        sslTrustStoreType,
        sslTrustStoreLocation,
        sslTrustStorePassword,
        sslKeyStoreType,
        sslKeyStoreLocation,
        sslKeyStorePassword,
        sslKeyPassword);
    KafkaConfiguration.createTopics(configuration, transactionTopics, partitionsCount,
        replicasCount);
    return new DefaultKafkaProducerFactory<>(configuration);
  }

  @Bean(KAFKA_BOX_TEMPLATE)
  public KafkaTemplate<String, ?> kafkaBoxTemplate(ProducerFactory<String, ?> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

  @Bean(KAFKA_PORTAL_TEMPLATE)
  public KafkaTemplate<String, ?> kafkaPortalTemplate(
      ProducerFactory<String, ?> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

}