package ru.vtb.tsp.ia.epay.supervisor.configs.converters;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import java.io.IOException;
import java.sql.Timestamp;

public class PgTimeStampSerializer extends JsonSerializer<Timestamp> implements
    ContextualSerializer {


  @Override
  public void serialize(Timestamp timestamp, JsonGenerator jsonGenerator,
      SerializerProvider serializerProvider) throws IOException {
    jsonGenerator.writeString(timestamp.toLocalDateTime().toString());
  }

  @Override
  public JsonSerializer<?> createContextual(SerializerProvider serializerProvider,
      BeanProperty beanProperty) throws JsonMappingException {
    return new PgTimeStampSerializer();
  }
}
