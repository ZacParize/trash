package ru.vtb.tsp.ia.epay.supervisor.services;

import java.util.Objects;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.supervisor.exceptions.ServiceException;

@Component
@RequiredArgsConstructor
public class ExceptionHandler {

    private final TransactionService transactionService;

    @Transactional
    public void handle(@Nullable ServiceException exception,
                       @Nullable String traceId) {
        if (Objects.isNull(exception) || Objects.isNull(exception.getPayload())) {
            return;
        }
        transactionService.lockById(exception.getPayload().getTransactionId())
                .filter(tx -> !tx.isCompleted())
                .ifPresent(tx -> {
                    final var payload = exception.getPayload();
                    payload.setError(TransactionError.builder()
                            .id(tx.getTransactionId())
                            .httpCode(exception.getHttpCode())
                            .message(exception.getMessage())
                            .description(exception.getDescription())
                            .traceId(traceId)
                            .build());
                    payload.setStatus(TransactionState.DECLINED);
                    transactionService.updateDataById(tx.getTransactionId(), payload);
                });
    }

}