package ru.vtb.tsp.ia.epay.supervisor.services;

import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.order.Order;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.Transaction;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderStateMachine {

  private final OrderStateCounterMonitoringService monitoringService;
  private final OrderService orderService;
  private final TransactionService transactionService;

  @Transactional
  public @Nullable TransactionPayload compareAndSet(
      @Nullable TransactionPayload transactionPayload) {
    return Optional.ofNullable(transactionPayload)
        .filter(tp -> Objects.nonNull(tp.getOrderInfo()))
        .map(tp -> {
          //TRANSFER
          if (tp.getOrderInfo().isTransfer()) {
            if (tp.isConfirmed() || tp.isDeclined()) {
              orderService.lockById(tp.getOrderInfo().getOrderId())
                  .filter(order -> !order.isDeclined() && !order.isPaid())
                  .ifPresent(order -> {
                    final var oldState = order.getState();
                    OrderState newState = oldState;
                    if (tp.isConfirmed()) {
                      newState = OrderState.PAID;
                    } else if (tp.isDeclined()) {
                      newState = OrderState.DECLINED;
                    }
                    if (!newState.equals(oldState)) {
                      log.info("Move order id {} state from {} to {}", order.getOrderId(),
                          oldState, newState);
                      orderService.upsert(order.withState(newState));
                      monitoringService.incrementCounter(newState.getValue());
                    }
                  });
            }
            //PAYMENT (REFUND)
          } else if (tp.getOrderInfo().isPayment()) {
            if (TransactionType.COF_PAYMENT.equals(tp.getType())
                && TransactionState.isDeclined(tp.getStatus())) {
              orderService.lockById(tp.getOrderInfo().getOrderId())
                  .filter(order -> !order.isDeclined() && !order.isExpired() && !order.isCanceled())
                  .ifPresent(order -> {
                    final var oldState = order.getState();
                    final var newState = OrderState.CANCELED;
                    log.info("Move order id {} state from {} to {}", order.getOrderId(),
                        oldState, newState);
                    orderService.upsert(order.withState(newState));
                    monitoringService.incrementCounter(newState.getValue());
                  });
            } else {
              orderService.lockById(tp.getOrderInfo().getOrderId())
                  .filter(order -> !order.isDeclined() && !order.isExpired() && !order.isCanceled())
                  .ifPresent(order -> {
                    final var transactions = transactionService
                        .getByOrderId(order.getOrderId());
                    final var oldState = order.getState();
                    var newState = oldState;
                    final var refundedAmount = Order.calculateRefundedAmount(transactions);
                    //REFUND
                    if (refundedAmount > 0d) {
                      if (order.isPaid() || order.isPartiallyRefunded()) {
                        newState = refundedAmount == order.getAmount()
                            ? OrderState.REFUNDED : OrderState.PARTIALLY_REFUNDED;
                      }
                    } else {
                      //PAYMENT
                      final var payedAmount = Order.calculatePayedAmount(transactions);
                      if (payedAmount > 0d && (order.isCreated() || order.isPartiallyPaid())) {
                        newState = payedAmount == order.getAmount()
                            ? OrderState.PAID : OrderState.PARTIALLY_PAID;
                      }
                    }
                    if (!newState.equals(oldState)) {
                      log.info("Move order id {} state from {} to {}", order.getOrderId(),
                          oldState, newState);
                      orderService.upsert(order.withState(newState));
                      monitoringService.incrementCounter(newState.getValue());
                    }
                  });
            }
            //TWO STAGE
          } else if (tp.getOrderInfo().isTwoStage()) {
            orderService.lockById(tp.getOrderInfo().getOrderId())
                .filter(order -> !order.isDeclined() && !order.isExpired() && !order.isCanceled())
                .ifPresent(order -> {
                  final var oldState = order.getState();
                  var newState = oldState;
                  final var transactions = transactionService
                      .getByOrderId(order.getOrderId());
                  //REVERSE
                  var tempAmount = Order.calculateReversedAmount(transactions);
                  if (tempAmount > 0) {
                    if (order.isPending()) {
                      newState = OrderState.VOIDED;
                    }
                  } else {
                    //REFUND
                    tempAmount = Order.calculateRefundedAmount(transactions);
                    if (tempAmount > 0d) {
                      if (order.isPaid() || order.isPartiallyRefunded()) {
                        newState = tempAmount == order.getAmount()
                            ? OrderState.REFUNDED : OrderState.PARTIALLY_REFUNDED;
                      }
                    } else {
                      //AUTHORIZED
                      tempAmount = Order.calculateAuthorizedAmount(transactions);
                      if (tempAmount > 0) {
                        if (order.isCreated()) {
                          newState = OrderState.PENDING;
                        }
                      } else {
                        //PAYMENT
                        tempAmount = Order.calculatePayedAmount(transactions);
                        if (tempAmount > 0 && (order.isCreated() || order.isPending())) {
                          newState = OrderState.PAID;
                        }
                      }
                    }
                  }
                  if (!newState.equals(oldState)) {
                    order = order.withState(newState);
                    //when complete transaction check if order amount != transaction amount
                    if (newState == OrderState.PAID && !order.getAmount().equals(tempAmount)) {
                      order = order.withAmount(tempAmount);
                    }
                    log.info("Move order id {} state from {} to {}", order.getOrderId(),
                        oldState, newState);
                    orderService.upsert(order);
                    monitoringService.incrementCounter(newState.getValue());
                  }
                });
          }
          return transactionService.getById(tp.getTransactionId())
              .map(Transaction::getData)
              .orElse(tp);
        }).orElse(transactionPayload);
  }

}