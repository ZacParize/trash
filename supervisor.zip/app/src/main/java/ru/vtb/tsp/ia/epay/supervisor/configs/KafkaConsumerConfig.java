package ru.vtb.tsp.ia.epay.supervisor.configs;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.validation.constraints.NotEmpty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import ru.vtb.tsp.ia.epay.core.configurations.KafkaConfiguration;

@Slf4j
@Configuration
@Conditional(IsStandInMigration.class)
public class KafkaConsumerConfig {

  private static final int CONSUMER_CONCURRENCY = 3;

  @Value("${spring.kafka.bootstrap-servers}")
  @NotEmpty
  private List<String> bootstrapServers;

  @Value("${spring.kafka.consumer.group-id}")
  @NotEmpty
  private String groupId;

  @Value("${app.kafka.consumer.topics}")
  @NotEmpty
  private List<String> consumerTopics;

  @Value("${app.kafka.dlq-topics}")
  @NotEmpty
  private List<String> dlqTopics;

  @Value("${app.kafka.partitions-count}")
  private int partitionsCount;

  @Value("${app.kafka.replicas-count}")
  private int replicasCount;

  @Value("${spring.kafka.consumer.ssl.protocol:#{null}}")
  private String sslProtocol;

  @Value("${spring.kafka.consumer.ssl.trust-store-type:#{null}}")
  private String sslTrustStoreType;

  @Value("${spring.kafka.consumer.ssl.trust-store-location:#{null}}")
  private String sslTrustStoreLocation;

  @Value("${spring.kafka.consumer.ssl.trust-store-password:#{null}}")
  private String sslTrustStorePassword;

  @Value("${spring.kafka.consumer.ssl.key-store-type:#{null}}")
  private String sslKeyStoreType;

  @Value("${spring.kafka.consumer.ssl.key-store-location:#{null}}")
  private String sslKeyStoreLocation;

  @Value("${spring.kafka.consumer.ssl.key-store-password:#{null}}")
  private String sslKeyStorePassword;

  @Value("${spring.kafka.consumer.ssl.key-password:#{null}}")
  private String sslKeyPassword;

  /*@Bean
  public KafkaTransactionManager<String, ?> kafkaTransactionManager(ProducerFactory<String, ?> producerFactory) {
      final var kafkaTransactionManager = new KafkaTransactionManager<>(producerFactory);
      kafkaTransactionManager.setTransactionSynchronization(AbstractPlatformTransactionManager.SYNCHRONIZATION_ALWAYS);
      kafkaTransactionManager.setRollbackOnCommitFailure(true);
      return kafkaTransactionManager;
  }*/

  @Bean
  public ConsumerFactory<String, ?> kafkaConsumerFactory() {
    final var configuration = KafkaConfiguration.consumerConfig(bootstrapServers,
                                                                                  groupId,
                                                                                  sslProtocol,
                                                                                  sslTrustStoreType,
                                                                                  sslTrustStoreLocation,
                                                                                  sslTrustStorePassword,
                                                                                  sslKeyStoreType,
                                                                                  sslKeyStoreLocation,
                                                                                  sslKeyStorePassword,
                                                                                  sslKeyPassword);
    final var topics = Stream.concat(consumerTopics.stream(), dlqTopics.stream())
        .collect(Collectors.toList());
    KafkaConfiguration.createTopics(configuration, topics, partitionsCount, replicasCount);
    return new DefaultKafkaConsumerFactory<>(configuration);
  }

  @Bean
  public ConcurrentKafkaListenerContainerFactory<String, ?> kafkaListenerContainerFactory(
      ConsumerFactory<String, Object> kafkaConsumerFactory) {
    //KafkaTransactionManager<String, ?> kafkaTransactionManager) {
    final var factory = new ConcurrentKafkaListenerContainerFactory<String, Object>();
    factory.setConsumerFactory(kafkaConsumerFactory);
    factory.setBatchListener(false);
    factory.setConcurrency(CONSUMER_CONCURRENCY);
    factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL);
    //factory.getContainerProperties().setTransactionManager(kafkaTransactionManager);
    return factory;
  }

}