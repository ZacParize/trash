package ru.vtb.tsp.ia.epay.supervisor.services;

import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Conditional;
import org.springframework.dao.DataAccessException;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import ru.vtb.smartreplication.core.exception.SmartReplicationException;
import ru.vtb.tsp.ia.epay.core.domains.enums.FiscalOperationType;
import ru.vtb.tsp.ia.epay.core.domains.kafka.payloads.FiscalizationTask;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.supervisor.configs.IsStandInMigration;
import ru.vtb.tsp.ia.epay.supervisor.exceptions.ApplicationException;
import ru.vtb.tsp.ia.epay.supervisor.exceptions.ServiceException;

@Slf4j
@Component
@RequiredArgsConstructor
@Conditional(IsStandInMigration.class)
public class ProcessorService implements GenericTransformer<Object, TransactionPayload> {

  private static final long TIMEOUT = 1000;

  private final CalculatorHandler calculatorHandler;
  private final KafkaService kafkaService;
  private final TransactionService transactionService;
  private final MessageAdapter messageAdapter;
  private final ExceptionHandler exceptionHandler;
  private final OrderStateMachine orderStateMachine;

  @Override
  public @Nullable
  TransactionPayload transform(@Nullable Object source) {
    return Optional.ofNullable(messageAdapter.deserialize(source))
        .orElseGet(() -> {
          kafkaService.sendToDlq(source);
          return null;
        });
  }

  //@Transactional(transactionManager = "transactionManager")
  @KafkaListener(topics = "${app.kafka.consumer.topics}", containerFactory = "kafkaListenerContainerFactory")
  public void process(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    boolean nack = false;
    final var transaction = transform(record.value());
    try {
      Optional.ofNullable(transaction)
          // update connected transaction
          .map(tp -> {
            Optional.ofNullable(tp.getConnectedTransaction())
                .filter(connectedTx -> Objects.nonNull(connectedTx.getTransactionId())
                    && Objects.nonNull(connectedTx.getState()))
                .ifPresent(connectedTx ->
                    transactionService.getById(connectedTx.getTransactionId())
                        .filter(cTx -> !cTx.getState().equals(connectedTx.getState()))
                        .ifPresent(cTx -> {
                          cTx.getData().setStatus(connectedTx.getState());
                          transactionService.updateDataById(cTx.getTransactionId(), cTx.getData());
                          // send transaction to portal
                          kafkaService.sendTransactionToPortal(cTx.getData());
                        }));
            return tp;
          })
          // update current transaction
          .map(tp -> {
            transactionService.updateDataById(tp.getTransactionId(), tp);
            return tp;
          })
          .map(orderStateMachine::compareAndSet)
          .map(tp -> {
            if (tp.isRouteCompleted() && (tp.isFiscalPayment() || tp.isFiscalRefund())) {
              log.info("Sending transaction id {}, transaction state {} with order id {}, order "
                      + "state {} to fiscalization",
                  tp.getTransactionId(),
                  tp.getStatus().getValue(),
                  tp.getOrderInfo().getOrderId(),
                  tp.getOrderInfo().getOrderState().getValue());
              final var taskBuilder = FiscalizationTask.builder()
                  .type("receipt")
                  .transactionCode(UUID.fromString(tp.getTransactionCode()))
                  .orderCode(UUID.fromString(tp.getOrderInfo().getOrderCode()))
                  .mstId(tp.getMerchant().getMstId());
              if (tp.isFiscalPayment()) {
                log.info("Register INCOME fiscal task, transaction id {}", tp.getTransactionId());
                taskBuilder.operationType(FiscalOperationType.INCOME);
              } else if (tp.isFiscalRefund() && tp.getOrderInfo().isPayment()) {
                log.info("Register INCOME_RETURN fiscal task, transaction id {}",
                    tp.getTransactionId());
                taskBuilder.operationType(FiscalOperationType.INCOME_RETURN);
              }
              kafkaService.sendFiscalTask(taskBuilder.build());
            }
            return tp;
          })
          .filter(tp -> !tp.isRouteCompleted())
          .flatMap(calculatorHandler::calculate)
          .flatMap(transactionService::updateTransactionFlow)
          .ifPresent(tp -> {
            // send transaction to next route point
            kafkaService.sendToBox(Collections.singletonList(
                Objects.requireNonNullElseGet(tp.getRoute().getNextPoint(),
                    () -> {
                      throw new ServiceException(ApplicationException.INCORRECT_ROUTE_EXCEPTION,
                          tp);
                    })), tp);
            // send transaction to portal
            if (tp.isAcceptableForStreaming()) {
              log.info("Sending transaction id {}, transaction state {} with order id {}, order "
                      + "state {} to portal",
                  tp.getTransactionId(),
                  tp.getStatus().getValue(),
                  tp.getOrderInfo().getOrderId(),
                  tp.getOrderInfo().getOrderState().getValue());
              kafkaService.sendTransactionToPortal(tp);
            }
          });
    } catch (DataAccessException | SmartReplicationException ex) {
      nack = true;
      if (ex instanceof DataAccessException) {
        log.error("Failed connect to database", ex);
      } else if (ex instanceof SmartReplicationException) {
        log.error("Smart replication exception", ex);
      }
    } catch (ServiceException ex) {
      exceptionHandler.handle(ex, ex.getPayload().getTransactionCode());
    } catch (Exception ex) {
      kafkaService.sendToDlq(record.value());
      log.error("Transaction can't be processed", ex);
    } finally {
      if (!nack) {
        acknowledgment.acknowledge();
      } else {
        acknowledgment.nack(TIMEOUT);
      }
    }
  }

}