package ru.vtb.tsp.ia.epay.supervisor.services;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class OrderStateCounterMonitoringService {

  private static final String ORDER_STATE_NAME_COUNTER = "TSPACQ_ORDER_STATE-%s";

  private final MeterRegistry meterRegistry;

  public void incrementCounter(String name) {
    Counter counter = Counter.builder(String.format(ORDER_STATE_NAME_COUNTER, name))
        .register(meterRegistry);
    counter.increment();
  }
}