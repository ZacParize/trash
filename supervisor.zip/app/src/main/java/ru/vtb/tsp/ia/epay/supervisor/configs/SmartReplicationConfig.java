package ru.vtb.tsp.ia.epay.supervisor.configs;

import io.etcd.jetcd.Client;
import io.grpc.netty.GrpcSslContexts;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import javax.sql.DataSource;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.ttddyy.dsproxy.ExecutionInfo;
import net.ttddyy.dsproxy.listener.lifecycle.JdbcLifecycleEventListener;
import net.ttddyy.dsproxy.listener.logging.CommonsLogLevel;
import net.ttddyy.dsproxy.support.ProxyDataSourceBuilder;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.common.config.SslConfigs;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import ru.vtb.smartreplication.client.EmptyJdbcCycle;
import ru.vtb.smartreplication.client.IChangeProducer;
import ru.vtb.smartreplication.client.ReplicationChangeSender;
import ru.vtb.smartreplication.client.SmartReplicationConfiguration;
import ru.vtb.smartreplication.client.SmartReplicationDataSource;
import ru.vtb.smartreplication.client.kafka.KafkaChangeHandler;
import ru.vtb.smartreplication.client.producer.AbstractCachedResolver;
import ru.vtb.smartreplication.client.producer.DistributedChangeSourceResolver;
import ru.vtb.smartreplication.client.producer.WatcherChangeSourceResolver;
import ru.vtb.smartreplication.client.producer.handler.CustomReplicationPropertiesProvider;
import ru.vtb.smartreplication.client.producer.handler.EmergencyFailureHandler;
import ru.vtb.smartreplication.configuration.IConfigurationManagerPrivate;
import ru.vtb.smartreplication.configuration.etcd.DefaultEtcdClientBuilderConfigurer;
import ru.vtb.smartreplication.configuration.etcd.EtcdClientBuilderConfigurerComposite;
import ru.vtb.smartreplication.configuration.etcd.EtcdClientBuilderConfigurerWrapper;
import ru.vtb.smartreplication.configuration.etcd.EtcdConfigurationManager;
import ru.vtb.smartreplication.configuration.etcd.EtcdMarker;
import ru.vtb.smartreplication.core.compress.ChangeCompressor;
import ru.vtb.smartreplication.core.compress.IChangeCompressor;
import ru.vtb.smartreplication.core.compress.JsonConverter;
import ru.vtb.smartreplication.core.exception.SmartReplicationException;
import ru.vtb.smartreplication.core.kafka.config.KafkaProducerConfig;
import ru.vtb.smartreplication.core.kafka.producer.OwnerKafkaProducerTopicResolver;
import ru.vtb.smartreplication.core.provider.ChangeFormatType;
import ru.vtb.smartreplication.core.provider.ChangeProvider;
import ru.vtb.smartreplication.core.provider.ThreadLocalChangeProvider;
import ru.vtb.smartreplication.core.ssl.KeyStoreSslContextBuilderConfigurer;
import ru.vtb.smartreplication.core.ssl.SslContextBuilderConfigurerComposite;
import ru.vtb.smartreplication.core.ssl.SslContextBuilderConfigurerWrapper;
import ru.vtb.smartreplication.model.Change;
import ru.vtb.smartreplication.model.ChangeSource;
import ru.vtb.smartreplication.model.CompressType;
import ru.vtb.smartreplication.model.ProviderType;
import ru.vtb.streaming.adapter.flow.AutoChangeFlow;
import ru.vtb.streaming.adapter.producer.ChangeProducer;
import ru.vtb.streaming.config.AdapterConfig;
import ru.vtb.streaming.config.SkipQueriesPredicate;
import ru.vtb.streaming.config.SkipTablePredicate;
import ru.vtb.streaming.jdbc.RewindCrawlerFactory;
import ru.vtb.streaming.jdbc.SyncJdbcInterceptor;
import ru.vtb.streaming.mdc.MDCKeySupplier;
import ru.vtb.streaming.mdc.MDCPropertiesSupplier;
import ru.vtb.streaming.mdc.MDCSuboSupplier;
import ru.vtb.streaming.parser.EnumCastMapper;
import ru.vtb.streaming.parser.ProxyParameterTransformer;
import ru.vtb.streaming.parser.ProxyQueryTransformer;
import ru.vtb.streaming.proxy.ExtendedResultSetProxyLogicFactory;
import ru.vtb.streaming.proxy.ReturnProxyFactory;
import ru.vtb.streaming.visitor.IVisitorFactory;
import ru.vtb.streaming.visitor.VisitorFactory;
import ru.vtb.tsp.ia.epay.core.services.StandInParamService;
import ru.vtb.tsp.ia.epay.supervisor.configs.converters.StandInObjectMapper;
import ru.vtb.tsp.ia.epay.supervisor.configs.properties.standin.StandInProperties;
import ru.vtb.tsp.ia.epay.supervisor.services.standin.CustomEmergencyFailureHandler;
import ru.vtb.tsp.ia.epay.supervisor.services.standin.CustomReturningColumnStrategy;


@Configuration
@ConditionalOnProperty(prefix = "smart-replication", name = "enable", havingValue = "true")
@Slf4j
public class SmartReplicationConfig {

  private StandInProperties standInProperties;
  private StandInParamService standInParamService;

  public SmartReplicationConfig(
      StandInProperties standInProperties,
      @Lazy StandInParamService standInParamService) {
    this.standInProperties = standInProperties;
    this.standInParamService = standInParamService;
  }

  @Bean
  @ConfigurationProperties("spring.datasource.main")
  public DataSourceProperties mainDatasourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  @ConfigurationProperties("spring.datasource.standin")
  public DataSourceProperties standInDatasourceProperties() {
    return new DataSourceProperties();
  }

  @Bean
  public ChangeProvider changeProvider() {
    return new ThreadLocalChangeProvider();
  }

  @Bean("datasource")
  @Primary
  @ConfigurationProperties("spring.datasource.main.hikari")
  public DataSource mainDataSource() {
    return mainDatasourceProperties().initializeDataSourceBuilder().build();
  }

  @Bean(initMethod = "start", destroyMethod = "stop")
  public EtcdConfigurationManager etcdConfigurationManager(
      final List<EtcdClientBuilderConfigurerWrapper<EtcdMarker>> etcdConfigurerWrappers) {
    final var composite = new EtcdClientBuilderConfigurerComposite();
    composite.addConfigurers(etcdConfigurerWrappers);
    final var builder = Client.builder();
    composite.configure(builder);
    return new EtcdConfigurationManager(builder);
  }


  @Bean
  @SneakyThrows
  public EtcdClientBuilderConfigurerWrapper<EtcdMarker> etcdSslConfigurer(
      final Optional<List<SslContextBuilderConfigurerWrapper<EtcdMarker>>>
          maybeSslConfigurerWrappers
  ) {
    final var sslConfigurerWrappers = maybeSslConfigurerWrappers.orElse(null);
    if (sslConfigurerWrappers == null) {
      log.warn("Found no beans of type {}<{}>",
          SslContextBuilderConfigurerWrapper.class.getSimpleName(),
          EtcdMarker.class.getSimpleName());
      return null;
    }
    log.info("Using SSL configurers to configure Etcd SslContext: {}", sslConfigurerWrappers);
    final var composite = new SslContextBuilderConfigurerComposite();
    composite.addConfigurers(sslConfigurerWrappers);
    final var sslContextBuilder = GrpcSslContexts.forClient();
    composite.configure(sslContextBuilder);
    final var context = sslContextBuilder.build();
    return new EtcdClientBuilderConfigurerWrapper<>(
        clientBuilder -> clientBuilder.sslContext(context));
  }

  @Bean
  public EtcdClientBuilderConfigurerWrapper<EtcdMarker> etcdConfigurer() {
    return new EtcdClientBuilderConfigurerWrapper<>(
        new DefaultEtcdClientBuilderConfigurer(standInProperties.getEtcd()));
  }

  @Bean
  public SslContextBuilderConfigurerWrapper<EtcdMarker> keyStoreConfigurer() {
    log.info("Initializing KeyStore SSL configurer");
    final var sslProps = standInProperties.getEtcd().getKeyStore();
    if (sslProps == null) {
      log.warn(
          "KeyStore SSL configurer initialization skipped because settings were not specified");
      return null;
    }
    return new SslContextBuilderConfigurerWrapper<>(
        new KeyStoreSslContextBuilderConfigurer(sslProps));
  }


  /**
   * standin Определение standin DataSource приложения.
   */
  @Bean("standindatasource")
  @ConfigurationProperties("spring.datasource.standin.hikari")
  public DataSource standInDataSource() {
    return standInDatasourceProperties().initializeDataSourceBuilder().build();
  }

  @Bean
  public AbstractCachedResolver changeSourceResolver(IConfigurationManagerPrivate configManager) {
    return new WatcherChangeSourceResolver(new DistributedChangeSourceResolver(
        standInProperties.getOwner(),
        configManager));
  }

  @Bean("emergencyFailureHandler")
  public EmergencyFailureHandler emergencyFailureHandler(
      AbstractCachedResolver changeSourceResolver,
      @Qualifier("customReplicationPropertiesProvider")
          CustomReplicationPropertiesProvider customReplicationPropertiesProvider,
      @Qualifier("emergencyTransactionManager")
          PlatformTransactionManager platformTransactionManager,
      @Qualifier("emergencyJdbcTemplate")
          NamedParameterJdbcTemplate emergencyJdbcTemplate) {
    return new CustomEmergencyFailureHandler(changeSourceResolver,
        customReplicationPropertiesProvider,
        standInProperties.getMaxReplicationErrors(),
        standInProperties.getErrorPeriodInSeconds(),
        platformTransactionManager,
        emergencyJdbcTemplate);
  }

  @Bean("customReplicationPropertiesProvider")
  public CustomReplicationPropertiesProvider customReplicationPropertiesProvider() {
    return new CustomReplicationPropertiesProvider() {
      @Override
      public boolean isReplicationEnabled() {
        return standInParamService.isReplicationEnabled();
      }

      @Override
      public void setReplicationEnabled(boolean isReplicationEnabled) {
        log.info("Set standIn replication flag: {}", isReplicationEnabled);
        standInParamService.setReplicationEnabled(isReplicationEnabled);
      }

      @Override
      public ChangeSource getDefaultChangeSource() {
        final var result = getStandInDefaultChangeSource();
        log.info("Get standIn default ChangeSource: {}", result.name());
        return result;
      }
    };
  }

  @Bean
  public SmartReplicationConfiguration smartReplicationConfiguration(
      final KafkaChangeHandler kafkaChangeHandler,
      final ChangeProvider changeProvider,
      @Qualifier("emergencyFailureHandler")
      @Lazy final EmergencyFailureHandler emergencyFailureHandler,
      final AbstractCachedResolver changeSourceResolver) {
    return new SmartReplicationConfiguration(
        standInProperties.getOwner(),
        new MDCKeySupplier(),
        kafkaChangeHandler,
        changeProvider,
        changeSourceResolver,
        () -> false,
        null, null, null, emergencyFailureHandler
    );
  }

  /**
   * Проксирование DataSource для его репликации (Прикладной Журнал / Standin / Smart Replication).
   */
  @Bean("smartReplicationDataSource")
  public DataSource smartReplicationDataSource(
      @Qualifier("datasource") final DataSource mainDataSource,
      @Qualifier("standindatasource") final DataSource secondaryDataSource,
      final SmartReplicationConfiguration smartReplicationConfiguration) {
    return new SmartReplicationDataSource(
        mainDataSource,
        secondaryDataSource,
        smartReplicationConfiguration
    );
  }

  @Bean("smartReplicationKafka")
  public KafkaProducerConfig producerConfig() {
    final KafkaProducerConfig producerConfig = new KafkaProducerConfig(
        standInProperties.getKafka().getBootstrapServers());
    if (standInProperties.getKafka().getSecurity().isEnable()) {
      Map<String, String> map = producerConfig.getSslConfiguration();
      map.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStoreLocation());
      map.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStorePassword());
      map.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG,
          standInProperties.getKafka().getSecurity().getTrustStoreType());
      map.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyStoreLocation());
      map.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyPassword());
      map.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyStoreType());
      map.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,
          standInProperties.getKafka().getSecurity().getKeyPassword());
      map.put(SslConfigs.SSL_PROTOCOL_CONFIG, "TLSv1.3");
      map.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG,
          standInProperties.getKafka().getSecurity().getProtocol());
    }
    return new KafkaProducerConfig(producerConfig);
  }

  @Bean
  public KafkaChangeHandler kafkaChangeHandler(
      @Qualifier("smartReplicationKafka") KafkaProducerConfig producerConfig) {
    final var resolver = new OwnerKafkaProducerTopicResolver();
    return new KafkaChangeHandler(producerConfig, resolver, getChangeCompressor());
  }

  @Bean
  public IVisitorFactory<Change> visitorFactory() {
    return new VisitorFactory(
        new RewindCrawlerFactory()
    );
  }

  @Bean
  public IChangeProducer<String, ExecutionInfo> producer(
      @Qualifier("smartReplicationDataSource") DataSource smartReplicationDataSource,
      AdapterConfig adapterConfig,
      IVisitorFactory<Change> visitorFactory,
      ChangeProvider changeProvider) {
    return ChangeProducer.builder()
        .dataSource(smartReplicationDataSource)
        .config(adapterConfig)
        .factory(visitorFactory)
        .provider(changeProvider)
        .build();
  }

  @Bean
  public JdbcLifecycleEventListener jdbcLifeListener(
      @Qualifier("smartReplicationDataSource") final DataSource smartReplicationDataSource,
      final AdapterConfig adapterConfig,
      final IVisitorFactory<Change> visitorFactory,
      IChangeProducer<String, ExecutionInfo> producer,
      SmartReplicationConfiguration smartReplicationConfiguration) {
    return new SyncJdbcInterceptor<>(
        AutoChangeFlow.builder()
            .config(adapterConfig)
            .dataSource(smartReplicationDataSource)
            .sender(new ReplicationChangeSender(smartReplicationConfiguration,
                getStandInDefaultChangeSource()))
            //.sender(new EmptyChangeSender())
            .producer(producer)
            .jdbcCycle(new EmptyJdbcCycle())
            .processor(visitorFactory.createProcessor())
            .build(),
        visitorFactory
    );
  }

  @Bean
  public AdapterConfig adapterConfig() {
    return new AdapterConfig(true)
        .subo(new MDCSuboSupplier())
        .key(() -> Optional.ofNullable(MDC.get(MDCKeySupplier.UNIQUE_KEY)).orElse(null))
        .customProperties(new MDCPropertiesSupplier())
        .provider(ProviderType.SMART_REPLICATION)
        .changeFormatType(ChangeFormatType.ENTITY) // в ResultSet для потребителя передаются
        .skipQueryPredicate(new SkipQueriesPredicate())
        .skipTablePredicate(new SkipTablePredicate<>(Set.of("audlib_event_code",
            "standin_params",
            "databasechangeloglock",
            "databasechangelog",
            "audlib_event",
            "audlib_security_officer_event",
            "audlib_security_officer_event_code",
            "flow_points",
            "flows",
            "flow_commands",
            "flyway_schema_history")))
        // обновляемые поля из таблицы
        .useContextConnection();
  }

  @Bean("proxydataSource")
  public DataSource proxyDataSource(
      @Qualifier("smartReplicationDataSource") final DataSource smartReplicationDataSource,
      final JdbcLifecycleEventListener jdbcLifeListener,
      AdapterConfig adapterConfig,
      IVisitorFactory<Change> visitorFactory) {

    return ProxyDataSourceBuilder.create(smartReplicationDataSource)
        .logQueryByCommons(CommonsLogLevel.DEBUG)
        .autoRetrieveGeneratedKeys(false, new ExtendedResultSetProxyLogicFactory())
        .jdbcProxyFactory(new ReturnProxyFactory())
        .proxyResultSet(new ExtendedResultSetProxyLogicFactory())
        .parameterTransformer(new ProxyParameterTransformer())
        .queryTransformer(
            new ProxyQueryTransformer(
                smartReplicationDataSource,
                visitorFactory,
                adapterConfig,
                new EnumCastMapper<>(
                    type -> EnumCastMapper.ENUM_CAST + "\"" + type.getSchema() + "\".\""
                        + type.getType() + "\"",
                    type -> EnumCastMapper.ENUM_CAST + type.getType()
                ),
                new CustomReturningColumnStrategy()
            )
        )
        .listener(
            jdbcLifeListener
        )
        .build();
  }

  private ChangeSource getStandInDefaultChangeSource() {
    try {
      return ChangeSource.valueOf(standInProperties.getDefaultChangeSource());
    } catch (Exception e) {
      return ChangeSource.MAIN;
    }
  }

  private IChangeCompressor getChangeCompressor() {
    if ((Objects.nonNull(standInProperties.getCompressType()))
        && (Objects.nonNull(standInProperties.getMinBytesToCompress()))) {
      return new ChangeCompressor(CompressType.valueOf(standInProperties.getCompressType()),
          new JsonConverter(new StandInObjectMapper()), standInProperties.getMinBytesToCompress());
    } else {
      return new ChangeCompressor(new JsonConverter(new StandInObjectMapper()));
    }
  }

  @Bean
  @Primary
  public PlatformTransactionManager transactionManager(
      @Qualifier("proxydataSource") DataSource applierDataSource) {
    return new DataSourceTransactionManager(applierDataSource);
  }

  @Bean
  @Primary
  public NamedParameterJdbcTemplate namedParameterJdbcTemplate(
      final @Qualifier("proxydataSource") DataSource applierDataSource) {
    return new NamedParameterJdbcTemplate(applierDataSource);
  }

  @Bean
  public JdbcTemplate jdbcTemplate(
      @Qualifier("proxydataSource") final DataSource applierDataSource) {
    return new JdbcTemplate(applierDataSource);
  }


  @Bean("emergencyTransactionManager")
  public PlatformTransactionManager emergencyTransactionManager(
      @Qualifier("datasource") DataSource mainDataSource,
      @Qualifier("standindatasource") final DataSource secondaryDataSource) {
    final var changeSource = getStandInDefaultChangeSource();
    switch (changeSource) {
      case MAIN:
        return new DataSourceTransactionManager(mainDataSource);
      case STAND_IN:
        return new DataSourceTransactionManager(secondaryDataSource);
      default:
        throw new SmartReplicationException("Unsupported emergencyTransactionManager type");
    }
  }

  @Bean("emergencyJdbcTemplate")
  public NamedParameterJdbcTemplate emergencyJdbcTemplate(
      @Qualifier("emergencyTransactionManager")
          PlatformTransactionManager emergencyTransactionManager) {
    return new NamedParameterJdbcTemplate(
        ((DataSourceTransactionManager) emergencyTransactionManager).getDataSource());
  }

}
