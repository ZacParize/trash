package ru.vtb.tsp.ia.epay.supervisor.configs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Slf4j
@Configuration
@EnableKafka
@ComponentScan({"ru.vtb.tsp.ia.epay.supervisor", "ru.vtb.tsp.ia.epay.core"})
@EnableTransactionManagement
public class AppConfig {
}