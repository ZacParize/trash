CREATE ROLE epay_user;
CREATE USER epay_supervisor;
GRANT epay_supervisor TO epay_user;
CREATE SCHEMA IF NOT EXISTS epay;