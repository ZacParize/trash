package ru.vtb.tsp.ia.epay.supervisor.configs;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import ru.vtb.tsp.ia.epay.supervisor.containers.ConfluentKafkaContainer;
import ru.vtb.tsp.ia.epay.supervisor.containers.PostgresqlContainer;

@SpringBootTest(classes = TestConfig.class)
@Transactional
@Testcontainers
public class BaseTest {

    @Container
    public static PostgresqlContainer POSTGRESQL_CONTAINER = PostgresqlContainer.getInstance();

    @Container
    public static KafkaContainer CONFLUENT_KAFKA_CONTAINER = ConfluentKafkaContainer.getInstance();

}