package ru.vtb.tsp.ia.epay.supervisor.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Optional;
import java.util.stream.Stream;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;
import ru.vtb.tsp.ia.epay.supervisor.configs.BaseTest;

class CalculatorHandlerTest extends BaseTest {

    @Autowired
    CalculatorHandler calculatorHandler;

    static Stream<Arguments> provideTransactionPayloads() throws IllegalAccessException {
        final var payload = TestFactory.getTransactionPayload();
        final var payloadBefore = TestFactory.getTransactionAfterCardInfo();
        final var payloadAfter = (TransactionPayload) TestFactory.clone(payloadBefore);
        payloadAfter.getRoute().setCurrentPoint(payloadBefore.getRoute().getCurrentPoint() + 1);
        final var completedPayload = TestFactory.getTransactionAfterCardInfo();
        completedPayload.getRoute().setCurrentPoint(completedPayload.getRoute().getFlowPoints().size() - 1);
        return Stream.of(Arguments.of(null, Optional.empty()),
                         Arguments.of(payload, Optional.of(payload)),
                         Arguments.of(payloadBefore, Optional.of(payloadAfter)),
                         Arguments.of(completedPayload, Optional.empty()));
    }

    @DisplayName("Should pass calculator handler calculate when correct transaction payloads")
    @ParameterizedTest
    @MethodSource("provideTransactionPayloads")
    void test_calculate(TransactionPayload payload, Optional<TransactionPayload> expected) {
        assertEquals(expected, calculatorHandler.calculate(payload));
    }

}