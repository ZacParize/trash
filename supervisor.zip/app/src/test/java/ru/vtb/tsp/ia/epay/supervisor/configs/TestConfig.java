package ru.vtb.tsp.ia.epay.supervisor.configs;

import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.validation.ValidationAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({AppConfig.class, KafkaConsumerConfig.class, KafkaProducerConfig.class})
@ImportAutoConfiguration(classes = ValidationAutoConfiguration.class)
public class TestConfig {
}