package ru.vtb.tsp.ia.epay.supervisor.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.Optional;
import java.util.stream.Stream;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.support.Acknowledgment;
import ru.vtb.tsp.ia.epay.core.configurations.ObjectMapperConfiguration;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;
import ru.vtb.tsp.ia.epay.core.services.OrderService;
import ru.vtb.tsp.ia.epay.core.services.TransactionService;
import ru.vtb.tsp.ia.epay.core.utils.TestFactory;
import ru.vtb.tsp.ia.epay.supervisor.configs.BaseTest;

class ProcessorServiceTest extends BaseTest {

  @Autowired
  CalculatorHandler calculatorHandler;

  @Autowired
  MessageAdapter messageAdapter;

  @Autowired
  ExceptionHandler exceptionHandler;

  TransactionService transactionService;

  KafkaService kafkaService;

  OrderStateMachine orderStateMachine;

  ProcessorService processorService;

  static Stream<Arguments> provideTransactionPayloadsForTransform() throws JsonProcessingException {
    final var payload = TestFactory.getTransactionPayload();
    final var payloadAsString = new ObjectMapperConfiguration()
        .objectMapper().writeValueAsString(payload);
    return Stream.of(Arguments.of(null, null),
        Arguments.of(payload, payload),
        Arguments.of(payloadAsString, payload));
  }

  @BeforeEach
  public void init() {
    transactionService = Mockito.mock(TransactionService.class);
    kafkaService = Mockito.mock(KafkaService.class);
    orderStateMachine = new OrderStateMachine(Mockito
        .mock(OrderStateCounterMonitoringService.class), Mockito.mock(OrderService.class),
        transactionService);
    processorService = new ProcessorService(calculatorHandler, kafkaService, transactionService,
        messageAdapter, exceptionHandler, orderStateMachine);
  }

  @DisplayName("Should pass processor service transform when correct message")
  @ParameterizedTest
  @MethodSource("provideTransactionPayloadsForTransform")
  void test_transform(Object message, TransactionPayload expected) {
    assertEquals(expected, processorService.transform(message));
  }

  @DisplayName("Should pass processor service process not last flow point")
  @Test
  void test_processNotLastFlowPoint() {
    final var payload = TestFactory.getTransactionPayload();
    payload.getRoute().setCurrentPoint(1);
    final var modifiedPayload = TestFactory.getTransactionPayload();
    modifiedPayload.getRoute().setCurrentPoint(2);
    final var acknowledgment = Mockito.mock(Acknowledgment.class);
    final var record = new ConsumerRecord<>("testTopic",
        0, 0L, "testKey", payload);
    Mockito.when(transactionService.updateDataById(anyString(), any(TransactionPayload.class)))
        .thenReturn(true);
    Mockito.when(transactionService.updateTransactionFlow(any()))
        .thenReturn(Optional.of(modifiedPayload));
    processorService.process(record, acknowledgment);
    Mockito.verify(kafkaService, Mockito.times(1))
        .sendToBox(anyList(), any());
  }

  @DisplayName("Should pass processor service process last flow point")
  @Test
  void test_processLastFlowPoint() {
    final var payload = TestFactory.getTransactionPayload();
    payload.getRoute().setCurrentPoint(payload.getRoute().getFlowPoints().size() - 2);
    final var modifiedPayload = TestFactory.getTransactionPayload();
    modifiedPayload.getRoute().setCurrentPoint(payload.getRoute().getFlowPoints().size() - 1);
    final var acknowledgment = Mockito.mock(Acknowledgment.class);
    final var record = new ConsumerRecord<>("testTopic",
        0, 0L, "testKey", payload);
    Mockito.when(transactionService.updateDataById(anyString(), any(TransactionPayload.class)))
        .thenReturn(true);
    Mockito.when(transactionService.updateTransactionFlow(any()))
        .thenReturn(Optional.of(modifiedPayload));
    processorService.process(record, acknowledgment);
    Mockito.verify(kafkaService, Mockito.times(1))
        .sendToBox(anyList(), any());
  }

  @DisplayName("Should pass processor service process when route is completed")
  @Test
  void test_processWhenRouteIsCompleted() {
    final var payload = TestFactory.getTransactionPayload();
    payload.getRoute().setCurrentPoint(payload.getRoute().getFlowPoints().size() - 1);
    final var acknowledgment = Mockito.mock(Acknowledgment.class);
    final var record = new ConsumerRecord<>("testTopic",
        0, 0L, "testKey", payload);
    Mockito.when(transactionService.updateDataById(anyString(), any(TransactionPayload.class)))
        .thenReturn(true);
    processorService.process(record, acknowledgment);
    Mockito.verify(kafkaService, Mockito.times(0))
        .sendToBox(anyList(), any());
  }

}