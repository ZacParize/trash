#!/bin/sh

echo "Active user"
whoami

echo "List of all users"
awk -F':' '{ print $1}' /etc/passwd

echo "====== Create files ======"
mkdir "/opt/truststores"
mkdir "/opt/truststores/consumer"
mkdir "/opt/truststores/producer"
mkdir "/opt/keystores"
mkdir "/opt/keystores/consumer"
mkdir "/opt/keystores/producer"

cp "$kafka_ssl_truststore_location" /opt/truststores/consumer/kafka-ift-truststore.pfx
cp "$kafka_ssl_truststore_location" /opt/truststores/producer/kafka-ift-truststore.pfx
cp "$kafka_ssl_keystore_location" /opt/keystores/consumer/kafka-ift-keystore.keystore
cp "$kafka_ssl_keystore_location" /opt/keystores/producer/kafka-ift-keystore.keystore

echo "====== Permission modifications ======"
chmod -R +rx /opt/truststores
chmod -R +rx /opt/keystores

echo "====== Content of /opt ======"
ls -l /opt
echo "====== Content of /opt/pki ======"
ls -l /opt/pki
echo "====== Content of /opt/truststores ======"
ls -l /opt/truststores
echo "====== Content of /opt/keystores ======"
ls -l /opt/keystores
echo "====== Content of /opt/truststores/consumer ======"
ls -l /opt/truststores/consumer
echo "====== Content of /opt/truststores/producer ======"
ls -l /opt/truststores/producer
echo "====== Content of /opt/keystores/consumer ======"
ls -l /opt/keystores/consumer
echo "====== Content of /opt/keystores/producer ======"
ls -l /opt/keystores/producer
echo "====== Launch application ======"
CMD='java -jar '
CMD="$CMD -Dfile.encoding=UTF-8"
CMD="$CMD $JAVA_MEM"
CMD="$CMD $JAVA_EXT"
CMD="$CMD -Duser.language=ru"
CMD="$CMD -Duser.country=RU"
CMD="$CMD -XX:+UseContainerSupport"
CMD="$CMD /opt/app.jar"
echo "$CMD"
$CMD
