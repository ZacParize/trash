plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot") version("2.4.4")
    id("io.spring.dependency-management") version("1.0.11.RELEASE")
    id("org.sonarqube") version("3.3")
}

buildscript {
    dependencies {
        classpath("com.gorylenko.gradle-git-properties:gradle-git-properties:2.4.0-rc2")
    }
}

apply(plugin = "com.gorylenko.gradle-git-properties")

configurations {
    implementation {
        resolutionStrategy.failOnVersionConflict()
        exclude("org.springframework.boot","spring-boot-starter-tomcat")
        exclude("org.springframework.boot","spring-boot-starter-logging")
        exclude("ch.qos.logback", "logback-classic")
        exclude("ch.qos.logback", "logback-core")
        exclude(group="io.springfox", module = "springfox-bean-validators")
        exclude(group="io.springfox", module = "springfox-boot-starter")
        exclude(group="io.springfox", module = "springfox-core")
        exclude(group="io.springfox", module = "springfox-data-rest")
    }
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    maven {
        url = uri(findProperty("nexus.artifact.repository").toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
    maven {
        url = uri(extra["nexus.omni.artifact.repository"].toString())
        credentials {
            username = System.getenv("CRED_NEXUS_CI_USER")
            password = System.getenv("CRED_NEXUS_CI_PASS")
        }
    }
}

dependencyManagement {
    imports {
        mavenBom("ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                + findProperty("bom.version").toString())
    }
}

dependencies {
    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-domain")
    implementation("ru.vtb.dev.corp.ia.epay:epay-core-lib")
    implementation("ru.vtb.dev.corp.ia.epay:epay-tokenization-api")

    // Javax annotations
    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310")

    //standin
    implementation("ru.vtb.smartreplication:smart-replication-producer-lib")
    implementation("ru.vtb.smartreplication:smart-replication-client-jdbc")
    implementation("ru.vtb.smartreplication:smart-replication-core-etcd-support-starter")
    implementation("io.grpc:grpc-core")
    implementation("io.grpc:grpc-netty")
    implementation("io.grpc:grpc-protobuf")
    implementation("io.grpc:grpc-stub")
    implementation("io.grpc:grpc-grpclb")
    implementation("net.jodah:failsafe")

    // Spring components
    implementation("org.springframework.kafka:spring-kafka")
    implementation("org.springframework.boot:spring-boot-starter-data-jdbc")
    implementation("org.springframework.boot:spring-boot-starter-integration")
    implementation("org.springframework.boot:spring-boot-starter-actuator")
    runtimeOnly("org.springframework.boot:spring-boot-starter-undertow")

    // Validation
    implementation("javax.validation:validation-api")

    implementation("org.flywaydb:flyway-core")

    implementation("org.apache.commons:commons-jexl3")

    // Database driver
    implementation("org.postgresql:postgresql")

    // Logging
    implementation("org.springframework.boot:spring-boot-starter-log4j2")
    implementation("com.vlkan.log4j2:log4j2-logstash-layout")
    implementation("ru.vtb.infra.logging:log4j2-integration")


    // Kafka streams
    implementation ("org.apache.kafka:kafka-streams")

    // Reactive streams
    implementation("io.projectreactor:reactor-core")
    implementation("io.projectreactor.kafka:reactor-kafka")

    // Tracing
    implementation("ru.vtb.dev.corp.ia.epay:epay-tracing-starter")

    // Monitoring
    implementation("io.micrometer:micrometer-registry-prometheus")
    implementation("org.springframework.boot:spring-boot-starter-web")

    // Lombok
    annotationProcessor("org.projectlombok:lombok")
    testAnnotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")

    // Use JUnit Jupiter API for testing
    testImplementation("org.springframework.boot:spring-boot-starter-test")
    testImplementation("org.junit.jupiter:junit-jupiter-api")
    testImplementation("org.testcontainers:testcontainers")
    testImplementation("org.testcontainers:postgresql")
    testImplementation("org.testcontainers:kafka")
    testImplementation("org.testcontainers:junit-jupiter")
    testCompileOnly("org.projectlombok:lombok")
    testRuntimeOnly("org.junit.jupiter:junit-jupiter-engine")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

springBoot {
    // Manifest manipulation
    mainClass.set("ru.vtb.tsp.ia.epay.supervisor.App")
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString()
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
        }
    }

    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    archiveFileName.set("${project.name}.jar")
}

tasks.test {
    // Use junit platform for unit tests.
    useJUnitPlatform()
}

configure<com.gorylenko.GitPropertiesPluginExtension> {
    customProperties.put("git.build.version", System.getenv("buildVersion"))
    customProperties.put("git.build.time", System.getenv("buildTime"))
    customProperties.put("git.api.version", System.getenv("VERSION"))
    failOnNoGitDirectory = false
}

tasks.register<Copy>("copyDependencies") {
    from(configurations.default)
            into("$buildDir/dependencies")
}

sonarqube {
    properties {
        property("sonar.language", "java")
        property("sonar.projectKey", findProperty("sonar.projectKey").toString())
        property("sonar.projectName", findProperty("sonar.projectKey").toString())
        property("sonar.dynamicAnalysis", "reuseReports")
        property("sonar.host.url", findProperty("sonar.host.url").toString())
        property("sonar.java.binarie", "${project.buildDir}/classes/**")
        property("sonar.exclusions", "src/main/resources/**/*," +
                "ru/vtb/tsp/ia/epay/supervisor/**/*Dto.java," +
                "ru/vtb/tsp/ia/epay/supervisor/**/*Abstract*.java," +
                "ru/vtb/tsp/ia/epay/supervisor/**/*Config.java," +
                "ru/vtb/tsp/ia/epay/supervisor/**/*Exception.java," +
                "ru/vtb/tsp/ia/epay/supervisor/configs/*.java" +
                "ru/vtb/tsp/ia/epay/supervisor/exceptions/*.java" +
                "ru/vtb/tsp/ia/epay/supervisor/App.java" +
                "**/*.yaml," +
                "**/*.yml," +
                "**/*.xml")
    }
}