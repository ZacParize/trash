"""
D3:G solution
"""

while True:
    num = int(input())
    if num == 0:
        break 
    else:
        print(num)