"""
D3:H solution
"""

while True:
    message = input()
    if message == "": # len(num) == 0
        break 
    else:
        print(message)