age = int(input())
if age < 18:
    raise Exception("ВОЗРАСТ МЕНЬШЕ 18 ЛЕТ!")