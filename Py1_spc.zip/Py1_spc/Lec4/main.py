"""
Управляющая конструкция - условный оператор
"""
# if expression:
#     body


age = int(input())

if age > 18:
    print("Welcome")
    print("U can use service")


print("After if block")