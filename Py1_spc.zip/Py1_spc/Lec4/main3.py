"""
оператор if-else
"""
# if expression:
#     body_1
# else:
#     body_2

age = int(input())

if age >= 18:
    print("Welcome")
else:
    print("Use DEMO -version on link: .........")

print("Done!")


"""
Взятие модуля abs()
"""
#abs(-20)
