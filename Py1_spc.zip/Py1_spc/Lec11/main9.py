"""
Удаление пары
"""
words = {"one" : 1, "two" : 2}
words.pop("one")
print(words)