print("Checking connection to db.....")
print("Checking internet connection .....")