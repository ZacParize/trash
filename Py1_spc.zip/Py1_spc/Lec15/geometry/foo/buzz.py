def hello():
    print("Hello from buzz.py!")