"""
D1:F solution
"""

#  "Имя: [имя] , Фамилия: [фамилия] , Возраст: [возраст] . Студент BPS"
name = input()#"Enter name: ")
last_name = input()#"Enter lastname: ")
age = input()#"Enter age: ")

print("Имя:", name, ", Фамилия:", last_name, ", Возраст:", age, ". Студент BPS")