"""
D1:A solution
"""
print("Привет! Я новый студент!")