"""
D7 : G solution
"""

def hello():
    print("Привет из функции!")

hello()