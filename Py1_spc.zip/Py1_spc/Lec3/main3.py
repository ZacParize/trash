"""
Тип "ничего" NoneType()
None - это прямой аналог null из SQL
"""
a_none = None
