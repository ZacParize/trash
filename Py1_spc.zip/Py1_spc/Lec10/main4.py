"""
Стандартные функции на списках:
len(), sum(), min(), max()
"""

nums = [10, 20, 30 ,40, -1, 1000]
# len()
print("Len:", len(nums))

# sum()
print("Sum:", sum(nums))


# min() / max()
print("min/max:", min(nums) , "/", max(nums))

