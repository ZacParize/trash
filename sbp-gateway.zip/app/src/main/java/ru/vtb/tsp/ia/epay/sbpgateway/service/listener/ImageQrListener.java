package ru.vtb.tsp.ia.epay.sbpgateway.service.listener;

import javax.validation.constraints.NotNull;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpgateway.configuration.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractListener;
import ru.vtb.tsp.ia.epay.sbpgateway.service.MementoService;

@Component(ImageQrListener.BEAN_NAME)
public class ImageQrListener extends AbstractListener {

  public static final String BEAN_NAME = "imageQrListener";

  public ImageQrListener(@NotNull MementoService mementoService) {
    super(mementoService);
  }

  @KafkaListener(topics = Constants.GATEWAY_IMAGE_QR_ADDRESS,
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  @Override
  public void listen(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    super.listen(record, acknowledgment);
  }
}