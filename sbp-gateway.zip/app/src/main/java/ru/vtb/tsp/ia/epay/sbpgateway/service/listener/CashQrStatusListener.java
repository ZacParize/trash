package ru.vtb.tsp.ia.epay.sbpgateway.service.listener;

import javax.validation.constraints.NotNull;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.sbpgateway.configuration.KafkaConsumerConfig;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress.Constants;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractListener;
import ru.vtb.tsp.ia.epay.sbpgateway.service.MementoService;

@Component(CashQrStatusListener.BEAN_NAME)
public class CashQrStatusListener extends AbstractListener {

  public static final String BEAN_NAME = "cashQrStatusListener";

  public CashQrStatusListener(@NotNull MementoService mementoService) {
    super(mementoService);
  }

  @KafkaListener(topics = Constants.GATEWAY_CASH_QR_STATUS_ADDRESS,
      containerFactory = KafkaConsumerConfig.KAFKA_LISTENER_CONTAINER_FACTORY_BEAN_NAME)
  @Override
  public void listen(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    super.listen(record, acknowledgment);
  }
}