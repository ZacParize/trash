package ru.vtb.tsp.ia.epay.sbpgateway.service;

import static java.util.Optional.ofNullable;

import java.util.List;
import java.util.Objects;
import java.util.Set;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.merchant.MerchantApiClient;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteFilter;
import ru.vtb.tsp.ia.epay.sbpgateway.client.AntiReplayResponseDto;
import ru.vtb.tsp.ia.epay.sbpgateway.client.AntiReplyApi;

@Slf4j
@Service
public class AuditFilterService {

  private final MerchantApiClient merchantApiClient;
  private final AntiReplyApi antiReplyApi;
  private final String systemUser;

  public AuditFilterService(MerchantApiClient merchantApiClient,
      AntiReplyApi antiReplyApi,
      @Value("${app.paylink.system-user}") String systemUser) {
    this.merchantApiClient = merchantApiClient;
    this.antiReplyApi = antiReplyApi;
    this.systemUser = systemUser;
  }

  @AuditProcess(value = "TSPACQ_BOX_JWT_EPA_AUTH")
  public MerchantSiteDto getMerchantSite(@Nullable final String mstId,
      @Nullable final String clientId) {
    if (clientId.isBlank()) {
      log.error("Empty clienId");
      throw new IllegalArgumentException();
    }

    if (systemUser.equals(clientId) && Objects.nonNull(mstId)) {
      return merchantApiClient
          .getMerchantSite(mstId)
          .orElseThrow(() -> {
            log.error("Not found merchantSites by mstId = {}, clientId is systemUser", mstId);
            return new IllegalArgumentException();
          });
    }

    if (Objects.nonNull(clientId) && Objects.nonNull(mstId)) {
      final var responseList = merchantApiClient
          .getMerchantSites(buildMerchantSiteFilter(clientId, mstId), null);
      checkSizeResponseList(responseList, clientId, mstId);
      return responseList.stream()
          .findFirst()
          .orElseThrow(() -> {
            log.error("Not found merchantSites by client_id = {} mstId = {}", clientId, mstId);
            return new IllegalArgumentException();
          });
    }

    final var responseList = merchantApiClient
        .getMerchantSites(buildMerchantSiteFilter(clientId, null), null);
    checkSizeResponseList(responseList, clientId, mstId);
    return responseList.stream()
        .findFirst()
        .orElseThrow(() -> {
          log.error("Not found merchantSites by client_id = {}, response: {}", clientId,
              responseList);
          return new IllegalArgumentException();
        });
  }

  private void checkSizeResponseList(@Nullable final List<MerchantSiteDto> responseList,
      @Nullable final String clientId,
      @Nullable final String mstId) {

    if (CollectionUtils.isEmpty(responseList)) {
      log.error("Not found many merchantSites by client_id = {}, mstId = {}, response: {}",
          clientId, mstId, responseList);
      throw new IllegalArgumentException();

    }
    if (responseList.size() > 1) {
      log.error("Found many merchantSites by client_id = {},  mstId = {}, response: {}", clientId,
          mstId, responseList);
      throw new IllegalArgumentException();
    }
  }

  private MerchantSiteFilter buildMerchantSiteFilter(@Nonnull final String login,
      @Nullable final String mstId) {
    return MerchantSiteFilter.builder()
        .login(Set.of(login))
        .mstId(ofNullable(mstId).map(Set::of).orElse(null))
        .build();
  }

  public ResponseEntity<AntiReplayResponseDto> getAntiReplayResponse(String jti) {
    return antiReplyApi.getStatus(HttpHeaders.EMPTY, jti);
  }
}