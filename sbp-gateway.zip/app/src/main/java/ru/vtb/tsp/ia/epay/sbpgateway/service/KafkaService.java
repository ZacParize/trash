package ru.vtb.tsp.ia.epay.sbpgateway.service;

import static ru.vtb.tsp.ia.epay.sbpgateway.configuration.KafkaProducerConfig.KAFKA_TEMPLATE;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;

@Slf4j
@Service
public class KafkaService {

  private final KafkaTemplate<String, Event> kafkaTemplate;
  private final List<String> dlqTopics;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForSubscriber;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForDlq;

  public KafkaService(@Qualifier(KAFKA_TEMPLATE) KafkaTemplate<String, Event> kafkaTemplate,
      @Value("${app.kafka.dlq-topics}") @NotEmpty List<String> dlqTopics,
      MementoService mementoService) {
    this.kafkaTemplate = kafkaTemplate;
    this.dlqTopics = Objects.requireNonNullElse(dlqTopics, Collections.emptyList());
    this.callbackFactoryForSubscriber = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Event {} is processed with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending event {} to subscriber {}", key, topic, ex);
      }
    };
    this.callbackFactoryForDlq = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Message {} is sent to dlq with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending message {} to portal {}", key, topic, ex);
      }
    };
  }

  public void sendToSubscriber(@Nullable Event event) {
    Optional.ofNullable(event)
        .ifPresent(e -> send(e, e.getMstId()));
  }

  public void sendToDlq(@Nullable Object message) {
    Optional.ofNullable(message).ifPresent(tx -> send(message, message.toString()));
  }

  private void send(@Nullable Object payload, String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    if (payload instanceof Event) {
      topics = ((Event) payload).getDestination().stream()
          .map(EventAddress::getRequestAddress)
          .collect(Collectors.toList());
      callback = callbackFactoryForSubscriber;
    } else {
      topics = dlqTopics;
      callback = callbackFactoryForDlq;
    }
    topics.forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
          .addCallback(callback.apply(topic, key));
    });
  }

}