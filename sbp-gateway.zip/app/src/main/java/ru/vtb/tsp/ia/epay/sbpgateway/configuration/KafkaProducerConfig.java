package ru.vtb.tsp.ia.epay.sbpgateway.configuration;

import java.util.List;
import javax.validation.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import ru.vtb.tsp.ia.epay.core.configurations.KafkaConfiguration;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;

@Configuration
public class KafkaProducerConfig {

  public static final String KAFKA_TEMPLATE = "kafkaBoxTemplate";

  @Value("${spring.kafka.bootstrap-servers}")
  @NotEmpty
  private List<String> bootstrapServers;

  @Value("${app.kafka.partitions-count}")
  private int partitionsCount;

  @Value("${app.kafka.replicas-count}")
  private int replicasCount;

  @Value("${spring.kafka.producer.ssl.protocol:#{null}}")
  private String sslProtocol;

  @Value("${spring.kafka.producer.ssl.trust-store-type:#{null}}")
  private String sslTrustStoreType;

  @Value("${spring.kafka.producer.ssl.trust-store-location:#{null}}")
  private String sslTrustStoreLocation;

  @Value("${spring.kafka.producer.ssl.trust-store-password:#{null}}")
  private String sslTrustStorePassword;

  @Value("${spring.kafka.producer.ssl.key-store-type:#{null}}")
  private String sslKeyStoreType;

  @Value("${spring.kafka.producer.ssl.key-store-location:#{null}}")
  private String sslKeyStoreLocation;

  @Value("${spring.kafka.producer.ssl.key-store-password:#{null}}")
  private String sslKeyStorePassword;

  @Value("${spring.kafka.producer.ssl.key-password:#{null}}")
  private String sslKeyPassword;

  @Bean
  ProducerFactory<String, ?> producerFactory() {
    final var configuration = KafkaConfiguration.producerConfig(bootstrapServers,
        sslProtocol,
        sslTrustStoreType,
        sslTrustStoreLocation,
        sslTrustStorePassword,
        sslKeyStoreType,
        sslKeyStoreLocation,
        sslKeyStorePassword,
        sslKeyPassword);
    KafkaConfiguration.createTopics(configuration, EventAddress.getRequestAddresses(),
        partitionsCount, replicasCount);
    return new DefaultKafkaProducerFactory<>(configuration);
  }

  @Bean(KAFKA_TEMPLATE)
  KafkaTemplate<String, Event> kafkaTemplate(
      ProducerFactory<String, Event> producerFactory) {
    return new KafkaTemplate<>(producerFactory);
  }

}