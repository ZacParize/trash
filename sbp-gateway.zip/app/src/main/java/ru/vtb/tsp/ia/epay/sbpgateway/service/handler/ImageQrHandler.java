package ru.vtb.tsp.ia.epay.sbpgateway.service.handler;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.UUID;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.service.MementoService;

@Component(ImageQrHandler.BEAN_NAME)
public class ImageQrHandler extends AbstractHandler<SbpImageQrCreationRequestDto> {

  public static final String BEAN_NAME = "imageQrService";

  public ImageQrHandler(KafkaService kafkaService, MementoService mementoService) {
    super(kafkaService, mementoService, req -> EventImpl.builder().header(EventHeaderImpl.builder()
            .mstId(((MerchantSiteDto) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal()).getId())
            .code(UUID.randomUUID().toString())
            .type(EventType.IMAGE_QR)
            .sentAt(LocalDateTime.now(ZoneOffset.UTC))
            .destination(Collections.singletonList(EventAddress.IMAGE_QR))
            .build())
        .payload(req)
        .build());
  }
}
