package ru.vtb.tsp.ia.epay.sbpgateway.configuration;

import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;

@Configuration
@RequiredArgsConstructor
@SecurityScheme(name = "bearerAuth", scheme = "bearer",
    type = SecuritySchemeType.HTTP, bearerFormat = "JWT")
public class SwaggerConfig {

}
