package ru.vtb.tsp.ia.epay.sbpgateway.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.stream.Collectors;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.util.ConcurrentReferenceHashMap;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.EventHeader;

@Service
public class MementoService {

  public static final long DISPERSION_TIME_SECONDS = 30L;

  private final Map<String, Event> map = new ConcurrentReferenceHashMap<>();

  public void put(Event event) {
    map.put(event.getCode(), event);
  }

  public Event get(String key) {
    return map.get(key);
  }

  @Scheduled(fixedDelay = DISPERSION_TIME_SECONDS * 1000)
  public void clean() {
    final var timeMark = LocalDateTime.now(ZoneOffset.UTC)
        .minusSeconds(DISPERSION_TIME_SECONDS);
    map.values().stream()
      .collect(Collectors.toMap(EventHeader::getCode, Event::getSentAt))
      .entrySet()
      .stream().filter(e -> timeMark.isAfter(e.getValue()))
      .forEach(e -> map.remove(e.getKey()));
  }
}