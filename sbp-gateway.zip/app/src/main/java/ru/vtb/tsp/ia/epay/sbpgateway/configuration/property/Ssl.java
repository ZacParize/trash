package ru.vtb.tsp.ia.epay.sbpgateway.configuration.property;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "app.ssl")
public class Ssl {

  private String truststorePath;
  private String truststorePass;
  private String keystorePath;
  private String keystorePass;
  private boolean clientAuth;
  private boolean certValidation;

}