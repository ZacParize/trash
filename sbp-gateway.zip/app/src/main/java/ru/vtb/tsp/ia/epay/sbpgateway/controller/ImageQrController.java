package ru.vtb.tsp.ia.epay.sbpgateway.controller;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpgateway.ImageQrApi;
import ru.vtb.tsp.ia.epay.sbpgateway.event.payload.EventPayload;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.ImageQrHandler;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class ImageQrController implements ImageQrApi {

  private static final String API_PREFIX = "/api/v1";
  private final ImageQrHandler handler;

  @AuditProcess("TSPACQ_BOX_SBP_QR_IMAGE")
  @PostMapping(API_PREFIX + "/qr/image")
  public ResponseEntity<Object> create(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      SbpImageQrCreationRequestDto request) {
    return ResponseEntity.ok(
        Optional.ofNullable(handler.handle(request))
            .map(EventPayload::getPayload)
            .orElse(null));
  }

}