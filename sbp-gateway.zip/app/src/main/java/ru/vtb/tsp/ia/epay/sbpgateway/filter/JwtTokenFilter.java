package ru.vtb.tsp.ia.epay.sbpgateway.filter;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.opentracing.Tracer;
import java.util.Base64;
import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.util.MimeTypeUtils;
import org.springframework.web.filter.OncePerRequestFilter;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AuditFilterService;

@Slf4j
public class JwtTokenFilter extends OncePerRequestFilter {

  private static final String MERCHANT_AUTHORIZATION = "Merchant-Authorization";
  private static final Base64.Decoder BASE64_DECODER = Base64.getDecoder();
  private static final String SUB = "sub";
  private static final String ROLE_USER = "ROLE_USER";
  private static final TypeReference<Map<String, Object>> MAP_TYPE_REFERENCE =
      new TypeReference<>() {
      };

  private final ObjectMapper objectMapper;
  private final Tracer tracer;
  private final AuditFilterService auditFilterService;

  public JwtTokenFilter(ObjectMapper objectMapper,
      Tracer tracer, AuditFilterService auditFilterService) {
    this.objectMapper = Objects.requireNonNull(objectMapper, "Object mapper can't be null");
    this.tracer = Objects.requireNonNull(tracer, "Tracer can't be null");
    this.auditFilterService = auditFilterService;
  }

  private void setSecurityContext(Object principal, HttpServletRequest request) {
    final var authentication = new UsernamePasswordAuthenticationToken(principal,
        null,
        Collections.singletonList(new SimpleGrantedAuthority(ROLE_USER)));
    authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
    SecurityContextHolder.getContext().setAuthentication(authentication);
  }

  @Override
  protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) {
    try {
      log.info("filter {}, request {} url {}",
          this.getClass().getSimpleName(), request.getMethod(), request.getRequestURI());
      final var header = request.getHeader(HttpHeaders.AUTHORIZATION);
      final var token = header.split(" ")[1].trim();
      final var chunks = token.split("\\.");
      final var claims = objectMapper
          .readValue(new String(BASE64_DECODER.decode(chunks[1])), MAP_TYPE_REFERENCE);
      MerchantSiteDto loggedMst;
      final var clientId = (String) claims.get(SUB);

      final var mstId = request.getHeader(MERCHANT_AUTHORIZATION);
      loggedMst = auditFilterService.getMerchantSite(mstId, clientId);

      setSecurityContext(loggedMst, request);
      chain.doFilter(request, response);
    } catch (Exception ex) {
      log.error("EPA authorization failed", ex);
      response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
      response.setHeader(HttpHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON_VALUE);
      /* AntiReplyTokenFilter.setCustomResponseBody(ex, response, objectMapper,
          tracer.scopeManager().activeSpan().context().toTraceId());*/
    } finally {
      SecurityContextHolder.clearContext();
    }
  }
}