package ru.vtb.tsp.ia.epay.sbpgateway.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import ru.vtb.tsp.ia.epay.core.configurations.ObjectMapperConfiguration;

@Slf4j
@Configuration
@RequiredArgsConstructor
public class RestTemplateConfig {

  private static final int READ_TIMEOUT_MILLISECONDS = 10_000;
  private static final int CONNECT_TIMEOUT_MILLISECONDS = 10_000;

  @Bean
  ObjectMapper merchantClientMapper() {
    return new ObjectMapperConfiguration().objectMapper();
  }

  @Bean
  RestTemplate merchantRestTemplate(RestTemplateBuilder builder) {
    return createRestTemplate(builder);
  }

  @Bean
  RestTemplate merchantSiteRestTemplate(RestTemplateBuilder builder) {
    return createRestTemplate(builder);
  }

  private RestTemplate createRestTemplate(RestTemplateBuilder builder) {
    final var requestFactory = new HttpComponentsClientHttpRequestFactory();
    requestFactory.setReadTimeout(READ_TIMEOUT_MILLISECONDS);
    requestFactory.setConnectTimeout(CONNECT_TIMEOUT_MILLISECONDS);
    return builder.requestFactory(() -> new BufferingClientHttpRequestFactory(requestFactory))
        .build();
  }

}
