package ru.vtb.tsp.ia.epay.sbpgateway.configuration.property;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Configuration
@ConfigurationProperties(prefix = "app.public-key")
public class PublicKeyProperties {

  private String apiKey;
  private boolean enabled;
  private String url;
  private String truststorePath;
  private String truststorePass;
  private String keystorePath;
  private String keystorePass;
  private boolean clientAuth;
  private boolean certValidation;

}