package ru.vtb.tsp.ia.epay.sbpgateway.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.opentracing.Tracer;
import java.io.IOException;
import java.time.Duration;
import java.util.Collections;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.servlet.http.HttpServletRequest;
import javax.validation.constraints.NotNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.header.HeaderWriterFilter;
import org.springframework.util.ObjectUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.DefaultCorsProcessor;
import org.springframework.web.filter.CorsFilter;
import ru.vtb.tsp.ia.epay.sbpgateway.filter.AntiReplyTokenFilter;
import ru.vtb.tsp.ia.epay.sbpgateway.filter.JwtTokenFilter;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AuditFilterService;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  private static final int CORS_TIMEOUT = 3600;
  private final String antiReplayUrl;
  private final String[] whiteList;
  private final ObjectMapper objectMapper;
  private final Tracer tracer;
  private final AuditFilterService auditFilterService;

  public SecurityConfig(@Value("${app.anti-replay.url}") String antiReplayUrl,
      @Value("${app.paylink.system-user}") String systemUser,
      ObjectMapper objectMapper,
      Tracer tracer,
      AuditFilterService auditFilterService) {
    Objects.requireNonNull(systemUser, "Paylink user can't be empty");
    this.antiReplayUrl = antiReplayUrl;
    this.objectMapper = objectMapper;
    this.tracer = tracer;
    this.auditFilterService = auditFilterService;
    this.whiteList = new String[]{
        //"/api/v1/**",
        // сваггер оставляем без авторизации доступ должен быть для тестирования.
        // на проде сваггер отключен, На ИФТ точно нужен
        "/swagger-resources/**",
        "/v3/api-docs/**",
        "/swagger-ui/**",
        "/swagger-ui.html",
        // актуатор должен быть всегда доступным
        "/actuator/**",
        "/version",
        "/favicon.ico"
    };
  }

  public CorsFilter getCorsFilter() {
    final var corsConfigurationSource = new CorsConfigurationSource() {
      @Override
      public @NotNull CorsConfiguration getCorsConfiguration(@Nullable HttpServletRequest request) {
        final var corsConfiguration = new CorsConfiguration();
        corsConfiguration.setAllowedMethods(Collections.singletonList("*"));
        corsConfiguration.setAllowedHeaders(Collections.singletonList("*"));
        corsConfiguration.setMaxAge(Duration.ofSeconds(CORS_TIMEOUT));
        return corsConfiguration;
      }
    };

    final var corsFilter = new CorsFilter(corsConfigurationSource);
    corsFilter.setCorsProcessor(new DefaultCorsProcessor() {
      @Override
      protected void rejectRequest(@NotNull ServerHttpResponse response) throws IOException {
        response.setStatusCode(HttpStatus.FORBIDDEN);
        response.getHeaders().add(HttpHeaders.ACCESS_CONTROL_ALLOW_CREDENTIALS,
            Boolean.FALSE.toString());
        response.flush();
      }
    });

    return corsFilter;
  }

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.httpBasic().disable()
        .csrf().disable()
        .cors().disable()
        .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        .and()
        .addFilterAfter(getCorsFilter(), HeaderWriterFilter.class)
        .addFilterBefore(new AntiReplyTokenFilter(objectMapper, auditFilterService, tracer),
            UsernamePasswordAuthenticationFilter.class)
        .addFilterAfter(new JwtTokenFilter(objectMapper, tracer, auditFilterService),
            AntiReplyTokenFilter.class)
        //белый список URL которые должны быть доступны в любом случае
        .authorizeRequests()
        .antMatchers(whiteList).permitAll()
        .anyRequest()
        .authenticated();
    http.exceptionHandling()
        .authenticationEntryPoint(new HttpStatusEntryPoint(HttpStatus.BAD_REQUEST));
  }

  @Override
  public void configure(WebSecurity web) {
    web.ignoring()
        // exclude from security
        .antMatchers(ObjectUtils.isEmpty(antiReplayUrl) ? new String[]{"/**"} : whiteList)
        // allow CORS
        .antMatchers(HttpMethod.OPTIONS);
  }

  @Bean
  FilterRegistrationBean<CorsFilter> corsFilter() {
    final var bean = new FilterRegistrationBean<>(getCorsFilter());
    bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
    return bean;
  }

}