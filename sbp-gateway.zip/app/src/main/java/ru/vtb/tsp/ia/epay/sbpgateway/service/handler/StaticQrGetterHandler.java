package ru.vtb.tsp.ia.epay.sbpgateway.service.handler;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.UUID;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.service.MementoService;

@Service(StaticQrGetterHandler.BEAN_NAME)
public class StaticQrGetterHandler extends AbstractHandler<String> {

  public static final String BEAN_NAME = "staticQrGetterHandler";

  public StaticQrGetterHandler(KafkaService kafkaService, MementoService mementoService) {
    super(kafkaService, mementoService, req -> EventImpl.builder().header(EventHeaderImpl.builder()
            .mstId(((MerchantSiteDto) SecurityContextHolder.getContext()
                .getAuthentication().getPrincipal()).getId())
            .code(UUID.randomUUID().toString())
            .type(EventType.STATIC_QR_GET)
            .sentAt(LocalDateTime.now(ZoneOffset.UTC))
            .destination(Collections.singletonList(EventAddress.STATIC_QR_GET))
            .build())
        .payload(req)
        .build());
  }
}