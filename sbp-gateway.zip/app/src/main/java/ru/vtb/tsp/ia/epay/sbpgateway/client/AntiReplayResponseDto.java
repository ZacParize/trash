package ru.vtb.tsp.ia.epay.sbpgateway.client;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.io.Serializable;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AntiReplayResponseDto implements Serializable {

  @JsonProperty("jti")
  private String jti;

  @JsonProperty("status")
  private Boolean status;

}