package ru.vtb.tsp.ia.epay.sbpgateway.configuration;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;

@Slf4j
@Configuration
@EnableKafka
@EnableScheduling
@ComponentScan("ru.vtb.tsp.ia.epay.merchant")
@EnableCaching(proxyTargetClass = true)
@RequiredArgsConstructor
public class AppConfig {

}