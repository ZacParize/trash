package ru.vtb.tsp.ia.epay.sbpgateway.controller;

import java.util.Map;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpgateway.StaticQrApi;
import ru.vtb.tsp.ia.epay.sbpgateway.event.payload.EventPayload;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.StaticQrCreationHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.StaticQrGetterHandler;

@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class StaticQrController implements StaticQrApi {

  private static final String API_PREFIX = "/api/v1";
  private final Map<String, AbstractHandler> handlers;

  @PostMapping(API_PREFIX + "/qr/static")
  public ResponseEntity<Object> create(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      SbpQrCodeCreationRequestDto request) {
    return ResponseEntity.ok(Optional.ofNullable(handlers.get(StaticQrCreationHandler.BEAN_NAME))
        .map(service -> (StaticQrCreationHandler) service)
        .map(service -> service.handle(request))
        .map(EventPayload::getPayload)
        .orElse(null));
  }

  @GetMapping(API_PREFIX + "/qr/static/{qrcId}")
  public ResponseEntity<Object> get(
      String merchantAuthorizationHeader,
      String authorizationHeader, String qrcId) {
    return ResponseEntity.ok(Optional.ofNullable(handlers.get(StaticQrGetterHandler.BEAN_NAME))
        .map(service -> (StaticQrGetterHandler) service)
        .map(service -> service.handle(qrcId))
        .map(EventPayload::getPayload)
        .orElse(null));
  }

}