package ru.vtb.tsp.ia.epay.sbpgateway.controller;


import java.io.Serializable;
import java.util.Map;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpgateway.CashQrApi;
import ru.vtb.tsp.ia.epay.sbpgateway.event.payload.EventPayload;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.CashQrActivationHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.CashQrCreationHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.CashQrDeactivationHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.handler.CashQrStatusHandler;


@Slf4j
@Validated
@RestController
@RequiredArgsConstructor
public class CashQrController implements CashQrApi {

  private static final String API_PREFIX = "/api/v1";
  private static final SbpCashQrCreationRequestDto CASH_QR_CREATION_REQUEST_STUB =
      SbpCashQrCreationRequestDto.builder().build();
  private final Map<String, AbstractHandler> handlers;

  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_CREATION")
  @PostMapping(API_PREFIX + "/qr/cash")
  public @NotNull ResponseEntity<Object> create(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      Serializable request) {
    return ResponseEntity.ok(
        Optional.ofNullable(handlers.get(CashQrCreationHandler.BEAN_NAME))
            .map(service -> (CashQrCreationHandler) service)
            .map(service -> service.handle(CASH_QR_CREATION_REQUEST_STUB))
            .map(EventPayload::getPayload)
            .orElse(null));
  }

  @PostMapping(API_PREFIX + "/qr/cash/status")
  public @NotNull ResponseEntity<Object> getStatus(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      SbpCashQrStatusRequestDto request) {
    return ResponseEntity.ok(
        Optional.ofNullable(handlers.get(CashQrStatusHandler.BEAN_NAME))
            .map(service -> (CashQrStatusHandler) service)
            .map(service -> service.handle(request))
            .map(EventPayload::getPayload)
            .orElse(null));
  }

  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_ACTIVATION")
  @PostMapping(API_PREFIX + "/qr/cash/activate")
  public @NotNull ResponseEntity<Object> activate(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      SbpCashQrActivationRequestDto request) {
    return ResponseEntity.ok(
        Optional.ofNullable(handlers.get(CashQrActivationHandler.BEAN_NAME))
            .map(service -> (CashQrActivationHandler) service)
            .map(service -> service.handle(request))
            .map(EventPayload::getPayload)
            .orElse(null));
  }

  @AuditProcess("TSPACQ_BOX_SBP_QR_CASH_DEACTIVATION")
  @PostMapping(API_PREFIX + "/qr/cash/deactivate")
  public @NotNull ResponseEntity<Object> deactivate(
      String merchantAuthorizationHeader,
      String authorizationHeader,
      SbpCashQrDeactivationRequestDto request) {
    return ResponseEntity.ok(
        Optional.ofNullable(handlers.get(CashQrDeactivationHandler.BEAN_NAME))
            .map(service -> (CashQrDeactivationHandler) service)
            .map(service -> service.handle(request))
            .map(EventPayload::getPayload)
            .orElse(null));
  }
}