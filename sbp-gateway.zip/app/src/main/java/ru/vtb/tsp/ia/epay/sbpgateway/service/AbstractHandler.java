package ru.vtb.tsp.ia.epay.sbpgateway.service;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.locks.LockSupport;
import java.util.function.Function;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;

@Slf4j
public abstract class AbstractHandler<T extends Serializable> {

  private static final Event EMPTY_EVENT = EventImpl.builder().build();
  private static final long REQUEST_REFRESH_TIME_NANOSECONDS = 200L * 1000L * 1000L;
  private static final long REQUEST_EXECUTION_TIME_SECONDS = 4L;
  protected final KafkaService kafkaService;
  protected final MementoService mementoService;
  protected final Function<T, Event> function;

  public AbstractHandler(@NotNull KafkaService kafkaService,
      @NotNull MementoService mementoService,
      @NotNull Function<T, Event> function) {
    this.kafkaService = kafkaService;
    this.mementoService = mementoService;
    this.function = function;
  }

  public @Nullable Event handle(@Nullable T request) {
    return Optional.ofNullable(request)
        .map(function)
        .map(event -> {
          kafkaService.sendToSubscriber(event);
          final var timeMark = LocalDateTime.now(ZoneOffset.UTC)
              .plusSeconds(REQUEST_EXECUTION_TIME_SECONDS);
          Event result;
          while (timeMark.isAfter(LocalDateTime.now(ZoneOffset.UTC))) {
            result = mementoService.get(event.getCode());
            if (Objects.nonNull(result)) {
              return result;
            }
            LockSupport.parkNanos(REQUEST_REFRESH_TIME_NANOSECONDS);
          }
          return EMPTY_EVENT;
        })
        .orElse(EMPTY_EVENT);
  }
}