package ru.vtb.tsp.ia.epay.sbpgateway.service;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.support.Acknowledgment;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;

@Slf4j
@RequiredArgsConstructor
public abstract class AbstractListener {

  private final MementoService mementoService;

  protected void listen(@NotNull ConsumerRecord<String, Event> record,
      @NotNull Acknowledgment acknowledgment) {
    try {
      Optional.ofNullable(record.value())
          .filter(event -> LocalDateTime.now(ZoneOffset.UTC)
              .minusSeconds(MementoService.DISPERSION_TIME_SECONDS).isBefore(event.getSentAt()))
          .ifPresent(mementoService::put);
    } catch (Exception ex) {
      log.error("Event can't be processed", ex);
    } finally {
      acknowledgment.acknowledge();
    }
  }
}