package ru.vtb.tsp.ia.epay.sbpgateway.service.handler;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.Optional;
import java.util.UUID;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteDto;
import ru.vtb.tsp.ia.epay.merchant.sites.dtos.MerchantSiteSbpParamsDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.service.AbstractHandler;
import ru.vtb.tsp.ia.epay.sbpgateway.service.KafkaService;
import ru.vtb.tsp.ia.epay.sbpgateway.service.MementoService;

@Component(CashQrCreationHandler.BEAN_NAME)
public class CashQrCreationHandler extends AbstractHandler<SbpCashQrCreationRequestDto> {

  public static final String BEAN_NAME = "cashQrCreationHandler";

  public CashQrCreationHandler(KafkaService kafkaService,
      MementoService mementoService,
      @Value("${app.sbp.agent-id}") String agentId,
      @Value("${app.sbp.member-id}") String memberId) {
    super(kafkaService, mementoService,
        req -> {
          final var merchantSite = (MerchantSiteDto) SecurityContextHolder.getContext()
              .getAuthentication().getPrincipal();
          Assert.notNull(merchantSite, "Merchant site can't be null");
          Assert.hasText(agentId, "Sbp agent-id can't be null or empty");
          Assert.hasText(memberId, "Sbp member-id can't be null or empty");
          final var merchantSiteParams = merchantSite.getParams();
          Assert.notNull(merchantSite, "Merchant site params can't be null");
          return EventImpl.builder().header(EventHeaderImpl.builder()
                  .mstId(((MerchantSiteDto) SecurityContextHolder.getContext()
                      .getAuthentication().getPrincipal()).getId())
                  .code(UUID.randomUUID().toString())
                  .type(EventType.CASH_QR_CRETE)
                  .sentAt(LocalDateTime.now(ZoneOffset.UTC))
                  .destination(Collections.singletonList(EventAddress.CASH_QR_CREATE))
                  .build())
              .payload(SbpCashQrCreationRequestDto.builder()
                  .account(Optional.ofNullable(merchantSiteParams.getSbpParams())
                      .map(MerchantSiteSbpParamsDto::getAccount)
                      .orElse(null))
                  .agentId(agentId)
                  .memberId(memberId)
                  .merchantId(Optional.ofNullable(merchantSiteParams.getSbpParams())
                      .map(MerchantSiteSbpParamsDto::getMerchantId)
                      .orElse(null))
                  .redirectUrl(merchantSiteParams.getCallbackUrl())
                  .build())
              .build();
        });
  }
}