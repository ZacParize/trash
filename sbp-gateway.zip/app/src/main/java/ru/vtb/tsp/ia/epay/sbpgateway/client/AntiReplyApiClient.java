package ru.vtb.tsp.ia.epay.sbpgateway.client;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.FeignClient;

@ConditionalOnProperty(name = "app.anti-replay.mock", havingValue = "false")
@FeignClient(name = "antiReplyApiClient", url = "${app.anti-replay.url}", decode404 = true)
public interface AntiReplyApiClient extends AntiReplyApi {

}