#!/bin/sh

echo "Active user"
whoami

echo "List of all users"
awk -F':' '{ print $1}' /etc/passwd

echo "====== Create files ======"
mkdir "/opt/truststores"
mkdir "/opt/truststores/consumer"
mkdir "/opt/truststores/producer"
mkdir "/opt/truststores/audit"
mkdir "/opt/truststores/feign"
mkdir "/opt/keystores"
mkdir "/opt/keystores/consumer"
mkdir "/opt/keystores/producer"
mkdir "/opt/keystores/audit"
mkdir "/opt/keystores/feign"

cp "$kafka_ssl_truststore_location" /opt/truststores/consumer/kafka-ift-truststore.pfx
cp "$kafka_ssl_truststore_location" /opt/truststores/producer/kafka-ift-truststore.pfx
cp "$kafka_ssl_keystore_location" /opt/keystores/consumer/kafka-ift-keystore.keystore
cp "$kafka_ssl_keystore_location" /opt/keystores/producer/kafka-ift-keystore.keystore
cp "$audit_truststore_path" /opt/truststores/audit/audit-kafka-truststore.pfx
cp "$audit_keystore_path" /opt/keystores/audit/kafka-ift-keystore.keystore
cp "$feign_ssl_truststore_path" /opt/truststores/feign/feign-ssl-truststore.pfx
cp "$feign_ssl_keystore_path" /opt/keystores/feign/feign-ssl-keystore.keystore

echo "====== Permission modifications ======"
chmod -R +rx /opt/truststores
chmod -R +rx /opt/keystores

echo "====== Content of /opt ======"
ls -l /opt
echo "====== Content of /opt/pki ======"
ls -l /opt/pki
echo "====== Content of /opt/truststores ======"
ls -l /opt/truststores
echo "====== Content of /opt/keystores ======"
ls -l /opt/keystores
echo "====== Content of /opt/truststores/consumer ======"
ls -l /opt/truststores/consumer
echo "====== Content of /opt/truststores/feign ======"
ls -l /opt/truststores/feign
echo "====== Content of /opt/truststores/producer ======"
ls -l /opt/truststores/producer
echo "====== Content of /opt/keystores/consumer ======"
ls -l /opt/keystores/consumer
echo "====== Content of /opt/keystores/producer ======"
ls -l /opt/keystores/producer
echo "====== Content of /opt/keystores/feign ======"
ls -l /opt/keystores/feign

echo "====== Launch application ======"
CMD='java -jar '
CMD="$CMD -Dfile.encoding=UTF-8"
CMD="$CMD $JAVA_MEM"
CMD="$CMD $JAVA_EXT"
CMD="$CMD -Duser.language=ru"
CMD="$CMD -Duser.country=RU"
CMD="$CMD -XX:+UseContainerSupport"
CMD="$CMD /opt/app.jar"
echo "$CMD"
$CMD