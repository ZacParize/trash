plugins {
    idea
    base
    java
    application
    `maven-publish`
    id("org.springframework.boot") version ("2.4.4")
    id("io.spring.dependency-management") version ("1.0.11.RELEASE")
    id("org.sonarqube") version ("3.3")
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

repositories {
    repositories {
        maven {
            url = uri(extra["nexus.artifact.repository"].toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

dependencyManagement {
    imports {
        mavenBom(
                "ru.vtb.dev.corp.ia.epay:tsp-ia-box-dependencies:"
                        + findProperty("bom.version").toString()
        )
    }
}

dependencies {

    implementation("com.google.code.findbugs:jsr305")
    implementation("com.fasterxml.jackson.core:jackson-databind")

    // Core dependencies
    implementation("ru.vtb.dev.corp.ia.epay:epay-sbpadapter-api")

    // Spring components
    implementation("org.springframework.boot:spring-boot-starter-web")

    implementation("javax.validation:validation-api")

    // Swagger
    implementation("org.springdoc:springdoc-openapi-ui")
    implementation("io.swagger.core.v3:swagger-annotations")

    annotationProcessor("org.projectlombok:lombok")
    compileOnly("org.projectlombok:lombok")
}

sourceSets {
    // Source sets configuration
    main {
        java.srcDir("src/main/java")
    }
    test {
        java.srcDir("src/test/java")
    }
}

publishing {
    // Artifact publishing configuration
    publications {
        create<MavenPublication>("maven") {
            artifactId = findProperty("app.name").toString() + "-api"
            groupId = findProperty("app.group").toString()
            version = findProperty("app.version").toString()
            from(components["java"])
            versionMapping {
                usage("java-api") {
                    fromResolutionOf("runtimeClasspath")
                }
                usage("java-runtime") {
                    fromResolutionResult()
                }
            }
        }
    }
    repositories {
        maven {
            url = uri(findProperty("nexus.publish.repository").toString())
            credentials {
                username = System.getenv("CRED_NEXUS_CI_USER")
                password = System.getenv("CRED_NEXUS_CI_PASS")
            }
        }
    }
}

tasks.withType<Jar> {
    // Set jar file name
    enabled = true
}

tasks.bootJar {
    // Set bootJar file name
    enabled = false


}

tasks.withType<JavaCompile> {
    options.encoding = "UTF-8"
}