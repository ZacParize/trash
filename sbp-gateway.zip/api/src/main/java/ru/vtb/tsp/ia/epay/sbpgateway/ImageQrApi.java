package ru.vtb.tsp.ia.epay.sbpgateway;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.annotation.Nullable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpImageQrCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.errors.ErrorDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpImageQrCreationResponseDto;

@Tag(name = "Получение Изображения Qr-кода в бинарном формате ", description = "Метод получения Изображения Qr-кода в бинарном формате")
public interface ImageQrApi {

  @SecurityRequirement(name = "bearerAuth")
  @Operation(summary = "Запрос для получения Изображения Qr-кода в бинарном формате")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpImageQrCreationResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE, schema =
          @Schema(implementation = ErrorDto.class))})})
  @NotNull ResponseEntity<?> create(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid @Nullable SbpImageQrCreationRequestDto request);

}
