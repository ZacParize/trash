package ru.vtb.tsp.ia.epay.sbpgateway;

import static org.springframework.util.MimeTypeUtils.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpQrCodeCreationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpQrCodeResponseDto;

@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Операции с Функциональными ссылками", description = "Методы для работы с Функциональными ссылками")
public interface StaticQrApi {

  @Operation(summary = "Запрос на регистрацию платежной ссылки")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = MediaType.APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpQrCodeResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга")})
  @NotNull ResponseEntity<?> create(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid SbpQrCodeCreationRequestDto request);

  @Operation(summary = "Запрос на получение зарегистрированной платежной ссылки")
  @ApiResponse(responseCode = "200", content = {
      @Content(
          mediaType = APPLICATION_JSON_VALUE,
          schema = @Schema(implementation = SbpQrCodeResponseDto.class))
  })
  @NotNull ResponseEntity<?> get(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @NotBlank @PathVariable String qrcId);
}
