package ru.vtb.tsp.ia.epay.sbpgateway;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import java.io.Serializable;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrActivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrDeactivationRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.requests.payments.SbpCashQrStatusRequestDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.errors.ErrorDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrActivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrCreationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrDeactivationResponseDto;
import ru.vtb.tsp.ia.epay.sbpadapter.dtos.responses.payments.SbpCashQrStatusResponseDto;

@SecurityRequirement(name = "bearerAuth")
@OpenAPIDefinition(info = @Info(title = "SBPGateway API", version = "1.0.0"))
@Tag(name = "Операции с Кассовыми ссылками", description = "Методы для работы с Кассовыми ссылками")
public interface CashQrApi {

  @Operation(summary = "Регистрация Кассовой ссылки")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpCashQrCreationResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE, schema =
          @Schema(implementation = ErrorDto.class))})})

  @NotNull ResponseEntity<?> create(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid Serializable request);

  @Operation(summary = "Получение статуса Кассовой ссылки")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpCashQrStatusResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE, schema =
          @Schema(implementation = ErrorDto.class))})})
  @NotNull ResponseEntity<?> getStatus(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid SbpCashQrStatusRequestDto request);

  @Operation(summary = "Активация Кассовой ссылки")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpCashQrActivationResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE, schema =
          @Schema(implementation = ErrorDto.class))})})
  @NotNull ResponseEntity<?> activate(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid SbpCashQrActivationRequestDto request);

  @Operation(summary = "Деактивация Кассовой ссылки")
  @ApiResponses(value = {
      @ApiResponse(responseCode = "200", description = "OK", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE,
              schema = @Schema(implementation = SbpCashQrDeactivationResponseDto.class))}),
      @ApiResponse(responseCode = "500", description = "Ошибка модуля процессинга", content =
          {@Content(mediaType = APPLICATION_JSON_VALUE, schema =
          @Schema(implementation = ErrorDto.class))})})
  @NotNull ResponseEntity<?> deactivate(
      @RequestHeader(name = "Merchant-Authorization", required = false) String merchantAuthorizationHeader,
      @RequestHeader(name = "Authorization") String authorizationHeader,
      @RequestBody @Valid SbpCashQrDeactivationRequestDto request);

}
