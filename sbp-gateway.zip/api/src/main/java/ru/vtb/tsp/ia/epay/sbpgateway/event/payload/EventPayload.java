package ru.vtb.tsp.ia.epay.sbpgateway.event.payload;

import java.io.Serializable;
import javax.validation.constraints.NotNull;

public interface EventPayload extends Serializable {

  @NotNull Object getPayload();

  void setPayload(@NotNull Object payload);

}