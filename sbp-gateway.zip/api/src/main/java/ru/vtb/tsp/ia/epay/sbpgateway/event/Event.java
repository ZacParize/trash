package ru.vtb.tsp.ia.epay.sbpgateway.event;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import ru.vtb.tsp.ia.epay.sbpgateway.event.impl.EventImpl;
import ru.vtb.tsp.ia.epay.sbpgateway.event.payload.EventPayload;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.EventHeader;

@JsonDeserialize(as = EventImpl.class)
public interface Event extends EventHeader, EventPayload {

}