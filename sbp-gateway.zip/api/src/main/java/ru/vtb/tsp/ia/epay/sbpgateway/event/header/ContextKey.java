package ru.vtb.tsp.ia.epay.sbpgateway.event.header;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ContextKey {
}