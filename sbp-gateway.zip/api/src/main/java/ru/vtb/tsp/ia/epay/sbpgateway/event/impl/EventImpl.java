package ru.vtb.tsp.ia.epay.sbpgateway.event.impl;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.sbpgateway.event.Event;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.ContextKey;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.EventHeader;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventImpl implements Event {

  @Builder.Default
  @NotNull
  private EventHeader header = new EventHeaderImpl();

  @NotNull
  private Object payload;

  @Override
  @NotNull
  public Object getFromContext(@NotNull ContextKey key) {
    return header.getFromContext(key);
  }

  @Override
  public void setInContext(@NotNull ContextKey key, Object value) {
    header.setInContext(key, value);
  }

  @NotBlank
  @Override
  @JsonIgnore
  public String getCode() {
    return Objects.requireNonNull(header, "Event header is not initialized").getCode();
  }

  @Override
  public void setCode(@NotBlank String code) {
    Objects.requireNonNull(header, "Event header is not initialized").setCode(code);
  }

  @NotNull
  @Override
  @JsonIgnore
  public EventType getType() {
    return Objects.requireNonNull(header, "Event header is not initialized").getType();
  }

  @Override
  public void setMstId(@NotBlank String code) {
    Objects.requireNonNull(header, "Event header is not initialized").setMstId(code);
  }

  @NotBlank
  @Override
  @JsonIgnore
  public String getMstId() {
    return Objects.requireNonNull(header, "Event header is not initialized").getMstId();
  }

  @Override
  public void setType(@NotNull EventType type) {
    Objects.requireNonNull(header, "Event header is not initialized").setType(type);
  }

  @NotEmpty
  @Override
  @JsonIgnore
  public List<EventAddress> getDestination() {
    return Objects.requireNonNull(header, "Event header is not initialized").getDestination();
  }

  @Override
  public void setDestination(@NotEmpty List<EventAddress> destination) {
    Objects.requireNonNull(header, "Event header is not initialized").setDestination(destination);
  }

  @NotNull
  @Override
  @JsonIgnore
  public LocalDateTime getSentAt() {
    return Objects.requireNonNull(header, "Event header is not initialized").getSentAt();
  }

  @Override
  public void setSentAt(@NotNull LocalDateTime sentAt) {
    Objects.requireNonNull(header, "Event header is not initialized").setSentAt(sentAt);
  }

}