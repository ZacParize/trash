package ru.vtb.tsp.ia.epay.sbpgateway.event;

public enum EventType {

  STATIC_QR_CREATE,
  STATIC_QR_GET,
  CASH_QR_CRETE,
  CASH_QR_ACTIVATE,
  CASH_QR_DEACTIVATE,
  CASH_QR_STATUS,
  IMAGE_QR;

  public static class Constants {

    public static final String STATIC_QR_CREATE = "STATIC_QR_CREATE";
    public static final String STATIC_QR_GET = "STATIC_QR_GET";
    public static final String CASH_QR_CRETE = "CASH_QR_CRETE";
    public static final String CASH_QR_ACTIVATE = "CASH_QR_ACTIVATE";
    public static final String CASH_QR_DEACTIVATE = "CASH_QR_DEACTIVATE";
    public static final String CASH_QR_STATUS = "CASH_QR_STATUS";
    public static final String IMAGE_QR = "IMAGE_QR";

  }

}