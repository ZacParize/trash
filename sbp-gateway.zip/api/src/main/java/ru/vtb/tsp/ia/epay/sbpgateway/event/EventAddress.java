package ru.vtb.tsp.ia.epay.sbpgateway.event;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum EventAddress {

  STATIC_QR_CREATE(Constants.ADAPTER_STATIC_QR_CREATE_ADDRESS,
      Constants.GATEWAY_STATIC_QR_CREATE_ADDRESS),
  STATIC_QR_GET(Constants.ADAPTER_STATIC_QR_GET_ADDRESS,
      Constants.GATEWAY_STATIC_QR_GET_ADDRESS),
  CASH_QR_CREATE(Constants.ADAPTER_CASH_QR_CREATE_ADDRESS,
      Constants.GATEWAY_CASH_QR_CREATE_ADDRESS),
  CASH_QR_ACTIVATE(Constants.ADAPTER_CASH_QR_ACTIVATE_ADDRESS,
      Constants.GATEWAY_CASH_QR_ACTIVATE_ADDRESS),
  CASH_QR_DEACTIVATE(Constants.ADAPTER_CASH_QR_DEACTIVATE_ADDRESS,
      Constants.GATEWAY_CASH_QR_DEACTIVATE_ADDRESS),
  CASH_QR_STATUS(Constants.ADAPTER_CASH_QR_STATUS_ADDRESS,
      Constants.GATEWAY_CASH_QR_STATUS_ADDRESS),
  IMAGE_QR(Constants.ADAPTER_IMAGE_QR_ADDRESS,
      Constants.GATEWAY_IMAGE_QR_ADDRESS);

  private static final Map<String, EventAddress> ADDRESS_BY_NAME_MAP =
      Arrays.stream(EventAddress.values())
          .collect(Collectors.toMap(EventAddress::name, Function.identity()));
  private final String requestAddress;
  private final String responseAddress;

  public static @Nullable EventAddress findByName(@Nullable String name) {
    return ADDRESS_BY_NAME_MAP.get(name);
  }

  public static @NotEmpty List<String> getResponseAddresses() {
    return Stream.of(EventAddress.values())
        .map(EventAddress::getResponseAddress)
        .collect(Collectors.toList());
  }

  public static @NotEmpty List<String> getRequestAddresses() {
    return Stream.of(EventAddress.values())
        .map(EventAddress::getRequestAddress)
        .collect(Collectors.toList());
  }

  public static class Constants {
    public static final String ADAPTER_STATIC_QR_CREATE_ADDRESS =
        "epay.sbpadapter-static-qr-create-event-topic";
    public static final String GATEWAY_STATIC_QR_CREATE_ADDRESS =
        "epay.sbpgateway-static-qr-create-event-topic";
    public static final String ADAPTER_STATIC_QR_GET_ADDRESS =
        "epay.sbpadapter-static-qr-get-event-topic";
    public static final String GATEWAY_STATIC_QR_GET_ADDRESS =
        "epay.sbpgateway-static-qr-get-event-topic";
    public static final String ADAPTER_CASH_QR_CREATE_ADDRESS =
        "epay.sbpadapter-cash-qr-create-event-topic";
    public static final String GATEWAY_CASH_QR_CREATE_ADDRESS =
        "epay.sbpgateway-cash-qr-create-event-topic";
    public static final String ADAPTER_CASH_QR_ACTIVATE_ADDRESS =
        "epay.sbpadapter-cash-qr-activate-event-topic";
    public static final String GATEWAY_CASH_QR_ACTIVATE_ADDRESS =
        "epay.sbpgateway-cash-qr-activate-event-topic";
    public static final String ADAPTER_CASH_QR_DEACTIVATE_ADDRESS =
        "epay.sbpadapter-cash-qr-deactivate-event-topic";
    public static final String GATEWAY_CASH_QR_DEACTIVATE_ADDRESS =
        "epay.sbpgateway-cash-qr-deactivate-event-topic";
    public static final String ADAPTER_CASH_QR_STATUS_ADDRESS =
        "epay.sbpadapter-cash-qr-status-event-topic";
    public static final String GATEWAY_CASH_QR_STATUS_ADDRESS =
        "epay.sbpgateway-cash-qr-status-event-topic";
    public static final String ADAPTER_IMAGE_QR_ADDRESS =
        "epay.sbpadapter-image-qr-event-topic";
    public static final String GATEWAY_IMAGE_QR_ADDRESS =
        "epay.sbpgateway-image-qr-event-topic";
  }

}