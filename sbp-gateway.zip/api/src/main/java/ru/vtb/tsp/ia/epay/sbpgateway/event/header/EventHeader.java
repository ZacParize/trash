package ru.vtb.tsp.ia.epay.sbpgateway.event.header;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import javax.annotation.Nullable;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl.EventHeaderImpl;

@JsonDeserialize(as = EventHeaderImpl.class)
public interface EventHeader extends Serializable {

  @Nullable Object getFromContext(@NotNull ContextKey key);

  void setInContext(@NotNull ContextKey key, Object value);

  @NotEmpty String getCode();

  void setCode(@NotBlank String code);

  @NotBlank String getMstId();

  void setMstId(@NotBlank String mstId);

  @NotNull
  EventType getType();

  void setType(@NotNull EventType type);

  @NotEmpty List<EventAddress> getDestination();

  void setDestination(@NotEmpty List<EventAddress> destination);

  @NotNull LocalDateTime getSentAt();

  void setSentAt(@NotNull LocalDateTime sentAt);

}