package ru.vtb.tsp.ia.epay.sbpgateway.event.header.impl;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.EnumMap;
import java.util.List;
import java.util.Objects;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventAddress;
import ru.vtb.tsp.ia.epay.sbpgateway.event.EventType;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.ContextKey;
import ru.vtb.tsp.ia.epay.sbpgateway.event.header.EventHeader;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventHeaderImpl implements EventHeader, Serializable {

  @NotEmpty
  private EnumMap<ContextKey, Object> context = new EnumMap<>(ContextKey.class);

  @NotBlank
  private String code;

  @NotBlank
  private String mstId;

  @NotNull
  private EventType type;

  @NotEmpty
  private List<EventAddress> destination;

  @NotNull
  private LocalDateTime sentAt;

  @Override
  @NotNull
  public Object getFromContext(@NotBlank ContextKey key) {
    if (Objects.isNull(context)) {
      return null;
    }
    return context.get(key);
  }

  @Override
  public void setInContext(@NotBlank ContextKey key, Object value) {
    if (Objects.isNull(key) || Objects.isNull(context)) {
      return;
    }
    context.put(key, value);
  }
}