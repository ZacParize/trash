Internet acquiring, box, card info service

Installation instructions:

1) Clone environment project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-environment.git

2) Clone the project:

   git clone https://bitbucket.region.vtb.ru/scm/smbq/tsp-ia-box-cardinfo.git

3) Launch environment:

   cd tsp-ia-box-environment/docker

   docker-compose stop && docker-compose up -d

4) Launch card info service


