package ru.vtb.tsp.ia.epay.cardinfo.configs;

import org.springframework.boot.test.context.SpringBootTest;
import org.testcontainers.containers.KafkaContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import ru.vtb.tsp.ia.epay.cardinfo.containers.ConfluentKafkaContainer;

@SpringBootTest(classes = TestConfig.class)
@Testcontainers
public class BaseTest {

  @Container
  public static KafkaContainer kafkaContainer = ConfluentKafkaContainer.getInstance();

}