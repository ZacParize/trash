package ru.vtb.tsp.ia.epay.cardinfo.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import java.util.stream.Stream;
import javax.validation.constraints.NotEmpty;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import ru.vtb.tsp.ia.epay.cardinfo.configs.BaseTest;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.BankInfo;

class BankServiceTest extends BaseTest {

  @Value("${app.bankFileName}")
  @NotEmpty
  String fileName;

  @Autowired
  BankService bankService;

  @ParameterizedTest
  @NullAndEmptySource
  @ValueSource(strings = {" ", "\t", "\n"})
  void incorrectFileName(String fileName) {
    assertFalse(bankService.load(fileName));
  }

  @Test
  void correctFileName() {
    assertTrue(bankService.load(fileName));
  }

  static Stream<Arguments> provideCorrectBankParameters() {
    return Stream.of(
        Arguments.of("220008040000", new BankInfo("Россия",
            "Rossiya",
            "http://www.abr.ru",
            "#98c2dd",
            List.of("#eeeeee", "#98c2dd"),
            "light",
            "colored",
            "#07476e",
            "ru-rossiya",
            "ru",
            "ru-rossiya.svg")),
        Arguments.of("2200080435", new BankInfo("Россия",
            "Rossiya",
            "http://www.abr.ru",
            "#98c2dd",
            List.of("#eeeeee", "#98c2dd"),
            "light",
            "colored",
            "#07476e",
            "ru-rossiya",
            "ru",
            "ru-rossiya.svg")),
        Arguments.of("2200080432500000", new BankInfo("Россия",
            "Rossiya",
            "http://www.abr.ru",
            "#98c2dd",
            List.of("#eeeeee", "#98c2dd"),
            "light",
            "colored",
            "#07476e",
            "ru-rossiya",
            "ru",
            "ru-rossiya.svg")),
        Arguments.of("22000807999", new BankInfo("Россия",
            "Rossiya",
            "http://www.abr.ru",
            "#98c2dd",
            List.of("#eeeeee", "#98c2dd"),
            "light",
            "colored",
            "#07476e",
            "ru-rossiya",
            "ru",
            "ru-rossiya.svg")),
        Arguments.of("22000807999", new BankInfo("Россия",
            "Rossiya",
            "http://www.abr.ru",
            "#98c2dd",
            List.of("#eeeeee", "#98c2dd"),
            "light",
            "colored",
            "#07476e",
            "ru-rossiya",
            "ru",
            "ru-rossiya.svg")),
        Arguments.of("427622", new BankInfo("Сбербанк России",
            "Sberbank",
            "https://www.sberbank.ru",
            "#1a9f29",
            List.of("#1a9f29", "#0d7518"),
            "dark",
            "white",
            "#fff",
            "ru-sberbank",
            "ru",
            "ru-sberbank.svg")),
        Arguments.of("", new BankInfo(null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null)),
        Arguments.of(null, new BankInfo(null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null,
            null)));
  }

  @ParameterizedTest
  @MethodSource("provideCorrectBankParameters")
  void correctBankParameters(String cardNumber, BankInfo idealBankInfo) {
    correctFileName();
    assertEquals(bankService.find(cardNumber), idealBankInfo);
  }

}