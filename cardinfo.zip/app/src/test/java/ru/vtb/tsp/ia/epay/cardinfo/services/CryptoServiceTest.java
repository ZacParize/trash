package ru.vtb.tsp.ia.epay.cardinfo.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.stream.Stream;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import ru.vtb.tsp.ia.epay.cardinfo.configs.BaseTest;

class CryptoServiceTest extends BaseTest {

  @Autowired
  CryptoService cryptoService;


  static Stream<Arguments> provideEncryptedPAN() {
    return Stream.of(
        Arguments.of("kxj4/d/MNLG2Cbr+v70KlPQNWYPh5kdUkyTFca9pZ1TpWQ9UuJfFboqq7UZrFMsnCHoD4lzhQcoIu"
                + "vJaV97deuLORZ0r2B8WZCnyVz0dEnsgj5Exb0+z1SbPoQRToj0jvkwt3R6EAGX9U8w3NUpNjf9tcbEli"
                + "V9NKIFwfM84AAGKdVY8DzI3Kb6PCN84c30iXWT7oC12W3n91HafwZBzh6VJm+BX+WqsS9HCFVcURjXRx"
                + "lyEliGc1QYZ8nIRFg0ofjyhMPNvkFyIXDMhghsUh+8WUoReOmLc4E5Ar0pPl2SJKoFL09t1DipeygFHC"
                + "j7UbvTkVXFwLC4rs/RkE41B6w==",
            "IV1SbR5BNBdii/LboU0OfyFUljWA67ntu2Oy0mgQ+dOFIdNMly2bX91irYPxYbDNgHYY2iWeGBikcHzMjJxFPK"
                + "6Vdtnt1mFdJvRzyJ46EkAaJaYVajPzdROU7H07CpgBlPLuPDo6jqFotpaPYkQNLzXghzkj7RWbE7Fuc5"
                + "R5lvqjLR5d4Q51XMywxabIo3L/Dhajg6uLP9aFQY9KWVd81N8YzOA/BTYSmaLOpCBP0EcFrH8F26PcE5"
                + "4ClI6X5K/qMupy3z5NsF/9r24W0M9zcMFi/K7kcXSny144mTvjg0UWP8JuVT6tSLPuLPsOi4yyhB/XDq"
                + "D/HVl2nerJKcmKHA==",
            "D4444001234567890"),
        Arguments.of("", "", "Dnull")
    );
  }

  static Stream<Arguments> provideEncryptedDpan() {
    return Stream.of(
        Arguments.of("D4444001234567890", "4444001234567890")
    );
  }

  @ParameterizedTest
  @MethodSource("provideEncryptedPAN")
  void getDPAN(String encryptedPan, String encryptedCvv, String expected) {
    assertEquals(expected,
        cryptoService.getDpan("txId", encryptedPan, encryptedCvv).get().getDpan());
  }

  @ParameterizedTest
  @MethodSource("provideEncryptedDpan")
  void getPan(String dpan, String expected) {
    assertEquals(expected,
        cryptoService.getPanByDpan("txId", dpan).get().getPan());
  }

}