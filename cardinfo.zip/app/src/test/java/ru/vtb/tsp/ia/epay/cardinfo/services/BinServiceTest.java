package ru.vtb.tsp.ia.epay.cardinfo.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.stream.Stream;
import javax.validation.constraints.NotEmpty;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import ru.vtb.tsp.ia.epay.cardinfo.configs.BaseTest;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.BinInfo;

class BinServiceTest extends BaseTest {

  @Value("${app.binFileName}")
  @NotEmpty
  String fileName;

  @Autowired
  BinService binService;

  @ParameterizedTest
  @NullAndEmptySource
  @ValueSource(strings = {" ", "\t", "\n"})
  void incorrectFileName(String fileName) {
    assertFalse(binService.load(fileName));
  }

  @Test
  void correctFileName() {
    assertTrue(binService.load(fileName));
  }

  static Stream<Arguments> provideCorrectBinParameters() {
    return Stream.of(
        Arguments.of("220008040000", new BinInfo("BANK ROSSIYA", "MR")),
        Arguments.of("2200080435", new BinInfo("BANK ROSSIYA", "MR")),
        Arguments.of("2200080432500000", new BinInfo("BANK ROSSIYA", "MR")),
        Arguments.of("22000807999", new BinInfo("BANK ROSSIYA", "MR")),
        Arguments.of("", new BinInfo(null, null)),
        Arguments.of(null, new BinInfo(null, null)));
  }

  @ParameterizedTest
  @MethodSource("provideCorrectBinParameters")
  void correctBinParameters(String cardNumber, BinInfo idealBinInfo) {
    correctFileName();
    assertEquals(binService.find(cardNumber), idealBinInfo);
  }

}