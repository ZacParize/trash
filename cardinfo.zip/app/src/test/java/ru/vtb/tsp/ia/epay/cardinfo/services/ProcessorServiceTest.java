package ru.vtb.tsp.ia.epay.cardinfo.services;

import ru.vtb.tsp.ia.epay.cardinfo.configs.BaseTest;

class ProcessorServiceTest extends BaseTest {

}