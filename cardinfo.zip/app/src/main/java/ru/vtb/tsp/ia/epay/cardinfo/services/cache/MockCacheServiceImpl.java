package ru.vtb.tsp.ia.epay.cardinfo.services.cache;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
@ConditionalOnProperty(name = "spring.redis.mock", havingValue = "true")
public class MockCacheServiceImpl implements CacheService {

  private static final Map<String, Object> cache = new ConcurrentHashMap<String, Object>();

  @Override
  public void cache(String key, Object data) {
    cache.put(key, data);
  }

  @Override
  public void set(String key, Object data) {
    if (data instanceof Map) {
      cache.put(key, new HashMap<>((Map<String, Object>) data));
    } else {
      cache.put(key, data);
    }
  }

  @Override
  public Object get(String key) {
    return cache.get(key);
  }
}
