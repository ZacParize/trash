package ru.vtb.tsp.ia.epay.cardinfo.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.regex.Pattern;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MaskService {

  private final ObjectMapper objectMapper;
  private static final Pattern PAN_REGEX = Pattern.compile("\"pan\"\\s*:\\s*\"([0-9 ]+)\"");
  private static final Pattern CVV_REGEX = Pattern.compile("\"cvv\"\\s*:\\s*\"(\\d+)\"");

  public String maskData(byte[] bodyData) {
    try {
      final Serializable obj = objectMapper.readValue(bodyData, Serializable.class);
      final var bodyStr = objectMapper.writeValueAsString(obj);
      var result = maskPan(bodyStr);
      return maskCvv(result);
    } catch (Exception e) {
      return new String(bodyData, StandardCharsets.UTF_8);
    }

  }

  private String maskPan(String body) {
    return mask(PAN_REGEX, body, 6, 4);
  }

  private String maskCvv(String body) {
    return mask(CVV_REGEX, body, 0, 0);
  }

  private String mask(Pattern panPattern, String body, int showFirstDigitCount,
      int showLastDigitCount) {
    final var m = panPattern.matcher(body);
    while (m.find()) {
      if (m.groupCount() > 0) {
        final var oldValue = m.group(1);
        final var newValue = Utils.mask(oldValue, showFirstDigitCount, showLastDigitCount);
        body = body.replaceAll(oldValue, newValue);
        return body;
      }
    }
    return body;
  }
}