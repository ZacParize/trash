package ru.vtb.tsp.ia.epay.cardinfo.services.exceptions;

public class DecriptEncryptException extends ServiceException {

  public DecriptEncryptException() {
    super(ApplicationException.DECRYPT_ENCRYPT_EXCEPTION, null);
  }

}