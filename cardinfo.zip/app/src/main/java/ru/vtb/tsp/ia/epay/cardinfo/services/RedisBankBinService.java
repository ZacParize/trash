package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;
import javax.annotation.PostConstruct;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class RedisBankBinService {

  private static final ExecutorService EXECUTOR_SERVICE = Executors.newFixedThreadPool(2);

  private final BankService bankService;
  private final BinService binService;
  private volatile boolean bankAndBinCacheIsLoaded;


  @PostConstruct
  @Scheduled(cron = "0 0 * ? * *")
  public void init() {
    if (!bankAndBinCacheIsLoaded) {
      log.info("Start Bank and Bin cache is warming up");
      AtomicInteger cacheCount = new AtomicInteger(2);
      EXECUTOR_SERVICE.submit(new ThreadWorker<>(() -> {
        final var result = bankService.load();
        isCacheLoaded(result, cacheCount);
        return result;
      }));
      EXECUTOR_SERVICE.submit(new ThreadWorker<>(() -> {
        final var result = binService.load();
        isCacheLoaded(result, cacheCount);
        return result;
      }));
    }
  }

  private void isCacheLoaded(boolean result, AtomicInteger cacheCount) {
    if (result) {
      if (0 == cacheCount.decrementAndGet()) {
        bankAndBinCacheIsLoaded = true;
        log.info("Bank and bin cache is warm up");
      }
    }
  }

  @AllArgsConstructor
  private static class ThreadWorker<T> implements Callable<T> {

    private final Supplier<T> supplier;

    @Override
    public T call() {
      return supplier.get();
    }
  }

}
