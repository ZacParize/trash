package ru.vtb.tsp.ia.epay.cardinfo.services.cache;


public interface CacheService {

  void cache(final String key, final Object data);

  void set(final String key, final Object data);

  Object get(final String key);
}
