package ru.vtb.tsp.ia.epay.cardinfo.configs;

import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.scheduling.annotation.EnableScheduling;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;

@Slf4j
@Configuration
@EnableKafka
@EnableScheduling
@Import(MessageAdapter.class)
@ComponentScan(basePackages = {"ru.vtb.tsp.ia.epay.cardinfo", "ru.vtb.tsp.ia.epay.core.utils",
    "ru.vtb.tsp.ia.epay.core.configurations"})
public class AppConfig {
}