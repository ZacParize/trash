package ru.vtb.tsp.ia.epay.cardinfo.client;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import ru.vtb.tsp.ia.epay.cardinfo.client.api.CryptoApi;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.CvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.DpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.DpanPublicKeyDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedCvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedCvvPublicKeyDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedPanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.ExtDpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.PanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.PublicKeyDto;

@Component
@ConditionalOnProperty(name = "app.crypto.mock", havingValue = "true")
@Slf4j
public class MockCryptoClient implements CryptoApi {

  public static final String PAN_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnZybMhwT"
      + "y16IoBRotiLW1O6T3+V1LrRweXMU8lsZO0dMqrUyCd92PdRlgcLPe2wPXwa4QxR6uumLwlDickKzX2fu6x4jFFhajW"
      + "T6nThoo9eRdHT5UoafsjnR2QPxgKo0/5GoghgYJbqGAmMPc5jKNzpd80/sWYOheIF9JISmvGAzLB5sCh+QpnfDwCD6"
      + "60SPq74Q7rH4Rfi7UkWF85x0NSi5rXlsTMXvbdjo4qSBEojYIy3rLuiVJ8ebypLzEuM4Xv4bLmefxmAdMiTrBau6RQ"
      + "MrYA9fKJ0ZDK6JclDY9MzPQYHD3A/eXm1avogl4g+5i2LrQdyLVV5FaJU7wCT6gwIDAQAB";
  public static final String CVV_PUBLIC_KEY = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnZybMhwT"
      + "y16IoBRotiLW1O6T3+V1LrRweXMU8lsZO0dMqrUyCd92PdRlgcLPe2wPXwa4QxR6uumLwlDickKzX2fu6x4jFFhajW"
      + "T6nThoo9eRdHT5UoafsjnR2QPxgKo0/5GoghgYJbqGAmMPc5jKNzpd80/sWYOheIF9JISmvGAzLB5sCh+QpnfDwCD6"
      + "60SPq74Q7rH4Rfi7UkWF85x0NSi5rXlsTMXvbdjo4qSBEojYIy3rLuiVJ8ebypLzEuM4Xv4bLmefxmAdMiTrBau6RQ"
      + "MrYA9fKJ0ZDK6JclDY9MzPQYHD3A/eXm1avogl4g+5i2LrQdyLVV5FaJU7wCT6gwIDAQAB";
  public static final String PRIVATE_KEY = "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCdnJs"
      + "yHBPLXoigFGi2ItbU7pPf5XUutHB5cxTyWxk7R0yqtTIJ33Y91GWBws97bA9fBrhDFHq66YvCUOJyQrNfZ+7rHiMUW"
      + "FqNZPqdOGij15F0dPlShp+yOdHZA/GAqjT/kaiCGBgluoYCYw9zmMo3Ol3zT+xZg6F4gX0khKa8YDMsHmwKH5Cmd8P"
      + "AIPrrRI+rvhDusfhF+LtSRYXznHQ1KLmteWxMxe9t2OjipIESiNgjLesu6JUnx5vKkvMS4zhe/hsuZ5/GYB0yJOsFq"
      + "7pFAytgD18onRkMrolyUNj0zM9BgcPcD95ebVq+iCXiD7mLYutB3ItVXkVolTvAJPqDAgMBAAECggEAbK0gYfP0PiV"
      + "n5aFM9lGdemMrOZXZMCQg7c1JYzcndbVbCtY3s5EO0eFTQJ8YO40uKCLVCQPlAF6rDIiDK7AMSLu8hQhZvdySS66WE"
      + "7Riip7IX9mMVLgZA2ZU6OOMMWCrfJFt9I4ykElFv/2YGOgAfwZS48N3P93Ah/wZUwXYhkhgQmPd9pbhWM9JQyeHxvZ"
      + "Ez4ov6lesd7DpmCXzNop7SS0XnGFHR03QXcKcWT1lYJcSgHxl0w4Idb6/tCsu00ix4LNFgEBRep7t3zMoXdcpBHpE1"
      + "GO4p31d6U1CfXN99d94Q/820P1L3OqwHH8/qjzFtDwiavA6gffJ1568PzWhAQKBgQD1jbvRF8RTsCEHe2LhglTcFwg"
      + "0wEE55HKb0FoUT1mImt6xheCBiJW/3TgRkSaBbdTgUAViFDDG9c5y36BYBZfR56vsyJZ1qKMMinRSA9C65/bK3bW6E"
      + "HYmAoSAGCxxd7WeiSgzLcTcjNciegLwzmj9sUKoScmY4CL0sSiJJSYXAwKBgQCkUR5D5O5Wnwk9/yjNPWq0DVwlIi2"
      + "EXkl4j/0cfhMhbEw8nc++678/kj4zJ/IhK2NababXwBU7NbvVJ3ULZkMMirNRyk+q6ZbJ9DPTj8qb9FVGEQLa+sLyY"
      + "91Gkh5+RBMa4OdQBK3tGakiqPGF5d6DPZ99gwBLilrsBGGz1ch2gQKBgQDDeVfZZM0iPeSdOykFEiaRqjgbHi0OdAC"
      + "UbzE2V9CTgY3jzgphs6RaPzWiLmVzxUYgZzNR13bY+9aj9ceEKreoHn/rl+bGtT9O/W0J2QWxtHTvG73N58rWCU0HV"
      + "7cRgNVw5gi9bSL425lrVau/nOFRi2nf5BV7AHpzRhBZ1NvUlwKBgGS0qp3l4wUHt3xds74GFC2BuqWvisIDn3fal8A"
      + "srMDhROApwDc8+RuXH7PumYEmvF+hsI2uVdTSG+qJojx4UkOPhlNscONJAneHyXOyPvTSDKlCp8NZyL0R433q8/Fi+"
      + "2qPyHTMSWR1Q6nQbSYpOfSpgeREs5uYkhzwmojDT3cBAoGBAIVYZ3RLLNlp5p11jTr6q7KYnfNNonNxpidnjlhnHeI"
      + "FVRgR4iouPp8OlHkmeg0jdlFrLwvEWuarNjcd8yVmieC8nFnPOYaSa64RJh2Kseq4oBrSuz8YHHK04D5SvzSW6acfa"
      + "dz3gz5itHV/Y3Hn3iaBBVHOe8k0l/MCS4OGNF/W";

  private PrivateKey privateKey;
  private PublicKey publicKey;

  public MockCryptoClient() {
    X509EncodedKeySpec keySpecPublic = new X509EncodedKeySpec(decode(PAN_PUBLIC_KEY));
    PKCS8EncodedKeySpec keySpecPrivate = new PKCS8EncodedKeySpec(decode(PRIVATE_KEY));

    KeyFactory keyFactory = null;
    try {
      keyFactory = KeyFactory.getInstance("RSA");
      publicKey = keyFactory.generatePublic(keySpecPublic);
      privateKey = keyFactory.generatePrivate(keySpecPrivate);
    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    } catch (InvalidKeySpecException e) {
      e.printStackTrace();
    }
  }

  @Override
  public ResponseEntity<PublicKeyDto> getPublicKey() {
    return ResponseEntity.ok(new PublicKeyDto(PAN_PUBLIC_KEY));
  }

  @Override
  public ResponseEntity<PublicKeyDto> getCvvPublicKey() {
    return ResponseEntity.ok(new PublicKeyDto(CVV_PUBLIC_KEY));
  }

  @Override
  public ResponseEntity<CvvDto> getCVVbyEncCVV(EncryptedCvvDto encryptedCvvDto) {
    return ResponseEntity.ok(new CvvDto(decryptString(encryptedCvvDto.getEncryptedCvv())));
  }

  @Override
  public ResponseEntity<EncryptedCvvDto> getEncCVVbyEncCVV(
      EncryptedCvvPublicKeyDto encryptedCvvPublicKeyDto) {
    return null;
  }

  @Override
  public ResponseEntity<DpanDto> getDPANbyEncPAN(EncryptedPanDto encryptedPanDto) {
    return ResponseEntity.ok(new DpanDto(decryptString(encryptedPanDto.getEncryptedPan())));
  }

  @Override
  public ResponseEntity<ExtDpanDto> getDPANbyEncPANExt(EncryptedPanDto encryptedPanDto) {
    String pan = decryptString(encryptedPanDto.getEncryptedPan());
    return ResponseEntity.ok(new ExtDpanDto(panToDpan(pan), pan));
  }

  @Override
  public ResponseEntity<EncryptedPanDto> getEncPANbyDPAN(DpanPublicKeyDto dpanPublicKeyDto) {
    return null;
  }

  @Override
  public ResponseEntity<DpanDto> getDPANbyPAN(PanDto panDto) {
    return ResponseEntity.ok(new DpanDto(panToDpan(panDto.getPan())));
  }

  @Override
  public ResponseEntity<PanDto> getPANbyDPAN(DpanDto dpanDto) {
    return ResponseEntity.ok(new PanDto(dpanDto.getDpan().substring(1)));
  }


  private static String encode(byte[] data) {
    return Base64.getEncoder().encodeToString(data);
  }

  private static byte[] decode(String data) {
    return Base64.getDecoder().decode(data);
  }


  private String decryptString(String encryptString) {
    byte[] encryptedBytes = decode(encryptString);
    Cipher cipher = null;
    try {
      cipher = Cipher.getInstance("RSA");
      cipher.init(Cipher.DECRYPT_MODE, privateKey);
      byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
      String decryptString = new String(decryptedMessage, "UTF8");
      log.info("decrypted String {}", decryptString);
      return decryptString;
    } catch (Exception e) {
      log.error(e.getMessage());
    }
    return null;
  }

  private static String panToDpan(String pan) {
    return "D" + pan;
  }
}
