package ru.vtb.tsp.ia.epay.cardinfo.configs.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "spring.redis")
public class RedisProperties {

  private Integer database;
  private String host;
  private Integer port;
  private Boolean ssl;
  private boolean supportUsername;
  private String username;
  private String password;
  private Long connectTimeout;
  private Integer maxActive;
  private Integer maxIdle;
  private Integer minIdle;
  private Integer maxWait;

}
