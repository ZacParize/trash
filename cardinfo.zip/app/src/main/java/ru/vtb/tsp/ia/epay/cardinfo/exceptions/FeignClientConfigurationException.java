package ru.vtb.tsp.ia.epay.cardinfo.exceptions;

public class FeignClientConfigurationException extends RuntimeException {

  public FeignClientConfigurationException(Throwable cause) {
    super(cause);
  }
}
