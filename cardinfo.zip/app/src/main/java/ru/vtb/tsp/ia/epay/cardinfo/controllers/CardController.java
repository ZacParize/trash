package ru.vtb.tsp.ia.epay.cardinfo.controllers;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static ru.vtb.tsp.ia.epay.cardinfo.App.VERSION_URL;
import static ru.vtb.tsp.ia.epay.cardinfo.controllers.CardController.URL;

import javax.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.CardRequestDto;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.DpanRequestDto;
import ru.vtb.tsp.ia.epay.cardinfo.services.CryptoService;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;

@RestController
@RequiredArgsConstructor
@RequestMapping(value = VERSION_URL + URL, produces = APPLICATION_JSON_VALUE)
public class CardController {

  public static final String URL = "/card";

  private final CryptoService cryptoService;

  @PostMapping(path = "/decrypt", consumes = APPLICATION_JSON_VALUE)
  public CardCacheDto getCardData(@RequestBody @Valid CardRequestDto dto) {
    return cryptoService.getDpan(dto.getTransactionId(), dto.getEncryptedPan(),
            dto.getEncryptedCvv())
        .orElseThrow(IllegalStateException::new);
  }

  @PostMapping(path = "/dpan/decrypt", consumes = APPLICATION_JSON_VALUE)
  public CardCacheDto get(@RequestBody @Valid DpanRequestDto dto) {
    return cryptoService.getPanByDpan(dto.getTransactionId(), dto.getDpan())
        .orElseThrow(IllegalStateException::new);
  }
}

