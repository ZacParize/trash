package ru.vtb.tsp.ia.epay.cardinfo.services.cache;


import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import java.time.Duration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.cardinfo.configs.RedisConfig;

@Slf4j
@Service
@ConditionalOnProperty(name = "spring.redis.mock", havingValue = "false")
public class RedisCacheServiceImpl implements CacheService {

  private final ValueOperations<String, Object> valueOps;

  public RedisCacheServiceImpl(RedisTemplate<String, Object> redisTemplate) {
    valueOps = redisTemplate.opsForValue();
  }

  @CircuitBreaker(name = RedisConfig.REDIS_CIRCUIT_BREAKER, fallbackMethod = "cacheFallBackMethod")
  public void cache(final String key, final Object data) {
    log.info("Cached data to redis with key = {}", key);
    valueOps.set(key, data, Duration.ofMinutes(15L));
  }

  public void cacheFallBackMethod(Throwable throwable) {
    log.info("cacheFallBackMethod invoked due to error:", throwable);
  }

  @CircuitBreaker(name = RedisConfig.REDIS_CIRCUIT_BREAKER)
  public void set(final String key, final Object data) {
    valueOps.set(key, data);
  }

  @CircuitBreaker(name = RedisConfig.REDIS_CIRCUIT_BREAKER)
  public Object get(final String key) {
    return valueOps.get(key);
  }
}
