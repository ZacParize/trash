package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiFunction;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.KafkaHeaders;
import org.springframework.kafka.support.SendResult;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.concurrent.ListenableFutureCallback;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

@Slf4j
@Service
public class KafkaService {

  private final KafkaTemplate<String, Object> kafkaTemplate;
  private final List<String> producerTopics;
  private final List<String> dlqTopics;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForBox;
  private final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>>
      callbackFactoryForDlq;

  public KafkaService(KafkaTemplate<String, Object> kafkaTemplate,
      @Value("${app.kafka.producer.topics}") List<String> producerTopics,
      @Value("${app.kafka.dlq-topics}") List<String> dlqTopics) {
    this.kafkaTemplate = kafkaTemplate;
    this.producerTopics = Objects.requireNonNullElse(producerTopics, Collections.emptyList());
    this.dlqTopics = Objects.requireNonNullElse(dlqTopics, Collections.emptyList());
    this.callbackFactoryForBox = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Transaction {} is processed with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending transaction {} to next route point {}", key, topic, ex);
      }
    };
    this.callbackFactoryForDlq = (topic, key) -> new ListenableFutureCallback<>() {
      @Override
      public void onSuccess(@NotNull SendResult<String, ?> result) {
        log.info("Message {} is sent to dlq with result {}", key, result);
      }

      @Override
      public void onFailure(@NotNull Throwable ex) {
        log.error("Error during sending message {} to portal {}", key, topic, ex);
      }
    };
  }

  public void sendToDlq(@Nullable Object message) {
    Optional.ofNullable(message)
        .ifPresent(tx -> send(message, message.toString()));
  }

  public void sendToBox(@Nullable TransactionPayload payload) {
    Optional.ofNullable(payload).ifPresent(tx -> send(tx, tx.getTransactionId()));
  }

  private void send(@Nullable Object payload, String key) {
    if (Objects.isNull(payload) || ObjectUtils.isEmpty(key)) {
      return;
    }
    final Map<String, Object> headers = new HashMap<>();
    headers.put(KafkaHeaders.MESSAGE_KEY, key);
    final List<String> topics;
    final BiFunction<String, String, ListenableFutureCallback<SendResult<String, ?>>> callback;
    if (payload instanceof TransactionPayload) {
      topics = producerTopics;
      callback = callbackFactoryForBox;
    } else {
      topics = dlqTopics;
      callback = callbackFactoryForDlq;
    }
    topics.forEach(topic -> {
      headers.remove(KafkaHeaders.TOPIC);
      headers.put(KafkaHeaders.TOPIC, topic);
      kafkaTemplate.send(new GenericMessage<>(payload, headers))
          .addCallback(callback.apply(topic, key));
    });
  }

}