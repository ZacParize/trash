package ru.vtb.tsp.ia.epay.cardinfo.services.exceptions;

import javax.annotation.Nullable;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

public class PanValidationException extends ServiceException {

  public PanValidationException(@Nullable TransactionPayload payload) {
    super(ApplicationException.PAN_VALIDATION_EXCEPTION, payload);
  }

}