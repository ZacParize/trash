package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.cardinfo.services.payments.CardPaymentProcessor;
import ru.vtb.tsp.ia.epay.cardinfo.services.payments.CofPaymentProcessor;
import ru.vtb.tsp.ia.epay.cardinfo.services.payments.PaymentProcessor;
import ru.vtb.tsp.ia.epay.core.domains.enums.CofOperation;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;

@Service
@Slf4j
@RequiredArgsConstructor
public class TokenizationService {

  private final Map<String, PaymentProcessor> paymentProcessorMap;

  public @NotNull Optional<TransactionPayload> handle(TransactionPayload payload) {
    return Optional.ofNullable(payload)
        .map(tx -> {
          //cof платежи, только если CofOperation.PAYMENT
          if ((!tx.isCompleted() && tx.getPaymentData() instanceof Card)
              && (Objects.equals(CofOperation.PAYMENT,
              ((Card) tx.getPaymentData()).getCofOperation()))) {
            paymentProcessorMap.get(CofPaymentProcessor.BEAN_NAME).handle(tx);
          } else if (!tx.isCompleted() && tx.getPaymentData() instanceof Card) {
            paymentProcessorMap.get(CardPaymentProcessor.BEAN_NAME).handle(tx);
          }
          return tx;
        });
  }
}