package ru.vtb.tsp.ia.epay.cardinfo.configs;

import feign.Logger;
import feign.Response;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import ru.vtb.tsp.ia.epay.cardinfo.services.MaskService;

@Slf4j
public class FeignLogger extends Logger {

  private final MaskService maskService;

  public FeignLogger(MaskService maskService) {
    this.maskService = maskService;
  }


  @Override
  protected Response logAndRebufferResponse(String configKey, Level logLevel, Response response,
      long elapsedTime) throws IOException {
    byte[] bodyData = IOUtils.toByteArray(response.body().asReader(StandardCharsets.UTF_8),
        StandardCharsets.UTF_8);
    if (logLevel.ordinal() >= Level.FULL.ordinal() && bodyData.length > 0) {
      log(configKey, "%s", maskService.maskData(bodyData));
      log(configKey, "<--- END HTTP (%s-byte body)", bodyData.length);
      return response.toBuilder().body(bodyData).build();
    } else {
      return super.logAndRebufferResponse(configKey, logLevel, response, elapsedTime);
    }
  }

  @Override
  protected void log(String configKey, String format, Object... args) {
    log.debug(format(configKey, format, args));
  }

  protected String format(String configKey, String format, Object... args) {
    return String.format(methodTag(configKey) + format, args);
  }
}