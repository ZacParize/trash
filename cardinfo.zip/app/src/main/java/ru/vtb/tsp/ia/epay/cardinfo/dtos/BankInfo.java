package ru.vtb.tsp.ia.epay.cardinfo.dtos;

import java.io.Serializable;
import java.util.List;
import lombok.Value;

@Value
public class BankInfo implements Serializable {

  public static BankInfo EMPTY_BANK_INFO = new BankInfo(null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null,
      null);

  String name;
  String nameEn;
  String url;
  String backgroundColor;
  List<String> backgroundColors;
  String backgroundLightness;
  String logoStyle;
  String text;
  String alias;
  String country;
  String logoSvg;

}