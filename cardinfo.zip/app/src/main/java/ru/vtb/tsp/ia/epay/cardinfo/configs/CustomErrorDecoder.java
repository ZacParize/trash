package ru.vtb.tsp.ia.epay.cardinfo.configs;

import feign.Response;
import feign.codec.ErrorDecoder;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.CryptographyException;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.DecriptEncryptException;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.ObsoleteKeyException;

public class CustomErrorDecoder implements ErrorDecoder {

  private static final String OBSOLETE_KEY = "The text is encrypted with an obsolete key";
  private static final String FAILED_DECRYPT = "Failed to decrypt an encrypted text";
  private final ErrorDecoder defaultErrorDecoder = new Default();

  @Override
  public Exception decode(String methodKey, Response response) {
    final var status = HttpStatus.valueOf(response.status());
    if (!status.is2xxSuccessful()) {
      try {
        final var body = IOUtils.toString(response.body().asReader(StandardCharsets.UTF_8));
        switch (body) {
          case OBSOLETE_KEY:
            return new ObsoleteKeyException();
          case FAILED_DECRYPT:
            return new DecriptEncryptException();
          default:
            return new CryptographyException();
        }
      } catch (Exception ignored) {
        return new CryptographyException();
      }
    } else {
      return defaultErrorDecoder.decode(methodKey, response);
    }
  }
}
