package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.Objects;
import java.util.Optional;
import javax.annotation.Nullable;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.PanValidationException;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.ServiceException;
import ru.vtb.tsp.ia.epay.core.domains.exceptions.TransactionError;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.entities.order.OrderState;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionState;
import ru.vtb.tsp.ia.epay.core.services.MessageAdapter;

@Slf4j
@Service
public class ProcessorService implements GenericTransformer<Object, TransactionPayload> {

  private static final long TIMEOUT = 1000;

  private final String applicationName;
  private final TokenizationService tokenizationService;
  private final KafkaService kafkaService;
  private final MessageAdapter messageAdapter;

  public ProcessorService(TokenizationService tokenizationService,
      KafkaService kafkaService,
      MessageAdapter messageAdapter,
      @Value("${spring.application.name}") String applicationName) {
    Assert.hasText(applicationName, "Application name can't be null or empty");
    this.tokenizationService = tokenizationService;
    this.kafkaService = kafkaService;
    this.messageAdapter = messageAdapter;
    this.applicationName = applicationName;
  }

  @Override
  public @Nullable
  TransactionPayload transform(@Nullable Object source) {
    return Optional.ofNullable(messageAdapter.deserialize(source))
        .orElseGet(() -> {
          kafkaService.sendToDlq(source);
          return null;
        });
  }

  //@Transactional(transactionManager = "transactionManager")
  @KafkaListener(topics = "${app.kafka.consumer.topics}",
      containerFactory = "kafkaListenerContainerFactory")
  public void process(@NotNull ConsumerRecord<String, ?> record,
      @NotNull Acknowledgment acknowledgment) {
    boolean nack = false;
    final var transaction = transform(record.value());
    try {
      Optional.ofNullable(transaction)
          .map(tp -> {
            tp.getRoute().addVisitedService(applicationName);
            return tp;
          })
          .flatMap(tokenizationService::handle)
          .ifPresent(kafkaService::sendToBox);
    } catch (ServiceException ex) {
      handle(ex, transaction).ifPresent(kafkaService::sendToBox);
    } catch (Exception ex) {
      kafkaService.sendToDlq(record.value());
      log.error("Transaction can't be processed", ex);
    } finally {
      if (!nack) {
        acknowledgment.acknowledge();
      } else {
        acknowledgment.nack(TIMEOUT);
      }
    }
  }

  private @NotNull Optional<TransactionPayload> handle(@Nullable ServiceException exception,
      @Nullable TransactionPayload payload) {
    if (Objects.isNull(exception) || Objects.isNull(payload)) {
      return Optional.of(payload);
    }
    if (exception instanceof PanValidationException) {
      if (Objects.nonNull(payload.getOrderInfo()) && payload.getOrderInfo().isTransfer()) {
        payload.getOrderInfo().setOrderState(OrderState.REJECTED);
      }
    }
    payload.setError(TransactionError.builder()
        .id(exception.getId())
        .httpCode(exception.getHttpCode())
        .message(exception.getMessage())
        .description(exception.getDescription())
        .traceId(payload.getTransactionCode())
        .build());
    payload.setStatus(TransactionState.DECLINED);
    return Optional.of(payload);
  }

}