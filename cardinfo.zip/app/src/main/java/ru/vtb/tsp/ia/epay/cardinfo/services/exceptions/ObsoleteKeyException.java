package ru.vtb.tsp.ia.epay.cardinfo.services.exceptions;

public class ObsoleteKeyException extends ServiceException {

  public ObsoleteKeyException() {
    super(ApplicationException.OBSOLETE_KEY_EXCEPTION, null);
  }

}