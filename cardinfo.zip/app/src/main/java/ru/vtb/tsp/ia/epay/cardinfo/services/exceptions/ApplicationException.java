package ru.vtb.tsp.ia.epay.cardinfo.services.exceptions;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;

@Getter
@RequiredArgsConstructor
@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum ApplicationException {

  CRYPTOGRAPHY_EXCEPTION("10300001", HttpStatus.BAD_REQUEST.value(),
      "CRYPTOGRAPHY_EXCEPTION", "Внутренняя ошибка"),
  PAN_VALIDATION_EXCEPTION("10300002", HttpStatus.BAD_REQUEST.value(),
      "PAN_VALIDATION_EXCEPTION", "Платеж отклонен. Проверьте реквизиты платежа"),
  OBSOLETE_KEY_EXCEPTION("10300003", HttpStatus.BAD_REQUEST.value(),
      "OBSOLETE_KEY_EXCEPTION", "Устаревший публичный ключ"),
  DECRYPT_ENCRYPT_EXCEPTION("10300004", HttpStatus.BAD_REQUEST.value(),
      "DECRYPT_ENCRYPT_EXCEPTION", "Устаревший публичный ключ");

  private final String id;
  private final Integer httpCode;
  private final String message;
  private final String description;

}
