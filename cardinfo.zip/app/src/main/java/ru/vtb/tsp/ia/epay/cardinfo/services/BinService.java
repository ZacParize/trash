package ru.vtb.tsp.ia.epay.cardinfo.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.BinInfo;
import ru.vtb.tsp.ia.epay.cardinfo.services.cache.CacheService;

@Slf4j
@Service
public class BinService {

  public static final String HIGH_RANGE = "high";
  public static final String LOW_RANGE = "low";
  private static final String BIN_PREFIX = "BIN_";
  private static final int PREFIX_LENGTH = 6;
  private static final String PAYSYSTEM = "paysystem";
  private static final String BANK = "issuer";
  private static final String DEFAULT_VALUE = "unknown";
  private final ObjectMapper objectMapper;
  private final CacheService redisCache;
  private final String fileName;

  public BinService(@NotNull ObjectMapper objectMapper,
      @Value("${app.binFileName}") @NotEmpty String fileName, CacheService redisCache) {
    this.objectMapper = objectMapper;
    this.redisCache = redisCache;
    this.fileName = fileName;
  }

  protected boolean load() {
    return load(this.fileName);
  }

  protected boolean load(@Nullable String fileName) {
    if (ObjectUtils.isEmpty(fileName)) {
      return false;
    }
    try (final var inputStream = getClass().getResourceAsStream(fileName)) {

      if (Objects.isNull(inputStream)) {
        return false;
      }
      log.info("Bin configuration would be loaded from file {}", fileName);
      final Map<String, Map<String, Map<String, Object>>> binMap = objectMapper.readValue(
          inputStream.readAllBytes(),
          new TypeReference<>() {
          });
      final Map<String, Object> map = new LinkedHashMap<>();
      binMap.forEach((externalKey, externalValue) -> {
        externalValue.forEach((key, value) -> {
          final var paySystem = (String) value.get("paysystem");
          final var lowRange = (String) value.get("low");
          final var highRange = (String) value.get("high");
          final var group = paySystem + "|" + lowRange + "|" + highRange;
          map.put(group, getRedisMap(value));
        });
        redisCache.set(BIN_PREFIX + externalKey, map);
        map.clear();
      });
      log.info("Bin configuration was successfully loaded from file {}", fileName);
      return true;
    } catch (IOException | NullPointerException e) {
      log.error("Exception during processing bin configuration file {}", fileName, e);
      return false;
    } catch (Exception e) {
      log.error("Error occurred during warm up bank and bin cache", e);
      return false;
    }
  }


  public BinInfo find(@Nullable String cardNumber) {
    if (ObjectUtils.isEmpty(cardNumber)) {
      return BinInfo.EMPTY_BIN;
    }
    log.info("Search bin information by card number {}", Utils.getMaskedDpan(cardNumber));
    final var map = (Map<String, Object>) redisCache.get(BIN_PREFIX
        + cardNumber.substring(0, Math.min(PREFIX_LENGTH, cardNumber.length())));
    if (Objects.nonNull(map)) {
      final var resultMap = cardNumber.length() <= PREFIX_LENGTH
          ? searchByPrefix(Optional.of(map)) : searchByCardNumber(Optional.of(map), cardNumber);
      if (resultMap.size() == 0) {
        log.info("No bin information found by card number {}", Utils.getMaskedDpan(cardNumber));
      } else {
        log.info("Bin information found {} by card number {}", resultMap,
            Utils.getMaskedDpan(cardNumber));
      }
      return decorate(resultMap);
    } else {
      log.info("No bin information found by card number {}", Utils.getMaskedDpan(cardNumber));
      return BinInfo.EMPTY_BIN;
    }
  }

  private Map<String, Object> searchByPrefix(
      @NotNull Optional<Map<String, Object>> nodeForSearching) {
    return nodeForSearching.map(node -> {
      final Map<String, Object> binData = new LinkedHashMap<>();
      getUniquePaysystem(node).ifPresent(e -> binData.put(PAYSYSTEM, e));
      getUniqueBank(node, null).ifPresent(e -> binData.put(BANK, e));
      return binData.entrySet()
          .stream()
          .sorted(Map.Entry.comparingByKey())
          .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
              (oldValue, newValue) -> oldValue, LinkedHashMap::new));
    }).orElse(null);
  }

  private Map<String, Object> searchByCardNumber(
      @NotNull Optional<Map<String, Object>> nodeForSearching,
      @NotEmpty String cardNumber) {
    return nodeForSearching.map(node -> {
      final Map<String, Object> binData = new LinkedHashMap<>();
      getUniquePaysystem(node).ifPresent(e -> binData.put(PAYSYSTEM, e));
      getUniqueBank(node, cardNumber).ifPresent(e -> binData.put(BANK, e));
      return (Map<String, Object>) binData.entrySet()
          .stream()
          .sorted(Map.Entry.comparingByKey())
          .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
              (oldValue, newValue) -> oldValue, LinkedHashMap::new));
    }).orElse(Collections.emptyMap());
  }

  private Optional<String> getUniquePaysystem(@NotNull Map<String, Object> node) {
    final var list = node.entrySet().stream()
        .map(entry -> (Map<String, Object>) entry.getValue())
        .map(entry2 -> entry2.get(PAYSYSTEM)).distinct().collect(Collectors.toList());
    if (list.size() > 1) {
      return Optional.empty();
    }
    return Optional.of(list.get(0).toString());
  }

  private Optional<String> getUniqueBank(@NotNull Map<String, Object> node,
      @Nullable String cardNumber) {
    final var banks = new HashSet<String>();
    String lowRange;
    String highRange;
    String tempCardNumber;
    int minLength;
    for (Entry<String, Object> entry : node.entrySet()) {
      Map<String, Object> map = (Map<String, Object>) entry.getValue();
      if (StringUtils.isNotEmpty(cardNumber)) {
        if (map.containsKey(BANK) && map.containsKey(LOW_RANGE)
            && map.containsKey(HIGH_RANGE)) {
          lowRange = (String) map.get(LOW_RANGE);
          highRange = (String) map.get(HIGH_RANGE);
          minLength = Math.min(cardNumber.length(),
              Math.min(lowRange.length(), highRange.length()));
          tempCardNumber = cardNumber.substring(0, minLength);
          if (tempCardNumber.compareTo(lowRange.substring(0, minLength)) >= 0
              && tempCardNumber.compareTo(highRange.substring(0, minLength)) <= 0) {
            banks.add((String) map.get(BANK));
          }
        }
      } else {
        banks.add((String) map.get(BANK));
      }
    }
    return banks.size() == 1 ? Optional.of(banks.iterator().next()) : Optional.empty();
  }

  private BinInfo decorate(@NotNull Map<String, Object> map) {
    final var bank = (String) map.getOrDefault(BANK, null);
    final var paysystem = (String) map.getOrDefault(PAYSYSTEM, null);
    log.info("Decorate bin information, bank {}, paysystem {}", bank, paysystem);
    return new BinInfo(bank, paysystem);
  }

  private Map<String, Object> getRedisMap(Map<String, Object> value) {
    final var map = new LinkedHashMap<String, Object>();
    map.put("low", (String) value.get("low"));
    map.put("high", (String) value.get("high"));
    map.put("issuer", (String) value.getOrDefault("bank_name", DEFAULT_VALUE));
    map.put("country", (String) value.getOrDefault("country", DEFAULT_VALUE));
    map.put("product", (String) value.getOrDefault("product_string", DEFAULT_VALUE));
    map.put("paysystem", (String) value.get(PAYSYSTEM));
    return map;
  }
}