package ru.vtb.tsp.ia.epay.cardinfo.configs;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.TimeoutOptions;
import io.lettuce.core.resource.ClientResources;
import io.lettuce.core.resource.DefaultClientResources;
import java.time.Duration;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cache.CacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericJackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import ru.vtb.tsp.ia.epay.cardinfo.configs.properties.RedisProperties;

@Slf4j
@Configuration
@ConditionalOnProperty(name = "spring.redis.mock", havingValue = "false")
@RequiredArgsConstructor
public class RedisConfig {

  public static final String REDIS_CIRCUIT_BREAKER = "redisCircuitBreaker";

  private final RedisProperties redisProperties;

  @Value("${spring.redis.maxWait}")
  private Integer redisTimeout;

  @Bean(destroyMethod = "shutdown")
  public ClientResources clientResources() {
    return DefaultClientResources.create();
  }

  @Bean
  public ClientOptions clientOptions() {
    return ClientOptions.builder()
        .timeoutOptions(TimeoutOptions.enabled(Duration.ofMillis(this.redisTimeout)))
        .disconnectedBehavior(ClientOptions.DisconnectedBehavior.REJECT_COMMANDS)
        .autoReconnect(true)
        .build();
  }

  @Bean
  public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
    return RedisCacheManager.RedisCacheManagerBuilder
        .fromConnectionFactory(redisConnectionFactory)
        .build();
  }

  @Bean
  public GenericObjectPoolConfig genericObjectPoolConfig() {
    GenericObjectPoolConfig genericObjectPoolConfig = new GenericObjectPoolConfig();
    genericObjectPoolConfig.setMaxIdle(redisProperties.getMaxIdle());
    genericObjectPoolConfig.setMinIdle(redisProperties.getMinIdle());
    genericObjectPoolConfig.setMaxTotal(redisProperties.getMaxActive());
    genericObjectPoolConfig.setMaxWait(Duration.ofMillis(redisProperties.getMaxWait()));
    return genericObjectPoolConfig;
  }

  @Bean
  LettucePoolingClientConfiguration lettucePoolConfig(
      GenericObjectPoolConfig genericObjectPoolConfig,
      ClientOptions options,
      ClientResources dcr) {
    return LettucePoolingClientConfiguration.builder()
        .poolConfig(genericObjectPoolConfig)
        .clientOptions(options)
        .clientResources(dcr)
        .build();
  }

  @Bean
  @Lazy
  public RedisConnectionFactory connectionFactory(
      LettucePoolingClientConfiguration lettucePoolConfig) {
    final RedisStandaloneConfiguration config = new RedisStandaloneConfiguration();
    config.setHostName(redisProperties.getHost());
    config.setPort(redisProperties.getPort());
    if (redisProperties.isSupportUsername()) {
      config.setUsername(redisProperties.getUsername());
    }
    config.setPassword(redisProperties.getPassword());
    return new LettuceConnectionFactory(config, lettucePoolConfig);
  }

  @Bean
  @ConditionalOnMissingBean(name = "redisTemplate")
  @Primary
  public RedisTemplate<String, Object> redisTemplate(
      RedisConnectionFactory redisConnectionFactory) {
    RedisTemplate<String, Object> template = new RedisTemplate<>();
    // Using the Jackson library to serialize objects into JSON strings
    template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
    template.setKeySerializer(new StringRedisSerializer());
    template.setHashKeySerializer(new StringRedisSerializer());
    template.setHashValueSerializer(new GenericJackson2JsonRedisSerializer());
    template.setConnectionFactory(redisConnectionFactory);
    return template;
  }
}
