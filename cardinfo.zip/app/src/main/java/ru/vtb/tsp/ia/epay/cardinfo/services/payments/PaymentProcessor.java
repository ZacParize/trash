package ru.vtb.tsp.ia.epay.cardinfo.services.payments;

import java.util.Optional;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;

public interface PaymentProcessor {

  public Optional<TransactionPayload> handle(TransactionPayload payload);

}
