package ru.vtb.tsp.ia.epay.cardinfo.services.payments;

import static ru.vtb.tsp.ia.epay.cardinfo.services.payments.CardPaymentProcessor.BEAN_NAME;

import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.cardinfo.services.BinService;
import ru.vtb.tsp.ia.epay.cardinfo.services.CryptoService;
import ru.vtb.tsp.ia.epay.cardinfo.services.Utils;
import ru.vtb.tsp.ia.epay.cardinfo.services.exceptions.PanValidationException;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionType;
import ru.vtb.tsp.ia.epay.tokenization.dto.domains.Binding;

@Service(BEAN_NAME)
@Slf4j
@RequiredArgsConstructor
public class CardPaymentProcessor implements PaymentProcessor {

  public static final String BEAN_NAME = "cardPaymentProcessor";

  private final CryptoService cryptoService;
  private final BinService binService;

  @Override
  public Optional<TransactionPayload> handle(TransactionPayload payload) {
    log.info("Start processing for encrypted PAN");
    final String encryptedPan = ((Card) payload.getPaymentData()).getEncryptedPan();
    final String encryptedCvv = ((Card) payload.getPaymentData()).getEncryptedCvv();
    cryptoService.getDpan(payload.getTransactionId(), encryptedPan, encryptedCvv)
        .ifPresent(dpan -> {
          //TODO Пока только для транзакций A2C_TRANSFER
          if ((!CryptoService.isPanValid(dpan.getPan()))
              && (TransactionType.A2C_TRANSFER.equals(payload.getType()))) {
            throw new PanValidationException(payload);
          } else {
            ((Card) payload.getPaymentData())
                .setDpanMasked4digets(Utils.getMaskedDpan(dpan.getDpan()));
            ((Card) payload.getPaymentData()).setBinding(Binding.builder()
                .token(dpan.getDpan())
                .build());
            final var bin = binService.find(dpan.getDpan());
            payload.getContext().put(TransactionInfoKey.CARD_BANK.getValue(),
                bin.getBank());
            payload.getContext().put(TransactionInfoKey.CARD_PAYSYSTEM.getValue(),
                bin.getPaysystem());
          }
        });
    return Optional.of(payload);
  }
}
