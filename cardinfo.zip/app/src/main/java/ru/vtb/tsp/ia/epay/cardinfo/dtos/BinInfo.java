package ru.vtb.tsp.ia.epay.cardinfo.dtos;

import java.io.Serializable;
import lombok.Value;

@Value
public class BinInfo implements Serializable {

  public static final BinInfo EMPTY_BIN = new BinInfo(null, null);

  String bank;
  String paysystem;

}