package ru.vtb.tsp.ia.epay.cardinfo.configs;

import feign.Client;
import feign.Retryer;
import feign.micrometer.MeteredClient;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Collections;
import javax.annotation.Nullable;
import javax.net.ssl.SSLContext;
import javax.validation.constraints.NotNull;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.conn.ssl.DefaultHostnameVerifier;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.ssl.SSLContextBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.ResourceUtils;
import ru.vtb.tsp.ia.epay.cardinfo.configs.properties.CryptoProperties;
import ru.vtb.tsp.ia.epay.cardinfo.services.MaskService;

@Configuration
@ConditionalOnProperty(name = "app.crypto.mock", havingValue = "false")
@EnableFeignClients(basePackages = {"ru.vtb.tsp.ia.epay.cardinfo.client"})
@Slf4j
public class FeignConfig {

  private static final long RETRY_PERIOD = 250L;
  private static final long RETRY_MAX_PERIOD = 2000L;
  private static final int RETRY_MAX_ATTEMPTS = 7;

  @Bean
  public FeignLogger feignLogger(MaskService maskService) {
    return new FeignLogger(maskService);
  }

  @Bean
  public Client client(CryptoProperties cryptoProperties) {
    final var ssl = getSSLContext(cryptoProperties, cryptoProperties.isClientAuth(),
        cryptoProperties.isCertValidation());
    return new MeteredClient.Default(ssl.getSocketFactory(),
        cryptoProperties.isCertValidation() ? new DefaultHostnameVerifier()
            : new NoopHostnameVerifier());

  }

  @Bean
  public Retryer retryer() {
    return new Retryer.Default(RETRY_PERIOD, RETRY_MAX_PERIOD, RETRY_MAX_ATTEMPTS);
  }

  private @NotNull KeyStore getKeystore(@NotNull String keystorePath,
                                        @NotNull String keystorePass) {
    try {
      final var keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      final var keyStoreInputStream = new FileInputStream(ResourceUtils.getFile(keystorePath));
      keyStore.load(keyStoreInputStream, keystorePass.toCharArray());
      return keyStore;
    } catch (CertificateException | IOException | NoSuchAlgorithmException | KeyStoreException ex) {
      log.error("Error occurred during keystore loading", ex);
      throw new ApplicationContextException("Error occurred during keystore loading", ex);
    }
  }

  private @Nullable String getKeyAlias(@NotNull KeyStore keyStore) {
    try {
      final var aliases = keyStore.aliases();
      for (String alias : Collections.list(aliases)) {
        log.info("FeignClientConfig keystore aliases {}", alias);
        if (keyStore.isKeyEntry(alias)) {
          log.info("FeignClientConfig key {}", alias);
          return alias;
        }
      }
    } catch (KeyStoreException ex) {
      log.error("Error occurred during keystore loading alias", ex);
      throw new ApplicationContextException("Error occurred during keystore loading alias", ex);
    }
    return null;
  }

  private @NotNull SSLContext getSSLContext(CryptoProperties cryptoProperties,
      boolean clientAuth, boolean certValidation) {
    final var builder = new SSLContextBuilder();
    try {
      if (clientAuth) {
        final var keyStore = getKeystore(cryptoProperties.getKeystorePath(),
            cryptoProperties.getKeystorePass());
        builder.loadKeyMaterial(keyStore, cryptoProperties.getKeystorePass().toCharArray(),
            ((aliases, socket) -> getKeyAlias(keyStore)));
      }
      if (certValidation) {
        builder.loadTrustMaterial(ResourceUtils.getFile(cryptoProperties.getTruststorePath()),
            cryptoProperties.getTruststorePass().toCharArray());
      } else {
        builder.loadTrustMaterial(null,
            (X509Certificate[] chain, String authType) -> true);
      }
      return builder.build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException
        | KeyManagementException | UnrecoverableKeyException ex) {
      log.error("Error occurred during creation ssl context", ex);
      throw new ApplicationContextException("Error occurred during creation ssl context", ex);
    }
  }

  @Bean
  public CustomErrorDecoder errorDecoder() {
    return new CustomErrorDecoder();
  }

}
