package ru.vtb.tsp.ia.epay.cardinfo.dtos;

import java.io.Serializable;
import lombok.Value;

@Value
public class CardInfo implements Serializable {

  public static final CardInfo EMPTY_CARD_INFO = new CardInfo(null, null);

  BankInfo bank;
  String paysystem;

}