package ru.vtb.tsp.ia.epay.cardinfo.services;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import javax.annotation.Nullable;
import javax.validation.constraints.NotEmpty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.vtb.tsp.ia.epay.cardinfo.dtos.BankInfo;
import ru.vtb.tsp.ia.epay.cardinfo.services.cache.CacheService;

@Slf4j
@Service
public class BankService {

  private static final String BANK_PREFIX = "BANK_";
  private static final String BANK_MAX_PREFIX_LENGTH = "BANK_MAX_PREFIX_LENGTH";
  private static final String BANK_MIN_PREFIX_LENGTH = "BANK_MIN_PREFIX_LENGTH";

  private final ObjectMapper objectMapper;
  private final CacheService redisCache;
  private final String fileName;

  public BankService(ObjectMapper objectMapper,
      @Value("${app.bankFileName}") @NotEmpty String fileName, CacheService redisCache) {
    this.objectMapper = objectMapper;
    this.redisCache = redisCache;
    this.fileName = fileName;
  }

  protected boolean load() {
    return load(this.fileName);
  }

  protected boolean load(@Nullable String fileName) {
    if (ObjectUtils.isEmpty(fileName)) {
      return false;
    }
    try (final var inputStream = getClass().getResourceAsStream(fileName)) {

      if (Objects.isNull(inputStream)) {
        return false;
      }

      log.info("Static banks configuration would be loaded from file {}", fileName);

      Map<String, Map<String, Object>> banks = new HashMap<>();
      banks.putAll(objectMapper.readValue(inputStream.readAllBytes(), new TypeReference<>() {
      }));

      int minPrefixLength = banks.get("prefixes").keySet().stream()
          .min(Comparator.comparing(String::length)).map(String::length)
          .orElseThrow(NoSuchElementException::new);
      int maxPrefixLength = banks.get("prefixes").keySet().stream()
          .max(Comparator.comparing(String::length)).map(String::length)
          .orElseThrow(NoSuchElementException::new);
      redisCache.set(BANK_MAX_PREFIX_LENGTH, maxPrefixLength);
      redisCache.set(BANK_MIN_PREFIX_LENGTH, minPrefixLength);
      banks.get("prefixes").forEach((k, v) -> {
        redisCache.set(BANK_PREFIX + k,
            new LinkedHashMap<>(Map.of("prefix", v, "bank", banks.get("banks").get(v))));
      });
      log.info("Static banks configuration was successfully loaded from file {}", fileName);
      return true;
    } catch (IOException | NullPointerException e) {
      log.error("Exception during processing static banks configuration file {}", fileName, e);
      return false;
    } catch (Exception e) {
      log.error("Error occurred during warm up bank and bin cache", e);
      return false;
    }
  }

  @SuppressWarnings("unchecked")
  public BankInfo find(@Nullable String cardNumber) {
    if (ObjectUtils.isEmpty(cardNumber)) {
      return BankInfo.EMPTY_BANK_INFO;
    }
    int minPrefixLength = (int) redisCache.get(BANK_MIN_PREFIX_LENGTH);
    int maxPrefixLength = (int) redisCache.get(BANK_MAX_PREFIX_LENGTH);
    final var minLength = Math.min(cardNumber.length(), minPrefixLength);
    final var maxLength = Math.min(cardNumber.length(), maxPrefixLength);

    if (minLength < minPrefixLength) {
      log.info("Card number {} is too short", cardNumber);
      return BankInfo.EMPTY_BANK_INFO;
    }

    for (int tempLength = maxLength; tempLength >= minLength; tempLength--) {
      final var tempCardNumber = cardNumber.substring(0, tempLength);
      final var bank = (Map<String, Object>) redisCache.get(BANK_PREFIX + tempCardNumber);
      if (Objects.nonNull(bank)) {
        Map<String, Object> bankMap = (Map<String, Object>) bank.get("bank");
        final var bankInfo = new BankInfo((String) bankMap.getOrDefault("name", null),
            (String) bankMap.getOrDefault("nameEn", null),
            (String) bankMap.getOrDefault("url", null),
            (String) bankMap.getOrDefault("backgroundColor", null),
            (List<String>) bankMap.getOrDefault("backgroundColors", null),
            (String) bankMap.getOrDefault("backgroundLightness", null),
            (String) bankMap.getOrDefault("logoStyle", null),
            (String) bankMap.getOrDefault("text", null),
            (String) bankMap.getOrDefault("alias", null),
            (String) bankMap.getOrDefault("country", null),
            (String) bankMap.getOrDefault("logoSvg", null));
        log.info("Found bank information {} by card number {}", bankInfo, cardNumber);
        return bankInfo;
      }
    }
    log.info("Found no bank information by card number {}", cardNumber);
    return BankInfo.EMPTY_BANK_INFO;
  }
}