package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.Objects;
import java.util.Optional;
import javax.validation.constraints.NotNull;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import ru.vtb.omni.audit.lib.api.annotation.AuditProcess;
import ru.vtb.tsp.ia.epay.cardinfo.client.api.CryptoApi;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.CvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.DpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedCvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedPanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.ExtDpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.PanDto;
import ru.vtb.tsp.ia.epay.cardinfo.services.cache.CacheService;
import ru.vtb.tsp.ia.epay.core.entities.redis.CardCacheDto;

@Slf4j
@Service
@RequiredArgsConstructor
public class CryptoService {

  private final CryptoApi cryptoApi;
  private final CacheService redisCache;

  public static boolean isPanValid(String pan) {
    if (StringUtils.isBlank(pan)) {
      return false;
    }
    pan = StringUtils.deleteWhitespace(pan);
    try {
      int sum = 0;
      for (int i = pan.length() - 1; i >= 0; i -= 2) {
        sum += Integer.parseInt(String.valueOf(pan.charAt(i)));
      }
      for (int i = pan.length() - 2; i >= 0; i -= 2) {
        sum += (Integer.parseInt(String.valueOf(pan.charAt(i))) * 2) % 9;
      }
      return 0 == sum % 10;
    } catch (Exception e) {
      log.error("Pan validation error {}", e.getMessage());
      return false;
    }
  }

  public Optional<CardCacheDto> getPanByDpan(@NotNull String txtId, @NotNull String dpan) {
    return Optional.of(dpan)
        .map(value -> new DpanDto(value))
        .flatMap(this::getPanDto)
        .map(panDto -> {
          final var cardCacheDto = CardCacheDto.builder()
              .dpan(dpan)
              .pan(panDto.getBody().getPan())
              .cvv(null)
              .build();
          redisCache.cache(txtId, cardCacheDto);
          return Optional.ofNullable(cardCacheDto);
        }).orElse(Optional.empty());
  }

  @AuditProcess("TSPACQ_BOX_DPAN_REQUEST")
  public Optional<CardCacheDto> getDpan(String txId, String encryptedPan, String encryptedCvv) {
    try {
      ExtDpanDto extDpan;
      EncryptedPanDto encryptedPanDto = new EncryptedPanDto(encryptedPan);
      extDpan = cryptoApi.getDPANbyEncPANExt(encryptedPanDto).getBody();
      CardCacheDto cardCacheDto = null;
      if (extDpan != null) {
        final var cvvDto = getCvvDto(encryptedCvv);
        cardCacheDto = CardCacheDto.builder()
            .dpan(extDpan.getDpan())
            .pan(extDpan.getPan())
            .cvv(Objects.nonNull(cvvDto) ? cvvDto.getCvv() : null)
            .build();
        redisCache.cache(txId, cardCacheDto);
      }
      return Optional.ofNullable(cardCacheDto);
    } catch (Exception ex) {
      log.error("Error occurred during getting DPAN", ex);
    }
    return Optional.empty();
  }

  private CvvDto getCvvDto(String encryptedCvv) {
    return Optional.ofNullable(encryptedCvv)
        .map(encCvv -> cryptoApi.getCVVbyEncCVV(new EncryptedCvvDto(encCvv)).getBody())
        .orElse(null);
  }

  private Optional<ResponseEntity<PanDto>> getPanDto(DpanDto dpanDto) {
    try {
      return Optional.of(cryptoApi.getPANbyDPAN(dpanDto));
    } catch (Exception ex) {
      log.error("Error occurred during getting PAN", ex);
      return Optional.empty();
    }
  }

}