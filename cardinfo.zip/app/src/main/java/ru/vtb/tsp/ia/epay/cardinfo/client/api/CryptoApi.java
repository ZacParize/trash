package ru.vtb.tsp.ia.epay.cardinfo.client.api;

import javax.validation.constraints.NotNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.CvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.DpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.DpanPublicKeyDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedCvvDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedCvvPublicKeyDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.EncryptedPanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.ExtDpanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.PanDto;
import ru.vtb.tsp.ia.epay.cardinfo.client.dto.PublicKeyDto;
import ru.vtb.tsp.ia.epay.cardinfo.services.monitoring.ExtPrometheusMertics;

@ExtPrometheusMertics
public interface CryptoApi {

  /**
   * Возвращает публичный ключ для шифрования PAN карты.
   */
  @GetMapping(path = "/getPublicKey", produces = "application/json",
      consumes = "application/json")
  @Deprecated
  @NotNull ResponseEntity<PublicKeyDto> getPublicKey();

  /**
   * Возвращает публичный ключ для шифрования CVV карты.
   */
  @GetMapping(path = "/cvv/getPublicKey", produces = "application/json",
      consumes = "application/json")
  @Deprecated
  @NotNull ResponseEntity<PublicKeyDto> getCvvPublicKey();

  /**
   * На входе принимает CVV карты, зашифрованный публичным ключом, полученным от сервиса. Возвращает
   * расшифрованный CVV карты.
   */
  @PostMapping(path = "/getCVVbyEncCVV", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<CvvDto> getCVVbyEncCVV(@RequestBody EncryptedCvvDto encryptedCvvDto);

  /**
   * На входе принимает зашифрованный CVV карты. Возвращает CVV карты, зашифрованный клиентским
   * публичным ключом.
   */
  @PostMapping(path = "/getEncCVVbyEncCVV", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<EncryptedCvvDto> getEncCVVbyEncCVV(
      @RequestBody EncryptedCvvPublicKeyDto encryptedCvvPublicKeyDto);

  /**
   * На входе принимает зашифрованный PAN карты. Возвращает DPAN карты.
   */
  @PostMapping(path = "/getDPANbyEncPAN", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<DpanDto> getDPANbyEncPAN(@RequestBody EncryptedPanDto encryptedPanDto);

  /**
   * Расширенный метод /getDPANbyEncPAN. На входе принимает зашифрованный PAN карты. Возвращает DPAN
   * карты и расшифрованный PAN.
   */
  @PostMapping(path = "/getDPANbyEncPANExt", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<ExtDpanDto> getDPANbyEncPANExt(
      @RequestBody EncryptedPanDto encryptedPanDto);

  /**
   * На входе принимает DPAN карты. Возвращает зашифрованный PAN карты.
   */
  @PostMapping(path = "/getEncPANbyDPAN", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<EncryptedPanDto> getEncPANbyDPAN(
      @RequestBody DpanPublicKeyDto dpanPublicKeyDto);

  /**
   * На входе принимает PAN карты. Возвращает DPAN карты.
   */
  @PostMapping(path = "/getDPANbyPAN", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<DpanDto> getDPANbyPAN(@RequestBody PanDto panDto);

  /**
   * На входе принимает DPAN карты. Возвращает PAN карты.
   */
  @PostMapping(path = "/getPANbyDPAN", produces = "application/json",
      consumes = "application/json")
  @NotNull ResponseEntity<PanDto> getPANbyDPAN(@RequestBody DpanDto dpanDto);

}
