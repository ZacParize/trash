package ru.vtb.tsp.ia.epay.cardinfo.client;

import org.springframework.cloud.openfeign.FeignClient;
import ru.vtb.tsp.ia.epay.cardinfo.client.api.CryptoApi;

@FeignClient(name = "cryptoApi", url = "${app.crypto.url}", decode404 = true)
public interface CryptoClient extends CryptoApi {

}
