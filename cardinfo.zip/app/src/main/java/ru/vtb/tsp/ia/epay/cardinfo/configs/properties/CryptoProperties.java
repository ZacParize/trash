package ru.vtb.tsp.ia.epay.cardinfo.configs.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Data
@Component
@ConfigurationProperties(prefix = "app.crypto")
public class CryptoProperties {

  private String url;
  private boolean mock;
  private String truststorePath;
  private String truststorePass;
  private String keystorePath;
  private String keystorePass;
  private boolean clientAuth;
  private boolean certValidation;
}
