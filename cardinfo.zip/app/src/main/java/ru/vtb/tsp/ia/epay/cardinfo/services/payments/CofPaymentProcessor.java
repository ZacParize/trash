package ru.vtb.tsp.ia.epay.cardinfo.services.payments;

import static ru.vtb.tsp.ia.epay.cardinfo.services.payments.CofPaymentProcessor.BEAN_NAME;

import java.util.Objects;
import java.util.Optional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import ru.vtb.tsp.ia.epay.cardinfo.services.BinService;
import ru.vtb.tsp.ia.epay.cardinfo.services.CryptoService;
import ru.vtb.tsp.ia.epay.cardinfo.services.Utils;
import ru.vtb.tsp.ia.epay.core.domains.transaction.TransactionPayload;
import ru.vtb.tsp.ia.epay.core.domains.transaction.payment.method.Card;
import ru.vtb.tsp.ia.epay.core.entities.transaction.TransactionInfoKey;
import ru.vtb.tsp.ia.epay.tokenization.dto.enums.PaymentSystem;

@Service(BEAN_NAME)
@Slf4j
@RequiredArgsConstructor
public class CofPaymentProcessor implements PaymentProcessor {

  public static final String BEAN_NAME = "cofPaymentProcessor";

  private final CryptoService cryptoService;
  private final BinService binService;

  @Override
  public Optional<TransactionPayload> handle(TransactionPayload payload) {
    log.info("Start processing for DPAN");
    var card = ((Card) payload.getPaymentData());
    final var dPan = ((Card) payload.getPaymentData()).getBinding().getToken();
    cryptoService.getPanByDpan(payload.getTransactionId(), dPan)
        .ifPresent(dpanDto -> {
          if (Objects.nonNull(dpanDto.getPan())) {
            final var bin = binService.find(dpanDto.getPan());
            card.setDpanMasked4digets(Utils.getMaskedDpan(dpanDto.getPan()));
            card.getBinding().setMaskedPan(StringUtils.right(dpanDto.getPan(), 4));
            binPaySystemToEnum(bin.getPaysystem())
                .ifPresent(paymentSystem -> {
                  card.getBinding().setPaymentSystem(paymentSystem);
                });
            if (Objects.nonNull(bin)) {
              payload.getContext().put(TransactionInfoKey.CARD_BANK.getValue(),
                  bin.getBank());
              payload.getContext().put(TransactionInfoKey.CARD_PAYSYSTEM.getValue(),
                  bin.getPaysystem());
            }
          }
        });
    return Optional.of(payload);
  }

  private Optional<PaymentSystem> binPaySystemToEnum(String binPaySystem) {
    return Optional.of(binPaySystem)
        .flatMap(bin -> {
          if (Objects.equals("MR", StringUtils.upperCase(binPaySystem))) {
            return Optional.of(PaymentSystem.MIR);
          } else if (Objects.equals("VS", StringUtils.upperCase(binPaySystem))) {
            return Optional.of(PaymentSystem.VISA);
          } else if (Objects.equals("MC", StringUtils.upperCase(binPaySystem))) {
            return Optional.of(PaymentSystem.MC);
          }
          return Optional.empty();
        });
  }
}
