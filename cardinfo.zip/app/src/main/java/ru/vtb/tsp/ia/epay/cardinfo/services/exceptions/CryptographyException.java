package ru.vtb.tsp.ia.epay.cardinfo.services.exceptions;

public class CryptographyException extends ServiceException {

  public CryptographyException() {
    super(ApplicationException.CRYPTOGRAPHY_EXCEPTION, null);
  }

}