package ru.vtb.tsp.ia.epay.cardinfo.services;

import java.util.Optional;
import org.apache.commons.lang3.StringUtils;

public class Utils {

  public static String getMaskedDpan(String value) {
    return Optional.ofNullable(value).map(s -> StringUtils.defaultIfEmpty("**** **** **** "
        + StringUtils.substring(s, s.length() - 4, s.length()), "")
    ).orElse("");
  }

  public static String mask(String cardNumber, int showFirstDigitCount, int showLastDigitCount) {
    if (StringUtils.isNotBlank(cardNumber)) {
      cardNumber = StringUtils.deleteWhitespace(cardNumber);
    }
    if (StringUtils.length(cardNumber) <= showFirstDigitCount + showLastDigitCount) {
      return StringUtils.repeat("*", StringUtils.length(cardNumber));
    }
    final var leftPart = StringUtils.left(cardNumber, showFirstDigitCount);
    final var maskedPart = StringUtils.repeat("*",
        cardNumber.length() - (showFirstDigitCount + showLastDigitCount));
    final var rightPart = StringUtils.right(cardNumber, showLastDigitCount);
    return leftPart + maskedPart + rightPart;
  }

}
